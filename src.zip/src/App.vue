<template>
  <div id="app" class="clearfix" @click="globalevent" @contextmenu.prevent="globalevent">
    <router-view />
  </div>
</template>

<script>
  export default {
    name: 'app',
    created() {
      // $utils.(GLOBAL_CONST.USER_INFO, userData)
    },
    mounted() {


    },
    methods: {
      globalevent(ev) {
        // if(ev.toElement.className.includes(demand-treeicon )){
        if (ev.toElement.className !== 'menu' && document.getElementById('menu')) {
          document.getElementById('menu').style.display = 'none';
        }
        // }
      }
    }
  }
</script>

<style lang="scss">
  // 这里面属于保留样式
  @import 'base/style/global';

  .clearfix::after {
    content: ".";
    clear: both;
    display: block;
    overflow: hidden;
    font-size: 0;
    height: 0;
  }

  .clearfix {
    zoom: 1;
  }

  #app .taskEdit-title .title-input .el-input__inner {
    padding: 3px 10px 4px 2px;
    font-size: 26px;
    font-weight: 200;
    height: 38px;
    border: 1px solid #ccc;
    /* border-bottom: 1px solid #ccc; */
    color: #777;
  }


  #app {
    height: 100%;
    /* overflow-y: hidden; */

    font-family: "microsoft yahei", 'Avenir', Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    color: #606266;
    // background:#373d41;

    .c-blue {
      // color: #4d9bff !important;
    }

    .c-disabled {
      color: #dde5ef !important;
    }

    .cp {
      cursor: pointer;
    }

    .cursor-default {
      cursor: default;
    }

    .cursor-text {
      cursor: text;
    }

    .content-box {
      .content-inter-box {
        min-width: 920px;
        width: 100%;
        height: 100%;
      }

      .function-header {
        border-bottom: none !important;
        height: 40px !important;
      }

      .product-box {
        width: 250px;
      }

      .content-inter-box {
        width: 100%;
        height: calc(100% - 50px);
      }

      abbr,
      acronym {
        border: 0;
      }

      a {
        text-decoration: none
      }

      .fm-d {
        font-family: 'Microsoft YaHei';
      }

      .cb {
        clear: both;
      }

      .cl {
        clear: left;
      }

      .cr {
        clear: right;
      }

      .clearfix:after {
        content: '.';
        display: block;
        height: 0;
        clear: both;
        visibility: hidden;
      }

      .clearfix {
        display: inline-block;
      }

      * html .clearfix {
        height: 1%;
      }

      .Clearfix {
        display: block;
      }

      .cp {
        cursor: pointer;
      }
    }

    .c-blue {
      color: #2196F3;
    }

    .c-yellow {
      color: rgba(255, 150, 50, .98) !important;
    }

    .c-red {
      color: #ff0d00 !important;
    }

    .task-name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      width: 70px;
      display: inline-block;
    }

    .c-error {
      color: red !important;
    }

    .c-gray {
      color: #999999 !important;
    }


    .width-input-select {
      width: 500px;
    }

    .button-left {
      margin-left: 49%;
    }

    .white-box {
      background: #fff;
      margin: 0px 5px 0px 5px;
      transition: all 0.5s linear;
      -moz-transition: all 0.3s linear;
      /* Firefox 4 */
      -webkit-transition: all 0.3s linear;
      /* Safari and Chrome */
      -o-transition: all 0.3s linear;
      /* Opera */
    }

    .table_b_f_b {
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
      width: 100%;
      height: 40px;
      border-top: none;
    }

    .el-button {
      padding: 7px 15px !important;
      font-size: 12px !important;
    }


    .el-dialog__header {
      background-color: #f2f2f2;
      padding: 12px 16px;
      border-radius: 5px 5px 0 0;
      height: 18px !important;
      text-align: left;
    }

    .el-dialog__headerbtn {
      top: 11px;
    }

    .el-dialog__body {
      padding: 15px 15px 10px 15px;
      font-size: 13px;
    }

    .el-date-range-picker {
      margin-left: 195px;
    }

    .ratio-input {
      width: 16%;

      input {
        text-align: right;
      }
    }

    .el-textarea__inner {
      font-family: "Helvetica Neue", Helvetica, "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "微软雅黑", Arial, sans-serif;
      font-size: 13px;
      font-weight: 500;
    }


    .form-btn-box {
      overflow: hidden;
      padding: 12px 24px 16px 24px;
      border-top: 1px solid #d8dee5;
    }


    .el-dialog--tiny {
      width: 380px;
      transition: all 0.5s linear;
      -moz-transition: all 0.5s linear;
      /* Firefox 4 */
      -webkit-transition: all 0.5s linear;
      /* Safari and Chrome */
      -o-transition: all 0.5s linear;
      /* Opera */
    }

    .el-dialog--large {
      width: 720px;
    }


    .global-search-box {
      position: absolute;
      left: 50%;
      margin-left: -150px;
    }

    .el-tabs--card .el-icon-close {
      font-size: 15px;
      color: #fff !important;
      background: #cccccc !important;
    }

    .el-tabs--card .el-icon-close:hover {
      background: #fb5736 !important;
    }


    .table-box {
      box-sizing: border-box;
      background: #fff;
      height: 100%;
    }

    .table-box .table-box-top {
      width: 100%;
      height: calc(100% - 44px);
      height: -webkit-calc(100% - 44px);
    }

    .table-outer-box {
      box-sizing: border-box;
    }

    .el-loading-mask {
      z-index: 2000;
    }


    /*.table-box-tab .el-tabs__header .el-tabs__item.is-active.is-closable {*/
    /*color: #20a0ff;*/
    /*}*/

    $blue: #60a0ff;

    .hover-blue:hover {
      color: #4d9bff;
    }


    .h-inherit {
      height: inherit !important;
    }


    .table_b_f_b {
      -webkit-box-sizing: border-box;
      -moz-box-sizing: border-box;
      box-sizing: border-box;
      width: 100%;
      height: 40px;
    }

    .el-table {
      font-size: 13px;
    }

    .el-table th>.cell {
      line-height: 34px;
    }

    .el-table td,
    .el-table th {
      padding: 2px 0;
      height: 34px;
    }

    .el-table th {
      background-color: #eef0f6;
      border-bottom: 1px solid #dfe3ed !important;
    }

    .el-table .cell,
    .el-table th>div {
      padding-left: 10px;
      padding-right: 10px;
    }

    .el-table--fit {
      border-bottom: 0;
    }

    .el-table:after {
      width: 0px;
    }

    .el-table:before {
      height: 0px;
    }

    .el-table td.gutter,
    .el-table th.gutter {
      background-color: #ebeef5;
    }

    /*这个类是为了解决当表格没有数据的时候出现左边框设置的类*/
    .el-table-left-none {
      border-left: none;
    }

    .el-table-right-none {
      border-right: 1px solid #dfe3ed;

    }

    .tree-table-left-none {
      .el-table--border {
        border-left: none;
      }
    }

    .tree-table-right-none {
      .el-table--border {
        border-right: 1px solid #dfe3ed;
      }
    }

    //需求关联当数据不存在的时候让表格body隐藏
    .el-table__body-none {
      .el-table__body-wrapper {
        display: none;
      }
    }

    .el-table__body-wrapper::-webkit-scrollbar {
      /*滚动条整体样式*/
      width: 8px;
      /*高宽分别对应横竖滚动条的尺寸*/
      height: 8px;
    }

    .el-table__body-wrapper::-webkit-scrollbar-thumb {
      /*滚动条里面小方块*/
      border-radius: 10px;
      -webkit-box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
      background: #999;
    }

    .el-table__body-wrapper::-webkit-scrollbar-track {
      /*滚动条里面轨道*/
      /* -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
        border-radius: 10px; */
      background: #eee;
    }

    .el-button {
      padding: 7px 15px;
      font-size: 12px;
    }

    .el-select-dropdown__item {
      font-size: 12px;
      min-width: 85px;
    }


    /*.el-tabs__item {*/
    /*font-size: 13px;*/
    /*font-weight: 400;*/
    /*color: #666666;*/
    /*}*/

    .el-tabs--card>.el-tabs__header .el-tabs__nav {
      border-left: 1px solid #fff;
      border-right: 1px solid #fff;
      border-top: 1px solid #fff;
    }

    .el-form-item__error {
      padding-top: 2px;
    }

    .table-box {
      box-sizing: border-box;
      background: #fff;
      height: 100%;

      .table-box-top {
        width: 100%;
        height: calc(100% - 40px);
        height: -webkit-calc(100% - 40px);
      }
    }

    // .el-date-editor--daterange.el-input__inner {
    //   width: 250px;
    // }

    .el-date-editor .el-range-input {
      width: 35%;
    }

    .el-date-editor .el-range__close-icon {
      width: 22px;
    }

    .el-tabs--card>.el-tabs__header .el-tabs__nav {
      border-radius: 0px;
    }

    .blue {
      div {
        color: blue
      }

      p {
        color: blue
      }
    }


    .el-textarea__inner {
      resize: both !important;
    }

    // ===============================================================弹窗样式高度及宽度===================================================================
    .el-dialog__footer {
      // border-top: 1px solid #d8dee5;
      height: 50px;
    }


    #oemDialog {
      .el-dialog__body {
        height: calc(100% - 40px);
        padding: 10px 5px 10px 5px;
      }
    }

    #appVersionPipeline {
      .el-dialog__body {
        height: calc(100% - 62px);
        padding: 0px 5px 10px 5px;
      }
    }

    .el-dialog__title {
      vertical-align: text-top;
      line-height: 18px;
      font-size: 14px;
    }

    .el-dialog-350w .el-dialog {
      width: 350px;
    }

    .el-dialog-400w .el-dialog {
      width: 400px;
    }

    .el-dialog-580w .el-dialog {
      width: 580px !important;
    }

    .el-dialog-640w .el-dialog {
      width: 640px !important;
    }

    .el-dialog-740w .el-dialog {
      width: 740px !important;
    }

    .el-dialog-880w .el-dialog {
      width: 880px !important;
    }

    .el-dialog-920w .el-dialog {
      width: 920px !important;
    }

    .el-dialog-1180w .el-dialog {
      width: 1180px !important;
    }

    .el-dialog-1200w .el-dialog {
      min-width: 1180px;
    }

    .el-dialog-1300w .el-dialog {
      min-width: 1280px;
    }


    #appVersionPipeline {
      .el-dialog {
        margin-top: 8vh !important;
      }
    }

    .form-iterm-box {
      padding: 10px 10px 10px 10px !important;
      overflow: hidden;
      height: 100%;
      box-sizing: border-box;

      img {
        max-width: 100%;
      }
    }

    .el-transfer {
      min-height: 470px;
      padding-top: 15px;
      padding-left: 10px;

      .el-transfer-panel {
        width: 270px;
        height: 440px;

        .el-transfer-panel__list {
          height: 330px;
        }
      }

      .el-transfer-panel__body {
        height: 383px;
      }

      .el-button--primary {
        height: 46px;
      }

      .el-input__inner {
        border: 1px solid #DDE5EF;
        height: 28px;
        font-size: 13px;
        border-radius: 2px;
        padding: 0px 10px 0px 33px;
      }
    }

    .el-input__icon {
      line-height: 30px;
    }

    #date_form {
      .el-input__inner {
        padding-left: 30px;
      }
    }

    .date_form1 {
      .el-input__inner {
        // padding-left: 30px;
      }
    }

    .date_start {
      .el-input__inner {
        padding-left: 30px;
      }
    }

    .el-time-select>.el-input__inner {
      padding-left: 30px !important;
    }
  }


  .ql-editor {
    min-height: 400px;
  }

  #app #taskEdit .ql-editor {
    min-height: 220px;
  }

  #app #pane-comment .tinymce-editor {
    min-height: 220px;
  }

  .ql-editor p img {
    width: auto;
  }

  #app #taskEdit .ql-toolbar.ql-snow {
    border: none;
    border-bottom: 1px solid #ccc;
  }

  #app #taskEdit .ql-container.ql-snow {
    border: none;
    border-bottom: 1px solid #ccc;
  }

  .edit-box p img {
    width: auto;
    max-width: 100%;
  }

  #app .el-dialog-img .el-dialog .el-dialog__header {
    height: 0 !important;
    padding: 0;
  }

  .scrollbar-apidoc-tree.el-scrollbar .el-scrollbar__wrap {
    overflow-x: hidden;
  }

  .tree-detail.el-tree>.custom-tree-node {
    display: inline-block;
  }
  
  * { touch-action: pan-y; } 
</style>