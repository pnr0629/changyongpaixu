import Vue from 'vue';

/**
 * 路由高阶组件
 * 包含模块加载错误处理, 原理来自 vue 官方文档，自己增加了错误处理
 * 用以解决频繁发版，导致用于进不去某些页面的问题
 * time: 2019.6.18
 * author: heyunjiang
 */
const componentWrapper = (component_promise_func) => {
  return () => ({
    component: (() => {
      const redirectUrl = process.env.NODE_ENV==='development'?"//dev.columbus.os.adc.com":"//columbus.os.adc.com";
      const component_promise = component_promise_func()
      component_promise.catch(e => {
        // window.location.href=redirectUrl;
        if(process.env.NODE_ENV==='development') {
          console.log(e)
        } else {
          location.reload()
        }
      })
      return component_promise;
    })()
  })
}

// const commend = (resolve) =>{requirement(['components/commend/commend'],resolve)};
const err_page = componentWrapper(() => import('components/err_page'));

//业务
const biz = componentWrapper(() => import('components/biz/index'));

const bizArray = ['bizList', 'bizMemberSetting', 'bizInfoSetting', 'bizImageSetting', 'gitLabRegister',"bizInstanceTagSetting"]
const [bizList, bizMemberSetting, bizInfoSetting, bizImageSetting, gitLabRegister,bizInstanceTagSetting] = bizArray.map(item => {
  return componentWrapper(() => import('components/biz/' + item))
})

//应用
const appArray = ['appList', 'appCreate', 'appVersions', 'appDeployTaskList',
  'appPipeline', 'appPipelineList', 'appPipelineExecHistory', 'appLog', 'appSettings',
  'AppCompileTaskList', 'appCompileHistory', 'AppCompileTaskOverView','AppCompileTaskDetail',
  'featureBranchList', 'featureBranchDetails', 'featureBranchIntegration']
const [appList, appCreate, appVersions, appDeployTaskList, appPipeline, appPipelineList,
  appPipelineExecHistory, appLog, appSettings,  AppCompileTaskList, appCompileHistory, AppCompileTaskOverView,AppCompileTaskDetail,
  featureBranchList, featureBranchDetails, featureBranchIntegration]
  = appArray.map(item => {
    return componentWrapper(() => import('components/biz/app/' + item))
  })

const appCompileTaskList = componentWrapper(() => import('components/biz/app/compile/compileTaskList'));
const appCompileTaskEdit = componentWrapper(() => import('components/biz/app/compile/compileTaskEdit'));

//发布单
const deployArray = ['deployNoteList', 'deployNoteFlow', 'deployNoteManage', 'deployStatistics']
const [deployNoteList, deployNoteFlow, deployNoteManage, deployStatistics] = deployArray.map(item => {
  return resolve => require(['components/biz/deployNote/' + item], resolve)
})

const deployNoteIframe = componentWrapper(() => import('components/deployNoteIframe'));

// 接口文档
const apiArray = ['apiList']
const [apiList] = apiArray.map(item => {
  return resolve => require(['components/biz/api/' + item], resolve)
})

//项目
const project = componentWrapper(() => import('components/project/index'));
const projectList = componentWrapper(() => import('components/project/projectList'));

const bugList = componentWrapper(() => import('components/project/bugManagement/index'));

const personalManagementList = componentWrapper(() => import('components/project/personalManagement/personalManagementList'));

//需求
const requirementList = componentWrapper(() => import('components/project/requirement/requirementList'));
const requirementView = componentWrapper(() => import('components/project/requirement/requirementView'));

//任务
const taskView = componentWrapper(() => import('components/project/task/taskView'));

//迭代
const sprintArray = ['sprintList', 'sprintDetail', 'sprintPlan','SprintInfoCustom']
const [sprintList, sprintDetail, sprintPlan,SprintInfoCustom] = sprintArray.map(item => {
  return componentWrapper(() => import('components/project/sprint/' + item));
})

//度量
const metric = componentWrapper(() => import('components/metric'));

//我的
const mine = componentWrapper(() => import('components/mine'));

const requirementCreate = componentWrapper(() => import('components/mine/requirement/create'));
const mineRequirementView = componentWrapper(() => import('components/mine/requirement/view'));

const review = componentWrapper(() => import('components/mine/review/review'));
const reviewDetail = componentWrapper(() => import('components/mine/review/reviewDetail'));

//管理
const manageArray = ['cmdbManage', 'cmdbManage', 'memberManage', 'roleManage', 'authSetManage', 'menuManage', 'functionManage', 'imageManage', 'sonarTaskManage', 'sonarSystemManage', 'appManage']
const [manage, manageCmdb, memberManage, roleManage, authSetManage, menuManage, functionManage, imageManage, sonarTaskManage, sonarSystemManage, appManage] = manageArray.map(item => {
  return componentWrapper(() => import('components/manage/' + item));
})

//图表
const bugChart = componentWrapper(() => import('components/project/chart/bugChart'));
const cusromChart = componentWrapper(() => import('components/project/chart/NewCustormChart'));

//文档 fileList
const fileArray = ['fileCreat','fileList','fileInfo']
const [fileCreat,fileList,fileInfo] = fileArray.map(item =>{
  return componentWrapper(() => import('components/project/file/' + item));
});


const chartDetail = componentWrapper(() => import('components/project/chart/ChartDetail'));
const childRouter = [
  {
    path: '/err_page',
    name: 'err_page',
    component: err_page,
    meta: {
      public: true
    }
  },
  {
    path: '/biz/list',
    name: 'bizList',
    component: bizList
  },
  {
    path: '/deployNoteIframe',
    name: 'deployNoteIframe',
    component: deployNoteIframe,
  },
  {
    path: '/biz',
    name: 'biz',
    component: biz,
    props: true,
    children: [
      {
        path: '/biz/setting',
        name: 'bizSetting',
        redirect: { name: 'bizMemberSetting' },
        meta: {
          parent: 'bizList'
        }
      },
      {
        path: '/biz/member/setting',
        name: 'bizMemberSetting',
        component: bizMemberSetting,
        meta: {
          parent: 'bizSetting'
        }
      },
      {
        path: '/biz/info/setting',
        name: 'bizInfoSetting',
        component: bizInfoSetting,
        meta: {
          parent: 'bizSetting'
        }
      },
      {
        path: '/biz/image/setting',
        name: 'bizImageSetting',
        component: bizImageSetting,
        meta: {
          parent: 'bizSetting'
        }
      },
      {
        path: '/biz/instanceTag/setting',
        name: 'bizInstanceTagSetting',
        component: bizInstanceTagSetting,
        meta: {
          parent: 'bizSetting'
        }
      },
      {
        path: '/deployNote',
        name: 'deployNote',
        // component: deployNote,
        redirect: { name: 'deployNoteList' },
        meta: {
          parent: 'bizList'
        }
      },
      {
        path: '/deployNote/list',
        name: 'deployNoteList',
        component: deployNoteList,
        meta: {
          parent: 'deployNote'
        }
      },
      {
        path: '/deployNote/flow',
        name: 'deployNoteFlow',
        component: deployNoteFlow,
        meta: {
          parent: 'deployNote'
        }
      },
      {
        path: '/deployNote/statistics',
        name: 'deployStatistics',
        component: deployStatistics,
        meta: {
          parent: 'deployNote'
        }
      },
      {
        path: '/deployNote/manage',
        name: 'deployNoteManage',
        component: deployNoteManage,
        meta: {
          parent: 'deployNote'
        }
      },
      {
        path: '/app/create',
        name: 'appCreate',
        component: appCreate,
        meta: {
          parent: 'bizList'
        }
      },
      {
        path: '/app/list',
        name: 'appList',
        component: appList,
        meta: {
          parent: 'bizList',
          showSub: false
        }
      },
      {
        path: '/app/versions',
        name: 'appVersions',
        component: appVersions,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/compile/task/list',
        name: 'appCompileTaskList',
        component: appCompileTaskList,
        meta: {
          parent: 'appList'
        }

      },
      {
        path: '/app/compile/task/edit',
        name: 'appCompileTaskEdit',
        component: appCompileTaskEdit,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/compile/task/deloy',
        name: 'appDeployTaskList',
        component: appDeployTaskList,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/pipeline',
        name: 'appPipeline',
        component: appPipeline,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/pipeline/list',
        name: 'appPipelineList',
        component: appPipelineList,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/feature_branch/list',
        name: 'featureBranchList',
        component: featureBranchList,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/feature_branch/details',
        name: 'featureBranchDetails',
        component: featureBranchDetails,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/feature_branch/integration',
        name: 'featureBranchIntegration',
        component: featureBranchIntegration,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/pipeline/exec/history',
        name: 'appPipelineExecHistory',
        component: appPipelineExecHistory,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/log',
        name: 'appLog',
        component: appLog,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/settings',
        name: 'appSettings',
        component: appSettings,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/compile/list',
        name: 'AppCompileTaskList',
        component: AppCompileTaskList,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/compile/history',
        name: 'appCompileHistory',
        component: appCompileHistory,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/compile/overview',
        name: 'AppCompileTaskOverView',
        component: AppCompileTaskOverView,
        meta: {
          parent: 'appList'
        }
      },
      {
        path: '/app/compile/detail',
        name: 'AppCompileTaskDetail',
        component: AppCompileTaskDetail,
        meta: {
          parent: 'appList'
        }
      },

      {
        path: '/biz/gitlab',
        name: 'gitLabRegister',
        component: gitLabRegister,
        meta: {
          parent: 'bizList'
        }
      },
      {
        path: '/biz/apiList',
        name: 'apiList',
        component: apiList,
        meta: {
          parent: 'bizList'
        }
      },
    ]
  },
  //项目
  {
    path: '/project/list',
    name: 'projectList',
    component: projectList
  },
  {
    path: '/project',
    name: 'project',
    component: project,
    children: [
      {
        path: '/requirement/list',
        name: 'requirementList',
        component: requirementList,
        meta: {
          parent: 'projectList'
        }
      },
      {
        path: '/staffManage/list',
        name: 'personalManagementList',
        component: personalManagementList,
        meta: {
          parent: 'projectList'
        }
      },
      {
        path: '/requirement/view',
        name: 'requirementView',
        component: requirementView,
        meta: {
          parent: 'requirementList'
        }
      },
      //任务
      {
        path: '/task/view',
        name: 'taskView',
        component: taskView,
        meta: {
          parent: 'projectList'
        }
      },
      // {
      //   path: '/task/edit',
      //   name: 'taskEdit',
      //   component: taskEdit,
      //   meta: {
      //     parent: 'taskView'
      //   }
      // },
      {
        path: '/bugList/list',
        name: 'bugList',
        component: bugList,
        meta: {
          parent: 'projectList'
        }
      },
      {
        path: '/chart/bugChart',
        name: 'bugChart',
        component: bugChart,
        meta: {
          parent: 'projectList'
        }
      },
      {
        path: '/chart/cusromChart',
        name: 'cusromChart',
        component: cusromChart,
        meta: {
          parent: 'projectList'
        }
      },


      {
        path: '/chart/chartDetail',
        name: 'chartDetail',
        component: chartDetail,
        meta: {
          parent: 'projectList'
        }
      },
      //文档
      {
        path: '/file/fileInfo',
        name: 'fileInfo',
        component: fileInfo,
        meta:{
          parent:'projectList'
        }
      },
      {
        path: '/file/fileCreat',
        name: 'fileCreat',
        component: fileCreat,
        meta:{
          parent:'fileInfo'
        }
      },
      {
        path: '/file/fileList',
        name: 'fileList',
        component: fileList,
        meta:{
          parent:'fileInfo'
        }
      },
      //迭代
      {
        path: '/sprint/list',
        name: 'sprintList',
        component: sprintList,
        meta: {
          parent: 'projectList'
        }
      },
      {
        path: '/sprint/detail',
        name: 'sprintDetail',
        component: sprintDetail,
        meta: {
          parent: 'sprintList'
        }
      },
      {
        path: '/sprint/plan',
        name: 'sprintPlan',
        component: sprintPlan,
        meta: {
          parent: 'sprintList'
        }
      },
      {
        path: '/sprint/custom',
        name: 'SprintInfoCustom',
        component: SprintInfoCustom,
        meta: {
          parent: 'sprintList'
        }
      }
    ]
  },
  //单一缺陷浏览
  {
    path: '/bugInfo',
    name: 'bugInfo',
    component: bugList
  },
  //度量
  {
    path: '/metric',
    name: 'metric',
    component: metric
  },
  //我的
  {
    path: '/mine',
    name: 'mine',
    component: mine
  },
  {
    path: '/requirement/create',
    name: 'requirementCreate',
    component: requirementCreate,
    meta: {
      parent: 'mine'
    }
  },
  {
    path: '/review',
    name: 'review',
    component: review,
    meta: {
      parent: 'mine'
    }
  },
  {
    path: '/review/detail',
    name: 'reviewDetail',
    component: reviewDetail,
    meta: {
      parent: 'mine'
    }
  },
  {
    path: '/requirement/view/mine',
    name: 'mineRequirementView',
    component: mineRequirementView,
    meta: {
      parent: 'mine'
    }
  },

  //管理
  {
    path: '/manage',
    name: 'manage',
    component: manage,
    redirect: { name: 'manageCmdb' }
  },
  {
    path: '/manage/cmdb',
    name: 'manageCmdb',
    component: manageCmdb,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/user',
    name: 'memberManage',
    component: memberManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/role',
    name: 'roleManage',
    component: roleManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/auth',
    name: 'authSetManage',
    component: authSetManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/menu',
    name: 'menuManage',
    component: menuManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/function',
    name: 'functionManage',
    component: functionManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/image',
    name: 'imageManage',
    component: imageManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/sonarManage/sonarTaskManage',
    name: 'sonarTaskManage',
    component: sonarTaskManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/sonarManage/sonarSystemManage',
    name: 'sonarSystemManage',
    component: sonarSystemManage,
    meta: {
      parent: 'manage'
    }
  },
  {
    path: '/manage/app',
    name: 'appManage',
    component: appManage,
    meta: {
      parent: 'manage'
    }
  },
]


export default childRouter
