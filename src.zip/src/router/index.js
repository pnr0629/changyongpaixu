import Vue from 'vue'
import Router from 'vue-router'
import childRouter from './routers'
import '@/base/js/utils'

const layout = (resolve) => {  require(['components/layout'], resolve)};

Vue.use(Router)

const router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'layout',
      component: layout,
      redirect: {name: 'mine'},
      children: childRouter
    }
  ]
})

const allRouter = []
router.options.routes.forEach((r) => {
  let tempRouter = {}
  tempRouter.name = r.name
  tempRouter.path = r.path
  allRouter.push(tempRouter)
})

function getRouters(r, parent) {
  r.forEach((c) => {
    let tempRouter = {}
    tempRouter.name = c.name
    tempRouter.path = c.path
    if(c.meta) {
      tempRouter.meta = {}
      tempRouter.meta.parent = c.meta.parent
    }
    allRouter.push(tempRouter)
    if(c.children) {
      getRouters(c.children)
    }
  })
}

getRouters(childRouter)

$utils.saveStorage(GLOBAL_CONST.ALL_ROUTER, allRouter)

//全局拦截器
let beforeEachFunction = async function(to, from, next) {
  let cookieUser = $utils.getCookie(GLOBAL_CONST.USER_COOKIE_NAME)
  let storageUser = $utils.getStorage(GLOBAL_CONST.USER_INFO)

  if(cookieUser && storageUser && storageUser.userId && cookieUser != storageUser.userId) {
    $utils.clearStorage();
    $utils.saveStorage(GLOBAL_CONST.ALL_ROUTER, allRouter)
  }

  storageUser = $utils.getStorage(GLOBAL_CONST.USER_INFO)
  if(!storageUser || !storageUser.userId) {
    await $utils.getUserInfo();
  }

  let hasRouter = false;
  allRouter.forEach((r) => {
    if(r.path == to.path) {
      hasRouter = true;
      return;
    }
  })

  //路由不存在，返回404
  if(!hasRouter) {
    console.warn('path don\'t exists', to.fullPath, allRouter)
    next({
      path: '/err_page',
      query: {
        status: 404,
        from: from.fullPath,
        msg: '页面不存在'
      }
    })
    return;
  }

  if (to.matched.some(res => res.meta.public)) {
    next()
  } else {
    if (!$utils.getCookie('user')) {
      window.location.href = "/login/" + btoa(encodeURIComponent(window.location.href));
      return;
    }

    if (to.meta && to.meta.parent) {
      let r = $utils.getRouter(to.meta.parent);
      //业务和应用
      if ((to.meta.parent == 'bizList' || r && r.meta && r.meta.parent == 'bizList') && !to.query.bizId) {
        next({
          path: '/err_page',
          query: {
            status: 403,
            from: from.fullPath,
            msg: '业务内页面必须包含参数[bizId]'
          }
        });
        return;
      }
      if(to.meta.parent == 'appList' && !to.query.appId) {
        next({
          path: '/err_page',
          query: {
            status: 403,
            from: from.fullPath,
            msg: '业务应用内页面必须包含参数[appId]'
          }
        });
        return;
      }

      //项目
      if ((to.meta.parent == 'projectList' || r && r.meta && r.meta.parent == 'projectList') && !to.query.projectId) {
        next({
          path: '/err_page',
          query: {
            status: 403,
            from: from.fullPath,
            msg: '项目内页面必须包含参数[projectId]'
          }
        });
        return;
      }
    }
    next()
  }

}

router.beforeEach(beforeEachFunction)

export default router
