/**
 * 全局常量缓存
 * 1. 自定义字段默认值类型
 * time: 2019.9.3
 */

export default {
  state: {
    customFieldInitTypeMap: {
      SINGLE_TEXT: '',
      MULTI_TEXT: '',
      MEMBER_CHOICE: '',
      LITE_DATE_ATTR: '',
      DATE_ATTR: '',
      BOOLEAN_ATTR: null,
      INT_ATTR: null,
      FLOAT_ATTR: null,
      SINGLE_CHOICE: null,
      MULTI_CHOICE: []
    }
  }
}
