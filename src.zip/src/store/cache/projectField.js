/**
 * 项目级别缓存
 * 1. 初始化：在每次从项目列表进入到某个具体项目, 在工作台查看需求、缺陷、任务, 刷新页面时，需要调用 this.$store.commit('UPDATE_PROJECTID')
 * 2. ProjectId: 目前还没有更新 ProjectId，所以只适用于项目内，如果要在工作台使用，则需要更新 ProjectId
 * 3. 项目级别通用字段：优先级、迭代列表等
 * 4. 项目级别自定义字段
 * 5. 预计工时数据
 * 6. 项目列表数据
 * time: 2019.6.10
 */
import CONSTVARLIABLE from '../mutation-types'

export default {
  state: {
    ProjectId: 0, // 该 module 其他字段，都是依赖于 ProjectId 字段，如果每次 ProjectId 更新，则需要初始化其他字段
    // 项目字段 select 类型的可选值缓存
    PROJECTFIELDSELECTVALUES: {
      priorityList: { 1: [], 2: [], 3: [] }, 
      assignUserList: { 1: [], 2: [], 3: [] }, 
      statusIdList: { 1: [], 2: [], 3: [] }, 
      sprintIdList: { 1: [], 2: [], 3: [] }, 
      expectHourList: { 1: [], 2: [], 3: [] }, 
    },
    // 自定义字段 (只包含自定义字段列表，不包含 option 选项值)
    CUSTOMFIELDSELECTVALUES: {
      requirement: [],
      bug: [],
      task: []
    },
    workItemTypeMap: {
      1: 'requirement',
      2: 'task',
      3: 'bug'
    },
    // 预计工时
    expectHourList: [
      { key: 2, value: "0.25天", label: "2h" },
      { key: 4, value: "0.5天", label: "4h" },
      { key: 8, value: "1天", label: "8h" },
      { key: 12, value: "1.5天", label: "12h" },
      { key: 16, value: "2天", label: "16h" },
      { key: 20, value: "2.5天", label: "20h" },
      { key: 24, value: "3天", label: "24h" },
      { key: 28, value: "3.5天", label: "28h", showMore: true },
      { key: 32, value: "4天", label: "32h", showMore: true },
      { key: 36, value: "4.5天", label: "36h", showMore: true },
      { key: 40, value: "5天", label: "40h", showMore: true },
      { key: 44, value: "5.5天", label: "44h", showMore: true },
      { key: 48, value: "6天", label: "48h", showMore: true },
      { key: 52, value: "6.5天", label: "52h", showMore: true },
      { key: 56, value: "7天", label: "56h", showMore: true },
      { key: 60, value: "7.5天", label: "60h", showMore: true },
      { key: 64, value: "8天", label: "64h", showMore: true },
      { key: 68, value: "8.5天", label: "68h", showMore: true },
      { key: 72, value: "9天", label: "72h", showMore: true },
      { key: 76, value: "9.5天", label: "76h", showMore: true },
      { key: 80, value: "10天", label: "80h", showMore: true },
      // { key: 84, value: "10.5天", label: "84h", showMore: true, custom: true } // 自定义数据
    ],
    // 项目列表信息
    ProjectInfo: {
      // 已完成的项目
      completed: {
        ProjectList: [],
        pageInfo: {
          pageNumber: 1,
          pageSize: 20,
          totalRecords: 0,
          totalPages: 0
        }
      },
      // 进行中的项目
      unCompleted: {
        ProjectList: [],
        pageInfo: {
          pageNumber: 1,
          pageSize: 20,
          totalRecords: 0,
          totalPages: 0
        }
      },
      // 我管理的项目 - 需求复制时用到
      mine: {
        ProjectList: [],
        pageInfo: {
          pageNumber: 1,
          pageSize: 20,
          totalRecords: 0,
          totalPages: 0
        }
      }
    }
  },
  mutations: {
    // 更新项目id，初始化所有数据
    [CONSTVARLIABLE.UPDATE_PROJECTID](state, {ProjectId}) {
      if(ProjectId === state.ProjectId) {return ;}
      state.ProjectId = ProjectId;
      Object.keys(state.PROJECTFIELDSELECTVALUES).forEach(item => {
        state.PROJECTFIELDSELECTVALUES[item] = {
          1: [],
          2: [],
          3: []
        }
      })
      Object.keys(state.CUSTOMFIELDSELECTVALUES).forEach(item => {
        state.CUSTOMFIELDSELECTVALUES[item] = []
      })
    },
    // 更新 select 可选值 - 项目级别通用字段
    [CONSTVARLIABLE.UPDATE_PROJECTFIELD](state, {key, values, workItemType}) {
      state.PROJECTFIELDSELECTVALUES[key][workItemType] = values;
    },
    // 更新 自定义字段
    [CONSTVARLIABLE.UPDATE_CUSTOMFIELD](state, {key, values}) {
      state.CUSTOMFIELDSELECTVALUES[key] = values;
    },
    // 更新 项目列表信息
    [CONSTVARLIABLE.UPDATE_PROJECTLIST](state, {ProjectList, type, pageInfo}) {
      state.ProjectInfo[type].ProjectList = [...state.ProjectInfo[type].ProjectList, ...ProjectList];
      state.ProjectInfo[type].pageInfo = {
        ...state.ProjectInfo[type].pageInfo,
        ...pageInfo
      }
    }
  },
  actions: {
    /**
     * 1 初始化项目字段数据
     * @param {payload.projectId} 项目id 
     * @param {payload.workItemType} 工作项类别：需求、任务、缺陷 
     * 说明：查看工作项列表或详情时，通常需要筛选或者修改工作项的一些基本信息，该函数作为统一入口，获取基本信息
     * 功能：统一入口，获取处理人列表、状态列表、优先级列表、迭代列表、预计工时列表
     */
    async initDataPROJECTFIELD ({commit, state, dispatch}, {payload}) {
      const getPriorityListResult = dispatch({ type: 'getPriorityList', payload });
      const getAssignUserListResult = dispatch({ type: 'getAssignUserList', payload })
      const getStatusIdListResult = dispatch({ type: 'getStatusIdList', payload })
      const getSprintIdListResult = dispatch({ type: 'getSprintIdList', payload })
      const getExpectHourListResult = dispatch({ type: 'getExpectHourList', payload })
      await Promise.all([getPriorityListResult, getAssignUserListResult, getStatusIdListResult, getSprintIdListResult, getExpectHourListResult]);
      return true;
    },
    // 获取处理人列表
    async getAssignUserList ({commit, state}, {payload}) {
      const result = await $http.post($http.api.bug_info.assignUsersList, {
        projectId: +payload.projectId || state.projectId,
        workItemType: payload.workItemType,
        query: ''
      })
      let assignUserList = []
      if(result.status === 200) {
        assignUserList = result.data.map(item => {
          return {
            key: item.userId,
            value: item.userName + '(' + item.userId + ')',
            ...item
          }
        })
      }
      commit(CONSTVARLIABLE.UPDATE_PROJECTFIELD, {
        key: 'assignUserList',
        values: assignUserList,
        workItemType: payload.workItemType
      })
      return true;
    },
    // 获取状态列表
    async getStatusIdList ({commit, state}, {payload}) {
      const result = await $http.post($http.api.bug_info.all_status_list, {
        projectId: +payload.projectId || state.projectId,
        workItemType: payload.workItemType
      })
      let statusIdList = []
      if(result.status === 200) {
        statusIdList = result.data.map(item => {
          return {
            key: item.statusId,
            value: item.statusName,
            ...item
          }
        })
      }
      commit(CONSTVARLIABLE.UPDATE_PROJECTFIELD, {
        key: 'statusIdList',
        values: statusIdList,
        workItemType: payload.workItemType
      })
      return true;
    },
    // 获取优先级列表
    async getPriorityList ({commit, state}, {payload}) {
      const result = await $http.get($http.api.bug_info.priorityList, {
        projectId: +payload.projectId || state.projectId,
        workItemType: payload.workItemType
      })
      let priorityList = []
      if(result.status === 200) {
        priorityList = result.data.map(item => {
          return {
            key: item.priority,
            value: item.literal,
            ...item
          }
        })
      }
      commit(CONSTVARLIABLE.UPDATE_PROJECTFIELD, {
        key: 'priorityList',
        values: priorityList,
        workItemType: payload.workItemType
      })
      return true;
    },
    // 获取迭代列表
    async getSprintIdList ({commit, state}, {payload}) {
      const result = await $http.get($http.api.bug_info.spritList, {
        projectId: +payload.projectId || state.projectId,
        workItemType: payload.workItemType,
        status: 1
      })
      let sprintIdList = []
      if(result.status === 200) {
        sprintIdList = result.data.map(item => {
          return {
            key: item.id,
            value: item.name,
            ...item
          }
        })
      }
      // 增加未规划
      sprintIdList.unshift({
        key: 0,
        value: '未规划'
      })
      commit(CONSTVARLIABLE.UPDATE_PROJECTFIELD, {
        key: 'sprintIdList',
        values: sprintIdList,
        workItemType: payload.workItemType
      })
      return true;
    },
    // 获取预计工时列表
    async getExpectHourList ({commit, state}, {payload}) {
      let expectHourList = state.expectHourList
      commit(CONSTVARLIABLE.UPDATE_PROJECTFIELD, {
        key: 'expectHourList',
        values: expectHourList,
        workItemType: payload.workItemType
      })
      return true;
    },
    /**
     * 2 获取项目列表 - 分页、分类别获取数据代表
     * @param {payload.type} 项目列表类型：string, completed -> 已完成，unCompleted -> 进行中, mine -> 我管理的项目 
     * @param {payload.pageInfo} 分页信息: pageNumber, pageSize
     */
    async getProjectList ({commit, state}, {payload}) {
      // 如果该分页已经在缓存中，则不需要再次获取
      let list = [];
      const typekey = { unCompleted: false, completed: true };
      let urlObj = {}, postObj = {}
      switch(payload.type) {
        case 'mine': urlObj = $http.api.project.project_mine_list;break;
        default: urlObj = $http.api.project.projectListPageination;postObj = {
          completed: typekey[payload.type],
          pageInfo: payload.pageInfo
        };break;
      }
      // 如果在缓存中有了该页的数据，则不需要再次获取
      if(state.ProjectInfo[payload.type].ProjectList.length > (payload.pageInfo.pageNumber - 1) * payload.pageInfo.pageSize) {
        list = state.ProjectInfo[payload.type].ProjectList.slice((payload.pageInfo.pageNumber - 1) * payload.pageInfo.pageSize, payload.pageInfo.pageNumber * payload.pageInfo.pageSize)
      } else {
        // 如果不在缓存中，则通过 http 请求获取数据
        let result = {}
        switch(payload.type) {
          case 'mine': result = await $http.get(urlObj, postObj);break;
          default: result = await $http.post(urlObj, postObj);break;
        }
        if(result.status === 200) {
          list = result.data.results || result.data;
          commit(CONSTVARLIABLE.UPDATE_PROJECTLIST, {
            ProjectList: list,
            type: payload.type,
            pageInfo: result.data.pageInfo || {}
          })
        } else {
          return false;
        }
      }
      return list;
    },
    /**
     * 3 获取项目自定义字段列表
     * @param {payload.workItemType} 工作项类型 1-需求， 2-任务， 3-缺陷
     */
    async getCustomField({commit, state}, {payload}) {
      const result = await $http.get($http.api.CustomField.custom_field_list, { 
        projectId: +payload.projectId || state.projectId, 
        workItemType: payload.workItemType,
        onlyEnabled: false 
      })
      let customFieldList = []
      if(result.status === 200 && result.data.attrs) {
        customFieldList = result.data.attrs.map(item => {
          return {
            key: item.attrName,
            value: item.fieldName,
            ...item
          }
        })
      }
      commit(CONSTVARLIABLE.UPDATE_CUSTOMFIELD, {
        key: state.workItemTypeMap[payload.workItemType],
        values: customFieldList
      })
      return result;
    }
  }
}
