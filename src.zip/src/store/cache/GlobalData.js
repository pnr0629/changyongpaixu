/**
 * 通用全局数据缓存
 * 1. 节假日：holiday
 * time: 2019.8.26
 */
import CONSTVARLIABLE from '../mutation-types'

export default {
  state: {
    // 中国节假日
    holiday: {}
  },
  mutations: {
    // 更新中国节假日
    [CONSTVARLIABLE.UPDATE_HOLIDAY](state, {key, values}) {
      state.holiday[key] = values;
    }
  },
  actions: {
    /**
     * 1 获取中国国家节假日
     * @param {payload.year} 年份 string 
     */
    async getHolidayInfo ({commit, state}, {payload}) {
      const year = payload.year + '';
      // 如果已经有了当前年份的数据，则直接返回
      if(state.holiday[year] && Object.keys(state.holiday[year]).length > 0) {
        return state.holiday[year];
      }
      // 如果木有当前年份的数据，则获取一次
      const result = await $http.get($http.api.task.holiday, {
        year: year
      })
      if(result.status === 200) {
        commit(CONSTVARLIABLE.UPDATE_HOLIDAY, {
          key: year,
          values: result.data
        })
      }
      return result.status === 200;
    }
  }
}
