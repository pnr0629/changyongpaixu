/**
 * api文档
 */
import CONSTVARLIABLE from '../mutation-types'
import { get } from 'http';
import { isNullOrUndefined } from 'util';

export default {
  state: {
    // fileTypeKeys:'',
    detailShow:true, // 控制文档列表&详情显示隐藏
    apiId:-1,//接口id
    apiTypeId:0,//分类id
    sortTotal:0,//接口列表总数
    detailInitData:{},//接口详情数据
    defaultExpandedKeys:[],
    //请求方式列表
    interfaceUrlList:[
      { key: 'POST', value: "POST", label: "POST" },
      { key: 'GET', value: "GET", label: "GET" },
      { key: 'PUT', value: "PUT", label: "PUT" },
      { key: 'DELETE', value: "DELETE", label: "DELETE" },
      { key: 'HEAD', value: "HEAD", label: "HEAD" },
      { key: 'OPTIONS', value: "OPTIONS", label: "OPTIONS" },
      { key: 'PATCH', value: "PATCH", label: "PATCH" },
    ],
    //method数据格式
    sendBodyList:[
      { key: 'string', value: "string", label: "string" },
      { key: 'number', value: "number", label: "number" },
      { key: 'object', value: "object", label: "object" },
      { key: 'array', value: "array", label: "array" },
      { key: 'boolean', value: "boolean", label: "boolean" },
      { key: 'integer', value: "integer", label: "integer" },
    ],
    //mock下拉列表
    mockList:[
      { value: "@id", label: "@id" },
      { value: "@string", label: "@string" },
      { value: "@ip", label: "@ip" },
      { value: "@date", label: "@date" },
      { value: "@name", label: "@name" },
      { value: "@email", label: "@email" },
      { value: "@url", label: "@url" },
      { value: "@timestamp", label: "@timestamp" },
      { value: "@text", label: "@text" },
      { value: "@float", label: "@float" },
      { value: "@double", label: "@double" },
      { value: "@boolean", label: "@boolean" },
      { value: "@character", label: "@character" },
    ],
     //header请求类型列表
    headerRequireList:[
      { value: "Accept", label: "Accept" },
      { value: "Accept-Charset", label: "Accept-Charset" },
      { value: "Accept-Encoding", label: "Accept-Encoding" },
      { value: "Accept-Language", label: "Accept-Language" },
      { value: "Accept-Datetime", label: "Accept-Datetime" },
      { value: "Authorization", label: "Authorization" },
      { value: "Cache-Control", label: "Cache-Control" },
      { value: "Connection", label: "Connection" },
      { value: "Cookie", label: "Cookie" },
      { value: "Content-Disposition", label: "Content-Disposition" },
      { value: "Content-Length", label: "Content-Length" },
      { value: "Content-MD5", label: "Content-MD5" },
      { value: "Content-Type", label: "Content-Type" },
      { value: "Date", label: "Date" },
      { value: "Expect", label: "Expect" },
      { value: "Host", label: "Host" },
      { value: "If-Match", label: "If-Match" },
      { value: "If-Modified-Since", label: "If-Modified-Since" },
      { value: "If-Range", label: "If-Range" },
      { value: "If-Unmodified-Since", label: "If-Unmodified-Since" },
      { value: "Max-Forwards", label: "Max-Forwards" },
      { value: "Origin", label: "Origin" },
      { value: "Pragma", label: "Pragma" },
      { value: "Proxy-Authorization", label: "Proxy-Authorization" },
      { value: "Range", label: "Range" },
      { value: "Referer", label: "Referer" },
      { value: "TE", label: "TE" },
      { value: "User-Agent", label: "User-Agent" },
      { value: "Upgrade", label: "Upgrade" },
      { value: "Via", label: "Via" },
      { value: "Warning", label: "Warning" },
      { value: "X-Requested-With", label: "X-Requested-With" },
      { value: "DNT", label: "DNT" },
      { value: "X-Forwarded-For", label: "X-Forwarded-For" },
      { value: "X-Forwarded-Host", label: "X-Forwarded-Host" },
      { value: "X-Forwarded-Proto", label: "X-Forwarded-Proto" },
      { value: "Front-End-Https", label: "Front-End-Https" },
      { value: "X-Http-Method-Override", label: "X-Http-Method-Override" },
      { value: "X-ATT-DeviceId", label: "X-ATT-DeviceId" },
      { value: "X-Wap-Profile", label: "X-Wap-Profile" },
      { value: "Proxy-Connection", label: "Proxy-Connection" },
      { value: "X-UIDH", label: "X-UIDH" },
      { value: "X-Csrf-Token", label: "X-Csrf-Token" },
    ],
    //状态列表
    statusList:[
      { value: 1, label: "已完成" },
      { value: 0, label: "未完成" },
    ],
    // 分类下拉数据
    sortListData:[],
    jsonTreeData:[{name:"root",type:"object",label:"root",children:[]}],
    //保存未编辑数据
    watchDataObj1:{},
    //监听编辑
    watchData:{},
    //监听当前是否编辑页面
    editShow:false,
    //配置环境数据
    // getClassEnv:[],
    //检测编辑是否保存成功
    hideSetTab:true,
    //全局环境保存之后获取被保存参数
    // globalUrl:{}
    //导入刷新标记
    exId:true,

    docSearchWord: ''
  },
  mutations: {

    changeDocSearchWord(state,n){
      state.docSearchWord = n;
    },

    // fileTypeKeysFun(state,n){
    //   state.fileTypeKeys = n;
    // },
    defaultExpandedKeysFun(state,n){
      state.defaultExpandedKeys = n;
    },
    //当前是否编辑未保存页面
    editShowFun(state,n){
      state.editShow = n;
    },
    // 控制文档列表&详情显示隐藏
    filePageSwitch(state,n){
      state.detailShow = n;
    },
    //控制接口id
    fileApiId(state,n){
      state.apiId = n;
    },
    //控制分类id
    fileApiTypeId(state,n){
      state.apiTypeId = n;
    },
    //控制接口列表总数
    sortTotalFun(state,n){
      state.sortTotal = n;
    },
    //控制分类下拉数据
    sortListDataFun(state,n){
      state.sortListData = n;
    },
    //接口详情数据获取
    detailInitDataFun(state,n){
      state.detailInitData = n;
    },
    //保存未编辑数据
    watchDataFun(state,n){
      state.watchData = n;
    },
    //保存已编辑数据
    watchDataObjFun(state,n){
      state.watchDataObj1 = n;
    },
    //存储环境配置
    // getClassEnvFun(state,n){
    //   let flag = null;
    //   n.forEach((el,index) => {
    //     el.showName = el.envName+'：'+el.envDomain
    //     if(!el.envId){
    //       flag = index
    //     }
    //   });
    //   console.log(n)
    //   n.splice(flag,1)
    //   state.getClassEnv = n;
    // },
    //隐藏设置tab
    hideSetTabFun(state,n){
      state.hideSetTab = n;
    },
    //导入刷新
    exIdFun(state,n){
      state.exId = n;
    }

  },
  actions:{
    // detailInitDataFun(context){
    //   context.commit('detailInitDataFun',n)
    // }
  }
}
