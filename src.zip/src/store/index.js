// 根 store
import GlobalData from './cache/GlobalData'
import projectField from './cache/projectField'
import fileField from './cache/fileField'
import constMap from './cache/constMap'

const store = {
  modules: {
    gd: GlobalData, // 全局通用数据
    pf: projectField, // 缺陷自定义字段缓存模块
    fe: fileField, // 文档公共模块
    cm: constMap
  },
  state: {
    projectName: ''
  },
  mutations: {
    updateProjectName(state, name) {
      state.projectName = name;
    }
  },
  actions: {
    modifyProjectName ({ commit }, obj) {
      commit('updateProjectName', obj.projectName)
    }
  }
}

export default store