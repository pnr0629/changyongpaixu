// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Vuex from 'vuex'
import { sync } from 'vuex-router-sync'
import App from './App'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import 'base/style/icon/iconfont.css'
import 'base/style/icon/iconfont.js'//为了能使用svg图标
import XsStaffing from './components/tool/Staffing'
import router from './router'
import storeconfig from './store'
import plugins from 'base/js/plugins'
import jsoneditor from 'jsoneditor/dist/jsoneditor.js'
import 'jsoneditor/dist/jsoneditor.css'
import globalComponents from 'base/globalComponents'

import EleMultiCascader from "@/components/commonComponents/EleMultiCascader"
import "ele-multi-cascader/dist/cascader.css"

import 'base/js/http'
import 'base/js/utils'
import 'default-passive-events'

Vue.prototype.$jsoneditor = jsoneditor

// Vue.use(ElementUI)
Vue.use(ElementUI, { size: 'mini' }) // 可以保证全局输入框及按钮都是 mini size 的
Vue.use(plugins)
Vue.use(XsStaffing)
Vue.use(globalComponents)
Vue.use(Vuex)
Vue.use(EleMultiCascader)

Vue.config.productionTip = false

const store = new Vuex.Store(storeconfig);

const unsync = sync(store, router);
unsync()

//全局监听文档是否未编辑就跳转页面
router.beforeEach((to, from, next) => {
  // console.log(to, from)
  // console.log(store.state.fe.editShow)
  // if(from.path=="/file/fileList"){
  if(store.state.fe.editShow){
      // next(false)
      // Vue.prototype.$confirm(`离开页面会丢失当前编辑的内容，确定要离开吗？`, {
      //   confirmButtonText: "确定",
      //   cancelButtonText: "取消",
      //   type: "warning"
      // }).then( () => {
      //   // this.editShowFun(false);
      //   store.commit('editShowFun',false)
      //   next()
      // }).catch(()=> {next(false)});
    store.commit('editShowFun',false)
    next()
    // }
  }else{
    next()
  }
})
/* eslint-disable no-new */
window.vueObj = new Vue({
  el: '#app',
  router,
  store: store,
  template: '<App/>',
  components: {App}
})
