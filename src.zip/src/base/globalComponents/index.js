import BackTop from "@/components/tool/BackTop";
import EllipsisBlock from "@/components/commonComponents/EllipsisBlock";
import SelectFilter from '@/components/commonComponents/SelectFilter';
import StringView from '@/components/commonComponents/StringView';
import CustomDate from '@/components/commonComponents/CustomDate';
import CustomStatus from '@/components/commonComponents/CustomStatus';
import TypedFormItem from '@/components/commonComponents/TypedFormItem';

import { DNumber } from './Directive';

const install = function (Vue, options) {
  Vue.component('BackTop', BackTop);
  Vue.component('SelectFilter', SelectFilter);
  Vue.component('EllipsisBlock', EllipsisBlock);
  Vue.component('CustomDate', CustomDate);
  Vue.component('CustomStatus', CustomStatus);
  Vue.component('TypedFormItem', TypedFormItem);

  // 注入 v-number 全局指令
  Vue.directive('number', DNumber);
  /**
   * 文件下载 - get
   * @param exportUrl 资源 uri
   * @param requestobj 需要 base64 化的 json 数据
   * @param paramObj 需要传递的 json 数据
   * @author heyunjiang
   * @time 2019.8.5
   */
  Vue.prototype.fileDownLoadForGet = function(exportUrl, requestobj={}, paramObj = {}) {
    if(!exportUrl) {
      throw new Error('请传入需要的 uri');
      return false;
    }
    const request = encodeURIComponent(new StringView(JSON.stringify(requestobj)).toBase64())
    let url = exportUrl + '?request=' + request;
    for(let item in paramObj) {
      url += '&' + item + '=' + paramObj[item]
    }
    window.open(url, '_blank');
  },
  /**
   * 操作前确认
   * @param text 需要提醒的文字
   * @return Boolean
   * @author heyunjiang
   * @time 2019.8.5
   */
  Vue.prototype.confirmBeforeOperate = async function(text = '') {
    let result = null
    try {
      result = await this.$confirm(text, {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: 'warning'
      })
    } catch (_) {
      result = false;
    }
    return result;
  }
};

export default {
  install
}
