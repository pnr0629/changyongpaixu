/**
 * 自定义全局指令组件
 * time: 2019.9.4
 * author: heyunjiang
 */

// 输入数字，实现不了，不能修改 vnode
const DNumber = {
  update: function (el, binding) {
    // const ele_poor = el.getElementsByTagName('input');
    // if(ele_poor.length > 0) {
    //   console.log(ele_poor[0].value)
    //   let value = ele_poor[0].value;
    //   ele_poor[0].value = value.replace(/\D/g, '');
    // }
  }
}

export {
  DNumber
}