# global.scss 的组件库

time: 2019.8.20  
author: heyunjiang

## 背景

目前 global.scss 体积太大了，需要拆分一下模块
