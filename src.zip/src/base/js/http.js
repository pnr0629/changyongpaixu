import axios from 'axios'
// import {Message} from 'iview'
import {Message} from 'element-ui';
import api from './api'

//测试环境IP
global.baserUrl = ''

var instance = axios.create({
  baseURL: baserUrl,
  headers: {
    'Content-Type': 'application/json;charset=UTF-8;multipart/form-data',
  },
  withCredentials: true //跨域安全策略
});

instance.interceptors.request.use(
  // config => {
  //     var userid = localStorage.getItem("userid");
  //     if (userid != null) {
  //         config.headers.userid = userid;
  //     }
  //     return config
  // },
  // function(error) {
  //     return Promise.reject(error)
  // }
)


global.$http = {
  get: (urlTarget, params, config) => {

    let url = urlTarget.url;


    if (config && config.load) {
      $http.Load();
    }

    if (!params) {
      params = {};
    }

    if (urlTarget.function_type === 'BIZ' && !params['bizId']) {
      params.bizId = getUrlParams()['bizId'];
    } else if (urlTarget.function_type === 'APP' && !params['appId']) {
      params.appId = getUrlParams()['appId'];
    } else if (urlTarget.function_type === 'PROJECT' && !params['projectId']) {
      params.projectId = getUrlParams()['projectId'];
    }

    url = getFullUrl(url, params);

    return new Promise((resolve, reject) => {
      instance.get(url).then((res) => {
        let isRequestNormal = parseResponse(res, reject, resolve);
        if (!isRequestNormal) {
          return;
        }
        resolve(res.data);
        if (config && config.load) {
          $http.desLoad();
        }

      }).catch((e) => {
        reject(e);
        if (config && config.load) {
          $http.desLoad();
        }
      });
    })

  },

  post: (urlTarget, params = {}, config) => {

    if (config && config.load) {
      $http.Load();
    }

    //处理form请求
    if (config && config.type === 'form') {
      let formData = new FormData();
      if (params) {
        if (params.toString().indexOf('FormData') === -1) {
          for (let paramsKey in params) {
            formData.append(paramsKey, params[paramsKey]);
          }
        } else {
          formData = params;
        }
      }
      params = formData;
    }

    let url = urlTarget.url;

    if (urlTarget.function_type === 'BIZ') {
      let bizId = getUrlParams()['bizId'];
      if (bizId == null) {
        bizId = params.bizId;
      }
      url = url + '?bizId=' + bizId;
    } else if (urlTarget.function_type === 'APP') {
      let appId = getUrlParams()['appId'];
      if (appId == null) {
        appId = params.appId;
      }
      url = url + '?appId=' + appId;
    } else if (urlTarget.function_type === 'PROJECT') {
      let projectId = params.projectId;
      if (projectId == null) {
        projectId = getUrlParams()['projectId'];
      }
      // url = url + '?projectId=' + projectId;
      url += /\?/.test(url) ? ('&projectId=' + projectId) : ('?projectId=' + projectId);
    }


    return new Promise((resolve, reject) => {
      instance.post(url, params).then((res) => {
        let isRequestNormal = parseResponse(res, reject, resolve);
        if (!isRequestNormal) {
          return;
        }
        
        resolve(res.data)
        
        if (config && config.load) {
          $http.desLoad();
        }
      }).catch((e) => {
        reject(e);

        if (config && config.load) {
          $http.desLoad();
        }
      })
    })
  }
  ,
  get loginInfo() {
    let obj = {};
    try {
      obj = JSON.parse(localStorage.getItem('loginInfo'));
      if (!obj) obj = {};
    } catch (e) {
      obj = {};
    }
    return obj;
  }
  ,
  set loginInfo(obj) {
    if (!obj)
      localStorage.removeItem('loginInfo');
    else
      localStorage.setItem('loginInfo', JSON.stringify(obj));
  }
  ,
  Load: () => {
    Message.loading({content: 'Loading...', duration: 0});
  },

  desLoad:
    () => {
      Message.destroy();
    },
  api: api
}


function setparams(data) {
  let paramStr = '';
  for (var k in data) {
    var value = data[k] != undefined ? data[k] : '';
    paramStr += `&${k}=${encodeURIComponent(value)}`; //encodeURIComponent   把字符串作为 URI 组件进行编码。
  }

  return paramStr ? paramStr.substring(1) : '';
}

function getFullUrl(url, param) {
  if (!param) {
    return url;
  }
  let paramStr = '';
  for (let k in param) {
    let value = param[k] == undefined || param[k] == null ? '' : param[k];
    paramStr += `&${k}=${encodeURIComponent(value)}`; //encodeURIComponent   把字符串作为 URI 组件进行编码。
  }
  let queryStr = paramStr && paramStr.length !== 0 ? paramStr.substring(1) : '';
  return url + (queryStr === '' ? '' : '?') + queryStr;
}

function getUrlParams() {
  let params = {};
  let search = window.location.search;
  if (search && search.length > 1) {
    search = search.substr(1);
    search.split("&").forEach(val => {
      let kv = val.split("=");
      params[kv[0]] = kv[1];
    });
  }
  return params;
}

/**
 * 正常请求返回true，异常返回false
 * @param res
 * @returns {boolean}
 */
function parseResponse(res, reject, resolve) {
  if (res.data == null) {
    reject(new Error('未知异常'));
    return false;
  }else if([501, 620, 621].includes(res.data.status)){
    return true;
  } 
  else if (res.data.status === 302) {
    window.location.href = "/login/" +btoa(encodeURIComponent(window.location.href));
    return false;
  } else if (res.data.status !== 200) {
    try {
      if(res.headers['content-type'] === "application/octet-stream") {
        resolve(res)
      } else {
        resolve(res.data)
      }
    } catch(e) {
      resolve(res.data)
    }
    Message.error(res.data.msg);
    return false;
  }
  return true;
}
