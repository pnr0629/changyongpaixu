# api 文档集合

time: 2019.7.28  
author: heyunjiang

## 说明

这里作为 api.js 的扩展支持，用以减少 api.js 文件体积
