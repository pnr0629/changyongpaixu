/**
 * 项目内自定义过滤器接口
 * author: heyunjiang
 * time: 2019.8.30
 */

export default {
  custom_filter_list: {url: "/api/coop/custom_filter/list", function_type: "PROJECT"}, // 列表
  custom_filter_save: {url: "/api/coop/custom_filter/save", function_type: "PROJECT"}, // 保存
  custom_filter_delete: {url: "/api/coop/custom_filter/delete", function_type: "PROJECT"}, // 删除
  custom_filter_detail: {url: "/api/coop/custom_filter/info", function_type: "PROJECT"}, // 详情
}