/**
 * 项目内权限自定义接口
 * author: heyunjiang
 * time: 2019.7.28
 */

export default {
  role_list: { url: "/api/coop/auth_custom/role/list", function_type: "PROJECT" }, // 获取自定义角色列表
  role_add: { url: "/api/coop/auth_custom/role/add", function_type: "PROJECT" }, // 添加自定义角色
  role_delete: { url: "/api/coop/auth_custom/role/delete", function_type: "PROJECT" }, // 删除自定义角色
  role_update: { url: "/api/coop/auth_custom/role/update", function_type: "PROJECT" }, // 修改自定义角色
  member_list: { url: "/api/coop/auth_custom/role/member/list", function_type: "PROJECT" }, // 获取角色成员列表
  member_add: { url: "/api/coop/auth_custom/role/member/add", function_type: "PROJECT" }, // 添加角色成员
  member_delete: { url: "/api/coop/auth_custom/role/member/delete", function_type: "PROJECT" }, // 删除角色成员
  function_list: { url: "/api/coop/auth_custom/role/function/list", function_type: "PROJECT" }, // 获取角色下功能列表
  function_update: { url: "/api/coop/auth_custom/role/function/update", function_type: "PROJECT" } // 更新角色下功能列表
}