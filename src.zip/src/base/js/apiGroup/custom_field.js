/**
 * 项目内自定义字段接口
 * author: heyunjiang
 * time: 2019.8.27
 */

export default {
  custom_field_list: {url: "/api/coop/userDefined/attr/info", function_type: "PROJECT"}, // 自定义字段列表
  custom_field_types: {url: "/frontend/coop/assist/userDefined/attr/allTypes", function_type: "SYS"}, // 自定义字段类型
  custom_field_choices: {url: "/api/coop/userDefined/attr/choices/query", function_type: "PROJECT"}, // 自定义字段 select 可选值 - 列表
  custom_field_choices_add: {url: "/api/coop/userDefined/attr/choices/create", function_type: "PROJECT"}, // 自定义字段 select 可选值 - 增加
  custom_field_choices_delete: {url: "/api/coop/userDefined/attr/choice/delete", function_type: "PROJECT"}, // 自定义字段 select 可选值 - 增加
  custom_field_create: {url: "/api/coop/userDefined/attr/create", function_type: "PROJECT"}, // 自定义字段创建
  custom_field_update: {url: " /api/coop/userDefined/attr/update", function_type: "PROJECT"}, // 自定义字段更新 - 字段名称、启用/禁用
  custom_field_delete: {url: "/api/coop/userDefined/attr/delete", function_type: "PROJECT"}, // 自定义字段删除
}