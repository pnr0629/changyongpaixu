/**
 * 通用辅助函数
 * time: 2019.6.5
 * author: heyunjiang
 * desc: 比如一些 sleep, 防抖，节流函数，文件下载
 */


