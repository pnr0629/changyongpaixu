
const GLOBAL_CONST = {
  ALL_BIZS_LIST: 'allBizsList',
  ALL_APPS_LIST: 'allAppsList',
  USER_INFO: 'userInfo',
  USER_ID: 'userId',
  USER_PERMISSION_INFO: 'upi',
  USER_BIZ_LIST: 'userBizList',
  USER_COOKIE_NAME: 'user',
  ALL_ROUTER: 'allRouter',

  COMPILE_TASK_STATUS: {
    COMPILE_RESULT_NEW : 0,  //编译任务初始化
    COMPILE_RESULT_ING : 1,  //编译任务进行中
    COMPILE_RESULT_SUC : 2,  //编译任务成功
    COMPILE_RESULT_FAIL : 3, //编译任务失败
  },

  //app constant
  APP_TYPE: {
    JAVA_MAVEN: 1,
    JAVA_WEB_MAVEN: 2,
    TAR: 3,
    SHELL: 4,
    MULTI_REPO_SHELL: 5,
    JAVA_GRADLE: 6,
    JAVA_WEB_GRADLE: 7,
    ANDROID_APK: 8,
  },

  //app images constant
  COMPILE_IMAGE_TYPE: {
    PRIVATE: 0,
    MAVEN: 1,
    NPM: 2,
    CMAKE: 3,
    CENTOS: 4,
    TAR: 13,
    PRIVATE_TAR: 14,
    GRADLE: 15,
    ANDROID: 17,
  },

  PKG_STATUS: {
    '0': '新建',
    '1': '排队中',
    '2': '打包中',
    '3': '打包失败',
    '4': '打包成功'
  },

  //pipeline constant
  STAGE_STATUS: {
    NOT_RUNNING: 'NOT_RUNNING',
    RUNNING: 'RUNNING',
    WAIT: 'WAIT',
    SUCCESS: 'SUCCESS',
    FAILURE: 'FAILURE',
  },

  WORKFLOW_TASK_STATUS: {
    NEW: 'NEW',
    RUNNING: 'RUNNING',
    WAIT: 'WAIT',
    SUCCESS: 'SUCCESS',
    FAILURE: 'FAILURE',
    MANUAL_STOP: 'MANUAL_STOP',
  },

  //任务类型
  WORKFLOW_TASK_TYPE: {
    BUILD : 'BUILD',
    DEPLOY: 'DEPLOY',
    CODE_SCANNING: 'CODE_SCANNING',
    INTF_AUTO_TEST: 'INTF_AUTO_TEST',
    UI_AUTO_TEST: 'UI_AUTO_TEST',
    VOICE_ASSISTANT_AI_AUTO_TEST: 'VOICE_ASSISTANT_AI_AUTO_TEST',
    CUSTOMIZED_SCRIPT: 'CUSTOMIZED_SCRIPT',
    ARTIFICIAL_CHECKPOINT: 'ARTIFICIAL_CHECKPOINT',
    SUBMIT_TEST: 'SUBMIT_TEST',
    PASS_TEST: 'PASS_TEST',
    UNIT_TEST: 'UNIT_TEST',
    AUTO_TEST: 'AUTO_TEST',
    BRANCH_MANAGE: 'BRANCH_MANAGE',
    MVN_DEPLOY: 'MVN_DEPLOY'
  },

  //触发方式
  WORKFLOW_TRIGGER_TYPE: {
    MANUAL_TRIGGER: 'MANU_TRIGGER',
    TIMING_TRIGGER: 'TIMING_TRIGGER',
    AUTO_TRIGGER: 'AUTO_TRIGGER'
  },

  PIPELINE_TRIGGER_TYPE_MAP: {
    'MANU_TRIGGER' : "手工",
    'TIMING_TRIGGER' : "定时",
    'AUTO_TRIGGER' : "自动"
  },

  //流转方式
  TRANSFER_TYPE: {
    FINISHED_SUCCESS_TRANSFER: 'FINISHED_SUCCESS_TRANSFER',
    UNFINISHED_TRANSFER: 'UNFINISHED_TRANSFER',
    FINISHED_TRANSFER: 'FINISHED_TRANSFER'
  },

  EXECUTE_TYPE: {
    MANUAL: 'MANUAL',
    AUTO: 'AUTO'
  },

  CODE_SCANNING_TYPE: {
    SONARQUBE_OPPO_RULE: 'SONARQUBE_OPPO_RULE',
    SONARQUBE: 'SONARQUBE',
    FIND_BUGS: 'FIND_BUGS',
    SAFETY_SCAN:'SAFETY_SCAN'
  },

  //default versionNameTemplateDataList
  DEFAULT_VERSION_NAME_TEMPLATE_DATA_LIST: [
    'date', 'totalIncr', 'branchName', 'appId', 'dateTime', 'todayIncr'
  ],

  FEATURE_BRANCH_STATUS: {
    DEVELOPING: 'DEVELOPING',

    INTEGRATED_DEV_WAITING: 'INTEGRATED_DEV_WAITING',
    INTEGRATED_DEV_HANDLING: 'INTEGRATED_DEV_HANDLING',
    INTEGRATED_DEV_EXCEPTION: 'INTEGRATED_DEV_EXCEPTION',
    INTEGRATED_DEV_SUCCESS: 'INTEGRATED_DEV_SUCCESS',

    INTEGRATED_TEST_WAITING: 'INTEGRATED_TEST_WAITING',
    INTEGRATED_TEST_HANDLING: 'INTEGRATED_TEST_HANDLING',
    INTEGRATED_TEST_EXCEPTION: 'INTEGRATED_TEST_EXCEPTION',
    INTEGRATED_TEST_SUCCESS: 'INTEGRATED_TEST_SUCCESS',

    DELETED: 'DELETED',
  },

  RELEASE_BRANCH_STATUS: {
    NEW: "NEW",

    INTEGRATED_DEV_HANDLING: 'INTEGRATED_DEV_HANDLING',
    INTEGRATED_DEV_EXCEPTION:'INTEGRATED_DEV_EXCEPTION',
    INTEGRATED_DEV_SUCCESS: 'INTEGRATED_DEV_SUCCESS',

    INTEGRATED_TEST_HANDLING: 'INTEGRATED_TEST_HANDLING',
    INTEGRATED_TEST_EXCEPTION: 'INTEGRATED_TEST_EXCEPTION',
    INTEGRATED_TEST_SUCCESS: 'INTEGRATED_TEST_SUCCESS',

    MERGE_MASTER_WAITING: 'MERGE_MASTER_WAITING',
    MERGE_MASTER_HANDLING: 'MERGE_MASTER_HANDLING',
    MERGE_MASTER_EXCEPTION: 'MERGE_MASTER_EXCEPTION',
    MERGE_MASTER_SUCCESS: 'MERGE_MASTER_SUCCESS',

    DELETED: 'DELETED',
  },

  FEATURE_BRANCH_TYPE: {
    DEV: 'dev',
    INTEGRATED_DEV: 'integrated_dev',
    INTEGRATED_TEST: 'integrated_test',
  }
}
global.GLOBAL_CONST = GLOBAL_CONST

global.$utils = {
  getStorage(key) {
    return JSON.parse(window.localStorage.getItem(key) || '[]')
  },
  saveStorage(key, items) {
    window.localStorage.setItem(key, JSON.stringify(items))
  },
  clearStorage() {
    window.localStorage.clear();
  },
  getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
      return (arr[2]);
    else
      return null;
  },
  getRouter(name) {
    let allRouter = this.getStorage(GLOBAL_CONST.ALL_ROUTER);
    if (allRouter) {
      let router;
      allRouter.forEach((r) => {
        if (r.name == name) {
          router = r;
          return;
        }
      })
      return router;
    }
    return undefined
  },
  getSubMenuList(router) {
    return this.getSubMenuListByName(router.name)
  },
  getCurrentUserId() {
    return this.getStorage(GLOBAL_CONST.USER_ID);
  },
  getSubMenuListByName(name) {
    let allRouter = this.getStorage(GLOBAL_CONST.ALL_ROUTER);
    if (allRouter) {
      let subMenuList = [];
      for (let i = 0; i < allRouter.length; i++) {
        let r = allRouter[i];
        if (r.meta && r.meta.parent && r.meta.parent == name) {
          subMenuList.push(r)
        }
      }
      return subMenuList;
    }
    return undefined
  },
  getTopMenu(r) {
    if (r && r.meta && r.meta.parent) {
      let tempRouter = this.getRouter(r.meta.parent)
      if(!tempRouter) {
        return r;
      }
      return this.getTopMenu(tempRouter);
    }
    return r;
  },
  getUserInfo() {
    return $http.get($http.api.user.getInitData).then(res => {
      let initData = res.data;
      let userData = {}
      userData.userId = initData.userId;
      userData.userName = initData.userName;
      userData.email = initData.email;
      userData.isImpersonating = initData.isImpersonating;

      $utils.saveStorage(GLOBAL_CONST.USER_ID, userData.userId)
      $utils.saveStorage(GLOBAL_CONST.USER_INFO, userData)
      $utils.saveStorage(GLOBAL_CONST.USER_PERMISSION_INFO, initData)
      $utils.saveStorage(GLOBAL_CONST.USER_BIZ_LIST, initData.bizList)

    }).catch(e => {
    });
  }
}
