/**
 * 全局配置
 * designer: heyunjiang
 * time: 2019.3.21
 */

const taskType =  GLOBAL_CONST.WORKFLOW_TASK_TYPE;

export default {
  font: {
    fontSize: '14', // 默认全局字体为14像素，不加单位，方便修改
    laptopWidth: '1350' // 笔记本电脑屏幕宽度 px
  },
  showLogBox: [
    taskType.BUILD,
    taskType.CODE_SCANNING,
    taskType.CUSTOMIZED_SCRIPT,
    taskType.UNIT_TEST,
    taskType.BRANCH_MANAGE,
    taskType.MVN_DEPLOY] // 指定对应流水线任务名称可见日志详情，暂时这样子配置
}
