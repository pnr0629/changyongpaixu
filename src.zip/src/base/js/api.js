import AuthCustom from './apiGroup/auth_custom';
import CustomField from './apiGroup/custom_field';
import CustomFilter from './apiGroup/custom_filter';

export default {
  pipeline: { //流水线
    save: {url: "/api/pipeline/save/v2", function_type: "APP"},
    delete: {url: "/api/pipeline/delete", function_type: "APP"},
    list: {url: "/api/pipeline/list", function_type: "APP"},
    historyList: {url: "/api/pipeline/history/list", function_type: "APP"},
    copyList: {url: "/api/pipeline/copy/list", function_type: "APP"},
    configDetailsV2: {url: "/api/pipeline/config_details/v2", function_type: "APP"},
    executeWhole: {url: "/api/pipeline/execute/whole", function_type: "APP"},
    stopWorkflowTask: {url : "/api/pipeline/workflowtask/stop", function_type: "APP"},
    appBranchCompleteInfo: {url: "/api/application/branches/complete_info", function_type: "APP"},
    appMember: {url: "/api/application/get_app_member", function_type: "APP"},
    systemRole: {url: "/api/system/role", function_type: "SYS"},
    intfTestplanBinded: {url: "/api/pipeline/test/intf/testplan/binded", function_type: 'APP'}, //查询当前流水线对应的应用是否绑定接口自动化任务
    uiTestsuiteBinded: {url: '/api/pipeline/test/ui/testsuite/binded', function_type: 'APP'}, //查询当前流水线对应的应用是否绑定UI自动化任务
    voiceAssistantTestplanBinded: {url: '/api/pipeline/test/voice_assistant_ai/testplan/binded', function_type: 'APP'}, //查询当前流水线对应的应用是否绑定语音助手AI自动化任务
    workflowExecOverview: {url: '/api/pipeline/workflow/exec/overview', function_type: 'APP'},
    stagesExecOverview: {url: '/api/pipeline/stages/exec/details', function_type: 'APP'},
    pkgList: {url: '/api/pipeline/pkg/list', function_type: 'APP'},
    switchDefaultPipeline: {url: '/api/pipeline/default/switch', function_type: 'APP'},
    template: {url: '/api/pipeline/template', function_type: 'APP'},
    sonarMetricsList: {url: '/api/pipeline/sonar/metrics/list', function_type: 'APP'},
    buildTaskVars: {url: '/api/pipeline/buildTask/variables', function_type: 'APP'},
  },
  compile: { //容器化构建
    compileTypes: {url: "/api/application/compile/compile_types", function_type: "BIZ"},
    compileHistoryLst: {url: "/api/application/compile/history/list", function_type: "APP"},
    compileTypeImages: {url: "/api/application/compile/compile_type_images", function_type: "BIZ"},
    get_private_images: {url: "/api/application/compile/get_private_images", function_type: "SYS"},
    compiling_detail: {url: " /api/application/compile/task/detail", function_type: "APP"},
    compiling_list: {url: " /api/application/compile/task/list", function_type: "APP"},
    update_image_dependent: {url: "/api/application/compile/update_image_dependent", function_type: "APP"},
    get_image_dependent: {url: "/api/application/compile/get_image_dependent", function_type: "APP"},
    logs: {url: "/api/application/compile/image_upload/logs", function_type: "BIZ"},
    task_save: {url: " /api/application/compile/task/save", function_type: "APP"},
    task_start:{url: "/api/application/compile/task/start", function_type: "APP"},
    task_overView:{url: "/api/application/compile/task/overview", function_type: "APP"},
    task_logs:{url: "/api/application/compile/task/logs", function_type: "APP"},
    step_overView:{url:'/api/application/compile/task/executes',function_type:"APP"},
    task_variables:{url:'/api/application/compile/task/variables',function_type:"APP"},
    task_stop:{url:'/api/application/compile/task/stop',function_type:"APP"},
    task_download:{url:'/api/application/compile/task/download',function_type:"APP"},
    task_default:{url:'/api/application/compile/task/default',function_type:"APP"},
    task_delete:{url:'/api/application/compile/task/delete',function_type:"APP"},
    image_types:{url:'/api/application/compile/types',function_type:"BIZ"},
    task_branch:{url:'/api/application/compile/task/branch',function_type:"APP"},
  },
  issue: {
    deploynoteflowinfo: {url: "/api/deploy_note/flow_info", function_type: "BIZ"},
    bizlistbizmembers: {url: "/api/biz/list_biz_members", function_type: "BIZ"},
    deploynotesaveflowinfo: {url: "/api/deploy_note/save_flow_info", function_type: "BIZ"}
  },
  creat_yy: {
    apiapplicationlist: {url: "/api/application/list", function_type: "BIZ"},
    createApplication: {url: "/api/application/create_application", function_type: "BIZ"},
    apiapplicationgetappinfo: {url: "/api/application/get_app_info", function_type: "SYS"}
  },
  deploy: {
    apihostlist: {url: "/api/host/list", function_type: "APP"},
    apiinstanceadd: {url: "/api/instance/add", function_type: "APP"},
    apiappinstancedel: {url: "/api/instance/del", function_type: "APP"},
    apihostadd: {url: "/api/host/add", function_type: "APP"},
    apihostdel: {url: "/api/host/del", function_type: "APP"},
    apideployplancreate: {url: "/api/deploy_plan/create", function_type: "APP"},
    apideployplandel: {url: "/api/deploy_plan/del", function_type: "APP"},
    apiapplicationlistdisconf: {url: "/api/application/list_disconf", function_type: "APP"},
    apiapplicationzonelist: {url: "/api/application/zone_list", function_type: "SYS"},
    apideployplanlist: {url: "/api/deploy_plan/list", function_type: "APP"},
    apideployplansearch: {url: "/api/deploy_plan/search", function_type: "APP"},
    apideployplanupdate: {url: "/api/deploy_plan/update", function_type: "APP"},
    execute: {url: "/api/deploy_plan/execute", function_type: "APP"},
  },
  biz: {
    get_sim_bizs: {url: "/api/biz/get_simple_bizs", function_type: "SYS"},
    list_all_biz: {url: "/api/biz/list_all", function_type: "SYS"},
    list_biz_members: {url: "/api/biz/list_biz_members", function_type: "BIZ"},
    list_biz_ope_members: {url: "/api/biz/list_biz_ope_members", function_type: "BIZ"},
    del_biz_member: {url: "/api/biz/del_biz_member", function_type: "BIZ"},
    edit_biz_member: {url: "/api/biz/edit_biz_member", function_type: "BIZ"},
    add_biz_member: {url: "/api/biz/add_biz_member", function_type: "BIZ"},
    add_biz_ops_member: {url: "/api/biz/add_biz_ope_member", function_type: "BIZ"},
    del_biz_ope_member: {url: "/api/biz/del_biz_ope_member", function_type: "BIZ"},
    get_biz_batch_setting_info: {url: "/api/biz/get_biz_batch_setting_info", function_type: "BIZ"},
    batch_change_owner: {url: "/api/biz/batch_change_owner", function_type: "BIZ"},
    batch_add_app_devs: {url: "/api/biz/batch_add_app_devs", function_type: "BIZ"},
    batch_add_app_tests: {url: "/api/biz/batch_add_app_tests", function_type: "BIZ"},
    list_biz_devs: {url: "/api/biz/list_biz_devs", function_type: "BIZ"},
    list_biz_tests: {url: "/api/biz/list_biz_tests", function_type: "BIZ"},
    getBizList: {url: "/api/biz/list", function_type: "SYS"},
    getAppList: {url: "/api/application/all", function_type: "SYS"},
    getAllUser: {url: "/api/biz/get_all_user", function_type: "SYS"},
    addBiz: {url: "/api/biz/add", function_type: "BIZ"},
    deleteBizDeployCallback: {url: "/api/biz/delete_biz_deploy_callback", function_type: "BIZ"},
    updateBizDeployCallback: {url: "/api/biz/update_biz_deploy_callback", function_type: "BIZ"},
    getBizDeployCallbacks: {url: "/api/biz/get_biz_deploy_callbacks", function_type: "BIZ"},
    getDeployDescTemp: {url: "/api/biz/get_deploy_desc_temp", function_type: "BIZ"},
    updateDeployDescTemp: {url: "/api/biz/update_deploy_desc_temp", function_type: "BIZ"},
    getBizInfo: {url: "/api/biz/info", function_type: "BIZ"},
    listSysOpeMembers: {url: "/api/biz/list_sys_ope_member", function_type: "SYS"},
    change_biz_default_test: {url: "/api/biz/change_biz_default_test", function_type: "BIZ"},
    get_all_test_origin: {url: "/api/biz/get_all_test_origin", function_type: "BIZ"},
    set_app_test_origin: {url: "/api/biz/batch_set_app_test_origin", function_type: "BIZ"},
    get_app_for_bacth: {url: "/api/biz/get_app_for_bacth", function_type: "BIZ"},
    get_biz_member: {url: "/api/biz/get_biz_member", function_type: "BIZ"},
    get_biz_identity: {url: "/api/biz/biz_identity", function_type: "BIZ"},
    add_biz_devtest: {url: "/api/biz/add_biz_devtest", function_type: "BIZ"},
    del_biz_devtest: {url: "/api/biz/del_biz_devtest", function_type: "BIZ"},
    gitlab_user: {url: "/api/biz/gitlab/user", function_type: "BIZ"},
    getAllBizList: {url: "/api/biz/biz_list", function_type: "BIZ"},
    get_selected_app_owners: {url: "/api/biz/get_selected_app_owners", function_type: "BIZ"},

    add_biz_instance_tag: {url: "/api/biz/add_instance_tag", function_type: "BIZ"},
    edit_biz_instance_tag: {url: "/api/biz/edit_instance_tag", function_type: "BIZ"},
    get_biz_instance_tag_list: {url: "/api/biz/get_instance_tag_list", function_type: "BIZ"},
    get_biz_instance_tag_info: {url: "/api/biz/get_instance_tag_info", function_type: "BIZ"},
    del_biz_instance_tag: {url: "/api/biz/del_instance_tag", function_type: "BIZ"},
  },
  app: {
    get_my_collect_apps: {url: "/api/application/get_my_collection_apps", function_type: "SYS"},
    change_app_collection: {url: "/api/application/change_app_collection", function_type: "APP"},
    del_single_image_bak: {url: "/api/application/delete_image_bak", function_type: "SYS"},
    del_single_fast_deploy: {url: "/api/application/change_single_app_fast_deploy", function_type: "SYS"},
    del_single_manual_upload: {url: "/api/application/change_single_app_manual_upload", function_type: "SYS"},
    flush_version_count: {url: "/api/application/flush_version_count", function_type: "APP"},
    get_manual_upload_info: {url: "/api/application/get_manual_upload_info", function_type: "SYS"},
    get_fast_deploy_info: {url: "/api/application/get_fast_deploy_info", function_type: "SYS"},
    get_image_back: {url: "/api/application/get_image_back_info", function_type: "SYS"},
    change_image_back: {url: "/api/application/change_image_back", function_type: "SYS"},
    change_fast_deploy: {url: "/api/application/change_fast_deploy", function_type: "SYS"},
    change_manual_upload: {url: "/api/application/change_manual_upload", function_type: "SYS"},
    get_simple_apps: {url: "/api/application/get_simple_apps", function_type: "SYS"},
    get_bare_app_info: {url: "/api/application/get_bare_app_info", function_type: "APP"},
    list: {url: "/api/application/list", function_type: "BIZ"},
    get_app_basic_info: {url: "/api/application/get_app_basic_info", function_type: "APP"},
    save_app_basic_info: {url: "/api/application/save_app_basic_info", function_type: "APP"},
    get_app_deploy_info: {url: "/api/application/get_app_deploy_info", function_type: "APP"},
    save_app_deploy_config: {url: "/api/application/save_app_deploy_config", function_type: "APP"},
    get_app_compile_info: {url: "/api/application/get_app_compile_info", function_type: "APP"},
    save_app_compile_config: {url: "/api/application/save_app_compile_config", function_type: "APP"},
    get_application_member_config_info: {
      url: "/api/application/get_application_member_config_info",
      function_type: "APP"
    },
    getTagList: {url: "/api/application_tag/list", function_type: "BIZ"},
    delTag: {url: "/api/application_tag/delete", function_type: "BIZ"},
    addTag: {url: "/api/application_tag/add", function_type: "BIZ"},
    updateTag: {url: "/api/application_tag/update", function_type: "BIZ"},
    bindTag: {url: "/api/application_tag/bind", function_type: "BIZ"},
    delApplication: {url: "/api/application/del_application", function_type: "BIZ"},
    saveApplicationDevMembers: {url: "/api/application/save_application_dev_members", function_type: "APP"},
    saveApplicationTestMembers: {url: "/api/application/save_application_test_members", function_type: "APP"},
    getZoneList: {url: "/api/application/zone_list", function_type: "SYS"},
    listDisconf: {url: "/api/application/list_disconf", function_type: "APP"},
    checkAppCode: {url: "/api/application/check_app_code", function_type: "SYS"},
    appMaxUploadConfig: {url: "/api/app_version/upload/config", function_type: "APP"},
    simpleInfo: {url: "/api/application/simple_info", function_type: "APP"},
    getBaseImageDefaultValue: {url: "/api/application/get_base_image_default_value", function_type: "SYS"},
    changeAppOwner: {url: "/api/application/change_app_owner", function_type: "APP"},
    app_transfer: {url: "/api/application/app_transfer", function_type: "BIZ"},
    getAppVersionName: {url: "/api/application/get_app_version_name", function_type: "APP"},
    get_use_config_center_status: {url: "/api/application/get_use_config_center_status", function_type: "APP"},
    change_use_config_center: {url: "/api/application/change_use_config_center", function_type: "APP"},
    switchDevelopMode: {url: "/api/application/developMode", function_type: "APP"},
    switchbleIntegratedEnv: {url: "/api/application/integratedEnv", function_type: "APP"},
    sourceRepoValidate: {url: "/api/application/source_repo/validate", function_type: "SYS"},
  },
  other: {
    get_doc_info: {url: "/api/get_doc_info", function_type: "SYS"},
  },
  config_center: {
    config_center_list: {url: "/api/config_center/config_center_list", function_type: "APP"},
    save_association: {url: "/api/config_center/save_association", function_type: "APP"},
    app_config_info: {url: "/api/config_center/app_config_info", function_type: "APP"},
    app_config: {url: "/api/config_center/app_config", function_type: "APP"},
    config_center_application: {url: "/api/config_center/config_center_application", function_type: "APP"},
    get_sys_config_info: {url: "/api/config_center/get_sys_config_info", function_type: "APP"}
  },
  appdate: {
    auto_test_result: {url: "/api/pipeline/test/auto_test/result", function_type: "APP"},
    getAppVersionName: {url: "/api/app_version/name", function_type: "APP"},
    appVersionCreate_v2: {url: "/api/app_version/create/v2", function_type: "APP"}, //应用版本生成（普通应用，多仓库共用）
    apipipelineexectaskdetails: {url: "/api/pipeline/exec/task/details", function_type: "APP"}, //查看版本生成时流水线执行详情某个任务
    apipipelinelogs: {url: "/api/pipeline/logs", function_type: "APP"}, //查询流水线执行日志
    appBranchList: {url: "/api/application/branch/list", function_type: "BIZ"}, //获取分支列表（非多仓库）
    apipipelineexecute: {url: "/api/pipeline/execute", function_type: "APP"}, //执行流水线任务
    apiappversionlist: {url: "/api/app_version/list", function_type: "APP"}, //获取版本列表
    apiinstancedeploy_history: {url: "/api/instance/deploy_history", function_type: "APP"}, //获取部署历史信息
    apipipelinetestintftasksresult: {url: "/api/pipeline/test/intf/tasks/result", function_type: "APP"}, //查询接口自动化任务执行结果
    apipipelinetestintftaskrerun: {url: "/api/pipeline/test/intf/task/rerun", function_type: "APP"}, //重跑接口自动化测试任务某个小任务
    apipipelinetestuijobsresult: {url: "/api/pipeline/test/ui/jobs/result", function_type: "APP"}, //查询UI自动化任务执行结果
    apipipelinetestuijobrerun: {url: "/api/pipeline/test/ui/job/rerun", function_type: "APP"}, //重跑UI自动化测试任务某个小任务
    apipipelinetestuijobfailcasesrerun: {url: "/api/pipeline/test/ui/job/failcases/rerun", function_type: "APP"}, //重跑UI自动化测试任务某个小任务的失败用例
    apipipelinetestvoiceassistantaijobsresult: {
      url: "/api/pipeline/test/voice_assistant_ai/jobs/result",
      function_type: "APP"
    }, //查询语音助手AI自动化任务执行结果
    apipipelinetestvoiceassistantaijobrerun: {
      url: "/api/pipeline/test/voice_assistant_ai/job/rerun",
      function_type: "APP"
    }, //重跑语音助手AI自动化测试任务某个小任务
    apipipelinetestfindbugstaskresult: {url: "/api/pipeline/test/findbugs/task/result", function_type: "APP"}, //查询代码扫描(findbugs)任务执行结果
    apipipelinetestsafetyscantaskresult: {url: "/api/pipeline/test/safety_scan/task/result", function_type: "APP"}, //查询安全扫描（securityscan）任务执行结果
    apipipelinesonartaskresult: {url: "/api/pipeline/sonar/task/result", function_type: "APP"}, //查询代码扫描(sonarqube)任务执行结果
    api_application_relate_app_list: {url: "/api/application/relate_app/list", function_type: "APP"}, //关联应用列表
    api_application_relate_app_add: {url: "/api/application/relate_app/add", function_type: "APP"}, //关联应用添加
    api_application_relate_apps_add: {url: "/api/application/relate_app/add_apps", function_type: "APP"}, //关联应用添加
    api_application_relate_app_list_can_relate_app: {
      url: "/api/application/relate_app/list_can_relate_app",
      function_type: "BIZ"
    }, //获取当前应用可关联的应用列表
    api_application_relate_app_remove: {url: "/api/application/relate_app/remove", function_type: "APP"}, //关联应用删除
    api_app_version_upload_detail_list: {url: "/api/app_version/upload_detail/list", function_type: "APP"}, //获取应用版本包上传详情
    api_app_version_upload_detail_re_upload: {url: "/api/app_version/upload_detail/re_upload", function_type: "APP"}, //应用版本包上传失败重传
    api_application_relate_app_update_order: {url: "/api/application/relate_app/update_order", function_type: "APP"}, //关联应用更新关联顺序
    api_app_version_manual_upload: {url: "/api/app_version/manual_upload", function_type: "APP"}, //应用版本手工上传（包含Docker镜像手工上传）
    appBranchLatestCommit: {url: "/api/application/branch/commit/latest", function_type: "APP"}, //获取分支最新的commit信息
    api_app_version_name_conflict_check: {url: "/api/app_version/name/conflict/check", function_type: "APP"}, //查询生成版本设置的版本名称是否重复
    api_app_version_download: {url: "/api/app_version/download", function_type: "APP"}, //获取应用版本包下载地址
    api_application_basic_info: {url: "/api/application/get_app_basic_info", function_type: "APP"}, //应用基本信息配置查询
    api_app_relate_app_available_biz_list: {url: "/api/application/relate_app/available_bizs", function_type: "APP"}, //获取当前应用可关联的业务列表
    api_application_relate_app_available_app_list: {
      url: "/api/application/relate_app/available_apps",
      function_type: "BIZ"
    }, //获取当前应用可关联的应用列表
    api_app_version_passtest: {url: '/api/app_version/passtest', function_type: "APP"}, //版本提测/测试通过接口
    get_today_version_count: {url: '/api/app_version/get_today_version_count', function_type: "APP"},
    getPaaSLogLink: {url: "/api/instance/jump_paas_instance_log", function_type: "APP"},//获取paas部署日志弹窗url
    deleteVersion: {url: "/api/app_version/delete_version", function_type: "APP"},
    appVersionBehindCount: {url: "/api/app_version/check/behind_count", function_type: "APP"},
  },

  feature_branch: {
    create: {url: "/api/feature_branch/create", function_type: "APP"},
    update: {url: "/api/feature_branch/update", function_type: "APP"},
    list: {url: "/api/feature_branch/list", function_type: "APP"},
    canImportBranches: {url: "/api/feature_branch/import/list", function_type: "APP"},
    details: {url: "/api/feature_branch/details", function_type: "APP"},
    status: {url: "/api/feature_branch/status", function_type: "APP"},
    delete: {url: "/api/feature_branch/delete", function_type: "APP"},
    versionList: {url: "/api/feature_branch/version/list", function_type: "APP"},
    commitDiff:{url: "/api/feature_branch/commit/diff", function_type: "APP"},

    waitIntegratedList: {url: "/api/feature_branch/wait_integrated/list", function_type: "APP"},
    currentIntegratedList: {url: "/api/feature_branch/current_integrated/list", function_type: "APP"},
    currentIntegratedRelease: {url: "/api/release_branch/current_integrated", function_type: "APP"},
    triggerIntegrated: {url: "/api/feature_branch/trigger_integrated", function_type: "APP"},
    submitTest:{url: "/api/release_branch/submit_test", function_type: "APP"},
    submitTestIntegrated:{url: "/api/release_branch/submit_test_integrated", function_type: "APP"},
    passTest:{url: "/api/release_branch/pass_test", function_type: "APP"},
    integratedPipelineQuery:{url: "/api/feature_branch/integrated_pipeline/query", function_type: "APP"},
    pipelineOverview:{url: "/api/feature_branch/pipeline/overview", function_type: "APP"},

    switchVerionDescType: {url: "/api/release_branch/versionDescType", function_type: "APP"},

    wait2DeployList: {url: "/api/release_branch/wait_to_deploy/list", function_type: "APP"},
    wait2DeployListByDeployNote: {url: "/api/release_branch/wait_to_deploy/list_by_deploy_note", function_type: "BIZ"},
    wait2DeployDelete: {url: "/api/release_branch/wait_to_deploy/delete", function_type: "APP"},
    wait2DeployMergeMaster: {url: "/api/release_branch/wait_to_deploy/merge_master", function_type: "APP"},
    mergeMasterWaitToDeleteFeatureBranch: {url: "/api/release_branch/merge_master/wait_to_delete_feature_branch", function_type: "APP"},
    getFeatureBranchListByReleaseBranch: {url: "/api/release_branch/wait_to_deploy/feature_list", function_type: "APP"},
    featureMasterCompare: {url: "/api/release_branch/wait_to_deploy/feature_master_compare", function_type: "APP"},
  },

  cmdb: {
    list: {url: "/api/cmdb/app/query", function_type: "SYS"},
    save_bind: {url: "/api/cmdb/save_bind", function_type: "SYS"},
    search: {url: "/api/cmdb/search", function_type: "SYS"},
    appcmdb: {url: "/api/cmdb/appcmdb", function_type: "SYS"},
    cmdbIps: {url: "/api/cmdb/cmdbIps", function_type: "BIZ"}
  },
  team: {getTeamList: {url: "/api/team/list", function_type: "SYS"}},
  system_log: {
    getAppLog: {url: "/api/system_log/app", function_type: "APP"},
    getAppDeployLog: {url: "/api/system_log/deploy", function_type: "APP"}
  },

  deploy_note: {
    get_ori_period_info: {url: "/api/deploy_note/get_period_info", function_type: "SYS"},
    del_deploy_period: {url: "/api/deploy_note/del_period", function_type: "SYS"},
    insert_or_update_period_info: {url: "/api/deploy_note/insert_or_update_period_info", function_type: "SYS"},
    getUnTreatedDeployNoteList: {url: "/api/deploy_note/untreated_deploy_note", function_type: "SYS"},
    getDeployNoteList: {url: "/api/deploy_note/list", function_type: "BIZ"},
    createDeployNote: {url: "/api/deploy_note/create", function_type: "BIZ"},
    getDeployNoteDetail: {url: "/api/deploy_note/detail_info", function_type: "BIZ"},
    uploadDeployDir: {url: "/api/deploy_note/upload_deploy", function_type: "BIZ"},
    updateDeployNote: {url: "/api/deploy_note/update", function_type: "BIZ"},
    getButtonAndCount: {url: "/api/deploy_note/get_button_and_count", function_type: "BIZ"},
    downloadDeployDir: {url: "/api/deploy_note/deploy_download", function_type: "BIZ"},
    getDeployDirList: {url: "/api/deploy_note/deploy_dir_list", function_type: "BIZ"},
    getDeployDetailList: {url: "/api/deploy_note/deploy_details", function_type: "BIZ"},
    deleteDeployDir: {url: "/api/deploy_note/delete_deploy", function_type: "BIZ"},
    deleteDeployNote: {url: "/api/deploy_note/del", function_type: "BIZ"},
    auditFlowUpdate: {url: "/api/deploy_note/audit_flow_update", function_type: "BIZ"},
    completeDeploy: {url: "/api/deploy_note/complete_deploy", function_type: "BIZ"},
    getBizPeriodList: {url: "/api/deploy_note/biz_period_list", function_type: "BIZ"},
    getPaaSLink: {url: "/api/instance/jump_paas_instance", function_type: "BIZ"},
    generateSign: {url: "/api/common/generate_sign", function_type: "SYS"},
    getPaasServerUrl: {url: "/api/common/get_paas_server_url", function_type: "SYS"},
    all_period_list: {url: "/api/deploy_note/all_period_list", function_type: "SYS"},
    get_year_list: {url: "/api/deploy_note/get_year_list", function_type: "BIZ"},
    get_week_list: {url: "/api/deploy_note/get_week_list", function_type: "BIZ"},
    get_deploy_statistics: {url: "/api/deploy_note/get_deploy_statistics", function_type: "BIZ"},
    getDeployNoteListByVersion: {url: "/api/deploy_note/list_by_version", function_type: "APP"},
  },
  auth: {
    addAuthSet: {url: "/api/system/add_set", function_type: "SYS"},
    updateAuthSet: {url: "/api/system/update_set", function_type: "SYS"},
    getAuthSet: {url: "/api/system/auth_set", function_type: "SYS"},
    authSetCheck: {url: "/api/system/set_check", function_type: "SYS"},
    deleteAuthSet: {url: "/api/system/delete_set", function_type: "SYS"},
    checkSetFunction: {url: "/api/system/check_set_function", function_type: "SYS"},
    getSetEntity: {url: "/api/system/set_entity", function_type: "SYS"},
    insertEntity: {url: "/api/system/insert_entity", function_type: "SYS"},
    updateEntity: {url: "/api/system/update_entity", function_type: "SYS"},
    deleteEntity: {url: "/api/system/delete_entity", function_type: "SYS"}
  },
  user: {
    impersionate_start: {url: "/api/impersonate/start", function_type: "SYS"},
    impersionate_stop: {url: "/api/impersonate/stop", function_type: "SYS"},
    getLoginUserInfo: {url: "/api/user/get_login_user_info", function_type: "SYS"},
    logout: {url: "/logout", function_type: "SYS"},
    getInitData: {url: "/api/user/get_init_data", function_type: "SYS"},
    getUserList: {url: "/api/user/user_list", function_type: "SYS"},
    updateUser: {url: "/api/user/user_update", function_type: "SYS"},
    addUser: {url: "/api/user/user_add", function_type: "SYS"},
    addRole: {url: "/api/role/role_add", function_type: "SYS"},
    updateRole: {url: "/api/role/role_update", function_type: "SYS"},
    checkRole: {url: "/api/role/role_check", function_type: "SYS"},
    deleteRole: {url: "/api/role/role_delete", function_type: "SYS"},
    roleMenuFuns: {url: "/api/menu/role_menu_funs", function_type: "SYS"},
    menuFunTree: {url: "/api/menu/menu_fun_tree", function_type: "SYS"},
    updateMenuFuns: {url: "/api/menu/update_menu_funs", function_type: "SYS"},
    checkUser: {url: "/api/user/user_exist", function_type: "SYS"}
  },
  function_manage: {
    get_func_list: {url: "/api/function/function_list", function_type: "SYS"},
    get_func_info: {url: "/api/function/function_detail", function_type: "SYS"},
    update_func: {url: "/api/function/function_update", function_type: "SYS"},
    add_func: {url: "/api/function/function_add", function_type: "SYS"},
    del_func: {url: "/api/function/function_delete", function_type: "SYS"},
  },
  menu_manage: {
    get_menu_list: {url: "/api/menu/menu_list", function_type: "SYS"},
    save_munu: {url: "/api/menu/menu_add", function_type: "SYS"},
    update_menu: {url: "/api/menu/menu_update", function_type: "SYS"},
    del_menu: {url: "/api/menu/menu_delete", function_type: "SYS"},
    menu_func_list: {url: "/api/menu/menu_fun_list", function_type: "SYS"},
    save_menu_2_func: {url: "/api/menu/menu_fun_update", function_type: "SYS"},
  },
  sonar_manage: {
    get_sonar_task_manage_list: {url: "/api/sonar/manage/task/list", function_type: "SYS"},
    get_sonar_task_manage_list_app: {url: "/api/sonar/manage/task/list_app", function_type: "SYS"},
    get_sonarqube_system_info: {url: "/api/sonar/manage/sonarqube/system_info", function_type: "SYS"},
    get_sonarqube_scanner_machine_info: {url: "/api/sonar/manage/scanner/machine_info/list", function_type: "SYS"},
    get_sonar_rate_limit_info: {url: "/api/sonar/manage/rate_limit/info", function_type: "SYS"},
    open_sonar_rate_limit: {url: "/api/sonar/manage/rate_limit/open", function_type: "SYS"},
    close_sonar_rate_limit: {url: "/api/sonar/manage/rate_limit/close", function_type: "SYS"},
  },
  image_manage: {
    get_image_types: {url: "/api/application/compile/compile_types", function_type: "SYS"},
    get_pri_types: {url: "/api/application/compile/pri_compile_types", function_type: "SYS"},
    get_images: {url: "/api/biz/image/get_images", function_type: "SYS"},
    get_image: {url: "/api/application/compile/get_image", function_type: "SYS"},
    save_image_type: {url: "/api/application/compile/save_compile_type", function_type: "SYS"},
    update_image_type: {url: "/api/application/compile/update_compile_type", function_type: "SYS"},
    del_image_type: {url: "/api/application/compile/del_compile_type", function_type: "SYS"},
    save_image: {url: "/api/application/compile/save_image", function_type: "SYS"},
    image_stable: {url: "/api/application/compile/image_stable", function_type: "SYS"},
    update_image: {url: "/api/application/compile/update_image", function_type: "SYS"},
    del_image: {url: "/api/application/compile/del_image", function_type: "SYS"},
    get_biz_by_image: {url: "/api/biz/image_biz_list", function_type: "SYS"},
    save_biz_image: {url: "/api/biz/save_image_biz", function_type: "SYS"},
    check_image_stable: {url: "/api/biz/image/check_image_stable", function_type: "SYS"},
    set_image_stable: {url: "/api/biz/image/image_stable", function_type: "SYS"},
    image_container_up: {url: "/api/biz/image/image_container_up", function_type: "SYS"},
    check_image_repeat: {url: "/api/biz/image/check_image_repeat", function_type: "SYS"},
    upload_image: {url: "/api/biz/image/upload_image", function_type: "SYS"},
    download_image: {url: "/api/biz/image/download_image", function_type: "SYS"},
    image_upload_histry: {url: "/api/biz/image/image_upload_histry", function_type: "SYS"},
    biz_images: {url: "/api/biz/image/biz_images", function_type: "BIZ"},
  },
  system:{
    get_server_time: {url: "/api/system/server_time", function_type: "SYS"},
  },
  // ************************************项目协同***************************************//
  sprint: {
    add_sprint: {url: "/api/coop/sprint/add", function_type: "PROJECT"},
    update_sprint: {url: "/api/coop/sprint/update", function_type: "PROJECT"},
    defect_sprint:{url: '/api/coop/sprint/delete', function_type: "PROJECT"},
    list_sprint: {url: "/api/coop/sprint/list", function_type: "PROJECT"},
    page_list: {url: "/api/coop/sprint/page_list", function_type: "PROJECT"},//迭代列表_分页
    base_info: {url: "/api/coop/sprint/base_info", function_type: "PROJECT"},
    info: {url: "/api/coop/sprint/info", function_type: "PROJECT"},
    stop_sprint: {url: "/api/coop/sprint/stop", function_type: "PROJECT"},
    search_task: {url: "/api/coop/sprint/search_require", function_type: "PROJECT"},
    task_info: {url: "/api/coop/sprint/task_info", function_type: "PROJECT"},
    user_task: {url: "/api/coop/sprint/user_task", function_type: "PROJECT"},
    status_distribute: {url: "/api/coop/sprint/graph/status_distribute", function_type: "PROJECT"},
    burn_down: {url: "/api/coop/sprint/graph/burn_down", function_type: "PROJECT"},
    add_task: {url: "/api/coop/sprint/add_task", function_type: "PROJECT"},
    delete_task: {url: "/api/coop/sprint/delete_task", function_type: "PROJECT"},
    //迭代进度信息
    list_sprint_name: {url: '/api/coop/sprint/list_name', function_type: "PROJECT"},
    defect_list:{url: '/api/coop/sprint/defect_info', function_type: "PROJECT"},
    schedule_info_list:{url: '/api/coop/sprint/stage/schedule_info/list', function_type: "PROJECT"},
    current_stage_update:{url: '/api/coop/sprint/stage/current/update', function_type: "PROJECT"},
    stage_time_info_list:{url: '/api/coop/sprint/stage/time_info/list', function_type: "PROJECT"},
    stage_time_info_update:{url: '/api/coop/sprint/stage/time/update', function_type: "PROJECT"},
    stage_list:{url: '/api/coop/sprint/stage/list', function_type: "PROJECT"},
    stage_add:{url: '/api/coop/sprint/stage/add_to_template', function_type: "PROJECT"},
    stage_delete:{url: '/api/coop/sprint/stage/delete', function_type: "PROJECT"},
    can_delete:{url: '/api/coop/sprint/stage/can_delete', function_type: "PROJECT"},//查询是否可以删除
    stage_update:{url: '/api/coop/sprint/stage/update', function_type: "PROJECT"},
    stage_sort:{url: '/api/coop/sprint/stage/sort', function_type: "PROJECT"},
    //迭代进度信息
    sprint_lock:{url: '/api/coop/sprint/lock', function_type: "PROJECT"},
    sprint_unlock:{url: '/api/coop/sprint/unlock', function_type: "PROJECT"},
    sprint_force_lock:{url: '/api/coop/sprint/force_lock', function_type: "PROJECT"},
    excel_export:{url: '/api/coop/sprint/excelExport', function_type: "PROJECT"},
    // 迭代阶段模板 - add by heyunjiang
    template_list: {url: '/api/coop/sprint/stage/template/list', function_type: "PROJECT"}, // 模板列表
    template_default_setting: {url: '/api/coop/sprint/stage/template/default/setting', function_type: "PROJECT"}, // 设置为默认模板
    template_delete: {url: '/api/coop/sprint/stage/template/delete', function_type: "PROJECT"}, // 删除模板
    template_info: {url: '/api/coop/sprint/stage/template/info', function_type: "PROJECT"}, // 查询模板信息
    template_update: {url: '/api/coop/sprint/stage/template/update', function_type: "PROJECT"}, // 更新模板信息
    template_add: {url: '/api/coop/sprint/stage/template/add', function_type: "PROJECT"}, // 新增模板
    template_use: {url: '/api/coop/sprint/using_template/update', function_type: "PROJECT"}, // 使用模板
    query_ids: {url: '/api/coop/sprint/query/ids', function_type: "SYS"}
  },
  review: {
    get_review_users: {url: "/api/coop/review/user/list", function_type: "SYS"},
    add_review: {url: "/api/coop/review/add", function_type: "SYS"},
    update_review: {url: "/api/coop/review/update", function_type: "SYS"},
    delete_review: {url: "/api/coop/review/delete", function_type: "SYS"},
    save_review_result: {url: "/api/coop/review/save_review_result", function_type: "SYS"},
    complete_review: {url: "/api/coop/review/complete_review", function_type: "SYS"},
    search_require: {url: "/api/coop/review/search_require", function_type: "SYS"},
    brief_info: {url: "/api/coop/review/brief_info", function_type: "SYS"},
    require_detail_info_tree: {url: "/api/coop/review/require_detail_info_tree", function_type: "SYS"},
    require_info_tree: {url: "/api/coop/review/require_info_tree", function_type: "SYS"},
    convert_to_tree: {url: "/api/coop/review/convert_to_tree", function_type: "SYS"}
  },
  comment: {
    add: {url: "/api/coop/comment/add", function_type: "PROJECT"},
    list: {url: "/api/coop/comment/list", function_type: "PROJECT"}
  },
  operationLog: {
    list: {url: "/api/coop/operation/list", function_type: "PROJECT"},
  },
  requirement: {
    create: {url: "/api/coop/requirement/create", function_type: "PROJECT"},
    update: {url: "/api/coop/requirement/update", function_type: "SYS"},
    seeDemand: {url: "/api/coop/requirement/query", function_type: "SYS"},
    copy: {url: "/api/coop/requirement/copy", function_type: "PROJECT"},
    demandRelevance: {url: "/api/coop/requirement/query/assoc", function_type: "PROJECT"},
    taskDecomposition: {url: "/api/coop/requirement/query/task", function_type: "PROJECT"},
    revisedList: {url: "/api/coop/content/pageable/list/query", function_type: "PROJECT"},
    reviseDetail: {url: "/api/coop/content/query", function_type: "SYS"},
    createTask: {url: "/api/coop/task/create", function_type: "PROJECT"},
    demandTree: {url: '/api/coop/requirement/tree/query', function_type: "PROJECT"},
    demandStatus: {url: "/api/coop/status/query/list/requirement", function_type: "PROJECT"},
    list_assoc_require: {url: '/api/coop/requirement/list/query', function_type: "SYS"},
    assoc_require: {url: '/api/coop/workItem/assoc', function_type: "SYS"},
    life_cycle:{url:"/api/coop/life_cycle/list",function_type: "PROJECT"},
    relateditem:{url:"/api/coop/requirement/query/relateditem/statistic",function_type: "PROJECT"},
    unbindParentChild: {url: "/api/coop/requirement/parentChild/relation/unbind", function_type: "PROJECT"}, // 父子需求关系解绑
    delete: {url: "/api/coop/requirement/delete", function_type: "PROJECT"}, // 删除需求
    parentable: {url: "/api/coop/requirement/query/parentable", function_type: "PROJECT"}, // 可以分解任务的需求列表 - 用于任务创建选择需求
    requirement_export: {url: "/api/coop/requirement/export", function_type: "PROJECT"}, // 导出需求
    requirement_model: {url: "/api/coop/requirement/excel/model", function_type: "PROJECT"}, // 获取需求导入模板
    requirement_import: {url: "/api/coop/requirement/excel/input", function_type: "PROJECT"}, // 获取需求导入模板
    list: {url: "/api/coop/requirement/list", function_type: "SYS"},
    parentable_reqt: {url: "/api/coop/requirement/query/parentable/reqt", function_type: "PROJECT"},
  },
  requirementCategory: {
    tree: {url: '/api/coop/requirementCategory/tree/query', function_type: "PROJECT"},
    create: {url: '/api/coop/requirementCategory/create', function_type: "PROJECT"},
    delete: {url: "/api/coop/requirementCategory/delete", function_type: "PROJECT"},
    modify: {url: '/api/coop/requirementCategory/updateName', function_type: "PROJECT"},
    list: {url: '/api/coop/requirementCategory/list/query', function_type: "PROJECT"},
    change: {url: '/api/coop/requirementCategory/change', function_type: "PROJECT"},
  },
  task: {
    taskEdit: {url: '/api/coop/task/query', function_type: "PROJECT"},
    taskList: {url: '/api/coop/task/view/query/byList', function_type: "PROJECT"},
    statusView: {url: '/api/coop/task/view/query/byStatus', function_type: "PROJECT"},
    taskUpdate: {url: '/api/coop/task/update', function_type: "PROJECT"},
    personView: {url: '/api/coop/task/view/query/byStaff', function_type: "PROJECT"},
    deleteTask: {url: "/api/coop/task/delete", function_type: "PROJECT"},
    task_view: {url: "/api/coop/task/view/query/custom/byStatus", function_type: "PROJECT"},
    person_view: {url: "/api/coop/task/view/query/custom/byStaff", function_type: "PROJECT"},
    time_linkage_calculate: {url: "/frontend/coop/assist/time_linkage_calculate", function_type: "SYS"}, // 任务工时、开始、结束时间联动
    holiday: {url: "/frontend/coop/assist/holiday/work/info", function_type: "SYS"}, // 日期节假日信息获取 暂时放在这里，后续放到公共接口组
    
    task_export: {url: "/api/coop/task/export", function_type: "PROJECT"}, // 导出任务
    requirement_list:{url: " /api/coop/requirement/simple/list", function_type: "PROJECT"}, // 导出任务
    requirement_update:{url: "/api/coop/requirement/update/parent", function_type: "PROJECT"}, // 更新父需求
  },
  attachment: {
    upload: {url: "/api/coop/attachment/upload", function_type: "SYS"},
    query: {url: "/api/coop/attachment/list/query", function_type: "SYS"},
    delete: {url: "/api/coop/attachment/delete", function_type: "SYS"}
  },
  mine: {
    minedDemand: {url: "/api/coop/requirement/list/query", function_type: "SYS"},
    mineTask: {url: "/api/coop/task/list/query", function_type: "SYS"},
    reviewList: {url: "/api/coop/review/list/v2", function_type: "SYS"},
    attachmentsList: {url: "/api/coop/attachment/list/query", function_type: "SYS"},
    updateDemand: {url: "/api/coop/requirement/update", function_type: "SYS"},
    workbenchCount: {url: "/api/coop/workbench/unhandle_item/count", function_type: "SYS"},
    statistics:{url: "/api/coop/workbench/item_count/v2", function_type: "SYS"},
    unhandle_workitem:{url: "/api/coop/workbench/unhandle_item/list", function_type: "SYS"},
    requirePoolProjectList: {url: '/api/coop/workbench/require_pool/project/list', function_type: "SYS"},
    workBenchProjectAuth: {url: '/api/coop/workbench/auth', function_type: "SYS"},

  },
  defect:{
    defect_list:{url: '/api/coop/defect/list/query', function_type: "SYS"},
    update_list:{url: '/api/coop/defect/update', function_type: "SYS"},
    list: {url: '/api/coop/defect/list', function_type: "SYS"}
  },
  status: {
    list_updatable: {url: "/api/coop/status/query/updatable", function_type: "SYS"},
    workbench_status: {url: "/api/coop/status/query/workbench", function_type: "SYS"}
  },
  project: {
    team_list: {url: "/api/coop/project/list", function_type: "SYS"},
    assign_team_list: {url: "/api/coop/project/assign/team/list", function_type: "SYS"},
    assign_project_list: {url: "/api/coop/project/assign/project/list", function_type: "SYS"},
    project_user_list: {url: "/api/coop/project/user/query/list", function_type: "PROJECT"},
    projectList: {url: '/api/coop/project/list', function_type: "SYS"},
    project_mine_list: {url: "/api/coop/project/with_create_require_auth/list", function_type: "SYS"}, // 我管理的项目列表
    complete_project: {url: '/api/coop/project/complete', function_type: "PROJECT"}, //结束项目
    projectListPageination: {url: '/api/coop/project/query/list', function_type: "SYS"},
    assignUser: {url: '/api/coop/project/user/query/list', function_type: "PROJECT"},
    info: {url: "/api/coop/project/query/info", function_type: "SYS"},
    query_assign_user: {url: "/api/coop/project/assign/user/query/list", function_type: "SYS"},
    coop_project_create: {url: '/api/coop/project/create', function_type: 'SYS'},
    coop_project_update: {url: '/api/coop/project/update', function_type: 'PROJECT'},
    coop_project_delete: {url: '/api/coop/project/delete', function_type: 'PROJECT'},
    coop_project_management_biz_list: {url: '/api/coop/project/management/biz/list', function_type: 'PROJECT'},
    coop_project_management_biz_assoc: {url: '/api/coop/project/management/biz/assoc', function_type: 'PROJECT'},
    coop_project_management_biz_available: {url: '/api/coop/project/management/biz/available', function_type: 'PROJECT'},
    coop_project_management_biz_disassoc: {url: '/api/coop/project/management/biz/disassoc', function_type: 'PROJECT'},
    coop_project_management_staff_list: {url: '/api/coop/project/management/staff/list', function_type: 'PROJECT'},
    coop_project_management_staff_roles_available: {
      url: '/api/coop/project/management/staff/roles/available',
      function_type: 'PROJECT'
    },
    coop_project_management_staff_roles_config: {
      url: '/api/coop/project/management/staff/roles/config',
      function_type: 'PROJECT'
    },
    coop_project_management_staff_remove: {url: '/api/coop/project/management/staff/remove', function_type: 'PROJECT'},
    staff_copy:{url: '/api/coop/project/management/staff/copy/list', function_type: 'PROJECT'},
    project_config:{url: '/api/coop/project_set/project/config', function_type: 'SYS'},//配置项目所属项目集
    project_set_list:{url: '/api/coop/project_set/project/list', function_type: 'SYS'},//参看项目集中的项目列表
    project_list:{url: '/api/coop/project_set/list', function_type: 'SYS'},//查看项目集列表
    project_set_update:{url: ' /api/coop/project_set/update', function_type: 'SYS'},//修改项目集
    project_set_delete:{url: ' /api/coop/project_set/delete', function_type: 'SYS'},//删除项目集
    project_set_create:{url: '/api/coop/project_set/create', function_type: 'SYS'},//添加项目集
    project_project_set_list:{url: '/api/coop/project/project_set/list', function_type: 'SYS'},//项目所属项目集列表
  },
  user_info: {
    get_user_info: {url: "/api/coop/project/query/userInfo", function_type: "SYS"},
    get_search_users: {url: "/api/coop/common/user/list", function_type: "SYS"},
  },
  // 缺陷管理相关 url
  bug_info: {
    bug_list: {url: '/api/coop/defect/list/query', function_type: "PROJECT"}, // 缺陷列表
    bug_detail: {url: '/api/coop/defect/query', function_type: "SYS"}, // 缺陷详情
    statusUpdatableList: {url: '/api/coop/status/query/updatable', function_type: "PROJECT"}, // 基本信息-可变更状态列表
    assignUsersList: {url: '/api/coop/project/user/query/list', function_type: "PROJECT"}, // 基本信息-可指派人员列表
    spritList: {url: '/api/coop/sprint/list_name', function_type: "PROJECT"}, // 基本信息-已有迭代列表
    causeList: {url: '/api/coop/defect/cause/list', function_type: "PROJECT"}, // 基本信息-缺陷原因列表
    priorityList: {url: '/api/coop/workItem/priority/list', function_type: "PROJECT"}, // 基本信息-严重程度列表
    getCustomFiledInfo: {url: '/api/coop/defect/custom/project/fields', function_type: "PROJECT"}, // 基本信息-获取定义字段信息
    updateCustomFiledInfo: {url: '/api/coop/defect/custom/project/fields/update', function_type: "PROJECT"}, // 基本信息-更新定义字段信息
    getCustomFiledSelectList: {url: '/api/coop/defect/custom/fields/choice', function_type: "PROJECT"}, // 基本信息-获取自定义字段的可选择值
    new_bug_post: {url: '/api/coop/defect/create', function_type: "PROJECT"}, // 新建缺陷
    update_bug_post: {url: '/api/coop/defect/update', function_type: "PROJECT"}, // 更新缺陷
    bug_status_list: {url: '/api/coop/operation/defect/statuses', function_type: "PROJECT"}, // 缺陷状态记录
    bug_operate_list: {url: '/api/coop/operation/list', function_type: "PROJECT"}, // 缺陷操作记录
    assoc_list: {url: '/api/coop/workItem/query/assoc', function_type: "PROJECT"}, // 查询关联工作项
    all_status_list: {url: '/api/coop/status/query/all', function_type: "PROJECT"}, // 全部状态查询
    remove_assoc_item: {url: '/api/coop/workItem/assoc/remove', function_type: "PROJECT"}, // 移除关联工作项
    bug_export: {url: '/api/coop/defect/export', function_type: "PROJECT"}, // 导出缺陷列表
    bug_delete:{url: '/api/coop/defect/delete', function_type: "PROJECT"}, //删除缺陷
    bug_transFormation:{url: '/api/coop/requirement/bugTransFormation', function_type: "PROJECT"}, //bug转需求
    bug_model:{url: ' /api/coop/defect/excel/model', function_type: "PROJECT"}, //获取缺陷导入模板
    bug_import:{url: ' /api/coop/defect/excel/input', function_type: "PROJECT"}, //批量导入缺陷
  },
  // 报表相关 url
  chart:{
    defect_distribute: {url: "/api/coop/chart/defect/distribute", function_type: "PROJECT"},
    defect_avg_close_minute: {url: "/api/coop/chart/defect/avg_close_minute", function_type: "PROJECT"},
    defect_reopen_rate :{url: "/api/coop/chart/defect/reopen_rate", function_type: "PROJECT"},
    chart_delivery_ability :{url: " /api/coop/chart/delivery_ability", function_type: "PROJECT"},
    chart_add :{url: "/api/coop/chart_custom/add", function_type: "SYS"},
    chart_list :{url: "/api/coop/chart_custom/list", function_type: "SYS"},
    chart_list_data :{url: "/api/coop/chart_custom/data", function_type: "SYS"},
    chart_delete :{url: "/api/coop/chart_custom/delete", function_type: "SYS"},
    chart_detail :{url: "/api/coop/chart_custom/detail", function_type: "SYS"},
    chart_update :{url: "/api/coop/chart_custom/update", function_type: "SYS"},
  },
  // 工作流状态设置 url，用于项目协同 -> 设置
  work_status_fow: {
    query: {url: "/api/coop/status/config/query", function_type: "PROJECT"}, // 获取全部工作流信息
    query_preview: {url: "/frontend/coop/assist/previewWorkflow", function_type: "PROJECT"}, // 获取全部工作流信息
    query_replicable: {url: "/api/coop/status/config/replicable", function_type: "PROJECT"}, // 获取可复制工作流信息
    with_staff: {url: "/api/coop/project/with_staff_manage_auth/list", function_type: "PROJECT"}, // 获取可复制工作流信息
    statu_create: {url: "/api/coop/status/config/status/create", function_type: "PROJECT"}, // 创建新的工作流状态
    rule_create: {url: "/api/coop/status/config/rule/create", function_type: "PROJECT"}, // 为状态创建新的流转规则
    statu_update: {url: "/api/coop/status/config/status/update", function_type: "PROJECT"}, // 更新工作流状态信息
    statu_delete: {url: "/api/coop/status/config/status/delete", function_type: "PROJECT"}, // 删除工作流状态
    rule_delete: {url: "/api/coop/status/config/rule/delete", function_type: "PROJECT"}, // 删除状态对应的流转规则
    flow_copy: {url: "/api/coop/status/config/replicate", function_type: "PROJECT"}, // 工作流复制
    flow_public: {url: "/api/coop/status/config/public", function_type: "PROJECT"}, // 工作流公开
    descTmpl_query: {url: "/api/coop/custom/descTmpl/query", function_type: "PROJECT"}, // 自定义模板查询
    descTmpl_update: {url: "/api/coop/custom/descTmpl/update", function_type: "PROJECT"}, // 自定义模板更新
  },
  // 度量
  metric: {
    months: {url: "/api/coop/measure/months/available", function_type: "SYS"}, // 获取可过滤月份信息
    defect: {url: "/api/coop/measure/defect/query", function_type: "SYS"}, // 获取研发质量、测试质量数据
    biz_info: {url: "/api/deploy/statistics/biz/info", function_type: "SYS"}, // 获取发布统计数据
    requirement_info: {url: "/api/coop/measure/require", function_type: "SYS"}, // 获取需求质量数据
    exportDefect: {url: "/api/coop/measure/defect/export", function_type: "SYS"}, // 导出研发质量、测试质量度量数据
    exportRequirement: {url: "/api/coop/measure/export/require", function_type: "SYS"}, // 导出需求质量度量数据
    exportBiz: {url: "/api/deploy/statistics/export/excel", function_type: "SYS"}, // 导出发布统计度量数据
    exportAll: {url: "/api/coop/measure/export", function_type: "SYS"} // 导出全部度量数据
  },
  // 项目内权限自定义
  AuthCustom,
  // 项目内自定义字段
  CustomField,
  // 项目内自定义过滤器
  CustomFilter,

  code:{
    sprint_code_association:{url: "/api/coop/code_association/statistics", function_type: "PROJECT"}, //迭代代码统计
    workItem_code_association:{url: "/api/coop/code_association/query", function_type: "PROJECT"},//代码提示
  },
// ************************************文档***************************************//
  document:{
    folder_query:{url: "/api/coop/documentFolder/tree/query", function_type: "PROJECT"}, //文件夹树结构
    folder_updateName:{url: "/api/coop/documentFolder/updateName", function_type: "PROJECT"}, //更新文件夹名称
    folder_create:{url: "/api/coop/documentFolder/create", function_type: "PROJECT"}, //创建文件夹
    folder_delete:{url: "/api/coop/documentFolder/delete", function_type: "PROJECT"}, //删除文件夹
    doc_tree_query:{url: "/api/coop/documentFolder/doc/tree/query", function_type: "PROJECT"}, //关联文档树形接口
    move:{url: "/api/coop/documentFolder/move", function_type: "PROJECT"}, //文件夹移动
    attachment_list:{url: "/api/coop/document/attachment/query", function_type: "PROJECT"}, //工作项附件列表
    doc_query:{url: "/api/coop/document/list/query", function_type: "PROJECT"}, //上传文档列表展示接口
    upload:{url: "/api/coop/document/upload", function_type: "PROJECT"}, //文档上传
    download:{url: "/api/coop/document/download/{fileName}", function_type: "PROJECT"}, //下载文件
    doc_delete:{url: "/api/coop/document/delete", function_type: "PROJECT"}, //删除文档
    rename:{url: "/api/coop/document/rename", function_type: "PROJECT"}, //文档重命名
    move_document:{url: "/api/coop/document/move", function_type: "PROJECT"}, //移动文档
    doc_association:{url: "/api/coop/document/association/doc", function_type: "PROJECT"}, //关联文档为附件
  },
  apidoc:{
    get_class:{url: "/api/apidoc/get_class", function_type: "PROJECT"}, //获取文档
    get_one_class:{url: "/api/apidoc/get_one_class", function_type: "PROJECT"}, //获取文档
    save_class:{url: "/api/apidoc/save_class", function_type: "PROJECT"}, //创建文档
    delete_class:{url: "/api/apidoc/delete_class", function_type: "PROJECT"}, //删除文档
    update_class:{url: "/api/apidoc/update_class", function_type: "PROJECT"}, //更新文档
    get_type:{url: "/api/apidoc/get_type", function_type: "PROJECT"}, //获取分类列表

    save_type:{url: "/api/apidoc/save_type", function_type: "PROJECT"}, //创建分类
    update_type:{url: "/api/apidoc/update_type", function_type: "PROJECT"}, //更新分类
    delete_type:{url: "/api/apidoc/delete_type", function_type: "PROJECT"}, //删除分类
    create_api:{url: "/api/apidoc/create_api", function_type: "PROJECT"}, //创建接口
    delete_api:{url: "/api/apidoc/delete_api", function_type: "PROJECT"}, //删除接口
    save_api_info:{url: "/api/apidoc/save_api_info", function_type: "PROJECT"}, //保存接口信息接口

    get_api_list:{url: "/api/apidoc/get_api_list", function_type: "PROJECT"},//获取分类接口列表
    get_all_api:{url: "/api/apidoc/get_all_api", function_type: "PROJECT"}, //获取全部分类列表

    get_class_env:{url: "/api/apidoc/get_class_env", function_type: "PROJECT"}, //获取接口文档环境
    delete_class_env:{url: "/api/apidoc/delete_class_env", function_type: "PROJECT"}, //删除接口文档环境
    update_class_env:{url: "/api/apidoc/update_class_env", function_type: "PROJECT"}, //更新接口文档环境
    save_class_env:{url: "/api/apidoc/save_class_env", function_type: "PROJECT"}, //保存接口文档环境
    get_all_type:{url: "/api/apidoc/get_all_type", function_type: "PROJECT"}, //保存接口文档环境
    update_api_type:{url: "/api/apidoc/update_api_type", function_type: "PROJECT"}, //更新接口的分类
    update_api_status:{url: "/api/apidoc/update_api_status", function_type: "PROJECT"}, //更新接口状态
    get_api_info:{url: "/api/apidoc/get_api_info", function_type: "PROJECT"}, //获取接口信息接口

    export_api_doc:{url: "/api/apidoc/export", function_type: "PROJECT"}, //导出接口文档
    import_yapi_api:{url: "/api/apidoc/import", function_type: "PROJECT"}, //导入yapi接口
    save_run_data:{url: "/api/apidoc/save_run_data", function_type: "PROJECT"}, //保存运行接口
    get_run_data:{url: "/api/apidoc/get_run_data", function_type: "PROJECT"}, //获取运行接口
  },

}
