<template>
  <div class="home page">
    <h3>{{status}}</h3>
    <p>{{msg}}</p>
    <router-link :to="from">点击返回</router-link>
  </div>
</template>

<script>
  export default {
    name: 'err_page',
    data() {
      return {
        from: this.$route.query.from || '',
        msg: this.$route.query.msg || '',
        status: this.$route.query.status || 404
      }
    },
    mounted() {
    }
  }
</script>

<style lang="scss" scoped>
  .home {
    text-align: center;
    h3 {
      margin-top: 100px;
    }
    p {
      font-size: 16px;
    }
  }
</style>
