<template>
  <div class="chart-pading-t">
    <!-- <ve-pie :data="chartData" :extend="chartExtend" v-if="chartType === 1"> </ve-pie> -->
    <ve-pie v-if="chartData.columns.length !==0" :data="chartData" :legend-visible="false">
    </ve-pie>
    <div v-if="chartData.columns.length ===0" class="emty-chart">
      <i class="el-icon-bell"></i>哎呦,暂无相关数据
    </div>
    <el-table v-show="showTable" :data="tableData" style="width: 100%">
      <el-table-column :prop="item.value" :label="item.key" v-for="item in tableTheaderData" :key="item.key">
      </el-table-column>
    </el-table>
    <div class="menulist" v-if="showMenu === id">
      <div class="menu" @click="showTableMethod()">{{showTable?'隐藏表格':'显示表格'}}</div>
      <div class="menu" @click="editChart(id)" v-show="authFunction('FUNC_COOP_CHART_UPDATE',0) && !isSystem">
        编辑
      </div>
      <div class="menu" @click="deletChart(id)" v-show="authFunction('FUNC_COOP_CHART_DELETE',0)">删除</div>
    </div>
  </div>

</template>
<script>
  import VePie from 'v-charts/lib/pie.common'

  export default {
    mame: "LineChart",
    components: {
      VePie,
    },
    data() {
      return {
        showTable: false,
        chartExtend: {
          series: {
            barMaxWidth: 20,
            cursor: 'default'
          },
          xAxis: {
            axisLabel: {
              showMaxLabel: true,
              rotate: 40,
              interval: 0,
            },

          },
        },

      }
    },
    props: {
      chartData: {
        type: Object,
        required: true,
      },
      id: {
        required: true,
      },
      showMenu: {
        required: true,
      },
      tableData: {
        required: true,
      },
      tableTheaderData: {
        required: true,
      },
      isSystem: {
        type: Boolean,
        desc: '是否是系统内置'
      }

    },
    mounted() {
      // console.log(this.chartData, this.showMenu)
    },
    methods: {
      editChart() {
        let projectId = this.getUrlParams().projectId;
        this.goToPage(this, 'chartDetail', {chartId: this.id, projectId});
      },
      deletChart() {
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          let projectId = this.getUrlParams().projectId;
          $http.post($http.api.chart.chart_delete, {chartId: this.id, projectId: projectId}).then(res => {
            this.$emit("updateChart")
          })
        }).catch(() => {
        });
      },
      showTableMethod() {
        this.showTable = !this.showTable;

      }
    },
  }
</script>
<style lang="scss" scoped>
  .chart-pading-t {
    box-sizing: border-box;
    padding-top: 10px;
  }

  .menulist {
    width: 72px;
    /*设置为0 隐藏自定义菜单*/
    height: 75px;
    overflow: hidden;
    /*隐藏溢出的元素*/
    right: 10px;
    top: 32px;
    background-color: #fff;
    position: absolute;
    /*自定义菜单相对与body元素进行定位*/
    z-index: 10001;
    border: 1px solid #EEF0F6;

    .menu {
      width: 72px;
      height: 25px;
      line-height: 25px;
      padding: 0 10px;
      color: #333;
      cursor: pointer;

      &:hover {
        background-color: #409EFF;
      }

      /* border: 1px solid #ccc; */
    }
  }

  .emty-chart {
    text-align: center;
    padding: 100px 0;
  }
</style>
