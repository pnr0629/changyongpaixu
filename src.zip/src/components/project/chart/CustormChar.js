const data = function() {
  return {}
}
const methods = {
  // 获取可指派人员列表
  getAssignUsersList() {
    return $http.post($http.api.bug_info.assignUsersList, {
      projectId: this.projectId,
      query: ''
    })
  },
  // 获取迭代列表
  getSpritList() {
    return $http.get($http.api.bug_info.spritList, {
      projectId: this.projectId,
      status: 1
    })
  },
  // 获取全部状态列表
  getAllStatusList() {
    return $http.post($http.api.bug_info.all_status_list, {
      projectId: this.projectId, // 不用传 status
      workItemType: 3
    })
  },
  // 获取严重程度列表
  getPriorityList() {
    return $http.get($http.api.bug_info.priorityList, {
      projectId: this.projectId, // 不用传 status
      workItemType: 3
    })
    // return Promise.resolve({
    //   status: 200,
    //   msg: '',
    //   data: [
    //     { key: 100, value: "P0" },
    //     { key: 90, value: "P1" },
    //     { key: 80, value: "P2" },
    //     { key: 70, value: "P3" }
    //   ]
    // })
  },
  // 获取原因列表
  getCauseList() {
    return $http.get($http.api.bug_info.causeList, {
      projectId: this.projectId // 不用传 status
    })
  },
  // http 错误统一处理
  httpErrorHandle(param) {
    this.$message({ message: param, type: 'error' })
  },
}
export default {
  data,
  methods
}
