<template>
  <div class="over">
    <div class="multiple">
      <div class="base-info-item fl">
        <span class="base-info-item-label ">迭代：</span>
        <span class="base-info-item-static">
          <el-select v-model="sendInformation.sprintDynamicFlag" placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in sprintSelect" :key="item.value" :label="item.label" :value="item.value">
            </el-option>
          </el-select>
        </span>
        <el-tooltip class="item" effect="dark" content="动态指定：在查询页面动态勾选迭代，然后点击查询，对应的报表数据会动态更新。反之，则不会更新。建议设为动态！" placement="right">
          <i class="el-icon-info"></i>
        </el-tooltip>
      </div>
      <div class="el-form-sprint-select fl">
        <el-select v-model="sendInformation.sprintIdList" multiple placeholder="请选择"
                   v-if="sendInformation.sprintDynamicFlag === 0" style="width: 200px;">
          <el-option v-for="item in fieldEditObject.sprintList" :key="item.id" :label="item.name" :value="item.id">
          </el-option>
        </el-select>
      </div>
    </div>

    <div class="base-info-item">
      <span class="base-info-item-label">创建时间：</span>
      <span class="base-info-item-static">
        <el-select v-model="sendInformation.createTime.dynamicFlag" placeholder="请选择" style="width: 200px;">
          <el-option v-for="item in timeSelect" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </span>
      <el-tooltip class="item" effect="dark" content="动态指定：在查询页面动态指定创建时间，然后点击查询，对应的报表数据会动态更新。反之，则不会更新。建议设为动态！" placement="right">
        <i class="el-icon-info"></i>
      </el-tooltip>
      <span class="base-info-item-static" v-show="sendInformation.createTime.dynamicFlag === 0">
        <custom-date v-model="sendInformation.createTime.startTime">
        </custom-date>
      </span>
      <span class="base-info-item-static" v-show="sendInformation.createTime.dynamicFlag === 0">
        <custom-date v-model="sendInformation.createTime.endTime" class="ml10">
        </custom-date>
      </span>
    </div>

    <!-- <div class="base-info-item">
    </div> -->
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">创建人：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.createUserList" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.assignUserList" :key="item.key" :label="item.value"
                       :value="item.key">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">处理人：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.assignUserList" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.assignUserList" :key="item.key" :label="item.value"
                       :value="item.key">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>

    <div class="base-info-item">
      <span class="base-info-item-label">严重程度：</span>
      <span class="base-info-item-static">
        <el-checkbox-group v-model="sendInformation.priorityList" @change="changeVal">
          <el-checkbox v-for="item in fieldEditObject.priorityList" :label="item.key" :key="item.key">{{item.literal}}
          </el-checkbox>
        </el-checkbox-group>
      </span>
    </div>
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">状态：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.statusIdList" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.statusList" :key="item.statusId" :label="item.statusName"
                       :value="item.statusId">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">原因：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.causeIdList" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.causeList" :key="item.key" :label="item.literal"
                       :value="item.key">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
    
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">缺陷来源：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.sources" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.sourceList" :key="item.key" :label="item.value"
              :value="item.key">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
    
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">功能特性：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.functionCharacters" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.functionCharacterList" :key="item.key" :label="item.value"
              :value="item.key">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
   
    <div class="multiple">
      <div class="base-info-item">
        <span class="base-info-item-label fl">复现概率：</span>
        <span class="el-form--select fl">
          <el-select v-model="sendInformation.reproduceProbabilities" multiple placeholder="请选择" style="width: 200px;">
            <el-option v-for="item in fieldEditObject.reproduceProbabilityList" :key="item.key" :label="item.value"
              :value="item.key">
            </el-option>
          </el-select>
        </span>
      </div>
    </div>
    <!-- <div class="base-info-item">
      <span class="base-info-item-label">严重程度：</span>
      <span class="base-info-item-static">
        <el-checkbox v-model="checked1" label="备选项1" border></el-checkbox>
        <el-checkbox v-model="checked2" label="备选项2" border></el-checkbox>
        <el-checkbox v-model="checked3" label="备选项3" border></el-checkbox>
        <el-checkbox v-model="checked4" label="备选项4" border></el-checkbox>
      </span>
    </div> -->

    <div class="base-info-item">
      <span class="base-info-item-label"> 重打开次数(>=)：</span>
      <span class="base-info-item-static">
        <el-input v-model="sendInformation.reopenCount"></el-input>
      </span>
    </div>
    <div class="base-info-item">
      <span class="base-info-item-label"> 修复次数(>=)：</span>
      <span class="base-info-item-static">
        <el-input v-model="sendInformation.fixedCount"></el-input>
      </span>
    </div>
    <div class="base-info-item">
      <span class="base-info-item-label">是否为已关闭：</span>
      <span class="base-info-item-static">
        <el-radio-group v-model="sendInformation.closed">
          <el-radio :label="1">是</el-radio>
          <el-radio :label="0">否</el-radio>
        </el-radio-group>
      </span>
    </div>
  </div>
</template>
<script>
  import CustormChar from './CustormChar.js';

  export default {
    name: "MolecularFiltration",
    mixins: [CustormChar],
    data() {
      return {
        projectId: this.getUrlParams().projectId,
        sprintSelect: [{
          label: "动态指定",
          value: 1,
        }, {
          label: "固定指定",
          value: 0
        }
        ],
        timeSelect: [{
          label: "动态指定",
          value: 1,
        }, {
          label: "固定指定",
          value: 0
        }
        ],
        molecularInformation: {
          sprint: "",
        },
        fieldEditObject: {
          statusList: [],
          assignUserList: [],
          sprintList: [],
          priorityList: [],
          causeList: [],
          sourceList: [], // 缺陷来源
          functionCharacterList: [], // 功能特性
          reproduceProbabilityList: [], // 复现概率
        },
        sendInformation: {
          sprintDynamicFlag: 1,
          sprintIdList: [],
          createUserList: [],
          assignUserList: [],
          priorityList: [],
          statusIdList: [],
          causeIdList: [],
          sources: [], // 缺陷来源
          functionCharacters: [], // 功能特性
          reproduceProbabilities: [], // 复现概率
          createTime: {
            dynamicFlag: 1,
            startTime: null,
            endTime: null,
          },
          finishTime: {
            startTime: null,
            endTime: null,
          },
          reopenCount: null,
          fixedCount: null,
          closed: null
        }
      }
    },
    props: {
      molecularData: {
        type: Object,
        require: false
      },
    },
    mounted() {
      this.getBasicData();
      this.getCustomFieldList();
      // 设置默认值
      setTimeout(() => {
        if (this.molecularData) {
          for (var i in this.molecularData) {
            for (var j in this.sendInformation) {
              if (i === j) {
                this.sendInformation[j] = this.molecularData[i];
              }
            }
          }
        }
      }, 500)
    },
    methods: {
      changeVal(val) {
        //alert(this.sendInformation.priorityList)
      },
      getBasicData() {
        this.projectId = this.getUrlParams().projectId;

        const promiseArr = [],
          fieldEditObjectKeys = []

        if (this.fieldEditObject.statusList.length === 0) {
          // 获取可指派人员列表
          promiseArr.push(this.getAllStatusList())
          fieldEditObjectKeys.push('statusList')
        }
        if (this.fieldEditObject.assignUserList.length === 0) {
          // 获取可指派人员列表
          promiseArr.push(this.getAssignUsersList())
          fieldEditObjectKeys.push('assignUserList')
        }
        if (this.fieldEditObject.sprintList.length === 0) {
          // 获取迭代列表
          promiseArr.push(this.getSpritList())
          fieldEditObjectKeys.push('sprintList')
        }
        if (this.fieldEditObject.priorityList.length === 0) {
          // 获取严重程度列表
          promiseArr.push(this.getPriorityList())
          fieldEditObjectKeys.push('priorityList')
        }
        if (this.fieldEditObject.causeList.length === 0) {
          // 获取原因列表
          promiseArr.push(this.getCauseList())
          fieldEditObjectKeys.push('causeList')
        }
        if (promiseArr.length === 0) {
          return;
        }

        // this.loadingStatus.basicLoading = true
        Promise.all(promiseArr).then(lists => {
          // this.loadingStatus.basicLoading = false
          // console.log(lists)
          lists.forEach((item, index) => {
            if (item.status === 200) {
              let keyName = '',
                valueName = ''
              switch (fieldEditObjectKeys[index]) {
                case 'statusList':
                  keyName = "statusId", valueName = 'statusName'
                case 'assignUserList':
                  keyName = 'userId', valueName = 'userName';
                  break;
                case 'sprintList':
                  keyName = 'id', valueName = 'name';
                  break;
                case 'priorityList':
                  keyName = 'priority', valueName = 'literal';
                  break;
                case 'causeList':
                  keyName = 'cause', valueName = 'literal';
                  break;
                default:
                  ;
              }
              this.fieldEditObject[fieldEditObjectKeys[index]] = item.data.map(jtem => {
                return {
                  key: jtem[keyName],
                  // value: jtem[valueName]
                  value: keyName === 'userId' ? (jtem[valueName] + '(' + jtem[keyName] + ')') : jtem[
                    valueName],
                  ...jtem
                }
              })

            } else {
              this.httpErrorHandle(item.msg)
            }
          })
        }).catch(e => {
          this.loadingStatus.basicLoading = false
          this.httpErrorHandle('网络又出问题了，请刷新页面重试')
        })
      },
      // 缺陷来源、功能特性、复现概率
      getCustomFieldList() {
        const arr = ['source', 'functionCharacter', 'reproduceProbability'];
        arr.forEach(item => this.getCustomFiledSelectList(item))
      },
      // 获取自定义字段的可选择值
      async getCustomFiledSelectList(fieldId, projectId) {
        let result = await $http.get($http.api.bug_info.getCustomFiledSelectList, {
          projectId: projectId || this.projectId,
          fieldId
        })
        if(result.status === 200) {
          this.fieldEditObject[fieldId + 'List'] = result.data.choices.map(item => {
            return {
              key: item.fieldValue,
              value: item.fieldDisplay,
              ...item
            }
          })
        }
      },
    },
  }

</script>
<style lang="scss" scoped>
  @import './NewCustormChart.scss';

  .el-form--select {
    display: inline-block;
    vertical-align: top;
    margin-left: 9px;
  }

  .multiple {
    overflow: hidden;

    .el-form-sprint-select {
      position: relative;
      left: 20px;
      top: 7px;
    }
  }
</style>
