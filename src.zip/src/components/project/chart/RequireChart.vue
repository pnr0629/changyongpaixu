<template>
  <div>
    <ve-line :settings="chartSettings" :data="chartData" height="100px" :extend="chartExtend" :legend-visible="false">
    </ve-line>
  </div>

</template>
<script>
  import VeLine from 'v-charts/lib/line.common'
  export default {
    mame: "LineChart",
    components: {
      VeLine,
    },
    data() {
      return {
        showTable: false,
        chartExtend: {
          backgroundColor: '',
          series: {
            barMaxWidth: 20,
            cursor: 'default',
            symbolSize: 12,   //折线点的大小

          },
          tooltip: {
            trigger: 'item',
            formatter: function (params) {
              var color = params.color;//图例颜色
              var htmlStr = '<div>';
              htmlStr += '<span style="margin-right:5px;display:inline-block;width:10px;height:10px;border-radius:5px;background-color:' + color + ';"></span>';
              //添加一个汉字，这里你可以格式你的数字或者自定义文本内容
              htmlStr += params.name + '：' + params.value[1] + params.seriesName;
              htmlStr += '</div>';
              return htmlStr;
            }
          },
          xAxis: {
            axisLabel: {
              showMaxLabel: true,
              rotate: 40,
              interval: 0,
            },
            show: false
          },
          yAxis: {
            show: false
            // yAxisType: ['percent'],
          },
          grid: {   // 设置条形图在画布中的位置
            top: 160,
            left: -10,
          },
        },
        chartSettings: {
          // yAxisType: ['percent'],
          type: 'category',
        }
      }
    },
    props: {
      chartData: {
        type: Object,
        required: true,
      },
    },
    methods: {
    },
  }
</script>
<style lang="scss" scoped>

</style>