<template>
  <div @click="allMenuShow" class="bug-chart">
    <requirement-detail></requirement-detail>
    <div class="serach-box" v-if="staticChartList.length !== 0">
      <el-button type="primary" @click="createChart" style="margin-right:18px;float: right;"
        v-show="authFunction('FUNC_COOP_CHART_ADD',0)">新建报表</el-button>
    </div>
    <div class="custorm-chart">
      <div class="custorm-chart-item" v-for="(item,index) in staticChartList" :key="index">
        <template v-if="item.data.chart.chartType !== 2"><i class="iconfont icon-chartSetting chart-set"
            @click.stop="chartSet(item.data.chart.id)"></i></template>
        <span class="chart-name"> {{item.data.chart.chartName}}</span>
        <template v-if="item.data.chart.chartType === 1">
          <ve-pie :chartData="item.data.charData" :showMenu="chartListStatus.showMenu" :isSystem="item.data.chart.isSystem"
            :tableData="item.data.table.tableData" :charindicatorType="item.data.chart.indicatorType"
            :tableTheaderData="item.data.table.tableTheaderData" :id='item.data.chart.id' @updateChart="getChartList">
          </ve-pie>
        </template>
        <template v-if="item.data.chart.chartType === 2">
          <div :class="`liquid${item.data.chart.id}`"
            style="width:100%;height: 100%;box-sizing: border-box;padding-top: 10px;">
          </div>
          <div class="menulist" v-show="chartListStatus.showMenu===item.data.chart.id">
            <div class="menu" @click="editChart(item.data.chart.id)"
              v-show="authUpdate && !item.data.chart.isSystem">编辑</div>
            <div class="menu" @click="deletChart(item.data.chart.id)"
              v-show="authDelete">删除</div>
          </div>
        </template>
        <template v-if="item.data.chart.chartType === 3">
          <!-- <i class="iconfont icon-task chart-set" @click.stop="chartSet(item.data.chart.id)"></i>
                  <span class="chart-name"> {{item.data.chart.chartName}}</span> -->
          <ve-line :chartData="item.data.charData" :showMenu="chartListStatus.showMenu"
            :tableData="item.data.table.tableData" @updateChart="getChartList" :isSystem="item.data.chart.isSystem"
            :charindicatorType="item.data.chart.indicatorType" :tableTheaderData="item.data.table.tableTheaderData"
            :id='item.data.chart.id'></ve-line>

        </template>
        <template v-if="item.data.chart.chartType === 4">
          <ve-histogram :chartData="item.data.charData" :showMenu="chartListStatus.showMenu" :isSystem="item.data.chart.isSystem"
            :tableData="item.data.table.tableData" :tableTheaderData="item.data.table.tableTheaderData"
            :charindicatorType="item.data.chart.indicatorType" :id='item.data.chart.id' :chartType="1"
            @updateChart="getChartList">
          </ve-histogram>
        </template>
        <template v-if="item.data.chart.chartType === 5">
          <ve-histogram :chartData="item.data.charData" :showMenu="chartListStatus.showMenu" :isSystem="item.data.chart.isSystem"
            :tableData="item.data.table.tableData" :tableTheaderData="item.data.table.tableTheaderData"
            :charindicatorType="item.data.chart.indicatorType" :id='item.data.chart.id' :chartType="2"
            @updateChart="getChartList">
          </ve-histogram>
        </template>
      </div>
    </div>
    <div class="char-search-box">
      <el-button type="primary" v-if="staticChartList.length === 0" @click="createChart"
        style="margin-right:18px;margin-top: 5px;float: right;"
        v-show="authFunction('FUNC_COOP_CHART_ADD',0)">新建报表</el-button>
      <div class="chart-search">
        <el-form :inline="true" class="bm20">

          <div class="el-form-select">
            迭代：
            <el-select v-model="sprintIdList" multiple filterable :reserve-keyword="reserveKeyword"
              placeholder="迭代信息可多选" class="mt7 w300 ">
              <el-option :label="data.name" :value="data.id" v-for="(data,index) in sprintData" :key="index">
              </el-option>
            </el-select>
          </div>
          <el-form-item class="ml10">
            创建时间：
            <custom-date v-model="startTime">
            </custom-date>
            至
            <custom-date v-model="endTime">
            </custom-date>
          </el-form-item>

          <el-form-item class="">
            <el-button type="primary" @click="serach()" class="serach ">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="custorm-chart">
      <div class="custorm-chart-item" v-for="(item,index) in dynamicChartList" :key="index">
        <i class="iconfont icon-chartSetting chart-set" @click.stop="chartSet(item.data.chart.id)"></i>
        <span class="chart-name"> {{item.data.chart.chartName}}</span>

        <template v-if="item.data.chart.chartType === 1">
          <ve-pie :charindicatorType="item.data.chart.indicatorType" :chartData="item.data.charData"
            :showMenu="chartListStatus.showMenu" :tableData="item.data.table.tableData" :isSystem="item.data.chart.isSystem"
            :tableTheaderData="item.data.table.tableTheaderData" :id='item.data.chart.id' @updateChart="getChartList">
          </ve-pie>
        </template>
        <template v-if="item.data.chart.chartType === 2">
          <div :class="`liquid${item.data.chart.id}`" style="width:100%;height: 100%;">
          </div>
          <div class="menulist" v-show="chartListStatus.showMenu===item.data.chart.id">
            <div class="menu" @click="editChart(item.data.chart.id)"
              v-show="authUpdate && !item.data.chart.isSystem">编辑</div>
            <div class="menu" @click="deletChart(item.data.chart.id)"
              v-show="authDelete">删除</div>
          </div>
        </template>
        <template v-if="item.data.chart.chartType === 3">
          <!-- <i class="iconfont icon-task chart-set" @click.stop="chartSet(item.data.chart.id)"></i>
              <span class="chart-name"> {{item.data.chart.chartName}}</span> -->
          <ve-line :charindicatorType="item.data.chart.indicatorType" :chartData="item.data.charData"
            :showMenu="chartListStatus.showMenu" :tableData="item.data.table.tableData" :isSystem="item.data.chart.isSystem"
            :tableTheaderData="item.data.table.tableTheaderData" :id='item.data.chart.id' @updateChart="getChartList">
          </ve-line>

        </template>
        <template v-if="item.data.chart.chartType === 4">
          <ve-histogram :charindicatorType="item.data.chart.indicatorType" :chartData="item.data.charData"
            :showMenu="chartListStatus.showMenu" :tableData="item.data.table.tableData" :isSystem="item.data.chart.isSystem"
            :tableTheaderData="item.data.table.tableTheaderData" :id='item.data.chart.id' :chartType="1"
            @updateChart="getChartList">
          </ve-histogram>
        </template>
        <template v-if="item.data.chart.chartType === 5">
          <ve-histogram :charindicatorType="item.data.chart.indicatorType" :chartData="item.data.charData"
            :showMenu="chartListStatus.showMenu" :tableData="item.data.table.tableData" :isSystem="item.data.chart.isSystem"
            :tableTheaderData="item.data.table.tableTheaderData" :id='item.data.chart.id' :chartType="2"
            @updateChart="getChartList">
          </ve-histogram>
        </template>
      </div>
    </div>
    <back-top></back-top>
  </div>
</template>
<script>
  // 入口文件
  import VeLine from './LineChart.vue'
  import VeHistogram from './HistogramChart.vue'
  import VePie from './PieChart.vue'
  import RequirementDetail from './RequirementDetail'
  var echarts = require('echarts');
  import 'echarts-liquidfill/src/liquidFill';
  import ProjectCommonMixin from '../ProjectCommonMixin'
  export default {
    name: "CustormChart",
    components: {
      VeLine,
      VeHistogram,
      VePie,
      RequirementDetail
    },
    mixins: [ProjectCommonMixin],
    data() {
      return {
        charData: [],
        chartListStatus: {
          static: 0, // 静态
          dynamic: 0,// 动态,
          showMenu: '',//控制下拉菜单出现
          showTable: '',//控制表格出现
          chartType: 1,//区分一维柱状图，2维柱状图
        },
        tableData: [], // 表体
        tableTheaderData: [], // 表头
        dynamicChartList: [],//动态列表
        staticChartList: [],//静态列表，
        sprintData: [],//迭代列表
        startTime: null,
        endTime: null,
        sprintIdList: [],
        reserveKeyword: false,
        dataRecods: '',
        count: 1,
        showMenu: "",
      }
    },
    mounted() {
      this.setDefaultDate();
      this.getChartList();
      this.getSprintName()
    },
    watch: {
      chartListStatus() {
        // console.log(this.chartListStatus)
      }
    },
    computed: {
      authUpdate() {
        return this.authFunction('FUNC_COOP_CHART_UPDATE',0);
      },
      authDelete() {
        return this.authFunction('FUNC_COOP_CHART_DELETE',0);
      }
    },
    methods: {
      setDefaultDate() {
        var nowDate = new Date();
        this.endTime = nowDate;
        var ms = nowDate.getTime();

        var oneMonthAgoDate = new Date(ms - 60 * 24 * 3600 * 1000);
        this.startTime = oneMonthAgoDate;

      },
      createChart() {
        let projectId = this.getUrlParams().projectId;
        this.goToPage(this, 'cusromChart', { chartId: this.id, projectId });

      },
      allMenuShow(data) {
        this.chartListStatus.showMenu = '';
      },
      showTableMethond(data) {
        if (this.chartListStatus.showTable === data) {
          this.chartListStatus.showTable = "";
          this.chartListStatus.showMenu = '';
        } else {
          this.chartListStatus.showTable = data;
          this.chartListStatus.showMenu = '';
        }
      },
      deletChart(id) {
        this.$confirm("确定删除r?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          let projectId = this.getUrlParams().projectId;
          $http.post($http.api.chart.chart_delete, { chartId: id,projectId:projectId }).then(res => {
            this.getChartList();
          })
        }).catch(() => {
        });
      },
      editChart(id) {
        let projectId = this.getUrlParams().projectId;
        this.goToPage(this, 'chartDetail', { chartId: id, projectId })
      },
      //获取迭代列表
      getSprintName() {
        let projectId = this.getUrlParams().projectId;
        $http.get($http.api.sprint.list_sprint_name, { projectId, status: 0 }).then((res) => {
          this.sprintData = res.data
        })
      },
      serach() {
        this.getChartList();
      },
      chartSet(data) {
        // this.$set(this.chartListStatus, 'showMenu', data)
        if (this.chartListStatus.showMenu === data) {
          this.chartListStatus.showMenu = "";
        } else {
          this.chartListStatus.showMenu = data;
        }
        // this.chartListStatus.showMenu = data;
      },
      //获取图表列表
      getChartList() {
        let projectId = this.getUrlParams().projectId;
        $http.get($http.api.chart.chart_list, {projectId}).then(res => {
          // console.log(res.data)
          this.getChartListData(res.data)
        })
      },
      initDom(data, ele) {
        var dom = document.getElementsByClassName(ele)[0];
        dom.style.boxSizing = 'border-box';
        dom.style.paddingTop = '10px';
        var myChart = echarts.init(dom);
        myChart.setOption({
          series: {
            type: 'liquidFill',
            cursor: 'default',
            data: data,
            // itemStyle: {
            //   shadowBlur: 0
            // },
            outline: {
              borderDistance: 0,
              itemStyle: {
                borderWidth: 3,
                borderColor: '#156ACF',
                shadowBlur: 20,
              }
            },
            label: {
              normal: {
                textStyle: {
                  color: 'red',
                  insideColor: 'yellow',
                  fontSize: 40
                }
              }
            },
          }
        }, true);
      },
      // 递归分片获取 chart 数据 - by heyunjiang
      GETHTTPCHART(arr, isDynamic) {
        if (arr.length === 0) { return false }
        let perPage = 3 // 每次获取3个图表数据
        let current = arr.length > perPage ? arr.slice(0, perPage) : arr // current 为本次需要获取的图表
        let next = arr.length > perPage ? arr.slice(perPage) : [] // current 为下次需要获取的图表
        let promiseAll = []
        current.forEach(item => {
          promiseAll.push(this.getChartData(item.id))
        })
        // 如果是动态的
        if (isDynamic) {
          Promise.all(promiseAll).then(list => {
            // this.dynamicChartList = list;
            list.forEach((item, index) => {
              let columns = [], rows = [], tableTheaderData = [], tableData = [], oTableDate = {};
              /**每个类型都有对应的处理表格数据方法符合v-charts图表和符合一维展示不和二维展示图表表格处理方法都不一致，下面就不进行一一备注**/
              //图表类型为2 不进行数据操作  随机生产相应dom的元素进行数据传递然后渲染
              if (list[index].data.chart.chartType === 2) {
                if (list[index].data.value) {
                  let dom = `liquid${list[index].data.chart.id}`;
                  let data = [list[index].data.value]
                  setTimeout(() => {
                    this.initDom(data, dom)
                  })
                } else {
                  let data = [0];
                  this.initDom(data, dom)
                }
              }
              else if (list[index].data.chart.chartType !== 5 && list[index].data.chart.chartType !== 2) {
                if (list[index].data.data) {
                  const legends = ["legends"];
                  for (var i = 1; i < list[index].data.data[1].length; i++) {
                    columns = [...legends, String('数量')]
                    list[index].data.data[0] = columns;
                  }
                  for (var i = 1; i < list[index].data.data.length; i++) {
                    let obj = {}
                    list[index].data.data[i].forEach((item, s) => {
                      obj[list[index].data.data[0][s]] = item
                    })
                    rows.push(obj)
                  }

                  tableTheaderData = rows.map((item, index) => {
                    return { key: item.legends, value: 'value' + (index + 1) }
                  })

                  // console.log(tableTheaderData)
                  //处理以为展示图表key不符合命名规范问题
                  tableData = list[index].data.data.map((item, index) => {
                    if (index > 0) {
                      let value = 'value' + index
                      return { [value]: item[1] }
                    }
                  })
                  tableData.splice(0, 1)
                  for (var i = 0; i < tableData.length; i++) {
                    Object.assign(oTableDate, tableData[i]);
                  }
                  tableData.length = 0;
                  tableData.push(oTableDate)
                }
                list[index].data.table = {
                  tableData: tableData,
                  tableTheaderData: tableTheaderData
                }
                list[index].data.charData = {
                  columns: columns,
                  rows: rows
                }
              }//图表类型5 
              else if (list[index].data.chart.chartType == 5) {
                if (list[index].data.data) {
                  columns = list[index].data.data[0];
                  for (var i = 1; i < list[index].data.data.length; i++) {
                    let obj = {}
                    list[index].data.data[i].forEach((item, s) => {
                      obj[list[index].data.data[0][s]] = item
                    })
                    rows.push(obj)
                  }

                  //key值相对应
                  tableTheaderData = columns.map((item, index) => {
                    return { key: item, value: 'value' + (index) }
                  })

                  //处理key值要符合命名规范的的方法 
                  rows.forEach((item, index) => {
                    let tTableDate = [], tTableObject = {}
                    Object.values(item).forEach((item, index) => {
                      let obj = {}, value = 'value' + index;
                      obj = { [value]: item };
                      tTableDate.push(obj)
                    })
                    for (var i = 0; i < tTableDate.length; i++) {
                      Object.assign(tTableObject, tTableDate[i])
                    }
                    tableData.push(tTableObject)
                  })
                }
                list[index].data.table = {
                  tableData: tableData,
                  tableTheaderData: tableTheaderData
                }
                list[index].data.charData = {
                  columns: columns,
                  rows: rows

                }
              }
            })
            this.dynamicChartList = [...this.dynamicChartList, ...list]
            this.GETHTTPCHART(next, isDynamic)
            // setTimeout(()=>{
            //   this.GETHTTPCHART(next, isDynamic)
            // }, 1000)
          })
        } else {
          // 如果是静态的
          Promise.all(promiseAll).then(list => {
            // this.staticChartList = list;
            list.forEach((item, index) => {
              let columns = [], rows = [], tableTheaderData = [], tableData = [], oTableDate = {};
              /**每个类型都有对应的处理表格数据方法符合v-charts图表和符合一维展示不和二维展示图表表格处理方法都不一致，下面就不进行一一备注**/
              //图表类型为2 不进行数据操作  随机生产相应dom的元素进行数据传递然后渲染
              if (list[index].data.chart.chartType === 2) {
                if (list[index].data.value) {
                  let dom = `liquid${list[index].data.chart.id}`;
                  let data = [list[index].data.value]
                  setTimeout(() => {
                    this.initDom(data, dom)
                  })
                } else {
                  let data = [0];
                  this.initDom(data, dom)
                }

              }
              else if (list[index].data.chart.chartType !== 5 && list[index].data.chart.chartType !== 2) {
                if (list[index].data.data) {
                  const legends = ["legends"];
                  for (var i = 1; i < list[index].data.data[1].length; i++) {
                    columns = [...legends, String('s' + i)]
                    list[index].data.data[0] = columns;
                  }
                  for (var i = 1; i < list[index].data.data.length; i++) {
                    let obj = {}
                    list[index].data.data[i].forEach((item, s) => {
                      obj[list[index].data.data[0][s]] = item
                    })
                    rows.push(obj)
                  }

                  tableTheaderData = rows.map((item, index) => {
                    return { key: item.legends, value: 'value' + (index + 1) }
                  })

                  // console.log(tableTheaderData)
                  //处理以为展示图表key不符合命名规范问题
                  tableData = list[index].data.data.map((item, index) => {
                    if (index > 0) {
                      let value = 'value' + index
                      return { [value]: item[1] }
                    }
                  })
                  tableData.splice(0, 1)
                  for (var i = 0; i < tableData.length; i++) {
                    Object.assign(oTableDate, tableData[i]);
                  }
                  tableData.length = 0;
                  tableData.push(oTableDate)
                }
                list[index].data.table = {
                  tableData: tableData,
                  tableTheaderData: tableTheaderData
                }
                list[index].data.charData = {
                  columns: columns,
                  rows: rows
                }
              }//图表类型5 
              else if (list[index].data.chart.chartType == 5) {
                if (list[index].data.data) {
                  columns = list[index].data.data[0];
                  for (var i = 1; i < list[index].data.data.length; i++) {
                    let obj = {}
                    list[index].data.data[i].forEach((item, s) => {
                      obj[list[index].data.data[0][s]] = item
                    })
                    rows.push(obj)
                  }

                  //key值相对应
                  tableTheaderData = columns.map((item, index) => {
                    return { key: item, value: 'value' + (index) }
                  })

                  //处理key值要符合命名规范的的方法 
                  rows.forEach((item, index) => {
                    let tTableDate = [], tTableObject = {}
                    Object.values(item).forEach((item, index) => {
                      let obj = {}, value = 'value' + index;
                      obj = { [value]: item };
                      tTableDate.push(obj)
                    })
                    for (var i = 0; i < tTableDate.length; i++) {
                      Object.assign(tTableObject, tTableDate[i])
                    }
                    tableData.push(tTableObject)
                  })
                }
                list[index].data.table = {
                  tableData: tableData,
                  tableTheaderData: tableTheaderData
                }
                list[index].data.charData = {
                  columns: columns,
                  rows: rows

                }
              }
            })
            this.staticChartList = [...this.staticChartList, ...list]
            this.GETHTTPCHART(next, isDynamic)
            // setTimeout(()=>{
            //   this.GETHTTPCHART(next, isDynamic)
            // }, 1000)
          })
        }
      },
      getChartListData(data) {
        // 初始化
        this.dynamicChartList = []
        Array.isArray(data.dynamicChartList) && this.GETHTTPCHART(data.dynamicChartList, true)
        this.staticChartList = []
        Array.isArray(data.staticChartList) && this.GETHTTPCHART(data.staticChartList, false)
      },
      // getChartListData(data) {
      //   let dpromiseAll = [], spromiseAll = [];
      //   //动态获取
      //   //先把所以的请求存放到一个数组
      //   data.dynamicChartList.forEach(item => {
      //     dpromiseAll.push(this.getChartData(item.id))
      //   })
      //   //然后通过promise依次发送动态图表的所有请求
      //   Promise.all(dpromiseAll).then(list => {
      //     this.dynamicChartList = list;
      //     this.dynamicChartList.forEach((item, index) => {
      //       let columns = [], rows = [], tableTheaderData = [], tableData = [], oTableDate = {};
      //       /**每个类型都有对应的处理表格数据方法符合v-charts图表和符合一维展示不和二维展示图表表格处理方法都不一致，下面就不进行一一备注**/
      //       //图表类型为2 不进行数据操作  随机生产相应dom的元素进行数据传递然后渲染
      //       if (this.dynamicChartList[index].data.chart.chartType === 2) {
      //         if (this.dynamicChartList[index].data.value) {
      //           let dom = `liquid${this.dynamicChartList[index].data.chart.id}`;
      //           let data = [this.dynamicChartList[index].data.value]
      //           setTimeout(() => {
      //             this.initDom(data, dom)
      //           })
      //         } else {
      //           let data = [0];
      //           this.initDom(data, dom)
      //         }
      //       }
      //       else if (this.dynamicChartList[index].data.chart.chartType !== 5 && this.dynamicChartList[index].data.chart.chartType !== 2) {
      //         if (this.dynamicChartList[index].data.data) {
      //           const legends = ["legends"];
      //           for (var i = 1; i < this.dynamicChartList[index].data.data[1].length; i++) {
      //             columns = [...legends, String('s' + i)]
      //             this.dynamicChartList[index].data.data[0] = columns;
      //           }
      //           for (var i = 1; i < this.dynamicChartList[index].data.data.length; i++) {
      //             let obj = {}
      //             this.dynamicChartList[index].data.data[i].forEach((item, s) => {
      //               obj[this.dynamicChartList[index].data.data[0][s]] = item
      //             })
      //             rows.push(obj)
      //           }

      //           tableTheaderData = rows.map((item, index) => {
      //             return { key: item.legends, value: 'value' + (index + 1) }
      //           })

      //           // console.log(tableTheaderData)
      //           //处理以为展示图表key不符合命名规范问题
      //           tableData = this.dynamicChartList[index].data.data.map((item, index) => {
      //             if (index > 0) {
      //               let value = 'value' + index
      //               return { [value]: item[1] }
      //             }
      //           })
      //           tableData.splice(0, 1)
      //           for (var i = 0; i < tableData.length; i++) {
      //             Object.assign(oTableDate, tableData[i]);
      //           }
      //           tableData.length = 0;
      //           tableData.push(oTableDate)
      //         }
      //         this.dynamicChartList[index].data.table = {
      //           tableData: tableData,
      //           tableTheaderData: tableTheaderData
      //         }
      //         this.dynamicChartList[index].data.charData = {
      //           columns: columns,
      //           rows: rows
      //         }
      //       }//图表类型5 
      //       else if (this.dynamicChartList[index].data.chart.chartType == 5) {
      //         if (this.dynamicChartList[index].data.data) {
      //           columns = this.dynamicChartList[index].data.data[0];
      //           for (var i = 1; i < this.dynamicChartList[index].data.data.length; i++) {
      //             let obj = {}
      //             this.dynamicChartList[index].data.data[i].forEach((item, s) => {
      //               obj[this.dynamicChartList[index].data.data[0][s]] = item
      //             })
      //             rows.push(obj)
      //           }

      //           //key值相对应
      //           tableTheaderData = columns.map((item, index) => {
      //             return { key: item, value: 'value' + (index) }
      //           })

      //           //处理key值要符合命名规范的的方法 
      //           rows.forEach((item, index) => {
      //             let tTableDate = [], tTableObject = {}
      //             Object.values(item).forEach((item, index) => {
      //               let obj = {}, value = 'value' + index;
      //               obj = { [value]: item };
      //               tTableDate.push(obj)
      //             })
      //             for (var i = 0; i < tTableDate.length; i++) {
      //               Object.assign(tTableObject, tTableDate[i])
      //             }
      //             tableData.push(tTableObject)
      //           })
      //         }
      //         this.dynamicChartList[index].data.table = {
      //           tableData: tableData,
      //           tableTheaderData: tableTheaderData
      //         }
      //         this.dynamicChartList[index].data.charData = {
      //           columns: columns,
      //           rows: rows

      //         }
      //       }
      //     })

      //     // console.log(this.dynamicChartList)
      //   })
      //   //静态获取
      //   data.staticChartList.forEach(item => {
      //     spromiseAll.push(this.getChartData(item.id))
      //   })
      //   //然后通过promise依次发送动态图表的所有请求
      //   Promise.all(spromiseAll).then(list => {
      //     this.staticChartList = list;
      //     this.staticChartList.forEach((item, index) => {
      //       let columns = [], rows = [], tableTheaderData = [], tableData = [], oTableDate = {};
      //       /**每个类型都有对应的处理表格数据方法符合v-charts图表和符合一维展示不和二维展示图表表格处理方法都不一致，下面就不进行一一备注**/
      //       //图表类型为2 不进行数据操作  随机生产相应dom的元素进行数据传递然后渲染
      //       if (this.staticChartList[index].data.chart.chartType === 2) {
      //         if (this.staticChartList[index].data.value) {
      //           let dom = `liquid${this.staticChartList[index].data.chart.id}`;
      //           let data = [this.staticChartList[index].data.value]
      //           setTimeout(() => {
      //             this.initDom(data, dom)
      //           })
      //         } else {
      //           let data = [0];
      //           this.initDom(data, dom)
      //         }

      //       }

      //       else if (this.staticChartList[index].data.chart.chartType !== 5 && this.staticChartList[index].data.chart.chartType !== 2) {
      //         if (this.staticChartList[index].data.data) {
      //           const legends = ["legends"];
      //           for (var i = 1; i < this.staticChartList[index].data.data[1].length; i++) {
      //             columns = [...legends, String('s' + i)]
      //             this.staticChartList[index].data.data[0] = columns;
      //           }
      //           for (var i = 1; i < this.staticChartList[index].data.data.length; i++) {
      //             let obj = {}
      //             this.staticChartList[index].data.data[i].forEach((item, s) => {
      //               obj[this.staticChartList[index].data.data[0][s]] = item
      //             })
      //             rows.push(obj)
      //           }

      //           tableTheaderData = rows.map((item, index) => {
      //             return { key: item.legends, value: 'value' + (index + 1) }
      //           })

      //           // console.log(tableTheaderData)
      //           //处理以为展示图表key不符合命名规范问题
      //           tableData = this.staticChartList[index].data.data.map((item, index) => {
      //             if (index > 0) {
      //               let value = 'value' + index
      //               return { [value]: item[1] }
      //             }
      //           })
      //           tableData.splice(0, 1)
      //           for (var i = 0; i < tableData.length; i++) {
      //             Object.assign(oTableDate, tableData[i]);
      //           }
      //           tableData.length = 0;
      //           tableData.push(oTableDate)
      //         }
      //         this.staticChartList[index].data.table = {
      //           tableData: tableData,
      //           tableTheaderData: tableTheaderData
      //         }
      //         this.staticChartList[index].data.charData = {
      //           columns: columns,
      //           rows: rows
      //         }
      //       }//图表类型5 
      //       else if (this.staticChartList[index].data.chart.chartType == 5) {
      //         if (this.staticChartList[index].data.data) {
      //           columns = this.staticChartList[index].data.data[0];
      //           for (var i = 1; i < this.staticChartList[index].data.data.length; i++) {
      //             let obj = {}
      //             this.staticChartList[index].data.data[i].forEach((item, s) => {
      //               obj[this.staticChartList[index].data.data[0][s]] = item
      //             })
      //             rows.push(obj)
      //           }

      //           //key值相对应
      //           tableTheaderData = columns.map((item, index) => {
      //             return { key: item, value: 'value' + (index) }
      //           })

      //           //处理key值要符合命名规范的的方法 
      //           rows.forEach((item, index) => {
      //             let tTableDate = [], tTableObject = {}
      //             Object.values(item).forEach((item, index) => {
      //               let obj = {}, value = 'value' + index;
      //               obj = { [value]: item };
      //               tTableDate.push(obj)
      //             })
      //             for (var i = 0; i < tTableDate.length; i++) {
      //               Object.assign(tTableObject, tTableDate[i])
      //             }
      //             tableData.push(tTableObject)
      //           })
      //         }
      //         this.staticChartList[index].data.table = {
      //           tableData: tableData,
      //           tableTheaderData: tableTheaderData
      //         }
      //         this.staticChartList[index].data.charData = {
      //           columns: columns,
      //           rows: rows

      //         }
      //       }
      //     })
      //     // console.log(this.staticChartList)

      //   })

      // },
      //获取列表数据
      getChartData(id) {
        const urlObj = {...$http.api.chart.chart_list_data};
        urlObj.url += "?projectId=" + this.getUrlParams().projectId;
        return $http.post(urlObj, {
          chartId: id,
          startTime: this.startTime,
          endTime: this.endTime,
          sprintIdList: this.sprintIdList
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  .bug-chart {
    position: relative;

    .serach-box {
      overflow: hidden;

    }

    .char-search-box {
      min-height: 30px;
      /* margin-top: 10px; */
      position: relative;
      display: inline-block;
      width: 100%;

      .chart-search {
        float: left;
        margin-left: 20px;

        .serach {
          position: relative;
          top: -1px;
        }

        .el-form-select {
          display: inline-block;
          vertical-align: top;
        }
      }
    }

    .custorm-chart {
      display: flex;
      flex-flow: wrap;
      justify-content: space-between;
      padding: 0 20px;

      .custorm-chart-item {
        canvas {
          &:hover {
            cursor: pointer;
          }
        }

        width: 45%;
        min-height: 400px;
        position: relative;
        margin-top: 20px;

        .menulist {
          width: 72px;
          /*设置为0 隐藏自定义菜单*/
          height: 75px;
          overflow: hidden;
          /*隐藏溢出的元素*/
          right: 0;
          top: 32px;
          background-color: #fff;
          position: absolute;
          /*自定义菜单相对与body元素进行定位*/
          z-index: 10001;
          border: 1px solid #EEF0F6;

          .menu {
            width: 72px;
            height: 25px;
            line-height: 25px;
            padding: 0 10px;
            color: #333;
            cursor: pointer;

            &:hover {
              background-color: #409EFF;
            }

            /* border: 1px solid #ccc; */
          }

        }
      }

      .chart-name {
        color: #000;
        font-size: 16px;
      }

      .chart-set {
        position: absolute;
        right: 10px;
        cursor: pointer;
        top: 10px;
      }
    }
  }
</style>
