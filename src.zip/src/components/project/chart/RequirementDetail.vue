<template>
  <div class="header-box">
    <p class="header-title">交付能力概况</p>
    <div class="header-item">
      <h4 class="header-item-title">需求交付周期 <el-tooltip class="item" effect="dark"  placement="top-start">
          <div slot="content">交付周期指需求从选择到完成交付所经历的天数。<br>该指标体现团队整体上对客户需求（或市场机会）的响应能力。<br>交付周期的统计缺省以85%的置信区间为依据，<br>即统计的时间范围（如近30天）内交付的需求中，85%的交付周期小于该时间。</div>
        <i class="el-icon-info"></i>
      </el-tooltip></h4>
      <p class="header-item-content">近30天：{{deliveryAbilityData.deliverPeriodNear30}}天</p>
      <p class="header-item-content">上一周期：{{deliveryAbilityData.deliverPeriodLast30}}天</p>
      <p class="header-item-content">环比：{{deliveryAbilityData.deliverPeriodRatio || 'N/A'}}</p>
      <div class="header-item-chart">
        <require-chart v-if="finsh" :chartData="requirePay"></require-chart>
      </div>
    </div>
    <div class="header-item">
      <h4 class="header-item-title">需求开发周期<el-tooltip class="item" effect="dark"  placement="top-start">
   
        <div slot="content">开发周期指需求从对开发就绪（待开发）到开发完成（待发布）所经历的天数<br>（哥伦布系统取需求下属任务总工时 按处理人数取平均来近似计算）。该指标<br>体现技术团队的响应能力。该指标体现技术团队的响应能力。
          开发周期的统计缺省以85%的置信区间为依据，<br>即统计的时间范围（如近30天）内开发完成的需求中，85%的开发周期小于该时间。</div>
      <i class="el-icon-info"></i>
    </el-tooltip></h4>
      <p class="header-item-content">近30天：{{deliveryAbilityData.developPeriodNear30}}天</p>
      <p class="header-item-content">上一周期：{{deliveryAbilityData.developPeriodLast30}}天</p>
      <p class="header-item-content">环比：{{deliveryAbilityData.developPeriodRatio || 'N/A'}}</p>
      <div class="header-item-chart">
        <require-chart v-if="finsh" :chartData="requireDev"></require-chart>
      </div>
    </div>
    <div class="header-item">
      <h4 class="header-item-title">需求交付数
        <el-tooltip class="item" effect="dark"  placement="top-start">
   
          <div slot="content">需求交付数（吞吐量）指过去一个时间段（如近30天）内，<br>团队上线需求的个数。该指标体现团队交付的效率及其趋势。</div>
        <i class="el-icon-info"></i>
      </el-tooltip>
      </h4>
      <p class="header-item-content">近30天：{{deliveryAbilityData.deliverCountNear30}}个</p>
      <p class="header-item-content">上一周期：{{deliveryAbilityData.deliverCountLast30}}个</p>
      <p class="header-item-content">环比：{{deliveryAbilityData.deliverCountRatio || 'N/A'}}</p>
      <div class="header-item-chart">
        <require-chart v-if="finsh" :chartData="requirePayNum"></require-chart>
      </div>
    </div>
    <!-- <div class="header-item">
      <h4 class="header-item-title">缺陷存量</h4>
      <p class="header-item-content">当前存量：N/A</p>
      <p class="header-item-content">近30天新增及关闭：N/A</p>
      <p class="header-item-content">近30天净增：N/A</p>
      <div class="header-item-chart">
            position: fixed;
    top: 0;
    left: 0;
    width: 99%;
    z-index: 999;
    background-color: white;
    height: 100%;
      </div>
    </div> -->
  </div>
</template>
<script>
  /**
   * @title 交付能力概况
   * @desc 
   * @author heyunjiang
   * @date 2019.7.11
   */
  import RequireChart from './RequireChart.vue'
  export default {
    name: "RequirementDetail",
    components: { RequireChart },
    mixins: [],
    props: {},
    data() {
      return {
        //需求交付
        requirePay: {
          columns: ['月份', '天'],
          rows: [{ 月份: '1' },
          { 月份: '2' },
          { 月份: '3' },
          { 月份: '4' },
          { 月份: '5' },
          { 月份: '6' },]
        },
        //需求开发
        requireDev: {
          columns: ['月份', '天'],
          rows: [{ 月份: '1' },
          { 月份: '2' },
          { 月份: '3' },
          { 月份: '4' },
          { 月份: '5' },
          { 月份: '6' },]
        },
        //交付个数
        requirePayNum: {
          columns: ['月份', '个'],
          rows: [{ 月份: '1' },
          { 月份: '2' },
          { 月份: '3' },
          { 月份: '4' },
          { 月份: '5' },
          { 月份: '6' },]
        },
        deliveryAbilityData: {},
        finsh: false,//加载完毕
      }
    },
    computed: {},
    watch: {},
    created() { },
    mounted() {
      this.getDeliveryAbility();
    },
    methods: {
      getDeliveryAbility() {
        let projectId = this.getUrlParams().projectId;
        $http.get($http.api.chart.chart_delivery_ability, { projectId }).then(res => {
          this.deliveryAbilityData = res.data
          for (var i = 0; i < this.deliveryAbilityData.deliverPeriod6Month.length; i++) {
            this.requirePay.rows[i].天 = this.deliveryAbilityData.deliverPeriod6Month[i];
          }
          for (var i = 0; i < this.deliveryAbilityData.developPeriod6Month.length; i++) {
            this.requireDev.rows[i].天 = this.deliveryAbilityData.developPeriod6Month[i];
          }
          for (var i = 0; i < this.deliveryAbilityData.deliverCount6Month.length; i++) {
            this.requirePayNum.rows[i].个 = this.deliveryAbilityData.deliverCount6Month[i];
          }
          for (var i = 0; i < this.deliveryAbilityData.xaxis.length; i++) {
            this.requirePay.rows[i].月份 = this.deliveryAbilityData.xaxis[i];
            this.requireDev.rows[i].月份 = this.deliveryAbilityData.xaxis[i];
            this.requirePayNum.rows[i].月份 = this.deliveryAbilityData.xaxis[i];
          }
          // console.log(this.requirePay);

          this.finsh = true;
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  @import '../../../base/style/common';

  .header-box {
    padding: 10px 0;
    margin-bottom: 10px;
    background-color: $color-mo-bg-common;
    overflow: hidden;

    .header-title {
      margin: 0;
      height: 26px;
      line-height: 26px;
      font-size: 16px;
      word-spacing: 1px;
      padding-left: 10px;
    }

    .header-item {
      float: left;
      width: 33.3%;
      box-sizing: border-box;
      border-right: 1px dashed #ccc;
      padding: 10px;

      &:last-of-type {
        border-right: none;
      }

      .header-item-title,
      .header-item-content {
        height: 26px;
        line-height: 26px;
        margin: 0;
      }

      .header-item-chart {
        height: 100px;
        background-color: white;
      }
    }
  }
</style>