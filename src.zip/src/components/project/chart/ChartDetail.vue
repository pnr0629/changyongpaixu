<template>
  <div class="new-custom-chart">
    <div class="base-info-item">
      <span class="base-info-item-label"><span class="required-icon">*</span>图表名称：</span>
      <span class="base-info-item-static">
        <el-input v-model="sendInformation.chartName" style="width:420px;">
        </el-input>
      </span>
    </div>
    <div class="base-info-item">
      <span class="base-info-item-label"> <span class="required-icon">*</span>排序值：</span>
      <span class="base-info-item-static">
        <el-input v-model="sendInformation.chartShowSort"></el-input>
      </span>
    </div>
    <div class="base-info-item" style="height:80px;">
      <span class="base-info-item-label" style="position: relative;top: -40px;"><span
          class="required-icon">*</span>图表类型：</span>
      <span class="base-info-item-static" style="width:75px;" v-for="(data,index) in chartType" :key="index"
        @click="chooseChartType(data.value)">
        <div class="gray-block " :style="{'border-color': data.value === colorChoose ? '#333': 'honeydew'}"><i
            :class="data.icon"></i></div>
        <span class="chart-label">{{data.label}}</span>
      </span>
    </div>
    <div class="base-info-item" v-if="sendInformation.chartType !== 2">
      <span class="base-info-item-label"><span class="required-icon">*</span>统计指标：</span>
      <span class="base-info-item-static">
        <el-select v-model="sendInformation.indicatorType" placeholder="请选择" style="width: 200px;">
          <el-option v-for="item in indicatorType" :key="item.value" :label="item.label" :value="item.value">
          </el-option>
        </el-select>
      </span>
    </div>
    <div class="base-info-item" v-if="sendInformation.chartType !== 2">
      <span class="base-info-item-label"><span class="required-icon">*</span>分组方式：</span>
      <span class="base-info-item-static">
        <el-cascader :options="gruopingInformation" v-model="chartFiled.packetModeOne" @change="packetModeChangeOne"
          change-on-select></el-cascader>
      </span>
    </div>
    <div class="base-info-item" v-if="sendInformation.chartType === 5">
      <span class="base-info-item-label"><span class="required-icon">*</span>二级分组：</span>
      <span class="base-info-item-static">
        <el-cascader :options="gruopingInformation" v-model="chartFiled.packetModeTwo" @change="packetModeChangeTwo"
          change-on-select></el-cascader>
      </span>
    </div>
    <div class="base-info-item">
      <span class="filter-condition">设置过滤条件：</span>
      <span class="base-info-item-static">
        <el-switch v-model="onOff" active-color="#13ce66" inactive-color="#ccc">
        </el-switch>
      </span>
    </div>

    <el-tabs type="border-card" @tab-click="fitterChange" v-show="onOff">
      <el-tab-pane label="分子过滤条件" ref="molecular" @saveInfo="saveInfo">
        <molecular-filtration :molecularData="molecularData"></molecular-filtration>
      </el-tab-pane>
      <el-tab-pane label="分母过滤条件" ref="denominator"
        v-if="sendInformation.chartType === 2 || sendInformation.indicatorType ===2">
        <denominator-filter :denominatorData="denominatorData"></denominator-filter>
      </el-tab-pane>
    </el-tabs>
    <el-button type="primary" style="margin-top: 10px" @click="saveInfo">保存</el-button>
    <el-button type="info" style="margin-top: 10px" @click="cancleInfo">取消</el-button>
  </div>
</template>
<script>
  /**
   * @title 创建自定义页面 - 中心控制模块
   * @desc 模块架构设计：分3个模块，中心控制模块 + 分母过滤条件+分子过滤条件
   * @author chenxuecheng
   * @date 2019-4-11
   */
  import MolecularFiltration from './MolecularFiltration.vue'
  import DenominatorFilter from './DenominatorFilter.vue'
  export default {
    name: 'NewCustormChart',
    components: {
      MolecularFiltration,
      DenominatorFilter
    },

    data() {
      return {
        //图表类型
        chartType: [{
          label: '饼图',
          value: 1,
          icon: 'iconfont icon-pie'
        },
        {
          label: '比例图',
          value: 2,
          icon: 'iconfont icon-water1'
        },
        {
          label: "折线图",
          value: 3,
          icon: 'iconfont icon-line'
        },
        {
          label: "一维柱状图",
          value: 4,
          icon: 'iconfont icon-bar'
        },
        {
          label: "二维柱状图",
          value: 5,
          icon: 'iconfont icon-bar'
        }
        ],
        //统计指标
        indicatorType: [{
          label: "数量统计",
          value: 1,
        },
        {
          label: "比率",
          value: 2,
        },
        {
          label: "平均关闭时长",
          value: 3,
        },
        {
          label: "平均关闭时长-不含挂起时间",
          value: 6,
        },
        {
          label: "平均修复时长",
          value: 4,
        },
        {
          label: "平均验收时长",
          value: 5,
        },
        ],
        //分组信息
        gruopingInformation: [{
          label: "迭代",
          value: "sprintId",
        },
        {
          label: '创建时间',
          value: "createTime",
          children: [{
            label: '日',
            value: 'day'
          },
          {
            label: '周',
            value: "week"
          },
          {
            label: "月",
            value: 'month'
          }

          ]
        }, {
          label: '完成时间',
          value: "finishTime",
          children: [{
            label: '日',
            value: 'day'
          },
          {
            label: '周',
            value: "week"
          },
          {
            label: "月",
            value: 'month'
          }

          ]
        }, {
          label: "创建人",
          value: "createUser"
        }, {
          label: "处理人",
          value: "assignUser"
        }, {
          label: "状态",
          value: "statusId"
        }, {
          label: "严重程度",
          value: "priority"
        }
        ],
        //图表创建字段
        chartFiled: {
          charName: '', //报表名称
          charStyle: "", //报表类型
          indicatorType: "", //统计指标
          packetModeOne: [], //分组1
          packetModeTwo: [], //分组方式2
          //图表筛选字段
          sprintID: [],
          createUser: [],
          assignUser: [],
          priority: [],
          status: [],
          createDate: '',
          reopen: ''
        },
        onOff: true,
        colorChoose: null,
        priorityList: [], //优先级列表
        statusList: [], //状态列表
        sendInformation: {
          chartName: '',
          chartShowSort:'',
          chartType: "",
          indicatorType: '',

        },
        packetModeOne: {
          field: null,
          flag: null
        },
        packetModeTwo: {
          field: null,
          flag: null
        },
        molecularData: {},
        denominatorData: {}
      }
    },
    mounted() {
      this.getChartDetail()
    },
    methods: {
      getChartDetail() {
        let chartId = this.getUrlParams().chartId;
        $http.get($http.api.chart.chart_detail, { chartId }).then(res => {
          this.sendInformation = res.data;
          if (res.data.groupBy && JSON.parse(res.data.groupBy).length > 0) {
            this.chartFiled.packetModeOne.push(JSON.parse(res.data.groupBy)[0].field);
            this.chartFiled.packetModeOne.push(JSON.parse(res.data.groupBy)[0].flag);
            if (JSON.parse(res.data.groupBy).length > 1) {
              this.chartFiled.packetModeTwo.push(JSON.parse(res.data.groupBy)[1].field);
              this.chartFiled.packetModeTwo.push(JSON.parse(res.data.groupBy)[1].flag);
            }
          }
          if (res.data.filter && JSON.parse(res.data.filter).length > 0) {
            this.molecularData = JSON.parse(res.data.filter)[0];
            if (JSON.parse(res.data.filter).length > 1) {
              this.denominatorData = JSON.parse(res.data.filter)[1];
            }
          }
          this.colorChoose = res.data.chartType;
        })
      },
      //保存
      saveInfo() {
        let reg=/(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*))$/;
        if(!reg.test(this.sendInformation.chartShowSort)){
          this.$message({type:'warning',message:'排序值只能填数字并且大于零'})
          return
        }
        if(!this.sendInformation.chartType) {
          this.$message({type:'warning',message:'图表类型不能为空'})
          return
        }
        this.sendInformation.filter = [];
        this.sendInformation.groupBy = [];
        this.sendInformation.projectId = this.getUrlParams().projectId;
        if (this.packetModeOne.field) {
          this.sendInformation.groupBy.push(this.packetModeOne)
        } else {
          this.packetModeOne.field = this.chartFiled.packetModeOne[0];
          this.packetModeOne.flag = this.chartFiled.packetModeOne[1]
          this.sendInformation.groupBy.push(this.packetModeOne)
        }
        if (this.packetModeTwo.field) {
          this.sendInformation.groupBy.push(this.packetModeTwo)
        } else {
          this.packetModeTwo.field = this.chartFiled.packetModeTwo[0];
          this.packetModeTwo.flag = this.chartFiled.packetModeTwo[1]
          this.sendInformation.groupBy.push(this.packetModeTwo)
        }
        if (this.$refs.molecular) {
          this.sendInformation.filter.push(this.$refs.molecular.$children[0]._data.sendInformation)
        }
        if (this.$refs.denominator) {
          this.sendInformation.filter.push(this.$refs.denominator.$children[0]._data.sendInformation)
        }


        // console.log(this.sendInformation)
        $http.post($http.api.chart.chart_update, this.sendInformation).then(res => {
          // console.log(res)
          if(res.status === 200) {
            this.$router.go(-1);
          }
        })
      },
      //取消
      cancleInfo() {
        this.$router.go(-1);//返回上一层
      },
      //选择图表类型
      chooseChartType(value) {
        this.sendInformation.chartType = value;
        this.colorChoose = value;
      },
      //分组value改变方法
      packetModeChangeOne(val) {
        this.packetModeOne.field = val[0]
        if (val[1]) {
          this.packetModeOne.flag = val[1]
        }

      },
      //第二分组value值改变
      packetModeChangeTwo(val) {
        this.packetModeTwo.field = val[0]
        if (val[1]) {
          this.packetModeTwo.flag = val[1]

        }
      },
      //分子与分母过滤条件切换
      fitterChange() {

      },


    },
  }

</script>
<style lang="scss" scoped>
  @import './NewCustormChart.scss';

  .base-info-item {
    height: 80px;
    line-height: 80px;
  }
</style>
