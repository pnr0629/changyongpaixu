<template>
  <div id="projectList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar page-content-box-width " style="border-bottom:2px solid #d6d9e0;overflow: hidden;height:auto;">
      
        <span class="header-filter-btn-box">
           <span class="header-filter-btn" style="font-size: 16px;font-weight: 900">项目列表</span>
          <span class="header-filter-btn"
            :class="{'filter-active':  TagNameInfo.active===1, 'filter-inactive': TagNameInfo.active !==1}" type="text"
            @click="shortcutClick(false)">进行中</span>
          <span class="header-filter-btn"
            :class="{'filter-active': TagNameInfo.active===2, 'filter-inactive': TagNameInfo.active !==2}" type="text"
            @click="shortcutClick(true)">已结束</span>
          <span class="header-filter-btn" v-for="item in totalTagList" :key="item.id"
            :class="{'filter-active': TagNameInfo.active === item.id, 'filter-inactive':  TagNameInfo.active !== item.id}"
            type="text" @click="getLabelList(item.id)">{{item.name}}</span>
        </span>
        <span class="fr" style="position: relative;top: 10px;" >
            <el-button type="success"  @click="createProject" 
            v-show="authFunction('FUNC_COOP_PROJ_CREATE', 0)">创建项目</el-button>
          <el-button type="primary" class="ml10 " @click="addTapsBtn()" >标签管理
          </el-button>
        </span>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-box-top">
            <div class="table-box">
              <div class="table-box-top">
                <el-table border :data="projectListData" style="height:100%;" class="page-content-box-width"
                  :class="{'el-table-left-none':projectListData.length == 0}">
                  <el-table-column label="项目名称" min-width="100">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="intentDemandList(scope.row)">{{scope.row.name}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="创建人员" min-width="100">
                    <template slot-scope="scope">
                      <span>{{scope.row.display.createUser}} ({{scope.row.createUser}})</span>
                    </template>
                  </el-table-column>
                  <el-table-column prop="description" label="项目描述" min-width="100"></el-table-column>
                  <el-table-column prop="createTime" label="创建时间" min-width="100"></el-table-column>
                  <el-table-column label="操作" min-width="60">
                    <template slot-scope="scope">
                      <div class="opreatebtns">
                        <span v-if="scope.row.authority&&scope.row.authority.editable"
                          @click="editProject(scope.row)">编辑</span>
                        <span v-if="scope.row.authority&&scope.row.authority.completable&&!scope.row.completed"
                          @click="endProject(scope.row)">结束</span>
                        <span v-if="scope.row.authority&&scope.row.authority.deletable"
                          @click="deleteProject(scope.row)">删除</span>
                        <span @click="useTag(scope.row)">项目标签</span>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
                <el-pagination v-if="projectStatusData.filterInfo.pageInfo.totalPages > 0 && showPage"
                  class="fr table-box-footer" size="middle" layout="prev, pager, next"
                  @current-change="pagainationChange" :current-page="projectStatusData.filterInfo.pageInfo.pageNumber"
                  :page-size="projectStatusData.filterInfo.pageInfo.pageSize"
                  :page-count="projectStatusData.filterInfo.pageInfo.totalPages">
                </el-pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--创建项目，编辑项目-->
    <el-dialog title="提示" :visible.sync="dialogVisible" class="el-dialog-640w" :before-close="handleCloseProject"
      :close-on-click-modal="false">
      <div class="form-iterm-box">
        <el-form ref="projectInfo" :model="projectInfo" label-width="80px">
          <el-form-item label="项目名称" prop="name" :rules="[{ required: true, message: '项目名称不能为空' }]">
            <el-input v-model="projectInfo.name"></el-input>
          </el-form-item>
          <!-- <el-form-item label="项目分类" prop="categories" :rules="[{ required: true, message: '项目名称不能为空' }]">
            <el-select v-model="projectInfo.categories">
              <el-option>
              </el-option>
            </el-select>
          </el-form-item> -->
          <el-form-item label="项目描述" prop="description" :rules="[{ required: true, message: '项目描述不能为空' }]">
            <el-input type="textarea" v-model="projectInfo.description" :autosize="{ minRows: 5, maxRows:10}">
            </el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseProject">取 消</el-button>
        <el-button type="primary" @click="submitProject">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 标签管理 -->
    <el-dialog title='标签管理' :visible.sync="dialogVisibleTab" class="issuedialog el-dialog-740w"
      :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div class="addclassTap">
          <span class="tapTitile fl">标签信息</span>
          <el-button type="primary" class="addtap fr" style="padding-bottom: 5px;" @click="showCreateTagDialog()">+添加标签
          </el-button>
        </div>
        <el-table :data="totalTagList" style="width: 100%;height: 100%;overflow:auto;">
          <el-table-column prop="name" label="名称" min-width="120">
          </el-table-column>
          <el-table-column prop="createTime" label="创建时间" min-width="80">
          </el-table-column>
          <el-table-column prop="updateTime" label="更新时间" min-width="80">
          </el-table-column>
          <el-table-column width="120" align="left" label="操作">
            <template slot-scope="scope">
              <span class="c-blue cp" @click="showEditTagDialog(scope.row)">编辑</span>
              <span class="c-blue cp" @click="showDelTagDialog(scope.row)">删除</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 添加标签 -->
    <el-dialog :title='TagNameInfo.tapTitle' :visible.sync="dialogVisible_a" class="el-dialog-350w issuedialog"
      :before-close="closeTagEditDialog" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="TagNameInfo" ref="TagNameInfo" @submit.native.prevent>
          <el-form-item label="标签" class="mt15" label-width="55px" prop="inputTagName"
            :rules="[{required: true, message: '不能为空' ,trigger: 'blur'}]">
            <el-input v-model.trim="TagNameInfo.inputTagName" style="width: 100%;" placeholder="请输入标签名称，字数控制20字以内">
            </el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeTagEditDialog()">关闭</el-button>
        <el-button type="primary" @click="saveOrUpdateTag()">保存</el-button>
      </span>
    </el-dialog>
    <!-- 设置项目标签 -->
    <el-dialog title='设置项目标签' :visible.sync="dialogAppTagVisible" class="el-dialog-350w issuedialog"
      :before-close="handleSetAppTagDialogClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form>
          <el-form-item :gutter="10" class="mt20" label="标签" label-width="60px"
            :rules="[{ required: true, message: '不能为空'}]">
            <el-select v-model="setProject.projectSetIdList" multiple placeholder="请选择"  style="width:100%;">
              <el-option v-for="item in totalTagList" :key="item.id" :label="item.name" :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleSetAppTagDialogClose">关闭</el-button>
        <el-button type="primary" @click="bindAppTag()">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "projectList",
    data() {
      return {
        showPage: true,//是否展示分页
        totalTagList: [],//标签数据
        modaltobody: false,
        shadeBtn: false,
        TagNameInfo: {
          active: 1,
          inputTagName: "",
        },
        id: "",
        projectInfo: {
          name: "",
          // categories:"",//项目分类
          description: ""
        }, // 新建项目信息，编辑(名称、描述、结束、删除)在进入项目后的设置里面
        flag: "", // 新建/编辑
        dialogVisibleTab: false,
        setProject: {
          projectSetIdList: [],//设置项目标签集合
          projectId: "",//当前项目id
        },
        dialogVisible: false, // 创建项目 dialog
        dialogVisible_a: false,
        dialogAppTagVisible: false,
        projectListData: [],
        editProjectId: null, // 编辑项目时的 id
        loading: false,
        projectStatusData: {
          filterInfo: {
            completed: false, // true -> 已结束， false -> 进行中
            pageInfo: {
              pageNumber: 1,
              pageSize: 20,
              totalPages: 0
            }
          }
        }
      };
    },
    computed: {},
    mounted() {
      // this.getBizList();
      this.getProjectList();
      this.getSetLabel()
    },

    methods: {
      //项目标签

      useTag(item) {
        this.setProject.projectId = item.id;
        this.dialogAppTagVisible = true;
        $http.get($http.api.project.project_project_set_list,{id:item.id}).then(res => {
          this.setProject.projectSetIdList = res.data;
        })
      },
      bindAppTag() {
        $http.post($http.api.project.project_config, { projectSetIdList: this.setProject.projectSetIdList, projectId: this.setProject.projectId }).then(res => {
          if (res.status === 200) {
            this.dialogAppTagVisible = false;
            if (this.TagNameInfo.active !==1 && this.TagNameInfo.active !==2) {
              $http.get($http.api.project.project_set_list, { projectSetId: this.id }).then(res => {
                this.projectListData = res.data;
                this.showPage = false;
                // this.projectStatusData.filterInfo.pageInfo = res.data.pageInfo;
              })
            }
          }
        })
      },
      handleSetAppTagDialogClose() {
        this.dialogAppTagVisible = false;
      },
      getSetLabel() {
        $http.get($http.api.project.project_list).then(res => {
          this.totalTagList = res.data;
          this.projectStatusData.filterInfo.pageInfo.totalPages = 0;
        })
      },
      getLabelList(id) {
        this.id = id;
        this.TagNameInfo.active = id;
        $http.get($http.api.project.project_set_list, { projectSetId: id }).then(res => {
          this.projectListData = res.data;
          this.showPage = false;
          // this.projectStatusData.filterInfo.pageInfo = res.data.pageInfo;
        })
      },
      saveOrUpdateTag() {
        if (!this.TagNameInfo.inputTagName || this.TagNameInfo.inputTagName.length === 0) {
          this.$message({
            message: "请输入标签名",
            type: "warning"
          });
          return;
        }
        if (this.TagNameInfo.inputTagName.length > 20) {
          this.$message({
            message: "输入的标签名过长",
            type: "warning"
          });
          return;
        }

        if (this.inputTagId) {
          $http.post($http.api.project.project_set_update, {
            id: this.inputTagId,
            name: this.TagNameInfo.inputTagName,
          }).then((res) => {
            if (res.status === 200) {
              this.$message({
                type: 'success',
                message: '修改标签成功'
              });
              this.closeTagEditDialog();
              this.getSetLabel();
            } else {
              this.$message({
                type: 'error',
                message: res.msg
              });
            }

          })
        } else {
          $http.post($http.api.project.project_set_create, { name: this.TagNameInfo.inputTagName }).then((res) => {
            if (res.status !== 200) {
              this.$message({
                type: 'error',
                message: res.msg
              });
            } else {
              this.$message({
                type: 'success',
                message: '添加标签成功'
              });
              this.closeTagEditDialog();
              this.getSetLabel();
            }
          }).catch(() => {
            this.$message({
              type: 'error',
              message: '添加标签失败'
            });
          });
        }
      },
      //删除标签
      showDelTagDialog(tag) {
        this.$confirm('此操作删除该标签[' + tag.name + '], 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.project.project_set_delete, { id: tag.id }, { type: "form" }).then((res) => {
            if (res.status === 200) {
              this.$message({
                type: 'success',
                message: '删除成功!'
              });
              this.projectStatusData.filterInfo.completed = false;
              this.TagNameInfo.active = 1;
              this.getProjectList();
              this.getSetLabel();
            } else {
              this.$message({
                type: 'error',
                message: res.msg
              });
            }
          });
        }).catch(() => {
        });
      },
      //小弹窗编辑标签
      showEditTagDialog(tag) {
        this.height_a = 'editBtn';
        this.TagNameInfo.tapTitle = '编辑标签';
        this.dialogVisible_a = true;
        this.TagNameInfo.inputTagName = tag.name;
        // this.TagNameInfo.inputTagType = tag.type;
        this.inputTagId = tag.id;
      },
      //添加标签(小弹窗)
      showCreateTagDialog() {
        this.inputTagId = null;
        this.TagNameInfo.inputTagName = '';
        // this.TagNameInfo.inputTagType = 0;
        // this.height_a = 'addTop';
        this.TagNameInfo.tapTitle = '创建标签';
        this.dialogVisible_a = true;
      },
      //点击取消按钮关闭标签管理弹窗
      closeTagEditDialog() {
        this.dialogVisible_a = false;
      },
      //标签管理
      addTapsBtn() {
        this.dialogVisibleTab = true;
      },
      //关闭标签弹窗
      handleClose() {
        this.dialogVisibleTab = false;
      },

      intentDemandList(data) {
        let projectId = data.id;
        this.goToPage(this, "requirementList", { projectId });
      },
      getProjectList() {
        $http.post($http.api.project.projectListPageination, { ...this.projectStatusData.filterInfo }).then(res => {
          this.projectListData = res.data.results;
          this.projectStatusData.filterInfo.pageInfo = res.data.pageInfo;
        });
        // $http.get($http.api.project.projectList).then(res => {
        //   this.projectListData = res.data;
        // });
      },
      // 创建项目
      createProject() {
        this.flag = 'creat';
        this.dialogVisible = true;
      },
      // 编辑项目
      editProject(info) {
        this.flag = 'edit';
        this.dialogVisible = true;
        this.editProjectId = info.id;
        this.projectInfo.name = info.name;
        this.projectInfo.description = info.description;
      },
      // 取消创建取消编辑
      handleCloseProject() {
        // this.$refs["projectInfo"].resetFields();
        this.projectInfo.name = "";
        this.projectInfo.description = "";
        this.dialogVisible = false;
      },
      // 编辑或创建项目确定
      submitProject() {
        this.$refs["projectInfo"].validate(valid => {
          if (valid) {
            if (this.flag == "creat") {
              $http.post($http.api.project.coop_project_create, this.projectInfo).then(res => {
                if (res.status === 200) {
                  this.getProjectList();
                  this.handleCloseProject();
                  $utils.getUserInfo();
                  this.$message({ message: res.msg || "创建项目成功", type: "success" });
                } else {
                  this.$message({ message: res.msg || "创建项目失败", type: "error" });
                }
              });
            } else if (this.flag == "edit") {
              $http.post($http.api.project.coop_project_update, {
                ...this.projectInfo,
                id: this.editProjectId,
                projectId: this.editProjectId
              }).then(res => {
                if (res.status === 200) {
                  this.getProjectList();
                  this.handleCloseProject();
                  this.$message({ message: res.msg || "更新项目成功", type: "success" });
                } else {
                  this.$message({ message: res.msg || "更新项目失败", type: "error" });
                }
              });
            }
          }
        });
      },
      // 过滤器切换
      shortcutClick(bool = false) {
        this.showPage = true;
        if (bool) {
          this.TagNameInfo.active = 2;
        } else {
          this.TagNameInfo.active = 1;
        }
        this.projectStatusData.filterInfo.completed = bool;
        this.projectStatusData.filterInfo.pageInfo.pageNumber = 1;
        this.$nextTick(this.getProjectList)
      },
      // 分页
      pagainationChange(num) {
        this.projectStatusData.filterInfo.pageInfo.pageNumber = num
        this.$nextTick(this.getProjectList)
      },
      // 操作前的确认
      async confirmBeforeOperate(text = '') {
        let result = null
        try {
          result = await this.$confirm(text, {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: 'warnint'
          })
        } catch (_) {
          result = false;
        }
        return result;
      },
      // 结束项目
      async endProject(info) {
        const confirmResult = await this.confirmBeforeOperate(`确认结束项目-${info.name}-吗？结束项目后不允许再创建需求、任务、迭代、缺陷等功能`);
        if (!confirmResult) { return false; }
        this.loading = true;
        const result = await $http.get($http.api.project.complete_project, {
          id: info.id,
          projectId: info.id
        })
        this.loading = false;
        if (result.status === 200) {
          this.$message({ message: result.msg || "结束成功", type: 'success' })
          this.getProjectList();
        } else {
          this.$message({ message: result.msg || "结束失败", type: 'error' })
        }
      },
      // 删除项目
      async deleteProject(info) {
        const confirmResult = await this.confirmBeforeOperate(`确认删除项目-${info.name}-吗？`);
        if (!confirmResult) { return false; }
        this.loading = true;
        const result = await $http.get($http.api.project.coop_project_delete, {
          id: info.id,
          projectId: info.id
        })
        this.loading = false;
        if (result.status === 200) {
          this.$message({ message: result.msg || "删除成功", type: 'success' })
          this.pagainationChange(1);
        } else {
          this.$message({ message: result.msg || "删除失败", type: 'error' })
        }
      }
    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  .header-filter-btn-box {
    float: left;
    margin: 22px 0 0 -10px;
    /* height: 22px; */
    line-height: 30px;
    .header-filter-btn {
      margin-left: 10px;
      font-size: 14px;
      cursor: pointer;
      display: inline-block;
    }
  }

  .opreatebtns {
    span {
      display: inline-block;
      padding: 0 2px;
      color: #2196F3;
      cursor: pointer;

      &:hover {
        color: #0880e0;
      }
    }
  }

  // 分页
  .table-box-footer {
    margin-top: 10px;
    margin-right: calc(10% - 5px);
  }

  @media only screen and (max-width: 1500px) {
    .table-box-footer {
      margin-right: calc(5% - 5px);
    }
  }

  .addtap {
    position: relative;
    top: -8px;
  }
</style>