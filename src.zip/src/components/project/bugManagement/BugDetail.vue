<template>
  <div @click="editTime($event,false)" class="detail-content bug-content-box" ref="bugContentBox"
    :class="{'detail-content-show':detailType==='show'}" v-if="!isAbnormity"
    v-loading="loadingStatus.bugDetailLoading||loadingStatus.basicLoading" element-loading-text="拼命加载中"
    element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
    <slide :show="show" @click.stop ref="side" :afterClose="contextmenuNone"
      :beforeClose="({cb}) => beforeSliderClose({ id: -1, cb })" v-loading="loading" element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading" element-loading-background="rgb(255,255,255)">
      <div slot="task" class="silder-box">
        <new-view @refeshBug="refeshBug" v-if="show && projectId" v-on:HandleSide="contextmenuNone"
          :requireContent="detailInfo.display.content" :requireTitle="detailInfo.display.title"
          :titleNotice.sync="sliderBeforeCloseData.title" :descNotice.sync="sliderBeforeCloseData.desc"
          :bugTorequirement="true" :restore="restore" :projectId="projectId" :projectTitleName="projectName"
          :defectId="detailInfo.id"></new-view>
      </div>
    </slide>
    <div class="slide-header" v-if="detailType==='editable'">
      <span class="taskinfo-title">新建缺陷</span>
      <div class="slide-header-right">
        <el-button-group>
          <el-button type="default" class="slider-header-btn" @click="bugCreate">保存</el-button>
          <el-button type="default" icon="el-icon-close" @click="bugClose"></el-button>
        </el-button-group>
      </div>
    </div>
    <!-- 如果是从右侧滑入，则需要展示 缺陷详情 header -->
    <div class="slide-header" v-if="isSlider">
      <span class="taskinfo-title">缺陷详情</span>
      <div class="slide-header-right">
        <el-button class="close-slide-btn" type="default"
          v-show="authFunction('FUNC_COOP_REQUIRE_BUGTRANSFORMATION', 3, getUrlParams().projectId || projectId)"
          @click="bugToRequirement()">
          转需求
        </el-button>
        <el-button class="close-slide-btn" type="default"
          v-show="authFunction('FUNC_COOP_DEFECT_DELETE', 3, getUrlParams().projectId || projectId)" @click="deleteBug">
          删除
        </el-button>
        <el-button class="close-slide-btn" type="default" icon="el-icon-close" @click="()=>{this.$emit('detailClose')}">
        </el-button>
      </div>
    </div>

    <el-row :gutter="10" class="detail-content-body">
      <el-col :xs="16" :sm="16" :md="16" :lg="16" :xl="18">
        <div class="detail-content-left">
          <!-- 标题 -->
          <div class="detail-content-header" :class="{'detail-content-header-inactive':detailType==='editable'}"
            style="padding-left:0;">
            <span v-if="statusObject.titleInputShowActiveStatus==='inactive' && detailType==='show'"
              class="detail-content-header-id">#{{detailInfo.id}}</span>
            <ellipsis-block :value="detailInfo.display&&detailInfo.display.title || ''"
              v-if="statusObject.titleInputShowActiveStatus==='inactive' && detailType==='show'"
              class="editable-field title-input-inactive"
              @click="showActiveStatusControl('titleInputShowActiveStatus', 'active')"></ellipsis-block>
            <span class="edit-box-bug-help-btn c-blue"
              v-if="!isSlider&&authFunction('FUNC_COOP_DEFECT_DELETE', 3, getUrlParams().projectId || projectId)"
              @click="deleteBug">删除</span>
            <span class="edit-box-bug-help-btn c-blue" style="margin-right: 45px;" @click="bugToRequirement()"
              v-if="!isSlider"
              v-show="authFunction('FUNC_COOP_REQUIRE_BUGTRANSFORMATION', 3, getUrlParams().projectId)">转需求</span>
            <!-- <span v-show="statusObject.titleInputShowActiveStatus==='inactive' && detailType==='show'"
              class="editable-field title-input-inactive cursor-pointer ellipsis"
              @click="showActiveStatusControl('titleInputShowActiveStatus', 'active')">{{detailInfo.display&&detailInfo.display.title}}</span> -->
            <el-input v-show="statusObject.titleInputShowActiveStatus==='active' || detailType==='editable'"
              ref="titleInput" class="title-input-active" placeholder="输入标题" size="large"
              @change="CHECKBEFORETITLEUPDATE('titleInputShowActiveStatus', 'inactive')"
              @blur="CHECKBEFORETITLEUPDATE('titleInputShowActiveStatus', 'inactive')" @input="titleInput"
              v-model="detailInfo.display.title"></el-input>
            <div v-if="warningStatusTitle" class="warning warning-title">标题过长，请注意！！！</div>
          </div>
          <div class="creat-title" v-if="detailInfo.display.createUser">
            <span>{{`${detailInfo.display.createUser}(${detailInfo.createUser}) `}}</span>创建于
            <span>{{detailInfo.createTime}}</span>
          </div>
          <div class="detail-content-left-content"
            :class="{'detail-content-left-content-inactive': statusObject.bugDescShowActiveStatus==='inactive' && detailType==='show'}"
            refs="bshaow">
            <!-- 缺陷描述 -->
            <div :class="{'edit-fullscreen': statusObject.fullScreen}">
              <span v-show="detailType==='show'" class="edit-box-bug-help-btn"
                :class="{'edit-box-bug-help-btn-save':statusObject.bugDescShowActiveStatus==='active'}"
                @click="showActiveStatusControl('bugDescShowActiveStatus', bugDescShowActiveStatusValue)">{{statusObject.bugDescShowActiveStatus==='inactive'?'编辑描述':'保存'}}</span>
              <span class="edit-box-bug-help-btn" style="right:75px;"
                @click="fullScreen">{{!statusObject.fullScreen ?'全屏':'正常'}}</span>
              <span v-show="detailType==='show' && statusObject.bugDescShowActiveStatus==='active'"
                class="edit-box-bug-help-btn-cancel" @click="editCancel">取消</span>
              <!-- <div v-show="statusObject.bugDescShowActiveStatus==='inactive' && detailType==='show'"
              class="edit-box-bug-inactive" v-html="detailInfo.display.content"></div> -->
              <show-larger v-show="statusObject.bugDescShowActiveStatus==='inactive' && detailType==='show'"
                :value="detailInfo.display.content"> </show-larger>
              <tiny-mce v-if="statusObject.bugDescShowActiveStatus==='active' || detailType==='editable'"
                :value="detailInfo.display.content" v-on:watch="editHnadle($event)" :minHeigt='minHeight'></tiny-mce>
            </div>
          </div>
          <div class="detail-content-left-assoc">
            <!-- 关联工作项 -->
            <div class="bug-assoc-header">
              <span class="title-common">关联工作项</span>
              <el-button type="text fr" v-show="authFunction('FUNC_COOP_WORKITEM_ASSOC', 0)" @click="modalStatusChange">
                添加关联</el-button>
            </div>
            <div class="bug-assoc-body"
              v-if="assocObject.requirements.length > 0 || assocObject.tasks.length > 0 || assocObject.defects.length > 0">
              <div class="bug-assoc-item" v-for="item in assocObject.requirements" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'requirement')">{{item.id}}-需求-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'requirement')">
                  <i class="el-icon-delete"></i>
                </span>
              </div>
              <div class="bug-assoc-item" v-for="item in assocObject.tasks" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'task')">{{item.id}}-任务-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'task')">
                  <i class="el-icon-delete"></i>
                </span>
              </div>
              <div class="bug-assoc-item" v-for="item in assocObject.defects" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'defect')">{{item.id}}-缺陷-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'defect')">
                  <i class="el-icon-delete"></i>
                </span>
              </div>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6">
        <div class="detail-content-right">
          <!-- 基本信息 -->
          <div class="bug-basic-info">
            <p class="bug-basic-info-title">基本信息
            </p>
            <bug-detail-basic-info :projectId="projectId" :detailType="detailType" :bugUpdate="bugUpdate" :detailInfo="detailInfo" 
              @showActiveStatus="showActiveStatus" v-model="basicInfoObj" @basicFun="basicFun"></bug-detail-basic-info>
          </div>
          <!-- 附件上传部分-->
          <div class="bug-attachment">
            <p class="bug-attachment-title">
              附件
              <span class="bug-attachment-title-btn"
                @click="fileUpdaloadBoxStatusHandle">{{fileUpdaloadBoxStatus?'收起上传':'展开上传'}}</span>
            </p>
            <file-upload :fileUpdaloadBoxStatus="fileUpdaloadBoxStatus" :uploadedFileList="uploadedFileList"
              :handleFileDelete="handleFileDelete" :detailInfoId="detailInfo.id"
              :handleUploadSuccess="handleUploadSuccess" workItemType="3"></file-upload>
          </div>
        </div>
      </el-col>
    </el-row>
    <div class="detail-content-footer" v-if="detailType==='show'">
      <!-- 状态流转、操作记录 -->
      <el-tabs v-model="statusObject.activeTagName" type="border-card">
        <el-tab-pane label="状态流转" name="status">
          <record-chain :data="statusRecordInfo.statusRecordList" :loadmoreCallback="StatusRecordLoadmoreCallback"
            :isMore="statusRecordInfo.statusRecordPageInfo.isMore"></record-chain>
        </el-tab-pane>
        <el-tab-pane label="操作记录" name="operate">
          <time-line :data="operateInfo.operateList" :loadmoreCallback="OperateLoadmoreCallback"
            :isMore="operateInfo.operatePageInfo.isMore"></time-line>
        </el-tab-pane>
        <el-tab-pane label="评论" name="comment">
          <comment-list workItemType="3" :workItemId="detailInfo.id " ref="comment" v-if="projectId && statusObject.activeTagName ==='comment'"
            :projectId=" projectId || this.getUrlParams().projectId"></comment-list>
        </el-tab-pane>
        <el-tab-pane label="代码提交" name="codeCommit">
          <code-commit v-if="detailInfo.id !== 0 && statusObject.activeTagName==='codeCommit'"
            :workItemId="detailInfo.id" :workItemType="3" :projectId="projectId||this.getUrlParams().projectId">
          </code-commit>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!-- 新建关闭前提示文字 -->
    <el-dialog title="提示" :visible.sync="noticeDialogInfo.noticeDialogStatus" width="30%" v-if="detailType==='editable'"
      :modal-append-to-body="false" :close-on-click-modal="false" :close-on-press-escape="false" :show-close="false"
      center>
      <span>{{noticeDialogInfo.noticeDialogMessage}}</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="beforeSliderCloseInEditableStatuCancel">取 消</el-button>
        <el-button type="primary" @click="beforeSliderCloseInEditableStatuOk">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 关联工作项 -->
    <assoc-work-item :projectId="projectId" v-if="projectId" :isShow="assocObject.modalStatu"
      :onClose="assocCloseCallback" :successCallback="assocSuccessCallback"></assoc-work-item>
    <!-- 二级状态选择、添加评论 -->
    <custom-status
      v-if="showStausObj.status"
      :statusHeight="showStausObj.statusHeight"
      :statusleft="showStausObj.statusleft"
      :projectId="projectId"
      :statusId="showStausObj.statusId"
      :workItemType="showStausObj.workItemType"
      :workItemId="showStausObj.workItemId"
      :statusShow="showStausObj.status"
      :parentInfo="showStausObj.parentInfo"
      @closeStatus="closeStatus"
      :updateData="bugUpdate"
    ></custom-status>
  </div>
</template>

<script>
  /**
   * @title 缺陷详情模块
   * @desc 状态：展示、编辑
   * @desc 展示：此刻可以编辑单个表单项、基本信息展示提出人和创建时间、展示底部状态及操作记录信息 (普通导航)、有编辑按钮
   * @desc 编辑：所有字段纯编辑状态(新建、编辑、其他页面调用)
   * @desc 说明：没有把代码很长的基本信息拿出去，因为在其他地方也使用到了 bugDetail 这个组件，不方便组织，这里暂且就放在这里 - 2019.4.21
   * @function 功能支持-基本信息：固定字段 + 自定义字段，其中固定字段只有 select 一种类型，如果需要 input 类型，需要增加开发，自定义字段支持 select 和 input 2种类型
   * @author heyunjiang
   * @date 2019-3-6
   */
  import editor from "@/components/tool/markedit";
  import FieldEdit from "@/components/tool/FieldEdit";
  import RecordChain from "@/components/tool/RecordChain";
  import TimeLine from "@/components/tool/TimeLine";
  import FileUpload from "@/components/commonComponents/FileUpload";
  import CommentList from "@/components/commonComponents/CommentList";
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import BugMixin from "./BugMixin";
  import BugCustomFieldsMixin from "./BugCustomFieldsMixin";
  import ProjectCommonMixin from "../ProjectCommonMixin";
  import BugDetailBasicInfo from "./BugDetailBasicInfo";
  import AssocWorkItem from "./AssocWorkItem";
  import CommentForStatus from "./CommentForStatus";
  import TinyMce from "components/tool/tinymce";
  import CodeCommit from "@/components/commonComponents/CodeCommit";
  import ShowLarger from "@/components/commonComponents/ShowLarger";
  import slide from "@/components/tool/slideSlip";
  import NewView from '../requirement/newrequirementView.vue';
  // 缺陷默认初始信息
  const resetInit = {
    content: "",
    statusId: "", // id
    cause: "", // id
    display: {
      stage: 0,
      cause: "",
      title: "",
      content:
        "",
      priority: "一般",
      biz: "",
      createUser: "",
      sprint: "",
      status: "",
      assignUser: "",
      functionCharacter: "",
      source: "",
      reproduceProbability: "",
      detail: {
        status: {},
        priority: {}
      }
    },
    sprintId: "", // id
    createUser: "", // id
    contentId: 0,
    assignUser: "", // id
    createTime: "",
    title: "",
    priority: 80, // id
    functionCharacter: 0,
    source: 0,
    reproduceProbability: 0,
    status: {
      statusId: 0,
      statusName: "",
      end: false
    },
    id: -3
  };
  const bugWorkTtemType = 3;

  export default {
    name: "BugDetail",
    components: {
      editor,
      FieldEdit,
      RecordChain,
      TimeLine,
      AssocWorkItem,
      FileUpload,
      CommentForStatus,
      CommentList,
      TinyMce,
      CodeCommit,
      ShowLarger,
      slide,
      NewView,
      BugDetailBasicInfo
    },
    mixins: [BugMixin, BugCustomFieldsMixin, ProjectCommonMixin, TinymceSaveMixin],
    props: {
      projectId: {
        type: [String, Number],
        required: true
      },
      //获取过滤时详情
      buginfoData: {
        type: Array,
        required: false,
      },
      //当前 bug 详情，可选，但是不能再 detailType 为 show 时不传
      activeBugInfo: {
        type: Object,
        required: false,
        default: function () {
          return resetInit;
        }
      },
      // 当前组件状态， show -> 展示， editable -> 新建
      detailType: {
        type: String,
        required: true,
        validator: function (value) {
          return ["show", "editable"].indexOf(value) !== -1;
        }
      },
      // 关闭处理函数 - 如果位于滑块内部，则是关闭时的回调函数
      rightSliderHandle: {
        type: Function,
        required: false,
        default: () => {
          return () => {}
        }
      },
      // 新建、更新成功之后回调函数
      operateCallback: {
        type: Function,
        required: false
      },
      // 点击关联工作项的回调函数 assocClickCallback(info, type) ，info 为简要信息, type 字段为 requirement | task | defect
      assocClickCallback: {
        type: Function,
        required: false
      },
      // 是否是滑框展示，并且 detailType === 'show'
      isSlider: {
        type: Boolean,
        required: false
      },
      // 是否需要更新数据了 - 关联工作项
      isReadyForUpdate: {
        type: Boolean,
        required: false,
        default: false
      },
      //区分是否列表视图
      listStatu: {
        type: Boolean,
        required: false,
        default: false
      }
    },
    data() {
      return {
        detailInfo: { ...resetInit }, // 与 props 不同，在这里是为了保存过程中的数据
        originalDetailInfo: {}, // 编辑前的历史数据，用于数据状态回滚，只在 detailType 为 show 的时候用到，因为 activeBugInfo 允许只传 id ，所以不能使用
        statusObject: {
          titleInputShowActiveStatus: "inactive", // 展示-标题输入栏状态变化
          bugDescShowActiveStatus: "inactive", // 展示-缺陷编辑状态变化
          activeTagName: "status", // 选项卡切换 operate status comment
          fullScreen: false,//是否全屏
          timeActive: false,//编辑关闭时间
        },
        // 已经上传的附件信息
        uploadedFileList: [],
        // 已经关联工作项
        assocObject: {
          requirements: [],
          tasks: [],
          defects: [],
          modalStatu: false // 模态框打开情况
        },
        // 状态流转数据信息
        statusRecordInfo: {
          statusRecordList: [],
          statusRecordPageInfo: {
            pageNum: 1,
            pageSize: 100,
            isMore: false
          }
        },
        // 操作记录数据信息
        operateInfo: {
          operateList: [],
          operatePageInfo: {
            pageNum: 1,
            pageSize: 10,
            isMore: false
          }
        },
        // loading 状态统一管理
        loadingStatus: {
          bugDetailLoading: false,
          basicLoading: false
        },
        // 上传附件框-展示/隐藏
        fileUpdaloadBoxStatus: true,
        // 已经填写信息判断提示框
        noticeDialogInfo: {
          noticeDialogStatus: false,
          noticeDialogMessage: "存在已经填写的内容，确定关闭？"
        },
        // 选择二级状态、评论 model
        CommentForStatusInfo: {
          isShow: false,
          statusInfo: {},
          onOk: this.bugStatusClickCallbackOnOk,
          onCancel: this.bugStatusClickCallbackOnCancel
        },
        // 更新评论列表-当值变化的时候，就会触发评论列表更新
        commentUpdata: true,
        comment: '',// 评论内容
        informant: "",//通知人
        loading: "",
        show: false,
        restore: "",
        projectName: "",
        count: 0,
        minHeight: null,//编辑器的初始高度
        // 状态流转
        showStausObj: {
          status: false,
        },
        // 基本信息字段
        basicInfoObj: {}
      };
    },
    computed: {
      // 缺陷描述状态控制
      bugDescShowActiveStatusValue: function () {
        return this.statusObject.bugDescShowActiveStatus === "inactive"
          ? "active"
          : "inactive";
      },
      // 是否是异常状态 - 包含情况：1.无 bug 信息或胡乱传的 bugId 2. 没有传 bugId
      isAbnormity: function () {
        if (this.detailInfo.id === resetInit.id && this.detailType === "show") {
          // this.bugClose();
          const slider = this.$parent.$el && this.$parent.$el.closest(".sider-right");
          if(slider) {
            slider.style.right = '-71%';
          }
          return true;
        }
        return false;
      },
      // 警告状态-标题
      warningStatusTitle: function () {
        return (
          this.detailInfo.display.title.length > 50 &&
          (this.statusObject.titleInputShowActiveStatus === "active" ||
            this.detailType === "editable")
        );
      }
    },
    watch: {
      //监听是否全屏 处理全屏幕状态下全滚动条问题
      statusObject: {
        handler(newInfo, oldInfo) {
          if (newInfo.fullScreen) {
            document.body.style.overflowY = 'hidden';
          } else {
            document.body.style.overflowY = '';
          }
        },
        deep: true
      },
      // 监听过滤之后信息
      buginfoData: {
        handler(newInfo, oldInfo) {
          if(newInfo){
            // this.detailInfo = newInfo[0]
          }
        },
        deep: true
      },
      // 切换缺陷 - 更新当前缺陷信息
      activeBugInfo: function (newInfo, oldInfo) {
        // props 数据检测
        if (!this.CHECKBEFOREENTER(newInfo, this.detailType)) {
          this.bugClose();
          return;
        }
        this.initData({ ...resetInit, ...newInfo });
        if(newInfo){
          this.detailInfo = newInfo
        }
      },
      // 更新缺陷附属内容
      isReadyForUpdate() {
        this.getAssocList(this.detailInfo);
      }
    },
    created: function () {
      // props 数据检测
      if (!this.CHECKBEFOREENTER(this.activeBugInfo, this.detailType)) {
        this.bugClose();
        return;
      }
      this.initData({ ...resetInit, ...this.activeBugInfo }); // 通过传入的缺陷简要信息(简要信息只要包含 id 则可)，获取详细信息
    },
    methods: {
      //获取过滤后的基本信息
      basicFun(val){

      },
      //编辑关闭时间
      editTime(e, val) {
        if (e.target.tagName === 'INPUT') {
          return false;
        }
        this.statusObject.timeActive = val;
        this.$nextTick(() => {
          if (this.statusObject.timeActive) {
            this.$refs.basicEndTime[0].focus()
          }
        })
      },
      //转需求使用到的关闭函数
      contextmenuNone(e) {
        if (this.show) {
          this.show = false;
          this.count = 0;
          this.restore = Math.random() * 10;
          this.newviewShow = true;
        }
        this.isShow = false;
      },
      //侧滑栏打开
      seeTaskHandle(data, e) {
        // data.id ? (this.viewShow = false) : (this.viewShow = true);
        // if (!data) {
        //   this.newviewShow = true;
        // }
        this.$nextTick(() => {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
          }, 500);
        });
        if (this.count === 0) {
          this.preID = data.id;
          this.show = !this.show;
          this.requireId = data.id;
          this.restore = Math.random() * 10;
          this.count++;
        } else {
          if (this.preID !== data.id) {
            this.preID = data.id;
            // this.show = !this.show;
            this.requireId = data.id;
            this.restore = Math.random() * 10;
          } else {
            this.restore = Math.random() * 10;
            this.preID = data.id;
            this.count = 0;
            this.show = !this.show;
            this.requireId = data.id;
          }
        }
        // console.log(this.detailInfo.display.content)
      },
      //bug转需求
      bugToRequirement() {
        this.seeTaskHandle("");
        // $http.get($http.api.bug_info.bug_transFormation, { defectId: this.detailInfo.id }).then(res => {
        //   console.log(res)
        // })
      },
      //为了传递给新建需求页面
      refeshBug() {
        this.$emit('refeshBug')
      },
      //删除缺陷
      deleteBug() {
        $http.get($http.api.bug_info.bug_delete, { id: this.detailInfo.id }).then(res => {
          if (res.status === 200) {
            this.$message({ type: 'success', message: '删除成功' });
            this.refeshBug()
            // this.operateCallback && this.operateCallback({});
          } else {
            this.$message({ type: 'error', message: res.msg });
          }
        })
      },
      //是否全屏
      fullScreen() {
        this.statusObject.fullScreen = !this.statusObject.fullScreen;
        if (this.statusObject.fullScreen) {
          this.minHeight = document.documentElement.clientHeight;
        } else {
          this.minHeight = null;
        }
      },
      // 提交评论
      onSubmitComment() {
        if (this.comment.trim() != "") {
          $http.post($http.api.comment.add, {
            workItemType: 3,
            workItemId: this.detailInfo.id,
            comment: this.comment.trim(),
            projectId: this.projectId
          }).then(res => {
            this.comment = "";
            this.commentUpdata = !this.commentUpdata; // 更新评论列表
          });
        }
      },
      //获取自定义模板内容
      queryDescTmpl() {
        $http.get($http.api.work_status_fow.descTmpl_query, { projectId: this.projectId, workItemType: 3 }).then((res) => {
          this.originalDetailInfo.display.content = res.data.template;
          this.$nextTick(() => {
            this.detailInfo.display.content = res.data.template;
          })
        })
      },
      // 传入参数数据检测
      CHECKBEFOREENTER(activeBugInfo, detailType) {
        if ((!activeBugInfo.id || activeBugInfo.id === resetInit.id) && detailType === "show") {
          return false;
        }
        return true;
      },
      // 标题变化检测
      CHECKBEFORETITLEUPDATE(key, value) {
        // 不能为空检测
        if (
          this.detailInfo.display.title.trim().length < 1 &&
          this.detailType === "show"
        ) {
          this.httpErrorHandle("标题不能为空");
          this.detailInfo.display.title = this.originalDetailInfo.display.title;
          return false;
        }
        // 没有改变检测
        if (
          this.detailInfo.display.title !== this.originalDetailInfo.display.title
        ) {
          this.showActiveStatusControl(key, value);
        } else {
          this.statusObject[key] = value;
        }
      },
      // 数据重置
      resetData(detailInfo) {
        // 1. 操作记录
        this.operateInfo = {
          operateList: [],
          operatePageInfo: {
            pageNum: 1,
            pageSize: 10,
            isMore: false
          }
        };
        // 2. 状态流转
        this.statusRecordInfo = {
          statusRecordList: [],
          statusRecordPageInfo: {
            pageNum: 1,
            pageSize: 100,
            isMore: false
          }
        };
        // 3. 缺陷编辑回到展示状态
        this.statusObject.bugDescShowActiveStatus = "inactive";
        // 4. 保存原始数据
        this.originalDetailInfo = {
          ...detailInfo,
          display: {
            ...detailInfo.display
          }
        };
        // 5. 设置缺陷默认详情
        this.detailInfo = {
          ...detailInfo,
          display: {
            ...detailInfo.display,
            title: ""
          }
        };
        // 6. 设置 projectId 基本信息初始值
        // if (this.detailType === "editable") {
        //   this.projectId = this.getUrlParams()["projectId"];
        // }
        // 7. 关联工作项
        this.assocObject = {
          requirements: [],
          tasks: [],
          defects: [],
          modalStatu: false
        };
        // 8. 附件信息
        this.uploadedFileList = [];
      },
      // 展示状态-标题、描述状态控制，更新标题、描述内容 - 这个函数设计的有点垃圾
      showActiveStatusControl(key, value) {
        this.statusObject[key] = value;
        if (key === "titleInputShowActiveStatus" && value === "active") {
          this.$nextTick(function () {
            this.$refs.titleInput.focus();
          });
        }
        if (value === "inactive") {
          // 更新数据
          switch (key) {
            case "titleInputShowActiveStatus":
              this.originalDetailInfo.display.title = this.detailInfo.display.title;
              this.bugUpdate("title", this.detailInfo.display.title);
              break;
            case "bugDescShowActiveStatus":
              let middleVal = this.detailInfo.display.content;
              this.detailInfo.display.content = middleVal;
              this.originalDetailInfo.display.content = middleVal;
              this.bugUpdate("content", middleVal);
              this.removeTinymceContent(this.detailInfo.id)
              break;
            default:
          }
        }
      },
      // 标题输入内容监听
      titleInput() {
        if (this.detailInfo.display.title !== this.originalDetailInfo.display.title) {
          this.$emit('update:titleNotice', true);
        } else {
          this.$emit('update:titleNotice', false);
        }
      },
      // 编辑器监听
      editHnadle(data) {
        this.detailInfo.display.content = data;
        if (data !== this.originalDetailInfo.display.content) {
          this.$emit('update:descNotice', true);
          this.saveTinymceContent({
            value: data,
            id: this.detailInfo.id,
            type: 'bug', // 需求、任务、缺陷
            isNew: this.detailType === 'editable' // 是否是新建
          })
        } else {
          this.removeTinymceContent(this.detailInfo.id)
          this.$emit('update:descNotice', false);
        }
      },
      // 编辑器点击取消
      editCancel() {
        this.detailInfo.display.content = this.originalDetailInfo.display.content;
        this.statusObject.bugDescShowActiveStatus = "inactive";
        this.$emit('update:descNotice', false);
        this.removeTinymceContent(this.detailInfo.id)
      },
      // 初始化 - 在 created 和 activeBugInfo 变化的时候才能调用的初始化方法
      initData(detailInfo) {
        // 数据重置
        this.resetData(detailInfo);
        this.getBugDetailInfo(detailInfo);
      },
      // 编辑器内容恢复
      async tinymceContentReset() {
        const exist = await this.isPreviousContentExist(this.detailInfo.id, 'bug', this.detailType === "editable", this.detailInfo.display.content);
        if (exist) {
          this.statusObject.bugDescShowActiveStatus = 'active';
          this.detailInfo.display.content = exist;
        }
      },
      // 1 获取缺陷详情 - detailInfo
      getBugDetailInfo(detailInfo = this.detailInfo) {
        if (this.detailType === "editable") {
          this.$nextTick(() => {
            this.tinymceContentReset();
            this.queryDescTmpl(); // 初始化时，恢复内容，应该在拿到模板信息之后，此刻没有问题，因为在用户确认的过程中已经拿到数据，如果网络慢了就会出现问题
          });
        }
        if (detailInfo.id === resetInit.id) {
          return;
        }
        this.loadingStatus.bugDetailLoading = true;
        $http
          .get($http.api.bug_info.bug_detail, {
            id: detailInfo.id
          })
          .then(result => {
            this.loadingStatus.bugDetailLoading = false;
            if (result.data == null) {
              this.detailInfo = resetInit;
              return false;
            }
            if (result.status === 200) {
              this.detailInfo = result.data;
              this.originalDetailInfo = {
                ...result.data,
                display: {
                  ...result.data.display
                }
              };
              this.tinymceContentReset();
              // this.projectId = result.data.projectId; // 此处更新全局 projectId
              this.getUploadedFileList(result.data);
              this.getBugStatusRecordList(result.data);
              this.getAssocList(result.data);
              setTimeout(() => {
                this.getBugOperateRecordList(result.data);
              }, 600);
            } else {
              this.detailInfo = resetInit;
              this.httpErrorHandle(result.msg);
            }
          });
      },
      // 2 新建缺陷 - 提交数据
      bugCreate() {
        if (this.detailInfo.display.title.trim().length < 1) {
          this.httpErrorHandle("标题不能为空");
          return;
        }
        // 新建的时候不传缺陷状态
        const { title, content } = this.detailInfo.display;
        const postObj = {
          title,
          content, // 缺陷描述
          ...this.basicInfoObj,
          projectId: this.projectId, // 项目id
          attachments: this.uploadedFileList.map(item => item.id), // 附件ID列表
          assoc: {
            requirements: this.assocObject.requirements.map(item => item.id),
            tasks: this.assocObject.tasks.map(item => item.id),
            defects: this.assocObject.defects.map(item => item.id)
          } // 关联项
        };
        // 保存上传设置的基本信息的 session 值
        sessionStorage.setItem("LASTBUGCREATE", JSON.stringify(postObj));

        $http.post($http.api.bug_info.new_bug_post, postObj).then(result => {
          if (result.status === 200) {
            this.$message({
              message: result.msg || "创建成功",
              type: "success"
            });
            this.resetData(resetInit);
            this.$emit('update:titleNotice', false);
            this.$emit('update:descNotice', false);
            this.$nextTick(() => {
              this.rightSliderHandle(false);
              this.removeTinymceContent(this.detailInfo.id)
              this.operateCallback && this.operateCallback();
            })
          } else {
            this.httpErrorHandle(result.msg || "创建失败");
          }
        });
      },
      // 2 新建时 - 关闭滑框前数据内容检测
      beforeSliderCloseInEditableStatu() {
        if (this.detailType === "editable") {
          this.$nextTick(async () => {
            let noticeTitle = '工作项';
            if (this.detailInfo.display.title.trim().length > 0) {
              noticeTitle += '标题';
            }
            if (this.detailInfo.display.content !== this.originalDetailInfo.display.content) {
              if (this.detailInfo.display.title.trim().length > 0) {
                noticeTitle += '和描述';
              } else {
                noticeTitle += '描述';
              }
            }
            if (this.detailInfo.display.title.trim().length > 0 || this.detailInfo.display.content !== this.originalDetailInfo.display.content) {
              const confirmResult = await this.confirmBeforeOperate(`${noticeTitle}已经填写/修改，请确认是否关闭`);
              if (!confirmResult) { return false; }
            }
            this.rightSliderHandle(false);
            this.removeTinymceContent(this.detailInfo.id)
          });
        } else {
          // 关闭
          this.rightSliderHandle(false);
          this.removeTinymceContent(this.detailInfo.id)
        }
      },
      // 2 新建时 - 关闭滑框前数据内容检测 - 确定关闭
      beforeSliderCloseInEditableStatuOk() {
        this.noticeDialogInfo.noticeDialogStatus = false;
        this.$emit('update:titleNotice', false);
        this.$emit('update:descNotice', false);
        this.resetData(resetInit);
        this.rightSliderHandle(false);
        this.removeTinymceContent(this.detailInfo.id)
      },
      // 2 新建时 - 关闭滑框前数据内容检测 - 取消关闭
      beforeSliderCloseInEditableStatuCancel() {
        this.noticeDialogInfo.noticeDialogStatus = false;
      },
      // 2 新建缺陷 - 点击关闭按钮
      bugClose() {
        this.beforeSliderCloseInEditableStatu();
      },
      // 3 更新缺陷 - 不包含附件、关联工作项
      bugUpdate(key, value, cb) {
        // if(key === 'content'){
        //   value = value.replace(/<br\s*\/?>/, "")
        // }
        this.statusObject.timeActive = false;
        if (this.detailType === "editable") {
          return;
        }
        let postObj;
        if (typeof key === "object") {
          // 支持传入多个
          postObj = {
            id: this.detailInfo.id,
            projectId: this.projectId, // 项目id
            ...key
          };
        } else {
          postObj = {
            id: this.detailInfo.id,
            projectId: this.projectId, // 项目id
            [key]: value
          };
        }

        $http
          .post($http.api.bug_info.update_bug_post, postObj)
          .then(result => {
            if (result.status === 200) {
              // 1 提示更新成功
              this.$message({
                message: result.msg || "更新成功",
                type: "success"
              });
              this.getBugDetailInfo();
              // 2 更新成功回调
              this.operateCallback && this.operateCallback();
              // 4 更新自定义字段 initValue initName
              key.cb&&key.cb();
              cb&&cb();
              // 6 更新状态流转、操作记录数据、评论
              // this.getBugStatusRecordList(this.detailInfo);
              // this.getBugOperateRecordList(this.detailInfo);
              this.commentUpdata = !this.commentUpdata;
              this.$emit('update:titleNotice', false);
              this.$emit('update:descNotice', false);
            } else {
              this.httpErrorHandle(result.msg || "更新失败");
            }
          })
          .catch(_ => console.log(_));
      },
      // 3 更新缺陷 - 状态变化 - 添加二级状态及评论
      bugStatusClickCallback(info, cb) {
        // 如果不需要评论
        if (!info.fields.present) {
          this.bugUpdate(info.updateName, info.key);
          cb(true);
        } else {
          // 如果需要评论
          this.CommentForStatusInfo = {
            isShow: true,
            statusInfo: { ...info },
            parentInfo: this.detailInfo,
            onOk: value => {
              this.bugStatusClickCallbackOnOk(value, cb);
            },
            onCancel: () => {
              this.bugStatusClickCallbackOnCancel(cb);
            }
          };
        }
      },
      // 3 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击确定
      bugStatusClickCallbackOnOk(value, cb) {
        this.CommentForStatusInfo.isShow = false;
        this.bugUpdate(value);
        cb(true);
      },
      // 3 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击取消
      bugStatusClickCallbackOnCancel(cb) {
        this.CommentForStatusInfo.isShow = false;
        cb(true);
      },
      // 4 文件上传 - 获取已经上传的文件列表
      getUploadedFileList(detailInfo) {
        if (detailInfo.id === resetInit.id) {
          return;
        }
        $http
          .post($http.api.attachment.query, {
            workItemId: detailInfo.id,
            workItemType: bugWorkTtemType,
            projectId: detailInfo.projectId
          })
          .then(result => {
            if (result.status === 200) {
              this.uploadedFileList = result.data.map(item => {
                return {
                  name: item.origName,
                  url: item.url,
                  createUser: item.display.createUser,
                  createUser: item.createTime,
                  size: item.size,
                  id: item.id
                };
              });
            } else {
              this.uploadedFileList = [];
            }
          });
      },
      // 4 文件上传 - 成功处理函数
      handleUploadSuccess(res) {
        this.uploadedFileList.push({
          name: res.data.origName,
          url: res.data.url,
          id: res.data.id
        });
        this.$message({
          message: "文件上传成功",
          type: "success"
        });
      },
      // 4 文件上传 - 文件删除
      handleFileDelete(file) {
        if (this.detailType === "editable") {
          // 新建状态
          this.uploadedFileList = this.uploadedFileList.filter(
            item => item.id !== file.id
          );
        } else {
          // 展示状态
          if (this.detailInfo.id === resetInit.id) {
            return;
          }
          $http
            .post($http.api.attachment.delete, {
              workItemId: this.detailInfo.id,
              workItemType: bugWorkTtemType,
              projectId: this.projectId,
              attachmentId: file.id
            })
            .then(result => {
              if (result.status === 200) {
                this.$message({
                  message: result.msg || "文件删除成功",
                  type: "success"
                });
                this.uploadedFileList = this.uploadedFileList.filter(
                  item => item.id !== file.id
                );
              } else {
                this.uploadedFileList = [];
                this.httpErrorHandle(result.msg || "文件删除失败");
              }
            });
        }
      },
      // 4 文件上传 - 上传框是否隐藏
      fileUpdaloadBoxStatusHandle() {
        this.fileUpdaloadBoxStatus = !this.fileUpdaloadBoxStatus;
      },
      // 5 状态流转记录 - 获取记录列表 - 排序是根据 id 排序，本该根据时间，但是时间同 id 是相同方向排序的
      getBugStatusRecordList(detailInfo) {
        if (detailInfo.id === resetInit.id) {
          return;
        }
        $http
          .get($http.api.bug_info.bug_status_list, {
            id: detailInfo.id,
            pageNum: this.statusRecordInfo.statusRecordPageInfo.pageNum,
            pageSize: this.statusRecordInfo.statusRecordPageInfo.pageSize,
            projectId: detailInfo.projectId
          })
          .then(result => {
            if (result.status === 200) {
              if (this.statusRecordInfo.pageNum === 1) {
                this.statusRecordInfo.statusRecordList = result.data.list.reverse();
              } else {
                // 需要去重
                let sessionList = [
                  ...this.statusRecordInfo.statusRecordList.reverse(),
                  ...result.data.list
                ];
                this.statusRecordInfo.statusRecordList = [
                  ...new Set(sessionList.map(item => item.id))
                ]
                  .sort((a, b) => b - a)
                  .map(item => {
                    let record = {};
                    for (let i = 0; i < sessionList.length; i++) {
                      if (sessionList[i].id === item) {
                        record = sessionList[i];
                        break;
                      }
                    }
                    return record;
                  })
                  .reverse();
              }
              this.statusRecordInfo.statusRecordPageInfo.isMore =
                result.data.total >
                this.statusRecordInfo.statusRecordPageInfo.pageNum *
                this.statusRecordInfo.statusRecordPageInfo.pageSize;
            } else {
              this.statusRecordInfo.statusRecordList = [];
              this.statusRecordInfo.statusRecordPageInfo.isMore = false;
            }
          });
      },
      // 5 状态流转记录 - 加载更多
      StatusRecordLoadmoreCallback() {
        if (!this.statusRecordInfo.statusRecordPageInfo.isMore) {
          return false;
        }
        this.statusRecordInfo.statusRecordPageInfo.pageNum =
          this.statusRecordInfo.statusRecordPageInfo.pageNum + 1;
        this.$nextTick(function () {
          this.getBugStatusRecordList(this.detailInfo);
        });
      },
      // 6 缺陷操作记录 - 获取记录列表
      getBugOperateRecordList(detailInfo) {
        if (detailInfo.id === resetInit.id) {
          return;
        }
        $http
          .get($http.api.bug_info.bug_operate_list, {
            workItemId: detailInfo.id,
            workItemType: bugWorkTtemType,
            pageNum: this.operateInfo.operatePageInfo.pageNum,
            pageSize: this.operateInfo.operatePageInfo.pageSize,
            projectId: detailInfo.projectId
          })
          .then(result => {
            // 用于拼接处理 - 如果请求还未完成，但是已经切换了bug，下一个bug的操作记录会包含上一个bug的操作记录
            if (detailInfo.id !== this.detailInfo.id) {
              return;
            }
            if (result.status === 200) {
              if (this.operateInfo.pageNum === 1) {
                this.operateInfo.operateList = result.data.list;
              } else {
                // 需要去重
                let sessionList = [
                  ...this.operateInfo.operateList,
                  ...result.data.list
                ];
                this.operateInfo.operateList = [
                  ...new Set(sessionList.map(item => item.id))
                ]
                  .sort((a, b) => b - a)
                  .map(item => {
                    let record = {};
                    for (let i = 0; i < sessionList.length; i++) {
                      if (sessionList[i].id === item) {
                        record = sessionList[i];
                        break;
                      }
                    }
                    return record;
                  });
                // this.operateInfo.operateList = [...this.operateInfo.operateList, ...result.data.list]
              }
              this.operateInfo.operatePageInfo.isMore =
                result.data.total >
                this.operateInfo.operatePageInfo.pageNum *
                this.operateInfo.operatePageInfo.pageSize;
            } else {
              this.operateInfo.operateList = [];
              this.operateInfo.operatePageInfo.isMore = false;
            }
          });
      },
      // 6 缺陷操作记录 - 加载更多
      OperateLoadmoreCallback() {
        if (!this.operateInfo.operatePageInfo.isMore) {
          return false;
        }
        this.operateInfo.operatePageInfo.pageNum =
          this.operateInfo.operatePageInfo.pageNum + 1;
        this.$nextTick(function () {
          this.getBugOperateRecordList(this.detailInfo);
        });
      },
      // 7 关联工作项-获取已经关联的列表
      getAssocList(detailInfo) {
        if (detailInfo.id === resetInit.id) {
          return;
        }
        this.assocItemGetHandle({
          workItemType: bugWorkTtemType,
          workItemId: detailInfo.id,
          projectId: detailInfo.projectId
        }).then(result => {
          if (result.status === 200) {
            this.assocObject.requirements = result.data.requirements;
            this.assocObject.tasks = result.data.tasks;
            this.assocObject.defects = result.data.defects;
          } else {
            this.assocObject.requirements = [];
            this.assocObject.tasks = [];
            this.assocObject.defects = [];
            this.httpErrorHandle(result.msg);
          }
        });
      },
      // 7 关联工作项-模态框打开
      modalStatusChange() {
        this.assocObject.modalStatu = true;
      },
      // 7 关联工作项-模态框点击关联回调
      assocSuccessCallback(key, result) {
        this.assocObject.modalStatu = false;
        let assocObjectKey = "requirements",
          targetWorkItemType = 1;
        switch (key) {
          case "requirement":
            assocObjectKey = "requirements";
            targetWorkItemType = 1;
            break;
          case "task":
            assocObjectKey = "tasks";
            targetWorkItemType = 2;
            break;
          case "bug":
            assocObjectKey = "defects";
            targetWorkItemType = 3;
            break;
        }
        let containsRepitDataArray = [
          ...this.assocObject[assocObjectKey],
          ...result
        ];
        let containsRepitDataArrayIds = [
          ...new Set(containsRepitDataArray.map(item => item.id))
        ];
        let data = containsRepitDataArrayIds.map(item => {
          return containsRepitDataArray.filter(jtem => jtem.id === item)[0];
        });
        this.assocObject[assocObjectKey] = data;
        // 如果是展示状态，则还需要提交数据 - result
        if (this.detailType === "show") {
          $http
            .post($http.api.requirement.assoc_require, {
              origWorkItemType: bugWorkTtemType,
              origWorkItemId: this.detailInfo.id,
              targetWorkItemType,
              targetWorkItemIds: result.map(item => item.id),
              projectId: this.projectId
            })
            .then(result => {
              if (result.status === 200) {
                this.$message({
                  message: result.msg || "添加关联工作项成功",
                  type: "success"
                });
              } else {
                this.httpErrorHandle(result.msg || "添加关联工作项失败");
              }
            });
        }
      },
      // 7 关联工作项-点击删除
      assocItemDelete(info, type) {
        this.$confirm("确认删除该关联?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            if (this.detailType === "editable") {
              // 新建状态
              this.assocObject[type + "s"] = this.assocObject[type + "s"].filter(
                item => item.id !== info.id
              );
            } else {
              // 展示状态
              let targetWorkItemType = "1";
              switch (type) {
                case "requirement":
                  targetWorkItemType = "1";
                  break;
                case "task":
                  targetWorkItemType = "2";
                  break;
                case "defect":
                  targetWorkItemType = "3";
                  break;
              }
              this.assocItemDeleteHandle({
                targetId: info.id,
                targetType: +targetWorkItemType,
                originId: this.detailInfo.id,
                originType: bugWorkTtemType,
                projectId: this.projectId
              }).then(result => {
                if (result.status === 200) {
                  this.$message({
                    message: result.msg || "关联项删除成功",
                    type: "success"
                  });
                  this.getAssocList(this.detailInfo);
                } else {
                  this.httpErrorHandle(result.msg || '关联项删除失败');
                }
              });
            }
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },
      // 7 关联工作项-模态框关闭
      assocCloseCallback() {
        this.assocObject.modalStatu = false;
        // this.getAssocList(this.detailInfo)
      },
      // last - 状态流转 - 计算
      offsetLeft(obj) {
        var tmp = obj.offsetLeft;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetLeft;
          val = val.offsetParent;
        }
        return tmp;
      },
      // last - 状态流转 - 计算
      offsetTop(obj) {
        var tmp = obj.offsetTop;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetTop;
          val = val.offsetParent;
        }
        return tmp;
      },
      // last - 状态流转 - 展示扭转状态
      showActiveStatus(e, item) {
        this.showStausObj.status = !this.showStausObj.status;
        if (this.showStausObj.status) {
          this.showStausObj.parentInfo = item;
          if (this.isSlider) {
            var pw = document.body.offsetWidth - document.getElementsByClassName("silder-box")[0].offsetWidth
            this.showStausObj.statusHeight = this.offsetTop(e.target) + 23 + 'px';
            this.showStausObj.statusleft = this.offsetLeft(e.target) - pw - 578 + 'px';
          } else {
            this.showStausObj.statusHeight = this.offsetTop(e.target) - 204 + 'px';
            this.showStausObj.statusleft = this.offsetLeft(e.target) - 680 + 'px';
          }
          this.showStausObj.statusId = item.statusId;
          this.showStausObj.workItemType = 3;
          this.showStausObj.workItemId = item.id;
        }
      },
      // last - 状态流转 - 关闭缺陷状态
      closeStatus() {
        this.showStausObj.status = false;
      }
    }
  };
</script>
<style lang="scss" scoped>
  @import "../ProjectCommon.scss";

  .edit-fullscreen {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    overflow: auto;
    background-color: white;
    z-index: 99999;
  }
</style>