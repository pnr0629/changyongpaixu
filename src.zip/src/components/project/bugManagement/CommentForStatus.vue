<template>
  <div @click.stop>
    <el-dialog
      :visible.sync="isShow"
      width="40%"
      title="状态流转信息填写"
      :show-close="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :append-to-body="true"
      :modal-append-to-body="true"
    >
      <div class="form-iterm-box">
        <el-form>
          <template v-for="item in attachFields">
            <el-form-item label="评论：" label-width="100px" v-if="item.key === 'comment'" :key="item.key">
              <el-input
                type="textarea"
                resize="vertical"
                :Rows="4"
                width="calc(100% - 60px)"
                placeholder="请输入评论内容"
                v-model="values.comment"
              ></el-input>
            </el-form-item>
            <el-form-item v-else-if="item.choice" :label="item.label+': '" label-width="100px" :key="item.key">
              <el-select v-model="values[item.key]" class="header-input">
                <el-option
                  v-for="jtem in item.selectValue"
                  :key="jtem.key"
                  :label="jtem.value"
                  :value="jtem.key"
                ></el-option>
              </el-select>
            </el-form-item>
            <el-form-item :label="item.label" label-width="60px" v-else :key="item.key">
              <el-input width="calc(100% - 60px)" v-model="values[item.key]"></el-input>
            </el-form-item>
          </template>
        </el-form>
      </div>
      <span v-if="loading">数据加载中</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="default" @click="onCancelClick">取消</el-button>
        <el-button type="success" @click="onSuccessClick">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 附件字段填选、评论添加
 * @function 获取/添加二次状态、添加评论
 * @author heyunjiang
 * @date 2019.4.10
 * @update 2019.5.23 从二级状态 -> 附加字段填选
 */

import BugCustomFieldsMixin from "./BugCustomFieldsMixin";

export default {
  name: "CommentForStatus",
  components: {},
  props: {
    isShow: {
      type: Boolean,
      required: true,
      desc: "模态框展示与否"
    },
    statusInfo: {
      type: Object,
      required: true,
      desc: "一级状态信息，内部包含需要展示的附加字段，数据从自定义字段接口拿取"
    },
    parentInfo: {
      type: Object,
      required: false,
      default: ()=> {
        return {}
      },
      desc: "状态对应的整体详细信息，用于拿附加字段的初始值"
    },
    onOk: {
      type: Function,
      required: true,
      desc: "信息添加回调"
    },
    onCancel: {
      type: Function,
      required: true,
      desc: "信息添加取消回调"
    }
  },
  mixins: [BugCustomFieldsMixin],
  data() {
    return {
      values: {}, // 绑定的值，点击ok，整体传递
      attachFields: [], // 附件字段，包含评论
      loading: false
    };
  },
  watch: {
    isShow() {
      if (this.isShow) {
        this.fieldInit();
      }
    }
  },
  methods: {
    // 字段初始化
    async fieldInit() {
      // 数据初始化
      this.attachFields = [];
      this.values = {comment: ""};
      this.loading = true;
      let result = await this.getCustomFiledInfo(this.parentInfo.projectId);
      this.loading = false;
      if(result.status !== 200 || result.data === null) {return false;}
      result = result.data;
      // 封装 this.attachFields 对象
      try {
        const required = this.statusInfo.fields.value.required; // 需要展示的字段集合
        const attachFields = [];
        required.forEach(item => {
          if(item === 'comment') {
            attachFields.push({
              key: item,
              label: '评论'
            })
            this.$set(this.values, 'comment', '')
          } else {
            if(result.def[item]) {
              attachFields.push({
                key: item,
                label: result.def[item].fieldName,
                choice: result.def[item].choice,
                selectValue: []
              })
              this.$set(this.values, item, this.parentInfo[item] || '')
            }
          }
        })
        // 获取预加载值
        attachFields.filter(item => item.choice).forEach(async item => {
          const result = await this.getPresetDataForSelect(item.key);
          item.selectValue = result.choices.map(jtem => {
            return {
              key: jtem.fieldValue,
              value: jtem.fieldDisplay,
              ...jtem
            }
          })
          this.$set(this.values, item.key, item.selectValue[0].key)
        })
        this.attachFields = attachFields
      } catch (_) {}
    },
    // 获取下拉框 select options 值
    async getPresetDataForSelect(fieldId) {
      const result = await this.getCustomFiledSelectList(fieldId, this.parentInfo.projectId);
      if(result.status === 200) {
        return result.data;
      }
      return [];
    },
    // 点击取消
    onCancelClick() {
      this.onCancel();
    },
    // 点击确定
    onSuccessClick() {
      let keys = Object.keys(this.values), statu = true;
      for(let i=0;i<keys.length;i++) {
        if(keys[i] === 'commit' && this.values.commit.trim().length===0) {
          this.$message({
            message: "请输入评论",
            type: "warning"
          });
          statu = false;
          break;
        } else if(!this.values[keys[i]]) {
          this.$message({
            message: this.attachFields.filter(item => item.key === keys[i])[0].label+"不能为空",
            type: "warning"
          });
          statu = false;
          break;
        }
      }
      if(!statu) {return false;}
      console.log(...this.values)
      this.onOk({ ...this.values, statusId: this.statusInfo.statusId});
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
