<template>
  <div class="bug-count-box">
    <div class="bug-count-item" v-for="(item, index) in headerCount" :key="index">
      <span class="bug-count-item-left cursor-pointer" :class="item.colorClass"
        @click="shortcutClick(item.key)">{{item.number}}</span>
      <span class="bug-count-item-right">
        <div class="bug-count-item-right-desc">{{item.descTop}}</div>
        <div class="bug-count-item-right-desc">{{item.descBottom}}</div>
      </span>
    </div>
  </div>
</template>
<script>
  /**
   * @title 缺陷顶部统计数据
   * @desc 
   * @author heyunjiang
   * @date 
   */
  export default {
    name: "HeaderCount",
    components: {},
    mixins: [],
    props: ['ONGOING', 'TODO', 'DONE', 'TOTAL', 'updateShortcutInfo'],
    data() {
      return {}
    },
    computed: {
      // 顶部统计数据
      headerCount() {
        return [
          {
            number: this.TOTAL && this.TOTAL.number || 0,
            colorClass: 'bug-count-item-color-total',
            descTop: '当前版本',
            descBottom: '个问题',
            key: 'toAll'
          },
          {
            number: this.DONE && this.DONE.number || 0,
            colorClass: 'bug-count-item-color-completed',
            descTop: '个问题',
            descBottom: '已完成',
            key: 'done',
          },
          {
            number: this.ONGOING && this.ONGOING.number || 0,
            colorClass: 'bug-count-item-color-fixing',
            descTop: '个问题',
            descBottom: '正在处理',
            key: 'ongIng',
          },
          {
            number: this.TODO && this.TODO.number || 0,
            colorClass: 'bug-count-item-color-waiting',
            descTop: '个问题',
            descBottom: '待处理',
            key: "toDo",
          }
        ]
      }
    },
    watch: {},
    created() { },
    mounted() {
      let key = this.getUrlParams().key;
      if (key) {
        this.select(key)
      }
    },
    methods: {
      // 快捷搜索点击
      shortcutClick(key, oldActive) {
        this.goToNewWindowPage(this, "bugList", { projectId: this.getUrlParams().projectId, key: key })
        // if (key === 'toAll') {
        //   this.updateShortcutInfo({
        //     done: false,
        //     ongIng: false,
        //     toDo: false,
        //   })
        // } else {
        //   this.updateShortcutInfo({
        //     done: false,
        //     ongIng: false,
        //     toDo: false,
        //     ...{ [key]: true }
        //   })
        // }
      },
      select(key) {
        this.updateShortcutInfo({
          done: false,
          ongIng: false,
          toDo: false,
          toAll: false,
          ...{ [key]: true }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  @import './BugCommon';

  // 顶部统计数据
  .bug-count-box {
    padding: 10px;
    margin-bottom: 10px;
    // border-bottom: 1px solid $color-border-bar;
    background-color: $color-mo-bg-common;

    .bug-count-item {
      display: inline-block;
      margin-right: 20px;
      padding: 0 5px;
      background-color: $color-mo-bg-weight;

      .bug-count-item-left {
        display: inline-block;
        min-width: 50px;
        height: 50px;
        line-height: 50px;
        font-size: 38px;
        padding-right: 5px;
        text-align: right;
        vertical-align: top;
      }

      .bug-count-item-right {
        display: inline-block;
        width: 60px;
        font-size: 14px;
        padding: 5px 0;

        .bug-count-item-right-desc {
          height: 20px;
          line-height: 20px;
        }
      }

      .bug-count-item-color-total {
        color: #475767;
      }

      .bug-count-item-color-completed {
        color: #4faa1a;
      }

      .bug-count-item-color-fixing {
        color: #45719e;
      }

      .bug-count-item-color-waiting {
        color: #ff0000;
      }
    }
  }
</style>