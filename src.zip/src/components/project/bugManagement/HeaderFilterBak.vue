<template>
  <div class="header-fiter-box-comon">
    <div class="header-filter-top-box">
      <!-- <el-button :class="{'active': item.isActive, 'inactive': !item.isActive, 'header-button-first': index === 0}"
        type="text" :key="item.name" v-for="(item, index) in filterButtons" @click="shortcutClick(item.key)">
        {{item.name}}</el-button> -->
      <el-form :inline="true" class="fontsize0">
        <el-form-item label="标题/ID" label-width="70px" class="header-filter-item">
          <el-input placeholder="标题/ID" class="header-filter-formitem-input" v-model="filterData.title"></el-input>
        </el-form-item>
        <el-form-item  class="header-filter-item">
          <el-select v-model="value7" placeholder="请选择过滤器">
            <el-option-group v-for="group in options3" :key="group.label" :label="group.label">
              <el-option v-for="item in group.options" :key="item.value" :label="item.label" :value="item.value"></el-option>
            </el-option-group>
          </el-select>
        </el-form-item>
        <el-form-item class="header-filter-item">
          <el-button type="primary" @click="filterClick">过滤</el-button>
          <!-- <el-button type="success" @click="()=>{$emit('bugExport')}">导出Excel</el-button> -->
          <el-button type="text" @click="filterChange">{{isFilterOpen?'收起':'展开'}}过滤器</el-button>
          <span class="header-button-more">
            <field-edit v-bind="FieldEditProps" v-if="isFilterOpen"></field-edit>
          </span>
        </el-form-item>
      </el-form>
      <el-button-group class="fr new-button">
        <el-button type="primary" v-show="authFunction('FUNC_COOP_DEFECT_CREATE', 3, getUrlParams().projectId)"
          @click="newBug((true))">新建缺陷</el-button>
        <el-button class="iconfontbtn" type="primary" @click="()=>{this.$emit('listStatuChange')}">
          <i class="iconfont icon-buglist" v-if="listStatu"></i>
          <i class="iconfont icon-buginfo" v-if="!listStatu"></i>
        </el-button>
      </el-button-group>
      <el-dropdown class="fr new-button">
            <el-button>导入/导出<i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_DEFECT_EXPORT', 3, getUrlParams().projectId || projectId)"><span
                  @click="()=>{$emit('bugExport')}">导出缺陷</span></el-dropdown-item>
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_DEFECT_EXCEL_MODEL', 3, getUrlParams().projectId || projectId)"><span
                  @click="dropdownBug">下载导入模板</span></el-dropdown-item>
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_DEFECT_EXCEL_INPUT', 3, getUrlParams().projectId || projectId)">
                <el-upload class="upload-demo" :action="importObject.importUrl" :data="importObject.importData"
                  :show-file-list="false" :on-success="uploadSuccess" multiple>
                  <span type="primary">导入缺陷</span>
                </el-upload>
              </el-dropdown-item>
            </el-dropdown-menu>
        </el-dropdown>
      
      <!-- <el-button type="primary" class="fr new-button" @click="newBug((true))">新建缺陷</el-button>
      <el-button type="primary" class="fr" @click="()=>{this.$emit('listStatuChange')}">切换到{{!listStatu?'列表':'详情'}}</el-button> -->
    </div>
    <div class="header-filter" :class="{'header-filter-hidden': !isFilterOpen}">
      <!-- 隐藏起来的过滤器 -->
      <el-form :inline="true" class="fontsize0">
        <el-form-item label="标题/ID" label-width="70px" class="header-filter-item">
          <el-input placeholder="标题/ID" class="header-filter-formitem-input" v-model="filterData.title"></el-input>
        </el-form-item>
        <el-form-item label="状态" label-width="70px" class="header-filter-item">
          <el-select placeholder="状态" multiple v-model="filterData.statusIds"
            @change="(value)=>{handleSelectChange(value, 'statusIds')}">
            <el-option label="全部" value="all">
              <span class="mini-circle" :style="{backgroundColor: 'transparent'}"></span>全部
            </el-option>
            <el-option :label="item.statusName" :value="item.statusId" v-for="(item, index) in dataList.statusList"
              :key="index">
              <span v-html="initNameStatus(item.color,item.statusName)"></span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="严重程度" label-width="70px" class="header-filter-item">
          <el-select placeholder="严重程度" multiple v-model="filterData.priorities"
            @change="(value)=>{handleSelectChange(value, 'priorities')}" :collapse-tags="false">
            <el-option label="全部" value="all">
              <span class="mini-circle" :style="{backgroundColor: 'transparent'}"></span>全部
            </el-option>
            <el-option :label="item.literal" :value="item.priority" v-for="(item, index) in dataList.prorityList"
              :key="index">
              <span v-html="initNameStatus(item.color,item.literal)"></span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="关联迭代" label-width="70px" class="header-filter-item">
          <sprint-multiple-select v-model="filterData.sprintIds" :selectAllInit="true" :panelWidth="200">
          </sprint-multiple-select>
          <!-- <el-select placeholder="关联迭代" multiple v-model="filterData.sprintIds"
            @change="(value)=>{handleSelectChange(value, 'sprintIds')}" :collapse-tags="false">
            <el-option label="全部" value="all"></el-option>
            <el-option :label="item.name" :value="item.id" v-for="(item, index) in dataList.sprintList" :key="index"></el-option>
          </el-select> -->
        </el-form-item>
        <el-form-item label="原因" label-width="70px" class="header-filter-item">
          <el-select placeholder="原因" multiple v-model="filterData.causes"
            @change="(value)=>{handleSelectChange(value, 'causes')}" :collapse-tags="false">
            <el-option label="全部" value="all"></el-option>
            <el-option :label="item.literal" :value="item.cause" v-for="(item, index) in dataList.causeList"
              :key="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="处理人" label-width="70px" class="header-filter-item">
          <el-select placeholder="处理人" multiple v-model="filterData.assignUsers"
            @change="(value)=>{handleSelectChange(value, 'assignUsers')}" :collapse-tags="false">
            <el-option value="search" disabled>
              <el-input placeholder="搜索" v-model="listFilter.assignUserFilter"></el-input>
            </el-option>
            <el-option label="全部" value="all"></el-option>
            <el-option :label="item.userName + '(' +item.userId + ')'" :value="item.userId"
              v-for="(item, index) in assignUserFilterList" :key="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建人" label-width="70px" class="header-filter-item">
          <el-select placeholder="创建人" multiple v-model="filterData.createUsers"
            @change="(value)=>{handleSelectChange(value, 'createUsers')}" :collapse-tags="false">
            <el-option value="search" disabled>
              <el-input placeholder="搜索" v-model="listFilter.createUserFilter"></el-input>
            </el-option>
            <el-option label="全部" value="all"></el-option>
            <el-option :label="item.userName + '(' +item.userId + ')'" :value="item.userId"
              v-for="(item, index) in createUserFilterList" :key="index"></el-option>
          </el-select>
        </el-form-item>
        <!-- 固定字段 -->
        <template v-for="item in fixedFieldValues">
          <el-form-item class="header-filter-item" :key="item.key">
            <span slot="label" class="header-filter-item-label">{{item.label}}</span>
            <el-select v-if="item.choice" multiple v-model="filterData[item.key + 's']"
              @change="(value)=>{handleSelectChange(value, item.key + 's', false)}" :collapse-tags="false">
              <el-option label="全部" value="all"></el-option>
              <el-option :label="jtem.fieldDisplay" :value="jtem.fieldValue"
                v-for="jtem in item.fieldEditProps.selectValue" :key="jtem.fieldValue"></el-option>
            </el-select>
            <el-input v-if="!item.choice" class="header-filter-formitem-input" :placeholder="item.label"
              v-model="filterData[item.key]"></el-input>
          </el-form-item>
        </template>
        <!-- 自定义字段 -->
        <template v-for="item in selectedCUSTOMFIELDVALUES">
          <el-form-item class="header-filter-item" :key="item.key">
            <span slot="label" class="header-filter-item-label">{{item.label}}</span>
            <el-select v-if="item.choice" multiple v-model="filterData.custom[item.key]"
              @change="(value)=>{handleSelectChange(value, item.key, true)}" :collapse-tags="false"
              @visible-change="(bool)=> bool&&getBasicCustomFiledSelectListOnClick(item.key)">
              <el-option label="全部" value="all"></el-option>
              <el-option :label="jtem.fieldDisplay" :value="jtem.fieldValue"
                v-for="jtem in item.fieldEditProps.selectValue" :key="jtem.fieldValue"></el-option>
            </el-select>
            <el-input v-if="!item.choice" class="header-filter-formitem-input" :placeholder="item.label"
              v-model="filterData.custom[item.key]"></el-input>
          </el-form-item>
        </template>
        <el-form-item class="header-filter-item">
          <el-button type="primary" @click="filterClick">过滤</el-button>
          <!-- <el-button type="success" @click="()=>{$emit('bugExport')}">导出Excel</el-button> -->
          <el-dropdown>
            <el-button>导入/导出<i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_DEFECT_EXPORT', 3, getUrlParams().projectId || projectId)"><span
                  @click="()=>{$emit('bugExport')}">导出缺陷</span></el-dropdown-item>
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_DEFECT_EXCEL_MODEL', 3, getUrlParams().projectId || projectId)"><span
                  @click="dropdownBug">下载导入模板</span></el-dropdown-item>
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_DEFECT_EXCEL_INPUT', 3, getUrlParams().projectId || projectId)">
                <el-upload class="upload-demo" :action="importObject.importUrl" :data="importObject.importData"
                  :show-file-list="false" :on-success="uploadSuccess" multiple>
                  <span type="primary">导入缺陷</span>
                </el-upload>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>

        </el-form-item>
      </el-form>
      <!-- <el-row :gutter="10" class="header-content-filter">
        <el-col :xs="16" :sm="16" :md="16" :lg="16" :xl="16">
        </el-col>
      </el-row> -->
    </div>
  </div>
</template>

<script>
  /**
  * @title 缺陷顶部过滤
  * @TODO 采用 FIELDOBJECT 代替 CUSTOMFIELD 字段
  * @author heyunjiang
  * @date 2019-3-4
  */
  import BugMixin from './BugMixin'
  import BugCustomFieldsMixin from './BugCustomFieldsMixin'
  import FieldEdit from "@/components/tool/FieldEdit"
  import ProjectCommonMixin from '../ProjectCommonMixin'
  import SprintMultipleSelect from "@/components/commonComponents/SprintMultipleSelect";

  export default {
    name: "HeaderFilter",
    components: {
      FieldEdit,
      SprintMultipleSelect
    },
    mixins: [BugMixin, BugCustomFieldsMixin, ProjectCommonMixin],
    props: {
      newBug: Function,
      updateFilterInfo: Function,
      updateShortcutInfo: Function,
      commonFilterInfo: Object,
      shortcutFilterInfo: Object,
      filterInfo: Object,
      listStatu: Boolean
    },
    data() {
      return {
        importObject: {
          importUrl: $http.api.bug_info.bug_import.url,
          importData: {
            projectId: this.getUrlParams().projectId
          }
        },
        isFilterOpen: false,
        // 过滤器下拉框可选择的值 - 部分固定字段，其他固定字段及自定义字段，是保存在 FIELDOBJECT 对象中的
        dataList: {
          statusList: [],
          prorityList: [],
          sprintList: [],
          causeList: [],
          assignUserList: [],
          createUserList: []
        },
        // 过滤器已经选择的信息
        filterData: {
          title: null,
          statusIds: [], // 缺陷状态列表
          priorities: [], // 缺陷优先级|严重程度
          sprintIds: [], // 关联迭代 id
          causes: [], // 缺陷原因列表
          assignUsers: [], // 指派人，即处理人
          createUsers: [], // 创建人
          custom: {}
        },
        selectedCUSTOMFIELD: [], // 当前选中的 CUSTOMFIELD 项
        selectedCUSTOMFIELDVALUES: [], // 当前选中的 CUSTOMFIELD 项的 value 数组
        // 扩展 element-select input 输入过滤选项
        listFilter: {
          assignUserFilter: '', // 处理人
          createUserFilter: '' // 创建人
        }
      }
    },
    computed: {
      filterButtons() {
        return [
          { name: '全部', key: 'all', isActive: !Object.values(this.shortcutFilterInfo.shortcut).includes(true) },
          { name: '我创建', key: 'created', isActive: this.shortcutFilterInfo.shortcut.created },
          { name: '指派给我', key: 'assigned', isActive: this.shortcutFilterInfo.shortcut.assigned },
          { name: '待我解决', key: 'toSolve', isActive: this.shortcutFilterInfo.shortcut.toSolve },
          { name: '待我验证', key: 'toAccept', isActive: this.shortcutFilterInfo.shortcut.toAccept },
        ]
      },
      projectId() {
        return this.commonFilterInfo.projectId
      },
      FieldEditProps() {
        return {
          initValue: this.selectedCUSTOMFIELD,
          initName: `<button type="button" class="el-button el-button--text" style="padding-left: 0 !important">更多<i class="el-icon-caret-bottom"></i></button>`,
          selectValue: Object.keys(this.FIELDOBJECT.CUSTOM).map(item => { return { key: item, value: this.FIELDOBJECT.CUSTOM[item].label } }),
          onChange: this.setSelectedCUSTOMFIELD,
          localSearch: true,
          showOuterBorder: false,
          multiple: true
        }
      },
      // 固定字段的 values 数组
      fixedFieldValues() {
        this.getFixedFileds();
        return Object.values(this.FIELDOBJECT.FIXED)
      },
      // 处理人
      assignUserFilterList() {
        if (this.listFilter.assignUserFilter.trim().length === 0) { return this.dataList.assignUserList }
        return this.dataList.assignUserList.filter(item => {
          filterData
          return (item.userName + '(' + item.userId + ')').indexOf(this.listFilter.assignUserFilter.trim()) !== -1
        })
      },
      // 创建人
      createUserFilterList() {
        if (this.listFilter.createUserFilter.trim().length === 0) { return this.dataList.createUserList }
        return this.dataList.createUserList.filter(item => {
          return (item.userName + '(' + item.userId + ')').indexOf(this.listFilter.createUserFilter.trim()) !== -1
        })
      }
    },
    watch: {
      filterInfo(value) {
        this.filterInit();
        // this.filterClick();
      },
      // 当更多里选择的值变化时，更新 selectedCUSTOMFIELDVALUES 字段 - 自定义字段
      selectedCUSTOMFIELD() {
        let values = []
        // 先清除未选中的自定义过滤字段 custom
        Object.keys(this.filterData.custom).forEach(item => {
          if (!this.selectedCUSTOMFIELD.includes(item)) {
            this.$delete(this.filterData.custom, item)
          }
        })
        // 增加过滤字段
        this.selectedCUSTOMFIELD.forEach(item => {
          // 增加节点
          values.push(this.FIELDOBJECT.CUSTOM[item])
          // 如果已经设置了 custom，则忽略
          if (this.filterData.custom[item]) { return true }
          // 如果没有设置，则增加 custom
          this.$set(this.filterData.custom, item, this.FIELDOBJECT.CUSTOM[item].choice ? ['all'] : null)
        })
        this.selectedCUSTOMFIELDVALUES = [...values]
      }
    },
    created() {
      this.filterInit();
    },
    mounted() {
      setTimeout(() => {
        if (this.getUrlParams().key) {
          this.filterClick()
        }
      },300)
    },
    methods: {
      uploadSuccess(res) {
        if (res.status === 200) {
          this.$message({ type: 'success', message: '上传成功' })
          this.$emit('refeshBug')
        } else {
          this.$message({ type: 'error', message: res.msg })
        }

      },
      //下载缺陷模板
      dropdownBug() {
        let projectId = this.getUrlParams().projectId;
        let url = $http.api.bug_info.bug_model.url + '?projectId=' + projectId
        window.open(url, '_blank');
      },
      filterInit() {
        this.updateFilterData();
      },
      // 增加固定字段 - filterData key
      getFixedFileds() {
        Object.keys(this.FIELDOBJECT.FIXED).forEach(item => {
          const isChoice = this.FIELDOBJECT.FIXED[item].choice;
          const key = isChoice ? (item + 's') : item;
          const value = isChoice ? ((!this.filterInfo[key] || this.filterInfo[key].length === 0) ? ['all'] : this.filterInfo[key]) : '';
          this.getBasicCustomFiledSelectListOnClick(item, false, 'FIXED');
          this.$set(this.filterData, key, value)
        })
      },
      // 获取固定字段下拉框数据
      getStaticSelectList() {
        let allPromises = []
        allPromises.push(this.getAllStatusList())
        allPromises.push(this.getPriorityList())
        allPromises.push(this.getSpritList())
        allPromises.push(this.getCauseList())
        allPromises.push(this.getAssignUsersList())
        Promise.all(allPromises).then(result => {
          this.dataList.statusList = result[0].data
          this.dataList.prorityList = result[1].data
          this.dataList.sprintList = result[2].data
          this.dataList.causeList = result[3].data
          this.dataList.assignUserList = result[4].data
          this.dataList.createUserList = result[4].data
        }).catch(_ => _)
      },
      // 更新过滤器过滤值 - 部分固定字段
      updateFilterData() {
        console.log('updateFilterData', this.filterData.statusIds)
        Object.keys(this.filterData).forEach(item => {
          if (Array.isArray(this.filterData[item])) {
            this.filterData = {
              ...this.filterData,
              [item]: (!this.filterInfo[item] || this.filterInfo[item].length === 0) ? ['all'] : this.filterInfo[item]
            }
          } else {
            this.filterData[item] = this.filterInfo[item] || '';
          }
        })

        // this.filterData.title = this.filterInfo.title
        // this.filterData.statusIds = this.filterInfo.statusIds.length===0?['all']:this.filterInfo.statusIds
        // this.filterData.priorities = this.filterInfo.priorities.length===0?['all']:this.filterInfo.priorities
        // this.filterData.sprintIds = this.filterInfo.sprintIds.length===0?['all']:this.filterInfo.sprintIds
        // this.filterData.causes = this.filterInfo.causes.length===0?['all']:this.filterInfo.causes
        // this.filterData.assignUsers = this.filterInfo.assignUsers.length===0?['all']:this.filterInfo.assignUsers
        // this.filterData.createUsers = this.filterInfo.createUsers.length===0?['all']:this.filterInfo.createUsers
      },
      // 展开/关闭过滤器，展开过滤器的时候，去获取一遍自定义字段列表，包含一些固定自定、自定义字段
      filterChange() {
        // 如果没有缓存，则发起请求获取数据
        if (this.dataList.prorityList.length < 1) { this.getStaticSelectList() }
        let nextOpenStatu = !this.isFilterOpen
        this.isFilterOpen = nextOpenStatu
        nextOpenStatu && this.getCustomInfo({ refresh: true })
        this.$emit('filterOpenChange', nextOpenStatu)
      },
      // 快捷搜索点击
      shortcutClick(key, oldActive) {
        if (key === 'all') {
          this.updateShortcutInfo({
            created: false,
            assigned: false,
            toSolve: false,
            toAccept: false
          })
        } else {
          this.updateShortcutInfo({
            created: false,
            assigned: false,
            toSolve: false,
            toAccept: false,
            ...{ [key]: true }
          })
        }
      },
      // 点击过滤按钮
      filterClick() {
        // 先封装自定义字段
        const custom = {};
        Object.keys(this.filterData.custom).forEach(item => {
          if (Array.isArray(this.filterData.custom[item])) {
            custom[item + 's'] = this.filterData.custom[item].includes('all') ? [] : this.filterData.custom[item];
          } else {
            custom[item] = this.filterData.custom[item] && this.filterData.custom[item].trim() || null;
          }
        })
        // 再封装固定字段
        const fixed = {};
        Object.keys(this.filterData).forEach(item => {
          if (Array.isArray(this.filterData[item])) {
            fixed[item] = this.filterData[item].includes('all') ? [] : this.filterData[item]
          } else if (item !== 'custom') {
            fixed[item] = this.filterData[item] && this.filterData[item].trim() || null;
          }
        })
        this.updateFilterInfo({
          ...fixed,
          custom
        })
      },
      // 控制全选 select ，同时支持固定字段与自定义字段
      handleSelectChange(value, key, isCustom) {
        let filterData = isCustom ? this.filterData.custom : this.filterData
        // 如果最后一个选中了全部
        if (value[value.length - 1] === 'all') {
          filterData[key] = ['all']
        }
        // 如果不是最后一个选中了全部
        if (filterData[key].includes('all') && filterData[key].length > 1) {
          filterData[key] = filterData[key].filter(item => item !== 'all')
        }
      },
      // 设置当前选中的自定义过滤条件
      setSelectedCUSTOMFIELD(value) {
        this.selectedCUSTOMFIELD = value
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import './BugCommon';

  @import '../ProjectCommon';

  .active {
    color: $color-font-active-common;
  }

  .inactive {
    color: $color-font-inactive-common;
  }

  .new-button {
    position: relative;
    top: 2px;
    right: 18px;
  }

  .header-button-more {
    display: inline-block;
    vertical-align: middle;
  }

  // 第一个按钮
  #app .el-button.header-button-first {
    padding-left: 0 !important;
  }

  // 过滤器
  .header-filter {
    padding: 10px 0 0;
  }

  .header-filter-item {
    margin-bottom: 0 !important;

    .header-filter-item-label {
      min-width: 58px;
      display: inline-block;
    }
  }

  .header-filter-hidden {
    display: none;
  }

  // 重写 app.vue 部分样式
  #app .header-content .el-button--text {
    margin-left: 0;
  }
</style>