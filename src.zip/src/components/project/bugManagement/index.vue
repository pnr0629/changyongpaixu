<template>
  <div class="content-outer-box" v-if="!isAbnormity">
    <div class="content-box" v-loading="loadingStatus.bugListLoading" element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
      <div class="header-box border-box" ref="headerBox" v-if="!isSingleBugExhibition">
        <header-count v-bind="bugInfo.summary" :updateShortcutInfo="updateShortcutInfo"></header-count>
        <header-filter @newBug="rightSliderHandle" @filterOpenChange="headerFilterOpenChange" :projectId="commonFilterInfo.projectId" @sprintTypeFun='sprintTypeFun'
          :listStatu="statusManage.isFullList" :filterInitData="filterInfo" @listStatuChange="listStatuChange" @refeshBug="refeshBug" @filterClick="updateFilterInfo"
          @bugExport="bugExport"></header-filter>
      </div>
      <div class="body-box" v-if="!statusManage.isFullList" ref="bugContentBox">
        <two-block-width-changer :initLeftWidth="300" fixedLeft barType='tiny'>
          <div class="left-box" slot="left" v-if="!isSingleBugExhibition">
            <left-list :bugList="bugInfo.bugList" :activeBugInfo="activeBugInfo"
              :changeActiveBugInfo="changeActiveBugInfo" :updateCommonInfo="updateCommonInfo"
              :commonFilterInfo="commonFilterInfo"></left-list>
            <div class="left-content-footer">
              <div class="pagination-custom">
                <span>每页</span>
                <el-input class="pagination-custom-input el-input-lowheight" size="mini"
                  @change="leftContentPagasizeChange" v-model.number="bugInfo.pageInfo.pageSize"></el-input>
                <span>条</span>
              </div>
              <el-pagination v-if="bugInfo.pageInfo.totalPages > 0" small class="fr" layout="prev, next"
                @current-change="leftContentPagainationChange" :current-page="bugInfo.pageInfo.pageNumber"
                :page-size="bugInfo.pageInfo.pageSize" :page-count="bugInfo.pageInfo.totalPages">
              </el-pagination>
            </div>
          </div>
          <div class="detail-box scrollbal-common" :class="{'detail-box-full': isSingleBugExhibition}" slot="right">
            <bug-detail :projectId="commonFilterInfo.projectId" v-if="bugInfo.bugList.length > 0 || isSingleBugExhibition" :activeBugInfo="activeBugInfo" :buginfoData="buginfoData"
              :operateCallback="getBugList" ref="bugDetail" detailType="show" :assocClickCallback="assocClickCallback"
              :isReadyForUpdate="statusManage.isReadyForUpdate" @refeshBug="refeshBug"></bug-detail>
            <empty-result v-if="bugInfo.bugList.length === 0"></empty-result>
          </div>
        </two-block-width-changer>
      </div>
      <div class="body-box" v-if="statusManage.isFullList">
        <div class="funnlist-box" :style="{height: funnlistBoxHeight}" v-if="!isSingleBugExhibition">
          <full-list :bugList="bugInfo.bugList" :changeActiveBugInfo="changeActiveBugInfo"
            :updateCommonInfo="updateCommonInfo" :commonFilterInfo="commonFilterInfo"></full-list>
          <div class="left-content-footer">
            <div class="pagination-custom">
              <span>每页</span>
              <el-input class="pagination-custom-input" size="mini" @change="leftContentPagasizeChange"
                v-model.number="bugInfo.pageInfo.pageSize"></el-input>
              <span>条</span>
            </div>
            <el-pagination v-if="bugInfo.pageInfo.totalPages > 0" class="fr" size="middle" layout="prev, pager, next"
              @current-change="leftContentPagainationChange" :current-page="bugInfo.pageInfo.pageNumber"
              :page-size="bugInfo.pageInfo.pageSize" :page-count="bugInfo.pageInfo.totalPages">
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <!-- 新建 -->
    <slide :show="statusManage.bugEditSlideStatus" :afterClose="() => rightSliderHandle(false)"
      v-if="!isSingleBugExhibition" :beforeClose="({cb}) => beforeSliderClose({ id: -3, cb})">
      <div slot="task" class="taslinfo">
        <bug-detail :projectId="commonFilterInfo.projectId" v-if="statusManage.bugEditSlideStatus" detailType="editable" :rightSliderHandle="rightSliderHandle"
          :operateCallback="getBugList" :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc" :listStatu="statusManage.isFullList"></bug-detail>
      </div>
    </slide>
    <!-- 关联项滑窗 -->
    <slide :show="assocInfo.assocSliderStatus" :afterClose="assocSliderClose"
      :beforeClose="({cb}) => beforeSliderClose({ id: assocInfo.info.id, cb})">
      <div slot="task" class="taslinfo">
        <bug-detail :projectId="commonFilterInfo.projectId" v-if="assocInfo.type==='defect'" isSlider :activeBugInfo="assocInfo.info" detailType="show"
          @detailClose="assocSliderClose" :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc" :operateCallback="getBugList" @refeshBug="refeshBug">
        </bug-detail>
        <task-detail v-if="assocInfo.type==='task'" :taskId="assocInfo.info.id" :show="assocInfo.assocSliderStatus"
          @HandleSide="assocSliderClose" :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc"></task-detail>
        <require-detail v-if="assocInfo.type==='requirement'" :requireId="assocInfo.info.id"
          :show="assocInfo.assocSliderStatus" @HandleSide="assocSliderClose"
          :titleNotice.sync="sliderBeforeCloseData.title" :descNotice.sync="sliderBeforeCloseData.desc">
        </require-detail>
      </div>
    </slide>
  </div>
</template>

<script>
  /**
  * @title 缺陷管理 - 中心控制模块
  * @desc 模块架构设计：分四个模块，中心控制模块 + 3个布局模块，共享数据抽离，通过中心控制模块控制
  * @desc 共享数据：过滤查询条件、当前展示的缺陷信息
  * @desc 约定：1. 采用右侧飘窗实现新建 2. 飘窗实现其他缺陷的预览及编辑，同需求、任务一致
  * @author heyunjiang
  * @date 2019-3-4
  * @update 2019.4.12 增加缺陷列表 statusManage.isFullList
  */
  import HeaderCount from './HeaderCount'
  import HeaderFilter from './HeaderFilter'
  import LeftList from './LeftList'
  import FullList from './FullList'
  import BugDetail from './BugDetail'
  import EmptyResult from './EmptyResult'
  import TaskDetail from '../task/taskDetail'
  import RequireDetail from '../requirement/requirementView'
  import slide from '@/components/tool/slideSlip'
  import StringView from '@/components/commonComponents/StringView'
  import ProjectCommonMixin from "../ProjectCommonMixin"
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin"
  import TwoBlockWidthChanger from "@/components/tool/TwoBlockWidthChanger";

  const bugId = 'bugId'

  export default {
    name: "BugManagementContainer",
    components: {
      HeaderCount,
      HeaderFilter,
      LeftList,
      BugDetail,
      slide,
      TaskDetail,
      RequireDetail,
      FullList,
      EmptyResult,
      TwoBlockWidthChanger
    },
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    data() {
      return {
        // 所有搜索通用信息
        commonFilterInfo: { // 全局过滤信息
          orderBy: [
            { column: "createTime", order: "DESC" } // 默认创建时间、降序排序
          ], // 排序方式，每个项包含 排序字段、ASC|DESC
          projectId: 0, // 项目 id
          pageInfo: { // 缺陷分页获取列表信息使用 - 用于设置初始信息
            pageNumber: 1,
            pageSize: 20,
          }
        },
        // 快捷搜索过滤信息
        shortcutFilterInfo: {
          shortcut: {  // 快捷搜索
            created: false, // 我创建的
            assigned: false, // 分配给我的
            toSolve: false, // 待我解决的
            toAccept: false, // 待我验证的

          }
        },
        // 过滤器搜索信息
        filterInfo: {
          title: null, // 缺陷标题
          statusIds: [], // 缺陷状态列表
          priorities: [], // 缺陷优先级|严重程度
          sprintIds: [], // 关联迭代 id
          causes: [], // 缺陷原因列表
          assignUsers: [], // 指派人，即处理人
          createUsers: [], // 创建人
          isArchived:0
          // sources: [], // 缺陷来源
          // functionCharacters: [], // 功能特性
          // reproduceProbabilitys: [] // 复现概率
        },
        buginfoData:[],
        // 缺陷列表信息
        bugInfo: {
          pageInfo: { // 缺陷分页信息信息 - 用于分页器，通过双向数据绑定更新
            pageNumber: 1,
            pageSize: 20,
            totalPages: 0,
            totalRecords: 0,
          },
          bugList: [], // 缺陷列表
          summary: {
            ONGOING: { number: 0 },
            TODO: { number: 0 },
            DONE: { number: 0 },
            TOTAL: { number: 0 }
          }
        },
        activeBugInfo: {}, // 当前展示的缺陷信息
        // 状态统一管理
        statusManage: {
          isFullList: false, // 是否满屏展示缺陷列表
          bugEditSlideStatus: false, // 新建缺陷右侧划入编辑状态
          isHeaderFilterOpen: false, // 是否展开过滤器
          isReadyForUpdate: false // 是否更新缺陷附属内容
        },
        SELFJDUGE: { // 内部判断逻辑
          safyCodes: [200] // 返回的 status 只有在这个范围内才是正常的
        },
        loadingStatus: { // loading 统一管理
          bugListLoading: false
        },
        // 缺陷页面右侧通用滑块-滑块信息-需求详情、任务详情、缺陷详情
        assocInfo: {
          assocSliderStatus: false,
          type: '',
          info: {}
        },
        funnlistBoxHeight: '100px'
      }
    },
    created: function () {
      if (this.getUrlParams()['projectId']) {
        this.commonFilterInfo.projectId = this.getUrlParams().projectId // 拿url后面跟的 projectId
        this.bugInfo.bugList = []
        sessionStorage.setItem('bugSelectType', 'refresh')
        // 恢复过滤器信息
        // this.rebackFilterInfo(this.getUrlParams()['projectId']);
        // 初次进入，如果传了 bugId ，则更新当前展示的缺陷信息
        if (this.getUrlParams()[bugId]) {
          this.changeActiveBugInfo({ id: +this.getUrlParams()[bugId] })
          this.getBugListForBugId(+this.getUrlParams()[bugId])
        } else {
          this.getBugList()
        }
      }
    },
    mounted: function () {
      this.funnlistBoxHeightGenerate();
    },
    watch: {
      // 在每次 activeBugInfo 切换的时候，如果当前 activeBugInfo.id 不等于 url 中的 bugId，则更新路由
      activeBugInfo() {
        if (!this.getUrlParams()[bugId] && !this.getUrlParams()['projectId']) { return false }
        // url 拿不到 bugId ：初次进入
        if (!this.getUrlParams()[bugId]) {
          this.$router.replace({ path: this.$route.path, query: { ...this.$route.query, bugId: this.activeBugInfo.id } })
        } else {
          if (this.getUrlParams()[bugId] === this.activeBugInfo.id) { return false }
          this.$router.push({ path: this.$route.path, query: { ...this.$route.query, bugId: this.activeBugInfo.id } })
        }
      }
    },
    computed: {
      // 只传 bugId
      isSingleBugExhibition() {
        return !this.getUrlParams()['projectId'] && this.getUrlParams()[bugId]
      },
      // 是否是异常状态，bugId 和 projectId 都不传
      isAbnormity() {
        return !this.getUrlParams()[bugId] && !this.getUrlParams()['projectId']
      }
    },
    beforeRouteUpdate(to, from, next) {
      if (to.query[bugId] !== this.activeBugInfo.id) {
        this.changeActiveBugInfo({ id: to.query[bugId] })
      }
      next()
    },
    beforeRouteLeave(to, from, next) {
      // if (this.statusManage.bugEditSlideStatus) {
      //   this.statusManage.bugEditSlideStatus = false;
      // }
      // 如果存在内容在编辑，则不能离开
      if (this.sliderBeforeCloseData.title || this.sliderBeforeCloseData.desc) {
        return false;
      }
      next()
    },
    methods: {
      //获取迭代过滤器类型
      sprintTypeFun(val){
        this.filterInfo.isArchived = val;
      },
      //更新当前缺陷列表选中信息
      refeshBug() {
        this.activeBugInfo = {};
        this.getBugList();
      },
      /**
       * @desc 获取缺陷列表
       * @param { type } optional, 更新方式： shortcut -> 快捷搜索, filter -> 过滤器搜索，如果没有传，则获取上一次的查询方式
       */
      getBugList(type) {
        const filterInfo = this.getFilterInfo(type);
        this.loadingStatus.bugListLoading = true
        if(filterInfo.sprintIds){
          filterInfo.sprintIds = filterInfo.sprintIds.filter( item =>[-1,-2,-3,-4,-5].indexOf(item)==-1);
        }
        $http.post($http.api.bug_info.bug_list, filterInfo).then(res => {
          if (this.SELFJDUGE.safyCodes.includes(res.status)) {
            this.loadingStatus.bugListLoading = false
            if (!res.data || !res.data.result || !Array.isArray(res.data.result)) { return false; }
            this.bugInfo.pageInfo = res.data.pageInfo;
            this.bugInfo.bugList = res.data.result;
            // this.buginfoData = res.data.result
            res.data.summary && (this.bugInfo.summary = res.data.summary);
            if (res.data.statusts && res.data.statusts.length > 0) {
              this.filterInfo = {
                ...this.filterInfo,
                statusIds: res.data.statusts.map(item => item)
              }
            }
            // 设置当前活跃信息：初始化、快捷方式切换、过滤器选择
            if (Object.keys(this.activeBugInfo).length === 0 || ['refresh', 'shortcut'].includes(type)) {
              this.activeBugInfo = res.data.result.length > 0 ? res.data.result[0] : {}
            }
          }
        }).catch(e => {
          console.error("项目缺陷信息失败" + e)
        })
      },
      // 获取过滤信息
      getFilterInfo(type) {
        let filterInfo = this.commonFilterInfo;
        if(!type) {
          type = sessionStorage.getItem('bugSelectType') || 'norefresh';
        } else {
          sessionStorage.setItem('bugSelectType', type)
        }
        switch (type) {
          case 'shortcut': filterInfo = { ...filterInfo, ...this.shortcutFilterInfo }; break;
          default: filterInfo = { ...filterInfo, ...this.filterInfo };
        }
        return filterInfo
      },
      // 获取缺陷列表 - 并且跳转到对应缺陷的页数 - 为了实现定位到缺陷那一页
      getBugListForBugId(bugId) {
        if (!bugId) { 
          this.getBugList();
          return ;
        }
        let filterInfo = this.commonFilterInfo
        let type = sessionStorage.getItem('bugSelectType') || 'refresh'
        switch (type) {
          case 'shortcut': filterInfo = { ...filterInfo, ...this.shortcutFilterInfo }; break;
          default: filterInfo = { ...filterInfo, ...this.filterInfo };
        }
        this.loadingStatus.bugListLoading = true
        $http.post($http.api.bug_info.bug_list, { ...filterInfo, queryId: bugId }).then(res => {
          if (this.SELFJDUGE.safyCodes.includes(res.status)) {
            this.bugInfo.pageInfo = res.data.pageInfo;
            this.bugInfo.bugList = res.data.result;
            res.data.summary && (this.bugInfo.summary = res.data.summary);
            if (Object.keys(this.activeBugInfo).length === 0 && res.data.result.length > 0) {
              this.activeBugInfo = res.data.result[0]
            }
          }
          this.loadingStatus.bugListLoading = false
        }).catch(e => {
          console.error("项目缺陷信息失败" + e)
        })
      },
      // 更新当前活跃 bug 信息
      changeActiveBugInfo: function (activeBugInfo) {
        this.activeBugInfo = activeBugInfo
        // 如果是列表模式，则展开通用滑块
        if (this.statusManage.isFullList) {
          this.assocInfo = {
            assocSliderStatus: true,
            type: 'defect',
            info: { ...activeBugInfo }
          }
        }
      },
      // 新建-右侧滑块控制
      rightSliderHandle(bool) {
        this.statusManage.bugEditSlideStatus = bool
      },
      // 过滤器更新-更新过滤过滤器信息
      updateFilterInfo(newFilter) {
        this.filterInfo = { ...this.filterInfo, ...newFilter }
        this.commonFilterInfo = {
          ...this.commonFilterInfo, pageInfo: {
            pageNumber: 1,
            pageSize: this.commonFilterInfo.pageInfo.pageSize,
          }
        }
        // 保存过滤器信息到 localstorage 里面
        // localStorage.setItem('bugFilterInfo_' + this.commonFilterInfo.projectId, JSON.stringify(this.filterInfo));
        this.$nextTick(function () {
          this.getBugList('refresh')
        })
      },
      // 过滤器更新-在进入缺陷模块时，恢复过滤器数据，只恢复固定字段的数据，不恢复自定义字段的数据
      rebackFilterInfo(projectId) {
        if (localStorage.getItem('bugFilterInfo_' + projectId)) {
          const filterInfo = JSON.parse(localStorage.getItem('bugFilterInfo_' + projectId));
          delete filterInfo.custom;
          this.filterInfo = filterInfo;
        }
      },
      // 过滤器更新-更新快捷查询信息
      updateShortcutInfo(newFilter) {
        this.shortcutFilterInfo.shortcut = { ...this.shortcutFilterInfo.shortcut, ...newFilter }
        this.commonFilterInfo = {
          ...this.commonFilterInfo, pageInfo: {
            pageNumber: 1,
            pageSize: this.commonFilterInfo.pageInfo.pageSize,
          }
        }
        this.$nextTick(function () {
          this.getBugList('shortcut')
        })
      },
      // 过滤器更新-更新通用过滤信息
      updateCommonInfo(newFilter) {
        this.commonFilterInfo = { ...this.commonFilterInfo, ...newFilter }
        this.$nextTick(function () {
          this.getBugList()
        })
      },
      // 过滤器更新-展开过滤器
      headerFilterOpenChange(value) {
        this.statusManage.isHeaderFilterOpen = value
        this.$nextTick(this.funnlistBoxHeightGenerate)
      },
      // 缺陷列表高度
      funnlistBoxHeightGenerate() {
        const top = this.$refs.headerBox.offsetHeight + 140
        this.funnlistBoxHeight = "calc(100vh - " + top + "px)"
      },
      // 缺陷列表分页-分页信息变化数据获取-页数
      leftContentPagainationChange(num) {
        this.updateCommonInfo({
          pageInfo: {
            pageSize: this.bugInfo.pageInfo.pageSize,
            pageNumber: num
          }
        })
      },
      // 缺陷列表分页-分页信息变化数据获取-每页条数
      leftContentPagasizeChange(num) {
        if(Number(num) < 1 || !/^\d+$/.test(Number(num))) {
          this.$message({ type: 'warning', message: '每页条数必须大于0，并且是整数' });
          this.updateCommonInfo({
            pageInfo: {
              pageSize: this.commonFilterInfo.pageInfo.pageSize,
              pageNumber: 1
            }
          })
        } else {
          this.updateCommonInfo({
            pageInfo: {
              pageSize: num,
              pageNumber: 1
            }
          })
        }
      },
      // 缺陷页面右侧通用滑块 - 弹出滑块
      assocClickCallback(info, type) {
        this.assocInfo = {
          assocSliderStatus: true,
          type,
          info: { ...info }
        }
      },
      // 缺陷页面右侧通用滑块 - 关闭滑块
      assocSliderClose() {
        this.assocInfo = {
          assocSliderStatus: false,
          type: '',
          info: {}
        }
        // 更新缺陷附属内容
        this.statusManage.isReadyForUpdate = !this.statusManage.isReadyForUpdate
      },
      // 缺陷列表状态/详情状态切换
      listStatuChange() {
        this.statusManage.isFullList = !this.statusManage.isFullList
      },
      encodeString(str) {
        return encodeURIComponent(new StringView(str).toBase64());
      },
      // 缺陷导出
      bugExport() {
        const filterInfo = this.getFilterInfo();
        const postInfo = {
          projectId: filterInfo.projectId,
          request: this.encodeString(JSON.stringify(filterInfo))
        }
        const url = $http.api.bug_info.bug_export.url + '?projectId=' + postInfo.projectId + '&request=' + postInfo.request;
        window.open(url, '_blank');
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import './BugCommon';
  $bottomContentHeight: calc(100vh - 155px);
  // $leftListWidth: 300px;
  // $detailBoxWidth: calc(100% - 310px);
  $leftListWidth: 100%;
  $detailBoxWidth: 100%;

  /* 顶部过滤 */
  .header-box {
    padding-bottom: 11px; // header-box height 凑够 40px
    border-bottom: 1px solid $color-border-bar;
  }

  /* 左侧缺陷列表 */
  .left-box {
    display: inline-block;
    min-width: 300px;
    width: $leftListWidth;
    height: $bottomContentHeight;
    padding: 0;
    margin: 0;
    overflow-y: auto;
    overflow-x: hidden;
    box-sizing: border-box;
    position: relative;
    top: -1px; // 解决空隙
    border: 1px solid $color-gray-common;
    border-top: none;

    .left-content-footer {
      position: absolute;
      bottom: 0;
      height: 32px;
      border-top: 1px solid $color-border-common;
      width: 100%;
      background: $color-input-background-common;
      padding: 2px 0 4px 2px;
      box-sizing: border-box;
      .pagination-custom {
        float: left;
        width: 105px;
        font-size: 12px;
        padding: 3px 0;
        box-sizing: border-box;
        .pagination-custom-input {
          display: inline-block;
          width: calc(100% - 60px);
        }
      }
    }
  }

  /* 全屏列表 */
  .funnlist-box {
    padding: 0;
    margin: 0;

    .left-content-footer {
      height: 32px;
      box-sizing: border-box;
      .pagination-custom {
        display: inline-block;
        width: 105px;
        font-size: 12px;
        padding: 3px 0;
        box-sizing: border-box;
        .pagination-custom-input {
          display: inline-block;
          width: calc(100% - 60px);
        }
      }
    }
  }

  /* 右侧缺陷详情 */
  .detail-box {
    float: right;
    width: $detailBoxWidth;
    min-height: $bottomContentHeight;
    padding: 0;
    margin: 0;
    overflow-x: auto; // 为什么这里需要加 x-hidden 才能正常展示需要的布局
  }

  .detail-box-full {
    width: 100%;
  }

  /* 重写 App.vue 一些全局样式 */
  #app .content-box {
    margin-bottom: 0;
  }
</style>
