<template>
  <div class="left-content">
    <div class="left-content-body scrollbal-common">
      <el-table :data="bugList" @sort-change="onFilterChange" border height="100%">
        <el-table-column prop="id" label="ID" show-overflow-tooltip width="72" class-name=" cp c-blue-hover">
        </el-table-column>
        <el-table-column prop="display.title" label="标题" class-name="buglist-title" show-overflow-tooltip
          min-width="240">
          <template slot-scope="scope">
            <global-input :initValue="scope.row.display.title"
              :onChange="(value)=>{GlobalBugUpdate({title: value, id: scope.row.id, projectId: scope.row.projectId, cb: updateCommonInfo})}">
              <span class="table-input-edit-text cp c-blue-hover" @click.stop="()=>itemClick(scope.row)"
                slot>{{scope.row.display.title}}</span>
            </global-input>
          </template>
        </el-table-column>
        <el-table-column prop="display.priority" label="严重程度" sortable="custom" show-overflow-tooltip align="left"
          width="100">
          <template slot-scope="scope">
            <span class="cursor-pointer"
              @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'priority', updateCommonInfo)">
              <!-- <span class="mini-circle" :style="{backgroundColor:scope.row.display.detail.priority.color}" ></span> -->
              <span v-html="initNameStatus(scope.row,'extent')"></span>
              <!-- {{scope.row.display.priority}} -->
            </span>
            <!-- <span>{{scope.row.display.priority}}</span> -->
          </template>
        </el-table-column>
        <el-table-column label="状态" show-overflow-tooltip resizable align="left" width="112">
          <template slot-scope="scope">
            <!-- <span  class="cursor-pointer"
              @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'statusId', updateCommonInfo)"></span> -->
            <span class="bug-basic-info-item-static editable-field cursor-pointer"
              @click="showActiveStatus($event,scope.row)" v-html="initNameStatus(scope.row,'status')">
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="display.cause" label="缺陷原因" show-overflow-tooltip align="left" width="80">
          <template slot-scope="scope">
            <span class="cursor-pointer"
              @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'cause', updateCommonInfo)">{{scope.row.display.cause}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="display.sprint" label="所属迭代" show-overflow-tooltip align="left" width="160">
          <template slot-scope="scope">
            <span class="cursor-pointer"
              @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'sprintId', updateCommonInfo)">{{scope.row.display.sprint}}</span>
          </template>
        </el-table-column>
        <el-table-column label="处理人" show-overflow-tooltip align="left" min-width="70">
          <template slot-scope="scope">
            <span class="cursor-pointer"
              @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'assignUser', updateCommonInfo)">{{scope.row.display.assignUser}}({{scope.row.assignUser}})</span>
          </template>
        </el-table-column>
        <el-table-column label="创建人" show-overflow-tooltip align="left" min-width="60">
          <template slot-scope="scope">
            <span>{{scope.row.display.createUser}}({{scope.row.createUser}})</span>
          </template>
        </el-table-column>
        <el-table-column prop="createTime" label="创建时间" sortable="custom" align="left" width="160"></el-table-column>
        <el-table-column prop="updateTime" label="修改时间" sortable="custom" align="left" width="160"></el-table-column>
      </el-table>
    </div>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
    <!-- 二级状态选择、添加评论 -->
    <!-- <comment-for-status v-bind="CommentForStatusInfo"></comment-for-status> -->
    <!-- //状态扭转 -->
    <custom-status v-if="showStausObj.status" :statusHeight="showStausObj.statusHeight"
      :statusleft="showStausObj.statusleft" :projectId="showStausObj.projectId" :statusId="showStausObj.statusId"
      :workItemType="showStausObj.workItemType" :workItemId="showStausObj.workItemId" :statusShow="showStausObj.status"
      :parentInfo="this.showStausObj.parentInfo" @closeStatus="closeStatus" :updateData="updataStausInfo">
    </custom-status>
  </div>
</template>

<script>
  /**
  * @title 缺陷列表
  * @author heyunjiang
  * @date 2019-4-12
  */
  import FieldEdit from '../../tool/FieldEdit'
  import GlobalSelect from '../../tool/FieldEdit/GlobalSelect.vue'
  import GlobalInput from '../../tool/FieldEdit/GlobalInput.vue'
  import CommentForStatus from './CommentForStatus.vue'
  import ProjectCommonMixin from '../ProjectCommonMixin'

  export default {
    name: "FullList",
    components: {
      FieldEdit,
      GlobalSelect,
      GlobalInput,
      CommentForStatus
    },
    mixins: [ProjectCommonMixin],
    props: {
      bugList: {
        type: Array,
        required: true
      },
      changeActiveBugInfo: {
        type: Function,
        required: true
      },
      updateCommonInfo: {
        type: Function,
        desc: '该函数用于更新当前列表数据，并且会更新到当前活跃项所对应的页数'
      },
      commonFilterInfo: Object
    },
    data() {
      return {
        CommentForStatusInfo: {
          isShow: false,
          statusInfo: {},
          parentInfo: {},
          onOk: this.bugStatusClickCallbackOnOk,
          onCancel: this.bugStatusClickCallbackOnCancel
        },
        targetdata: this.GlobalSelectProps,
        showStausObj: {
          status: false,
        }
      }
    },
    mounted() { },
    computed: {},
    methods: {
      offsetLeft(obj) {
        var tmp = obj.offsetLeft;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetLeft;
          val = val.offsetParent;
        }
        return tmp;
      },
      offsetTop(obj) {
        var tmp = obj.offsetTop;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetTop;
          val = val.offsetParent;
        }
        return tmp;
      },
      //关闭缺陷状态
      closeStatus() {
        this.showStausObj.status = false;
      },
      //状态扭转更新缺陷信息
      updataStausInfo(value, cb) {
        this.GlobalBugUpdate({
          ...value,
          cb: this.updateCommonInfo
        })
      },
      //展示扭转状态
      showActiveStatus(e, item) {
        // console.log(-(document.getElementsByClassName("is-scrolling-none")[0].scrollTop-150))
        if (document.getElementById("main-content").offsetHeight - this.offsetTop(e.target) > 408) {
          this.showStausObj.statusHeight = this.offsetTop(e.target) - 204 + 'px';
          this.showStausObj.statusleft = this.offsetLeft(e.target) - 400 + 'px';
         
        } else {
          this.showStausObj.statusHeight = this.offsetTop(e.target) - 660 + 'px';
          this.showStausObj.statusleft = this.offsetLeft(e.target) - 400 + 'px';
        }
        this.showStausObj.status = !this.showStausObj.status;
        this.showStausObj.parentInfo = item;
        this.showStausObj.statusId = item.statusId;
        this.showStausObj.projectId = this.getUrlParams().projectId;
        this.showStausObj.workItemType = 3;
        this.showStausObj.workItemId = item.id;
        if (this.showStausObj.workItemId && this.showStausObj.temId !== item.id) {
          this.showStausObj.status = true;
        }
        this.showStausObj.temId = item.id;
        e.stopPropagation()
      },
      // 顶部过滤-排序方式
      onFilterChange(obj) {
        let param = {}, arr = []
        if (obj.prop) {
          param = {
            column: obj.prop.split('.').reverse()[0],
            order: obj.order === 'descending' ? 'DESC' : 'ASC'
          }
          arr.push(param)
        }
        this.updateCommonInfo({
          orderBy: arr,
          pageInfo: {
            pageSize: this.commonFilterInfo.pageInfo.pageSize,
            pageNumber: 1
          }
        })
      },
      // 缺陷 item 点击
      itemClick(info) {
        this.changeActiveBugInfo(info)
      },
      // initname - 状态
      initNameStatus(item, info) {
        if (info == 'status') {
          return `<span class="statusbox-list-common" style="background-color: ${item.display.detail.status.color}">${item.display.status}</span>`
        } else {
          return `<span class="statusbox-list-common" style="background-color: ${item.display.detail.priority.color}">${item.display.priority}</span>`
        }
      },
      // 更新缺陷 - 状态变化 - 添加二级状态及评论
      bugStatusClickCallback(info, cb, parentInfo) {
        // 如果不需要选择附加字段
        if (!info.fields.present) {
          this.GlobalBugUpdate({
            [info.updateName]: info.key,
            cb: this.updateCommonInfo
          })
          cb(true)
        } else {
          // 如果需要附加字段
          this.CommentForStatusInfo = {
            isShow: true,
            statusInfo: { ...info },
            parentInfo,
            onOk: (value) => { this.bugStatusClickCallbackOnOk(value, cb) },
            onCancel: () => { this.bugStatusClickCallbackOnCancel(cb) }
          }
        }
      },
      // 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击确定
      bugStatusClicackCallbkOnOk(value, cb) {
        this.CommentForStatusInfo.isShow = false
        this.GlobalBugUpdate({
          ...value,
          cb: this.updateCommonInfo
        })
        cb(true)
      },
      // 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击取消
      bugStatusClickCallbackOnCancel(cb) {
        this.CommentForStatusInfo.isShow = false
        cb(true)
      },
    }
  }
</script>

<style lang="scss" scoped>
  @import './BugCommon';
  $leftHeaderHeight: 40px;

  .left-content {
    height: calc(100% - 30px);
    position: relative;
  }

  .left-content-header {
    height: $leftHeaderHeight;
    line-height: $leftHeaderHeight;
    padding: 2px 2px 2px 10px;

    .field-edit-asside {
      display: inline-block;
      overflow: hidden;
    }

    .header-icon-class {
      cursor: pointer;

      &:hover {
        background-color: $color-gray-common;
      }
    }
  }

  .left-content-body {
    height: calc(100% - 10px);
    overflow-x: hidden;
    overflow-y: auto;

    .bug-active {
      background-color: $color-active-background-common;

      p {
        // text-decoration: underline;
      }
    }

    .bug-card-simple {
      padding: 8px 20px 6px;
      box-sizing: border-box;
      border-bottom: 1px solid $color-border-common;
      position: relative;
      cursor: pointer;

      &:hover {
        @extend .bug-active;
      }

      p {
        @extend .list-item-ellipsis;
        height: 21px;
        line-height: 21px;
        margin: 0;
        color: $color-font-active-jira;
      }

      .bug-card-simple-status {
        position: absolute;
        right: 20px;
        top: 8px;
        padding: 2px 5px;
        height: 16px;
        line-height: 16px;
        font-size: $font-size-small;
        background-color: #fff;
        border: 1px solid #e4e8ed;
        display: inline-block;
        max-width: 12em;

        .mini-circle {
          margin: 0 2px 0 0;
          // width: 8px;
          // height: 8px;
          // border-radius: 4px;
          // top: -1px;
        }
      }
    }
  }
</style>