<template>
  <el-dialog :visible.sync="modalStatu" width="60%" class="AssocWorkItem" title="关联工作项" :modal-append-to-body="false">
    <div class="form-iterm-box" v-if="projectId">
      <el-form :inline="true">
        <el-row :gutter="10">
          <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="7">
            <el-form-item label="类型：">
              <el-select placeholder="选择类型" v-model="basic.currentType" class="header-input">
                <el-option v-for="item in basic.typeList" :key="item.key" :label="item.value" :value="item.key" ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="7">
            <el-form-item label="项目：">
              <el-select placeholder="选择项目" v-model="searchInfo.projectId" class="header-input">
                <el-option v-for="item in projectList" :key="item.id" :label="item.name" :value="item.id" ></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="7">
            <el-form-item label="标题：" class="header-input">
              <el-input placeholder="请输入需求标题关键字" v-model="searchInfo.title"></el-input>
            </el-form-item>
          </el-col>
          <el-col :xs="24" :sm="24" :md="12" :lg="12" :xl="3">
            <el-form-item>
              <el-button type="primary" @click="searchAssocRequrie">查询</el-button>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="table-box-top">
        <el-table
          :data="assocRequireDataList"
          ref="assocRequireTableRef"
          style="width: 100%;height: 100%;">
          <el-table-column type="selection" width="40"></el-table-column>
          <el-table-column :label="firstLabel" show-overflow-tooltip width="70" prop="id">
            <template slot-scope="scope">
              <span class="c-blue cp">{{scope.row.id}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="display.title" show-overflow-tooltip :label="secondLabel" min-width="180">
            <template slot-scope="scope">
              <span class="c-blue cp">{{scope.row.display.title}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="display.projectName" show-overflow-tooltip label="所属项目" min-width="80"></el-table-column>
          <el-table-column prop="display.assignUser" label="处理人" min-width="60">
          </el-table-column>
          <el-table-column prop="display.status" label="状态" width="80"></el-table-column>
        </el-table>
      </div>
      <div class="table_b_f_b">
        <el-pagination
          v-show="assocRequireDataList && assocRequireDataList.length>0"
          class="fr mr10"
          style="margin-top: 9px;"
          @size-change="handleAssocRequirePageSizeChange"
          @current-change="handleAssocRequirePageNumChange"
          :current-page="searchInfo.pageInfo.pageNumber"
          :page-sizes="[10, 20, 30]"
          :page-size="searchInfo.pageInfo.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="searchInfo.pageInfo.totalRecords"
        ></el-pagination>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button type="primary" @click="handleSureAssocRequrie()">关联</el-button>
    </span>
  </el-dialog>
</template>

<script>
/**
 * @title 关联工作项
 * @desc 缺陷：只能关联一种类型、选择一页的数据关联
 * @author heyunjiang
 * @date 2019-3-13
 */
export default {
  name: "AssocWorkItem",
  props: {
    // 项目 id
    projectId: {
      type: [Number, String]
    },
    isShow: {
      type: Boolean,
      required: true
    },
    // 关联成功回调，返回已经关联好的数据类型及关联选好的id列表
    successCallback: {
      type: Function
    },
    // 关闭模态框
    onClose: {
      type: Function
    }
  },
  data() {
    return {
      modalStatu: false,
      searchInfo: {
        projectId: '',
        title: null,
        isArchived: -1,
        pageInfo: {
          pageNumber: 1,
          pageSize: 10,
          totalRecords: 0,
          totalPages: 0
        }
      }, // 搜索信息
      projectList: [],
      assocRequireDataList: [],
      basic: {
        currentType: 'requirement', // 当前查询类型
        typeList: [
          {key: 'requirement', value: '需求'},
          {key: 'task', value: '任务'},
          {key: 'bug', value: '缺陷'}
        ]
      },
      typeName: {
        requirement: '需求',
        task: '任务',
        bug: '缺陷'
      }
    }
  },
  computed: {
    firstLabel() {
      return this.typeName[this.basic.currentType] + 'ID'
    },
    secondLabel() {
      return this.typeName[this.basic.currentType] + '标题'
    }
  },
  watch: {
    projectId() {
      this.searchInfo.projectId = +this.projectId
    },
    // modalStatu 不能用作计算属性，因为计算属性的值通常会和常规双向绑定数据起冲突，双向绑定数据最多只能应用到监听数据上
    isShow() {
      // this.searchAssocRequrie(); // 何运江注释掉， on 2019.5.23 ，获取具体列表时机不对
      this.modalStatu = this.isShow
      if(!this.isShow) {
        this.resetData()
        this.onClose&&this.onClose()
      } else {
        // 初始化获取项目列表数据
        this.getProjectList();
        this.searchAssocRequrie();
      }
    },
    modalStatu() {
      if(!this.modalStatu) {
        this.resetData()
        this.onClose&&this.onClose()
      }
    }
  },
  mounted() {
    // this.searchAssocRequrie();
  },
  methods: {
    // 获取项目列表
    getProjectList() {
      $http.get($http.api.project.projectList).then(result => {
        if(result.status === 200) {
          this.projectList = result.data
          this.searchInfo.projectId = +this.projectId || result.data[0].id
        } else {
          this.projectList = []
        }
      }).catch(e => {
        console.log(e)
      })
    },
    // 重置数据
    resetData() {
      this.searchInfo.pageInfo.pageNumber = 1;
      this.searchInfo.title = '';
      this.assocRequireDataList = [];
    },
    // 查询具体数据
    searchAssocRequrie() {
      let url = ''
      switch(this.basic.currentType) {
        case 'requirement': url = $http.api.requirement.list_assoc_require;break;
        case 'task': url = $http.api.mine.mineTask;break;
        case 'bug': url = $http.api.bug_info.bug_list;break;
      }
      this.$nextTick(function() {
        $http.post(url, this.searchInfo).then(result => {
          if(result.status === 200) {
            this.assocRequireDataList = result.data.result
            this.searchInfo.pageInfo.totalRecords = result.data.pageInfo.totalRecords
            this.searchInfo.pageInfo.totalPages = result.data.pageInfo.totalPages
          } else {
            this.assocRequireDataList = []
          }
        }).catch(_ => _)
      })
    },
    // 分页 - 第几页
    handleAssocRequirePageNumChange(pageNum) {
      // 保存数据
      this.searchInfo.pageInfo.pageNumber = pageNum;
      this.searchAssocRequrie();
    },
    // 分页 - 每页条数
    handleAssocRequirePageSizeChange(pageSize) {
      // 保存数据
      this.searchInfo.pageInfo.pageSize = pageSize;
      this.searchAssocRequrie();
    },
    // 获取当前选中数据
    getSelectedItems() {
      let assocRequrieIds = [];
      this.$refs["assocRequireTableRef"].selection.forEach(item => {
        assocRequrieIds.push(item);
      })

      return assocRequrieIds
    },
    // 点击关联
    handleSureAssocRequrie() {
      this.successCallback&&this.successCallback(this.basic.currentType, this.getSelectedItems())
    }
  }
};
</script>

<style lang="scss" scoped>
  .header-input {
    max-width: 100%;
    margin-bottom: 0;
  }
</style>
