<template>
  <div>
    <div class="bug-basic-info-item" v-if="detailType==='show'">
      <span class="bug-basic-info-item-label">状态：</span>
      <span
        class="bug-basic-info-item-static editable-field cursor-pointer"
        @click="showActiveStatus($event,detailInfo)"
        v-html="initNameStatus(detailInfo.display.detail.status.color,detailInfo.display.status)"
      ></span>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">严重程度：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.priority.fieldEditProps" :onChange="(value)=>{bugUpdate('priority', value, initData)}"></field-edit>
      <el-select v-else class="bug-basic-info-item-select-width" v-model="fieldEditObject.priority.fieldEditProps.initValue">
        <el-option v-for="jtem in fieldEditObject.priority.fieldEditProps.selectValue" @change="updateModel" :label="jtem.value" :key="jtem.key" :value="jtem.key">
          <span class="mini-circle" :style="{backgroundColor: jtem.color}"></span>{{jtem.value}}
        </el-option>
      </el-select>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">处理人：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.assignUser.fieldEditProps" :onChange="(value)=>{bugUpdate('assignUser', value, initData)}"></field-edit>
      <select-filter v-else class="bug-basic-info-item-select-width" @change="updateModel" v-model="fieldEditObject.assignUser.fieldEditProps.initValue"
        :selectList="fieldEditObject.assignUser.fieldEditProps.selectValue">
      </select-filter>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">迭代：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.sprint.fieldEditProps" :onChange="(value)=>{bugUpdate('sprintId', value, initData)}"></field-edit>
      <el-select v-else class="bug-basic-info-item-select-width" @change="updateModel" v-model="fieldEditObject.sprint.fieldEditProps.initValue">
        <el-option value="0" label="未规划"></el-option>
        <el-option v-for="jtem in fieldEditObject.sprint.fieldEditProps.selectValue" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
      </el-select>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">原因：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.cause.fieldEditProps" :onChange="(value)=>{bugUpdate('cause', value, initData)}"></field-edit>
      <el-select v-else class="bug-basic-info-item-select-width" @change="updateModel" v-model="fieldEditObject.cause.fieldEditProps.initValue">
        <el-option v-for="jtem in fieldEditObject.cause.fieldEditProps.selectValue" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
      </el-select>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <ellipsis-block class="bug-basic-info-item-label" value="结束时间："></ellipsis-block>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.endTime.fieldEditProps" :onChange="(value)=>{bugUpdate('endTime', value, initData)}"></field-edit>
      <custom-date v-else class="bug-basic-info-item-select-width" @change="updateModel" v-model="fieldEditObject.endTime.fieldEditProps.initValue"></custom-date>
    </div>
    <!-- 旧自定义字段接口中包含的固定字段 这3个字段留着，后续待后端搞完，再开放 -->
    <!-- <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">缺陷来源：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.source.fieldEditProps" :onChange="(value)=>{bugUpdate('source', value)}"></field-edit>
      <el-select v-else class="bug-basic-info-item-select-width" v-model="fieldEditObject.source.fieldEditProps.initValue">
        <el-option v-for="jtem in fieldEditObject.source.fieldEditProps.selectValue" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
      </el-select>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">功能特性：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.functionCharacter.fieldEditProps" :onChange="(value)=>{bugUpdate('functionCharacter', value)}"></field-edit>
      <el-select v-else class="bug-basic-info-item-select-width" v-model="fieldEditObject.functionCharacter.fieldEditProps.initValue">
        <el-option v-for="jtem in fieldEditObject.functionCharacter.fieldEditProps.selectValue" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
      </el-select>
    </div>
    <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
      <span class="bug-basic-info-item-label">复现概率：</span>
      <field-edit v-if="detailType==='show'" v-bind="fieldEditObject.reproduceProbability.fieldEditProps" :onChange="(value)=>{bugUpdate('reproduceProbability', value)}"></field-edit>
      <el-select v-else class="bug-basic-info-item-select-width" v-model="fieldEditObject.reproduceProbability.fieldEditProps.initValue">
        <el-option v-for="jtem in fieldEditObject.reproduceProbability.fieldEditProps.selectValue" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
      </el-select>
    </div> -->
    <el-row :gutter="10">
      <!-- 旧版自定义字段 -->
      <el-col :md="24" :lg="24" :xl="24" v-for="item in customFiledObjectVaues" :key="item.label">
        <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}">
          <ellipsis-block class="bug-basic-info-item-label" :value="item.label + ':'"></ellipsis-block>
          <field-edit
            v-if="detailType==='show'"
            v-bind="item.fieldEditProps"
            @FieldEditFieldClick="getBasicCustomFiledSelectListOnClick(item.key, false, item.type)"
            :onChange="(value)=>{bugUpdate({[item.key]: value, cb: initData})}"
          ></field-edit>
          <template v-else>
            <el-select
              class="bug-basic-info-item-select-width"
              value-key="key"
              v-if="item.choice"
              v-model="item.fieldEditProps.initValue"
              @change="updateModel"
            >
              <el-option
                v-for="jtem in item.fieldEditProps.selectValue"
                :label="jtem.value"
                :key="jtem.key"
                :value="jtem.key"
              ></el-option>
            </el-select>
            <el-input v-else
              class="basic-title-input-active"
              v-model="item.fieldEditProps.initValue"
              @change="updateModel"
            ></el-input>
          </template>
        </div>
      </el-col>
    </el-row>
    <!-- 新版自定义字段 -->
    <basic-info-custom-field :workItemType="3" :detailType="detailType" :detailInfo="detailInfo" :sessionStorageData="sessionStorageData"
      :projectId="projectId" :updateField="bugUpdate" v-model="customFieldObj"></basic-info-custom-field>
    <div class="bug-basic-info-item" v-if="detailType==='show'">
      <span class="bug-basic-info-item-label">提出人：</span>
      <span class="bug-basic-info-item-static">{{`${detailInfo.display.createUser}(${detailInfo.createUser})`}}</span>
    </div>
    <div class="bug-basic-info-item" v-if="detailType==='show'">
      <span class="bug-basic-info-item-label">创建时间：</span>
      <span class="bug-basic-info-item-static">{{detailInfo.createTime}}</span>
    </div>
  </div>
</template>
<script>
/**
 * @title 缺陷详情 - 基本信息组件 - 固定字段 + 旧接口的 FIXED， AUTO_HIDE 2个字段
 * @desc 这里做个拆分，减少缺陷详情组件体积
 * @author heyunjiang
 * @date 2019.8.28
 */

const resetInit = {
  content: "",
  statusId: "", // id
  cause: "", // id
  display: {
    stage: 0,
    cause: "",
    title: "",
    content:
      "",
    priority: "一般",
    biz: "",
    createUser: "",
    sprint: "",
    status: "",
    assignUser: "",
    functionCharacter: "",
    source: "",
    reproduceProbability: "",
    detail: {
      status: {},
      priority: {}
    }
  },
  sprintId: "", // id
  endTime: "",
  createUser: "", // id
  contentId: 0,
  assignUser: "", // id
  createTime: "",
  title: "",
  priority: 80, // id
  functionCharacter: 0,
  source: 0,
  reproduceProbability: 0,
  status: {
    statusId: 0,
    statusName: "",
    end: false
  },
  id: -3
};
const bugWorkTtemType = 3;

import ProjectCommonMixin from "../ProjectCommonMixin";
import BugCustomFieldsMixin from "./BugCustomFieldsMixin"; // 后续放弃使用，暂时使用，保留 FIXED， AUTO_HIDE 2个字段
import FieldEdit from "@/components/tool/FieldEdit";
import GlobalInput from "@/components/tool/FieldEdit/GlobalInput.vue";
import BasicInfoCustomField from "@/components/project/BasicInfoCustomField";

export default {
  name: "BugDetailBasicInfo",
  components: {
    FieldEdit,
    GlobalInput,
    BasicInfoCustomField
  },
  model: {
    prop: 'value',
    event: 'change'
  },
  mixins: [ProjectCommonMixin, BugCustomFieldsMixin],
  props: {
    value: Object,
    projectId: [String, Number],
    // 当前组件状态， show -> 展示， editable -> 新建
    detailType: {
      type: String,
      required: true,
      validator: function (value) {
        return ["show", "editable"].indexOf(value) !== -1;
      }
    },
    bugUpdate: {
      type: Function,
      required: true,
      desc: '缺陷数据更新'
    },
    detailInfo: Object, // 基本信息数据源
  },
  data() {
    return {
      // 基本信息 - 固定字段 - 5个
      fieldEditObject: {
        priority: {
          key: 'priority',
          fieldEditProps: {
            initValue: resetInit.priority,
            selectValue: [],
            colorType: "font"
          }
        },
        assignUser: {
          key: 'assignUser',
          fieldEditProps: {
            initValue: resetInit.assignUser,
            selectValue: [],
            localSearch: true
          }
        },
        sprint: {
          key: 'sprintId',
          fieldEditProps: {
            initValue: resetInit.sprintId,
            selectValue: []
          }
        },
        cause: {
          key: 'cause',
          fieldEditProps: {
            initValue: resetInit.cause,
            initName: resetInit.display.cause,
            selectValue: []
          }
        },
        endTime: {
          key: 'endTime',
          fieldEditProps: {
            initValue: resetInit.endTime,
            inputType: 'date'
          }
        },
        // functionCharacter: {
        //   label: "功能特性",
        //   fieldEditProps: {
        //     initValue: resetInit.functionCharacter,
        //     initName: resetInit.display.functionCharacter,
        //     selectValue: []
        //   }
        // },
        // source: {
        //   label: "缺陷来源",
        //   fieldEditProps: {
        //     initValue: resetInit.source,
        //     initName: resetInit.display.source,
        //     selectValue: []
        //   }
        // },
        // reproduceProbability: {
        //   label: "复现概率",
        //   fieldEditProps: {
        //     initValue: resetInit.reproduceProbability,
        //     initName: resetInit.display.reproduceProbability,
        //     selectValue: []
        //   }
        // }
      },
      // 字段默认值 - 通过 sessionStorage 获取
      sessionStorageData: {},
      customFieldObj: {}
    }
  },
  computed: {
    // 自定义字段 - 旧接口 - 缺陷来源、功能特性、复现概率、重打开原因、打回原因等自定义字段
    customFiledObjectVaues: function () {
      let arr = [];
      Object.keys(this.FIELDOBJECT).forEach(item => {
        arr = arr.concat(Object.values(this.FIELDOBJECT[item]));
      });
      this.updateModel();
      return arr;
    },
  },
  watch: {
    detailInfo() {
      this.initData();
    }
  },
  mounted() {
    this.initData()
  },
  methods: {
    // 初始化数据
    async initData() {
      this.setFieldEditObjectInitData();
      this.getSessionStorageData();
      // 如果是展示状态，延迟300ms再获取可选择的值，减少 http 请求的拥堵
      if(this.detailType === 'show') {
        await this.sleep(300);
      }
      this.getPriorityList();
      this.getAssignUsersList();
      this.getSpritList();
      this.getCauseList();
      this.getBasicCustomFiled(this.detailInfo);
    },
    // 获取严重程度
    async getPriorityList() {
      // 减少发起的请求，增加效率
      if(this.fieldEditObject.priority.fieldEditProps.selectValue.length > 0) {return ;}
      const result = await $http.get($http.api.bug_info.priorityList, {
        projectId: this.projectId, // 不用传 status
        workItemType: 3
      });
      if (result.status && result.status === 200) {
        this.fieldEditObject.priority.fieldEditProps.selectValue = result.data.map(item => {
          return {
            ...item,
            key: item.priority,
            value: item.literal
          }
        })
        this.fieldEditObject.priority.fieldEditProps.initValue = this.sessionStorageData.priority || resetInit.priority;
        this.updateModel();
      }
    },
    // 获取可指派人员列表
    async getAssignUsersList(query) {
      // 减少发起的请求，增加效率
      if(this.fieldEditObject.assignUser.fieldEditProps.selectValue.length > 0) {return ;}
      const result = await $http.post($http.api.bug_info.assignUsersList, {
        projectId: this.projectId,
        query: ''
      });
      if (result.status && result.status === 200) {
        this.fieldEditObject.assignUser.fieldEditProps.selectValue = result.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName  + "(" + item.userId + ")"
          }
        })
        this.fieldEditObject.assignUser.fieldEditProps.initValue = this.sessionStorageData.assignUser || $utils.getStorage(GLOBAL_CONST.USER_INFO).userId;
        this.updateModel();
      }
    },
    // 获取迭代列表
    async getSpritList() {// 减少发起的请求，增加效率
      if(this.fieldEditObject.sprint.fieldEditProps.selectValue.length > 0) {return ;}
      const result = await $http.get($http.api.bug_info.spritList, {
        projectId: this.projectId,
        status: 1
      });
      if (result.status && result.status === 200) {
        this.fieldEditObject.sprint.fieldEditProps.selectValue = result.data.map(item => {
          return {
            ...item,
            key: item.id,
            value: item.name
          }
        })
        this.fieldEditObject.sprint.fieldEditProps.initValue = this.sessionStorageData.sprintId || (result.data.length > 0 ? result.data[0].id : '');
        this.updateModel();
      }
    },
    // 获取原因列表
    async getCauseList() {// 减少发起的请求，增加效率
      if(this.fieldEditObject.cause.fieldEditProps.selectValue.length > 0) {return ;}
      const result = await $http.get($http.api.bug_info.causeList, {
        projectId: this.projectId
      });
      if (result.status && result.status === 200) {
        this.fieldEditObject.cause.fieldEditProps.selectValue = result.data.map(item => {
          return {
            ...item,
            key: item.cause,
            value: item.literal
          }
        })
        this.fieldEditObject.cause.fieldEditProps.initValue = this.sessionStorageData.cause || (result.data.length > 0 ? result.data[0].cause : '');
        this.updateModel();
      }
    },
    // 获取字段默认值 - sessionStorageData
    getSessionStorageData() {
      let sessionValues  = sessionStorage.getItem("LASTBUGCREATE");
      if(this.detailType === 'editable') { this.fieldEditObject.endTime.fieldEditProps.initValue = this.sessionStorageData.endTime || new Date(); }
      if(!sessionValues) {return ;}
      this.sessionStorageData = JSON.parse(sessionValues);
    },
    // 基本信息 - initvalue initName 初始值更新
    setFieldEditObjectInitData() {
      // this.detailInfo.display.detail.status.color = detailInfo.display.detail.status.color;
      // this.detailInfo.display.status = detailInfo.display.status;
      const detailInfo = this.detailInfo;
      // this.fieldEditObject.status.fieldEditProps.initValue = detailInfo.statusId;
      // this.fieldEditObject.status.fieldEditProps.initName = `<span class="statusbox-common" style="background-color: ${detailInfo.display.detail.status.color}">${detailInfo.display.status}</span>`;
      this.fieldEditObject.priority.fieldEditProps.initValue = detailInfo.priority;
      let font = (detailInfo.display.detail.priority.font && JSON.parse(detailInfo.display.detail.priority.font)) || {
        bold: false,
        size: "14"
      };
      this.fieldEditObject.priority.fieldEditProps.initName = `<span class="statusbox-common" style="background-color: ${
        detailInfo.display.detail.priority.color
        };">${detailInfo.display.priority}</span>`;
      this.fieldEditObject.assignUser.fieldEditProps.initValue =
        detailInfo.assignUser;
      this.fieldEditObject.assignUser.fieldEditProps.initName =
        detailInfo.display.assignUser;
      this.fieldEditObject.sprint.fieldEditProps.initValue =
        detailInfo.sprintId;
      this.fieldEditObject.sprint.fieldEditProps.initName =
        detailInfo.display.sprint;
      this.fieldEditObject.cause.fieldEditProps.initValue = detailInfo.cause;
      this.fieldEditObject.cause.fieldEditProps.initName = detailInfo.display.cause;
      this.fieldEditObject.endTime.fieldEditProps.initValue = detailInfo.endTime || '';
      this.fieldEditObject.endTime.fieldEditProps.initName = detailInfo.endTime || '';
      // this.fieldEditObject.reproduceProbability.fieldEditProps.initValue =
      //   detailInfo.reproduceProbability;
      // this.fieldEditObject.reproduceProbability.fieldEditProps.initName =
      //   detailInfo.display.reproduceProbability;
      // this.fieldEditObject.source.fieldEditProps.initValue = detailInfo.source;
      // this.fieldEditObject.source.fieldEditProps.initName =
      //   detailInfo.display.source;
      // this.fieldEditObject.functionCharacter.fieldEditProps.initValue =
      //   detailInfo.functionCharacter;
      // this.fieldEditObject.functionCharacter.fieldEditProps.initName =
      //   detailInfo.display.functionCharacter;
      this.updateModel();
    },
    // 固定字段 - 旧接口 - 通过 BugCustomFieldsMixin 来设置 缺陷来源、功能特性、复现概率、重打开原因、打回原因等固定字段
    getBasicCustomFiled(detailInfo, refresh) {
      let obj = { detailInfo };
      if (this.detailType === "editable") {
        obj.preload = true; // 预加载
        obj.setInitData = true; // 设置默认选择值
      }
      refresh && (obj.refresh = true);
      this.getCustomInfo(obj);
    },
    // 更新 v-model 值
    updateModel() {
      const modelObj = {
        userDefinedAttrs: this.customFieldObj
      };
      // 获取固定字段
      Object.values(this.fieldEditObject).forEach(item => {
        modelObj[item.key] = item.fieldEditProps.initValue;
      })
      // 获取旧接口的 FIXED 字段
      Object.keys(this.FIELDOBJECT.FIXED).forEach(item => {
        modelObj[item] = this.FIELDOBJECT.FIXED[item].fieldEditProps.initValue;
      });
      this.$emit('change', modelObj)
    },
    // last - 状态流转 - 展示扭转状态
    showActiveStatus(e, item) {
      this.$emit('showActiveStatus', e, item)
    }
  }
}
</script>
<style lang="scss" scoped>
@import "../ProjectCommon";

.bug-basic-info-item-input-box {
  display: inline-block;
  position: relative;
  height: 100%;
  box-sizing: border-box;
  padding: 0 5px;
}

.bug-basic-info-item {
  @extend .editable-common;
  font-size: $font-size-medium;
  &.bug-basic-info-item-select {
    padding: 5px 0;
  }
  // lable
  .bug-basic-info-item-label {
    display: inline-block;
    min-width: 90px;
    max-width: 100px;
    overflow: hidden;
    @extend .list-item-ellipsis;
  }
  // 非 field-edit 字段样式
  .bug-basic-info-item-static {
    display: inline-block;
    padding: 0 10px;
    max-width: calc(100% - 123px);
    @extend .list-item-ellipsis;
  }
  // 新建缺陷时才有的
  .bug-basic-info-item-select-width {
    max-width: calc(100% - 105px);
    overflow: hidden;
  }
  .basic-title-input-active {
    @extend .bug-basic-info-item-select-width;
  }
}
</style>
