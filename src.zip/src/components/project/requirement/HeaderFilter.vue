<template>
  <div class="header-fiter-box-comon" v-loading="getLoading" element-loading-text=" "
      element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
    <div class="header-filter-top-box">
      <el-form :inline="true">
        <el-form-item label="标题/ID" label-width="70px" class="header-filter-item">
          <el-input placeholder="标题/ID" class="header-filter-formitem-input" v-model="filterData.title"></el-input>
        </el-form-item>
        <el-form-item class="header-filter-item">
          <el-select  v-model="filterTypeValue" @change="customFilterChoose" placeholder="请选择过滤器">
            <el-option-group v-for="group in customFilterList" :key="group.label" :label="group.label">
              <el-option v-for="item in group.options" :key="item.key" :label="item.value" :value="item.key">
                <span :class="{'header-filter-item-option-label' : group.itemDetable}">{{item.value}}</span>
                <!-- <ellipsis-block @click="()=>{customFilterChoose(item.key)}" :value="item.value" :class="{'header-filter-item-option-label' : group.itemDetable}"></ellipsis-block> -->
                <span v-show="group.itemDetable" class="header-filter-item-option-delete cursor-pointer" @click.stop="filterDeleteClick(item)"><i class="el-icon-delete"></i></span>
              </el-option>
            </el-option-group>
          </el-select>
        </el-form-item>
        <el-form-item class="header-filter-item header-filter-operatebtns">
          <el-button type="primary" @click="filterClick">过滤</el-button>
          <el-button type="text" @click="filterStatusChange">{{isFilterOpen?'收起':'展开'}}过滤器</el-button>
          <el-button type="text" @click="filterSaveClick" v-show="isFilterOpen">保存过滤器</el-button>
        </el-form-item>
        <el-form-item class="header-filter-item header-filter-custombtns">
          <el-button
            type="primary"
            class="creatstyle new-button"
            v-show="authFunction('FUNC_COOP_REQT_CREATE', 3, projectId)"
            @click="onCreate"
          >创建需求</el-button>
          <el-dropdown>
            <el-button>
              导入/导出
              <i class="el-icon-arrow-down el-icon--right"></i>
            </el-button>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>
                <span @click="exportExcel">导出需求</span>
              </el-dropdown-item>
              <el-dropdown-item>
                <span @click="requirementModel">下载导入模板</span>
              </el-dropdown-item>
              <el-dropdown-item
                v-show="authFunction('FUNC_COOP_REQT_CREATE', 3, projectId)"
              >
                <el-upload
                  :action="importObject.importUrl"
                  :data="importObject.importData"
                  :show-file-list="false"
                  :on-success="uploadSuccess"
                  multiple
                  :on-exceed="handleExceed"
                >
                  <span
                    type="primary"
                    v-show="authFunction('FUNC_COOP_REQT_CREATE', 3, projectId)"
                  >导入需求</span>
                </el-upload>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </el-form-item>
      </el-form>
    </div>
    <div class="header-filter-content" :class="{'header-filter-hidden': !isFilterOpen}">
      <!-- 隐藏起来的过滤器 -->
      <el-form :inline="true">
        <el-form-item label="处理人" label-width="70px" class="header-filter-item">
          <select-filter v-model="filterData.assignUsers" multiple @change="(value)=>{handleSelectChange(value, 'assignUsers')}"
            :selectList="assignUserFilterList" placeholder="处理人">
            <el-option label="全部" value="all" slot></el-option>
          </select-filter>
        </el-form-item>
        <el-form-item label="优先级" label-width="70px" class="header-filter-item">
          <el-select placeholder="优先级" multiple v-model="filterData.priorities"
            @change="(value)=>{handleSelectChange(value, 'priorities')}" :collapse-tags="false">
            <el-option label="全部" value="all">
              <span class="mini-circle" :style="{backgroundColor: 'transparent'}"></span>全部
            </el-option>
            <el-option :label="item.literal" :value="item.priority" v-for="(item, index) in prioritiesFilterList"
              :key="index">
              <span v-html="initNameStatus(item.color,item.literal)"></span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="关联迭代" label-width="70px" class="header-filter-item">
          <sprint-multiple-select v-model="filterData.sprintIds" :selectAllInit="false" :panelWidth="200" @recordFun='recordFun'></sprint-multiple-select>
        </el-form-item>
        <el-form-item label="状态" label-width="70px" class="header-filter-item">
          <el-select placeholder="状态" multiple v-model="filterData.statusIds" @change="(value)=>{handleSelectChange(value, 'statusIds')}">
            <el-option label="全部" value="all"><span class="mini-circle" :style="{backgroundColor: 'transparent'}"></span>全部</el-option>
            <el-option :label="item.statusName" :value="item.statusId" v-for="(item, index) in statusFilterList" :key="index">
              <span v-html="initNameStatus(item.color,item.statusName)"></span>
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建人" label-width="70px" class="header-filter-item">
          <select-filter v-model="filterData.createUsers" multiple @change="(value)=>{handleSelectChange(value, 'createUsers')}"
            :selectList="assignUserFilterList" placeholder="创建人">
            <el-option label="全部" value="all" slot></el-option>
          </select-filter>
        </el-form-item>
        <el-form-item label="创建时间" label-width="70px" class="header-filter-item">
          <custom-date v-model="filterData.createTimes" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"></custom-date>
        </el-form-item>
        <el-form-item label="父需求" label-width="70px" class="header-filter-item">
          <select-filter v-model="filterData.parentRequireIds" multiple @change="(value)=>{handleSelectChange(value, 'parentRequireIds')}"
            :selectList="requirementFilterList" placeholder="父需求">
            <el-option label="全部" value="all" slot>全部</el-option>
          </select-filter>
        </el-form-item>
        <el-form-item label="开始时间" label-width="70px" class="header-filter-item">
          <custom-date v-model="filterData.startTimes" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"></custom-date>
        </el-form-item>
        <el-form-item label="结束时间" label-width="70px" class="header-filter-item">
          <custom-date v-model="filterData.endTimes" type="daterange" range-separator="至" start-placeholder="开始日期" end-placeholder="结束日期"></custom-date>
        </el-form-item>
        <!-- <el-form-item label="关注人" label-width="70px" class="header-filter-item">
          <select-filter v-model="filterData.relevantUsers" multiple @change="(value)=>{handleSelectChange(value, 'relevantUsers')}"
            :selectList="assignUserFilterList" placeholder="创建人">
            <el-option label="全部" value="all" slot></el-option>
          </select-filter>
        </el-form-item> -->

        
        <!-- 固定字段 -->
        <!-- <template v-for="item in fixedFieldValues">
          <el-form-item class="header-filter-item" :key="item.key">
            <span slot="label" class="header-filter-item-label">{{item.label}}</span>
            <el-select v-if="item.choice" multiple v-model="filterData[item.key + 's']"
              @change="(value)=>{handleSelectChange(value, item.key + 's', false)}" :collapse-tags="false">
              <el-option label="全部" value="all"></el-option>
              <el-option :label="jtem.fieldDisplay" :value="jtem.fieldValue"
                v-for="jtem in item.fieldEditProps.selectValue" :key="jtem.fieldValue"></el-option>
            </el-select>
            <el-input v-if="!item.choice" class="header-filter-formitem-input" :placeholder="item.label"
              v-model="filterData[item.key]"></el-input>
          </el-form-item>
        </template> -->
        <!-- 自定义字段 -->
        <template v-for="item in selectedCUSTOMFIELDVALUES">
          <el-form-item class="header-filter-item" :key="item.key">
            <span slot="label" class="header-filter-item-label">{{item.value}}</span>
            <typed-form-item
              class="bug-basic-info-item-select-width"
              v-model="filterData.userDefinedAttrs[item.key]"
              :type="item.attrValue === 'LITE_DATE_ATTR' ? 'LITE_DATE_RANGE_ATTR' : item.attrValue"
              :selectList="item.fieldEditProps.selectValue"
              :filterField="true"></typed-form-item>
          </el-form-item>
        </template>
        <el-form-item class="header-filter-item">
          <span class="header-button-more">
            <field-edit v-bind="FieldEditProps" v-if="isFilterOpen"></field-edit>
          </span>
        </el-form-item>
      </el-form>
    </div>
    <el-dialog
      title="保存过滤器"
      :visible.sync="filterSaveDialog.status"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      width="400px"
    >
      <el-form :inline="true" @submit.native.prevent>
        <el-form-item class="header-input" label="过滤器名称">
          <el-input placeholder="请输入过滤器名称" :style="{width: '270px'}" v-model.trim="filterSaveDialog.name"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose">取 消</el-button>
        <el-button type="primary" @click="postFilterCustomInfo">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 任务顶部过滤器
 * @desc 
 * @author heyunjiang
 * @date 
 */


import SprintMultipleSelect from "@/components/commonComponents/SprintMultipleSelect";
import FieldEdit from "@/components/tool/FieldEdit";
import ProjectCommonMixin from "../ProjectCommonMixin";
import FilterCommonMixin from "../FilterCommonMixin";

export default {
  name: "HeaderFilter",
  components: {
    SprintMultipleSelect,
    FieldEdit
  },
  mixins: [ProjectCommonMixin, FilterCommonMixin],
  props: {},
  data() {
    return {
      workItemType: 1,
      // 过滤器表单
      filterData: {
        title: '',
        sprintIds: [],
        assignUsers: [],
        parentRequireIds: [],
        statusIds: [],
        priorities: [],
        createUsers: [],
        createTimes: [],
        startTimes: [],
        endTimes: [],
        // relevantUsers: [],
        userDefinedAttrs: {}
      },
      importObject: {
        importUrl: $http.api.requirement.requirement_import.url,
        importData: {
          projectId: this.projectId
        }
      },
    }
  },
  computed: {},
  watch: {},
  mounted() {
    this.initData();
  },
  methods: {
    // 点击过滤
    filterClick() {
      
      this.$emit('onSubmit', this.copyFilterDataRemoveAll(this.filterData))
    },
    // 点击 - 创建需求
    onCreate() {
      this.$emit('onCreate');
    },
    // 点击 - 下载导入模板
    requirementModel() {
      this.$emit('requirementModel');
    },
    // 点击 - 导出需求
    exportExcel() {
      this.$emit('exportExcel', this.formInline);
    },
    // 上传成功
    uploadSuccess(res) {
      if (res.status === 200) {
        this.$message({ type: 'success', message: res.msg || '上传成功' })
        // this.init();
        this.$emit('uploadSuccess');
      } else {
        this.$message({ type: 'error', message: res.msg || '上传失败' })
      }
    },
    handleExceed() { },
    //判断已归档还是未归档
    recordFun(val){
      // console.log(val)
      this.$emit('sprintTypeFun', val)
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '../ProjectCommon';
  .header-filter-item-option-label {
    display: inline-block;
    height: auto;
    width: calc(100% - 30px);
    vertical-align: top;
  }
  .header-filter-item-option-delete {
    padding: 0 3px;
    &:hover {
      color: #409EFF;
    }
  }
</style>
