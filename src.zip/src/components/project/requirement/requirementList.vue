<template>
  <div id="demandlist" class="content-outer-box">
    <slide :show="show" @click.stop ref="side" :afterClose="contextmenuNone"
      :beforeClose="({cb}) => beforeSliderClose({ id: newviewShow ? -1 : requireId, cb })" v-loading="loading"
      element-loading-text="拼命加载中" element-loading-spinner="el-icon-loading"
      element-loading-background="rgb(255,255,255)">
      <div slot="task" class="silder-box">
        <new-view v-if="newviewShow" :currentCategoryId="currentCategoryId" v-on:HandleSide="contextmenuNone"
          :titleNotice.sync="sliderBeforeCloseData.title" :descNotice.sync="sliderBeforeCloseData.desc"
          :restore="restore" :projectId="rootNode.projectId" :projectTitleName="projectName"></new-view>
        <demand-view :projectId="rootNode.projectId" :requireId="requireId" :show="show" :restore="restore"
          v-on:HandleSide="contextmenuNone" :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc" v-if="!viewShow" @updateInfoSuccess="getTreeTable">
        </demand-view>
      </div>
    </slide>
    <div id="menu" v-show="isShow" ref="menu" style="z-index: 4;">
      <div class="menu cursor-pointer" v-show="activeCategoryEditShowId!==-1" @click="dialogHandle($event,1)">创建分类</div>
      <div class="menu cursor-pointer" @click="dialogHandle($event,2)">创建子分类</div>
      <div class="menu cursor-pointer" v-show="activeCategoryEditShowId!==-1" @click="dialogHandle($event,3)">修改分类</div>
      <div class="menu cursor-pointer" v-show="activeCategoryEditShowId!==-1" @click="dialogHandle($event,4)">删除分类</div>
    </div>
    <div class="x-arD content-box">
      <div class="form-area mb10">
        <header-filter :projectId="formInline.projectId" @onCreate="onCreate" @exportExcel="exportExcel"
          @requirementModel="requirementModel" @onSubmit="onSubmit" @uploadSuccess="getTreeTable" @sprintTypeFun='sprintTypeFun' ></header-filter>
      </div>
      <div class="demand-classification" ref="boxTop">
        <two-block-width-changer :initLeftWidth="200" fixedLeft barType='tiny'>
          <div slot="left">
            <div class="demand-classification-left fl demand-treeicon">
              <div class="null">
                <h3 class="ml10" @contextmenu.prevent="onMousnextHandle($event)">需求分类</h3>
              </div>
              <el-tree @node-click="HandleNode" :data="listData" lable="name" node-key="id" default-expand-all
                render-after-expand :expand-on-click-node="false" :draggable="true" :allow-drag="allowDrag"
                @node-drop="finalNodeDrag"
                style="background-color:#f1f1f1; width: 100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"
                :render-content="renderContent">
                <span></span>
              </el-tree>
            </div>
          </div>
          <div class="demand-classification-right" ref="list" slot="right">
            <span class="cursor-pointer c-blue" @click="addFatherRquire">+快速创建需求</span>
            <tree-table @seeTaskHandle="seeTaskHandle" @updataTitle="getCreateTitle" :data="treeData" :eval-args="args"
              @cancleCreateRequire="cancleRequire" :expand-all="expandAll" :ltype="1" :isChecked="false" border
              :sortaChangeCallBack="sortaChangeCallBack" :class="{'tree-table-left-none':treeData.length == 0}"
              id="requlist"
              :updateGlobalTitle="(info, value)=>{GlobalRequirementUpdate({id: info.id, title: value, projectId: info.projectId || this.getUrlParams().projectId, cb: getTreeTable})}">
              <el-table-column label="优先级" prop="priority" sortable="custom" width="90">
                <template slot-scope="scope">
                  <span class="cursor-pointer" v-if="!scope.row.isNewAdd"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'priority', getTreeTable)">
                    <span v-if="!scope.row.isNewAdd"
                      v-html="initNameStatus(scope.row.display.detail.priority.color,scope.row.display.detail.priority.literal)"></span>
                  </span>
                  <el-select v-if="scope.row.isNewAdd" v-model="sendRqueireInfo.priority">
                    <el-option :label="data.value" :value="data.key" v-for="(data,index) in priorityList" :key="index">
                      <template slot-scope="scope">
                        <span style="float: left">
                          <span class="mini-circle" :style="{backgroundColor:data.color}"></span>
                          {{data.literal}}
                        </span>
                      </template>
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column label="迭代" prop="sprintId" sortable="custom" show-overflow-tooltip min-width="80">
                <template slot-scope="scope">
                  <span class="cursor-pointer table-column-padding" v-if="!scope.row.isNewAdd"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'sprintId', getTreeTable)">{{scope.row.display.sprint || '--'}}</span>
                  <el-select v-if="scope.row.isNewAdd" placeholder="请选择项目迭代" style="width:100%;"
                    v-model="sendRqueireInfo.sprintId">
                    <el-option v-for="item in sprintList" :key="item.id" :label="item.value" :value="item.key">
                    </el-option>
                  </el-select>
                </template>
              </el-table-column>
              <el-table-column label="状态" prop="statusId" sortable="custom" show-overflow-tooltip width="80">
                <template slot-scope="scope">
                  <span class="cursor-pointer" @click="showActiveStatus($event,scope.row)" v-if="!scope.row.isNewAdd"
                    v-html="initNameStatus(scope.row.display.detail.status.color,scope.row.display.status)">
                  </span>
                </template>
              </el-table-column>
              <el-table-column label="处理人" prop="assignUser" sortable="custom" width="160" show-overflow-tooltip>
                <template slot-scope="scope">
                  <span class="cursor-pointer" v-if="!scope.row.isNewAdd"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'assignUser', getTreeTable)">{{scope.row.display.assignUser}}
                    ({{scope.row.assignUser}})</span>
                  <select-filter v-model="sendRqueireInfo.assignUser" :selectList="assignUserData"
                    v-if="scope.row.isNewAdd"></select-filter>
                </template>
              </el-table-column>
              <el-table-column label="需求分类" prop="categoryId" sortable="custom" show-overflow-tooltip width="100">
                <template slot-scope="scope">
                  <span class="cursor-pointer" v-if="!scope.row.isNewAdd"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'categoryId', getTreeTable)">{{scope.row.display.category}}</span>
                  <span class="cursor-pointer c-blue" v-if="scope.row.isNewAdd" @click="saveRequir">保存</span>
                  <span class="cursor-pointer c-blue" v-if="scope.row.isNewAdd"  @click="cancleRequire">取消</span>
                </template>
              </el-table-column>

              <el-table-column label="预计开始时间" prop="startTime" sortable="custom" show-overflow-tooltip width="125">
                <template slot-scope="scope">
                  <global-input :initValue="scope.row.startTime || ''" inputType="time" v-if="!scope.row.isNewAdd"
                    :onChange="(value)=>{GlobalRequirementUpdate({startTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTreeTable})}">
                    <span slot>{{scope.row.startTime || '--'}}</span>
                  </global-input>
                  <!-- <custom-date style="width: 100px;" v-if="scope.row.isNewAdd" v-model="createRequireInfo.startTime">
                  </custom-date> -->
                </template>
              </el-table-column>
              <el-table-column label="预计结束时间" prop="endTime" sortable="custom" show-overflow-tooltip width="125">
                <template slot-scope="scope">
                  <global-input :initValue="scope.row.endTime || ''" inputType="time" v-if="!scope.row.isNewAdd"
                    :onChange="(value)=>{GlobalRequirementUpdate({endTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTreeTable})}">
                    <span slot>{{scope.row.endTime || '--'}}</span>
                  </global-input>
                  <!-- <custom-date style="width: 100px;" v-if="scope.row.isNewAdd" v-model="createRequireInfo.endTime">
                  </custom-date> -->
                </template>
              </el-table-column>
            </tree-table>
          </div>
        </two-block-width-changer>
      </div>
    </div>
    <!--自定义右键菜单html代码-->
    <el-dialog :title="title" :visible.sync="centerDialogVisible" width="20%" center>
      <el-form v-if="dialogStatus!==4" @submit.native.prevent>
        <el-form-item label="分类名称" label-width="80px" class="mt15">
          <el-input v-model="classificationName" placeholder="请输入标题"></el-input>
        </el-form-item>
      </el-form>
      <div v-if="dialogStatus==4">确定删除该分类?</div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="sureSendHandle()" class="fr">确 定</el-button>
        <el-button @click="centerDialogVisible = false" class="fr mr10">取 消</el-button>
      </div>
    </el-dialog>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
    <custom-status v-if="statusShow" :statusHeight="showStausObj.statusHeight" :statusleft="showStausObj.statusleft"
      :projectId="formInline.projectId" :statusId="showStausObj.statusId" :workItemType="showStausObj.workItemType"
      :workItemId="showStausObj.workItemId" @closeStatus="closeStatus" :updateData="getTreeTable"></custom-status>
  </div>
</template>

<script>
  import DemandView from "./requirementView.vue";
  import HeaderFilter from "./HeaderFilter"
  import NewView from "./newrequirementView.vue";
  import TreeTable from "@/components/tool/TreeTable";
  import TwoBlockWidthChanger from "@/components/tool/TwoBlockWidthChanger";
  import slide from "@/components/tool/slideSlip";
  import GlobalSelect from "@/components/tool/FieldEdit/GlobalSelect.vue";
  import GlobalInput from "../../tool/FieldEdit/GlobalInput.vue";
  import ProjectCommonMixin from "@/components/project/ProjectCommonMixin";
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import EllipsisBlock from "@/components/commonComponents/EllipsisBlock";
  let RESETSENDREQUIRE = {
    priority: 80,
    sprintId: '',
    title: "",
    assignUser: '',
    categoryId: 0,
    innerProject: true,
    content: "",
  }
  let RESETINFO = {
    isNewAdd: true,
    priority: 80,
    startTime: "",
    id: 0,
    endTime: "",
    display: {
      title: "",
      status: "",
      assignUser: "",
    },
    assignUser: '',
    progress: null,
    sprintId: '',
    statusId: "",
    categoryId: 2,
    children: [],
    contentId: 1,
    createTime: ''
  }
  export default {
    name: "requirementList",
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    data() {
      return {
        viewShow: true,
        newviewShow: false,
        visible2: false,
        projectName: " ",
        mineId: null,
        title: "创建分类名称",
        classificationName: null,
        parentId: null,
        isShow: false,
        args: [null, null, "timeLine"],
        centerDialogVisible: false,
        expandAll: true,
        data: [],
        dialogStatus: 1,
        formInline: {
          projectId: this.getUrlParams().projectId,
          title: null,
          assignUsers: [],
          isArchived: 0,
          sprintIds: [],
          statusIds: [],
          priorities: [],
          categoryIds: [],
          custom: {},
          orderBy: [
            {
              column: "createTime",
              order: "DESC"
            }
          ]
        },
        listData: [],
        rootNode: [
          {
            id: -1,
            label: "全部分类",
            name: "全部分类",
            parentId: 0,
            projectId: this.getUrlParams().projectId,
            children: Array
          }
        ],
        treeData: [],

        //侧滑栏参数
        count: 0, //计数器为了保村上一次的Id
        restore: 1,
        preID: null, //记录上一次的ID
        show: false,
        requireId: null,
        loading: false,
        activeCategoryEditShowId: -1, // 左側需求分類當前選中項 0->未分類 -1 -> 全部分類
        showStausObj: {},//状态数据
        statusShow: false,//状态展示
        currentCategoryId: "",//当前的分类ID
        createRequireInfo: {
          status: false,
          ...RESETINFO
        },
        // 快速创建需求数据对象
        sendRqueireInfo: {
          ...RESETSENDREQUIRE
        },
        priorityList: [],//优先级列表
        sprintList: [],//迭代列表
        assignUserData: [],//处理人
      };
    },
    mounted() {
      this.init();
      this.getTreeTable();
      this.isRqeuirementId = {
        id: this.getUrlParams().requireId
      };
      if (this.isRqeuirementId.id) {
        this.seeTaskHandle(this.isRqeuirementId);
      }
      // 获取自定义字段列表
      this.getCustomFieldList(1, this.getUrlParams().projectId);
    },
    components: {
      TreeTable,
      DemandView,
      NewView,
      slide,
      GlobalSelect,
      GlobalInput,
      EllipsisBlock,
      TwoBlockWidthChanger,
      HeaderFilter
    },
    show: function (newName, oldName) {
      if (newName !== true) {
      }
    },
    beforeRouteLeave(to, from, next) {
      // 如果存在内容在编辑，则不能离开
      if (this.sliderBeforeCloseData.title || this.sliderBeforeCloseData.desc) {
        return false;
      }
      next()
    },
    methods: {
      //获取迭代过滤器类型
      sprintTypeFun(val){
        this.formInline.isArchived = val;
        // console.log('isArchived',val)
        this.formInline.sprintIds = this.formInline.sprintIds.filter(item => item !== -3);
      },
      //获取自定义模板内容
      queryDescTmpl() {
        $http.get($http.api.work_status_fow.descTmpl_query, { projectId: this.projectId, workItemType: 1 }).then((res) => {
          this.sendRqueireInfo.content = res.data.template;
        })
      },
      //取消快速创建
      cancleRequire() {
        if (this.createRequireInfo.status) {
          this.treeData.shift()
          this.createRequireInfo.status = false;
          this.sendRqueireInfo = { ...RESETSENDREQUIRE }
        }
      },
      //快速保存需求
      saveRequir() {
        if (!this.sendRqueireInfo.title) {
          this.$message({ type: "warning", message: "需求标题不能为空" })
          return
        }
        this.sendRqueireInfo.projectId = this.getUrlParams().projectId;
        this.sendRqueireInfo.categoryId = this.currentCategoryId;
        // 获取自定义字段的默认值对象
        $http.post($http.api.requirement.create, {
          ...this.sendRqueireInfo,
          ...this.getCustomFieldsPresetValues(1)
        }).then(ret => {
          if (ret.status === 200) {
            this.$message({ message: ret.msg || "添加需求成功", type: "success" });
            this.getTreeTable();
            this.createRequireInfo.status = false;
            this.createRequireInfo = {
              ...RESETINFO
            }
            this.sendRqueireInfo = { ...RESETSENDREQUIRE }
          } else {
            this.$message({ message: ret.msg || "添加需求失败", type: "error" });
          }
        });
      },
      //获取用户输入的需求标题
      getCreateTitle(data) {
        this.sendRqueireInfo.title = data;
      },
      //获取用户
      getAssignUser(value) {
        let projectId = this.getUrlParams().projectId || this.projectId;
        let query = value || null;
        $http
          .post($http.api.project.assignUser, { projectId, query })
          .then(res => {
            this.assignUserData = res.data.map(item => {
              return {
                key: item.userId,
                value: item.userName + "(" + item.userId + ")"
              };
            });
          });
      },
      //获取迭代列表
      getSprintList() {
        $http
          .get($http.api.sprint.list_sprint_name, {
            projectId: this.getUrlParams().projectId || this.projectId,
            status: 1
          })
          .then(res => {
            if (res.status == 200) {
              this.sprintList = res.data.map(item => {
                return {
                  value: item.name,
                  key: item.id,
                  id: item.id
                };
              });
              this.sprintList.unshift({
                key: 0,
                value: "未规划"
              });
            }
          });
      },
      //获取优先级
      getPriorityList() {
        let projectId = this.getUrlParams().projectId || this.projectId;
        $http
          .get($http.api.bug_info.priorityList, { projectId, workItemType: 1 })
          .then(res => {
            this.priorityList = res.data.map(item => {
              return {
                value: item.literal,
                key: item.priority,
                color: item.color,
                ...item
              };
            });
          });
      },
      //快去创建需求
      addFatherRquire() {
        if (this.createRequireInfo.status) {
          this.$message({ type: 'warning', message: '一次性只能创建一条需求' })
          return
        }
        this.treeData.unshift(this.createRequireInfo);
        this.getPriorityList();
        this.getSprintList();
        this.getAssignUser();
        this.createRequireInfo.status = true;
      },
      //拖拽完之后的回调
      finalNodeDrag(node, lnode, type, event) {
        console.log(lnode, type)
        if (node.level <= lnode.level) {
          this.id = node.key;
          this.targetId = lnode.key;
          if (type == 'inner' && lnode.key === 0) {
            this.$message({ type: "error", message: "不能拖动到未分类之下" })
            this.getRequirementCategory()
            this.getTreeTable()
            return
          }
        }
        if (node.level > lnode.level) {
          this.id = node.key;
          this.targetId = lnode.parent.key;
          if (lnode.key === -1) {
            this.$message({ type: "error", message: "不能拖到全部分类之外" })
            this.getRequirementCategory()
            this.getTreeTable()
            return
          }
        }
        $http.get($http.api.requirementCategory.change, { id: this.id, targetId: this.targetId }).then(res => {
          if (res.status === 200) {
            this.$message({ type: 'success', message: "更改成功" })
            this.getRequirementCategory()
            this.getTreeTable()
          } else {
            this.$message({ type: 'error', message: res.msg })
            this.getRequirementCategory()
            this.getTreeTable()
          }
        })

      },
      //禁止拖拽
      allowDrag(node) {
        // console.log(node)
        if (node.key === -1 || node.key === 0) {
          return false;
        } else {
          return true;
        }
        // if ( node.level && node.level ===node.previousSibling.level ) {
        //   return true;
        // }
        // if( node.level && node.level == node.nextSibling.level&& node.nextSibling.key !==0){
        //   return true;
        // }
      },
      offsetLeft(obj) {
        var tmp = obj.offsetLeft;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetLeft;
          val = val.offsetParent;
        }
        return tmp;
      },
      offsetTop(obj) {
        var tmp = obj.offsetTop;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetTop;
          val = val.offsetParent;
        }
        return tmp;
      },
      //关闭状态框
      closeStatus() {
        this.statusShow = false;
      },
      //展示扭转状态
      showActiveStatus(e, item) {
        if (document.getElementById("main-content").offsetHeight - this.offsetTop(e.target) > 408) {
          this.showStausObj.statusHeight = this.offsetTop(e.target) - 12 + 'px';
          this.showStausObj.statusleft = this.offsetLeft(e.target) - 400 + 'px';
        } else if (document.getElementById("main-content").offsetHeight - this.offsetTop(e.target) < 408 && document.getElementById("main-content").offsetHeight > document.body.clientHeight) {
          this.showStausObj.statusHeight = this.offsetTop(e.target) - 480 + 'px';
          this.showStausObj.statusleft = this.offsetLeft(e.target) - 400 + 'px';
        }
        this.showStausObj.statusId = item.statusId;
        this.showStausObj.workItemType = 1;
        this.showStausObj.workItemId = item.id;
        this.statusShow = !this.statusShow;
        if (this.showStausObj.workItemId && this.showStausObj.temId !== item.id) {
          this.statusShow = true;
        }
        this.showStausObj.temId = item.id;
        e.stopPropagation()
      },
      // 下载模板
      requirementModel() {
        let projectId = this.getUrlParams().projectId;
        let url = $http.api.requirement.requirement_model.url + '?projectId=' + projectId
        window.open(url, '_blank');
      },
      // 导出 excel
      exportExcel(formInline) {
        let projectId = this.getUrlParams().projectId;
        formInline = {
          ...this.formInline,
          ...formInline
        };
        for (let i in formInline) {
          if (Array.isArray(formInline[i]) && formInline[i].length > 0) {
            if (formInline[i] == "all") {
              formInline[i] = [];
            }
          }
        }
        this.fileDownLoadForGet($http.api.requirement.requirement_export.url, formInline, { projectId })
      },
      sortaChangeCallBack(obj) {
        if (obj.prop) {
          this.formInline = {
            ...this.formInline,
            orderBy: [
              {
                column: obj.prop,
                order: obj.order === "descending" ? "DESC" : "ASC"
              }
            ]
          }
        } else {
          this.formInline = {
            ...this.formInline,
            orderBy: []
          }
        }
        this.$nextTick(this.getTreeTable);
      },

      //新建需求
      onCreate() {
        this.seeTaskHandle("");
      },
      //需求分类编辑
      renderContent(h, { node, data, store }) {
        let name = data.name
        let label = ""
        if (node.label.indexOf('(') !== -1) {
          label = node.label.substr(node.label.indexOf('('), node.label.length - 1)
        }
        return (
          <div
            class="iconmorebox"
            on-click={() => this.iconmoreEvent(node, data, event)}>
            <EllipsisBlock class="font-ellipsis" on-click={() => this.iconmoreEvent(node, data, event)} value={name}>
              <span class="cursor-pointer">{name}</span>
            </EllipsisBlock>
            <span>{label}</span>
            {data.id !== 0 && (
              <div class="iconmore">
                <i class="iconfont icon-operate" />
              </div>
            )}
          </div>
        );
      },
      // 点击需求分类
      iconmoreEvent(node, data, ev) {
        if (data.id === -1) {
          this.currentCategoryId = 0;
        } else {
          this.currentCategoryId = data.id;
        }
        if (ev.target.className.indexOf("iconfont icon-operate") !== -1) {
          this.onMousnextHandle1(ev, data, node);
          return;
        }
        this.formInline = {
          ...this.formInline,
          categoryIds: data.id === -1 ? [] : [data.id]
        }
        // this.categoryIds(data);

        this.isShow = false;
        this.getTreeTable();
      },
      // 需求分类编辑 - 展示tool-tip
      renderToolTipEvent() { },
      //子分类请求 - 废弃
      categoryIds(data) {
        if (data.id != -1) {
          // this.$set(this.formInline, categoryIds, [...this.formInline.categoryIds, data.id])
          this.formInline.categoryIds.push(data.id);
          for (let i = 0; i < data.children.length; i++) {
            // this.$set(this.formInline, categoryIds, [...this.formInline.categoryIds, data.children[i].id])
            this.formInline.categoryIds.push(data.children[i].id);
            if (data.children[i].children.length > 0) {
              this.categoryIds(data.children[i]);
            }
          }
        }
      },

      //侧滑栏打开
      seeTaskHandle(data, e) {
        this.projectName = document.getElementById("h3-inlineName").innerHTML;
        this.viewShow = !data.id;
        if (!data) {
          this.newviewShow = true;
        }
        this.$nextTick(() => {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
          }, 500);
        });

        if (this.count === 0) {
          this.preID = data.id;
          this.show = !this.show;
          this.requireId = data.id;

          this.restore = Math.random() * 10;
          this.count++;
        } else {
          if (this.preID !== data.id) {
            this.preID = data.id;
            // this.show = !this.show;
            this.requireId = data.id;
            this.restore = Math.random() * 10;
          } else {
            this.restore = Math.random() * 10;
            this.preID = data.id;
            this.count = 0;
            this.show = !this.show;
            this.requireId = data.id;
          }
        }
      },
      // 获取需求分类
      init() {
        this.queryDescTmpl();
        //先获取需求分类
        let projectId = this.getUrlParams().projectId;
        $http.get($http.api.requirementCategory.tree, { projectId }).then(res => {
          //todo cpp 这里应该获取自己的queryType=1

          this.rootNode[0].children = [];
          res.data.forEach(node => {
            this.rootNode[0].children.push(node);
          });
          this.listData = this.rootNode;

          //再获取需求数据和各分类的统计数据
          this.getTreeTable();
        });
      },
      // 在滑窗关闭后的回调
      contextmenuNone(e) {
        if (this.show) {
          this.show = false;
          this.count = 0;
          this.restore = Math.random() * 10;
        }
        this.requireId = -1; // 清除保存的需求 id，保证再次点击相同的需求，可以更新数据 add by heyunjiang on 2019.8.1
        this.newviewShow = e;
        this.isShow = false;
        this.getTreeTable();
      },

      //点击节点事件
      HandleNode(data, node, self) { },

      //更改弹窗提示语
      dialogHandle(e, index) {
        this.centerDialogVisible = true;
        this.dialogStatus = index;
        if (this.dialogStatus === 1) {
          this.title = "创建的分类名称";
        } else if (this.dialogStatus === 2) {
          this.title = "创建的子分类的名称";
        } else if (this.dialogStatus === 3) {
          this.title = "修改的名称分类名称";
        } else if (this.dialogStatus === 4) {
          this.centerDialogVisible = false;
          this.$confirm(`确定删除该分类？`, {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          })
            .then(async () => {
              const result = await this.deleteRequirementCategory();
              if (result.status === 200) {
                this.$message({
                  message: res.msg || "需求删除成功",
                  type: "success"
                });
                // 关闭当前 slider
                this.bugClose();
              } else {
                this.$message({
                  message: result.msg || "需求删除失败",
                  type: "warning"
                });
              }
            })
            .catch(e => { });
          this.title = "删除分类";
        }

        this.isShow = false;
      },
      onMousnextHandle(e) {
        e.preventDefault();
        this.$refs.menu.style.left = e.clientX - 130 + "px";
        this.$refs.menu.style.top = e.clientY - 80 + "px";
        this.parentId = null;

        this.isShow = true;
      },
      onMousnextHandle1(e, data, node) {
        e.preventDefault();
        document.getElementById("menu").style.display = "block";
        this.$refs.menu.style.left = e.clientX - 30 + "px";
        this.$refs.menu.style.top = e.clientY - 5 + "px";
        this.parentId = data.parentId;
        this.activeCategoryEditShowId = node.data.id;
        this.mineId = data.id;
        this.isShow = true;
      },
      sureSendHandle() {
        this.centerDialogVisible = false;
        if (this.dialogStatus === 1) {
          this.addRequirementCategory();
        } else if (this.dialogStatus === 2) {
          this.parentId = this.mineId;
          this.addRequirementCategory();
        } else if (this.dialogStatus === 3) {
          this.modifyRequirementCategory();
        } else {
          this.deleteRequirementCategory();
        }
        this.getTreeTable();
      },
      // 点击过滤
      onSubmit(formInline) {
        this.formInline = {
          ...this.formInline,
          ...formInline
        }
        this.getTreeTable();
      },
      getRequirementCategory() {
        let projectId = this.getUrlParams().projectId;
        $http.get($http.api.requirementCategory.tree, { projectId }).then(res => {
          //todo cpp 这里应该获取自己的queryType=1
          // this.listData = [];
          this.rootNode = [
            {
              id: -1,
              label: "全部分类",
              name: "全部分类",
              parentId: 0,
              projectId: this.getUrlParams().projectId,
              children: []
            }
          ];
          // this.rootNode[0].children = [];
          res.data.forEach(node => {
            this.rootNode[0].children.push(node);
          });
          this.listData = this.rootNode;
        });
      },
      addRequirementCategory() {
        let projectId = this.getUrlParams().projectId;
        $http
          .post($http.api.requirementCategory.create, {
            projectId: projectId,
            name: this.classificationName,
            parentId: this.parentId
          })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1
            this.classificationName = null;
            this.getRequirementCategory();
            this.getTreeTable();
          });
      },
      deleteRequirementCategory() {
        $http
          .get($http.api.requirementCategory.delete, {
            id: this.mineId
          })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1
            this.classificationName = null;
            this.getRequirementCategory();
            this.getTreeTable();
          });
      },
      modifyRequirementCategory() {
        $http
          .post($http.api.requirementCategory.modify, {
            name: this.classificationName,
            id: this.mineId
          })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1
            this.classificationName = null;
            this.getRequirementCategory();
            this.getTreeTable();
          });
      },
      getTreeTable() {
        //this.formInline.projectId = this.getUrlParams().projectId;
        let formInline = {};
        let projectId = this.getUrlParams().projectId;
        Object.assign(formInline, this.formInline)
        for (let i in formInline) {
          if (Array.isArray(formInline[i]) && formInline[i].length > 0) {
            if (formInline[i] == "all") {
              formInline[i] = [];
            }
          }
        }
        formInline.sprintIds = formInline.sprintIds.filter(item => [-1,-2,-3,-4,-5].indexOf(item)==-1);
        $http.post($http.api.requirement.demandTree, formInline).then(res => {
          //todo cpp 这里应该获取自己的queryType=1
          this.treeData = res.data.result;
          this.createRequireInfo.status = false;
          this.refreshCategoryData(res.data.summary);
        });
      },
      refreshCategoryData(summaryData) {
        let rootCount = this.processCategoryNodeIterator(
          this.listData[0],
          summaryData
        );
        this.listData[0].label = this.listData[0].name + "(" + rootCount + ")";
      },
      processCategoryNodeIterator(nodeData, summaryData) {
        if (!nodeData) {
          return;
        }

        nodeData.label = nodeData.name;
        let categoryId = nodeData.id;
        let selfCount = 0;

        if (summaryData[categoryId]) {
          selfCount = summaryData[categoryId].count;
        } else {
          selfCount = 0;
        }

        let nodeCount = selfCount;
        nodeData.children.forEach(child => {
          let childCount = this.processCategoryNodeIterator(child, summaryData);
          nodeCount = nodeCount + childCount;
        });

        nodeData.label = nodeData.name + "(" + nodeCount + ")";
        return nodeCount;
      }
    }
  };
</script>

<style lang="scss" scoped>
  /*css代码*/
  .number {
    margin-left: 5px;
    font-size: 13px;
    font-weight: normal;
  }

  #menu {
    width: 130px;
    /*设置为0 隐藏自定义菜单*/
    height: auto;
    overflow: hidden;
    /*隐藏溢出的元素*/
    background-color: #fff;
    position: fixed;
    /*自定义菜单相对与body元素进行定位*/
    z-index: 2;
    border: 1px solid #eef0f6;
  }

  .menu {
    width: 130px;
    height: 25px;
    line-height: 25px;
    padding: 0 10px;
    color: #333;

    //cursor: pointer;
    &:hover {
      background-color: #409eff;
    }
  }

  .demand-classification {
    overflow: hidden;
    width: 100%;

    .left-box-top {
      position: fixed;
      top: 0;
    }
  }

  .demand-classification-left {
    background-color: #f1f1f1 !important;
    height: 100%;
    min-height: 703px;
    min-width: 200px;
    width: 100%;
    border: 1px solid #e4e7ed;
    box-sizing: border-box;

    .el-tree-node__content {
      background: #409eff;

      .iconmore {
        color: #c4bc2c !important;

        &:hover {
          display: inline-block;
        }
      }
    }
  }

  .demand-classification-right {
    width: 100%;
    box-sizing: border-box;
    // width: calc(100% - 207px);
    // height: calc(100vh - 200px);
    // float: right;
  }
</style>