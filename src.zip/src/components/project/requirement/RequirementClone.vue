<template>
  <el-dialog 
    :visible="cloneRequirementModalStatus" 
    title="复制需求" 
    custom-class="dialog-noanimate"
    :show-close="false"
    width="550px"
    :modal-append-to-body="false">
      <div>
        <el-form label-width="34%" class="modal-form">
          <el-form-item label="复制需求到">
            <el-select v-model="form.toProjectId" placeholder="请选择目标项目">
              <el-option :value="item.id" :label="item.name + (item.id === +projectId?'(当前项目)':'')" v-for="item in projectList" :key="item.id">{{item.name}}{{item.id === +projectId?'(当前项目)':''}}</el-option>
              <el-option value="0" disabled v-if="canloadmore">
                <div class="showmore" @click="changePageination(projectListPageInfo.pageNumber + 1)">更多</div>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="创建人">
            <el-radio v-model="form.keepCreateUser" :label="true">保留原需求的创建人</el-radio>
            <el-radio v-model="form.keepCreateUser" :label="false">我({{userInfo.userName}})</el-radio>
          </el-form-item>
          <el-form-item label="复制子需求和任务">
            <el-radio v-model="form.copyChild" :label="true">是</el-radio>
            <el-radio v-model="form.copyChild" :label="false">否</el-radio>
          </el-form-item>
        </el-form>
        <p class="center notice">(注：复制后的需求和任务状态都为初始状态)</p>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="default" @click="closeModal">取消</el-button>
        <el-button type="primary" @click="saveCopy" :disabled="loadingObject.posting">保存{{loadingObject.posting?"中...":""}}</el-button>
      </span>
    </el-dialog>
</template>
<script>
/**
 * @title 需求复制组件
 * @desc 项目列表采用分页(vuex 缓存)；每次打开 modal 时会恢复初始状态
 * @author heyunjiang
 * @date 2019.6.20
 */
import { mapState } from 'vuex'

export default {
  name: "RequirementClone",
  components: {},
  mixins: [],
  props: {
    requireId: {
      type: [Number, String],
      required: true
    },
    projectId: {
      type: [Number, String],
      required: true
    },
    cloneRequirementModalStatus: {
      type: Boolean,
      required: true
    },
    closeModal: {
      type: Function,
      required: true
    }
  },
  data() {
    return {
      loadingObject: {
        getting: false,
        posting: false
      },
      form: {
        toProjectId: +this.projectId,
        keepCreateUser: true,
        copyChild: true
      },
      projectListPageInfo: {
        pageNumber: 1,
        pageSize: 100
      },
      userInfo: {}
    }
  },
  computed: {
    ...mapState({
      projectInfo: state => state.pf.ProjectInfo.mine, // 获取进行中项目的列表信息
    }),
    projectList() {
      return this.projectInfo.ProjectList.slice(0, this.projectListPageInfo.pageNumber * this.projectListPageInfo.pageSize);
    },
    canloadmore() {
      return this.projectList.length < this.projectInfo.pageInfo.totalRecords
    }
  },
  watch: {
    // 当打开 modal 的时候，需要初始化分页信息，然后再获取数据
    cloneRequirementModalStatus(value) {
      if(value) {
        this.changePageination()
      }
    }
  },
  mounted() {
    this.userInfo = $utils.getStorage(GLOBAL_CONST.USER_INFO);
  },
  methods: {
    // 获取项目列表数据，分页信息依赖当前组件的 projectListPageInfo
    async getProjectList() {
      this.loadingObject.getting = true;
      const result = await this.$store.dispatch({ type: 'getProjectList', payload: {
        type: 'mine',
        pageInfo: this.projectListPageInfo
      } })
      this.loadingObject.getting = false;
    },
    // 更新分页信息，用于初始化及更多获取
    changePageination(pageNumber = 1) {
      this.projectListPageInfo = {
        pageNumber: pageNumber,
        pageSize: this.projectListPageInfo.pageSize
      }
      this.$nextTick(this.getProjectList)
    },
    // 复制需求
    async saveCopy() {
      this.loadingObject.posting = true;
      const result = await $http.post($http.api.requirement.copy, {
        ...this.form,
        projectId: this.projectId,
        requireId: this.requireId
      })
      this.loadingObject.posting = false;
      if(result.status === 200) {
        this.$message({
          message: result.msg || '复制需求成功',
          type: 'success'
        })
        this.closeModal()
      } else {
        this.$message({
          message: result.msg || '复制需求失败',
          type: 'error'
        })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .showmore {
    cursor: pointer;
    text-align: center;
    &:hover {
      color: #409eff;
    }
  }
</style>
