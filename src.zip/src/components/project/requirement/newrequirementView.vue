<template>
  <div id="demand1" class="content-outer-box detail-content" @click.stop="HandleSide">
    <div class="bug-content-box">
      <div class="slide-header">
        <span class="taskinfo-title">创建需求</span>
        <div class="slide-header-right">
          <el-button-group>
            <el-button type="default" class="slider-header-btn" @click="saveRequire" v-if="!bugTorequirement">保存
            </el-button>
            <el-button type="default" class="slider-header-btn" @click="saveBugTorequire" v-else>保存</el-button>
            <el-button type="default" icon="el-icon-close" @click="bugClose"></el-button>
          </el-button-group>
        </div>
      </div>
      <!-- 标题 -->

      <el-row :gutter="10" class="detail-content-body">
        <el-col :xs="16" :sm="16" :md="16" :lg="16" :xl="18">
          <div class="detail-content-left">
            <div class="detail-content-header" style="padding:5px;">
              <el-input ref="titleInput" class="title-input-active" placeholder="输入标题" size="large"
                v-model="requirement.title" @input="titleInput" style="height:35px;"></el-input>
            </div>
            <div class="detail-content-left-content" :class="{'detail-content-left-content-inactive': editStatus===1}"
              style="box-shadow:none;">
              <!-- 需求描述 -->
              <!-- <span v-if="editStatus===1" class="edit-box-bug-help-btn" @click="onEditRequirement">编辑描述</span> -->
              <!-- <span class="edit-box-bug-help-btn-save" @click="handleSaveEdit">保存</span> -->
              <!-- <span class="edit-box-bug-help-btn-cancel" @click="handleCancelEdit">取消</span> -->
              <div class="edit-box-bug-inactive" v-html="requirement.content" v-show="false"></div>
              <tiny-mce :value="requirement.content" @watch="editHnadle($event)"></tiny-mce>
            </div>
          </div>
        </el-col>
        <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6">
          <div class="detail-content-right">
            <div class="bug-basic-info">
              <p class="bug-basic-info-title">基本信息</p>
              <el-row :gutter="10">
                <el-col :md="24" :lg="24" :xl="24">
                  <div class="bug-basic-info-item">
                    <span class="bug-basic-info-item-label">所属项目：</span>
                    <span class="bug-basic-info-item-static"
                      :title="requirement.display.projectName">{{requirement.display.projectName}}</span>
                  </div>
                  <div class="bug-basic-info-item bug-basic-info-item-select">
                    <span class="bug-basic-info-item-label">需求分类：</span>
                    <!-- <field-edit :initName="requirement.display.category" :initValue="requirement.categoryId"
                    :selectValue="requrieCategoryList" :onChange="handleCategoryChange"></field-edit>-->
                    <el-select class="bug-basic-info-item-select-width" value-key="key" @change="handleCategoryChange"
                      v-model="requirement.categoryId">
                      <el-option v-for="jtem in requrieCategoryList" :label="jtem.value" :key="jtem.key"
                        :value="jtem.key"></el-option>
                    </el-select>
                  </div>
                  <div class="bug-basic-info-item bug-basic-info-item-select">
                    <span class="bug-basic-info-item-label">优先级：</span>
                    <!-- <field-edit :initName="requirement.display.priority" :initValue="requirement.priority"
                  :selectValue="priorityList" :colorType="colorType.ft" :onChange="handlePriorityChange"></field-edit>  
                  -->
                    <el-select class="bug-basic-info-item-select-width" value-key="key" @change="handlePriorityChange"
                      v-model="requirement.priority">
                      <el-option v-for="jtem in priorityList" :label="jtem.value" :key="jtem.key" :value="jtem.key">
                      </el-option>
                    </el-select>
                  </div>
                  <div class="bug-basic-info-item bug-basic-info-item-select">
                    <span class="bug-basic-info-item-label">迭代：</span>
                    <el-select class="bug-basic-info-item-select-width" value-key="key" v-model="requirement.sprintId">
                      <el-option value="0" label="未规划"></el-option>
                      <el-option v-for="jtem in sprintList" :label="jtem.value" :key="jtem.key" :value="jtem.key">
                      </el-option>
                    </el-select>
                  </div>
                  <div class="bug-basic-info-item bug-basic-info-item-select">
                    <span class="bug-basic-info-item-label">指派给：</span>
                    <!-- <field-edit :initName="requirement.display.assignUser" :initValue="requirement.assignUser"
                    :selectValue="assignUserData" :onChange="handleAssignerChange" localSearch></field-edit> -->
                    <!-- <el-select class="bug-basic-info-item-select-width" value-key="key"
                      v-model="requirement.assignUser">
                      <el-option v-for="jtem in assignUserData" :label="jtem.value" :key="jtem.key" :value="jtem.key">
                      </el-option>
                    </el-select> -->
                    <select-filter v-model="requirement.assignUser" class="bug-basic-info-item-select-width" :selectList="assignUserData"></select-filter>
                  </div>
                  <!-- <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">状态：</span>-->
                  <!-- <field-edit :initName="requirement.display.status" :initValue="requirement.statusId"
                  :selectValue="nextStatusList" :onChange="handleStatusChange" :colorType="colorType.bg"></field-edit>-->
                  <!-- <span class="bug-basic-info-item-label">新建</span> 
                  </div>-->
                  <div class="bug-basic-info-item bug-basic-info-item-select">
                    <span class="bug-basic-info-item-label">开始时间：</span>
                    <custom-date ref="start" class="bug-basic-info-item-select-width" v-model="requirement.startTime" @change="handleStartTimeChange()">
                    </custom-date>
                  </div>
                  <div class="bug-basic-info-item bug-basic-info-item-select">
                    <span class="bug-basic-info-item-label">结束时间：</span>
                    <custom-date v-model="requirement.endTime" class="bug-basic-info-item-select-width" ref="end" @change="handleEndTimeChange()"></custom-date>
                  </div>
                  <!-- 新版自定义字段 -->
                  <basic-info-custom-field :workItemType="1" detailType="editable" :detailInfo="requirement"
                    :projectId="projectId || getUrlParams().projectId" v-model="customFieldObj"></basic-info-custom-field>
                </el-col>
              </el-row>
            </div>
            <div class="bug-attachment">
              <p class="bug-attachment-title">
                附件
                <span class="bug-attachment-title-btn" @click="HandleShow">{{fileListShow?'收起上传':'展开上传'}}</span>
              </p>
              <file-upload :fileUpdaloadBoxStatus="fileListShow" :uploadedFileList="fileDataList"
                :handleFileDelete="deleteAttachment" :detailInfoId="0" :handleUploadSuccess="handleUploadSuccess"
                workItemType="1"></file-upload>
            </div>
          </div>
        </el-col>
      </el-row>
      <div class="detail-content-footer" v-if="false"></div>
    </div>
  </div>
</template>

<script>
  /**
   * author: panhui
   * time: 2019.4
   */
  import editor from "@/components/tool/markedit";
  import slide from "components/tool/slideSlip";
  import taskEdit from "components/project/task/taskEdit.vue";
  import FieldEdit from "@/components/tool/FieldEdit";
  import TimeLine from "@/components/tool/TimeLine";
  import FileUpload from "@/components/commonComponents/FileUpload";
  import CommentList from "@/components/commonComponents/CommentList";
  import TinyMce from 'components/tool/tinymce';
  import ProjectCommonMixin from "../ProjectCommonMixin";
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import BasicInfoCustomField from "@/components/project/BasicInfoCustomField";
  export default {
    name: "requirementView",
    components: {
      editor,
      taskEdit,
      slide,
      FieldEdit,
      TimeLine,
      FileUpload,
      CommentList,
      TinyMce,
      BasicInfoCustomField
    },
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    data() {
      return {
        statusObject: {
          activeName2: "4", //评论等状态控制,
          editTitleStatus: 1 //标题状态控制
        },

        timeVal: {
          start: "",
          end: ""
        }, ///时间编辑状态控制
        editTask: false,
        html: "",
        deleteShow: false,
        urlParam: {
          projectId: 0,
          requireId: 0
        },
        fileListShow: true,
        // 原始数据，用户数据是否修改判断
        originalData: {
          content:
            "",
          title: null,
        },
        requirement: {
          display: {
            projectName: "",
            assignUser: ""
          },
          content: "",
          title: null,
          startTime: "",
          endTime: "",
          priority: 0,
          categoryId: this.currentCategoryId || 0,
          sprintId: null,
          statusId: 0,
          assignUser: "",
          projectId: this.getUrlParams().projectId || this.projectId,
          innerProject: true,
          attachments: [],
          id: -1
        },
        creatliteral: '',
        assignProjectList: [],
        assignUserData: [],
        editStatus: 1, //1处于只读状态，2处于可编辑状态
        editBackupValue: null, //编辑的备份数据，点击取消后 展示该值
        statusValue: "",
        editorSetting: {
          height: 400
        },
        colorType: {
          bg: "bg",
          ft: "font",
          cr: "circle"
        },
        field: {
          title: "title",
          content: "content",
          expectedTime: "expectedTime",
          assignUser: "assignUser",
          priority: "priority",
          category: "category",
          sprintId: "sprintId",
          startTime: "startTime",
          endTime: "endTime",
          statusId: "statusId"
        },
        intermediateValue: "", //处理监听子组件返回的中间值
        labelPosition: "right",
        formLabelAlign: {
          name: "",
          region: "",
          type: ""
        },
        //切换信息

        //切换选项切换绑定的值
        disabledTask: "",
        radio3: 2,
        radio2: 1,
        upoladID: {
          workItemType: 1,
          workItemId: this.requireId
        },
        uploadActionUrl: $http.api.attachment.upload.url,
        fatherDemandData: [], //父需求
        childDemandData: [], //子需求
        association: [], //关联需求
        taskDataList: [], //任务分解
        revisedList: [], //修订列表
        revisedPageInfo: { pageSize: 10, pageNumber: 1 },
        revisedDialogVisible: false,
        comment: "",
        commentDataList: [],
        commentPageInfo: { pageSize: 10, pageNum: 1 },
        operationLogDataList: [],
        operationLogPageInfo: { pageSize: 10, pageNum: 1, isMore: false },
        fileDataList: [],
        requrieCategoryList: [],
        assignUser: "", //处理人model
        assignUserList: [],
        sprintList: [],
        nextStatusList: [],

        saveTitle: "",
        updateTaskData: {},

        assocRequireDialogVisible: false,
        assocRequireDataList: [],
        assocRequirePageInfo: { pageSize: 10, pageNumber: 1 },
        projectNameList: [],
        assocRequireSearchInfo: {
          projectId: this.parseInteger(this.getUrlParams().projectId),
          title: null,
          isArchived: -1,
          pageInfo: {}
        },
        userData: {},
        idVip: null,
        idEditVip: null,
        showheader: false,
        loading: false,

        priorityList: [], //优先级列表
        customFieldObj: {}
      };
    },
    props: {
      requireId: {
        type: [Number, String],
        default: null
      },
      projectTitleName: {
        type: [Number, String],
        default: null
      },
      restore: {
        type: [Number, String],
        default: null
      },
      requireContent: {
        type: String,
      },
      requireTitle: {
        type: String
      },
      bugTorequirement: {
        type: Boolean,
        default: false,
        desc: "缺陷转需求"
      },
      defectId: {
        type: [String, Number],
      },
      projectId: {
        type: [String, Number],
      },
      currentCategoryId:{
        type: [String, Number],
      }
    },
    watch: {
      requireId: function (newVal, oldVal) {
        if (newVal == oldVal) {
          this.$nextTick(() => {
            // this.upoladID.workItemId = this.requireId;
            // this.urlParam.projectId = this.getUrlParams().projectId;
            this.statusObject.activeName2 = "4";
            this.getRequirementInfo();
            this.getDemandRelevance();
            this.getTaskDecomposition();
            this.getAttachmentList();
            // this.getCommentList();
            this.getSprintList();
            this.getAssignUser();

            this.requirement.display.projectName = document.getElementById(
              "h3-inlineName"
            ).innerHTML;
          });
        }
      },
      projectTitleName: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          this.requirement.display.projectName = newVal;
        }
      },
      restore: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          this.getRequireCategoryList();
          this.getPriorityList();
          this.getAssignUser();
        }
      }
    },
    mounted() {
      this.userData = $utils.getStorage(GLOBAL_CONST.USER_INFO);
      this.getSprintList();
      this.getAssignUser();
      this.getRequireCategoryList();
      this.getPriorityList();
      this.requirement.display.projectName = this.projectTitleName;
      this.tinymceContentReset();
      this.queryDescTmpl();

    },
    methods: {
      //缺陷转需求保存
      saveBugTorequire() {
        this.fileDataList.forEach(fileData => {
          this.requirement.attachments.push(fileData.id);
        });

        if (!this.requirement.title) {
          this.$message({ message: "需求标题不能为空", type: "error" });
          return false;
        }
        this.requirement.defectId = this.defectId;
        this.requirement.workItemType = 3;
        let RequirementAndDefecId = this.requirement
        $http.post($http.api.bug_info.bug_transFormation, RequirementAndDefecId).then(ret => {
          if (ret.status === 200) {
            this.$message({ message: ret.msg || "添加需求成功", type: "success" });
            this.$emit("HandleSide", false);
            this.removeTinymceContent(this.requirement.id)
            this.$emit('refeshBug')
          } else {
            this.$message({ message: ret.msg || "添加需求失败", type: "error" });
          }

        });
      },
      //获取自定义模板内容
      queryDescTmpl() {
        $http.get($http.api.work_status_fow.descTmpl_query, { projectId: this.projectId, workItemType: 1 }).then((res) => {
          this.originalData.content = res.data.template;
          this.$nextTick(() => {
            if (!this.bugTorequirement) {
              this.requirement.content = res.data.template;
            } else {
              this.requirement.content = this.requireContent
              this.requirement.title = this.requireTitle
            }
          })
        })
      },
      // 编辑器内容恢复
      async tinymceContentReset() {
        const exist = await this.isPreviousContentExist(this.requirement.id, 'requirement', true, this.requirement.content);
        if (exist) {
          this.requirement.content = exist;
        }
      },
      //保存需求
      saveRequire() {
        // if (!this.checkRequire()) return;
        // this.requirement.attachments = [];
        this.fileDataList.forEach(fileData => {
          this.requirement.attachments.push(fileData.id);
        });

        if (!this.requirement.title) {
          this.$message({ message: "需求标题不能为空", type: "error" });
          return false;
        }
        $http.post($http.api.requirement.create, {
          ...this.requirement,
          userDefinedAttrs: this.customFieldObj,
        }).then(ret => {
          if (ret.status === 200) {
            this.$message({ message: ret.msg || "添加需求成功", type: "success" });
            this.$emit('update:titleNotice', false);
            this.$emit('update:descNotice', false);
            this.$nextTick(() => {
              this.$emit("HandleSide", false);
              this.removeTinymceContent(this.requirement.id)
            })
          } else {
            this.$message({ message: ret.msg || "添加需求失败", type: "error" });
          }
        });
      },
      deleteAttachment(file) {
        let id = file.id;
        this.fileDataList = this.fileDataList.filter(
          item => item.id !== file.id
        );
      },
      //进入任务视图
      toTaskView(info) {
        this.goToNewWindowPage(this, "taskView", {
          taskId: info.id,
          projectId: info.projectId
        });
      },
      // 点击关闭按钮
      async bugClose() {
        let noticeTitle = '工作项';
        if (this.requirement.title !== this.originalData.title) {
          noticeTitle += '标题';
        }
        if (this.requirement.content !== this.originalData.content) {
          if (this.requirement.title !== this.originalData.title) {
            noticeTitle += '和描述';
          } else {
            noticeTitle += '描述';
          }
        }
        if (this.requirement.title !== this.originalData.title || this.requirement.content !== this.originalData.content) {
          const confirmResult = await this.confirmBeforeOperate(`${noticeTitle}已经填写/修改，请确认是否关闭`);
          if (!confirmResult) { return false; }
        }

        // if (this.requirement.title !== this.originalData.title) {
        //   const confirmResult = await this.confirmBeforeOperate(`工作项标题已经填写/修改，请确认是否关闭`);
        //   if (!confirmResult) { return false; }
        // }
        // if (this.requirement.content !== this.originalData.content) {
        //   const confirmResult = await this.confirmBeforeOperate(`工作项描述已经填写/修改，请确认是否关闭`);
        //   if (!confirmResult) { return false; }
        // }
        this.$emit("HandleSide", false);
        this.removeTinymceContent(this.requirement.id)
      },
      getAssignProjectList() {
        //请求处理人接口
        $http.get($http.api.project.assign_project_list).then(res => {
          this.assignProjectList = res.data;
        });
      },
      handleEditExoectHour(id) {
        this.editTask = id;
      },
      handleAssignRadioChange() {
        //指派
        if (this.assignRadio == 1) {
          this.getAssignTeamList();
        } else {
          this.getAssignProjectList();
        }
      },
      getSprintList() {
        $http
          .get($http.api.sprint.list_sprint_name, {
            projectId: this.urlParam.projectId || this.projectId,
            status: 1
          })
          .then(res => {
            if (res.status == 200) {
              this.sprintList = res.data.map(item => {
                return {
                  value: item.name,
                  key: item.id,
                  id: item.id
                };
              });
            }
          });
      },
      getRequireCategoryList() {
        $http
          .get($http.api.requirementCategory.list, {
            projectId: this.urlParam.projectId || this.projectId
          })
          .then(res => {
            this.requrieCategoryList = res.data.map(item => {
              return {
                value: item.label,
                key: item.id
              };
            });
          });
        console.log(this.requrieCategoryList)
      },
      //获取优先级
      getPriorityList() {
        let projectId = this.getUrlParams().projectId || this.projectId;
        $http
          .get($http.api.bug_info.priorityList, { projectId, workItemType: 1 })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1

            this.priorityList = res.data.map(item => {
              return {
                value: item.literal,
                key: item.priority,
                color: item.color,
                ...item
              };
            });
            let user = this.priorityList.find(n => n.value == "P2");
            this.requirement.priority = user.key
            this.requirement.display.priority = `<span class="statusbox-list-common" style="background-color:${user.color}">${user.literal}</span>`
          });
      },
      //获取用户
      getAssignUser(value) {
        let projectId = this.getUrlParams().projectId || this.projectId;
        this.userData = $utils.getStorage(GLOBAL_CONST.USER_INFO);
        let query = value || null;
        $http
          .post($http.api.project.assignUser, { projectId, query })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1

            this.assignUserData = res.data.map(item => {
              return {
                key: item.userId,
                value: item.userName + "(" + item.userId + ")"
              };
            });
            let data = this.userData.userId;
            let user = this.assignUserData.find(n => n.key == data);

            this.requirement.assignUser = user.key;
          });
      },
      HandleShow() {
        this.fileListShow = !this.fileListShow;
      },
      HnadleSaveSptint() {
        this.editBackupValue = this.requirement.sprintId;
      },
      // 标题输入内容监听
      titleInput() {
        if (this.requirement.title !== this.originalData.title) {
          this.$emit('update:titleNotice', true);
        } else {
          this.$emit('update:titleNotice', false);
        }
      },
      // 编辑器内容输入监听
      editHnadle(data) {
        this.requirement.content = data;
        if (data !== this.originalData.content) {
          this.$emit('update:descNotice', true);
          this.saveTinymceContent({
            value: data,
            id: this.requirement.id,
            type: 'requirement', // 需求、任务、缺陷
            isNew: true
          })
        } else {
          this.$emit('update:descNotice', false);
          this.removeTinymceContent(this.requirement.id)
        }
      },
      parseInteger(value) {
        return parseInt(value);
      },
      //分解任务成功保存
      saveTask() {
        this.taskDataList.pop();
        this.createTaskInfo.projectId = this.urlParam.projectId;
        this.createTaskInfo.requireId = this.requireId;
        // this.createTaskInfo.sprintId = 0;
        if (this.createTaskInfo.title != null) {
          this.createTask();
        }
      },
      //取消创建任务
      cancelSaveTask() {
        this.taskDataList.pop();
      },
      // 删除
      taskDelete(val) {
        this.$confirm("此操作将删除该数据, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            $http
              .get($http.api.task.deleteTask, { id: val }, { type: "form" })
              .then(res => {
                if (res.status === 200) {
                  this.$message({
                    message: res.msg || "删除成功",
                    type: "success"
                  });
                  this.getTaskDecomposition();
                } else {
                  this.$message({ message: res.msg || "删除失败", type: "error" });
                }
              });
          })
          .catch(() => { });
      },
      downloadHandle(row) {
        window.location.href = row.url;
      },
      handleUploadSuccess(res) {
        this.fileDataList.push(res.data);
      },
      HandleSide(e) {
        this.timeVal.start = "";
        this.timeVal.end = "";
        if (this.statusObject.editTitleStatus === 2) {
          if (this.editBackupValue !== this.requirement.title) {
            this.requireUpdateInfo = {};
            this.requireUpdateInfo.id = this.requireId;
            this.requireUpdateInfo.title = this.requirement.title;
            this.sendUpdateRequireRequest();
            this.editBackupValue = this.requirement.title;
          }
        }
        this.statusObject.editTitleStatus = 1;
        //隐藏上传&关联文档tips doc-upload
        this.publicHideTips(e)
      },
      onTitleEdit() {
        this.statusObject.editTitleStatus = 2;
        this.editBackupValue = this.requirement.title;
        this.$nextTick(function () {
          this.$refs.titleInput.focus();
        });
      },
      onEditRequirement() {
        this.editStatus = 2;
      },
      handleCancelEdit() {
        this.editStatus = 1;
      },
      handleSaveEdit() {
        this.requirement.content = this.intermediateValue;

        this.prepareUpdateRequire(this.field.content, this.requirement.content);
        this.editStatus = 1;
        // 我加入的代码

        $http
          .post($http.api.requirement.update, this.requireUpdateInfo)
          .then(res => {
            this.$message({ message: "修改需求成功", type: "success" });
          });
      },
      //获取今天明天后天的日期
      _GetDateStr(AddDayCount) {
        let date = new Date(this.createTaskInfo.startTime);
        date.setDate(date.getDate() + AddDayCount);
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        let d = date.getDate();
        return y + "-" + m + "-" + d;
      },
      //取消编辑
      HandleTaskEdit() {
        $http
          .post($http.api.task.taskUpdate, { id: this.idVip })
          .then(res => {
            this.getTaskDecomposition();
          })
          .catch(() => {
            this.getTaskDecomposition();
          });
      },
      handleAddChildRequrie() {
        if (this.childDemandData.length < 1) {
          this.createRequireData.isFirst = true;
        } else {
          this.createRequireData.isFirst = false;
        }
        this.childDemandData.push(this.createRequireData);
      },
      handelCancelCreateChildRequire() {
        this.childDemandData.pop();
      },
      changHandleTask(index) {
        if (this.radio3 == "2") {
          this.changeStatus = "1";
        } else if (this.radio3 == "3") {
          this.changeStatus = "2";
        }
      },
      onSubmitComment() {
        if (this.comment.trim() != "") {
          $http
            .post($http.api.comment.add, {
              workItemType: 1,
              workItemId: this.requireId,
              comment: this.comment.trim(),
              projectId: this.projectId
            })
            .then(res => {
              this.commentPageInfo.pageNum = 1;
              // this.getCommentList();
              this.comment = "";
              this.commentUpdata = !this.commentUpdata; // 更新评论列表
            });
        }
      },
      handleAssignerChange(value) {
        this.requirement.assignUser = value;
        this.prepareUpdateRequire(
          this.field.assignUser,
          this.requirement.assignUser
        );
        //this.sendUpdateRequireRequest();
      },
      handleCategoryChange(value) {
        this.requirement.categoryId = value;

        this.prepareUpdateRequire(
          this.field.category,
          this.requirement.categoryId
        );
        //this.sendUpdateRequireRequest();
      },
      handlePriorityChange(value) {
        this.requirement.priority = value;
        let user = this.priorityList.find(n => n.key == value);
        this.requirement.display.priority = `<span class="statusbox-list-common" style="background-color:${user.color}">${user.literal}</span>`
        // this.prepareUpdateRequire(this.field.priority, this.requirement.priority);
        // this.sendUpdateRequireRequest();
      },
      handleSprintChange(value) {
        this.requirement.sprintId = value;
        this.prepareUpdateRequire(this.field.sprintId, this.requirement.sprintId);
        this.sendUpdateRequireRequest();
      },
      handleStartTimeChange() {
        this.timeVal.start = "";
      },
      handleEndTimeChange() {
        this.timeVal.end = "";
      },
      handleStatusChange(value) {
        this.requirement.statusId = value;
        this.prepareUpdateRequire(this.field.statusId, this.requirement.statusId);
        this.sendUpdateRequireRequest();

        this.nextStatusList.forEach(status => {
          if (this.requirement.statusId == status.statusId) {
            this.requirement.display.status = status.statusName;
          }
        });
      },
      handleStatusClick() {
        this.statusValue = this.requirement.statusId;
        this.getNextStatusList(this.requirement.statusId);
      },
      prepareUpdateRequire(field, value) {
        this.requireUpdateInfo = {};
        //this.requireUpdateInfo.id = this.requireId;

        if (field == this.field.content) {
          this.requireUpdateInfo.content = value;
        } else if (field == this.field.title) {
          this.requireUpdateInfo.title = value;
        } else if (field == this.field.expectedTime) {
          this.requireUpdateInfo.expectedTime = value;
        } else if (field == this.field.statusId) {
          this.requireUpdateInfo.statusId = value;
        } else if (field == this.field.startTime) {
          this.requireUpdateInfo.startTime = value;
        } else if (field == this.field.priority) {
          this.requireUpdateInfo.priority = value;
        } else if (field == this.field.sprintId) {
          this.requireUpdateInfo.sprintId = value;
        } else if (field == this.field.endTime) {
          this.requireUpdateInfo.endTime = value;
        } else if (field == this.field.assignUser) {
          this.requireUpdateInfo.assignUser = value;
        } else if (field == this.field.category) {
          this.requireUpdateInfo.categoryId = value;
        }
      },
      sendUpdateRequireRequest() {
        $http
          .post($http.api.requirement.update, this.requireUpdateInfo)
          .then(res => {
            this.$nextTick(() => {
              this.getRequirementInfo();
              this.getOperationLogDataList();
              this.$message({ message: "修改需求成功", type: "success" });
            })

            this.requirement.content = this.requireContent ? this.requireContent : "";
            this.requirement.title = this.requireTitle ? this.requireTitle : '';
          })
          .catch(e => {
            this.requirement.sprintId = this.editBackupValue;
            this.requirement.statusId = this.statusValue;
          });
      },
      handleAssociateRequire() {
        this.assocRequireDialogVisible = true;
        this.getProjectList();
      },
      searchAssocRequrie() {
        if (
          (!this.assocRequireSearchInfo.projectId ||
            this.assocRequireSearchInfo.projectId == 0) &&
          !this.assocRequireSearchInfo.title
        ) {
          this.$message({ message: "项目和标题不能同时为空", type: "warning" });
          return;
        }
        this.assocRequirePageInfo.pageNumber = 1;
        this.assocRequirePageInfo.pageSize = 10;
        this.getSearchAssocRequireList();
      },
      getProjectList() {
        $http.get($http.api.project.projectList).then(res => {
          this.projectNameList = res.data;
        });
      },
      getSearchAssocRequireList() {
        this.assocRequireSearchInfo.pageInfo = {
          pageNumber: this.assocRequirePageInfo.pageNumber,
          pageSize: this.assocRequirePageInfo.pageSize
        };
        $http
          .post(
            $http.api.requirement.list_assoc_require,
            this.assocRequireSearchInfo
          )
          .then(res => {
            this.assocRequireDataList = res.data.result;
            this.assocRequirePageInfo = res.data.pageInfo;
          });
      },
      handleAssocRequirePageSizeChange(pageSize) {
        this.assocRequirePageInfo.pageSize = pageSize;
        this.getSearchAssocRequireList();
      },
      handleAssocRequirePageNumChange(pageNum) {
        this.assocRequirePageInfo.pageNumber = pageNum;
        this.getSearchAssocRequireList();
      },
      handleRevisedPageSizeChange(pageSize) {
        this.revisedPageInfo.pageSize = pageSize;
        this.getRevisedList();
      },
      handleRevisedPageNumChange(pageNum) {
        this.revisedPageInfo.pageNumber = pageNum;
        this.getRevisedList();
      },
      handleSureAssocRequrie() {
        let assocRequrieIds = [];
        this.$refs["assocRequireTableRef"].selection.forEach(item => {
          assocRequrieIds.push(item.id);
        });

        let requestParam = {
          origWorkItemType: 1,
          targetWorkItemIds: assocRequrieIds,
          targetWorkItemType: 1,
          origWorkItemId: this.requireId
        };
        $http
          .post($http.api.requirement.assoc_require, requestParam)
          .then(res => {
            this.getDemandRelevance();
            this.assocRequireDialogVisible = false;
          });
      },
      toRequrieDetailPage(row) {
        let param = { requireId: row.id, projectId: row.projectId };
        // this.goToPage(this, "requirementView", param);
        this.goToNewWindowPage(this, "requirementList", param);
        // window.location.reload();
      }
    }
  };
</script>
<style lang="scss" scoped>
  @import "../ProjectCommon.scss";

  .title-input {
    display: inline-block;
    width: calc(100% - 200px);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-size: 24px;
    height: 38px;
    line-height: 38px;

    &:hover {
      box-shadow: 0 0 0 1px #ccc;
    }
  }

  .title-input-true {
    line-height: 40px;
    height: 40px;
    display: inline-block;
    width: calc(100% - 200px);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-size: 24px;
    outline: none;
  }

  .side-left {
    width: 67%;
    float: left;
  }

  .title {
    width: 100%;
  }

  .edit-position-box {
    width: 100%;
    position: relative;
    overflow: hidden;

    .edit-detail-btn {
      position: absolute;
      padding: 2px 4px;
      right: 12px;
      top: 17px;
      border: 1px solid #dde5ef;
      cursor: pointer;
      -webkit-box-sizing: border-box;
      box-sizing: border-box;

      &:hover {
        background-color: #ebf2f9;
      }
    }

    .edit-cancle-and-sure-btn {
      position: absolute;
      right: 12px;
      top: 32px;

      .edit-cancle-btn,
      .edit-sure-btn {
        padding: 2px 4px;
        border: 1px solid #dde5ef;
        cursor: pointer;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
      }
    }
  }

  .demand-title {
    background-color: #eef0f6;
    height: 36px;
    line-height: 36px;
    white-space: nowrap;
  }

  .child-demand {
    margin-top: 3px;
  }

  .same-box-heander {
    height: 36px;
    /*line-height: 35px;*/
    font-size: 13px;
    color: #909399;
    float: left;
    font-weight: 900;
  }

  .detail-content-header-1 {
    position: relative;
    padding: 5px;


  }

  .same-box-heander1 {
    height: 36px;
    line-height: 35px;
    font-size: 13px;
    color: #909399;
    float: left;
    text-indent: 1em;
    font-weight: 900;
  }

  .same-box {
    text-align: left;
    font-size: 13px;
    color: #333;
    float: left;
    margin-top: 5px;
    margin-bottom: 5px;
  }

  .demand-box {
    margin-top: 20px;
    margin-left: 20px;
    height: 44px;
    line-height: 44px;
  }

  .border {
    padding-bottom: 6px;
  }

  .detailed-information,
  .demand-connect,
  .task-decompose {
    /* border-bottom: 1px solid #ccc;
    border-top: 1px solid #ccc; */
    padding-bottom: 20px;
    width: 100%;

    .task-decompose-title {
      // height: 40px;
      // line-height: 40px;
      padding-bottom: 10px;
    }
  }

  .detailed-information1 {
    width: 100%;
    min-height: 300px;
  }

  .el-icon-download,
  .el-icon-close {
    cursor: pointer;
  }

  .el-icon-download {
    margin-left: 20%;
  }

  .commentData {
    margin-top: 20px;

    .person {
      margin-left: 20px;
    }

    .content {
      margin-top: 10px;
      margin-left: 20px;
      color: black;
    }
  }

  .list {
    margin-top: 5px;
    cursor: pointer;
  }

  .edit-box {
    width: 99%;
    min-height: 421px;
    margin: 10px 10px 10px 40px;
    font-size: 13px;
    border-radius: 5px;
    -webkit-box-shadow: 0 0 3px #eee;
    box-shadow: 0 0 3px #eee;
    padding: 10px;
    box-sizing: border-box;

    .edit-box-requirement {
      padding-top: 10px;
    }
  }

  .time1 {
    text-indent: 1em;
  }

  .icon {
    margin-right: 10%;
  }

  .head-portrait {
    width: 41px;
    height: 46px;
    border: 1px solid #ccc;
  }

  textarea[disabled] {
    background-color: #fff !important;
    border: none;
  }

  .commentData1 {
    line-height: 30px;
  }

  .flleName {
    padding-top: 15px;
    padding-bottom: 8px;
    font-size: 14px;
    color: #333;
    overflow: hidden;
  }

  .father-demand,
  .child-demand,
  .association-demand {
    border-bottom: 1px solid #eef0f6;
  }

  .el-form-item {
    margin-bottom: 5px;
  }

  .bold-font {
    font-weight: 900;
  }

  .comment-paging {
    margin-right: 125px;
  }

  .w99 {
    width: 99%;
    margin: 0 auto;
  }
</style>