<template>
  <div>
    <el-form :inline="true" :model="formInline">
      <el-form-item
        label
        class="marginBottom1"
        :class="{marginBottom1:showFilter}"
        v-if="!showFilter"
      >
        <el-input
          v-model="formInline.title"
          class="header-filter-item1"
          placeholder="请输入标题/ID"
          style="width: 201px;"
        ></el-input>
      </el-form-item>
      <el-form-item
        label="标题/ID"
        class="marginBottom1"
        :class="{marginBottom1:showFilter}"
        v-if="showFilter"
      >
        <el-input v-model="formInline.title" class="header-filter-item1" placeholder="请输入标题/ID"></el-input>
      </el-form-item>
      <el-form-item label="处理人" class="marginBottom" :class="{noshow: showFilter}" >
        <select-filter multiple
          v-model="formInline.assignUsers"
          @change="(value)=>{handleSelectChange(value,'assignUsers')}"
          class="header-filter-item1" :selectList="assignUserData">
          <el-option value="all" label="全部" slot></el-option>
        </select-filter>
      </el-form-item>
      <el-form-item label="优先级" class="marginBottom" :class="{noshow:showFilter}">
        <el-select
          v-model="formInline.priorities"
          class="header-filter-item2"
          style="width: 105px;"
          multiple
          @change="(value)=>{handleSelectChange(value,'priorities')}"
        >
          <el-option label="全部" value="all"></el-option>
          <el-option
            :label="data.literal"
            :value="data.priority"
            v-for="(data,index) in priorityList"
            :key="index"
          >
            <template slot-scope="scope">
              <span style="float: left">
                <span v-html="initNameStatus(data.color,data.literal)"></span>
              </span>
            </template>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="迭代" class="marginBottom" :class="{noshow:showFilter}">
        <sprint-multiple-select class="header-filter-item1" v-model="formInline.sprintIds" :selectAllInit="true" :panelWidth="160"></sprint-multiple-select>
      </el-form-item>
      <el-form-item label="状态" class="marginBottom" :class="{noshow:showFilter}">
        <el-select
          multiple
          v-model="formInline.statusIds"
          @click.native="getStaus"
          @change="(value)=>{handleSelectChange(value,'statusIds')}"
          style="width: 105px;"
        >
          <el-option label="全部" value="all" selected></el-option>
          <el-option
            :label="data.statusName"
            :value="data.statusId"
            v-for="(data,index) in demandStatusData"
            :key="index"
          >
            <template slot-scope="scope">
              <span style="float: left">
                <span v-html="initNameStatus(data.color,data.statusName)"></span>
              </span>
            </template>
          </el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="归档" class="marginBottom" :class="{noshow:showFilter}">
        <el-select v-model="formInline.isArchived" class="header-filter-item">
          <el-option
            :label="data.name"
            :value="data.id"
            v-for="(data,index) in isArchivedList"
            :key="index"
          ></el-option>
        </el-select>
      </el-form-item>
      <el-button type="primary" class="submitstyle" @click="onSubmit">过滤</el-button>
      <el-dropdown>
        <el-button>
          导入/导出
          <i class="el-icon-arrow-down el-icon--right"></i>
        </el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item>
            <span @click="exportExcel">导出需求</span>
          </el-dropdown-item>
          <el-dropdown-item>
            <span @click="requirementModel">下载导入模板</span>
          </el-dropdown-item>
          <el-dropdown-item
            v-show="authFunction('FUNC_COOP_REQT_CREATE', 3, getUrlParams().projectId)"
          >
            <el-upload
              :action="importObject.importUrl"
              :data="importObject.importData"
              :show-file-list="false"
              :on-success="uploadSuccess"
              multiple
              :on-exceed="handleExceed"
            >
              <span
                type="primary"
                v-show="authFunction('FUNC_COOP_REQT_CREATE', 3, getUrlParams().projectId)"
              >导入需求</span>
            </el-upload>
          </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
      <!-- <el-button type="primary" style="margin-top:8px;margin-left:10px;" @click="onshowFrom"><i class="el-icon-arrow-down"></i>展开</el-button> -->
      <span class="showFrom" @click="onshowFrom" v-if="!showFilter">展开过滤器</span>
      <span class="hideFrom" @click="onhideFrom" :class="{noshow:showFilter}">收起过滤器</span>
      <el-button
        type="primary"
        class="creatstyle"
        v-show="authFunction('FUNC_COOP_REQT_CREATE', 3, getUrlParams().projectId)"
        @click="onCreate"
      >创建需求</el-button>
      <div id="clear" style="clear:both"></div>
    </el-form>
  </div>
</template>
<script>
/**
 * @title 需求列表 - filter
 * @desc 还是拆分出来了，不拆分维护太痛苦了
 * @author heyunjiang
 * @date 2019.8.9
 */
import ProjectCommonMixin from "@/components/project/ProjectCommonMixin";
import SprintMultipleSelect from "@/components/commonComponents/SprintMultipleSelect";

export default {
  name: "HeaderFilter",
  components: {
    SprintMultipleSelect
  },
  mixins: [ProjectCommonMixin],
  props: {
    headerFilterInfo: {
      type: Object,
      required: false,
      default: () => { return {} }
    }
  },
  data() {
    return {
      projectId: this.getUrlParams().projectId,
      formInline: {
        projectId: this.getUrlParams().projectId,
        title: null,
        assignUsers: [],
        isArchived: 0,
        sprintIds: [],
        statusIds: [],
        priorities: []
      },
      isArchivedList: [
        { id: -1, name: "全部" },
        { id: 0, name: "未归档" },
        { id: 1, name: "已归档" }
      ],
      importObject: {
        importUrl: $http.api.requirement.requirement_import.url,
        importData: {
          projectId: this.getUrlParams().projectId
        }
      },
      showFilter: true, // 是否展示过滤器
      demandStatusData: [], // 状态列表
      sprintData: [], // 迭代列表
      priorityList: [], // 优先级列表
      assignUserData: [], // 处理人列表
    }
  },
  computed: {},
  watch: {
    headerFilterInfo() {
      this.formInline = {
        ...this.formInline,
        ...this.headerFilterInfo
      }
    }
  },
  mounted() {
    this.showFilter = true;
    this.init();
  },
  methods: {
    init() {
      this.getPriorityList();
      this.getAssignUser();
      this.getStaus();
    },
    // 点击 - 创建需求
    onCreate() {
      this.$emit('onCreate');
    },
    // 点击 - 下载导入模板
    requirementModel() {
      this.$emit('requirementModel');
    },
    // 点击 - 导出需求
    exportExcel() {
      this.$emit('exportExcel', this.formInline);
    },
    // 点击 - 过滤
    onSubmit() {
      this.$emit('onSubmit', this.formInline);
    },
    // 上传成功
    uploadSuccess(res) {
      if (res.status === 200) {
        this.$message({ type: 'success', message: res.msg || '上传成功' })
        // this.init();
        this.$emit('uploadSuccess');
      } else {
        this.$message({ type: 'error', message: res.msg || '上传失败' })
      }
    },
    handleExceed() { },
    // 控制全选 select ，同时支持固定字段与自定义字段
    handleSelectChange(value, isCustom) {
      let filterData = this.formInline;
      // 如果最后一个选中了全部
      if (value[value.length - 1] === "all") {
        filterData[isCustom] = ["all"];
        //this.formInline[isCustom] = [];
      }
      // 如果不是最后一个选中了全部
      if (
        filterData[isCustom].includes("all") &&
        filterData[isCustom].length > 1
      ) {
        filterData[isCustom] = filterData[isCustom].filter(item => item !== "all");
      }
    },
    //展开过滤条件
    onshowFrom() {
      this.showFilter = true;
    },
    // 收缩过滤条件
    onhideFrom() {
      this.showFilter = false;
    },
    // 初始化 - 获取状态列表
    getStaus() {
      let projectId = this.getUrlParams().projectId;
      $http.post($http.api.requirement.demandStatus, {
        workItemType: 1,
        projectId
      }).then(res => {
        this.demandStatusData = res.data;
      }).catch(e => {
        this.$message({ message: "操作失败", type: "error" });
      });
    },
    // 初始化 - 获取优先级列表
    getPriorityList() {
      let projectId = this.getUrlParams().projectId;
      $http.get($http.api.bug_info.priorityList, { projectId, workItemType: 1 }).then(res => {
        this.priorityList = res.data;
      });
    },
    // 初始化 - 获取处理人列表
    getAssignUser() {
      let projectId = this.getUrlParams().projectId;
      let query = null;
      $http.post($http.api.project.assignUser, { projectId, query }).then(res => {
        this.assignUserData = res.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName + '(' + item.userId + ')'
          }
        });
      });
    }
  }
}
</script>
<style lang="scss" scoped>
.marginBottom {
  margin-bottom: 0px !important;
  display: none;
}

.marginBottom1 {
  margin-bottom: 0px !important;
}

.header-filter-item1 {
  width: 7vw;
}

.header-filter-item2 {
  width: 80px;
}

.submitstyle {
  margin-top: 7px;
  //margin-left: 10px;
}
.hideFrom {
  margin-top: 8px;
  margin-left: 10px;
  color: #409eff;
  display: none;
  cursor: pointer;
}

.showFrom {
  margin-top: 8px;
  margin-left: 10px;
  color: #409eff;
  display: inline-block;
  cursor: pointer;
}
.creatstyle {
  margin-top: 8px;
  float: right;
}

.noshow {
  display: inline-block !important;
}
</style>
