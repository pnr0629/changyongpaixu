<template>
  <el-dialog :visible="cloneRquireModalStatus" title="选择父需求" modal-append-to-body="false" custom-class="dialog-noanimate"
    :modal-append-to-body="false" :before-close="closeModal">
    <el-form :inline="true" @submit.native.prevent>
      <el-form-item class="header-input"  label="所属项目:">
        <!-- <el-input placeholder="请输入需求标题关键字" v-model="searchInfo.title"></el-input> -->
         <span>{{projectName}}</span>
      </el-form-item>
      <el-form-item class="header-input" style="margin-left: 180px;" label="标题/ID:">
        <el-input placeholder="请输入标题/ID" v-model="searchInfo.title"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="searchRequrieList">查询</el-button>
      </el-form-item>
    </el-form>
    <div class="table-box-top">
      <el-table :data="requirementList" ref="assocRequireTableRef" style="width: 100%;height: 100%;">
        <el-table-column width="50" align="center">
          <template slot-scope="scope">
            <el-radio v-model="required" :label="scope.row.id">{{null}}</el-radio>
          </template>
        </el-table-column>
        <el-table-column width="70" show-overflow-tooltip label="需求ID" prop="id">
          <template slot-scope="scope">
            <span class="c-blue cp" @click.stop="assocItemClick(scope.row, 'requirement')">{{scope.row.id}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="display.title" show-overflow-tooltip label="需求标题" min-width="180">
          <template slot-scope="scope">
            <span class="c-blue cp"
              @click.stop="assocItemClick(scope.row, 'requirement')">{{scope.row.display.title}}</span>
          </template>
        </el-table-column>
        <!-- <el-table-column prop="display.projectName" show-overflow-tooltip label="所属项目" min-width="80">
        </el-table-column> -->
        <el-table-column prop="display.assignUser" show-overflow-tooltip label="处理人" min-width="60">
        </el-table-column>
        <el-table-column prop="display.status" show-overflow-tooltip label="状态" width="80"></el-table-column>
      </el-table>
    </div>
    <div class="table_b_f_b">
      <el-pagination v-show="requirementList && requirementList.length>0" class="fr mr10" style="margin-top: 9px;"
        @size-change="handleRequirementListPageSizeChange" @current-change="handleRequirementListPageNumChange"
        :current-page="searchInfo.pageInfo.pageNumber" :page-sizes="[10, 20, 30]"
        :page-size="searchInfo.pageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper"
        :total="searchInfo.pageInfo.totalRecords"></el-pagination>
    </div>
    <div class="fotter">
      <div class="fr ">
        <el-button type="primary" @click="updateRequirement">确定</el-button>
      </div>
    </div>
  </el-dialog>
</template>
<script>
  export default {
    name: 'ChangeFatherRquire',
    props: {
      cloneRquireModalStatus: {
        type: Boolean,
        required: true
      },
      closeModal: {
        type: Function,
        required: true
      },
      projectId: {
        type: [String, Number],
        required: true
      },
      oriParentId: {
        type: [String, Number],
        required: true
      },
      taskId: {
        type: [String, Number],
        required: true
      }
    },
    data() {
      return {
        requirementList: [], // 可以选择的父需求列表
        searchInfo: {
          title: '',
          pageInfo: {
            pageNumber: 1,
            pageSize: 10,
            totalRecords: 0
          }
        },
        required: "",
        confirm: 0,
        projectName:"",
      }
    },
    watch: {
      cloneRquireModalStatus(value) {
        // if (value && this.requirementList.length === 0) {
        //   this.searchRequrieList()
        // } else {
        //   // this.resetInfo()
        // }
        this.searchRequrieList()
      }
    },
    mounted() {
      this.searchRequrieList()
    },
    methods: {
      //更新父需求
      updateRequirement() {
        if(!this.required){
          this.$message({type:'warning',message:"请选择父需求"})
          return
        }
        $http.get($http.api.task.requirement_update, {
          id: this.taskId,
          oriParentId: this.oriParentId,
          newParentId: this.required,
          confirm: this.confirm
        }).then(res => {
          if (res.status === 501) {
            this.$confirm(res.msg, {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              modal:false,
              type: 'warning'
            }).then(() => {
              this.confirm = 1;
              this.updateRequirement();
            }).catch(() => {
              this.confirm = 0;
            });
          }
          else if (res.status === 200) {
            this.$message({
              message: '更新父需求成功',
              type: 'success'
            })
            this.closeModal();
            this.$emit("updata")
          }
          else {
            this.$message({
              message: res.msg,
              type: 'error'
            })
          }
        });
      },
      // 选择需求 - 点击查询
      searchRequrieList() {
        $http.post($http.api.requirement.parentable_reqt, {
          title: this.searchInfo.title,
          pageInfo: this.searchInfo.pageInfo,
          projectId: this.projectId,
          reqtId: this.taskId,
        }).then(res => {
          if (res.status === 200) {
            this.searchInfo.pageInfo = res.data.pageInfo;
            this.requirementList = res.data.result;
            this.projectName = this.requirementList[0].display.projectName;
          } else {
            this.$message({
              message: res.msg || '没有满足条件的需求',
              type: 'error'
            })
            this.requirementList = []
          }
        });
      },
      // 分页
      handleRequirementListPageSizeChange(pageSize) {
        this.searchInfo.pageInfo.pageSize = pageSize;
        this.searchRequrieList();
      },
      // 分页
      handleRequirementListPageNumChange(pageNum) {
        this.searchInfo.pageInfo.pageNumber = pageNum;
        this.searchRequrieList();
      },
    },
  }
</script>
<style lang="scss" scoped>
  .fotter {
    width: 100%;
    overflow: hidden;
  }
</style>