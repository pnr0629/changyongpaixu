<template>
  <div id="demand" class="content-outer-box detail-content" @click.stop="HandleSide" style="height: 1000px;"
    v-loading="loading" element-loading-text="拼命加载中" element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)">
    <div class="bug-content-box">
      <div class="slide-header">
        <span class="taskinfo-title">需求详情</span>
        <div class="slide-header-right">
          <el-button-group>
            <el-button type="default"
              v-show="authFunction('FUNC_COOP_PROJECT_REQT_COPY', 3, getUrlParams().projectId || projectId)"
              @click="handelRequirementClone">复制需求</el-button>
            <el-button type="default"
              v-show="authFunction('FUNC_COOP_REQT_DELETE', 3, getUrlParams().projectId || projectId)"
              @click="handelRequirementDelete">删除需求</el-button>
            <el-button type="default" icon="el-icon-close" @click="bugClose"></el-button>
          </el-button-group>
        </div>
      </div>
      <el-row :gutter="10" class="detail-content-body">
        <el-col :xs="16" :sm="16" :md="16" :lg="16" :xl="18" style="position: relative">
          <div class="detail-content-left">
            <!-- 标题 -->
            <div class="detail-content-header">
              <span v-if="statusObject.editTitleStatus==1" class="detail-content-header-id">#{{requirement.id}}</span>
              <ellipsis-block :value="requirement.title || ''" v-show="statusObject.editTitleStatus==1"
                style="width: calc(100% - 99px);" class="editable-field title-input-inactive" @click="onTitleEdit">
              </ellipsis-block>
              <!-- <span
                  v-show="statusObject.editTitleStatus==1"
                  style="width: calc(100% - 99px);"
                  :title="requirement.title"
                  class="editable-field title-input-inactive cursor-pointer ellipsis"
                  @click.stop="onTitleEdit"
                >{{requirement.title}}</span> -->
              <el-input v-show="statusObject.editTitleStatus==2" @click.stop ref="titleInput" class="title-input-active"
                placeholder="输入标题" @change="editinput" @blur="editinput" size="large" v-model="requirement.title">
              </el-input>
            </div>
            <div class="creat-title">
              <span>{{`${requirement.display.createUser}(${requirement.createUser}) `}}</span>创建于
              <span>{{requirement.createTime}}</span>
            </div>
            <div class="detail-content-left-content"
              :class="{'detail-content-left-content-inactive': editStatus===1,'showMore':showMore}" ref="showMorebox">
              <div ref="showMoresbox" :class="{'edit-fullscreen': statusObject.fullScreen}">
                <!-- 需求描述 -->
                <span v-if="editStatus===1" class="edit-box-bug-help-btn" @click="onEditRequirement">编辑描述</span>
                <span class="edit-box-bug-help-btn" style="right:75px;"
                  @click="fullScreen">{{!statusObject.fullScreen ?'全屏':'正常'}}</span>
                <span v-show="editStatus!==1" class="edit-box-bug-help-btn-save" @click="handleSaveEdit">保存</span>
                <span v-show="editStatus!==1" class="edit-box-bug-help-btn-cancel" @click="handleCancelEdit">取消</span>
                <show-larger v-if="editStatus===1" :value="requirement.content"></show-larger>
                <tiny-mce v-if="editStatus!==1" :value="requirement.content" ref="fullFuc123"
                  v-on:watch="editHnadle($event)" :minHeigt='minHeight'></tiny-mce>
              </div>
            </div>
          </div>
          <div class="textTaskbox" v-if="showTxtMore">
            <div @click="showMoreBtn" v-if="showTxtMore" class="moreText" style="line-height: 53px; ">
              -----------&nbsp;展示更多&nbsp;-----------</div>
          </div>
          <div @click="hideMoreBtn" v-if="hideTxtMore" class="moreText">-----------&nbsp;收起更多&nbsp;-----------</div>
          <div class="detail-content-left">
            <div class="detail-content-left-assoc">
              <div class="bug-assoc-header">
                <span class="title-common">关联工作项</span>
                <!-- <span  class="demandre" @click="handleAssociateRequire()">添加关联</span> -->
                <el-button type="text fr" v-show="authFunction('FUNC_COOP_WORKITEM_ASSOC', 0)"
                  @click="handleAssociateRequire">添加关联</el-button>
              </div>
              <!-- <div class="bug-assoc-body" v-if="demandObject.requirements.length > 0">
                  <div
                    class="bug-assoc-item"
                    v-for="(item, index) in demandObject.requirements"
                    :key="item.id">
                    <span class="bug-assoc-item-text" @click.stop="demandItemClick(item, 'requirement')">{{item.id}}-需求-{{item.display.title}}</span>
                    <span class="bug-assoc-item-delete" @click.stop="demandItemDelete(item, 'requirement',index)"><i class="el-icon-delete"></i></span>
                  </div>
                </div>-->
              <div class="bug-assoc-body" style="box-shadow: 0 0 2px white;"
                v-if="assocObject.parentRequirements.length > 0 || assocObject.requirements.length > 0 || assocObject.tasks.length > 0 || assocObject.defects.length > 0">
                <div class="bug-assoc-item" v-for="item in assocObject.parentRequirements" :key="item.id">
                  <span class="bug-assoc-item-text"
                    @click.stop="assocItemClick(item, 'requirement')">{{item.id}}-父需求-{{item.display.title}}</span>

                  <span class="requirement-status">
                    {{item.display.assignUser}}
                    <span class="requirement-assiguser"></span>
                    {{item.display.status}}
                  </span>
                  <!-- <span class="bug-assoc-item-delete" @click.stop="demandItemDelete(item, 'requirement')"><i
                    class="el-icon-delete"></i></span>-->
                </div>
                <div class="bug-assoc-item" v-for="item in assocObject.requirements" :key="item.id">
                  <span class="bug-assoc-item-text"
                    @click.stop="assocItemClick(item, 'requirement')">{{item.id}}-需求-{{item.display.title}}</span>
                  <span class="requirement-status">
                    {{item.display.assignUser}}
                    <span class="requirement-assiguser"></span>
                    {{item.display.status}}
                  </span>
                  <span class="bug-assoc-item-delete" @click.stop="demandItemDelete(item, 'requirement')">
                    <i class="el-icon-delete"></i>
                  </span>
                </div>
                <div class="bug-assoc-item" v-for="item in assocObject.tasks" :key="item.id">
                  <span class="bug-assoc-item-text"
                    @click.stop="assocItemClick(item, 'task')">{{item.id}}-任务-{{item.display.title}}</span>
                  <span class="requirement-status">
                    {{item.display.assignUser}}
                    <span class="requirement-assiguser"></span>
                    {{item.display.status}}
                  </span>
                  <span class="bug-assoc-item-delete" @click.stop="demandItemDelete(item, 'task')">
                    <i class="el-icon-delete"></i>
                  </span>
                </div>
                <div class="bug-assoc-item" v-for="item in assocObject.defects" :key="item.id">
                  <span class="bug-assoc-item-text"
                    @click.stop="assocItemClick(item, 'defect')">{{item.id}}-缺陷-{{item.display.title}}</span>
                  <span class="requirement-status">
                    {{item.display.assignUser}}
                    <span class="requirement-assiguser"></span>
                    {{item.display.status}}
                  </span>
                  <span class="bug-assoc-item-delete" @click.stop="demandItemDelete(item, 'defect')">
                    <i class="el-icon-delete"></i>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </el-col>
        <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6">
          <div class="detail-content-right info-title">
            <div class="bug-basic-info">
              <p class="bug-basic-info-title">基本信息</p>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">所属项目：</span>
                <span class="bug-basic-info-item-static"
                  :title="requirement.display.projectName">{{requirement.display.projectName}}</span>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">需求分类：</span>
                <field-edit :initName="requirement.display.category" :initValue="requirement.categoryId"
                  :selectValue="requrieCategoryList" :onChange="handleCategoryChange"></field-edit>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">优先级：</span>
                <field-edit :initName="requirement.display.priority" :initValue="requirement.priority"
                  :selectValue="priorityList" :onChange="handlePriorityChange" :colorType="colorType.bg"></field-edit>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">迭代：</span>
                <field-edit :initName="requirement.display.sprint" :initValue="requirement.sprintId"
                  :selectValue="sprintList" :onChange="handleSprintChange"></field-edit>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label" style="vertical-align: top;">父需求:</span>
                <span class=" cursor-pointer editable-field-label" style="width:calc(100% - 123px);display:inline-block;" :title="requirement.display.parentTitle" @click="ChangeFatherRquireFuc"
                  @mouseover="deleteParentRequire=true" @mouseout="deleteParentRequire=false">
                  <span class="hover-basic-info-item-static">
                    {{requirement.display.parentTitle ? requirement.display.parentTitle:'--'}}</span>
                  <i v-show="deleteParentRequire && requirement.parentId > 0"  class="el-icon-delete link-common ml10"
                    @click.stop="deleteParentRequireFuc" style="position: relative;top:-9px;"></i>
                </span>
                <change-father-rquire v-if="cloneRquireModalStatus" @updata="updateRquire"
                  :cloneRquireModalStatus="cloneRquireModalStatus" :oriParentId="requirement.parentId"
                  :taskId="requirement.id" :projectId="projectId||this.getUrlParams().projectId"
                  :closeModal="closeModal">
                </change-father-rquire>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">指派给：</span>
                <field-edit :initName="requirement.display.assignUser" :initValue="requirement.assignUser"
                  :selectValue="assignUserData" :onChange="handleAssignerChange" localSearch></field-edit>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">开始时间：</span>
                <custom-date v-show="timeVal.start === 'start'" ref="start" v-model="requirement.startTime" type="date"
                  prefix-icon="clean-icon" placeholder="选择日期" value-format="yyyy-MM-dd" class="basic-title-input-active"
                  @change="handleStartTimeChange()"></custom-date>
                <span class="bug-basic-info-item-static editable-field cursor-pointer" @click.stop="chooseTime('start')"
                  v-show="timeVal.start === ''">{{requirement.startTime?requirement.startTime:'--'}}</span>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">结束时间：</span>
                <custom-date v-model="requirement.endTime" v-show="timeVal.end === 'end'" ref="end" type="date"
                  prefix-icon="clean-icon" placeholder="选择日期" value-format="yyyy-MM-dd" class="basic-title-input-active"
                  @change="handleEndTimeChange()"></custom-date>
                <span class="bug-basic-info-item-static editable-field cursor-pointer" @click.stop="chooseTime('end')"
                  v-show="timeVal.end === ''">{{requirement.endTime?requirement.endTime:'--'}}</span>
              </div>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">状态：</span>
                <!-- <field-edit :initName="requirement.display.status" :initValue="requirement.statusId"
                  :selectValue="nextStatusList" :onChange="handleStatusChange" :colorType="colorType.bg"></field-edit> -->
                <span class="bug-basic-info-item-static editable-field cursor-pointer"
                  @click="showActiveStatus($event,requirement,1)"
                  v-html="initNameStatus(requirement.display.detail && requirement.display.detail.status.color,requirement.display.status)">
                </span>

              </div>
              <!-- 新版自定义字段 -->
              <basic-info-custom-field :workItemType="1" detailType="show" :detailInfo="requirement"
                :projectId="projectId || getUrlParams().projectId" :updateField="sendUpdateRequireRequest"></basic-info-custom-field>
              <div class="bug-basic-info-item">
                <span class="bug-basic-info-item-label">创建人：</span>
                <span class="bug-basic-info-item-static"
                  :title="requirement.display.createUser">{{`${requirement.display.createUser}(${requirement.createUser})`}}</span>
              </div>
            </div>
            <div class="bug-attachment">
              <p class="bug-attachment-title">
                附件
                <span class="bug-attachment-title-btn" @click="HandleShow">{{fileListShow?'收起上传':'展开上传'}}</span>
              </p>
              <file-upload :fileUpdaloadBoxStatus="fileListShow" :uploadedFileList="fileDataList"
                :handleFileDelete="deleteAttachment" :detailInfoId="requireId"
                :handleUploadSuccess="handleUploadSuccess" workItemType="1"></file-upload>
            </div>
          </div>
        </el-col>
      </el-row>
      <div class="detail-content-footer">
        <div class="control">
          <el-tabs v-model="statusObject.activeName2" type="border-card" @tab-click="changHandleTask1" value="3">
            <el-tab-pane :label="panelabel.tesk" name="3">
              <div class="task-decompose" v-show="statusObject.activeName2==='3'">
                <!-- <span class="fl task-decompose-title" style="font-size: 14px;font-weight: 600;">任务列表</span> -->
                <a v-if="disabledTask && authFunction('FUNC_COOP_TASK_CREATE', 3, projectId || getUrlParams().projectId)"
                  class="fl ml10 c-blue cp task-decompose-title" @click="addTaskHandle()"
                  style="margin-top: -3px;">+任务分解</a>
                <span v-else class="fl ml10 task-decompose-title"
                  style="color:#cccccc;margin-top: -3px;display: inline-block;">
                  <i class="el-icon-warning" style="color:#409EFF;"></i>&nbsp;父需求或者需求已完成/取消不能分解任务
                </span>
                <el-table class="tiny-table" :data="taskDataList" border style="width: 100%">
                  <el-table-column label="任务标题" show-overflow-tooltip min-width="116">
                    <template slot-scope="scope">
                      <el-input v-if="scope.row.isNewAdd==1" v-model="createTaskInfo.title" placeholder="输入任务标题">
                      </el-input>
                      <el-input v-else-if="scope.row.isNewAdd==2" v-model="createTaskInfo.title" placeholder="输入任务标题"
                        @blur="blurSearchFor"></el-input>
                      <global-input v-else :initValue="scope.row.display.title"
                        :onChange="(value)=>{updateGlobalTitle(scope.row, value, 2)}">
                        <span class="table-input-edit-text c-blue-hover" slot>
                          <span @click="toTaskView(scope.row,$event)"
                            class="c-blue cp">{{scope.row.display.title}}</span>
                        </span>
                      </global-input>
                    </template>
                  </el-table-column>
                  <el-table-column label="优先级" show-overflow-tooltip width="84" sortable prop="priority">
                    <template slot-scope="scope">
                      <el-select v-if="scope.row.isNewAdd==1" v-model="createTaskInfo.priority">
                        <el-option :label="data.value" :value="data.key" v-for="(data,index) in priorityList"
                          :key="index">
                          <template slot-scope="scope">
                            <span style="float: left">
                              <span class="mini-circle" :style="{backgroundColor:data.color}"></span>
                              {{data.literal}}
                            </span>
                          </template>
                        </el-option>
                      </el-select>
                      <el-select v-else-if="scope.row.isNewAdd==2" v-model="createTaskInfo.priority"
                        @change="priorityChange()">
                        <el-option :label="data.value" :value="data.key" v-for="(data,index) in priorityList"
                          :key="index">
                          <template slot-scope="scope">
                            <span style="float: left">
                              <span class="mini-circle" :style="{backgroundColor:data.color}"></span>
                              {{data.literal}}
                            </span>
                          </template>
                        </el-option>
                      </el-select>
                      <span v-else class="cursor-pointer"
                        @click.stop="(e) => updateGlobalTaskInfo(scope.row, e, 'priority', getTaskDecomposition)">
                        <span
                          v-html="initNameStatus(scope.row.display.detail.priority.color,scope.row.display.detail.priority.literal)"></span>
                      </span>
                    </template>
                  </el-table-column>
                  <el-table-column label="处理人" show-overflow-tooltip width="100" sortable prop="assignUser">
                    <template slot-scope="scope">
                      <select-filter v-model="createTaskInfo.assignUser" :selectList="assignUserData"
                        v-if="scope.row.isNewAdd==1"></select-filter>
                      <select-filter v-model="createTaskInfo.assignUser" :selectList="assignUserData"
                        v-else-if="scope.row.isNewAdd==2" @change="assignUserChange"></select-filter>
                      <span v-else class="cursor-pointer"
                        @click.stop="(e) => updateGlobalTaskInfo(scope.row, e, 'assignUser', getTaskDecomposition)">{{scope.row.display.assignUser}}</span>
                    </template>
                  </el-table-column>
                  <!-- <el-table-column label="预计工时/h" show-overflow-tooltip width="82">
                      <template slot-scope="scope">
                        <el-input class="basic-title-input-active" placeholder="请输入工时/h" v-model="createTaskInfo.expectHour" v-if="scope.row.isNewAdd==1"
                          @change="taskTimeChange('expectHour')" style="width: 68px;" ></el-input>
                        <el-input class="basic-title-input-active" placeholder="请输入工时/h" v-model="createTaskInfo.expectHour" v-else-if="scope.row.isNewAdd==2"
                          @change="taskTimeChange('expectHour')" style="width: 68px;" ></el-input>
                        <global-input v-else :initValue="scope.row.expectHour" 
                          :onChange="(value)=>{GlobalTaskUpdate({expectHour: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTaskDecomposition})}">
                          <span class="ellipsis cursor-pointer" slot>{{scope.row.expectHour}}</span>
                        </global-input>
                      </template>
                    </el-table-column>-->
                  <el-table-column label="预计工时" show-overflow-tooltip width="82">
                    <template slot-scope="scope">
                      <expect-hour v-bind:hour.sync="createTaskInfo.expectHour" v-if="scope.row.isNewAdd==1"
                        :changeCallback="()=>blurexpectHour(1)"></expect-hour>
                      <expect-hour v-bind:hour.sync="createTaskInfo.expectHour" v-if="scope.row.isNewAdd==2"
                        :changeCallback="()=>blurexpectHour(2)"></expect-hour>
                      <span v-else class="cursor-pointer"
                        @click.stop="(e) => updateGlobalTaskInfo(scope.row, e, 'expectHour', getTaskDecomposition)">{{(scope.row.expectHour/8)+'天' || '--'}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="预计开始日期" width="124" sortable prop="startTime">
                    <template slot-scope="scope">
                      <custom-date style="width: 110px;" v-if="scope.row.isNewAdd==1" v-model="createTaskInfo.startTime"
                        type="date" placeholder="选择日期" value-format="yyyy-MM-dd" prefix-icon="clean-icon"
                        @change="taskTimeChange('startTime')"></custom-date>
                      <custom-date v-else-if="scope.row.isNewAdd==2" v-model="createTaskInfo.startTime" type="date"
                        placeholder="选择日期" value-format="yyyy-MM-dd" prefix-icon="clean-icon"
                        @change="taskTimeChange('startTime')"></custom-date>
                      <global-input v-else :initValue="scope.row.startTime || ''" inputType="time"
                        :onChange="(value)=>{GlobalTaskUpdate({startTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTaskDecomposition})}">
                        <span slot>{{scope.row.startTime || '--'}}</span>
                      </global-input>

                    </template>
                  </el-table-column>
                  <el-table-column label="预计结束日期" width="124">
                    <template slot-scope="scope">
                      <custom-date style="width: 110px;" v-if="scope.row.isNewAdd == 1" v-model="createTaskInfo.endTime"
                        type="date" placeholder="选择日期" value-format="yyyy-MM-dd" prefix-icon="clean-icon"
                        @change="taskTimeChange('endTime')"></custom-date>
                      <custom-date v-else-if="scope.row.isNewAdd == 2" v-model="createTaskInfo.endTime" type="date"
                        placeholder="选择日期" value-format="yyyy-MM-dd" prefix-icon="clean-icon"
                        @change="taskTimeChange('endTime')"></custom-date>
                      <global-input v-else :initValue="scope.row.endTime || ''" inputType="time"
                        :onChange="(value)=>{GlobalTaskUpdate({endTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTaskDecomposition})}">
                        <span slot>{{scope.row.endTime || '--'}}</span>
                      </global-input>
                    </template>
                  </el-table-column>
                  <el-table-column label="迭代" show-overflow-tooltip width="100">
                    <template slot-scope="scope">
                      <el-select v-if="scope.row.isNewAdd==1" placeholder="请选择活动区域" style="width:100%;"
                        v-model="createTaskInfo.sprintId">
                        <el-option v-for="item in sprintList" :key="item.id" :label="item.value" :value="item.key">
                        </el-option>
                      </el-select>
                      <el-select v-else-if="scope.row.isNewAdd==2" placeholder="请选择活动区域" style="width:100%;"
                        v-model="createTaskInfo.sprintId" @change="sprintIdChange()">
                        <el-option v-for="item in sprintList" :key="item.id" :label="item.value" :value="item.key">
                        </el-option>
                      </el-select>
                      <span v-else class="cursor-pointer table-column-padding"
                        @click.stop="(e) => updateGlobalTaskInfo(scope.row, e, 'sprintId', getTaskDecomposition)">{{scope.row.display.sprint || '--'}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="状态" show-overflow-tooltip width="80">
                    <template slot-scope="scope">
                      <span v-if="scope.row.isNewAdd==1">-</span>
                      <span v-else-if="scope.row.isNewAdd==2">-</span>
                      <span v-else class="cursor-pointer statusbox-list-common-box"
                        v-html="initNameStatus(scope.row.display.detail.status.color,scope.row.display.status)"
                        @click.stop="(e) => updateGlobalTaskInfo(scope.row, e, 'statusId', getTaskDecomposition)">{{scope.row.display.status}}</span>
                    </template>
                  </el-table-column>

                  <el-table-column prop label="操作" show-overflow-tooltip width="80">
                    <template slot-scope="scope">
                      <span v-if="scope.row.isNewAdd==1" class="c-blue cp" @click="saveTask()">保存</span>
                      <span v-if="scope.row.isNewAdd==1" class="c-blue cp" @click="cancelSaveTask()">取消</span>

                      <span v-if="scope.row.isNewAdd==2" class="c-blue cp" @click="HandleTaskEdit()">取消</span>
                      <span
                        v-if="authFunction('FUNC_COOP_TASK_DELETE', 3, projectId) && scope.row.isNewAdd !=1 && scope.row.isNewAdd !=2 "
                        class="cp c-blue" @click="taskDelete(scope.row.id)">删除</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
            </el-tab-pane>
            <el-tab-pane :label="panelabel.childrequrie" name="4">
              <div class="demand-connect">
                <div>
                  <div style="overflow:hidden;margin-top: -3px;" class="border">
                    <span class="fl c-blue cp" @click="handleAddChildRequrie()"
                      v-if="!requirement.display.end&&authFunction('FUNC_COOP_REQT_CREATE', 3, projectId || getUrlParams().projectId)">+添加子需求</span>
                    <span v-else class="fl ml10 task-decompose-title"
                      style="color:#cccccc;margin-top: -3px;display: inline-block;">
                      <i class="el-icon-warning" style="color:#409EFF;"></i>
                      &nbsp;需求已完成/取消不能添加子需求
                    </span>
                  </div>
                  <!-- <el-table :data="childDemandData" style="width: 100%" @row-dblclick="handEditTable_b"> -->
                  <el-table :data="childDemandData" style="width: 100%">
                    <el-table-column label="类型" width="80" v-if="false">
                      <template slot-scope="scope">
                        <span v-if="scope.row.isFirst" class="bold-font">子需求</span>
                        <span v-else class="bold-font"></span>
                      </template>
                    </el-table-column>
                    <el-table-column label="需求ID" show-overflow-tooltip width="80">
                      <template slot-scope="scope">
                        <span v-if="scope.row.isNewAdd"></span>
                        <span v-else class="c-blue-hover cp"
                          @click="toRequrieDetailPage(scope.row)">{{scope.row.id}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="标题" show-overflow-tooltip min-width="180">
                      <template slot-scope="scope">
                        <el-input v-if="scope.row.isNewAdd == 1" v-model="createRequireData.title" style="width:100%;"
                          placeholder="输入标题"></el-input>
                        <el-input v-else-if="scope.row.isNewAdd == 2" v-model="editRequireData.title"
                          style="width:100%;" placeholder="输入标题" @blur="blurSearchEdit()"></el-input>
                        <global-input v-else :initValue="scope.row.display.title"
                          :onChange="(value)=>{updateGlobalTitle(scope.row, value, 1)}">
                          <span class="table-input-edit-text c-blue-hover" slot>
                            <span @click="toRequrieDetailPage(scope.row)"
                              class="font-desgin cp">{{scope.row.display.title}}</span>
                          </span>
                        </global-input>
                      </template>
                    </el-table-column>
                    <el-table-column label="优先级" show-overflow-tooltip width="80">
                      <template slot-scope="scope">
                        <el-select v-model="createRequireData.priority" v-if="scope.row.isNewAdd == 1"
                          :disabled="operaisdisable">
                          <el-option :label="data.value" :value="String(data.key)" v-for="(data,index) in priorityList"
                            :key="index">
                            <template slot-scope="scope">
                              <span style="float: left">
                                <span class="mini-circle" :style="{backgroundColor:data.color}"></span>
                                {{data.literal}}
                              </span>
                            </template>
                          </el-option>
                        </el-select>
                        <el-select v-model="editRequireData.priority" v-else-if="scope.row.isNewAdd == 2"
                          @change="priorityEdit()">
                          <el-option :label="data.value" :value="data.key" v-for="(data,index) in priorityList"
                            :key="index">
                            <template slot-scope="scope">
                              <span style="float: left">
                                <span class="mini-circle" :style="{backgroundColor:data.color}"></span>
                                {{data.literal}}
                              </span>
                            </template>
                          </el-option>
                        </el-select>
                        <span v-else>
                          <span class="cursor-pointer"
                            v-html="initNameStatus(scope.row.display.detail.priority.color,scope.row.display.detail.priority.literal)"
                            @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'priority', getDemandRelevance)"></span>
                        </span>
                      </template>
                    </el-table-column>
                    <el-table-column label="迭代" show-overflow-tooltip min-width="80">
                      <template slot-scope="scope">
                        <!-- <el-select v-if="scope.row.isNewAdd == 1" style="width:100%;" :disabled="operaisdisable"
                            v-model="createRequireData.sprintId">
                            <el-option v-for="item in sprintList" :key="item.id" :label="item.value" :value="item.key">
                            </el-option>
                          </el-select>-->
                        <span v-if="scope.row.isNewAdd == 1"></span>
                        <!-- <el-select style="width:100%;"
                            v-model="editRequireData.sprintId" @change="sprintIdedit()">
                            <el-option v-for="item in sprintList" :key="item.id" :label="item.value" :value="item.key">
                            </el-option>
                          </el-select>-->
                        <span v-else class="cursor-pointer"
                          @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'sprintId', getDemandRelevance)">{{scope.row.display.sprint||'--'}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="状态" show-overflow-tooltip width="90">
                      <template slot-scope="scope">
                        <span></span>
                        <el-select v-if="scope.row.isNewAdd == 1" style="width:100%;" :disabled="operaisdisable"
                          v-model="createRequireData.statusId">
                          <el-option v-for="item in nextStatusList" :key="item.statusId" :label="item.statusName"
                            :value="item.statusId"></el-option>
                        </el-select>
                        <el-select v-else-if="scope.row.isNewAdd == 2" style="width:100%;"
                          v-model="editRequireData.statusId" @change="statusChange()">
                          <el-option v-for="item in nextStatusList" :key="item.statusId" :label="item.statusName"
                            :value="item.statusId"></el-option>
                        </el-select>
                        <span v-else class="cursor-pointer"
                          v-html="initNameStatus(scope.row.display.detail.status.color,scope.row.display.status)"
                          @click="showActiveStatus($event,scope.row,1)"></span>
                      </template>
                    </el-table-column>
                    <el-table-column label="处理人" show-overflow-tooltip min-width="80">
                      <template slot-scope="scope">
                        <select-filter v-model="createRequireData.assignUser" :selectList="assignUserData"
                          :disabled="operaisdisable" v-if="scope.row.isNewAdd==1"></select-filter>
                        <select-filter v-model="editRequireData.assignUser" :selectList="assignUserData"
                          :disabled="operaisdisable" v-else-if="scope.row.isNewAdd==2" @change="assignUserEdit">
                        </select-filter>
                        <span v-else class="cursor-pointer"
                          @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'assignUser', getDemandRelevance)">{{scope.row.display.assignUser}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="开始日期" width="100">
                      <template slot-scope="scope">
                        <custom-date v-if="scope.row.isNewAdd == 1" v-model="createRequireData.startTime" type="date"
                          :disabled="operaisdisable" class="date_form1" placeholder="选择日期" value-format="yyyy-MM-dd"
                          prefix-icon="clean-icon">
                        </custom-date>
                        <custom-date v-else-if="scope.row.isNewAdd == 2" v-model="editRequireData.startTime"
                          :disabled="operaisdisable" type="date" class="date_form1" placeholder="选择日期"
                          value-format="yyyy-MM-dd" prefix-icon="clean-icon" @change="startTimeEdit()"></custom-date>
                        <global-input v-else :initValue="scope.row.startTime || ''" inputType="time"
                          :onChange="(value)=>{GlobalRequirementUpdate({startTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getDemandRelevance})}">
                          <span slot>{{scope.row.startTime || '--'}}</span>
                        </global-input>
                      </template>
                    </el-table-column>
                    <el-table-column label="结束日期" width="100">
                      <template slot-scope="scope">
                        <custom-date v-if="scope.row.isNewAdd == 1" v-model="createRequireData.endTime" type="date"
                          :disabled="operaisdisable" class="date_form1" placeholder="选择日期" value-format="yyyy-MM-dd"
                          prefix-icon="clean-icon">
                        </custom-date>
                        <custom-date v-else-if="scope.row.isNewAdd == 2" v-model="editRequireData.endTime"
                          :disabled="operaisdisable" type="date" class="date_form1" placeholder="选择日期"
                          value-format="yyyy-MM-dd" prefix-icon="clean-icon" @change="endTimeEdit()"></custom-date>
                        <global-input v-else :initValue="scope.row.endTime || ''" inputType="time"
                          :onChange="(value)=>{GlobalRequirementUpdate({endTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getDemandRelevance})}">
                          <span slot>{{scope.row.endTime || '--'}}</span>
                        </global-input>
                      </template>
                    </el-table-column>
                    <el-table-column label="操作" show-overflow-tooltip min-width="80">
                      <template slot-scope="scope">
                        <span v-if="scope.row.isNewAdd == 1 && !operaisdisable" class="c-blue cp"
                          @click="handelSaveChildRequire()">保存</span>
                        <span v-if="scope.row.isNewAdd == 1 && !operaisdisable" class="c-blue cp"
                          @click="handelCancelCreateChildRequire()">取消</span>
                        <span v-if="scope.row.isNewAdd == 1 && operaisdisable" class="c-disable cp">保存中</span>
                        <span v-if="scope.row.isNewAdd == 2" class="c-blue cp" @click="handelCancelEdit()">取消</span>
                        <span
                          v-if="![1, 2].includes(scope.row.isNewAdd) && authFunction('FUNC_COOP_REQT_PARENT_CHILD_UNBIND', 3, projectId)"
                          class="c-blue cp" @click="()=>{handelUnbindParentChildren(scope.row, false)}">关系解绑</span>
                      </template>
                    </el-table-column>
                  </el-table>
                  <el-table :data="association" :show-header="showheader" style="width: 100%"
                    :class="{'el-table__body-none':association.length == 0}" @row-dblclick="handEditTable_c">
                    <el-table-column label="类型" width="80">
                      <template slot-scope="scope">
                        <span v-if="scope.row.association" class="bold-font">关联需求</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="需求ID" width="80">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="toRequrieDetailPage(scope.row)">{{scope.row.id}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="标题" min-width="200">
                      <template slot-scope="scope">
                        <el-input v-if="scope.row.isNewAdd == 2" v-model="editRequireData.title" style="width:100%;"
                          placeholder="输入标题" @blur="blurSearchEdit()"></el-input>
                        <span v-else class="c-blue cp"
                          @click="toRequrieDetailPage(scope.row)">{{scope.row.display.title}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="优先级" min-width="60">
                      <template slot-scope="scope">
                        <el-select v-model="editRequireData.priority" v-if="scope.row.isNewAdd == 2"
                          @change="priorityEdit()">
                          <el-option :label="data.value" :value="String(data.key)" v-for="(data,index) in priorityList"
                            :key="index">
                            <template slot-scope="scope">
                              <span style="float: left">
                                <span class="mini-circle" :style="{backgroundColor:data.color}"></span>
                                {{data.literal}}
                              </span>
                            </template>
                          </el-option>
                        </el-select>
                        <span v-else>
                          <span class="mini-circle"
                            :style="{backgroundColor:scope.row.display.detail.priority.color}"></span>
                          {{scope.row.display.detail.priority.literal}}
                        </span>
                      </template>
                    </el-table-column>
                    <el-table-column label="迭代" min-width="80">
                      <template slot-scope="scope">
                        <el-select v-if="scope.row.isNewAdd == 2" style="width:100%;" v-model="editRequireData.sprintId"
                          @change="sprintIdedit()">
                          <el-option v-for="item in sprintList" :key="item.id" :label="item.value" :value="item.key">
                          </el-option>
                        </el-select>
                        <span v-else>{{scope.row.display.sprint||'--'}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="状态" min-width="80">
                      <template slot-scope="scope">
                        <el-select v-if="scope.row.isNewAdd == 2" style="width:100%;" v-model="editRequireData.statusId"
                          @change="statusChange()">
                          <el-option v-for="item in nextStatusList" :key="item.statusId" :label="item.statusName"
                            :value="item.statusId"></el-option>
                        </el-select>
                        <span v-else>{{scope.row.display.status}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="处理人" min-width="80">
                      <template slot-scope="scope">
                        <el-select v-model="editRequireData.assignUser" filterable v-if="scope.row.isNewAdd == 2"
                          @change="assignUserEdit()">
                          <el-option v-for="(data,index) in assignUserData" :key="data.key" :value="data.key"
                            :label="data.value">
                            <!-- <template slot-scope="scope">{{data.userName}}({{data.userId}})</template> -->
                          </el-option>
                        </el-select>
                        <span v-else>{{scope.row.display.assignUser}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="开始日期" min-width="100">
                      <template slot-scope="scope">
                        <custom-date v-if="scope.row.isNewAdd == 2" v-model="editRequireData.startTime" type="date"
                          class="date_form1" placeholder="选择日期" value-format="yyyy-MM-dd" prefix-icon="clean-icon"
                          @change="startTimeEdit()"></custom-date>
                        <span v-else>{{scope.row.endTime}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="结束日期" min-width="100">
                      <template slot-scope="scope">
                        <custom-date v-if="scope.row.isNewAdd == 2" v-model="editRequireData.endTime" type="date"
                          class="date_form1" placeholder="选择日期" value-format="yyyy-MM-dd" prefix-icon="clean-icon"
                          @change="endTimeEdit()"></custom-date>
                        <span v-else>{{scope.row.endTime}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column label="操作" min-width="80">
                      <template slot-scope="scope">
                        <span v-if="scope.row.isNewAdd == 2" class="c-blue cp" @click="handelCancelEdit()">取消</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </el-tab-pane>
            <el-tab-pane :label="panelabel.discuss" name="0">
              <div class="detailed-information1" ref="detaild" v-show="statusObject.activeName2==='0'">
                <comment-list workItemType="1" :workItemId="requireId"
                  :projectId="projectId || this.getUrlParams().projectId" @discussFun="discussFun"></comment-list>
              </div>
            </el-tab-pane>
            <el-tab-pane :label="panelabel.correctlist" name="1">
              <div class="detailed-information1" v-show="statusObject.activeName2==='1'">
                <div>
                  <el-table :data="revisedList" border style="width: 100%">
                    <el-table-column prop="version" label="修订版本"></el-table-column>
                    <el-table-column prop="updateTime" label="修订时间"></el-table-column>
                    <el-table-column prop="display.createUser" label="操作人"></el-table-column>
                    <el-table-column label="操作">
                      <template slot-scope="scope">
                        <span class="cp c-blue" @click="viewRequireRevise(scope.row.id)">查看</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="revisedList-paging">
                  <el-pagination v-show="revisedList && revisedList.length != 0" class="fr" style="margin-top: 9px;"
                    @size-change="handleRevisedPageSizeChange" @current-change="handleRevisedPageNumChange"
                    :current-page="revisedPageInfo.pageNumber" :page-sizes="[10, 20, 30]"
                    :page-size="revisedPageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper"
                    :total="revisedPageInfo.totalRecords"></el-pagination>
                </div>
              </div>
              <el-dialog title="修订详情" :visible.sync="revisedDialogVisible" class="issuedialog"
                :modal-append-to-body="false">
                <div class="form-iterm-box" id="reviseDetail" :modal-append-to-body="false"></div>
              </el-dialog>
            </el-tab-pane>
            <el-tab-pane :label="panelabel.operarecord" name="2">
              <div class="detailed-information1" v-show="statusObject.activeName2==='2'">
                <time-line :data="operationLogDataList" :loadmoreCallback="loadmoreOperationLogDataList"
                  :isMore="operationLogPageInfo.isMore"></time-line>
              </div>
            </el-tab-pane>
            <el-tab-pane :label="panelabel.codeCommit" name="5">
              <code-commit :workItemId="requireId" :workItemType="1" :update="codeCommitUpdata"
                :projectId="projectId||this.getUrlParams().projectId"></code-commit>
            </el-tab-pane>
            <!-- <el-tab-pane label="定时任务补偿" name="fourth">定时任务补偿</el-tab-pane> -->
          </el-tabs>
        </div>
      </div>
      <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
    </div>
    <el-dialog :visible.sync="assocRequireDialogVisible" title="关联需求" class="el-dialog-880w"
      :modal-append-to-body="false">
      <div class="form-iterm-box" style="padding-top: 0px !important;">
        <el-form :inline="true" class="demo-form-inline mb10">
          <el-form-item label="项目：" style="font-size:15px;color:#555;">
            <el-select placeholder="选择项目" style="width:200px;" v-model="assocRequireSearchInfo.projectId">
              <!--<el-option label="全部" value="-1"></el-option>-->
              <el-option v-for="item in projectNameList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="标题：">
            <el-input placeholder="请输入需求标题关键字" v-model="assocRequireSearchInfo.title"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="searchAssocRequrie">查询</el-button>
          </el-form-item>
        </el-form>
        <div class="table-box-top">
          <el-table :data="assocRequireDataList" ref="assocRequireTableRef" style="width: 100%;height: 100%;">
            <el-table-column type="selection" width="40"></el-table-column>
            <el-table-column label="需求ID" width="70" prop="result.id">
              <template slot-scope="scope">
                <span class="c-blue cp">{{scope.row.id}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="display.title" label="需求标题" min-width="180">
              <template slot-scope="scope">
                <span class="c-blue cp">{{scope.row.display.title}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="display.projectName" label="所属项目" min-width="80"></el-table-column>
            <el-table-column prop="display.assignUser" label="处理人" min-width="80">
              <!-- <template slot-scope="scope">
                    <el-select  v-model="scope.row.display.assignUser" @change="handleAssignerChange()"
                    filterable remote reserve-keyword @click.native="handleassignUser" :remote-method="remoteMethod">
  
                    <el-option v-for="(data,index) in assignUserData" :key="data.userId" :value="data.userId"
                      :label="data.userName">
                      <template slot-scope="scope">{{data.userName}}({{data.userId}})</template>
                    </el-option>
                  </el-select>
                </template>-->
            </el-table-column>
            <el-table-column prop="display.status" label="状态" width="80"></el-table-column>
          </el-table>
        </div>
        <div class="table_b_f_b">
          <el-pagination v-show="assocRequireDataList && assocRequireDataList.length != 0" class="fr mr10"
            style="margin-top: 9px;" @size-change="handleAssocRequirePageSizeChange"
            @current-change="handleAssocRequirePageNumChange" :current-page="assocRequirePageInfo.pageNumber"
            :page-sizes="[10, 20, 30]" :page-size="assocRequirePageInfo.pageSize"
            layout="total, sizes, prev, pager, next, jumper" :total="assocRequirePageInfo.totalRecords"></el-pagination>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleSureAssocRequrie()">关联</el-button>
      </span>
    </el-dialog>
    <requirement-clone :requireId="requireId || 0" :cloneRequirementModalStatus="cloneRequirementModalStatus"
      :closeModal="handelRequirementClone" :projectId="getUrlParams().projectId || projectId"></requirement-clone>
    <custom-status v-if="statusShow" :statusHeight="showStausObj.statusHeight" :statusleft="showStausObj.statusleft"
      :projectId="getUrlParams().projectId || projectId" :statusId="showStausObj.statusId"
      :workItemType="showStausObj.workItemType" :workItemId="showStausObj.workItemId" @closeStatus="closeStatus"
      :updateData="updateRquire">
    </custom-status>
  </div>

</template>

<script>
  /**
       Auth: Lei.j1ang
       Created: 2018/1/19-14:54
       */

  import editor from "@/components/tool/markedit";
  import slide from "components/tool/slideSlip";
  import ProjectCommonMixin from "components/project/ProjectCommonMixin";
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import GlobalSelect from "@/components/tool/FieldEdit/GlobalSelect.vue";
  import GlobalInput from "@/components/tool/FieldEdit/GlobalInput.vue";
  import taskEdit from "components/project/task/taskEdit.vue";
  import FieldEdit from "@/components/tool/FieldEdit";
  import TimeLine from "@/components/tool/TimeLine";
  import FileUpload from "@/components/commonComponents/FileUpload";
  import ShowLarger from "@/components/commonComponents/ShowLarger";
  import CommentList from "@/components/commonComponents/CommentList";
  import TinyMce from "components/tool/tinymce";
  import CodeCommit from "@/components/commonComponents/CodeCommit";
  import ExpectHour from "@/components/commonComponents/ExpectHour";
  import BasicInfoCustomField from "@/components/project/BasicInfoCustomField";
  import RequirementClone from "./RequirementClone";
  import ChangeFatherRquire from "./ChangeFatherRquire"
  export default {
    name: "requirementView",
    components: {
      editor,
      taskEdit,
      slide,
      FieldEdit,
      TimeLine,
      FileUpload,
      CommentList,
      GlobalSelect,
      GlobalInput,
      TinyMce,
      CodeCommit,
      ExpectHour,
      RequirementClone,
      ShowLarger,
      ChangeFatherRquire,
      BasicInfoCustomField
    },
    data() {
      return {
        cloneRquireModalStatus: false,
        deleteParentRequire: false,
        statusObject: {
          activeName2: "3", //评论等状态控制,
          editTitleStatus: 1, //标题状态控制
          fullScreen: false,
        },

        timeVal: {
          start: "",
          end: ""
        }, //时间编辑状态控制
        editTask: false,
        html: "",
        deleteShow: false,
        urlParam: {
          projectId: 0,
          requireId: 0
        },
        demandShow: false, //展示需求关联
        showMore: false, //展示更多
        showTxtMore: true,
        hideTxtMore: false,
        fileListShow: true,
        requirement: {
          display: {
            projectName: "",
            assignUser: "",
            end: true
          },
          priority: 0,
          categoryId: 0,
          sprintId: 0,
          statusId: 0,
          assignUser: "",
          createUser: "",
          createTime: "",
          id: -1
        },
        assignUserData: [],
        demandObject: {
          requirements: []
        },
        // 已经关联工作项 add by hyj
        assocObject: {
          //父需求
          parentRequirements: [],
          requirements: [],
          tasks: [],
          defects: [],
          modalStatu: false // 模态框打开情况
        },
        editStatus: 1, //1处于只读状态，2处于可编辑状态
        editBackupValue: null, //编辑的备份数据，点击取消后 展示该值
        statusValue: "",
        editorSetting: {
          height: 400
        },
        colorType: {
          bg: "bg",
          ft: "font",
          cr: "circle"
        },
        field: {
          title: "title",
          content: "content",
          expectedTime: "expectedTime",
          assignUser: "assignUser",
          priority: "priority",
          category: "category",
          sprintId: "sprintId",
          startTime: "startTime",
          endTime: "endTime",
          statusId: "statusId"
        },
        intermediateValue: "", //处理监听子组件返回的中间值
        labelPosition: "right",
        formLabelAlign: {
          name: "",
          region: "",
          type: ""
        },
        //切换信息

        //切换选项切换绑定的值
        disabledTask: "",
        radio3: 2,
        radio2: 1,
        upoladID: {
          workItemType: 1,
          workItemId: this.requireId
        },
        uploadActionUrl: $http.api.attachment.upload.url,
        fatherDemandData: [], //父需求
        childDemandData: [], //子需求
        operaisdisable: false, //保存中
        association: [], //关联需求
        taskDataList: [], //任务分解
        revisedList: [], //修订列表
        revisedPageInfo: { pageSize: 10, pageNumber: 1 },
        revisedDialogVisible: false,
        comment: "",
        commentDataList: [],
        commentPageInfo: { pageSize: 10, pageNum: 1 },
        operationLogDataList: [],
        operationLogPageInfo: { pageSize: 10, pageNum: 1, isMore: false },
        fileDataList: [],
        requrieCategoryList: [],
        assignUserList: [],
        sprintList: [],
        nextStatusList: [],
        minHeight: null,
        createRequireData: {
          isNewAdd: 1,
          title: "",
          projectId: 0,
          parentId: 0,
          sprintId: "",
          priority: "80",
          assignUser: null,
          startTime: "",
          endTime: "",
          statusId: ""
        },
        editRequireData: {
          isNewAdd: 2,
          title: "",
          projectId: 0,
          parentId: 0,
          sprintId: "",
          priority: "80",
          assignUser: null,
          startTime: "",
          endTime: "",
          statusId: ""
        },
        saveTitle: "",
        updateTaskData: {},
        createTaskInfo: {
          isNewAdd: null,
          title: "",
          priority: "80",
          startTime: null,
          endTime: null,
          expectHour: null,
          assignUser: null,
          priority: "",
          progress: 0,
          projectId: this.projectId,
          requireId: this.requireId,
          sprintId: 0
        },
        assocRequireDialogVisible: false,
        assocRequireDataList: [],
        assocRequirePageInfo: { pageSize: 10, pageNumber: 1 },
        projectNameList: [],
        assocRequireSearchInfo: {
          projectId: this.parseInteger(this.getUrlParams().projectId),
          title: null,
          isArchived: -1,
          pageInfo: {}
        },
        userData: {},
        idVip: null,
        idEditVip: null,
        showheader: false,
        loading: false,
        expectHourList: [
          { value: 4, label: "0.5天" },
          { value: 8, label: "1天" },
          { value: 12, label: "1.5天" },
          { value: 16, label: "2天" },
          { value: 20, label: "2.5天" },
          { value: 24, label: "3天" }
        ],
        priorityList: [], //优先级列表
        commentUpdata: false, // 更新评论列表
        codeCommitUpdata: false, // 更新代码列表
        panelabel: {
          tesk: "任务分解(0)",
          childrequrie: "子需求(0)",
          discuss: "评论(0)",
          correctlist: "修订列表(0)",
          operarecord: "操作记录(0)",
          codeCommit: "代码提交(0)"
        },
        cloneRequirementModalStatus: false, // 复制需求模态框状态
        statusShow: false,
        showStausObj: {},
      };
    },
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    props: {
      requireId: {
        type: [Number, String],
        default: null
      },
      projectId: {
        type: [Number, String],
        default: null
      },
      show: {
        type: Boolean,
        default: false
      }
    },
    computed: {},
    watch: {
      show: function (newVal, oldVal) {
        if (newVal === false) {
          this.editStatus = 1;
        }
      },
      statusObject: {
        handler(newInfo, oldInfo) {
          if (newInfo.fullScreen) {
            document.getElementById('contentBox').style.overflowY = 'hidden';
          } else {
            document.getElementById('contentBox').style.overflowY = '';
          }
        },
        deep: true
      },
      requireId: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          if (this.requireId == -1 || this.requireId == 0) { return; }
          this.$nextTick(() => {
            this.upoladID.workItemId = this.requireId;
            this.urlParam.projectId =
              this.getUrlParams().projectId || this.projectId;
            this.statusObject.activeName2 = "3";

            this.getRequirementInfo();
            this.getDemandRelevance();
            this.getTaskDecomposition();
            this.getAttachmentList();
            // this.getCommentList();
            this.getSprintList();
            this.getAssignUser();
            this.getRequireCategoryList();
            this.getPriorityList();
            this.boxShowmore(newVal, oldVal);
            this.tabRelateditem();
            this.demandShow = false;
          });
        }
      }
    },
    mounted() {
      this.userData = $utils.getStorage(GLOBAL_CONST.USER_INFO);
      if (this.requireId) {
        this.upoladID.workItemId = this.requireId;
        this.urlParam.projectId = this.getUrlParams().projectId || this.projectId;
        this.getRequirementInfo();
        this.getDemandRelevance();
        this.getTaskDecomposition();
        this.getAttachmentList();
        // this.getCommentList();
        this.getSprintList();
        this.getAssignUser();
        this.getRequireCategoryList();
        this.getPriorityList();
        this.tabRelateditem();
      }
      // 获取自定义字段列表
      this.getCustomFieldList(1, this.getUrlParams().projectId || this.projectId);
      this.getCustomFieldList(2, this.getUrlParams().projectId || this.projectId);
    },
    methods: {
      //删除父需求邱
      async deleteParentRequireFuc() {
        const result = await this.confirmBeforeOperate('是否确定解绑父需求?');
        if (!result) { return; }
        this.deleteFather()
        // this.$confirm('是否确定解绑父需求','提示', {
        //   confirmButtonText: '确定',
        //   cancelButtonText: '取消',
        //   type: 'warning'
        // }).then(() => {
        //   this.deleteFather();
        // }).catch(() => {

        // });
      },
      deleteFather() {
        $http.get($http.api.task.requirement_update, {
          id: this.requirement.id,
          oriParentId: this.requirement.parentId,
          newParentId: -1,
          confirm: 0,
        }).then(res => {
          if (res.status === 200) {
            this.$message({ type: 'success', message: '解绑父需求成功' })
            this.updateRquire()
          } else {
            this.$message({ type: 'error', message: res.msg })
          }
        })
      },
      //打开父需求弹窗
      ChangeFatherRquireFuc() {
        this.cloneRquireModalStatus = true;
      },
      //关闭父需求的弹窗
      closeModal() {
        this.cloneRquireModalStatus = false;
      },
      offsetLeft(obj) {
        var tmp = obj.offsetLeft;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetLeft;
          val = val.offsetParent;
        }
        return tmp;
      },
      offsetTop(obj) {
        var tmp = obj.offsetTop;
        var val = obj.offsetParent;
        while (val != null) {
          tmp += val.offsetTop;
          val = val.offsetParent;
        }
        return tmp;
      },
      //关闭状态框
      closeStatus() {
        this.statusShow = false;
      },
      //更新需求
      updateRquire() {
        this.getRequirementInfo();
        this.getDemandRelevance();
        this.tabRelateditem();
      },
      //展示扭转状态
      showActiveStatus(e, item, type) {
        var pw = document.body.offsetWidth - document.getElementsByClassName("silder-box")[0].offsetWidth
        this.showStausObj.statusHeight = this.offsetTop(e.target) + 30 + 'px';
        this.showStausObj.statusleft = this.offsetLeft(e.target) - pw - 560 + 'px';
        this.showStausObj.statusId = item.statusId;
        this.showStausObj.workItemType = type;
        this.showStausObj.workItemId = item.id;
        this.statusShow = !this.statusShow;
        if (this.showStausObj.workItemId && this.showStausObj.temId !== item.id) {
          this.statusShow = true;
        }
        this.showStausObj.temId = item.id;
        e.stopPropagation()
      },
      //编辑评论tinymce返回数据
      editComentLister(data) {
        this.comment = data;
      },
      //评论提交获取子组件参数
      discussFun(val){
        this.panelabel.discuss = `评论(${val.total})`;
      },
      //是否全屏
      fullScreen() {
        this.statusObject.fullScreen = !this.statusObject.fullScreen;
      },
      // 编辑器内容恢复 - add by heyunjiang on 2019.7.9
      async tinymceContentReset() {
        if(this.requireId === -1) { return ; }
        const exist = await this.isPreviousContentExist(+this.requireId, 'requirement', false, this.requirement.content);
        if (exist) {
          this.$nextTick(() => {
            this.requirement.content = exist;
            this.intermediateValue = exist;
            this.editStatus = 2;
          })
        }
      },
      // 任务联动 - add by heyunjiang on 2019.6.11
      async taskTimeChange(key) {
        const result = await this.time_linkage_calculate({
          startTime: this.createTaskInfo.startTime,
          endTime: this.createTaskInfo.endTime,
          expectHour: this.createTaskInfo.expectHour,
          modifiedFiled: key || "startTime"
        });
        if (result.status === 200) {
          this.createTaskInfo = {
            ...this.createTaskInfo,
            startTime: result.data.timeCalculateResult.startTime || 0,
            endTime: result.data.timeCalculateResult.endTime,
            expectHour: result.data.timeCalculateResult.expectHour
          };
        } else {
          this.$message({
            message: result.msg || "时间计算出错，请自行选择",
            type: "error"
          });
        }
      },
      // 全局更新标题 - add by heyunjiang on 2019.5.8
      updateGlobalTitle(info, value, workItemType) {
        let originInfo = { ...info };
        let cb = this.getTaskDecomposition;
        let updatefunc = this.GlobalRequirementUpdate;
        switch (+workItemType) {
          case 1:
            updatefunc = this.GlobalRequirementUpdate;
            cb = this.getDemandRelevance;
            break;
          case 2:
            updatefunc = this.GlobalTaskUpdate;
            cb = this.getTaskDecomposition;
            break;
          case 3:
            updatefunc = this.GlobalBugUpdate;
            break;
        }
        updatefunc({
          id: originInfo.id,
          title: value,
          projectId: originInfo.projectId || this.getUrlParams().projectId,
          cb
        });
      },
      // 更新子任务 - add by heyunjiang on 2019.5.15
      updateGlobalTaskInfo(info, e, type) {
        this.GlobalSelectTargetClick(
          { ...info, workItemType: 2 },
          e,
          type,
          this.getTaskDecomposition
        );
      },
      // 复制需求 - add by heyunjiang on 2019.6.20
      handelRequirementClone() {
        this.cloneRequirementModalStatus = !this.cloneRequirementModalStatus;
      },
      // 删除需求
      handelRequirementDelete() {
        let info = this.requirement;
        this.$confirm(`确认删除需求"${info.display.title}"吗？(需求下所有子需求以及任务均会一并删除，请确认)`, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(async () => {
            this.loading = true;
            const result = await this.requirementDelete({ id: info.id, projectId: this.projectId || this.getUrlParams().projectId, });
            this.loading = false;
            if (result.status === 200) {
              this.$message({
                message: result.msg || "需求删除成功",
                type: "success"
              });
              // 关闭当前 slider
              if (this.getUrlParams().requireId) {
                this.$router.replace({
                  path: this.$route.path,
                  query: { ...this.$route.query, requireId: null }
                });
              }
              this.bugClose();
            } else {
              this.$message({
                message: result.msg || "需求删除失败",
                type: "warning"
              });
            }
          })
          .catch(e => { });
      },
      // 需求父子关系解绑
      handelUnbindParentChildren(info, isParent) {
        this.$confirm(`确认解除当前需求与\"${info.display.title}\"的父子关系吗`, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(async () => {
            let obj = {};
            if (isParent) {
              obj = { id: this.requireId, parentId: info.id };
            } else {
              obj = { id: info.id, parentId: this.requireId };
            }
            const result = await this.requirementUnbindParentChild({ ...obj });
            if (result.status === 200) {
              this.$message({
                message: result.msg || "父子关系解绑成功",
                type: "success"
              });
              // 更新子需求
              this.getDemandRelevance();
              this.getRequirementInfo(); // 更新当前需求
              // 手动更新本地
              this.childDemandData = this.childDemandData.filter(
                item => item.id !== info.id
              );
              this.fatherDemandData = this.fatherDemandData.filter(
                item => item.id !== info.id
              );
            } else {
              this.$message({
                message: result.msg || "父子关系解绑失败",
                type: "warning"
              });
            }
          })
          .catch(e => { });
      },
      editinput() {
        if (this.editBackupValue !== this.requirement.title) {
          this.requireUpdateInfo = {};
          this.requireUpdateInfo.id = this.requireId;
          this.requireUpdateInfo.title = this.requirement.title;
          this.sendUpdateRequireRequest();
          this.editBackupValue = this.requirement.title;
        }
        this.statusObject.editTitleStatus = 1;
      },
      //各关联项数量统计
      tabRelateditem() {
        $http
          .get($http.api.requirement.relateditem, {
            id: this.requireId,
            projectId: this.projectId
          })
          .then(ret => {
            let data = ret.data;
            
            this.panelabel.tesk = `任务分解(${data.taskCount})`;
            this.panelabel.childrequrie = `子需求(${data.childReqtCount})`;
            this.panelabel.discuss = `评论(${data.commentCount})`;
            this.panelabel.correctlist = `修订列表(${data.workConentCount})`;
            this.panelabel.operarecord = `操作记录(${data.operationLogCount})`;
            this.panelabel.codeCommit = `代码提交(${data.codeCommitCount})`;
          });
      },
      //关联跳转
      demandItemClick(info, type) {
        this.toRequrieDetailPage(info);
      },
      //关联删除
      demandItemDelete(info, type, index) {
        this.$confirm("确认删除该关联?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            if (this.detailType === "editable") {
              // 新建状态
              this.demandObject[type + "s"] = this.demandObject[
                type + "s"
              ].filter(item => item.id !== info.id);
            } else {
              // 展示状态
              let targetWorkItemType = "1";
              switch (type) {
                case "requirement":
                  targetWorkItemType = "1";
                  break;
                case "task":
                  targetWorkItemType = "2";
                  break;
                case "defect":
                  targetWorkItemType = "3";
                  break;
              }
              this.assocItemDeleteHandle({
                targetId: info.id,
                targetType: +targetWorkItemType,
                originId: this.requirement.id,
                originType: 1,
                projectId: this.getUrlParams().projectId || this.projectId
              }).then(result => {
                if (result.status === 200) {
                  this.$message({
                    message: result.msg || "关联项删除成功",
                    type: "success"
                  });
                  this.getDemandRelevance();
                } else {
                  this.httpErrorHandle(result.msg);
                }
              });
            }
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除"
            });
          });
      },

      //展示需求关联
      showDemandrelevance() {
        this.demandShow = true;
      },
      //展示更多
      showMoreBtn() {
        this.showMore = false;
        this.showTxtMore = false;
        this.hideTxtMore = true;
      },
      ////收起更多
      hideMoreBtn() {
        this.showMore = true;
        this.showTxtMore = true;
        this.hideTxtMore = false;
      },
      //判断更多的盒子高度
      boxShowmore(newVal, oldVal) {
        //this.$nextTick(() => {
        setTimeout(() => {
          let boxHeight = this.$refs.showMorebox.offsetHeight;
          let boxsHeight = this.$refs.showMoresbox.offsetHeight;
          this.showTxtMore = false;
          this.showMore = false;
          if (boxsHeight > boxHeight) {
            this.showTxtMore = true;
            this.showMore = true;
            this.hideTxtMore = false;
          } else if (boxHeight > 349) {
            //this.hideTxtMore = true;
            this.showTxtMore = true;
            this.showMore = true;
            this.hideTxtMore = false;
          }
          if (boxsHeight < 349) {
            this.hideTxtMore = false;
          }
        }, 300);

        //})
      },
      //进入任务视图
      toTaskView(info) {
        this.goToNewWindowPage(this, "taskView", {
          taskId: info.id,
          projectId: info.projectId
        });
      },
      async bugClose() {
        if (this.intermediateValue !== this.requirement.content) {
          const confirmResult = await this.confirmBeforeOperate(`工作项描述已经填写/修改，请确认是否关闭`);
          if (!confirmResult) { return false; }
        }
        this.$emit('update:descNotice', false);
        this.removeTinymceContent(this.requireId);
        this.$emit("HandleSide");
      },
      handleClick(...tab) { },
      chooseTime(val) {
        if (val === "start") {
          this.timeVal.start = val;
        } else {
          this.timeVal.end = val;
        }

        this.$nextTick(() => {
          this.$refs.start.focus();
          this.$refs.end.focus();
        });

        // this.$refs.mark.$el.querySelector('input').focus();
      },
      handleEditExoectHour(id) {
        this.editTask = id;
      },
      handleSaveExoectHoue(id, value) {
        //  this.editTask = false;
      },
      //获取优先级
      getPriorityList() {
        let projectId = this.getUrlParams().projectId || this.projectId;
        $http
          .get($http.api.bug_info.priorityList, { projectId, workItemType: 1 })
          .then(res => {
            this.priorityList = res.data.map(item => {
              return {
                value: item.literal,
                key: item.priority,
                color: item.color,
                ...item
              };
            });
          });
      },
      handleassignUser() {
        // this.getAssignUser()
      },
      //获取用户
      getAssignUser(value) {
        let projectId = this.getUrlParams().projectId || this.projectId;
        let query = value || null;
        $http
          .post($http.api.project.assignUser, { projectId, query })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1

            this.assignUserData = res.data.map(item => {
              return {
                key: item.userId,
                value: item.userName + "(" + item.userId + ")"
              };
            });
           
          });
      },
      //任务分解字段更新
      updateTaskOneField(field, value) {
        // this.updateTaskData = {};
        // this.updateTaskData.id = this.getUrlParams().taskId;
        // this.updateTaskData.id =

        if (field == this.createTaskInfo.expectHour) {
          this.updateTaskData.content = value;
        } else if (field == this.createTaskInfo.assignUser) {
          this.updateTaskData.title = value;
        }

        $http
          .post($http.api.task.taskUpdate, this.updateTaskData)
          .then(res => {
            if (res.status === 200) {
              this.$message({
                message: res.msg || "修改任务成功",
                type: "success"
              });
              this.getTaskDecomposition();
            } else {
              this.$message({
                message: res.msg || "修改任务失败",
                type: "error"
              });
            }
          })
          .catch(e => {
            this.getTaskDecomposition();
          });
      },
      HandleShow() {
        this.fileListShow = !this.fileListShow;
      },
      HnadleSaveSptint() {
        this.editBackupValue = this.requirement.sprintId;
      },
      editHnadle(data) {
        this.intermediateValue = data;
        if (data !== this.requirement.content) {
          this.$emit('update:descNotice', true);
          this.saveTinymceContent({
            value: data,
            id: this.requireId,
            type: 'requirement', // 需求、任务、缺陷
            isNew: false
          })
        } else {
          this.$emit('update:descNotice', false);
        }
      },
      parseInteger(value) {
        let val = value || this.projectId;
        return parseInt(val);
      },
      //分解任务成功保存
      saveTask() {
        this.createTaskInfo.projectId = this.urlParam.projectId || this.projectId;
        this.createTaskInfo.requireId = this.requireId;
        // 任务工时校验
        if (
          this.createTaskInfo.expectHour &&
          this.createTaskInfo.expectHour % 2 > 0
        ) {
          this.$message({
            message: "任务工时必须为2的倍数",
            type: "warning"
          });
          return false;
        }
        // this.createTaskInfo.sprintId = 0;
        if (this.createTaskInfo.title && this.createTaskInfo.title !== " ") {
          this.createTask();
          this.taskDataList.shift();
        } else {
          this.$message({
            message: "标题为必填项",
            type: "error"
          });
          return;
        }
      },
      //取消创建任务
      cancelSaveTask() {
        this.taskDataList.shift();
      },
      // 删除
      taskDelete(val) {
        this.$confirm("此操作将删除该数据, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            $http
              .get($http.api.task.deleteTask, { id: val }, { type: "form" })
              .then(res => {
                if (res != undefined) {
                  this.$message({
                    message: "删除成功",
                    type: "success"
                  });
                  this.getTaskDecomposition();
                  this.tabRelateditem();
                }
              });
          })
          .catch(() => { });
      },
      downloadHandle(row) {
        window.location.href = row.url;
      },
      handleUploadSuccess(res) {
        this.fileDataList.push(res.data);
      },
      HandleSide(e) {
        this.timeVal.start = "";
        this.timeVal.end = "";
        this.closeStatus()
        //隐藏上传&关联文档tips doc-upload
        this.publicHideTips(e)
        // if (this.statusObject.editTitleStatus === 2) {
        //   if (this.editBackupValue !== this.requirement.title) {
        //     this.requireUpdateInfo = {};
        //     this.requireUpdateInfo.id = this.requireId;
        //     this.requireUpdateInfo.title = this.requirement.title;
        //     this.sendUpdateRequireRequest();
        //     this.editBackupValue = this.requirement.title;
        //   }
        // }
        // this.statusObject.editTitleStatus = 1;
      },
      onTitleEdit() {
        this.statusObject.editTitleStatus = 2;
        this.editBackupValue = this.requirement.title;

        this.$nextTick(function () {
          this.$refs.titleInput.focus();
        });
      },
      onEditRequirement() {
        this.editStatus = 2;
        if (this.statusObject.fullScreen) {
          this.minHeight = document.documentElement.clientHeight;
        } else {
          this.minHeight = null;
        }
        this.$nextTick(() => {
          // console.log(this.$refs.fullFuc123)
          this.sprintLock();
          this.editStatus = 2;
          this.showMore = false;
          this.showTxtMore = false;
          this.hideTxtMore = false;
          // this.$refs.fullFuc123.mceFullScreenFuc();
        })
      },
      sprintLock() {
        $http
          .get($http.api.sprint.base_info, {
            sprintId: this.requirement.sprintId,
            projectId: this.urlParam.projectId || this.projectId
          })
          .then(res => {
            if (res.data.isLocked) {
              this.$confirm("迭代已锁定，修改需求描述会记录需求变更", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
              });
            }
          });
      },
      handleCancelEdit() {
        this.editStatus = 1;
        this.boxShowmore();
        this.$emit('update:descNotice', false);
        this.removeTinymceContent(this.requireId);
      },
      handleSaveEdit() {
        this.requirement.content = this.intermediateValue;
        this.prepareUpdateRequire(this.field.content, this.requirement.content);
        this.editStatus = 1;
        this.$emit('update:descNotice', false);
        // 我加入的代码
        $http
          .post($http.api.requirement.update, this.requireUpdateInfo)
          .then(res => {
            if (res.status == 200) {
              this.$message({ message: "修改需求成功", type: "success" });
              this.removeTinymceContent(this.requireId);
              this.getRevisedList();
              this.tabRelateditem();
              this.boxShowmore();
            }
          });
      },
      // 关联工作项-获取已经关联的列表
      getAssocList(detailInfo) {
        this.assocItemGetHandle({
          workItemType: 1,
          workItemId: detailInfo.id,
          projectId: this.urlParam.projectId || this.projectId
        }).then(result => {
          if (result.status === 200) {
            this.assocObject.parentRequirements =
              result.data.parent && Object.keys(result.data.parent).length > 0
                ? [{ ...result.data.parent }]
                : [];
            this.assocObject.requirements = result.data.requirements;
            this.assocObject.tasks = result.data.tasks;
            this.assocObject.defects = result.data.defects;
          } else {
            this.assocObject.parentRequirements = [];
            this.assocObject.requirements = [];
            this.assocObject.tasks = [];
            this.assocObject.defects = [];
            this.httpErrorHandle(result.msg);
          }
        });
      },
      getDemandRelevance() {
        if(this.requireId === -1) { return ; }
        this.getAssocList({ id: this.requireId });
        // return ;
        $http
          .get($http.api.requirement.demandRelevance, {
            projectId: this.urlParam.projectId || this.projectId,
            id: this.requireId
          })
          .then(res => {
            //     //todo cpp 这里应该获取自己的queryType=1

            // this.fatherDemandData = res.data.parent;
            //     this.demandObject.requirements = res.data.association;//关联需求
            if (this.fatherDemandData[0]) {
              this.fatherDemandData[0].father = 1;
            }
            this.childDemandData = res.data.children;
            if (this.childDemandData[0]) {
              this.childDemandData[0].isFirst = 1;
            }
            //    // this.association = res.data.association;
            //     if (this.association[0]) {
            //       this.association[0].association = 1;
            //     }
          });
      },
      getTaskDecomposition() {
        if(this.requireId === -1) { return ; }
        $http
          .get($http.api.requirement.taskDecomposition, {
            projectId: this.urlParam.projectId || this.projectId,
            id: this.requireId
          })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1
            this.taskDataList = res.data;
          });
      },
      getRevisedList() {
        if(this.requireId === -1) { return ; }
        let pageInfo = {
          pageNumber: this.revisedPageInfo.pageNumber,
          pageSize: this.revisedPageInfo.pageSize
        };
        $http
          .post($http.api.requirement.revisedList, {
            workItemType: 1,
            workItemId: this.requireId,
            projectId: this.urlParam.projectId || this.projectId,
            pageInfo
          })
          .then(res => {
            this.revisedList = res.data.results;
            this.revisedPageInfo = res.data.pageInfo;
          });
      },

      viewRequireRevise(reviseId) {
        $http
          .get($http.api.requirement.reviseDetail, { id: reviseId })
          .then(res => {
            if (res.status == 200) {
              this.revisedDialogVisible = true;
              this.$nextTick(() => {
                let elementById = document.getElementById("reviseDetail");
                elementById.innerHTML = res.data.content;
              });
            }
          });
      },
      createTask() {
        $http
          .post($http.api.requirement.createTask, {
            ...this.createTaskInfo,
            ...this.getCustomFieldsPresetValues(2)
          })
          .then(res => {
            this.getTaskDecomposition();
            this.$message({
              message: "分解任务成功",
              type: "success"
            });
            this.tabRelateditem();
          });
      },
      addTaskHandle() {
        for (let i of this.taskDataList) {
          if (i.isNewAdd) {
            return this.$message({
              message: "同时只能增加一条任务",
              type: "warning"
            });
          }
        }
        // contentBox.scrollTop = contentBox.scrollHeight
        this.createTaskInfo.isNewAdd = 1;
        this.createTaskInfo.title = "";
        this.createTaskInfo.priority = this.requirement.priority;
        this.createTaskInfo.startTime = "";
        this.createTaskInfo.endTime = "";
        this.createTaskInfo.expectHour = 4;
        this.createTaskInfo.assignUser = this.requirement.assignUser;
        this.createTaskInfo.progress = null;
        this.createTaskInfo.sprintId = this.requirement.sprintId;
        this.taskDataList.unshift(this.createTaskInfo);
      },
      //获取今天明天后天的日期
      _GetDateStr(AddDayCount) {
        let date = new Date(this.createTaskInfo.startTime);
        date.setDate(date.getDate() + AddDayCount);
        let y = date.getFullYear();
        let m = date.getMonth() + 1;
        let d = date.getDate();
        return y + "-" + m + "-" + d;
      },

      //选择工时得出截止日期
      // selectExpectHour() {
      //   if (
      //     this.createTaskInfo.expectHour == 4 ||
      //     this.createTaskInfo.expectHour == 8
      //   ) {
      //     this.createTaskInfo.endTime = this._GetDateStr(0);
      //   } else if (
      //     this.createTaskInfo.expectHour == 12 ||
      //     this.createTaskInfo.expectHour == 16
      //   ) {
      //     this.createTaskInfo.endTime = this._GetDateStr(1);
      //   } else if (
      //     this.createTaskInfo.expectHour == 20 ||
      //     this.createTaskInfo.expectHour == 24
      //   ) {
      //     this.createTaskInfo.endTime = this._GetDateStr(2);
      //   }
      // },

      //表格鼠标双击事件
      handleMouseEnter(val) {
        let flag = false;
        this.taskDataList.map(item => {
          if (item.isNewAdd) {
            this.$message({ message: "一次只可编辑一条数据", type: "info" });
            flag = true;
          }
        });
        if (flag == false) {
          this.idVip = val.id;
          this.createTaskInfo.isNewAdd = 2;
          this.createTaskInfo.title = val.display.title;
          this.createTaskInfo.priority = val.display.priority;
          this.createTaskInfo.endTime = val.endTime;
          this.createTaskInfo.expectHour = val.expectHour;
          this.createTaskInfo.assignUser = val.assignUser;
          this.createTaskInfo.progress = val.progress;
          this.createTaskInfo.projectId =
            this.getUrlParams().projectId || this.projectId;
          this.createTaskInfo.requireId = this.requireId;
          this.createTaskInfo.sprintId = val.sprintId;
          this.taskDataList.forEach((item, index) => {
            if (item.id == val.id) {
              this.taskDataList.splice(index, 1, this.createTaskInfo);
            }
          });
        }
      },
      //取消编辑
      HandleTaskEdit() {
        $http
          .post($http.api.task.taskUpdate, { id: this.idVip })
          .then(res => {
            this.getTaskDecomposition();
          })
          .catch(() => {
            this.getTaskDecomposition();
          });
      },
      //任务更新
      updateTaskInfo(key, value) {
        let params = {
          id: this.idVip,
          [key]: value
        };
        $http
          .post($http.api.task.taskUpdate, params)
          .then(res => {
            this.getTaskDecomposition();
            this.$message({
              message: "编辑成功",
              type: "success"
            });
          })
          .catch(() => {
            this.getTaskDecomposition();
          });
      },
      //标题更新
      blurSearchFor() {
        this.updateTaskInfo("title", this.createTaskInfo.title);
      },
      //优先级更新
      priorityChange() {
        this.updateTaskInfo("priority", this.createTaskInfo.priority);
      },
      //处理人更新
      assignUserChange() {
        this.updateTaskInfo("assignUser", this.createTaskInfo.assignUser);
      },
      //预计工时更新
      blurexpectHour(index) {
        //index = 1表示撞创建状态 2表示更新状态
        if (this.createTaskInfo.startTime) {
          if (
            this.createTaskInfo.expectHour == 4 ||
            this.createTaskInfo.expectHour == 8
          ) {
            this.createTaskInfo.endTime = this._GetDateStr(0);
          } else if (
            this.createTaskInfo.expectHour == 12 ||
            this.createTaskInfo.expectHour == 16
          ) {
            this.createTaskInfo.endTime = this._GetDateStr(1);
          } else if (
            this.createTaskInfo.expectHour == 20 ||
            this.createTaskInfo.expectHour == 24
          ) {
            this.createTaskInfo.endTime = this._GetDateStr(2);
          }
        }
        if (index === 2) {
          this.updateTaskInfo("expectHour", this.createTaskInfo.expectHour);
          this.updateTaskInfo("endTime", this.createTaskInfo.endTime);
        }
      },
      //预计开始日期更新
      startTimeChange(index) {
        //index = 1表示撞创建状态 2表示更新状态
        let nowDate = this.formatDate(new Date(), "yyyyMMdd");
        let startTime = this.createTaskInfo.startTime.replace(/-/g, "");
        if (parseInt(nowDate.substring(0, 9)) > parseInt(startTime)) {
          this.$message({
            message: "预计开始日期不能小于当前日期",
            type: "warning"
          });
          return;
        }
        this.blurexpectHour(index);
        if (index === 2) {
          this.updateTaskInfo("startTime", this.createTaskInfo.startTime);
        }
      },
      //结束时间更新
      endTimeChange() {
        let nowDate = this.formatDate(new Date(), "yyyyMMdd");
        let endTime = this.createTaskInfo.endTime.replace(/-/g, "");
        if (parseInt(nowDate.substring(0, 9)) > parseInt(endTime)) {
          this.$message({
            message: "预计结束日期不能小于当前日期",
            type: "warning"
          });
          return;
        }
        this.updateTaskInfo("endTime", this.createTaskInfo.endTime);
      },
      sprintIdChange() {
        this.updateTaskInfo("sprintId", this.createTaskInfo.sprintId);
      },
      // statusIdChange() {
      //   this.updateTaskInfo('statusId',this.createTaskInfo.statusId);
      // },

      handleAddChildRequrie() {
        if (this.childDemandData.length < 1) {
          this.createRequireData.isFirst = true;
        } else {
          this.createRequireData.isFirst = false;
        }

        for (var i in this.childDemandData) {
          if (this.childDemandData[i].isNewAdd) {
            return this.$message({
              message: "同时只能增加一条子需求",
              type: "warning"
            });
            return;
          }
        }
        this.createRequireData.priority = this.requirement.priority+'';
        this.childDemandData.push(this.createRequireData);
      },

      handEditTable_a(val) {
        let flag = false;

        if (this.childDemandData.length == 0) {
          this.fatherDemandData.map(a => {
            this.association.map(c => {
              if (a.isNewAdd || c.isNewAdd) {
                this.$message({ message: "一次只可编辑一条数据", type: "info" });
                flag = true;
              }
            });
          });
        }

        if (this.association.length == 0) {
          this.fatherDemandData.map(a => {
            this.childDemandData.map(b => {
              if (a.isNewAdd || b.isNewAdd) {
                this.$message({ message: "一次只可编辑一条数据", type: "info" });
                flag = true;
              }
            });
          });
        }

        if (this.childDemandData.length == 0 && this.association.length == 0) {
          this.fatherDemandData.map(a => {
            if (a.isNewAdd) {
              this.$message({ message: "一次只可编辑一条数据", type: "info" });
              flag = true;
            }
          });
        }

        if (
          (this.fatherDemandData.length != 0 &&
            this.childDemandData.length != 0) ||
          this.association.length != 0
        ) {
          this.fatherDemandData.map(a => {
            this.childDemandData.map(b => {
              this.association.map(c => {
                if (a.isNewAdd || b.isNewAdd || c.isNewAdd) {
                  this.$message({
                    message: "一次只可编辑一条数据",
                    type: "info"
                  });
                  flag = true;
                }
              });
            });
          });
        }

        if (flag == false) {
          this.idEditVip = val.id;
          this.editRequireData.title = val.display.title;
          this.editRequireData.priority = val.priority;
          this.editRequireData.sprintId = val.sprintId;
          this.editRequireData.statusId = val.statusId;
          this.editRequireData.assignUser = val.assignUser;
          this.editRequireData.startTime = val.startTime;
          this.editRequireData.endTime = val.endTime;
          this.fatherDemandData.forEach((i, index_i) => {
            if (i.id == this.idEditVip) {
              this.fatherDemandData.splice(index_i, 1, this.editRequireData);
            }
          });
        }
      },
      handEditTable_b(val) {
        let flag = false;
        if (this.fatherDemandData.length == 0) {
          this.childDemandData.map(b => {
            this.association.map(c => {
              if (b.isNewAdd || c.isNewAdd) {
                this.$message({ message: "一次只可编辑一条数据", type: "info" });
                flag = true;
              }
            });
          });
        }

        if (this.association.length == 0) {
          this.fatherDemandData.map(a => {
            this.childDemandData.map(b => {
              if (a.isNewAdd || b.isNewAdd) {
                this.$message({ message: "一次只可编辑一条数据", type: "info" });
                flag = true;
              }
            });
          });
        }

        if (this.fatherDemandData.length == 0 && this.association.length == 0) {
          this.childDemandData.map(b => {
            if (b.isNewAdd) {
              this.$message({ message: "一次只可编辑一条数据", type: "info" });
              flag = true;
            }
          });
        }

        if (
          (this.fatherDemandData.length != 0 &&
            this.childDemandData.length != 0) ||
          this.association.length != 0
        ) {
          this.fatherDemandData.map(a => {
            this.childDemandData.map(b => {
              this.association.map(c => {
                if (a.isNewAdd || b.isNewAdd || c.isNewAdd) {
                  this.$message({
                    message: "一次只可编辑一条数据",
                    type: "info"
                  });
                  flag = true;
                }
              });
            });
          });
        }

        if (flag == false) {
          this.idEditVip = val.id;
          this.editRequireData.title = val.display.title;
          this.editRequireData.priority = val.priority;
          this.editRequireData.sprintId = val.sprintId;
          this.editRequireData.statusId = val.statusId;
          this.editRequireData.assignUser = val.assignUser;
          this.editRequireData.startTime = val.startTime;
          this.editRequireData.endTime = val.endTime;
          this.childDemandData.forEach((i, index_i) => {
            if (i.id == this.idEditVip) {
              this.childDemandData.splice(index_i, 1, this.editRequireData);
            }
          });
        }
      },
      handEditTable_c(val) {
        let flag = false;

        if (this.fatherDemandData.length == 0) {
          this.childDemandData.map(b => {
            this.association.map(c => {
              if (b.isNewAdd || c.isNewAdd) {
                this.$message({ message: "一次只可编辑一条数据", type: "info" });
                flag = true;
              }
            });
          });
        }

        if (this.childDemandData.length == 0) {
          this.fatherDemandData.map(a => {
            this.association.map(c => {
              if (a.isNewAdd || c.isNewAdd) {
                this.$message({ message: "一次只可编辑一条数据", type: "info" });
                flag = true;
              }
            });
          });
        }

        if (
          this.childDemandData.length == 0 &&
          this.fatherDemandData.length == 0
        ) {
          this.association.map(c => {
            if (c.isNewAdd) {
              this.$message({ message: "一次只可编辑一条数据", type: "info" });
              flag = true;
            }
          });
        }
        if (
          (this.fatherDemandData.length != 0 &&
            this.childDemandData.length != 0) ||
          this.association.length != 0
        ) {
          this.fatherDemandData.map(a => {
            this.childDemandData.map(b => {
              this.association.map(c => {
                if (a.isNewAdd || b.isNewAdd || c.isNewAdd) {
                  this.$message({
                    message: "一次只可编辑一条数据",
                    type: "info"
                  });
                  flag = true;
                }
              });
            });
          });
        }
        if (flag == false) {
          this.idEditVip = val.id;
          this.editRequireData.title = val.display.title;
          this.editRequireData.priority = val.priority;
          this.editRequireData.sprintId = val.sprintId;
          this.editRequireData.statusId = val.statusId;
          this.editRequireData.assignUser = val.assignUser;
          this.editRequireData.startTime = val.startTime;
          this.editRequireData.endTime = val.endTime;
          this.association.forEach((i, index_i) => {
            if (i.id == this.idEditVip) {
              this.association.splice(index_i, 1, this.editRequireData);
            }
          });
        }
      },

      // 取消编辑
      handelCancelEdit() {
        $http
          .post($http.api.requirement.update, {
            id: this.idEditVip
          })
          .then(res => {
            this.getDemandRelevance();
          })
          .catch(() => {
            this.getDemandRelevance();
          });
      },
      //关联需求更新
      requirementUpdateInfo(key, value) {
        $http
          .post($http.api.requirement.update, {
            id: this.idEditVip,
            [key]: value
          })
          .then(res => {
            if (res.status === 200) {
              this.getDemandRelevance();
              this.$message({ message: res.msg || "编辑成功", type: "success" });
            } else {
              this.$message({ message: res.msg || "编辑失败", type: "error" });
            }
          })
          .catch(() => {
            this.getDemandRelevance();
          });
      },
      //需求关联标题编辑
      blurSearchEdit() {
        if (
          this.editRequireData.title.length <= 0 ||
          this.editRequireData.title.length > 64
        ) {
          this.$message({ message: "标题长度只能在1~64之间", type: "warning" });
          return;
        }
        this.requirementUpdateInfo("title", this.editRequireData.title);
      },

      // 需求关联迭代编辑
      sprintIdedit() {
        this.requirementUpdateInfo("sprintId", this.editRequireData.sprintId);
      },
      //需求关联状态
      statusChange() {
        this.requirementUpdateInfo("statusId", this.editRequireData.statusId);
      },
      //需求关联优先级编辑
      priorityEdit() {
        this.requirementUpdateInfo("priority", this.editRequireData.priority);
      },
      //需求关联处理人编辑
      assignUserEdit() {
        this.requirementUpdateInfo("assignUser", this.editRequireData.assignUser);
      },
      //需求关联开始日期编辑
      startTimeEdit() {
        let nowDate = this.formatDate(new Date(), "yyyyMMdd");
        let startTime = this.editRequireData.startTime.replace(/-/g, "");
        if (parseInt(nowDate.substring(0, 9)) > parseInt(startTime)) {
          this.$message({
            message: "开始日期不能小于当前日期",
            type: "warning"
          });
          return;
        }
        this.requirementUpdateInfo("startTime", this.editRequireData.startTime);
      },
      // 需求关联结束日期编辑
      endTimeEdit() {
        let startTime = this.editRequireData.startTime.replace(/-/g, "");
        let endTime = this.editRequireData.endTime.replace(/-/g, "");
        if (parseInt(startTime) > parseInt(endTime)) {
          this.$message({
            message: "结束日期不能小于开始日期",
            type: "warning"
          });
          return;
        }
        this.requirementUpdateInfo("endTime", this.editRequireData.endTime);
      },
      handelSaveChildRequire() {
        if (
          this.createRequireData.title.length <= 0 ||
          this.createRequireData.title.length > 64
        ) {
          this.$message({ message: "标题长度只能在1~64之间", type: "warning" });
          return;
        }
        this.createRequireData.parentId = this.requireId;
        this.createRequireData.projectId =
          this.urlParam.projectId || this.projectId;

        this.operaisdisable = true;
        $http
          .post($http.api.requirement.create, { 
            ...this.createRequireData,
            ...this.getCustomFieldsPresetValues(1)
          })
          .then(res => {
            if (res.status === 200) {
              this.operaisdisable = false;
              this.getDemandRelevance();
              this.tabRelateditem();
              this.$message({
                message: res.msg || "添加子需求成功",
                type: "success"
              });
              this.getRequirementInfo(); // 当前需求已经成为父需求，需要更新需求信息，看是否能够分解任务等
            } else {
              this.$message({
                message: res.msg || "添加子需求失败",
                type: "error"
              });
            }
          });
      },
      handelCancelCreateChildRequire() {
        this.childDemandData.pop();
      },
      changHandleTask(index) {
        if (this.radio3 == "2") {
          this.changeStatus = "1";
        } else if (this.radio3 == "3") {
          this.changeStatus = "2";
        }
      },
      changHandleTask1(index) {
        if (this.statusObject.activeName2 == "0") {
          // this.$refs.detaild.style.border = "none"
          // this.getCommentList();
        } else if (this.statusObject.activeName2 == "1") {
          this.getRevisedList();
        } else if (this.statusObject.activeName2 == "2") {
          this.getOperationLogDataList();
        } else if (this.statusObject.activeName2 == "3") {
        } else if (this.statusObject.activeName2 == "4") {
        } else if (this.statusObject.activeName2 == "5") {
          this.codeCommitUpdata = !this.codeCommitUpdata;
        }
      },
      onSubmitComment() {
        if(this.requireId === -1) { return ; }
        if (this.comment.trim() != "") {
          $http
            .post($http.api.comment.add, {
              workItemType: 1,
              workItemId: this.requireId,
              comment: this.comment.trim(),
              projectId: this.projectId
            })
            .then(res => {
              this.commentPageInfo.pageNum = 1;
              // this.getCommentList();
              this.comment = "";
              this.commentUpdata = !this.commentUpdata; // 更新评论列表
              this.tabRelateditem();
            });
        }
      },
      getRequirementInfo() {
        if(this.requireId === -1) { return ; }
        $http
          .get($http.api.requirement.seeDemand, { id: this.requireId })
          .then(res => {
            this.$nextTick(() => {
              this.requirement = res.data;
              this.requirement.display.end = res.data.display.detail.status.end;
              this.requirement.createUser = res.data.createUser;
              this.requirement.createTime = res.data.createTime;
              this.requirement.assignUser = res.data.assignUser;
              this.requirement.title = res.data.display.title;
              this.requirement.content = res.data.display.content;
              this.intermediateValue = res.data.display.content;
              this.disabledTask = res.data.display.authority.decomposeTask;
              this.requirement.display.priority = `<span class="statusbox-common" style="background-color: ${
                res.data.display.detail.priority.color
                // };font-size: ${
                // res.data.display.detail.priority.font.size
                // }px;font-weight: ${
                // res.data.display.detail.priority.font.bold ? "bold" : "normal"
                }">${res.data.display.priority}</span>`;
              this.requirement.statusId = res.data.statusId;
              this.requirement.display.status = `<span class="statusbox-common" style="background-color: ${
                res.data.display.detail.status.color
                }">${res.data.display.status}</span>`;
              this.handleStatusClick();
              this.nextStatusList.push({
                statusId: res.data.statusId,
                statusName: res.data.display.status
              });
              this.tinymceContentReset() // 在拿到内容之后再更新之前的，放置被后面获取到的内容给冲突了
              this.boxShowmore();
              this.tabRelateditem();
            });
          });
      },
      // getCommentList() {
      //   $http
      //     .get($http.api.comment.list, {
      //       workItemType: 1,
      //       workItemId: this.requireId,
      //       pageNum: this.commentPageInfo.pageNum,
      //       pageSize: this.commentPageInfo.pageSize
      //     })
      //     .then(res => {
      //       let commentList = res.data.list;
      //       this.commentDataList = commentList;
      //       this.commentPageInfo.total = res.data.total;
      //     });
      // },
      loadmoreOperationLogDataList() {
        this.operationLogPageInfo.pageNum = this.operationLogPageInfo.pageNum + 1;
        this.getOperationLogDataList();
      },
      getOperationLogDataList() {
        if(this.requireId === -1) { return ; }
        $http
          .get($http.api.operationLog.list, {
            workItemType: 1,
            workItemId: this.requireId,
            pageNum: this.operationLogPageInfo.pageNum,
            pageSize: this.operationLogPageInfo.pageSize,
            projectId: this.projectId
          })
          .then(res => {
            if (this.operationLogPageInfo.pageNum > 1) {
              this.operationLogDataList = [
                ...this.operationLogDataList,
                ...res.data.list
              ];
            } else {
              this.operationLogDataList = res.data.list;
            }
            this.operationLogPageInfo.pageSize = res.data.pageSize;
            this.operationLogPageInfo.pageNum = res.data.pageNum;
            this.operationLogPageInfo.isMore =
              res.data.total >
              this.operationLogPageInfo.pageNum *
              this.operationLogPageInfo.pageSize;
          });
      },
      getAttachmentList() {
        if(this.requireId === -1) { return ; }
        $http
          .post($http.api.attachment.query, {
            workItemType: 1,
            workItemId: this.requireId
          })
          .then(res => {
            this.fileDataList = res.data;
          });
      },
      deleteAttachment(info) {
        if(this.requireId === -1) { return ; }
        let id = info.id;
        $http
          .post($http.api.attachment.delete, {
            attachmentId: id,
            workItemType: 1,
            workItemId: this.requireId
          })
          .then(ret => {
            if (ret.status == 200) {
              let oldList = this.fileDataList;
              this.fileDataList = [];
              oldList.forEach(attach => {
                if (attach.id != id) {
                  this.fileDataList.push(attach);
                }
              });
              this.$message({
                type: "success",
                message: ret.msg || "删除成功!"
              });
            } else {
              this.$message({
                type: "error",
                message: ret.msg || "删除失败!"
              });
            }
          });
      },
      getRequireCategoryList() {
        $http
          .get($http.api.requirementCategory.list, {
            projectId: this.urlParam.projectId || this.projectId
          })
          .then(res => {
            this.requrieCategoryList = res.data.map(item => {
              return {
                value: item.label,
                key: item.id
              };
            });
          });
      },
      getSprintList() {
        $http
          .get($http.api.sprint.list_sprint_name, {
            projectId: this.urlParam.projectId || this.projectId,
            status: 1
          })
          .then(res => {
            if (res.status == 200) {
              this.sprintList = res.data.map(item => {
                return {
                  value: item.name,
                  key: item.id,
                  id: item.id
                };
              });
              this.sprintList.unshift({
                key: 0,
                value: "未规划"
              });
            }
          });
      },
      getNextStatusList(statusId) {
        if(this.requireId === -1) { return ; }
        $http
          .post($http.api.status.list_updatable, {
            workItemType: 1,
            workItemId: this.requireId,
            statusId: statusId
          })
          .then(res => {
            this.nextStatusList = [];

            this.nextStatusList = res.data.map(item => {
              return {
                value: item.statusName,
                key: item.statusId,
                ...item
              };
            });
          });
      },
      handleAssignerChange(value) {
        this.requirement.assignUser = value;
        this.prepareUpdateRequire(
          this.field.assignUser,
          this.requirement.assignUser
        );
        this.sendUpdateRequireRequest();
      },
      handleCategoryChange(value) {
        this.requirement.categoryId = value;
        this.prepareUpdateRequire(
          this.field.category,
          this.requirement.categoryId
        );
        this.sendUpdateRequireRequest();
      },
      handlePriorityChange(value) {
        this.requirement.priority = value;

        this.prepareUpdateRequire(this.field.priority, this.requirement.priority);
        this.sendUpdateRequireRequest();
      },
      handleSprintChange(value) {
        this.requirement.sprintId = value;
        this.prepareUpdateRequire(this.field.sprintId, this.requirement.sprintId);
        this.sendUpdateRequireRequest();
      },
      handleStartTimeChange() {
        this.timeVal.start = "";
        this.prepareUpdateRequire(
          this.field.startTime,
          this.requirement.startTime
        );
        this.sendUpdateRequireRequest();
      },
      handleEndTimeChange() {
        this.timeVal.end = "";
        this.prepareUpdateRequire(this.field.endTime, this.requirement.endTime);
        this.sendUpdateRequireRequest();
      },
      handleStatusChange(value) {
        this.requirement.statusId = value;
        this.prepareUpdateRequire(this.field.statusId, this.requirement.statusId);
        this.sendUpdateRequireRequest();

        this.nextStatusList.forEach(status => {
          if (this.requirement.statusId == status.statusId) {
            this.requirement.display.status = status.statusName;
          }
        });
      },
      handleStatusClick() {
        this.statusValue = this.requirement.statusId;
        this.getNextStatusList(this.requirement.statusId);
      },
      prepareUpdateRequire(field, value) {
        this.requireUpdateInfo = {};
        this.requireUpdateInfo.id = this.requireId;

        if (field == this.field.content) {
          this.requireUpdateInfo.content = value;
        } else if (field == this.field.title) {
          this.requireUpdateInfo.title = value;
        } else if (field == this.field.expectedTime) {
          this.requireUpdateInfo.expectedTime = value;
        } else if (field == this.field.statusId) {
          this.requireUpdateInfo.statusId = value;
        } else if (field == this.field.startTime) {
          this.requireUpdateInfo.startTime = value;
        } else if (field == this.field.priority) {
          this.requireUpdateInfo.priority = value;
        } else if (field == this.field.sprintId) {
          this.requireUpdateInfo.sprintId = value;
        } else if (field == this.field.endTime) {
          this.requireUpdateInfo.endTime = value;
        } else if (field == this.field.assignUser) {
          this.requireUpdateInfo.assignUser = value;
        } else if (field == this.field.category) {
          this.requireUpdateInfo.categoryId = value;
        }
      },
      sendUpdateRequireRequest(obj) {
        if(this.requireId === -1) { return ; }
        $http.post($http.api.requirement.update, {
          id: this.requireId,
          ...this.requireUpdateInfo,
          ...obj
        }).then(res => {
          this.getRequirementInfo();
          this.getOperationLogDataList();
          if (res.status === 200) {
            this.$emit('updateInfoSuccess');
            this.$message({ message: "修改需求成功", type: "success" });
          } else {
            this.$message({ message: res.msg, type: "error" });
          }
        }).catch(e => {
          this.requirement.sprintId = this.editBackupValue;
          this.requirement.statusId = this.statusValue;
          this.getRequirementInfo();
          this.$message({ message: "修改需求失败", type: "error" });
        });
      },
      // 关联工作项 - 点击添加关联
      handleAssociateRequire() {
        this.assocRequireDialogVisible = true;
        this.searchAssocRequrie();
        this.getProjectList();
      },
      // 关联工作项 - 点击查询
      searchAssocRequrie() {
        if (
          (!this.assocRequireSearchInfo.projectId ||
            this.assocRequireSearchInfo.projectId == 0) &&
          !this.assocRequireSearchInfo.title
        ) {
          this.$message({ message: "项目和标题不能同时为空", type: "warning" });
          return;
        }
        this.assocRequirePageInfo.pageNumber = 1;
        this.assocRequirePageInfo.pageSize = 10;
        this.getSearchAssocRequireList();
      },
      // 关联工作项 - 获取项目列表
      getProjectList() {
        $http.get($http.api.project.projectList).then(res => {
          this.projectNameList = res.data;
        });
      },
      getSearchAssocRequireList() {
        this.assocRequireSearchInfo.pageInfo = {
          pageNumber: this.assocRequirePageInfo.pageNumber,
          pageSize: this.assocRequirePageInfo.pageSize
        };
        $http
          .post(
            $http.api.requirement.list_assoc_require,
            this.assocRequireSearchInfo
          )
          .then(res => {
            this.assocRequireDataList = res.data.result;
            this.assocRequirePageInfo = res.data.pageInfo;
          });
      },
      handleAssocRequirePageSizeChange(pageSize) {
        this.assocRequirePageInfo.pageSize = pageSize;
        this.getSearchAssocRequireList();
      },
      handleAssocRequirePageNumChange(pageNum) {
        this.assocRequirePageInfo.pageNumber = pageNum;
        this.getSearchAssocRequireList();
      },
      handleRevisedPageSizeChange(pageSize) {
        this.revisedPageInfo.pageSize = pageSize;
        this.getRevisedList();
      },
      handleRevisedPageNumChange(pageNum) {
        this.revisedPageInfo.pageNumber = pageNum;
        this.getRevisedList();
      },
      // handleCommentPageSizeChange(pageSize) {
      //   this.commentPageInfo.pageSize = pageSize;
      //   this.getCommentList();
      // },
      // handleCommentPageNumChange(pageNum) {
      //   this.commentPageInfo.pageNum = pageNum;
      //   this.getCommentList();
      // },
      handleSureAssocRequrie() {
        if(this.requireId === -1) { return ; }
        let assocRequrieIds = [];
        this.$refs["assocRequireTableRef"].selection.forEach(item => {
          assocRequrieIds.push(item.id);
        });

        let requestParam = {
          origWorkItemType: 1,
          targetWorkItemIds: assocRequrieIds,
          targetWorkItemType: 1,
          origWorkItemId: this.requireId
        };
        $http
          .post($http.api.requirement.assoc_require, requestParam)
          .then(res => {
            this.getDemandRelevance();
            this.assocRequireDialogVisible = false;
          });
      },
      toRequrieDetailPage(row) {
        if(this.requireId === -1) { return ; }
        let param = { requireId: row.id, projectId: row.projectId };
        // this.goToPage(this, "requirementView", param);
        this.goToNewWindowPage(this, "requirementList", param);
        // window.location.reload();
        //this.boxShowmore();
      }
    }
  };
</script>
<style lang="scss" scoped>
  @import "../ProjectCommon.scss";
  .hover-basic-info-item-static{
    display: inline-block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: calc(100% - 59px);
    padding-left: 10px;
  }
  .edit-fullscreen {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    overflow: auto;
    background-color: white;
    z-index: 99999;
  }

  .demandheader {
    width: calc(100% - 350px);
    margin-bottom: 10px;

    .demandre {
      color: #409eff;
      cursor: pointer;
      float: right;
      display: inline-block;
    }

    .demandtitle {
      margin: 10px;
      font-size: 14px;
      font-weight: 700;
      color: #333;
    }
  }

  .showMore {
    height: 349px;
    overflow: hidden;
    /* box-shadow: 0 0 1px #565454; */
    border-radius: 5px;
    padding: 0 1px;
  }

  .moreText {
    text-align: center;
    color: #409eff;
    cursor: pointer;
    //position: absolute;
    width: 100%;
    /* background: gainsboro; */
    /* top: 400px; */
    /* bottom: 15px; */
    //height: 50px;
    /* opacity: 3.5; */
    //line-height: 53px;
    font-weight: bold;
  }

  .requirement-assiguser {
    width: 20px;
    display: inline-block;
  }

  .requirement-status {
    position: absolute;
    right: 70px;
    //max-width: 100px;
    display: inline-block;
  }

  .textTaskbox {
    position: absolute;
    width: calc(100% - 12px);
    background: rgba(218, 210, 210, 0.5);
    top: 376px;
    left: 6px;
    height: 50px;
  }

  .title-input {
    display: inline-block;
    width: calc(100% - 200px);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-size: 24px;
    height: 38px;
    line-height: 38px;

    &:hover {
      box-shadow: 0 0 0 1px #ccc;
    }
  }

  .title-input-true {
    line-height: 40px;
    height: 40px;
    display: inline-block;
    width: calc(100% - 200px);
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    font-size: 24px;
    outline: none;
  }

  .side-left {
    width: 67%;
    float: left;
  }

  .title {
    width: 100%;
  }

  .info-title {}

  .edit-position-box {
    width: 100%;
    position: relative;
    overflow: hidden;

    .edit-detail-btn {
      position: absolute;
      padding: 2px 4px;
      right: 12px;
      top: 17px;
      border: 1px solid #dde5ef;
      cursor: pointer;
      -webkit-box-sizing: border-box;
      box-sizing: border-box;

      &:hover {
        background-color: #ebf2f9;
      }
    }

    .edit-cancle-and-sure-btn {
      position: absolute;
      right: 12px;
      top: 32px;

      .edit-cancle-btn,
      .edit-sure-btn {
        padding: 2px 4px;
        border: 1px solid #dde5ef;
        cursor: pointer;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
      }
    }
  }

  .demand-title {
    background-color: #eef0f6;
    height: 36px;
    line-height: 36px;
    white-space: nowrap;
  }

  .child-demand {
    margin-top: 3px;
  }

  .same-box-heander {
    height: 36px;
    /*line-height: 35px;*/
    font-size: 13px;
    color: #909399;
    float: left;
    font-weight: 900;
  }

  .same-box-heander1 {
    height: 36px;
    line-height: 35px;
    font-size: 13px;
    color: #909399;
    float: left;
    text-indent: 1em;
    font-weight: 900;
  }

  .same-box {
    text-align: left;
    font-size: 13px;
    color: #333;
    float: left;
    margin-top: 5px;
    margin-bottom: 5px;
  }

  .demand-box {
    margin-top: 20px;
    margin-left: 20px;
    height: 44px;
    line-height: 44px;
  }

  .border {
    padding-bottom: 6px;
  }

  .detailed-information,
  .demand-connect,
  .task-decompose {
    /* border-bottom: 1px solid #ccc;
      border-top: 1px solid #ccc; */
    padding-bottom: 20px;
    width: 100%;

    .task-decompose-title {
      // height: 40px;
      //line-height: 40px;
      padding-bottom: 5px;
    }
  }

  .detailed-information1 {
    width: 100%;
    min-height: 300px;
  }

  .el-icon-download,
  .el-icon-close {
    cursor: pointer;
  }

  .el-icon-download {
    margin-left: 20%;
  }

  .commentData {
    margin-top: 20px;

    .person {
      margin-left: 20px;
    }

    .content {
      margin-top: 10px;
      margin-left: 20px;
      color: black;
    }
  }

  .list {
    margin-top: 5px;
    cursor: pointer;
  }

  .edit-box {
    width: 99%;
    min-height: 421px;
    margin: 10px 10px 10px 40px;
    font-size: 13px;
    border-radius: 5px;
    -webkit-box-shadow: 0 0 3px #eee;
    box-shadow: 0 0 3px #eee;
    padding: 10px;
    box-sizing: border-box;

    .edit-box-requirement {
      padding-top: 10px;
    }
  }

  .time1 {
    text-indent: 1em;
  }

  .icon {
    margin-right: 10%;
  }

  .head-portrait {
    width: 41px;
    height: 46px;
    border: 1px solid #ccc;
  }

  textarea[disabled] {
    background-color: #fff !important;
    border: none;
  }

  .commentData1 {
    line-height: 30px;
  }

  .flleName {
    padding-top: 15px;
    padding-bottom: 8px;
    font-size: 14px;
    color: #333;
    overflow: hidden;
  }

  .father-demand,
  .child-demand,
  .association-demand {
    border-bottom: 1px solid #eef0f6;
  }

  .el-form-item {
    margin-bottom: 5px;
  }

  .bold-font {
    font-weight: 900;
  }

  .comment-paging {
    margin-right: 125px;
  }

  .w99 {
    width: 99%;
    margin: 0 auto;
  }
</style>