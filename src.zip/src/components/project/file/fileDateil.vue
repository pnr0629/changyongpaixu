<template>
  <div id="demandlist">
    <el-tabs v-model="activeName2" type="card" @tab-click="handleClick" :before-leave="tabSwcith">
      <el-tab-pane label="预览"  name="view">
        <div class="file-box" v-if="activeName2=='view'">
          <!-- 基本信息 -->
          <div>
            <p class="file-right-box-title-font ">&nbsp;基本信息</p>
            <ul>
              <li class="file-box-margin" style="padding-top: 0;">
                <span class="file-font-width">接口名称：</span>
                <span>{{interfaceList.apiName}}</span>
                <div class="fr" >
                  <span class="file-font-width">创建人：</span>
                  <span style="display:inline-block;width:135px">{{interfaceList.createUser}}</span>
                  <!-- <span style="display:inline-block;width:68px"></span> -->
                </div>
              </li>
              <li>
                <span class="file-font-width">状<span style="visibility: hidden;">状态</span>态：</span>
                <span><span style="background:yellow;" class="file-status" 
                :style="{background:interfaceList.apiStatus?'#57cf27':'red'}"></span>
                {{interfaceList.apiStatus?'已完成':'未完成'}}</span>
                <div class="fr">
                  <span class="file-font-width">更新时间：</span>
                  <span style="display:inline-block;width:135px">{{interfaceList.updateTime}}</span>
                </div>
                </li>
              <!-- <li><span class="file-font-width">Tag：</span><span>{{interfaceList.tag}}</span></li> -->
              <li>
                <span class="file-font-width">接口路径：</span>
                <span class="file-font-style" 
                :class="{'file-font-style-blue':['GET','HEAD'].indexOf(interfaceList.apiMethod)==-1,
                'file-font-style-green':['GET','HEAD'].indexOf(interfaceList.apiMethod) !==-1}">
                {{interfaceList.apiMethod}}</span>
                <span>{{interfaceList.apiPath}}</span>
                <i class="el-icon-news cursor-pointer file-api-copy" @click="copyApiPathFun" title="复制路径"></i>
                <div class="file-copy-box">
                  <div class="file-copy-mask"></div>
                  <input type="text" :value="interfaceList.apiPath" id="apiPathValue"/>
                </div>
                
              </li>
              <li><span class="file-font-width" style="margin-left: 10px;"> Mock地址：</span>
              <a :href="interfaceList.mockUrl" target="_blank">{{interfaceList.mockUrl}}</a></li>
            </ul>
          </div>
          <div class=" " v-show="interfaceList.apiDesc!==null&&interfaceList.apiDesc!==''">
            <p class="file-right-box-title-font ">&nbsp;备注</p>
            <div v-html="interfaceList.apiDesc"></div>
          </div>
          <!-- 请求参数  -->
          <div v-show="reqParamsShow.allShow">
            <p class="file-right-box-title-font ">&nbsp;请求参数</p>
            <div v-show="reqParamsShow.reqHeaderShow" class="mBr">
              <div class="mTB20 file-small-title">Headers：</div>
              <el-table :data="headerList" ref="headerList" style="width: 80%;height: 100%;" border>
                <el-table-column prop="name" label="参数名称" ></el-table-column>
                <el-table-column prop="value" label="参数值"></el-table-column>
                <!-- <el-table-column prop="required" label="是否必须" ></el-table-column> -->
                <!-- <el-table-column prop="example" label="示例" ></el-table-column> -->
                <el-table-column prop="headerDesc" label="备注"></el-table-column>
              </el-table>
            </div>
            <div v-show="reqParamsShow.reqQueryShow" class="mBr">
              <div class="mTB20 file-small-title">Query：</div>
              <el-table :data="queryRequireList" ref="queryRequireList" style="width: 80%;height: 100%;" border>
                <el-table-column prop="name" label="参数名称" ></el-table-column>
                <el-table-column prop="required" label="是否必须" >
                  <template slot-scope="scope">
                    <span >
                      {{scope.row.required?'必需':'非必需' }}
                    </span>
                  </template>
                </el-table-column>
                <el-table-column prop="example" label="示例" ></el-table-column>
                <el-table-column prop="queryDesc" label="备注"></el-table-column>
              </el-table>
            </div>
            <div v-show="reqParamsShow.reqBodyShow" class="mBr">
              <div class="mTB20 file-small-title">Body:</div>
              <!-- json -->
              <tree-table :data="reqBodyData" style="width: 80%;height: 100%;" v-show="interfaceList.reqBodyType=='json'">
                <el-table-column prop="type" label="类型" ></el-table-column>
                <el-table-column prop="required" label="是否必须" >
                  <template slot-scope="scope">
                    <span >
                      {{scope.row.required?'必需':'非必需' }}
                    </span>
                  </template>
                </el-table-column>
                <!-- <el-table-column prop="example" label="默认值" ></el-table-column> -->
                <el-table-column prop="description" label="备注"></el-table-column>
              </tree-table>
              <!-- from -->
              <el-table :data="fromList" ref="fromList" style="width: 80%;height: 100%;" border v-show="interfaceList.reqBodyType=='form'">
                <el-table-column prop="name" label="参数名称" ></el-table-column>
                <el-table-column prop="type" label="参数类型"></el-table-column>
                <el-table-column prop="required" label="是否必须" >
                  <template slot-scope="scope">
                    <span >
                      {{scope.row.required?'必需':'非必需' }}
                    </span>
                  </template>
                </el-table-column>
                <el-table-column prop="example" label="示例" ></el-table-column>
                <el-table-column prop="formDesc" label="备注"></el-table-column>
              </el-table>
            </div>
          </div>  
          <!-- 返回数据 -->
          <div class=" ">
            <p class="file-right-box-title-font">&nbsp;返回数据</p>
            <div class="mBr">
              <tree-table :data="resBodyData" style="width: 80%;height: 100%;">
                <el-table-column prop="type" label="类型" ></el-table-column>
                <el-table-column prop="required" label="是否必须" >
                  <template slot-scope="scope">
                    <span >
                      {{scope.row.required?'必需':'非必需'}}
                    </span>
                  </template>
                </el-table-column>
                <el-table-column prop="description" label="备注"></el-table-column>
              </tree-table>
            </div>
          </div>
          <!-- 状态码 -->
          <div class=" " v-if="statusCodeList.length!==0">
            <p class="file-right-box-title-font">&nbsp;状态码</p>
            <el-table :data="statusCodeList" ref="statusCodeList" style="width: 80%;height: 100%;" border>
              <el-table-column prop="code" label="状态码" ></el-table-column>
              <el-table-column prop="codeExplain" label="状态码说明"></el-table-column>
            </el-table>
          </div>
          <div style="height: 200px"></div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="编辑" name="edit" v-if="authFunction('FUNC_APIDOC_SAVE_INFO', 3, getUrlParams().projectId)">
        <file-edit :setId="this.setId" v-if="activeName2=='edit'" @sortFun="sortChildFun"></file-edit>
      </el-tab-pane>
      <el-tab-pane label="运行" name="run" v-if="authFunction('FUNC_APIDOC_SAVE_RUN_DATA', 3, getUrlParams().projectId)">
        <file-run :setId="this.setId" v-if="activeName2=='run'"></file-run>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>

import TreeTable from "@/components/tool/fileTreeTable";
import fileEdit from "./fileEdit.vue";
import fileRun from "./fileRun.vue";
import {mapState,mapMutations,mapActions} from "vuex";
export default {
  name: "fileDateil",
  // mixins: [ProjectCommonMixin],
  data() {
    return {
      activeName2: 'view',
      // remarkContent:'备注备注.....',
      interfaceList:{
        apiName:'',
        apiMethod:'',
        createUser:'',
        apiPath:'',
        updateTime:'',
        apiStatus:'',
        mockUrl:'',
        apiDesc:'',
        reqBodyType:''
      },
      // InitData:{},
      queryRequireList:[],
      headerList:[],
      fromList:[],
      statusCodeList:[],
      jsonTreeData:[],
      responseData:[],
      resBodyData:[],
      reqBodyData:[],
      reqParamsShow:{
        reqQueryShow:false,
        reqHeaderShow:false,
        reqBodyShow:false,
        allShow:false
      }
    };
  },
  props: {
    setId: {
      type: [Number, String],
      default: null
    }
  },
  watch: {
    apiId: function (newVal, oldVal){
      this.init();
    }
  },
  computed:{
    ...mapState({
      // detailShow:state=>state.fe.detailShow,
      detailInitData:state=>state.fe.detailInitData,
      apiId:state=>state.fe.apiId,
      apiTypeId:state=>state.fe.apiTypeId,
      watchData:state=>state.fe.watchData,
      watchDataObj1:state=>state.fe.watchDataObj1,
      editShow:state=>state.fe.editShow
    }),
  },
  mounted() {
    if (this.getUrlParams().apiId!==-1&&this.getUrlParams().apiId){
      this.init();
    }
    
  },
  components: {
    TreeTable,fileEdit,fileRun
  }, 
  methods: {
    ...mapMutations(['detailInitDataFun','watchDataFun','editShowFun']),
    //复制路径
    copyApiPathFun(){
      let target = document.getElementById('apiPathValue');
    // 选择内容
      target.focus();
      target.setSelectionRange(0, target.value.length);
      // 复制内容
      let succeed="";
      try {
        succeed = document.execCommand("copy");
      } catch (e) {
        succeed = false;
      }
      return succeed;
    },
    //监听名称和分类change是否触发
    sortChildFun(item){
      this.$emit('sortFun',true)
    },
    //检查请求方式
    checkReqMethod(){
      var reqMethod=this.interfaceList.apiMethod;
      if ((reqMethod=='GET')||(reqMethod='HEAD')||(reqMethod=='OPTIONS')){
        return false;
      }
      return true;
    },

    //初始化数据
    init(str){
      this.editShowFun(false);
      let apiId1 = this.apiId||this.getUrlParams().apiId;
      $http.get($http.api.apidoc.get_api_info,{apiId:apiId1}).then(res =>{
        if(res.data){
          this.detailInitDataFun(res.data);
          this.watchDataFun(JSON.parse(JSON.stringify(res.data)));
          let data = res.data;
          str?this.activeName2='run':this.activeName2='view';
          this.interfaceList = {
            apiName:data.apiName,
            apiPath:data.apiPath,
            apiMethod:data.apiMethod,
            apiTypeId:data.apiTypeId,
            apiStatus:data.apiStatus,
            mockUrl:data.mockUrl,
            createUser:data.createUser,
            updateTime:data.updateTime,
            apiDesc:data.apiDesc,
            reqBodyType:data.reqBodyType
          }
          this.queryRequireList = data.reqQueryBoList;
          this.headerList = data.reqHeadersBoList;
          this.fromList = data.reqBodyFormBoList;
          this.statusCodeList = data.statusCodeBoList;
          if(data.reqBodyJson){
            this.jsonTreeData.push(data.reqBodyJson);
          }else {
            this.jsonTreeData=[];
          }
          if (data.resBody) {
            this.responseData=data.resBody.properties;
          }else {
            this.responseData=[];
          }

          this.resBodyData=[];
          if (data.resBody) {
            let resBodyDataAll=JSON.parse(JSON.stringify(data.resBody));
            if (resBodyDataAll.type=='array'){
              let resBodyDataLet={};
              resBodyDataLet.fieldName='';
              resBodyDataLet.description=resBodyDataAll.description;
              resBodyDataLet.mock=resBodyDataAll.mock;
              resBodyDataLet.required=resBodyDataAll.required;
              resBodyDataLet.type=resBodyDataAll.properties[0].type+' [ ]';
              resBodyDataLet.properties=this.changArray(resBodyDataAll.properties[0].properties)
              this.resBodyData.push(resBodyDataLet);
            } else if (resBodyDataAll.type=='object') {
              this.resBodyData=this.changArray(resBodyDataAll.properties)
            }else {
              let resBodyDataLet={};
              resBodyDataLet.fieldName='';
              resBodyDataLet.description=resBodyDataAll.description;
              resBodyDataLet.mock=resBodyDataAll.mock;
              resBodyDataLet.required=resBodyDataAll.required?1:0;
              resBodyDataLet.type=resBodyDataAll.type;
              resBodyDataLet.properties=resBodyDataAll.properties;
              this.resBodyData.push(resBodyDataLet)
            }
          }

          this.reqBodyData=[];
          if (data.reqBodyJson) {
            let reqBodyDataAll=JSON.parse(JSON.stringify(data.reqBodyJson));
            if (reqBodyDataAll.type=='array'){
              let reqBodyDataLet={};
              reqBodyDataLet.fieldName='';
              reqBodyDataLet.description=reqBodyDataAll.description;
              reqBodyDataLet.mock=reqBodyDataAll.mock;
              reqBodyDataLet.required=reqBodyDataAll.required;
              reqBodyDataLet.type=reqBodyDataAll.properties[0].type+' [ ]';
              reqBodyDataLet.properties=this.changArray(reqBodyDataAll.properties[0].properties)
              this.reqBodyData.push(reqBodyDataLet);
            } else if (reqBodyDataAll.type=='object') {
              this.reqBodyData=this.changArray(reqBodyDataAll.properties)
            }else {
              let reqBodyDataLet={};
              reqBodyDataLet.fieldName='';
              reqBodyDataLet.description=reqBodyDataAll.description;
              reqBodyDataLet.mock=reqBodyDataAll.mock;
              reqBodyDataLet.required=reqBodyDataAll.required?1:0;
              reqBodyDataLet.type=reqBodyDataAll.type;
              reqBodyDataLet.properties=reqBodyDataAll.properties;
              this.reqBodyData.push(reqBodyDataLet)
            }
          }

          this.reParamShow();
          // apiName       
        }
      }).catch(e =>{

      })
    },



    changArray(properties){
      let newProperties=[];
      for (let item in properties){
        if (properties[item].type=='array'){
          let childrenProperties=properties[item].properties;
          properties[item].type=childrenProperties[0].type+' [ ]';
          if (childrenProperties[0].properties){
            properties[item].properties=this.changArray(childrenProperties[0].properties)
          }else {
            properties[item].properties=[];
          }
          newProperties.push(properties[item]);
        }else if (properties[item].type=='object'){
          properties[item].properties=this.changArray(properties[item].properties);
          newProperties.push(properties[item]);
        } else {
          newProperties.push(properties[item])
        }
      }
      return newProperties;
    },



    
    reParamShow(){
      this.reqParamsShow.reqBodyShow=false;
      this.reqParamsShow.reqQueryShow=false;
      this.reqParamsShow.reqHeaderShow=false;
      this.reqParamsShow.allShow=false;
  
      if (['GET','HEAD','OPTIONS'].indexOf(this.interfaceList.apiMethod) ==-1) {
        if (this.interfaceList.reqBodyType=='form') {
          if (this.fromList.length!==0){
            this.reqParamsShow.reqBodyShow=true;
          }
        }
        if (this.interfaceList.reqBodyType=='json') {
          if (this.jsonTreeData.length!==0){
            this.reqParamsShow.reqBodyShow=true;
          }
        }
      }
      if (this.queryRequireList.length!==0) {
        this.reqParamsShow.reqQueryShow=true;
      }
      if (this.headerList.length!==0) {
        this.reqParamsShow.reqHeaderShow=true;
      }
      if (this.reqParamsShow.reqBodyShow||this.reqParamsShow.reqQueryShow||this.reqParamsShow.reqHeaderShow) {
        this.reqParamsShow.allShow=true;
      }
    },
    
    //切换tab
    handleClick(tab, event) {
      // console.log(tab)
      // console.log(event)
      // console.log(this.activeName2)
      if(this.editShow){
        this.$confirm(`离开页面会丢失当前编辑的内容，确定要离开吗？`, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then( () => {
          this.editShowFun(false);
          this.activeName2=tab.name;
        }).catch(()=> {});
      } 
      
      if(this.activeName2=='view'){
        this.init();
      }
      if(this.activeName2=='run'){
        this.init('run');
      }
    },
    //切换标签之前的钩子
    tabSwcith(activeName, oldActiveName){
      return !this.editShow
      
    }
  }
};
</script>

<style lang="scss" scoped>
ul{
  list-style: none;
  // margin: 0;
  padding: 0;
  width: 62%;
  // width: calc(100% - 250px);
  li{
    padding: 10px;
    position: relative;
    min-width: 500px;
  }
}
.file-right{
  display: inline-block;
  // position: absolute;
  // right: 0;

}
.file-status{
    display: inline-block;
    padding: 4px;
    margin: 0 5px;
    border-radius: 10px;
}
.file-api-copy{
    margin-left: 20px;
    &:hover{
      color: #409eff;
    }
}
.file-copy-box{
    width: 20px;
    display: inline-block;
    position: relative;
  .file-copy-mask{
    width: 20px;
    height: 20px;
    background: #fff;
    position: absolute;
    top: 0;
  }
  #apiPathValue{
    width: 20px;
    color: #fff;border:none;
    &:focus{
      outline: 1px solid #fff;
    }
  }
}
</style>
