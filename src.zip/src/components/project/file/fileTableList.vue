<template>
  <div id="demandlist" class="file-table-style" ref="doctableList">
    <el-table :data="list" ref="assocRequireTableRef" style="width: 100%;height: 100%;">
      <el-table-column prop="title" label="接口名称" >
        <template slot-scope="scope">
          <span class="cp c-blue-hover" @click="interfaceUrlClick(scope.row)">
            {{scope.row.apiName }}
          </span>
        </template>
      </el-table-column>
      <el-table-column prop="url" label="接口路径">
        <template slot-scope="scope">
          <span class="file-font-style" 
          :class="{'file-font-style-blue':['GET','HEAD'].indexOf(scope.row.apiMethod)==-1,
          'file-font-style-green':['GET','HEAD'].indexOf(scope.row.apiMethod) !==-1}"
          >
            {{scope.row.apiMethod }}
          </span>
          <span>
            {{scope.row.apiPath }}
          </span>
        </template>
      </el-table-column>
      <el-table-column prop="count" label="接口分类" width="280">
        <template slot-scope="scope">
          <el-select  style="width:90%;" :disabled="!authFunction('FUNC_APIDOC_UPDATE_API_TYPE', 3, getUrlParams().projectId)"
          v-model="scope.row.apiTypeId" @change="sortChangeEvent(scope.row)">
              <el-option v-for="(item,index) in sortListData" :key="index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column prop="count" label="状态" width="180" >
        <template slot-scope="scope">
          <el-select style="width:25%;min-width: 80px;" :disabled="!authFunction('FUNC_APIDOC_UPDATE_API_STATUS', 3, getUrlParams().projectId)"
           v-model="scope.row.apiStatus" @change="statusChangeEvent(scope.row)">
              <el-option v-for="(item,index) in statusList" :key="index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination class="fr mr10" style="margin-top:4px;"
        @current-change="handleCurrentChange"
        :pager-count="5"
        :page-size="pageData.pageSize"
        :current-page="pageData.pageCurrent"
        layout="total, prev, pager, next" :total="pageData.total">
    </el-pagination>
     <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
  </div>
</template>
<script>
import {mapState,mapMutations} from "vuex";
import ProjectCommonMixin from "@/components/project/ProjectCommonMixin";
import GlobalSelect from "@/components/tool/FieldEdit/GlobalSelect.vue";
import merge from 'webpack-merge';
export default {
  name: "fileTableList",
  mixins: [ProjectCommonMixin],
  data() {
    return {
      list:[],
      listData:{
        pageNum:1,
        pageSize:15,
      },
      pageData:{
        pageNum:1,
        pageSize:15,
        pageCurrent:1,
      },
      diagloshow:false,
      editdiagloshow:false,
      fileName:''
    };
  },
  computed:{
    ...mapState({
      defaultExpandedKeys:state=>state.fe.defaultExpandedKeys,
      detailShow:state=>state.fe.detailShow,
      interfaceUrlList:state=>state.fe.interfaceUrlList,
      apiId:state=>state.fe.apiId,
      apiTypeId:state=>state.fe.apiTypeId,
      statusList:state=>state.fe.statusList,
      sortListData:state=>state.fe.sortListData,
      exId:state=>state.fe.exId,
    }),
  },
  props: {
    setId: {
      type: [Number, String],
      default: null
    }
  },
  watch: {
    setId: function (newVal, oldVal){
      this.init();
      this.$router.push({
        query:merge(this.$route.query,{'apiId':-1,'apiTypeId':this.setId})
      })
      
    },
    apiTypeId: function (newVal, oldVal){
      this.init(); 
    },
    exId: function (newVal, oldVal){
      this.init(); 
    }
  },
  mounted() { 
    this.init();
  },
  components: {
    GlobalSelect,
  }, 
  methods: {
    ...mapMutations(['defaultExpandedKeysFun','filePageSwitch','sortTotalFun','fileApiId','fileApiTypeId','exIdFun']),
    //初始化
    init(){
      let apiTypeId = this.setId;
      if (apiTypeId==0||!apiTypeId||apiTypeId=='-1'){
        this.getAllSortList();
      } else if (apiTypeId!=-1&&apiTypeId!='-1') {
        this.getSortList()
      }
      if(!this.exId){
        this.getAllSortList();
        this.exIdFun(true)
      }
    },
    //添加分类
    // confirmBtn(){

    // },
    // 获取分类列表
    getSortList(){
      this.listData.apiTypeId = this.setId||this.getUrlParams().apiTypeId;
      $http.get($http.api.apidoc.get_api_list,{...this.listData}).then(res =>{
        if(res.data){
          this.list = res.data.list;
          this.pageData = {
            pageNum: res.data.pageNum,
            pageSize: res.data.pageSize,
            total:res.data.total,
            pageCurrent:res.data.pageNum,
          }
          this.sortTotalFun(res.data.total)
        }
      }).catch(e =>{

      })
    },
    //选择分类change
    sortChangeEvent(item){
      $http.post($http.api.apidoc.update_api_type,{apiId:item.apiId,apiTypeId:item.apiTypeId},{type:'form'}).then(res =>{
        if(res.status==200){
          this.$emit('sortFun',true)
          this.$message({
            message: '修改接口分类成功',
            type: 'success'
          });
          this.init();
        }
      }).catch(e =>{

      })
    },
    //updata选择状态
    statusChangeEvent(item){
      $http.post($http.api.apidoc.update_api_status,{apiId:item.apiId,apiStatus:item.apiStatus},{type:'form'}).then(res =>{
        if(res.status==200){
          this.$message({
            message: '修改状态成功',
            type: 'success'
          });
        }
      }).catch(e =>{

      })
    },
    // 获取全部分类列表
    getAllSortList(){
      this.listData.apiClassId = this.getUrlParams().apiClassId
      // if(!this.apiTypeId){return false}
      $http.get($http.api.apidoc.get_all_api,{... this.listData}).then(res =>{
        if(res.data){
          this.list = res.data.list;
          this.pageData = {
            pageNum: res.data.pageNum,
            pageSize: res.data.pageSize,
            total:res.data.total,
            pageCurrent:res.data.pageNum,
          }
          this.sortTotalFun(res.data.total)
        }
      }).catch(e =>{

      })
    },
    // 分页参数改变
    handleCurrentChange(val){
      this.listData.pageNum = val
      let apiTypeId = this.setId;
      if (apiTypeId==0||!apiTypeId){
        this.getAllSortList();
      } else if (apiTypeId!=-1&&apiTypeId!='-1') {
        this.getSortList()
      }
      // (this.setId&&this.setId!=-1&&this.setId!='-1')?this.getSortList():this.getAllSortList();
    },
    //修改分类&状态
    // getprojectTable(){

    // },
    //接口详情跳转
    interfaceUrlClick(item){
      this.$router.push({
        query:merge(this.$route.query,{'apiTypeId':-1,'apiId':item.apiId})
      })
      this.filePageSwitch(false);
      let defaultExpandedKeys=[];
      defaultExpandedKeys.push(item.apiId)
      this.defaultExpandedKeysFun(defaultExpandedKeys)
      // console.log(this.defaultExpandedKeys)
      this.fileApiId(item.apiId)
      this.fileApiTypeId(-1);
    }
  }
};
</script>

<style lang="scss" scoped>
.file-box{
  position: relative;
  .file-left-box{
    // position: absolute;
    width: 20%;
    min-width: 230px;
    height: 100%;
    min-height: 703px;
    border: 1px solid gainsboro;
    .file-left-btn-box{
      
      .file-left-btn{
        display: inline-block;
        width: 50%;
        height: 50px;
        text-align: center;
        line-height: 50px;
        // border-bottom: 1px solid gainsboro;
      }
      .left-btn-grey{
        background: gainsboro;
      }
    }
    
  }
  .file-right-box{
    width: 78%;
    height: 100%;
    min-height: 703px;
    border: 1px solid gainsboro;
    
  }
}

</style>
