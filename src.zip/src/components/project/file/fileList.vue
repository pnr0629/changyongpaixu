<template>
  <div  class="content-outer-box">
    <div >
        <!-- <el-radio-group v-model="isCollapse" style="margin-bottom: 20px;" @change="handleRadioChange">
          <el-radio-button label="接口">接口</el-radio-button>
          <el-radio-button label="设置">设置</el-radio-button>
        </el-radio-group> -->
        <!-- <span>文档名：</span> -->
      </div>
      <span @click="backBtn" class="file-back"><i class="el-icon-arrow-left"></i><i class="el-icon-arrow-left"></i>返回</span>
      <div class="file-header-title">{{apiClassName}}</div>
      <file-setting v-if="isCollapse == '设置'" @setValue="setValue"></file-setting>
    <div class="file-box" v-if="isCollapse == '接口'">
      <div class="file-left-box fl">
        <div class="file-left-btn-box left-btn-grey">
          <span class="file-left-btn " @click="handleRadioChange('接口')" :class="{'left-btn-grey':bthGrayShow}">接口列表</span>
          <span class="file-left-btn " @click="handleRadioChange('设置')" :class="{'left-btn-grey':!bthGrayShow}" style="background:#fff;">设置</span>
        </div>
        <div class="api-search" v-if="bthGrayShow">
          
          <el-input v-model="filterText" placeholder="搜索接口" class="mt10 ml10 fl" style="width:60%;"></el-input>
          <el-button type="primary" @click="addsortBtn" class="add-type-button ml5 mt10 fl " v-show="authFunction('FUNC_APIDOC_ADD_TYPE', 3, getUrlParams().projectId)">添加分类</el-button>
        </div>
        <div style="padding: 10px;background: #f3f4f6;" v-if="!bthGrayShow">
          <el-input v-model="testGatherName" placeholder="请输入内容" style="width:60%;"></el-input>
          <el-button type="primary" @click="addTestGatherBtn">添加集合</el-button>
        </div>
        <div class="left-content-body scrollbal-common">
          <!-- <el-scrollbar class="scrollbar-apidoc-tree"> -->
            <el-tree :data="list" node-key="keyId" :default-expanded-keys="defaultExpandedKeys" ref='tree' :props="defaultProps" :filter-node-method="filterNode" :expand-on-click-node="false" :highlight-current="true">
              <div class="iconmorebox" slot-scope="scope" :class="{'chooseShow':showSelected(scope)}" style="height: 31px;" @click="HandleNode(scope,$event)">
                <span :title="scope.node.label"  style="height: 31px;line-height: 31px;">
                  <i class="iconfont icon-folder " v-if="scope.data.apiListBoList&&scope.node.label=='全部接口'"></i>
                  <i class="iconfont icon-folder-open" v-if="scope.data.apiListBoList&&scope.node.label!=='全部接口'"></i>
                  <span class="file-font-ellipsis" :class="{'font-max-width':scope.data.apiListBoList,'font-min-width':!scope.data.apiListBoList}">{{scope.node.label}}</span>
                </span>
                <div class="iconmore1" v-show="scope.data.apiListBoList&&scope.data.name !=='全部接口'" style="margin-top: 5px;">
                  <i class="el-icon-plus" style='width:20px' v-show="authFunction('FUNC_APIDOC_ADD_API', 3, getUrlParams().projectId)"
                  @click="addInterfaceBtn(scope)" title="添加接口"></i>
                  <i class="el-icon-edit" style='width:20px' v-show="authFunction('FUNC_APIDOC_UPDATE_TYPE', 3, getUrlParams().projectId)"
                   @click="fixSortBtn(scope)" title="修改分类"></i>
                  <i class="el-icon-delete" v-show="authFunction('FUNC_APIDOC_DELETE_TYPE', 3, getUrlParams().projectId)"
                   @click="deleteSortBtn(scope)" title="删除分类"></i>
                </div>
                <div class="iconmore1" v-show="!scope.data.apiListBoList" style="margin-top: 5px;">
                  <i style="visibility: hidden;">占s</i>
                  <i class="el-icon-delete" style='width:20px' v-show="authFunction('FUNC_APIDOC_DELETE_API', 3, getUrlParams().projectId)"
                   @click="deleteSortBtn(scope)" title="删除接口"></i>
                </div>
                <!-- <div style="clear: both;"></div> -->
              </div>
            </el-tree>
          <!-- </el-scrollbar> -->
        </div>
      </div>
      <div class="file-right-box fr">
        <div v-if="detailShow">
          <div class="file-right-box-title" v-if="bthGrayShow">
            <span class="file-right-box-title-font">&nbsp;全部接口有({{sortTotal}})个</span>
            <div style="display: inline-block;position: absolute;right: 100px;">
              <el-button @click="exportDoc" v-show="authFunction('FUNC_APIDOC_EXPORT_API_DOC', 3, getUrlParams().projectId)"
              class="cursor-pointer file-plus-hover" type="primary">导出</el-button>
              <el-button @click="importDoc" v-show="authFunction('FUNC_APIDOC_IMPORT_API_DOC', 3, getUrlParams().projectId)"
                         class="cursor-pointer file-plus-hover" type="primary">导入</el-button>
              <!--<el-upload-->
                <!--class="upload-demo"-->
                <!--:action="importUrl"-->
                <!--name="file"-->
                <!--style="display: inline-block;"-->
                <!--:data='{apiClassId:this.getUrlParams().apiClassId}'-->
                <!--:show-file-list="false"-->
                <!--:on-success="importDocSuccess"-->
                <!--:on-error="importDocError"-->
                <!--accept=".json"-->
                <!--multiple>-->
                  <!--<el-button v-show="authFunction('FUNC_APIDOC_IMPORT_API_DOC', 3, getUrlParams().projectId)"-->
                  <!--class="cursor-pointer file-plus-hover" type="primary">导入</el-button>-->
              <!--</el-upload>-->
            </div>
            
            <el-button type="primary" v-show="authFunction('FUNC_APIDOC_ADD_API', 3, getUrlParams().projectId)"
            @click="addInterfaceBtn" class="fr">添加接口</el-button>
            <div style="clear: both;"></div>
          </div>
          <div class="file-right-box-title" v-if="!bthGrayShow">
            <span class="file-right-box-title-font">测试集合</span>
          </div>
        </div>
        <table-list v-if="detailShow" :setId="apiTypeId" @sortFun="sortChildFun" :exId="exId"></table-list>
        <file-dateil v-if="!detailShow" :setId="apiId" @sortFun="sortChildFun"></file-dateil>
      </div>
    </div>
    <!-- 添加分类&修改分类 -->
    <el-dialog :title="sortTitle" :visible.sync="addDiagloshow" width="24%" :close-on-click-modal="false">
      <div class="date-container">
        <div class="data-left m10">
          <span class="data-icon file-font-width"><span style="color:red;">*</span>分类名：</span>
          <el-input v-model="fileName" placeholder="请输入分类名" style="width:60%;"></el-input>
        </div>  
        <div class="data-left m10">
          <span class="data-icon file-font-width">备注：</span>
          <el-input v-model="fileDesc" placeholder="请输入备注" style="width:60%;"></el-input>
        </div>  
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addDiagloshow=false">取 消</el-button>
        <el-button type="primary" @click="saveSortBtn" v-if="sortTitle=='添加分类名'">确 定</el-button>
        <el-button type="primary" @click="saveFixSortBtn" v-else>确 定</el-button>
      </div>
    </el-dialog>
    <!-- 添加接口-->
    <el-dialog title="添加接口" :visible.sync="addInterfaceshow" width="24%" :close-on-click-modal="false">
      <div class="date-container">
        <div class="data-left m10">
          <span class="data-icon file-font-width"><span style="color:red;">*</span>选择分类：</span>
          <!-- <el-input v-model="interfaceArr.apiTypeId" placeholder="接口分类" style="width:60%;"></el-input> -->
          <el-select placeholder="选择分类" style="width:60%;" v-model="interfaceArr.apiTypeId" @change="sortChangeEvent">
              <el-option v-for="(item,index) in sortListData" :key="index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </div>  
        <div class="data-left m10">
          <span class="data-icon file-font-width"><span style="color:red;">*</span>接口名称：</span>
          <el-input v-model="interfaceArr.apiName" placeholder="接口名称" style="width:60%;"></el-input>
        </div> 
        <div class="data-left m10">
          <span class="data-icon file-font-width"><span style="color:red;">*</span>接口路径：</span>
          <el-select  style="width:80px;" v-model="interfaceArr.apiMethod">
              <el-option v-for="item in interfaceUrlList" :key="item.key" :label="item.label" :value="item.value"></el-option>
          </el-select>
          <el-input v-model="interfaceArr.apiPath" placeholder="/path" style="width:40%;"></el-input>
        </div> 
        <div class="data-icon m10"><span style="visibility: hidden;">注意</span>注:详细的接口数据可以在编辑页面中添加</div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addInterfaceshow=false">取 消</el-button>
        <el-button type="primary" @click="savePathBtn">确 定</el-button>
      </div>
    </el-dialog>

    <!-- 导入-->
    <el-dialog title="导入接口" :visible.sync="importDocShow" width="24%" :close-on-click-modal="false">
      <div class="date-container" style="margin-bottom: 20px">
        <div class="data-left m10">
          <span class="data-icon file-font-width">公共路径：</span>
          <el-input v-model="commonPath" placeholder="请输入公共路径" style="width:60%;"></el-input>
        </div>
        <div class="data-left m10">
          <span class="data-icon file-font-width"><span style="color:red;">* </span>json文件：</span>
        <el-upload
          class="upload-demo"
          :action="importUrl"
          name="file"
          style="display: inline-block;"
          :data='{apiClassId:this.getUrlParams().apiClassId,commonPath:this.commonPath}'
          :show-file-list="false"
          :on-success="importDocSuccess"
          :on-error="importDocError"
          accept=".json"
          multiple>
          <el-button v-show="authFunction('FUNC_APIDOC_IMPORT_API_DOC', 3, getUrlParams().projectId)"
                     class="cursor-pointer file-plus-hover" type="primary">选择文件</el-button>
        </el-upload>
        </div>
        <div class="data-icon m10"><span style="visibility: hidden;">注意</span>注: 若有公共路径，请先输入公共路径，如无则直接选择.json文件</div>
      </div>
    </el-dialog>

  </div>
</template>
<script>
import {mapState,mapMutations} from "vuex";
import TableList from "./fileTableList.vue";
import fileDateil from "./fileDateil.vue";
import fileSetting from "./fileSetting.vue";
import merge from 'webpack-merge';
export default {
  name: "fileCreat",
  //mixins: [ProjectCommonMixin],
  data() {
    return {
      isCollapse:'接口',
      list:[],
      defaultProps:{
        children: 'apiListBoList',
        label: 'name'
      },
      importUrl:'',
      nodeArr:[],//分类默认选中
      bthGrayShow:true,
      interfaceArr:{apiMethod:'GET',apiTypeId:'',apiName:'',apiPath:''},
      diagloshow:false,
      addDiagloshow:false,
      addInterfaceshow:false,
      importDocShow: false,
      commonPath: '',
      fileName:'',
      filterText:'',
      fileDesc:'',
      testGatherName:'',
      sortTitle:'添加分类',
      apiClassId: 0,
      // defaultExpandedKeys:[],
      apiClassName:'',
      exId:true
    };
  },
  watch: {
    apiClassId: function (newVal, oldVal){
      this.getApiTypeList();
      this.getAllType();
    },
    filterText(val) {
      this.$refs.tree.filter(val);
    }
  },
  computed:{
    ...mapState({
      defaultExpandedKeys:state=>state.fe.defaultExpandedKeys,
      apiId:state=>state.fe.apiId,
      apiTypeId:state=>state.fe.apiTypeId,
      detailShow:state=>state.fe.detailShow,
      interfaceUrlList:state=>state.fe.interfaceUrlList,
      sortTotal:state=>state.fe.sortTotal,
      sortListData:state=>state.fe.sortListData,
      watchData:state=>state.fe.watchData,
      watchDataObj1:state=>state.fe.watchDataObj1,
      detailInitData:state=>state.fe.detailInitData,
      editShow:state=>state.fe.editShow
    }),
  },
  mounted() {
    this.importUrl="/api/apidoc/import?projectId="+this.getUrlParams().projectId;
    this.apiClassId=this.getUrlParams().apiClassId;
    this.getApiClassInfo();
    this.fileApiTypeId(this.getUrlParams().apiTypeId?this.getUrlParams().apiTypeId:0);
    this.fileApiId(this.getUrlParams().apiId?this.getUrlParams().apiId:-1);
    // let isSetting=this.getUrlParams().isCollapse;
    // if (isSetting==2){
    //   this.isCollapse='设置'
    // }
    if(this.apiTypeId || this.apiId){
      this.apiTypeId!=='-1'?this.filePageSwitch(true):this.filePageSwitch(false)
    }
    this.getApiTypeList();
    this.getAllType();
  },
  components: { TableList,fileDateil,fileSetting}, 
  methods: {
    ...mapMutations(['defaultExpandedKeysFun','filePageSwitch','fileApiId','fileApiTypeId','sortListDataFun','detailInitDataFun','watchDataFun','watchDataObjFun','editShowFun','exIdFun']),
    //返回
    backBtn(){
      this.goToPage(this,'fileInfo',{projectId:this.getUrlParams().projectId,docType:'api'})
    },
    //设置跳转
    handleRadioChange(data){
      this.isCollapse = data;
      if(this.isCollapse == "设置" && this.getUrlParams().isCollapse){
        this.fileApiTypeId(0);
        this.fileApiId(-1)
        this.$router.push({query:{projectId:this.getUrlParams().projectId,apiClassId:this.apiClassId,isCollapse:2}});
      }else {
        // this.filePageSwitch(true)
         //处理数据操作时,页面没有实时渲染
        // this.fileApiTypeId('-1');
        // this.exIdFun(false) 
        // this.getApiTypeList();
        // this.getAllType();
      }
    },
    setValue(setValue){
      this.isCollapse = setValue;
    },
    // 设置
    // setBtn(){
    //   this.isCollapse == "设置"
    //   this.handleRadioChange()
    // },
    getApiClassInfo(){
      $http.get($http.api.apidoc.get_one_class,{apiClassId:this.apiClassId}).then(res =>{
        if (res.status==200){
          this.apiClassName=res.data.apiClassName;
        }
      })
    },
    //导出
    exportDoc(){
      window.location.href='/api/apidoc/export?projectId='+this.getUrlParams().projectId+'&apiClassId='+this.getUrlParams().apiClassId;
    },

    importDoc(){
      this.commonPath='';
      this.importDocShow=true;
    },

    importDocSuccess(response){
      if (response.status==200){
        this.importDocShow=false;
        this.commonPath='';
        this.$message({
          message:'导入成功',
          type:'success'
        })
        this.fileApiTypeId(this.getUrlParams().apiTypeId?this.getUrlParams().apiTypeId:0);
        this.fileApiId(this.getUrlParams().apiId?this.getUrlParams().apiId:-1);
        if(this.apiTypeId || this.apiId){
          this.apiTypeId!=='-1'?this.filePageSwitch(true):this.filePageSwitch(false)
        }
        this.getApiClassInfo();
        this.getApiTypeList();
        this.getAllType();
        this.exIdFun(false)
        // this.$nextTick(()=>{
        //   // this.$refs.doctableList.init()
        //   console.log(this.$refs)
        // });
        
      }else {
        this.$message({
          message:response.msg,
          type:'error'
        })
      }
    },
    // 获取文档
    // getDoc(){
    //   $http.get($http.api.apidoc.get_class,{projectId:this.projectId}).then(res =>{
    //     this.list=res.data;
    //   }).catch(e =>{

    //   })
    // },
    importDocError(){
      this.$message({
        message:'上传失败',
        type:'error'
      })
    },
    //监听table list的分类change是否触发
    sortChildFun(item){
      if(item){
        this.getApiTypeList();
      }
    },
    //过滤节点
    filterNode(value, data) {
      if (!value) return true;
      // if(data.apiListBoList!==undefined){
      //   return true;
      // }
      let result=data.name.indexOf(value) !== -1;
      if (data.apiPath){
        result = result || data.apiPath.indexOf(value) !== -1;
      }
      return result;
    },

    getApiTypeList(){
      $http.get($http.api.apidoc.get_type,{apiClassId:this.apiClassId}).then(res =>{
        this.list = res.data;
        this.list.unshift({name:'全部接口',id:'',keyId:'all',apiTypeDesc:'全部接口',apiListBoList:[]})
        this.initTreeData(this.list);
      }).catch(e =>{

      })
    },

    initTreeData(arr) {
      let key=0;
      let defaultExpandedKeys=[];
      arr.forEach(item => {
        // key++;
        item.keyId = 0-item.id;
        if (item.id==parseInt(this.apiTypeId)) {
          defaultExpandedKeys.push(item.keyId);
        }
        if(item.apiListBoList&&item.apiListBoList.length>0){
          item.apiListBoList.forEach(item1 =>{
            // key++;
            item1.keyId=item1.id;
            if (item1.id==parseInt(this.apiId)) {
              defaultExpandedKeys.push(item.keyId)
            }
          })
        }
      });
      this.defaultExpandedKeysFun(defaultExpandedKeys)
    },

    showSelected(scope){
      if (scope.data.apiListBoList!==undefined){
        if (scope.data.id==this.apiTypeId){
          return true;
        }
      }else {
        if (scope.data.id==this.apiId){
          return true;
        }
      }
      return false;
    },

    //获取全部分类
    getAllType(){
      $http.get($http.api.apidoc.get_all_type,{apiClassId:this.apiClassId}).then(res =>{
        if(res.data.length>0){
          res.data.forEach(item=>{
            item['label'] = item.apiTypeName
            item['value'] = item.apiTypeId
          })
        }
        // this.interfaceSortList=res.data;
        this.sortListDataFun (res.data)
      }).catch(e =>{

      })
    },
    updateShow(index,type){
      this.list[index].type=!type;
    },

    //接口列表
    interfaceListBtn(){
      this.bthGrayShow= true;
    },
    //测试集合
    testGatherBtn(){
      this.bthGrayShow= false;
    },
    //添加集合
    addTestGatherBtn(){

    },
    //添加分类
    addsortBtn(){
      this.addDiagloshow=true;
      this.sortTitle = "添加分类名";
      // this.filePageSwitch(true)
    },
    //确认添加分类
    saveSortBtn(){
      if(!this.fileName.trim()){
        this.$message({
          message: '分类名不能为空!',
          type: 'error'
        });
        return false
      }
      $http.post($http.api.apidoc.save_type,{apiClassId:this.getUrlParams().apiClassId,apiTypeName:this.fileName,apiTypeDesc:this.fileDesc}).then(res =>{
        if(res.status==200){
          this.$message({
            message: '接口分类添加成功',
            type: 'success'
          });
          this.fileName="";
          this.fileDesc="";
          this.getApiTypeList();
          this.getAllType();
          this.addDiagloshow=false;
        }
      }).catch(e =>{

      })
    },
    //添加接口
    addInterfaceBtn(item){
      this.addInterfaceshow = true;
      this.getAllType()
      if(item.data){
        this.interfaceArr.apiTypeId = item.data.id;
      }else{
        this.interfaceArr.apiTypeId = '';
      }
    },
    //选择分类change
    sortChangeEvent(val){

    },
    // 修改分类
    fixSortBtn(item){
      this.sortTitle = "修改分类名";
      this.addDiagloshow=true;
      this.fileName = item.data.name;
      this.fileDesc=item.data.apiTypeDesc;
      this.editorApiTypeId=item.data.id;
    },
    //保存修改分类
    saveFixSortBtn(){
      if(!this.fileName.trim()){
        this.$message({
          message: '分类名不能为空!',
          type: 'error'
        });
        return false
      }
      $http.post($http.api.apidoc.update_type,{apiTypeId:this.editorApiTypeId,apiTypeName:this.fileName,apiTypeDesc:this.fileDesc}).then(res =>{
        if(res.status==200){
          this.$message({
            message: '接口分类修改成功',
            type: 'success'
          });
          this.getApiTypeList();
          this.addDiagloshow=false;
        }
      }).catch(e =>{

      })
    },
    //保存接口
    savePathBtn(){
      
      for(var i in this.interfaceArr){
        if(!this.interfaceArr[i]){
          this.$message({
            message: '必填项不能为空!',
            type: 'error'
          });
          return false
        }
      }
      if(!this.interfaceArr.apiName.trim()){
        this.$message({
          message: '必填项不能为空!',
          type: 'error'
        });
        return false
      }
      if(!this.interfaceArr.apiPath.startsWith('/')){
        this.$message({
          message: 'path第一位必需为 /, 只允许由 字母数字-/_:.! 组成',
          type: 'error'
        });
        return false
      }
      $http.post($http.api.apidoc.create_api,{apiTypeId:this.apiTypeId,...this.interfaceArr}).then(res =>{
        if(res.status==200){
          this.$message({
            message: '创建接口成功',
            type: 'success'
          });
          this.interfaceArr.apiMethod="GET";
          this.interfaceArr.apiName="";
          this.interfaceArr.apiPath="";
          this.interfaceArr.apiTypeId="";
          this.getApiTypeList();
          this.initPage(res.data,null);
          this.addInterfaceshow = false
        }
      }).catch(e =>{

      })
    },
    // 删除分类
    deleteSortBtn(item){
      if (item.data.apiListBoList!==undefined){
        this.$confirm(`确定删除此接口分类吗？该操作会删除该分类下所有接口，接口删除后无法恢复`, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(async () => {
          let formData=new FormData();
          formData.set("apiTypeId",item.data.id)
          $http.post($http.api.apidoc.delete_type,formData,{type:"form"}).then(res =>{
            if (res.status===200){
              this.$message({
                message: '删除分类成功',
                type: 'success'
              });
              this.getApiTypeList();
              this.initPage(this.list[0],null)
            }
          }).catch(e =>{

          })
        }).catch(e => {});
      }else {
        this.$confirm(`确定删除此接口吗？该操作会删除该接口，接口删除后无法恢复`, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(async () => {
          let formData=new FormData();
          formData.set("apiId",item.data.id);
          $http.post($http.api.apidoc.delete_api,formData,{type:'form'}).then(res =>{
            if (res.status===200){
              this.$message({
                message: '删除接口成功',
                type: 'success'
              });
              this.initPage(item.node.parent.data,null)
              this.getApiTypeList();
            }
          }).catch(e =>{

          })
        }).catch(e => {});
      }
    },
    HandleNode(scope,ev){
      if(['el-icon-plus','el-icon-edit','el-icon-delete'].indexOf(ev.target.className)!==-1){
        return false
      }
      if(this.editShow){
        this.$confirm(`离开页面会丢失当前编辑的内容，确定要离开吗？`, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then( () => {
          this.filterText="";
          let defaultExpandedKeys=[];
          defaultExpandedKeys.push(scope.node.key);
          if (scope.data.apiListBoList){
            scope.node.parent.childNodes.forEach(node =>{
              if (node.key!==scope.node.key){
                node.expanded=false;
              }
            })
          }
          let data = scope.data,node = scope.node;
          this.editShowFun(false);
          this.defaultExpandedKeysFun(defaultExpandedKeys)
          this.initPage(data,node)
        }).catch(()=> {});
      }else{
        this.filterText="";
        let defaultExpandedKeys=[];
        defaultExpandedKeys.push(scope.node.key);
        if (scope.data.apiListBoList){
          scope.node.parent.childNodes.forEach(node =>{
            if (node.key!==scope.node.key){
              node.expanded=false;
            }
          })
        }
        let data = scope.data,node = scope.node;
        this.editShowFun(false);
        this.defaultExpandedKeysFun(defaultExpandedKeys)
        this.initPage(data,node)
      }   
    },
    //init页面渲染
    initPage(data,node){
      
      //处理数据操作时,页面没有实时渲染
      // let arr = JSON.parse(JSON.stringify(this.list))
      // this.list = arr; 
      let obj = {}
      if (data.apiListBoList) {
        this.fileApiTypeId(data.id);
        this.fileApiId(-1);
        obj = {'apiId':-1,'apiTypeId':data.id}
        this.filePageSwitch(true)
      }else {
        this.fileApiTypeId(-1);
        this.fileApiId(data.id);
        obj = {'apiId':data.id,'apiTypeId':-1}
        this.filePageSwitch(false)
      }
      if(data.name=="全部接口"){
        window.history.replaceState(null,null,'?projectId='+this.getUrlParams().projectId+'&apiClassId='+this.getUrlParams().apiClassId);
      }else{
        window.history.replaceState(null,null,'?projectId='+this.getUrlParams().projectId+'&apiClassId='+this.getUrlParams().apiClassId+'&apiId='+obj.apiId+'&apiTypeId='+obj.apiTypeId);
      }
      
      // this.$router.push({
      //   query:merge(this.$route.query,obj)
      // })
      
    }
  }
};
</script>

<style lang="scss" scoped>
  .scrollbar-apidoc-tree {
    height: 660px;
    width: 250px;
  }
.file-back{
  color: #409eff;
  cursor: pointer;
  display: inline-block;
  margin-right: 10px;
}
.left-content-body{
  height: 605px;
  overflow-x: hidden;
  overflow-y: auto;
}
.file-font-ellipsis{
  width: 185px;
  // width: calc(100% + 120px);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  display: inline-block;
  vertical-align:bottom;
}

.file-header-title{
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 10px;
  display: inline-block;
}
.file-box{
  position: relative;
  .file-left-box{
    width: 285px;
    min-width: 230px;
    /* height: 100%; */
    /*max-height: 1000px;*/
    // height: 760px;
    background: #f3f4f6;
    border: 1px solid #f3f4f6;
    // overflow-y: auto;
    .api-search {
      height: 50px;
      background: #f3f4f6;
      /*.api-search-input {*/
        /*.el-input--mini .el-input__inner {*/
          /*height: 28px !important;*/
        /*}*/
      /*}*/
      .add-type-button {
        height: 30px;
      }
    }

    .file-left-btn-box{
      
      .file-left-btn{
        display: inline-block;
        width: 49.3%;
        height: 50px;
        text-align: center;
        // padding: 0 10px;
        cursor: pointer;
        line-height: 50px;
        font-size: 16px;
        // border-bottom: 1px solid gainsboro;
      }
     
    }
     .left-btn-grey{
        background: #f3f4f6;
      }
     
  }
  .file-right-box{
    width: calc(100% - 325px);
    height: 100%;
    min-height: 703px;
    padding: 0 10px;
    border: 1px solid #f3f4f6;
    .file-right-box-title{
      padding: 10px 0;
      .file-right-box-title-font{
        font-size: 22px;
        font-weight: 500;
        border-left: #3c85d2 4px solid;
      }
    }
  }
}
.file-font-width{
  width: 90px;
  display: inline-block;
  text-align: right;
}
.chooseShow{
  background: #d5ebfc;
  border-right: 2px #3c85d2 solid;
}
.iconmorebox{
  font-size: none;
  &:hover{
    background: #e5f3ff;
    .iconmore1 {
      display: inline-block;
      font-size: small;
    }
  }
}
.iconmore1{
  display: none;
}
.font-max-width{
  max-width: 155px;
}
.font-min-width{
  max-width: 210px;
}
</style>
