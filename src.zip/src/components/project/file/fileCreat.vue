<template>
  <div  class="content-outer-box">
    <div class="file-content">
      <div class="file-detali-box cursor-pointer" style="vertical-align: top;" @click="creatFile" v-show="authFunction('FUNC_APIDOC_ADD_CLASS', 3, getUrlParams().projectId)">
        <div class="file-creat-box">
          <span class="file-creat-font"><i class="el-icon-circle-plus-outline"></i>新建接口文档</span>
        </div>
        
      </div>
        <div class="file-detali-box cursor-pointer" v-for="(item,index) in list" :key="index">
          <div class="file-detali-box-top" style="width:97%;" :title="item.apiClassName" @click="toFilelist(item)">
            <span class="file-dateli-font " >{{item.apiClassName}}</span>
          </div> 
           <!-- 显示更多 -->
          <div class="file-more" 
            v-show="authFunction('FUNC_APIDOC_UPDATE_CLASS', 3, getUrlParams().projectId)||authFunction('FUNC_APIDOC_DELETE_CLASS', 3, getUrlParams().projectId)">
            <el-popover placement="right" width="30;" trigger="click" popper-class="file-popper" >
              <el-button @click="editEvent(item)" v-show="authFunction('FUNC_APIDOC_UPDATE_CLASS', 3, getUrlParams().projectId)"
              class="cursor-pointer file-plus-hover" type="text">编辑</el-button>
              <el-button @click="deleteDoc(item)" v-show="authFunction('FUNC_APIDOC_DELETE_CLASS', 3, getUrlParams().projectId)"
              class="cursor-pointer file-plus-hover" type="text">删除</el-button>
              <!-- <el-button @click="exportDoc(item)" class="cursor-pointer file-plus-hover" type="text">导出</el-button>
              <el-upload
                class="upload-demo"
                :action="importUrl"
                name="file"
                :data='{apiClassId:item.apiClassId}'
                :show-file-list="false"
                :on-success="importDocSuccess"
                :on-error="importDocError"
                accept=".json"
                multiple>
                  <el-button class="cursor-pointer file-plus-hover" type="text">导入</el-button>
              </el-upload> -->
              <span class="iconfont icon-operate fr" @click="moreEvent" slot="reference"> </span>
            </el-popover>
          </div>
          
          <div class="file-detali-box-bottom" @click="toFilelist(item)">
            <span class="file-user-font">{{item.createUser}}创建于 {{item.createTime}}</span>
            <span class="file-user-font fr">{{item.apiCount}}个</span>
          </div>
        </div>
    </div>
    <!-- 新建文档dialog -->
    <el-dialog title="新建接口文档" :visible.sync="diagloshow" width="26%" :close-on-click-modal="false">
      <div class="date-container">
        <div class="data-left">
          <span class="data-icon"><span style="color:red;">*</span>文档名称：</span>
          <el-input v-model="fileName" placeholder="请输入内容" style="width:74%;"></el-input>
        </div>
        <!--<div class="data-left">-->
          <!--<span class="data-icon">文库模板：</span>-->
          <!--<el-radio v-model="fileName" label="接口文档"></el-radio>-->
        <!--</div>-->
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancleBtn">取 消</el-button>
        <el-button type="primary" @click="createDoc">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 编辑名称 -->
    <el-dialog title="编辑名称" :visible.sync="editdiagloshow" width="26%" :close-on-click-modal="false">
      <div class="date-container">
        <div class="data-left">
          <span class="data-icon"><span style="color:red;">*</span>文库名称：</span>
          <el-input v-model="fileName" placeholder="请输入内容" style="width:80%;"></el-input>
        </div>  
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editdiagloshow=false">取 消</el-button>
        <el-button type="primary" @click="editDoc">确 定</el-button>
      </div>
    </el-dialog>
    
  </div>
</template>
<script>
import {mapState,mapMutations} from "vuex";
export default {
  name: "fileCreat",
  //mixins: [ProjectCommonMixin],
  data() {
    return {
      list:[],
      diagloshow:false,
      editdiagloshow:false,
      fileName:'',
      projectId:0,
      apiClassId:0,
      importUrl:'',
      // tipShow:true
    };
  },
  computed:{
    ...mapState({
      apiId:state=>state.fe.apiId,
      docSearchWord:state=>state.fe.docSearchWord,
    }),
  },

  watch: {
    docSearchWord: function (newVal, oldVal) {
      this.getDoc();
    },
  },

  mounted() {
    this.projectId=this.getUrlParams().projectId;
    this.importUrl="/api/apidoc/import?projectId="+this.projectId;
    this.initApiClassList();
  },
  components: {
  }, 
  methods: {
    ...mapMutations(['filePageSwitch','fileApiId','fileApiTypeId','sortListDataFun','changeDocSearchWord']),

    initApiClassList(){
      if (this.docSearchWord.trim()!==''){
        this.changeDocSearchWord('');
      }else {
        this.getDoc();
      }
    },

    importDocError(){
      this.$message({
        message:'上传失败',
        type:'error'
      })
    },

    importDocSuccess(response){
      if (response.status==200){
        this.$message({
          message:'导入成功',
          type:'success'
        })
        this.getDoc()
      }else {
        this.$message({
          message:response.msg,
          type:'error'
        })
      }
    },

    exportDoc(item){
      // let formData=new FormData;
      // formData.set('apiClassId',item.apiClassId())
      // $http.get($http.api.apidoc.export_api_doc,{apiClassId:item.apiClassId}).then(res =>{
      //   if (res.status==200){
      //     this.$message({
      //       message:'导出成功',
      //       type:'success'
      //     })
      //   }
      // })

      window.location.href='/api/apidoc/export?projectId='+this.projectId+'&apiClassId='+item.apiClassId;
    },

    //编辑文档
    editDoc(){
      if(!this.fileName.trim()){
        this.$message({
          message: '文档名不能为空!',
          type: 'error'
        });
        return false
      }
      $http.post($http.api.apidoc.update_class,{apiClassId:this.apiClassId,apiClassName:this.fileName}).then(res =>{
        if (res.status === 200) {
          this.$message({
            message: '修改成功',
            type: 'success'
          });
          this.editdiagloshow = false;
          this.fileName='';
          this.getDoc();
        }
      }).catch(e =>{

      })
    },
  //删除文档
    deleteDoc(item){
      this.hideTips()
      this.$confirm("删除文档将无法恢复，确定删除！", "提示", {
        distinguishCancelAndClose: true,
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: 'warning'
      }).then(() => {
        $http.post($http.api.apidoc.delete_class,{apiClassId:item.apiClassId}).then(res =>{
          if (res.status==200){
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            this.getDoc();
          }
        }).catch(e =>{

        })
      }).catch(e =>{

      })
    },
  //创建文档
    createDoc(){
      if(!this.fileName.trim()){
        this.$message({
          message: '文档名不能为空!',
          type: 'error'
        });
        return false
      }
      $http.post($http.api.apidoc.save_class,{projectId:this.projectId,apiClassName:this.fileName}).then(res =>{
        if (res.status === 200) {
          this.$message({
            message: '新建成功',
            type: 'success'
          });
          this.diagloshow = false;
          this.fileName='';
          this.getDoc();
        }
      }).catch(e =>{

      })
    },
// 获取文档
    getDoc(){
      $http.get($http.api.apidoc.get_class,{projectId:this.projectId,keyWord:this.docSearchWord}).then(res =>{
        this.list=res.data;
      }).catch(e =>{

      })
    },

    creatFile(){
      // v-show="authFunction('FUNC_APIDOC_ADD_API', 3, getUrlParams().projectId)"
      this.diagloshow = true;
      this.fileName = '';
    },
    confirmBtn() {
      //新建阶段
      if (!this.fileName) {
        this.$message({ message: "请输入名称" });
        return false;
      }
      this.diagloshow = false;
    },
    cancleBtn() {
      this.diagloshow = false;
    },
    editEvent(item){
      this.fileName=item.apiClassName||"";
      this.apiClassId=item.apiClassId;
      this.editdiagloshow = true;
      this.hideTips()
     
    },
    deleteEvent(item){
    },
    moreEvent(){

    },
    //隐藏tips
    hideTips(){
      let classList = [...document.getElementsByClassName("file-popper")]
      classList.forEach(el => {
        el.style.display = 'none'
      });
    },
    // 跳转至文档详情列表
    toFilelist(item){
      this.filePageSwitch(true);
      this.goToPage(this, 'fileList', {
        projectId: this.getUrlParams().projectId,
        apiClassId:item.apiClassId,
      });
    },
    //弹窗关闭前的回调
    handleClose(done) {
      
    }
  }
};
</script>

<style lang="scss" scoped>
.file-plus-hover{
  display: block;
  margin-left: 1px;
  &:hover{
    background: #d5ebfc;
  }
}
.file-content{
  min-height: 700px;
  display: inline-block;
  // flex-wrap: wrap;
  .file-creat-box{
    text-align: center;
    line-height: 100px;
    
  }
  
  .file-detali-box{
    width: 300px;
    height: 106px;
    margin:4px 10px;
    padding: 0 10px;
    border-radius: 5px;
    border: 1px solid #ececec;
    display: inline-block;
    position: relative;
    .file-more{
      position: absolute;
      top: 23px;
      right: 10px;
    }
    &:hover{
        // color: #3c85d2;
        background:#ececec; 
        // border: 1px solid #3c85d2;
        box-shadow: 1px 6px 10px #c9c7c7;
      }
    .file-creat-font{
      font-size: 22px;
      font-weight: 600;
      color: #3c85d2;
      i{
        transform: scale(1.2);
        padding: 5px;
      }
    }
     
    .file-detali-box-top{
      padding: 20px 0;
      .file-dateli-font{
        font-size: 22px;
        font-weight: 600;
        width: 282px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        display: inline-block;
      }
     
    }
    .file-detali-box-bottom{
      .file-user-font{
        // font-size: 22px;
        // font-weight: 600;
      }
    }
  }
}

</style>
