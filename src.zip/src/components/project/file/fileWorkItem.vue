<template>
  <div  class="content-outer-box">
    <div class="file-box">
       <el-table :data="attachmentList"  style="width: 100%;height: 100%;" border>
          <el-table-column prop="origName" label="文件名" show-overflow-tooltip width="300"></el-table-column>
          <el-table-column prop="size" label="大小(kb)" width="80"></el-table-column>
          <el-table-column prop="workItemTypeName" label="工作项类型" width="100"></el-table-column>
          <el-table-column prop="title" label="工作项" min-width="240px" show-overflow-tooltip>
            <template slot-scope="scope">
              <span class="file-text" @click="goToWorkItemDetail(scope.row)">{{scope.row.title}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="createUser" label="上传人" width="170" show-overflow-tooltip>
            <template slot-scope="scope">
                  <span class="table-column-padding">{{scope.row.userName}}({{scope.row.createUser}})</span>
            </template>
          </el-table-column>
          <el-table-column prop="createTime" label="上传时间" width="160" show-overflow-tooltip></el-table-column>
          <el-table-column label="操作" show-overflow-tooltip width="100">
            <template slot-scope="scope">
              <span @click="downloadAttachment(scope.row)"  class="file-text">下载</span>
              <span class="file-text" @click="deleteAttachment(scope.row)">删除</span>
            </template>
          </el-table-column>
       </el-table>
      <div class="table_b_f_b">
        <el-pagination class="fr mr10" style="margin-top: 9px;"
          @size-change="handleAttachmentListSizeChange"
          @current-change="handleAttachmentListCurrentChange"
          :current-page="pageInfo.pageNum"
          :page-sizes="[15, 30, 50]"
          :page-size="pageInfo.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :page-count="pageInfo.pages"
          :total="pageInfo.total"
        >
        </el-pagination>
      </div>
    </div>
  </div>
</template>
<script>
import {mapState,mapMutations} from "vuex";
export default {
  name: "fileInfo",
  //mixins: [ProjectCommonMixin],
  data() {
    return {
      pageInfo:{
        pageSize:15,
        pageNum:1,
        total:0,
        pages:0
      },
      attachmentList:[]
    };
  },
  computed:{
    ...mapState({
      docSearchWord:state=>state.fe.docSearchWord,
    }),
  },

  watch: {
    docSearchWord: function (newVal, oldVal) {
      this.getWorkItemAttachmentList();
      // if (newVal !== oldVal) {
      //   console.log(newVal)
      //   this.getWorkItemAttachmentList();
      // }
    },
  },

  mounted() {
    this.initAttachmentList();
  },
  components: {
  
  },
  methods: {
    ...mapMutations(['changeDocSearchWord']),

    initAttachmentList(){
      if (this.docSearchWord.trim()!==''){
        this.changeDocSearchWord('');
      }else {
        this.getWorkItemAttachmentList();
      }
    },

    goToWorkItemDetail(row){
      if (row.workItemType==1){
        this.goToPage(this,"requirementList",{projectId:this.getUrlParams().projectId,requireId:row.workItemId});
      }else if (row.workItemType==2){
        this.goToPage(this,"taskView",{projectId:this.getUrlParams().projectId,taskId:row.workItemId});
      } else if (row.workItemType==3) {
        this.goToPage(this,"bugList",{projectId:this.getUrlParams().projectId,bugId:row.workItemId});
      }
    },

    getWorkItemAttachmentList(){
      $http.get($http.api.document.attachment_list,{keyWord:this.docSearchWord,page:this.pageInfo.pageNum,size:this.pageInfo.pageSize}).then(res =>{
        if (res.status==200){
          this.pageInfo.total=res.data.total;
          this.pageInfo.pages=res.data.pages;
          this.attachmentList=res.data.list;
        }
      }).catch(e =>{

      })
    },

    handleAttachmentListCurrentChange(val){
      this.pageInfo.pageNum=val;
      this.getWorkItemAttachmentList();
    },

    handleAttachmentListSizeChange(val){
      this.pageInfo.pageSize=val;
      this.getWorkItemAttachmentList();
    },

    //跳转
    herfBtn(scope){

    },
    //下载
    downloadAttachment(scope){
      window.location.href=scope.url+'?projectId='+this.getUrlParams().projectId+'&origName='+scope.origName;
    },
    //删除
    deleteAttachment(scope) {
      this.$confirm(`确定移除 ${scope.origName}？`).then(() => {
        $http.post($http.api.attachment.delete, {attachmentId: scope.attachmentId, workItemType: scope.workItemType, workItemId: scope.workItemId}).then(res => {
          if (res.status == 200) {
            this.$message({
              type: "success",
              message: res.msg || "删除成功!"
            });
            this.getWorkItemAttachmentList();
          } else {
            this.$message({
              type: "error",
              message: res.msg || "删除失败!"
            });
          }
        });
      }).catch(_=>_)
    },
  }
};
</script>

<style lang="scss" scoped>
.file-box{
  min-height: 700px;
  .file-text{
      color:#409EFF;
      margin-right: 10px;
      cursor:pointer;
    }
}

</style>
