<template>
  <div id="demandlist" >
        <div class="file-box" @click="fileEdiGloal">
          <!-- 基本设置 -->
          <div>
            <p class="file-right-box-title-font ">&nbsp;基本设置</p>
            <ul class="file-box-pad">
              <li class="file-box-margin">
                <span class="file-font-width"><span style="color:red;">*</span>接口名称：</span>
                  <el-input v-model="interfaceList.apiName" placeholder="接口名称" style="width:70%;" @change="checkEdit"></el-input>
                <span v-show="interfaceList.apiName.length==0" style="color:red;">请输入接口名称!</span>
              </li>
              <li>
                <span class="file-font-width"><span style="color:red;">*</span>选择分类：</span>
                <el-select  style="width:70%;" v-model="interfaceList.apiTypeId" @change="checkEdit">
                  <el-option v-for="item in sortListData" :key="item.value" :label="item.label" :value="item.value"></el-option>
                </el-select>
              </li>
              <li>
                <span class="file-font-width"><span style="color:red;">*</span>接口路径：</span>
                <el-select  style="width:80px;" @change="checkParamGroup" v-model="interfaceList.apiMethod" >
                  <el-option v-for="item in interfaceUrlList" :key="item.key" :label="item.label" :value="item.value"></el-option>
                </el-select>
                <el-input v-model="interfaceList.apiPath" placeholder="接口名称" style="width: calc(67% - 39px);" @change="checkEdit"></el-input>
                <span v-show="interfaceList.apiPath.length==0" style="color:red;">请输入接口路径!</span>
              </li>
              <li>
                <span class="file-font-width"><span style="color:red;">*</span>状态：</span>
                <el-select  v-model="interfaceList.apiStatus" style="width:70%;" @change="checkEdit">
                  <el-option v-for="item in statusList" :key="item.value" :label="item.label" :value="item.value"></el-option>
                </el-select>
              </li>
            </ul>
          </div>
          <!-- 请求参数设置  -->
          <div>
            <p class="file-right-box-title-font ">&nbsp;请求参数设置</p>
            <div class="file-tab">
              <el-radio-group v-model="paramSet" style="margin-bottom: 20px;" @click="paramSetClick">
                <el-radio-button label="Body" v-if="['GET','HEAD','OPTIONS'].indexOf(interfaceList.apiMethod)==-1">Body</el-radio-button>
                <el-radio-button label="Query" >Query</el-radio-button>
                <el-radio-button label="Headers" >Headers</el-radio-button>
              </el-radio-group>
            </div>
            <div class="file-edit-block">
              <div class="mTB file-btn-box">
                <div v-if="paramSet =='Body'&&['GET','HEAD','OPTIONS'].indexOf(interfaceList.apiMethod)==-1" style="margin-bottom: 15px;">
                  <el-radio-group v-model="interfaceList.reqBodyType">
                    <el-radio label="form">form</el-radio>
                    <el-radio label="json">json</el-radio>
                    <!-- <el-radio label="file">file</el-radio>
                    <el-radio label="raw">raw</el-radio> -->
                  </el-radio-group>
                </div>
                 <el-button type="primary" @click="addQueryBtn" v-if="paramSet =='Query'">添加Query参数</el-button>
                 <el-button type="primary" @click="addHeadersBtn" v-if="paramSet =='Headers'">添加Headers</el-button>
                 <el-button type="primary" @click="addJsonBtn" v-if="interfaceList.reqBodyType =='json'&&paramSet =='Body'">导入json</el-button>
                 <el-button type="primary" @click="addFormBtn" v-if="interfaceList.reqBodyType =='form'&&paramSet =='Body'&&['GET','HEAD','OPTIONS'].indexOf(interfaceList.apiMethod)==-1">添加form参数</el-button>
                 <!-- Query批量 -->
                 <span class="file-btn-font fr cursor-pointer" @click="addBatchQueryshow" v-if="paramSet =='Query'">批量添加</span>
                 <!-- form批量 -->
                 <span class="file-btn-font fr cursor-pointer" @click="addBatchFormshow" v-if="interfaceList.reqBodyType =='form'&&paramSet =='Body'">批量添加</span>
                 <!-- 添加Query参数 -->
                 <ul class="file-box-pad" v-if="paramSet =='Query'">
                   <li v-for="(data,$index) in queryRequireList" :key="$index">
                     <el-input v-model="data.name" style="width:calc(27% - 10px);" placeholder="参数名称" @change="checkEdit"></el-input>
                     <el-select  v-model="data.required" style="width:calc(17% - 10px);" @change="checkEdit">
                      <el-option v-for="item in requireList" :key="item.key" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                    <el-input v-model="data.example" style="width:calc(27% - 10px);" placeholder="参数示例" @change="checkEdit" type="textarea" autosize></el-input>
                    <el-input v-model="data.queryDesc" style="width:calc(27% - 10px);" placeholder="备注" @change="checkEdit" type="textarea" autosize></el-input>
                    <i class="el-icon-delete cursor-pointer" @click="queryDelete(data,$index)"></i>
                   </li>
                 </ul>
                 <!-- 添加Headers -->
                 <ul class="file-box-pad" v-if="paramSet =='Headers'">
                   <li v-for="(data,$index) in headerList" :key="$index">
                     <el-autocomplete  v-model="data.name" placeholder="参数名称" :fetch-suggestions="querySearch" style="width: 17%;" >
                      <!--<el-option v-for="item in headerRequireList" :key="item.value" :label="item.label" :value="item.value"></el-option>-->
                    </el-autocomplete>
                     <el-input v-model="data.value" placeholder="参数值" style="width:31%;" @change="checkEdit" type="textarea" autosize></el-input>
                      <el-input v-model="data.headerDesc" style="width:47%;" placeholder="备注" @change="checkEdit" type="textarea" autosize></el-input>
                    <i class="el-icon-delete cursor-pointer" @click="headerDelete(data,$index)"></i>
                   </li>
                 </ul>
                 <!-- 添加body -->
                 <div class="file-json-tree file-box-pad" v-if="interfaceList.reqBodyType =='json'&&paramSet =='Body'">
                  <!-- json编辑 -->
                  <json-tree :jsondata="jsonTreeData"></json-tree>
                 </div> 
                  <!-- 添加form参数 -->
                 <ul class="file-box-pad" v-if="interfaceList.reqBodyType =='form'&&paramSet =='Body'">
                   <li v-for="(data,$index) in fromList" :key="$index">
                     <el-input v-model="data.name" style="width:calc(17% - 10px);" placeholder="name" @change="checkEdit"></el-input>
                     <el-select  v-model="data.type" style="width:calc(16% - 10px);" @change="checkEdit">
                      <el-option v-for="item in fromTypeList" :key="item.key" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                    <el-select  v-model="data.required" style="width:calc(16% - 10px);" @change="checkEdit">
                      <el-option v-for="item in requireList" :key="item.key" :label="item.label" :value="item.value"></el-option>
                    </el-select>
                    <el-input v-model="data.example" style="width:calc(17% - 10px);" placeholder="参数示例" @change="checkEdit" type="textarea" autosize></el-input>
                    <el-input v-model="data.formDesc" style="width:calc(27% - 10px);" placeholder="备注" @change="checkEdit" type="textarea" autosize></el-input>
                    <i class="el-icon-delete cursor-pointer" @click="formDelete(data,$index)"></i>
                   </li>
                 </ul>  
              </div>
          
            </div>
           
          </div>  
          <!-- 返回数据设置  -->
          <div class=" "  style="overflow: auto;">
            <p class="file-right-box-title-font ">&nbsp;返回数据设置 </p>
         
            <div class="file-json-tree file-box-pad mTB">
              <!-- json编辑 -->
              <el-button type="primary" @click="addBodyJsonBtn" style="margin-bottom: 25px;">导入json</el-button>
              <json-tree :jsondata="responseData"></json-tree>
            </div> 
          </div>
          <!-- 状态码   -->
          <div class=" ">
            <p class="file-right-box-title-font ">&nbsp;状态码 </p>
            <div class="file-edit-block mTB file-btn-box">
              <el-button type="primary" @click="addStatusCodeBtn">添加</el-button>
              <ul class="file-box-pad">
                <!-- json编辑 -->
                <li v-for="(data,$index) in statusCodeList" :key="$index">
                  <el-input v-model="data.code" style="width:calc(27% - 10px);" placeholder="状态码" @change="checkEdit"></el-input>
                  <el-input v-model="data.codeExplain" placeholder="说明" style="width:calc(27% - 10px);" @change="checkEdit"></el-input>
                  <i class="el-icon-delete cursor-pointer" @click="statusCodeDelete(data,$index)"></i>
                </li>
              </ul>
            </div>
          </div>
          <!-- 备注 -->
          <div class="">
            <p class="file-right-box-title-font ">&nbsp;备注 </p>
            <tiny-mce :value="interfaceList.apiDesc" :plugins="tinymcePlugins" :toolbar="tinymceToolbar" @watch="editHnadle($event)"></tiny-mce>
            <input type="text" style="display:none;" v-model="apiDesc"/>
          </div>
          <div style="height: 30px"></div>
          <!-- 保存  -->
          <div class=" file-edit-block file-fixed" >
            <div class="file-tab">
              <el-button type="primary" @click="saveBtn">保存</el-button>
            </div>
          </div>
        </div>
        <div style="clear:both;"></div>
 
        <!-- 批量添加参数 -->
        <el-dialog title="批量添加参数" :visible.sync="addBatchshow" width="24%" :close-on-click-modal="false">
          <div class="date-container">
            <div class="data-left m10">
              <el-input v-model="batchParam" placeholder="name:string" type="textarea"></el-input>
            </div>    
          </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="addBatchshow=false">取 消</el-button>
            <el-button type="primary" @click="addBatchConfirmBtn">确 定</el-button>
          </div>
        </el-dialog>
        <!-- json导入 -->
        <el-dialog title="JSON导入" :visible.sync="jsonShow" width="440px" :close-on-click-modal="false">
          <div class="date-container">
             <div id="jsoneditor" style="width:400px;height:400px;" v-if="jsonShow"></div>    
          </div>
          <div slot="footer" class="dialog-footer">
            <el-button @click="jsonShow=false">取 消</el-button>
            <el-button type="primary" @click="jsonConfirmBtn" v-if="jsonimport">确 定</el-button>
            <el-button type="primary" @click="jsonBodyConfirmBtn" v-if="!jsonimport">确 定</el-button>
          </div>
        </el-dialog>
  </div>
</template>
<script>
import fileMixin from "./fileMixin.js";
import JsonTree from "./fileJsonTree.vue";
import {mapState,mapMutations} from "vuex";
import TinyMce from 'components/tool/tinymce'
let GenerateSchema = require('generate-schema')
export default {
  name: "fileEdit",
  mixins: [fileMixin],
  data() {
    return {
      activeName2: 'view',
      interfaceList:{apiId:'',apiPath:'',apiTypeId:'',apiName:'',apiPath:'',apiStatus:'未完成',apiMethod:'POST',apiDesc:''},
      paramSet:'Query',
      showTag:false,
      setTagList:[],
      //header参数设置
      headerList:[{name:'',value:'',headerDesc:''}],
      requireList:[
        { key: 1, value: 1, label: "必需" },
        { key: 0, value: 0, label: "非必需" },
      ],
      //from选择类型
      fromTypeList:[
        { key: 'file', value: "file", label: "file" },
        { key: 'text', value: "text", label: "text" },
      ],
      //statusCode
      statusCodeList:[],
      //添加from参数
      fromList:[{name:"",type:"",required:" ",example:"",formDesc:""}],
      queryRequireList:[
        {name:'',required:'',example:'',queryDesc:''}
      ],
      //批量添加list
      jsonTreeData:[{fieldName:"root",type:"object",mock:{mock:""},description:'',properties:[]}],
      responseData:[{fieldName:"root",type:"object",mock:{mock:""},description:'',properties:[]}],
      jsonData:{},
      jsonflag:{},
      addBatchshow:false,
      jsonShow:false,
      batchParam:"",
      jsonTREEData:{},
      BatchQueryshow:false,
      BatchFormshow:false,
      count:0,//公共计数器
      jsonimport:true,//区分json导入
      apiDesc:'apidociseditor',//监听备注
      tinymcePlugins:'lists image table  wordcount  paste autoresize fullscreen',
      tinymceToolbar:'undo redo | bold italic forecolor backcolor bullist  numlist  lists  imageCustom  fullscreen table',
    };
  },
  props: {
    setId: {
      type: [Number, String],
      default: null
    },
  },
  watch: {
    detailInitData:function(newVal, oldVal){
      this.init();
    },
    apiDesc:function(newVal, oldVal){
      if(oldVal!=='apidociseditor'){
        if(newVal!==oldVal){
          this.editShowFun(true);
        }
      }

    },
  },
  computed:{
    ...mapState({
      detailInitData:state=>state.fe.detailInitData,
      interfaceUrlList:state=>state.fe.interfaceUrlList,
      headerRequireList:state=>state.fe.headerRequireList,
      apiId:state=>state.fe.apiId,
      apiTypeId:state=>state.fe.apiTypeId,
      statusList:state=>state.fe.statusList,
      sortListData:state=>state.fe.sortListData,
    }),
  },
  mounted() {
    this.init();
  },
  updated(){
    this.fileEdiGloal();
  },
  components: {
    TinyMce,JsonTree
  }, 
  methods: {
    ...mapMutations(['watchDataFun','watchDataObjFun','editShowFun']),

    querySearch(queryString, cb) {
      var restaurants = this.headerRequireList;
      var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
      // 调用 callback 返回建议列表的数据
      cb(results);
    },
    createFilter(queryString) {
      return (restaurant) => {
        return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
      };
    },

    //初始化数据
    init(){
      let apiId = this.getUrlParams().apiId;
      let data = this.detailInitData;
      if(!data){return false;}
      this.interfaceList = {apiId:data.apiId,apiName:data.apiName,reqBodyType:data.reqBodyType,apiPath:data.apiPath,apiMethod:data.apiMethod,apiTypeId:data.apiTypeId,apiStatus:data.apiStatus,apiDesc:data.apiDesc};
      this.queryRequireList = data.reqQueryBoList;
      this.headerList = data.reqHeadersBoList;
      this.fromList = data.reqBodyFormBoList;
      this.statusCodeList=data.statusCodeBoList;
      this.jsonTreeData[0].properties=[];
      if(data.reqBodyJson){
        this.jsonTreeData[0].properties=data.reqBodyJson.properties;
        this.jsonTreeData[0].type=data.reqBodyJson.type;
        this.jsonTreeData[0].description=data.reqBodyJson.description;
      }
      this.responseData[0].properties=[];
      if(data.resBody){
        this.responseData[0].properties=data.resBody.properties;
        this.responseData[0].type=data.resBody.type;
        this.responseData[0].description=data.resBody.description;
      }
      if (this.interfaceList.apiMethod =='GET'||this.interfaceList.apiMethod =='HEAD'||this.interfaceList.apiMethod =='OPTIONS'){
        this.paramSet='Query';
      }else {
        this.paramSet='Body';
      }
    },
    checkParamGroup(){
      if ((this.interfaceList.apiMethod =='GET'||this.interfaceList.apiMethod =='HEAD'||this.interfaceList.apiMethod =='OPTIONS')&&this.paramSet=='Body'){
        this.paramSet='Query';
      }
      if (!(this.interfaceList.apiMethod =='GET'||this.interfaceList.apiMethod =='HEAD'||this.interfaceList.apiMethod =='OPTIONS')&&this.paramSet!=='Body'){
        this.paramSet='Body';
      }
      this.checkEdit();
    },

    //tag显示
    showTagEvent(){
      this.showTag = true;
      this.taglList.push({ key: '2', value: "", label: "" })
    },
    //添加tag
    addTag(){
      this.taglList.push({ key: '2', value: "", label: "" })
    },
    //tag设置
    tagConfirmBtn(){
      this.showTag = false;
    },
    //删除tag
    tagDelete(data,index){

    },
    //body header query 切换
    paramSetClick(){

    },
    //添加Headers
    addHeadersBtn(){
      this.headerList.push({name:''.value,value:'',example:'',headerDesc:''})
    },
    //删除header
    headerDelete(data,index){
      this.headerList.splice(index,1)
    },

    //添加statusCode
    addStatusCodeBtn(){
      this.statusCodeList.push({code:''.value,codeExplain:''})
    },
    //删除statusCode
    statusCodeDelete(data,index){
      this.statusCodeList.splice(index,1)
    },
    //添加Query参数
    addQueryBtn(){
      this.count++;
      let obj = {name:'',required:1,example:'',queryDesc:''};
      this.queryRequireList.push(obj);
    },
    //删除query
    queryDelete(data,index){
      this.queryRequireList.splice(index,1)
    },
    //添加form
    addFormBtn(){
      this.count++;
      this.fromList.push({name:'field'+this.count,type:"text",required:1,example:"",formDesc:""})
    },
    //删除form
    formDelete(data,index){
      this.fromList.splice(index,1)
    },
    //Query批量
    addBatchQueryshow(){
      this.addBatchshow = true;
      this.BatchQueryshow = true;
    },
    //Form批量
    addBatchFormshow(){
      this.addBatchshow = true;
      this.BatchFormshow = true;
    },
    //添加批量参数
    addBatchConfirmBtn(){
      let arr = this.batchParam.split(/[(\r\n)\r\n]+/)
      let list = [];
      if(this.BatchFormshow){
        this.fromList = [];
        arr.forEach((item)=>{
          let arr = []
          arr = item.replace(/：/g,":").split(':');
          if(arr[0]!==""){
            list.push({name:arr[0],required:1,example:arr[1]||'',formDesc:'',type:""});
          }  
        }); 
        this.fromList.push(...list)
        this.BatchFormshow = false;
      };
      if(this.BatchQueryshow){
        this.queryRequireList = [];
        arr.forEach((item)=>{
          let arr = []
          arr =  item.replace(/：/g,":").split(':');
          if(arr[0]!==""){
            list.push({name:arr[0],required:1,example:arr[1]||'',queryDesc:''})
          }   
        });
        this.queryRequireList.push(...list)
        this.BatchQueryshow = false;
      };
      this.addBatchshow = false;
      this.batchParam = ""
    },
   
    //json导入btn
    addJsonBtn(){
      this.jsonimport = true;
      this.jsonShow = true;
      this.$nextTick(()=>{
        this.jsonflag = this.jsonSet({id:'jsoneditor',mode:'code'})
      }); 
    },
    addBodyJsonBtn(){
      this.jsonimport = false
      this.jsonShow = true;
      this.$nextTick(()=>{
        this.jsonflag = this.jsonSet({id:'jsoneditor',mode:'code'})
      }); 
    },
    //json导入
    jsonConfirmBtn(){
      this.jsonTreeData = this.jsonChange();
    },
     //json body导入
    jsonBodyConfirmBtn(){
      this.responseData = this.jsonChange();
    },
    //处理json body导入数据
    jsonChange(){
      if(this.jsonflag.get()){
        let obj = {}
        obj['root'] = this.jsonflag.get()
        let schema = GenerateSchema.json(obj)
        this.jsonTREEData.root = schema
        let data = this.jsonToTree(this.jsonTREEData.root.properties);
        this.jsonShow = false;
        return data;
      }
    },
    //备注
    editHnadle(data) {
      this.interfaceList.apiDesc = data;
      this.apiDesc = data;
    },
    // 保存
    saveBtn(){
      for (var i in this.interfaceList){
        if(i !=='apiStatus'&&i !=='apiDesc'){
          
          if(!this.interfaceList[i]){
            return false
          }
        }  
      }
      if(!this.interfaceList.apiName.replace(/\s+/g,"")){
        this.interfaceList.apiName = "";
        return false
      }
      if(!this.interfaceList.apiPath.startsWith('/')){
        this.$message({
          message: 'path第一位必需为 /, 只允许由 字母数字-/_:.! 组成',
          type: 'error'
        });
        return false
      }
      this.dataCheck(this.queryRequireList);
      this.dataCheck(this.headerList);
      this.dataCheck(this.fromList);
      this.dataStatusCode(this.statusCodeList);
      let obj = this.AllData()
      $http.post($http.api.apidoc.save_api_info,{...obj}).then(res =>{
        if (res.status==200){
          this.$message({
            message: '保存成功',
            type: 'success'
          });
          this.editShowFun(false);
          // this.editSaveFun(true);
          this.$emit('sortFun',true)
          this.watchDataObjFun({});
        }
      }).catch(e =>{
         
      })    
    },
    //校验列表
    dataCheck(arr){
      if(arr.length>0){
        arr.forEach((item,index)=>{
          if(!item['name']){
            arr.splice(index,1)
            this.dataCheck(arr)
          }
        });
      }
    },
    //校验statusCode
    dataStatusCode(arr){
      if(arr.length>0){
        arr.forEach((item,index)=>{
          if(!item['code']){
            arr.splice(index,1)
            this.dataStatusCode(arr)
          }
        });
      }
    },
    //未保存数据
    AllData(){
      let obj = {};
      obj = {...this.interfaceList,reqQueryBoList:this.dataChange(this.queryRequireList),
        reqHeadersBoList:this.dataChange(this.headerList),reqBodyFormBoList:this.dataChange(this.fromList),
        reqBodyJson:this.dataChange(this.jsonTreeData[0]),resBody:this.dataChange(this.responseData[0]),
        statusCodeBoList:this.statusCodeList
      }
      return obj;
    },
    //保存请求数据转换
    dataChange(data){
      // 声明cache变量，便于匹配是否有循环引用的情况
      let cache = [];
      let str = JSON.stringify(data, function(key, value) {
        if (typeof value === 'object' && value !== null) {
          if (cache.indexOf(value) !== -1) {
              // 移除
            return;
          }
            // 收集所有的值
          cache.push(value);
        }
        return value;
      });
      cache = null; 
      return JSON.parse(str);
      // return data;
    }, 
    //全局监听
    fileEdiGloal(){
      let obj = this.AllData();
      this.watchDataObjFun(obj);
    }
  }
};
</script>

<style lang="scss" scoped>

.file-box{
  ul{
    list-style: none;
    // margin: 0;
    padding: 0;
    // width: 70%;
    li{
      padding: 6px 0;
      margin: 3px 0;
    }
  }
}
.file-edit-block{
  background: #f3f4f6;
  
}
.file-border-warn{
  border: 1px solid red;
  border-radius: 3px;
  display: inline-block;
}
.file-box-pad{
    // padding: 0 9%;
    overflow: auto;
    background: #f3f4f6;
  }
.file-tab{
  text-align: center;
  height: 60px;
  z-index: 199;
  line-height: 60px;
  .el-button {
    margin-top: 10px;
  }
}
.file-btn-box{
  // width: 80%;
  .file-btn-font{
    color: #409EFF;
  }
}
.file-fixed{
  position: fixed;
  bottom: 0;
  width:calc(100% - 400px);
  /*margin-left: 20px;*/
}
.file-json-tree{
  margin: 10px 0;
  min-width: 1000px;
}
</style>
