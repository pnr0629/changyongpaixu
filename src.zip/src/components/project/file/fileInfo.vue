<template>
  <div  class="content-outer-box">
    <div >
      <div class="file-search">
        <el-input v-model="search" placeholder="请输文件名" class="fl mt5" style="width:20%"></el-input>
        <el-button type="primary" class="fl mt5 ml5" @click="searchBtn">搜索</el-button>
      </div>
      <!-- 分类编辑菜单 -->
      <div class="file-tab-box">
        <el-tabs v-model="docType" type="border-card" @tab-click="handleClick">
          <el-tab-pane label="上传的文档" name="doc">
            <div class="file-doc-box">
              <div class="file-doc-left">
                 <ul ref="docMenu" id="menu">
                  <li v-if="menuData.id!==0&&menuData.folderType==0&&authFunction('FUNC_COOP_DOCUMENT_FOLDER_CREATE', 3, getUrlParams().projectId)" @click="createFolder">创建文件夹</li>
                  <li v-if="menuData.folderType==0&&authFunction('FUNC_COOP_DOCUMENT_FOLDER_CREATE', 3, getUrlParams().projectId)" @click="creatChildFolder">创建子文件夹</li>
                  <li v-if="menuData.id!==0&&menuData.folderType==0&&authFunction('FUNC_COOP_DOCUMENT_FOLDER_UPDATE', 3, getUrlParams().projectId)" @click="editFolder">修改文件夹名</li>
                  <li v-if="menuData.id!==0&&menuData.folderType==0&&authFunction('FUNC_COOP_DOCUMENT_FOLDER_DELETE', 3, getUrlParams().projectId)" @click="deleteFolder">删除文件夹</li>
                </ul>
                <div class="file-doc-left-title">文件夹列表</div>
                <div class="file-doc-left-tree scrollbal-common">
                  <el-tree  style="background-color:#f1f1f1;" :data="folderTree" :props="defaultProps" ref="folderTree"
                  :highlight-current="true"
                            :draggable="true"
                            :allow-drag="decideNodeDrag"
                            :allow-drop="decideNodeDrop"
                            @node-drop="moveFolder"
                  :expand-on-click-node="false"
                  node-key="key"
                  default-expand-all
                   >
                    <div class="iconmorebox" slot-scope="scope" @click.stop="HandleNode(scope.data,scope.node,$event)">
                      <div style="display:inline-block;" @mouseenter="showTip(scope,$event)">
                        <span :class="scope.node.key===selectFolder.key?'c-blue':''" class="doc-max-width ellipsis" v-if="tipsShow">{{ scope.node.label }}</span>
                        <el-tooltip effect="dark" placement="top-start" :content="scope.node.label" v-if="!tipsShow">
                          <span :class="scope.node.key===selectFolder.key?'c-blue':''" class="doc-max-width ellipsis">{{ scope.node.label }}</span>
                        </el-tooltip>
                      </div>
                      
                      <div class="iconmore">
                          <i class="iconfont icon-operate" slot="reference" v-if="scope.data.folderType==0&&scope.data.id>=0" @click.stop="operaBtn(scope.data,$event)"/>
                      </div>
                    </div>
                  </el-tree>
                </div>
              </div>
              
              <div class="file-doc-right fr">
                <div class="file-doc-right-title m10">
                  <el-breadcrumb separator-class="el-icon-arrow-right" class="detail-breadcrumb" style="margin-top:9px;">
                    <el-breadcrumb-item v-show="breadcrumb.length != 0" v-for="(item,index) in breadcrumb" :key="index">
                      <template>
                        <a @click="goToFolder(item)" class="product-breadcrumb">{{item.name}}</a>
                      </template>
                    </el-breadcrumb-item>
                  </el-breadcrumb>
                  <el-upload
                    v-show="selectFolder.folderType==0&&(selectFolder.id>=0||selectFolder.id === -2)"
                    class="upload-demo fr"
                    :action="uploadUrl"
                    name="file"
                    style="display: inline-block;"
                    :data='{documentFolderId:selectFolder.id}'
                    :show-file-list="false"
                    :on-success="uploadDocSuccess"
                    :on-error="uploadDocError"
                    multiple>
                    <el-button v-show="authFunction('FUNC_COOP_DOCUMENT_UPLOAD', 3, getUrlParams().projectId)" class="cursor-pointer file-plus-hover" type="primary">上传</el-button>
                  </el-upload>
                    <div style="clear:both;"></div>
                </div>
                <div class="m10 file-doc-table">
                  <el-table :data="docList"  style="width: 100%;height: 100%;" border>
                    <el-table-column prop="origName" label="文件名"  show-overflow-tooltip>
                      <template slot-scope="scope">
                        <span v-if="scope.row.id!=renameDocId">{{scope.row.origName}}</span>
                        <el-input v-if="scope.row.id==renameDocId" v-model="renameName"
                                  @blur="editDocName(scope.row)" @change="editDocName(scope.row)" ref="rename"></el-input>
                      </template>
                    </el-table-column>
                    <el-table-column prop="size" label="大小(kb)" width="80"></el-table-column>
                    <el-table-column prop="createUser" label="上传人" show-overflow-tooltip width="150">
                      <template slot-scope="scope">
                        <span class="table-column-padding">{{scope.row.userName}}({{scope.row.createUser}})</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="createTime" label="上传时间" show-overflow-tooltip  width="200"></el-table-column>
                    <el-table-column prop="name" label="操作"  width="250">
                       <template slot-scope="scope">
                          <span class="file-text" @click="downloadDoc(scope.row)">下载</span>
                          <span class="file-text" v-show="authFunction('FUNC_COOP_DOCUMENT_RENAME', 3, getUrlParams().projectId)" @click="openEditDocName(scope.row)">重命名 </span>
                          <span class="file-text" v-show="authFunction('FUNC_COOP_DOCUMENT_DELETE', 3, getUrlParams().projectId)" @click="deleteDoc(scope.row)">删除</span>
                          <span class="file-text" v-show="authFunction('FUNC_COOP_DOCUMENT_MOVE', 3, getUrlParams().projectId)" @click="moveDoc(scope.row)">移动</span>
                        </template>
                    </el-table-column>
                  </el-table>
                  <el-pagination class="fr mr10" style="margin-top: 9px;"
                     @size-change="handleDocListSizeChange"
                     @current-change="handleDocListCurrentChange"
                     :current-page="pageInfo.pageNum"
                     :page-sizes="[15, 30, 50]"
                     :page-size="pageInfo.pageSize"
                     layout="total, sizes, prev, pager, next, jumper"
                     :page-count="pageInfo.pages"
                     :total="pageInfo.total"
                  >
                  </el-pagination>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="工作项附件文档" name="attachment">
            <file-work-item v-if="docType=='attachment'"></file-work-item>
          </el-tab-pane>
          <el-tab-pane label="接口文档" name="api">
            <file-creat v-if="docType=='api'" :keyWord="search"></file-creat>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <!-- 创建,修改文件弹窗 -->
    <el-dialog :title="operationTitle" :visible.sync="dialogVisible" width="400px">
      <span>文件夹名称:</span>
      <el-input v-model="folderName" placeholder="请输入文件夹名称" style="width:78%;"></el-input>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="saveFolder">确 定</el-button>
      </span>
    </el-dialog>
    <!-- 移动弹窗 -->
    <el-dialog title="移动至" :visible.sync="moveVisible" :before-close="colseMoveDialog" width="20%">
      <el-tree :data="moveData.moveTreeData"
               node-key="id"
               :default-checked-keys="moveData.defaultCheckedKeys"
               :default-expanded-keys="moveData.defaultCheckedKeys"
               ref="moveFolderTree"
               :props="defaultProps"
               show-checkbox
               :check-strictly="true"
               @check-change="checkChange"
      >
        <!--@node-click="handleNodeClick"-->
      </el-tree>
      <span slot="footer" class="dialog-footer">
        <el-button @click="colseMoveDialog">取 消</el-button>
        <el-button type="primary" @click="moveSuerBtn">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 文档首页
 * @desc 状态：展示、编辑
 * @author panhui
 * @date 2019-8-20
 */
import {mapState,mapMutations} from "vuex";
import fileCreat from "./fileCreat.vue";
import fileWorkItem from "./fileWorkItem.vue";

export default {
  name: "fileInfo",
  //mixins: [ProjectCommonMixin],
  data() {
    return {
      tipsShow:true,
      search:'',
      docType:'doc',
      projectId:0,
      selectFolder: {},
      folderName:'',
      operationTitle:'创建文件',
      renameDocId:0,
      renameName:'',
      breadcrumb:[],
      docTypeDes:{
        0:'上传文档',
        1:'附件',
        3:'接口文档'
      },
      menuData:{},
      dialogVisible:false,
      moveVisible:false,
      folderTree:[],
      defaultProps:{
        children: 'children',
        label: 'label',
      },
      docList:[],
      moveData:{},//选择移动时的公共数据
      pageInfo:{
        pageSize:15,
        pageNum:1,
        total:0,
        pages:0,
      },
      uploadUrl:''
    };
  },
  computed:{
    ...mapState({
      docSearchWord:state=>state.fe.docSearchWord,
    }),
  },
  watch: {

  },
  mounted() {
    this.projectId=this.getUrlParams().projectId;
    this.uploadUrl='/api/coop/document/upload?projectId='+this.projectId;
    this.docType=this.getUrlParams().docType?this.getUrlParams().docType:'doc';
    this.getInitFolderTree();
  },
  components: {
    fileCreat,fileWorkItem
  }, 
  methods: {
    ...mapMutations(['fileTypeKeysFun','changeDocSearchWord']),
  //文件分类tips显示
    showTip(scope,ev){
      if(ev.target.clientWidth>160){
        this.tipsShow = false
      }else{
        this.tipsShow = true
      }
    },
    decideNodeDrag(node){
      if (node.data.key>0 && node.data.folderType==0) {
        return true;
      }
      return false;
    },

    decideNodeDrop(draggingNode, dropNode, type){
      if (dropNode.data.key>=0 && dropNode.data.folderType==0 && type=='inner') {
        return true;
      }
      return false;
    },

    moveFolder(draggingNode, inNode, $event){
      $http.post($http.api.document.move,{id:draggingNode.data.id,parentId:inNode.data.id},{type:'form'}).then(res =>{
        if (res.status == 200){
          this.$message({
            type: 'success',
            message: '移动成功'
          });
          this.getFolderTree();
        }
      }).catch(e =>{

      })
    },

    goToFolder(item){
      this.selectFolder=item;
      this.getNodeAllParent(this.$refs.folderTree.getNode(item.key));
      // this.setCurrentNodeLight();
      this.getDocumentList();
    },

    setCurrentNodeLight(){
      // while (this.$refs.folderTree.getNode(this.selectFolder.key)==null){
      //
      // }
      this.$refs.folderTree.setCurrentKey(this.selectFolder.key);
    },

    handleDocListSizeChange(val){
      this.pageInfo.pageSize=val;
      this.getDocumentList();
    },

    handleDocListCurrentChange(val){
      this.pageInfo.pageNum=val;
      this.getDocumentList();
    },

    uploadDocSuccess(response){
      if (response.status==200){
        this.$message({
          type: 'success',
          message: '上传成功!'
        });
        this.getDocumentList();
        this.getFolderTree();
      }
    },

    uploadDocError(){

    },

    getInitFolderTree(){
      $http.get($http.api.document.folder_query,{projectId:this.projectId}).then(res =>{
        if (res.status==200){
          this.folderTree=res.data;
          this.selectFolder=res.data[0];
          let array=[];
          array.push(this.selectFolder);
          this.breadcrumb=array;
          // this.setCurrentNodeLight();
          this.getDocumentList();
        }
      }).catch(e =>{

      })
    },

    getFolderTree(){
      $http.get($http.api.document.folder_query,{projectId:this.projectId}).then(res =>{
        if (res.status==200){
          this.folderTree=res.data;
          // this.setCurrentNodeLight();
        }
      }).catch(e =>{

      })
    },

    //文件分类事件
    HandleNode(data,node,ev){
      // sessionStorage.setItem("fileTypeKeys", data.id);
      // if(['iconfont icon-operate'].indexOf(ev.target.className)!==-1){
      //   return false
      // }
      if (ev.toElement.className !== 'menu' && document.getElementById('menu')) {
        document.getElementById('menu').style.display = 'none';
      }
      this.search='';
      this.selectFolder=data;
      this.getNodeAllParent(node);
      this.getDocumentList();
    },

    getNodeAllParent(node){
      let temp = node;
      let array = [];
      while (temp) {
        if (temp.data.name) {
          array.push(temp.data)
        }
        temp = temp.parent;
      }
      this.breadcrumb = array.reverse();
    },

    getDocumentList(){
      $http.post($http.api.document.doc_query,{
        documentFolderId:this.selectFolder.id,
        keyWord:this.search,
        folderType:this.selectFolder.folderType,
        pageInfo: {pageNumber:this.pageInfo.pageNum,pageSize: this.pageInfo.pageSize}
      }).then(res =>{
        if (res.status==200){
          this.docList=res.data.result;
          if (res.data.result.length === 0){
            if (this.selectFolder.folderType === -1 && this.selectFolder.id !== -1) {
              this.getInitFolderTree()
            } else {
              this.getFolderTree();
            }
          }
          this.pageInfo.pageNum=res.data.pageInfo.pageNumber;
          this.pageInfo.pageSize=res.data.pageInfo.pageSize;
          this.pageInfo.pages=res.data.pageInfo.totalPages;
          this.pageInfo.total=res.data.pageInfo.totalRecords;
        }
      }).catch(e =>{

      })
    },


    getDocumentListForSearch(){
      $http.post($http.api.document.doc_query,{
        documentFolderId:this.selectFolder.id,
        keyWord:this.search,
        folderType:this.selectFolder.folderType,
        pageInfo: {pageNumber:this.pageInfo.pageNum,pageSize: this.pageInfo.pageSize}
      }).then(res =>{
        if (res.status==200){
          this.docList=res.data.result;
          this.pageInfo.pageNum=res.data.pageInfo.pageNumber;
          this.pageInfo.pageSize=res.data.pageInfo.pageSize;
          this.pageInfo.pages=res.data.pageInfo.totalPages;
          this.pageInfo.total=res.data.pageInfo.totalRecords;
        }
      }).catch(e =>{

      })
    },

    //分类更多选项
    operaBtn(data,ev){
      this.menuData = data;
      this.$refs.docMenu.style.display = 'block'
      // document.getElementById("docMenu").style.display = "block";
      this.$refs.docMenu.style.left = ev.pageX - 100 + "px";
      this.$refs.docMenu.style.top = ev.pageY - 200 + "px"
    },
    //创建文件夹
    createFolder(){
      this.dialogVisible = true;
      this.folderName = "";
      this.operationTitle = "创建文件夹"
    }, 
    //创建子文件夹
    creatChildFolder(){
      this.dialogVisible = true;
      this.folderName = "";
      this.operationTitle = "创建子文件夹"
    },
    //修改文件夹
    editFolder(){
      this.dialogVisible = true;
      this.operationTitle = "修改文件夹"
      this.folderName = this.menuData.name;
    },
    //删除文件夹
    deleteFolder(){
      this.$confirm('确认删除该文件夹及文件夹下的文档吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        $http.get($http.api.document.folder_delete,{id:this.menuData.id}).then(res =>{
          if (res.status==200){
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
            if (this.selectFolder.key===this.menuData.key){
              this.getInitFolderTree();
            }else {
              this.getFolderTree();
            }
          }
        }).catch(e =>{

        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });          
      });
    },
    //分类确定操作
    async saveFolder(){
      if(!this.folderName.trim()){
        this.$message({
          type: 'info',
          message: '输入内容为空'
        });
        return false
      }else if(this.operationTitle == "创建文件夹"){
        $http.post($http.api.document.folder_create,{projectId:this.projectId,parentId: this.menuData.parentId,name:this.folderName}).then(res =>{
          if (res.status==200){
            this.$message({
              type: 'success',
              message: '创建成功!'
            });
            this.dialogVisible = false;
            this.getFolderTree();
          }
        }).catch(e =>{

        })
      }else if(this.operationTitle == "创建子文件夹"){
        $http.post($http.api.document.folder_create,{projectId:this.projectId,parentId:this.menuData.id,name:this.folderName}).then(res =>{
          if (res.status==200) {
            this.$message({
              type: 'success',
              message: '创建成功!'
            });
            this.dialogVisible = false;
            this.getFolderTree();
          }
        }).catch(e =>{

        })
      }else if(this.operationTitle == "修改文件夹"){
        $http.post($http.api.document.folder_updateName,{id:this.menuData.id,name:this.folderName}).then(res =>{
          if (res.status==200) {
            this.$message({
              type: 'success',
              message: '修改成功!'
            });
            this.dialogVisible = false;
            this.getFolderTree();
          }
        }).catch(e =>{0

        })
      }
    },
    //tab切换
    handleClick(tab, event) {
      this.search='';
      this.$router.replace({ path: this.$route.path, query: { projectId:this.projectId, docType: this.docType } })
      if (this.docType === 'doc'){
        this.getInitFolderTree();
      }
    },
    //搜索确定
    searchBtn(){
      if (this.docType=='doc'){
        this.getDocumentListForSearch();
      } else {
        this.changeDocSearchWord(this.search);
      }
    },
    //下载
    downloadDoc(row){
      window.location.href=row.url+'?projectId='+this.getUrlParams().projectId+'&origName='+row.origName;
      // let {node,data} = this.menuData;
    },
    //重命名
    openEditDocName(row){
      this.renameDocId=row.id;
      this.renameName=row.name;
      this.$nextTick(() => {
        this.$refs.rename.focus();
        // ['text', 'progress'].includes(this.inputType) && this.$refs.editable.focus();
        // this.inputType === 'time' && this.$refs.globalDatepicker.focus();
      });
      // scope.row.show = true;
      // //外部添加列表属性键值时需要获取最新数据重新渲染列表
      // this.list = JSON.parse(JSON.stringify(this.list))
      // this.$nextTick(() => {this.$refs['colTxt'].focus()})
    },
    //确认重命名
    editDocName(row){
      if (this.renameName.trim() === '') {
        this.$message({
          type: 'warning',
          message: '文件名不能为空'
        });
        this.renameDocId=0;
        this.renameName='';
        return false;
      }
      if (this.renameName === row.name) {
        this.renameDocId=0;
        this.renameName='';
        return false;
      }
      if (this.renameDocId!==0){
        this.renameDocId=0;
        let name=this.renameName+row.format;
        this.renameName='';
        $http.post($http.api.document.rename,{id:row.id,name:name}).then(res =>{
          if (res.status==200){
            this.$message({
              type: 'success',
              message: '更新成功'
            })
            this.getDocumentList();
          }
        }).catch(e =>{

        })
      }
      // scope.row.show = false;
      // //外部添加列表属性键值时需要获取最新数据重新渲染列表
      // this.list = JSON.parse(JSON.stringify(this.list))
    },
    //删除
    deleteDoc(row){
      this.$confirm(`确定移除 ${row.origName}？`).then(() => {
        $http.get($http.api.document.doc_delete,{id:row.id}).then(res =>{
          if (res.status==200){
            this.$message({
              type: 'success',
              message: '删除成功'
            })
            this.getDocumentList();
            this.getFolderTree();
          }
        }).catch(e =>{

        })
      }).catch(_=>_)
    },
    //移动
    moveDoc(row){
      this.moveData.document = row
      this.moveData.moveTreeData=this.folderTree[0].children;
      let arr = [row.documentFolderId];
      this.moveData.defaultCheckedKeys=arr;
      this.moveVisible = true;
    },

    colseMoveDialog(){
      this.moveVisible = false;
      this.moveData={};
    },

    //移动tree事件
    handleNodeClick(data,checked,child){
      if(checked == true){
        this.moveData.checkedId = data.id;
        this.$refs.moveFolderTree.setCheckedNodes([data]);
      }
      // this.moveData.checkedKeys = [data.id]
      // if (checked===true){
      //   this.moveData.checkedId=data.id;
      //   this.$refs.moveFolderTree.setCheckedKeys([data.id]);
      //   this.moveData.checkedData=data;
      // } else {
      //   if (this.moveTreeData.checkedId===data.id){
      //     this.$refs.moveFolderTree.setCheckedKeys([data.id]);
      //   }
      // }
    },
    checkChange(data,checked,child){
      if (checked) {
        let arr = [data.id];
        this.moveData.checkedId=data.id;
        this.$refs.moveFolderTree.setCheckedKeys(arr);
      }
    },

    //确认移动
    moveSuerBtn(){
      this.moveVisible = false;
      $http.post($http.api.document.move_document,{id:this.moveData.document.id,folderId:this.moveData.checkedId},{type:"form"}).then(res =>{
        if (res.status===200){
          this.$message({
            type: 'success',
            message: '移动成功'
          })
          this.colseMoveDialog();
          if (this.selectFolder.folderType === 0){
            this.getFolderTree();
          }
          this.getDocumentList();
        }
      }).catch(e =>{

      })
    },
    //分页事件
    handleCurrentChange(val){

    }
  }
};
</script>

<style lang="scss" scoped>

  .file-search {
    height: 40px;
  }

#menu{
  display: none;
  list-style: none;
  border: 1px solid #f3f4f6;
  position: absolute;
  background: #fff;
  padding: 0;
  z-index: 9;
  li{
    cursor: pointer;
    padding: 3px 5px;
    &:hover{
      background: #409eff;
      color: #fff;
    }
  }
}
.doc-max-width{
  max-width: 170px;
  overflow: hidden;
  display: inline-block;
}
.lineshow{
  display: inline-block;
}
.file-doc-box{
  width: 100%;
  .file-doc-left{
    @extend .lineshow;
    height: 700px;
    background: #f1f1f1;
    width: 250px;
    border: 1px solid #f3f4f6;
    .file-doc-left-title{
      font-size: 16px;
      font-weight: 600;
      padding: 10px;
    }
    .file-doc-left-tree{
      height: 650px;
      overflow-x: hidden;
      overflow-y: auto;
    }
  }
  .file-doc-right{
    @extend .lineshow;
    min-height: 700px;
    width: calc(100% - 270px);
    border: 1px solid #f3f4f6;
    .file-doc-right-title {
      min-height: 28px;
      .detail-breadcrumb {
        float: left;
      }
    }

    .file-text{
      color:#409EFF;
      cursor:pointer;
      margin-right: 10px;
      display: inline-block;
    }
  }
}
</style>
