/**
 * @title 文档 mixin
 * @desc 文档公共方法
 * @time 2019.6.20
 * @author panhui
 */

const data = function () {
  return {}
}
const methods = {
 
// json-scheme转化为tree数据
  jsonToTree(jsonTreeData) {
    // let obj = [{ fieldName: "root", type: 'object', label: "root", required: '', description: '', mock: { mock: '' }, properties: [] }]
    // for (let x in jsonTreeData['root'].properties){
    //   let children=this.jsonPanda(x,jsonTreeData['root'].properties[x]);
    //   obj[0].properties.push(children);
    // }
    let obj = [];
    obj.push(this.jsonPanda('root', jsonTreeData['root']));
    return obj;

  },

  jsonPanda(field, data) {
    let obj = { fieldName: "", type: '', label: "", required: '', description: '', mock: { mock: '' }, properties: [] }
    obj.fieldName = field;
    obj.label = field;
    obj.type = data.type;
    obj.required = 0;
    obj.description = '';
    obj.mock.mock = '';
    obj.properties = [];
    if (field == 'items' && data.type == undefined) {
      obj.type = 'string';
    }
    if (data.type == 'array') {
      obj.properties.push(this.jsonPanda('items', data.items));
    } else if (data.type == 'object') {
      for (let x in data.properties) {
        obj.properties.push(this.jsonPanda(x, data.properties[x]));
      }
    } else {
      obj.required = 1;
    }
    return obj;

  },
  //jsontree转换为json格式
  dataJson(obj) {
    let objData = {}
    if(!obj){
      return false;
    }
    let data = obj.properties
    if (obj.type == "object" ||obj.type == "array") {
      if (data.length > 0) {
        objData = this.arrData(data)
      }
    }else {
      objData[obj.fieldName] = ""
      return objData;
    }
    return objData;
  },
  arrData(data,obr,par) {
    let daObj = {};
    for (let i = 0; i < data.length; i++) {
      if(obr == 'array'&&['object', 'array'].indexOf(data[i].type) == -1){
        return data[i].fieldName
      }else  if(data[i].type == "array"){
        if(obr == "array"){
          par.push(this.arrData(data[i].properties, data[i].type,daObj[data[i].fieldName]))
        }else{
          daObj[data[i].fieldName] = []
        }
        if (data[i].properties.length > 0) {
          daObj[data[i].fieldName].push(this.arrData(data[i].properties, data[i].type,daObj[data[i].fieldName])) 
        }
      }else{
        daObj[data[i].fieldName] = ""
      } 
      // if (data[i].type == 'array') {
      //   // daObj[data[i].fieldName] = []
      //   if (data[i].properties.length > 0) {
      //     daObj[data[i].fieldName].push(this.arrData(data[i].properties, data[i].type,daObj[data[i].fieldName])) 
      //   }
      // }
      if (data[i].type == 'object') {
        daObj[data[i].fieldName] = {}
        if (data[i].properties.length > 0) {
          for (var j in data[i].properties) {
            if (obr == 'array') { 
              daObj[data[i].properties[j].fieldName] = ""
              delete daObj[data[i].fieldName]
            } else {
              daObj[data[i].fieldName][data[i].properties[j].fieldName] = ""
            }
            if (data[i].properties[j].properties.length > 0) {
              if(data[i].properties[j].type== 'array'){
                daObj[data[i].fieldName][data[i].properties[j].fieldName] = []
                daObj[data[i].fieldName][data[i].properties[j].fieldName].push(this.arrData(data[i].properties[j].properties,9))
              }else{
                this.arrData(data[i].properties[j].properties,data[i].properties[j].type)
              }
              // console.log(data[i].properties[j].properties,data[i].properties[j].type)
              
            }
          }
        }
      }
    }
    return daObj
  },
//返回数据校验
  checkData(obj,res){
    let data = obj.properties,dataObj = {},arr = [],resObj = {};
    if(JSON.stringify(data)=='[]'){
      return resObj
    }
    function list(data,parent){
      for(let i = 0; i < data.length; i++){
        // let dataObj = {}
        // dataObj['name'] = data[i].fieldName
        // dataObj['type'] = data[i].type
        // dataObj["required"] = data[i].required
        
        if(parent){
          dataObj[data[i].fieldName] = data[i].type+'-'+parent
        }else{
          dataObj[data[i].fieldName] = data[i].type+'-1'
     
        }
        // arr.push(dataObj)
        if(data[i].properties.length>0){
          
          list(data[i].properties,data[i].fieldName)
        }
        // console.log('arr',dataObj)
      } 
    }
    list(data,'')
    if(!res){
      return false;
    }
    
    if(this.typeof(res) == 'object'){
      for(let x in res){
        let str = dataObj[x].split('-')
        if(str[0] !== this.typeof(res[x])){
          resObj = {type:str[0],name:x}
          return resObj
        }else{
          resObj = {}
        }
        
      }
    }

  },
  //检测数据类型
  typeof(obj){
    let data = Object.prototype.toString.call(obj).replace('[object', "").replace(']', "").trim().toLowerCase();
    return data
  },

  //api文档json设置
  jsonSet(obj) {//id,mode,data
    let container = document.getElementById(obj.id);
    let options = {
      mode: obj.mode,
      // modes: ['code', 'form', 'text', 'tree', 'view'], // allowed modes
      mainMenuBar: false
    };
    let editor = new this.$jsoneditor(container, options,obj.data);
    return editor;
  },
  //检测是否已编辑
  checkEdit() {
    this.editShowFun(true);
  },
}
export default {
  data,
  methods
}
