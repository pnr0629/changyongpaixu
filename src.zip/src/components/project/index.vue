<template>
  <div class="x-arD content-box">
    <div class="function-bar">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ name:'requirementList', query:{projectId: this.$route.query.projectId} }">
          <span class="h3-inline" id="h3-inlineName">{{projectName}}</span>
        </el-breadcrumb-item>
        <el-breadcrumb-item>{{menuName}}</el-breadcrumb-item>
      </el-breadcrumb>
    </div>
    <div class="white-box table-outer-box">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
  export default {
    name: "project",
    data() {
      return {
        menuList: [],
        sideBarDefaultActive: '',
        // projectName: '',
        menuName: '',
      }
    },

    watch: {
      '$route'(to, from) {
        this.renderMenuName()
      }
    },
    computed: {
      projectName() {
        return this.$store.state.projectName
      }
    },

    async mounted() {
      this.renderMenuName();

      //每次界面刷新，启动同步代码获取
      await $http.get($http.api.project.info, { id: this.$route.query.projectId }).then(res => {
        // this.projectName = res.data.name;
        this.$store.dispatch('modifyProjectName', {projectName: res.data.name})
        // console.log(this.projectName)
      }).catch(e => {
        console.error("获取项目名称失败, projectId:" + this.$route.query.projectId)
      });
    },

    methods: {
      renderMenuName() {
        //暂时先写死
        let currentRoute = this.$route;
        switch (currentRoute.name) {
          case 'requirementList':
            this.menuName = "需求列表";
            break;
          case 'taskView':
            this.menuName = "任务列表";
            break;
          case 'sprintList':
            this.menuName = "迭代列表";
            break;
          case 'sprintDetail':
            this.menuName = "迭代详情";
            break;
          case 'sprintPlan':
            this.menuName = "规划迭代";
            break;
          case 'requirementView':
            this.menuName = "需求详情";
            break;
          case 'taskEdit':
            this.menuName = "任务详情";
            break;
          case 'personalManagementList':
            this.menuName = '设置';
            break;
          case 'bugList':
            this.menuName = '缺陷详情';
            break;
          case 'bugChart':
            this.menuName = '报表统计';
            break;
          case 'fileInfo':
            this.menuName = '文档';
            break;  
          case 'fileList':
            this.menuName = '文档详情';
            break;
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .el-menu--horizontal {
    border-bottom: none !important;
  }

  .el-menu-demo {
    float: left;
    height: 40px !important;
    border: none;

    .el-menu-item {
      height: 48px !important;
      border-bottom: 1px !important;
      line-height: 50px;
    }
  }

  .el-breadcrumb {
    // margin-top: 20px;
    // margin-left: 5px;
    // float: left;
    height: 48px;
    overflow: hidden;
    box-sizing: border-box;
    .el-breadcrumb__item {
      line-height: 48px;
      height: 48px;
      &:last-child {
        position: relative;
        top: 2px;
      }
    }
  }
</style>