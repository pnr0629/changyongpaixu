<template>
  <div v-loading="loading" element-loading-text=" "
      element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
    <div class="header-btn"><el-button type="primary" v-show="authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_CREATE', 3, projectId)" @click="addField">增加自定义字段</el-button></div>
    <el-table :data="customFieldList" style="width: 100%">
      <el-table-column prop="fieldName" label="字段名" min-width="180" show-overflow-tooltip></el-table-column>
      <el-table-column prop="attrText" label="字段类型" width="100" show-overflow-tooltip></el-table-column>
      <el-table-column label="默认值" width="180" show-overflow-tooltip>
        <template slot-scope="scope">
          <span v-if="!['MULTI_CHOICE'].includes(scope.row.attrValue)">{{(scope.row.presetValue && scope.row.presetValue.value) || ( scope.row.presetValue && scope.row.presetValue.key)}}</span>
          <span v-else>{{(scope.row.presetValue && scope.row.presetValue.value)}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="enabled" label="是否启用" width="80" show-overflow-tooltip>
        <template slot-scope="scope">
          <span>{{scope.row.enabled?'是':'否'}}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150">
        <template slot-scope="scope">
          <span class="operatebtn link-common" v-show="fieldEditable" @click="editField(scope.row)">编辑</span>
          <span class="operatebtn link-common" v-show="fieldDeletable" @click="deleteField(scope.row)">删除</span>
          <span class="operatebtn link-common" v-show="fieldEnable" @click="disableField(scope.row)">{{scope.row.enabled ? '禁用' : '启用'}}</span>
        </template>
      </el-table-column>
    </el-table>
    <custom-field-dialog :dialogMoudleShowStatus="dialogMoudleShowStatus" :dialogMoudleOperateStatus="dialogMoudleOperateStatus" :dialogInfo="dialogInfo"
     @cancel="closeDialog" @success="operateCallback" @updateField="updateFieldInfo" :projectId="projectId" :workItemType="workItemType"></custom-field-dialog>
  </div>
</template>
<script>
/**
 * @title 自定义字段
 * @desc 
 * @author heyunjiang
 * @date 2019.8.23
 */
import CustomFieldDialog from './CustomFieldDialog'

export default {
  name: "CustomField",
  components: {
    CustomFieldDialog
  },
  mixins: [],
  props: {
    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型'
    },
    projectId: [String, Number]
  },
  data() {
    return {
      dialogLoading: false, // 是否在添加/更新
      loading: false,
      dialogMoudleShowStatus: false, // 模态框是否打开
      dialogMoudleOperateStatus: 'add', // 新增 or update
      dialogInfo: {}, // 字段数据信息
    }
  },
  computed: {
    customFieldList() {
      const state = this.$store.state;
      return state.pf.CUSTOMFIELDSELECTVALUES[state.pf.workItemTypeMap[this.workItemType]].map(item => {
        let presetValue = '';
        try {
          presetValue = JSON.parse(item.presetValue);
        } catch (_) {}
        return {
          ...item,
          presetValue
        }
      });
    },
    fieldEditable() {
      return this.authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_CREATE', 3, this.projectId);
    },
    fieldDeletable() {
      return this.authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_DELETE', 3, this.projectId);
    },
    fieldEnable() {
      return this.authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_UPDATE', 3, this.projectId);
    }
  },
  watch: {},
  mounted() {},
  methods: {
    // 获取自定义字段列表
    getCustomFieldList() {
      this.$store.dispatch({
        type: 'getCustomField',
        payload: { 
          workItemType: this.workItemType,
          projectId: this.projectId 
        }
      });
    },
    // 点击 - 编辑字段
    editField(info) {
      this.dialogMoudleShowStatus = true;
      this.dialogMoudleOperateStatus = 'update';
      this.dialogInfo = { ...info };
    },
    // 点击 - 删除字段
    async deleteField(info) {
      const confirmResult = await this.confirmBeforeOperate(`确认删除字段"${info.fieldName}"吗？`);
      if(!confirmResult) { return false; }
      let result = {};
      this.loading = true;
      try {
        result = await $http.get($http.api.CustomField.custom_field_delete, {
          id: info.id,
          projectId: this.projectId
        });
      } catch(_) {
        result.status = 0;
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({type: 'success', message: result.msg || '删除成功'});
      } else {
        this.$message({type: 'error', message: result.msg || '删除失败'});
      }
      this.getCustomFieldList();
    },
    // 点击 - 禁用/启用字段
    async disableField(info) {
      const name = info.enabled ? '禁用' : '启用';
      const confirmResult = await this.confirmBeforeOperate(`确认${name}字段"${info.fieldName}"吗？`);
      if(!confirmResult) { return false; }
      this.updateFieldInfo({
        ...info,
        presetValue: JSON.stringify(info.presetValue),
        enabled: !info.enabled
      })
    },
    // 点击 - 新增字段
    addField() {
      this.dialogMoudleShowStatus = true;
      this.dialogMoudleOperateStatus = 'add';
      this.dialogInfo = {};
    },
    // 更新字段 - 禁用/启用，名称修改，默认值修改
    async updateFieldInfo(info) {
      let result = {};
      this.loading = true;
      try {
        result = await $http.post($http.api.CustomField.custom_field_update, {
          id: info.id,
          enabled: info.enabled,
          fieldName: info.fieldName,
          presetValue: info.presetValue,
          projectId: this.projectId
        });
      } catch(_) {
        result.status = 0;
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({type: 'success', message: result.msg || '更新成功'});
      } else {
        this.$message({type: 'error', message: result.msg || '更新失败'});
      }
      this.getCustomFieldList();
      info.cb && info.cb();
    },
    // 关闭 dialog
    closeDialog() {
      this.dialogMoudleShowStatus = false;
    },
    // 新增成功回调函数
    operateCallback() {
      this.closeDialog();
      this.getCustomFieldList();
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '../../../../base/style/common.scss';
  .header-btn {
    margin-bottom: 10px;
  }
</style>
