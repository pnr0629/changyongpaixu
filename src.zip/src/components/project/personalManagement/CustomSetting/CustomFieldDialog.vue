<template>
  <div class="custom-dialog" v-loading="loading" element-loading-text=" "
      element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
    <el-dialog
      :title="dialogName"
      :visible.sync="dialogMoudleShowStatus"
      :modal-append-to-body="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      :show-close="false"
      width="600px"
    >
      <div class="form-iterm-box" v-if="dialogMoudleShowStatus">
        <el-form :model="formInfo" label-width="80px">
          <el-form-item label="字段名称" prop="fieldName" :rules="[{ required: true, message: '字段名称不能为空' }]">
            <el-input v-model="formInfo.fieldName"></el-input>
          </el-form-item>
          <el-form-item label="字段类型" prop="attrType" :rules="[{ required: true }]">
            <el-select v-model="formInfo.attrType" @change="fieldTypeChange" :disabled="dialogMoudleOperateStatus !== 'add'">
              <el-option v-for="item in attrTypeList" :key="item.attrType" :value="item.attrType" :label="item.attrText"></el-option>
            </el-select>
            <div class="select-box" v-show="[10, 11].includes(formInfo.attrType)">
              <div>
                <span class="link-common select-box-btnitem" v-show="fieldAddable" @click="addSelectOption">增加字段选项</span>
                <!-- <span class="link-common select-box-btnitem" @click="deleteSelectOptionAll">删除字段全部选项</span> -->
              </div>
              <div class="select-box-option-item-box">
                <div class="select-box-option-item" v-for="item in selectOptionList" :key="item.key">
                  <el-input class="select-box-option-item-input" @change="addSelectOptionChange" :disabled="!item.isNew" v-model="item.value"></el-input>
                  <span class="select-box-option-item-delete cursor-pointer" v-show="fieldDeletable" @click="deleteSelectOption(item)"><i class="el-icon-delete"></i></span>
                </div>
              </div>
            </div>
          </el-form-item>
          <el-form-item label="默认值">
            <typed-form-item :type="defaultInputAttrValue" v-model="formInfo.presetValue" :selectList="selectOptionList"></typed-form-item>
            <span class="link-common" @click="resetPresetValue">清空默认值</span>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose">取 消</el-button>
        <el-button type="primary" @click="handleSubmit" v-show="authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_CREATE', 3, projectId)">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 自定义字段 add/update dialog
 * @desc 
 * @author heyunjiang
 * @date 2019.8.27
 */
const dialogInfoInit = {
  attrType: 1,
  attrValue: 'SINGLE_TEXT',
  fieldName: '',
  presetValue: '',
  choices: []
}

export default {
  name: "CustomFieldDialog",
  components: {},
  mixins: [],
  props: {
    dialogMoudleShowStatus: Boolean,
    dialogMoudleOperateStatus: String,
    dialogInfo: Object,
    projectId: [String, Number],
    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型'
    },
  },
  data() {
    return {
      disalogStatus: false,
      formInfo: { ...dialogInfoInit },
      attrTypeList: [], // 字段可选类型列表
      selectOptionList: [], // 字段类型为单选、多选时的选项值
      selectOptionIndex: 0, // 字段选项值 key
      loading: false,
      memberList: [], // 人员列表
    }
  },
  computed: {
    dialogName() {
      return this.dialogMoudleOperateStatus === 'add' ? '新增字段' : '更新字段';
    },
    // 当前字段类型 attrValue
    defaultInputAttrValue() {
      const item = this.attrTypeList.find(item => item.attrType === this.formInfo.attrType);
      return (item&&item.attrValue) || 'SINGLE_TEXT';
    },
    fieldAddable() {
      return this.authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_CHOICE_CREATE', 3, this.projectId);
    },
    fieldDeletable() {
      return this.authFunction('FUNC_COOP_PROJECT_USER_DEFINED_ATTR_CHOICE_DELETE', 3, this.projectId);
    },
  },
  watch: {
    dialogInfo() {
      this.formInfoReset();
    },
    dialogMoudleShowStatus() {
      this.disalogStatus = this.dialogMoudleShowStatus;
    }
  },
  mounted() {
    this.formInfoReset();
    this.getAttrTypeList();
  },
  methods: {
    // form 表单重置
    formInfoReset() {
      const obj = {
        ...dialogInfoInit,
        ...this.dialogInfo,
      };
      obj.presetValue = obj.presetValue ? obj.presetValue.key : this.$store.state.cm.customFieldInitTypeMap[obj.attrValue];
      this.formInfo = obj;
      this.selectOptionList = [];
      this.selectOptionIndex = 0;
      // 如果当前字段为 更新 + select，则获取字段可选择字段的 list
      if(['SINGLE_CHOICE', 'MULTI_CHOICE'].includes(this.dialogInfo.attrValue)) {
        this.getSelectOptionList();
      }
      // 如果当前字段为 更新 + 人员列表
      this.getAssignUsersList();
    },
    // 获取可选择字段类型列表
    async getAttrTypeList() {
      if(this.attrTypeList.length > 0) {return ;}
      let result = {};
      try {
        result = await $http.get($http.api.CustomField.custom_field_types);
      } catch(_) {
        result.status = 0;
      }
      if(result.status === 200) {
        this.attrTypeList = result.data;
      }
    },
    // 获取字段可选择值列表列表
    async getSelectOptionList(attrName) {
      let result = {};
      this.loading = true;
      try {
        result = await $http.get($http.api.CustomField.custom_field_choices, {
          projectId: this.projectId,
          workItemType: this.workItemType,
          attrName: attrName || this.dialogInfo.attrName
        });
      } catch(_) {
        result.status = 0;
      }
      this.loading = false;
      if(result.status === 200) {
        this.selectOptionList = result.data.map(item => {
          return {
            ...item,
            key: item.choice,
            value: item.value,
            isNew: false
          }
        });
        const length = this.selectOptionList.length;
        this.selectOptionIndex = length;
      }
    },
    // 删除全部选项
    async deleteSelectOptionAll() {
      if(this.dialogMoudleOperateStatus === 'add') {
        this.selectOptionList = [];
      } else {
        // 发起请求删除
        const confirmResult = await this.confirmBeforeOperate(`确认删除全部字段值吗？`);
        if(!confirmResult) { return false; }
        this.deleteFieldOption({all: true});
      }
    },
    // 删除选项
    async deleteSelectOption(info) {
      if(info.isNew) {
        this.selectOptionList = this.selectOptionList.filter(item => item.key !== info.key);
      } else {
        // 发起请求删除
        const confirmResult = await this.confirmBeforeOperate(`确认删除字段值"${info.value}"吗？`);
        if(!confirmResult) { return false; }
        this.deleteFieldOption({id: info.id});
      }
    },
    // 删除选项 - 更新时才能调用这个接口，新建时不允许调用
    async deleteFieldOption(obj) {
      let result = {};
      this.loading = true;
      try {
        result = await $http.get($http.api.CustomField.custom_field_choices_delete, {
          projectId: this.projectId,
          workItemType: this.workItemType,
          ...obj
        });
      } catch(_) {
        result.status = 0;
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({type: 'success', message: result.msg || '删除字段值成功'});
      } else {
        this.$message({type: 'error', message: result.msg || '删除字段值失败'});
      }
      this.getSelectOptionList();
    },
    // 新增时，字段类型切换
    fieldTypeChange() {
      if([10, 11].includes(this.formInfo.attrType)) {
        this.selectOptionList = [{
          key: this.selectOptionIndex,
          value: '',
          isNew: true
        }];
      }
      if(this.defaultInputAttrValue === 'MEMBER_CHOICE') {
        this.selectOptionList = this.memberList;
      }
      this.formInfo.presetValue = this.$store.state.cm.customFieldInitTypeMap[this.defaultInputAttrValue];
    },
    // 重置默认值
    resetPresetValue() {
      this.formInfo.presetValue = this.$store.state.cm.customFieldInitTypeMap[this.defaultInputAttrValue];
    },
    // 点击 - 增加字段选项
    addSelectOption() {
      if(this.dialogMoudleOperateStatus === 'update' && this.selectOptionList.find(item => item.isNew)) {
        this.$message({
          type: 'warning',
          message: '已经增加了一个字段选项，请先填写'
        })
        return ;
      }
      this.selectOptionIndex++;
      this.selectOptionList = [...this.selectOptionList, {
        key: this.selectOptionIndex,
        value: '',
        isNew: true
      }];
    },
    // 增加字段选项 - 更新时，发起请求增加可选字段
    async addSelectOptionChange(value) {
      if(this.dialogMoudleOperateStatus === 'add' || value.length < 1) {return ;}
      let result = {};
      this.loading = true;
      try {
        result = await $http.post($http.api.CustomField.custom_field_choices_add, {
          projectId: this.projectId,
          workItemType: this.workItemType,
          attrName: this.formInfo.attrName,
          choice: value
        });
      } catch(_) {
        result.status = 0;
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({type: 'success', message: result.msg || '新增字段值成功'});
      } else {
        this.$message({type: 'error', message: result.msg || '新增字段值失败'});
      }
      this.getSelectOptionList();
    },
    // dialog - 点击取消
    handleClose() {
      this.$emit('cancel');
      this.formInfoReset();
    },
    // dialog - 点击确定 - 新增/更新字段
    handleSubmit() {
      if(this.dialogMoudleOperateStatus === 'add') {
        this.addFiled();
      } else {
        const StringifyPresetValue = JSON.stringify({
          "key": this.formInfo.presetValue,
          "value": this.generateDefaultValueString()
        })
        this.$emit('updateField', {
          ...this.formInfo,
          presetValue: StringifyPresetValue,
          cb: () => {
            this.formInfoReset();
            this.$emit('cancel');
          }
        });
      }
    },
    // 新增字段
    async addFiled() {
      if(this.formInfo.fieldName.length < 1) {
        this.$message({type: 'warning', message: '字段名称不能为空'});
        return ;
      }
      if(this.selectOptionList.filter(item => item.value.length > 0).length < 1 && ['SINGLE_CHOICE', 'MULTI_CHOICE'].includes(this.defaultInputAttrValue)) {
        this.$message({type: 'warning', message: '多选/单选可选值数量至少 > 1'});
        return ;
      }
      const StringifyPresetValue = JSON.stringify({
        "key": this.formInfo.presetValue, // 如果是多选、单选，则新建时保存的是临时的 key ,需要在后续做个转换，转换成服务器提供的key
        "value": this.generateDefaultValueString()
      })
      let result = {};
      this.loading = true;
      try {
        result = await $http.post($http.api.CustomField.custom_field_create, {
          ...this.formInfo,
          presetValue: StringifyPresetValue,
          attrValue: this.defaultInputAttrValue,
          choices: this.selectOptionList.filter(item => item.value.length > 0).map(item => item.value),
          projectId: this.projectId,
          enabled: true,
          workItemType: this.workItemType
        });
      } catch(_) {
        result.status = 0;
      }
      if(result.status === 200) {
        // 更新默认值数据
        if(['SINGLE_CHOICE', 'MULTI_CHOICE'].includes(this.formInfo.attrValue)) {
          await this.replacePresetValue(StringifyPresetValue, result.data);
        }
        this.$message({type: 'success', message: result.msg || '新增成功'});
        this.formInfoReset();
        this.$emit('success');
      } else {
        this.$message({type: 'error', message: result.msg || '新增失败'});
      }
      this.loading = false;
    },
    // 生成默认值字符串
    generateDefaultValueString() {
      let presetValueName = '';
      switch(this.defaultInputAttrValue) {
        case 'MEMBER_CHOICE' :
        case 'SINGLE_CHOICE' : try {
          presetValueName = this.selectOptionList.find(item => item.key === this.formInfo.presetValue).value;
        } catch (_) {};break;
        case 'MULTI_CHOICE' :  presetValueName = [];
          this.selectOptionList.forEach(item => {
            if(this.formInfo.presetValue.includes(item.key)) {
              presetValueName.push(item.value)
            }
          })
          presetValueName = presetValueName.join(',');
          break;
        case 'BOOLEAN_ATTR' : switch(this.formInfo.presetValue) {
          case true: presetValueName = '是';break;
          case false: presetValueName = '否';break;
          default: presetValueName = '';
        };break;
        default: presetValueName = this.formInfo.presetValue;
      }
      return presetValueName;
    },
    // 获取人员列表
    async getAssignUsersList(field) {
      // 减少发起的请求，增加效率
      if(this.memberList.length > 0) {
        this.selectOptionList = this.memberList;
        return ;
      }
      const result = await $http.post($http.api.bug_info.assignUsersList, {
        projectId: this.projectId,
        query: ''
      });
      if (result.status && result.status === 200) {
        const list = result.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName  + "(" + item.userId + ")"
          }
        })
        this.memberList = list;
        this.selectOptionList = list;
      }
    },
    // 新建成功之后：多选、单选 对应的 presetValue 更新
    async replacePresetValue(StringifyPresetValue, successInfo) {
      await this.getSelectOptionList(successInfo.attrName);
      const presetValue = JSON.parse(StringifyPresetValue);
      const updateObj = {...presetValue};
      // 如果是单选
      if(this.formInfo.attrValue === 'SINGLE_CHOICE') {
        this.selectOptionList.forEach(item => {
          if(item.value === presetValue.value) {
            updateObj.key = item.key
          }
        })
      }
      // 如果是多选
      if(this.formInfo.attrValue === 'MULTI_CHOICE') {
        updateObj.key = [];
        this.selectOptionList.forEach(item => {
          if(presetValue.value.includes(item.value)) {
            updateObj.key.push(item.key)
          }
        })
      }
      // 发起请求更新默认值
      const result = await $http.post($http.api.CustomField.custom_field_update, {
        ...successInfo,
        presetValue: JSON.stringify(updateObj)
      });
      return result;
    }
  }
}
</script>
<style lang="scss" scoped>
  .custom-dialog {
    z-index: 3;
  }
  .select-box {
    .select-box-btnitem {
      margin-right: 10px;
    }
    .select-box-option-item-box {
      display: flex;
      flex-flow: row wrap;
      justify-content: space-between;
      .select-box-option-item {
        .select-box-option-item-input {
          width: 200px;
        }
        .select-box-option-item-delete {
          padding: 0 5px;
          &:hover {
            color: #409EFF;
          }
        }
      }
    }
  }
</style>
