<template>
  <div>
    <div class="custom-box">
      <div class="custom-left">
        <div
          class="custom-item"
          @click="customChoose(item.type)"
          v-for="item in items"
          :key="item.type"
          :style="{background: currentItem === item.type ? 'yellowgreen' : ''} "
        >{{item.label}}</div>
      </div>
      <div class="custom-right">
        <div class="custom-right-title">描述信息</div>
        <div class="custom-right-template">
          <span
            class="save-template"
            v-show="authFunction('FUNC_COOP_TMPL_DESC_UPDATE', 3, projectId)"
            @click="updateDescTmpl"
          >保存</span>
          <tiny-mce :value="template" @watch="editHnadle($event)"></tiny-mce>
        </div>
        <div class="custom-right-title">字段配置</div>
        <div class="custom-right-customfield">
          <custom-field :workItemType="currentItem" :projectId="projectId"></custom-field>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
/**
 * @title 自定义模板模块
 * @desc 入口文件
 * @author heyunjiang
 * @date 2019.8.23
 */
import TinyMce from 'components/tool/tinymce';
import CustomField from './CustomField'

export default {
  name: "CustomSetting",
  components: {
    TinyMce,
    CustomField
  },
  mixins: [],
  props: {},
  data() {
    return {
      items: [
        { label: '需求', type: 1 },
        { label: '任务', type: 2 },
        { label: '缺陷', type: 3 },
      ],
      currentItem: 1,//自定义模板区别需求，缺陷，任务
      template: '',//模板内容
      projectId: this.getUrlParams().projectId,
    }
  },
  computed: {},
  watch: {},
  mounted() {
    this.queryDescTmpl();
  },
  methods: {
    // 编辑器事件 handler
    editHnadle(data) {
      this.template = data;
    },
    //自定义模板选项切换
    customChoose(item) {
      this.currentItem = item;
      this.queryDescTmpl();
    },
    //获取自定义模板内容
    async queryDescTmpl() {
      const result = await this.$store.dispatch({
        type: 'getCustomField',
        payload: { workItemType: this.currentItem }
      });
      if(result.status === 200) {
        this.template = result.data.template;
      }
    },
    //更新自定义模板
    updateDescTmpl() {
      $http.post($http.api.work_status_fow.descTmpl_update, { projectId: this.projectId, workItemType: this.currentItem, template: this.template }).then((res) => {
        if (res.status === 200) {
          this.$message({ type: 'success', message: '修改成功' })
        }
      })
    },
  }
}
</script>
<style lang="scss" scoped>
.custom-box {
  .custom-left {
    float: left;
    width: 20%;
    margin-top: 10px;
    .custom-item {
      width: 100%;
      height: 40px;
      line-height: 40px;
      cursor: pointer;
      text-align: center;
      background-color: lightslategray;
      margin-top: 10px;
      color: whitesmoke;
      &:hover {
        background-color: yellowgreen;
      }
      &:first-child {
        margin-top: 0;
      }
    }
  }

  .custom-right {
    width: 76%;
    float: right;
    position: relative;
    .custom-right-title {
      height: 30px;
      line-height: 30px;
      font-size: 16px;
      border-bottom: 1px solid #efefef;
      margin: 5px 0;
    }
    // 模板
    .custom-right-template {
      position: relative;
      .save-template {
        position: absolute;
        padding: 2px 4px;
        right: 12px;
        top: 9px;
        z-index: 2;
        border: 1px solid #dde5ef;
        cursor: pointer;
        box-sizing: border-box;
        &:hover {
          background-color: #ebf2f9;
        }
      }
    }
    // 自定义字段
    .custom-right-customfield {
      margin-top: 10px;
    }
  }
}
</style>
