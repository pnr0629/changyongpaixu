<template>
  <div class="tab-minheight">
    <span class="setting-tab-header">缺陷自定义字段配置管理</span>
    <div class="checkbox-content">
      <el-checkbox class="checkbox-item" v-for="item in dataList" :label="item.label" :key="item.key" v-model="item.isChecked" 
        :disabled="!isEditable">{{item.label}}</el-checkbox>
    </div>
    <div class="checkbox-footer" v-if="authFunction('FUNC_COOP_PROJ_MANG_BIZ_ASSOC', 3, projectId)">
      <el-button-group>
        <el-button class="checkbox-button" type="primary" @click="controllBtnClick" v-show="!isEditable">编辑</el-button>
        <el-button class="checkbox-button" type="primary" @click="okBtnClick" v-show="isEditable">保存</el-button>
        <el-button class="checkbox-button" type="primary" @click="cancelBtnClick" v-show="isEditable">取消</el-button>
      </el-button-group>
    </div>
  </div>
</template>
<script>
/**
 * @title 缺陷自定义字段配置管理 - 已废弃
 * @desc 缺陷自定义字段配置管理
 * @author heyunjiang
 * @date 2019.4.24
 */

import BugCustomFieldsMixin from '../bugManagement/BugCustomFieldsMixin'

export default {
  name: "CustomFieldManagement",
  components: {},
  mixins: [BugCustomFieldsMixin],
  props: {},
  data() {
    return {
      projectId: this.getUrlParams().projectId,
      isEditable: false, // 是否可以编辑
      dataList: [], // 当前 model 数据
      OriginalDataList: [] // 原始数据，用于数据回滚
    }
  },
  computed: {},
  watch: {},
  created() {
    this.initData()
  },
  methods: {
    async initData() {
      let result = await this.getCustomFiledInfo()
      if(result.status === 200) {
        let defKeys = Object.keys(result.data.def)
        let list = Object.keys(result.data.config).filter(item => defKeys.includes(item)).map(item => {
          return {
            key: item,
            label: result.data.def[item].fieldName,
            isChecked: result.data.config[item]
          }
        })
        this.dataList = list.map(item => {return {...item}})
        this.OriginalDataList = list.map(item => {return {...item}})
      }
    },
    // 点击编辑
    controllBtnClick() {
      this.isEditable = !this.isEditable
    },
    // 点击确定
    async okBtnClick() {
      this.controllBtnClick()
      let config = {}
      this.dataList.forEach(item => {
        config[item.key] = item.isChecked
      })
      let result = await this.updateCustomFiledInfo(config)
      if(result.status === 200) {
        this.$message({
          message: result.msg || '更新成功',
          type: 'success'
        })
        this.initData()
      } else {
        this.$message({ message: result.msg || '更新失败', type: 'error' })
      }
    },
    // 点击取消
    cancelBtnClick() {
      this.dataList = this.OriginalDataList.map(item => {return {...item}})
      this.controllBtnClick()
    }
  }
}
</script>
<style lang="scss" scoped>
  .setting-tab-header {
    font-size: 16px;
    font-weight: 900;
    display: block;
    margin-top: 12px;
  }
  .tab-minheight {
    overflow: hidden;
  }
  .checkbox-content {
    clear: left;
    overflow: hidden;
    margin-top: 25px;
  }
  .checkbox-footer {
    margin-top: 20px;
  }
</style>
