<template>
  <div v-loading="loading"
    element-loading-text=""
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)">
    <span class="setting-tab-header">项目信息配置管理</span>
    <div class="project-content">
      <el-form ref="projectInfo" :model="projectInfo" :rules="rules" label-width="80px" label-position="left">
        <el-form-item label="项目名称" prop="name">
          <el-input v-model="projectInfo.name" class="project-content-input" :disabled="!editable"></el-input>
        </el-form-item>
        <el-form-item label="项目描述" prop="description">
          <el-input type="textarea" v-model="projectInfo.description" class="project-content-textarea" :disabled="!editable"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" v-show="authFunction('FUNC_COOP_PROJECT_UPDATE', 3, projectId)" @click="save">保存</el-button>
          <el-button type="default" v-show="showCancel" @click="cancel">取消</el-button>
          <el-button type="warning" v-show="!projectInfo.completed&&authFunction('FUNC_COOP_PROJECT_COMPLETE', 3, projectId)" @click="endProject">结束项目</el-button>
          <el-button v-show="authFunction('FUNC_COOP_PROJECT_DELETE', 3, projectId)" @click="deleteProject">删除项目</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>
<script>
/**
 * @title 项目信息编辑组件
 * @desc 
 * @author heyunjiang
 * @date 2019.5.21
 */
export default {
  name: "ProjectInfoManagement",
  components: {},
  mixins: [],
  props: {},
  data() {
    return {
      projectId: this.getUrlParams().projectId,
      projectInfo: {
        name: '', // 项目名称
        description: '', // 项目描述
        completed: true // 是否已结束
      },
      rules: {
        name: [
          { required: true, message: '请输入项目名称', trigger: 'change' }
        ],
      },
      originalData: {},
      loading: false
    }
  },
  computed: {
    // 是否拥有权限编辑
    editable() {
      return this.authFunction('FUNC_COOP_PROJECT_UPDATE', 3, this.projectId)
    },
    // 是否修改了内容
    showCancel() {
      return this.projectInfo.name !== this.originalData.name || this.projectInfo.description !== this.originalData.description
    }
  },
  watch: {},
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.projectInfo.completed = true;
      this.getProjectInfo();
    },
    // 获取项目信息
    async getProjectInfo() {
      this.loading = true;
      const result = await $http.get($http.api.project.info, {
        id: this.projectId,
      })
      this.loading = false;
      if(result.status === 200) {
        this.projectInfo = {...result.data}
        this.originalData = {...result.data}
      }
    },
    // 保存项目
    async save() {
      // 校验必填项
      let validResult
      this.$refs['projectInfo'].validate((valid) => {
        validResult = valid
      });
      if(!validResult) { return false; }
      // 执行保存
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.project.coop_project_update, {
          id: this.projectId,
          ...this.projectInfo
        })
      } catch (_) {
        // result = _
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "更新成功", type: 'success' })
        this.originalData = {...this.projectInfo}
        this.$store.dispatch('modifyProjectName', {projectName: this.projectInfo.name})
      } else {
        this.$message({ message: result.msg || "更新失败", type: 'error' })
        this.projectInfo = {...this.originalData}
      }
    },
    // 取消编辑
    cancel() {
      this.projectInfo = {...this.originalData}
    },
    // 操作前的确认
    async confirmBeforeOperate(text = '') {
      let result = null
      try {
        result = await this.$confirm(text, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: 'warnint'
        })
      } catch (_) {
        result = false;
      }
      return result;
    },
    // 结束项目
    async endProject() {
      const confirmResult = await this.confirmBeforeOperate(`确认结束项目-${this.projectInfo.name}-吗？结束项目后不允许再创建需求、任务、迭代、缺陷等功能`);
      if(!confirmResult) {return false;}
      this.loading = true;
      const result = await $http.get($http.api.project.complete_project, {
        id: this.projectId
      })
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "结束成功", type: 'success' })
        this.projectInfo.completed = true
        this.originalData.completed = true
      } else {
        this.$message({ message: result.msg || "结束失败", type: 'error' })
        this.projectInfo.completed = false
        this.originalData.completed = false
      }
    },
    // 删除项目
    async deleteProject() {
      const confirmResult = await this.confirmBeforeOperate(`确认删除项目-${this.projectInfo.name}-吗？`);
      if(!confirmResult) {return false;}
      this.loading = true;
      const result = await $http.get($http.api.project.coop_project_delete, {
        id: this.projectId
      })
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "删除成功", type: 'success' })
        this.goToPage(this, "projectList");
      } else {
        this.$message({ message: result.msg || "删除失败", type: 'error' })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .setting-tab-header {
    font-size: 16px;
    font-weight: 900;
    display: block;
    margin-top: 12px;
  }
  .project-content {
    overflow: hidden;
    margin-top: 10px;
    .project-content-input {
      width: 300px;
    }
    .project-content-textarea {
      width: 300px;
    }
  }
</style>
