<template>
  <div id="personalManagementList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box" style="height: -webkit-calc(100% - 45px);">
        <el-tabs v-model="currentTab" type="border-card">
          <el-tab-pane label="关联业务管理" name="biz">
            <!-- 关联业务管理 -->
            <div class="tab-minheight">
              <div style="height:50px;">
                <span class="tit fl" style="font-size: 16px;font-weight:900;margin-top: 12px;">关联业务管理</span>
                <el-input v-model="relatedBusinessInfo.name" class="fl ml10 mt10" style="width:200px;"
                  placeholder="请输入业务名称" clearable></el-input>
                <el-button type="primary" class="fl mt10 ml10" @click="queryRelatedBusinessBtn">查询</el-button>
                <el-button type="primary" class="fr mt10" @click="addRelatedBusiness"
                  v-show="authFunction('FUNC_COOP_PROJ_MANG_BIZ_ASSOC', 3, projectId)">添加</el-button>
              </div>
              <div style="">
                <el-table :border="true" :data="relatedBusinessData.results" style="width: 100%;height: 100%;">

                  <el-table-column label="已关联业务" min-width="120" prop="name"></el-table-column>
                  <el-table-column label="操作" width="60"
                    v-if="authFunction('FUNC_COOP_PROJ_MANG_BIZ_DISASSOC', 3, projectId)">
                    <template slot-scope="scope">
                      <span class="cp c-blue" @click="deleteRelatedBusiness(scope.row)"
                        v-show="authFunction('FUNC_COOP_PROJ_MANG_BIZ_DISASSOC', 3, projectId)">删除</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleSizeChange"
                  @current-change="handleCurrentChange" :pager-count="5"
                  :current-page="relatedBusinessData.pageInfo.pageNum" :page-sizes="[20, 30, 50]"
                  :page-size="relatedBusinessData.pageInfo.pageSize" layout="total, sizes, prev, pager, next"
                  :total="relatedBusinessData.total">
                </el-pagination>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="人员管理" name="user">
            <!-- 人员管理 -->
            <div class="tab-minheight">
              <div style="height:50px;">
                <span class="tit fl" style="font-size: 16px;font-weight:900;margin-top: 12px;">人员管理</span>
                <el-input v-model="search" class="fl ml10 mt10" style="width:200px;" placeholder="请输入人员名称" clearable>
                </el-input>
                <el-button type="primary" class="fl mt10 ml10" @click="queryPersonnelManagementBtn">查询</el-button>
                <el-button type="primary" class="fl mt10 ml10"  v-show="authFunction('FUNC_COOP_PROJ_MANG_BIZ_ASSOC', 3, projectId)"  @click="copyProjectPerson">导入项目成员</el-button>
                <el-button type="primary" class="fr mt10"
                  v-show="authFunction('FUNC_COOP_PROJ_MANG_STAFF_CONFIG', 3, projectId)"
                  @click="addPersonnelManagement">添加
                </el-button>
              </div>
              <div style="">
                <el-table :border="true" :data="personnelManagementData.results" style="width: 100%;height: 100%;">
                  <el-table-column prop="userName" label="人员" min-width="120">
                    <template slot-scope="scope">
                      {{scope.row.userName+'('+scope.row.userId+')'}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="" label="来自业务" min-width="120">
                    <template slot-scope="scope">
                      <span>{{fromBusiness(scope.row)}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="角色" min-width="180">
                    <template slot-scope="scope">
                      {{arrayJoiner(scope.row.roles)}}
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" width="120"
                    v-if="authFunction('FUNC_COOP_PROJ_MANG_STAFF_CONFIG', 3, projectId) ||
                                  authFunction('FUNC_COOP_PROJ_MANG_STAFF_REMOVE', 3, projectId)||authFunction('FUNC_COOP_PROJ_PRODUCT_MANAGER', 3, projectId)">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="editPersonnelManagement(scope.row)"
                        v-show="authFunction('FUNC_COOP_PROJ_MANG_STAFF_CONFIG', 3, projectId)">编辑</span>
                      <span class="c-blue cp" @click="delPersonnelManagement(scope.row)"
                        v-show="authFunction('FUNC_COOP_PROJ_MANG_STAFF_REMOVE', 3, projectId)">删除</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleOpsSizeChange"
                  @current-change="handleOpsCurrentChange" :pager-count="5"
                  :current-page="personnelManagementData.pageInfo.pageNum" :page-sizes="[15,20, 30, 50]"
                  :page-size=personnelManagementData.pageInfo.pageSize layout="total, sizes, prev, pager, next"
                  :total="personnelManagementData.total">
                </el-pagination>
              </div>
            </div>

          </el-tab-pane>
          <el-tab-pane label="角色设置" name="role">
            <role-manage v-if="currentTab==='role'"></role-manage>
          </el-tab-pane>
          <!-- <el-tab-pane label="缺陷字段管理" name="custom">
            <custom-field-management v-if="currentTab==='custom'"></custom-field-management>
          </el-tab-pane> -->
          <el-tab-pane label="项目信息管理" name="info">
            <project-info-management v-if="currentTab==='info'"></project-info-management>
          </el-tab-pane>
          <el-tab-pane label="工作流设置" name="flow">
            <work-flow-setting v-if="currentTab==='flow'"></work-flow-setting>
          </el-tab-pane>
          <el-tab-pane label="迭代阶段设置" name="sprint">
            <sprint-stage-management v-if="currentTab==='sprint'"></sprint-stage-management>
          </el-tab-pane>
          <el-tab-pane label="自定义模板" name="customTemplates">
            <custom-setting v-if="currentTab==='customTemplates'"></custom-setting>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <!-- 添加关联业务弹窗 -->
    <el-dialog title='添加关联业务' class="el-dialog-350w" :before-close="relatedBusinessOut"
      :visible.sync="relatedBusinessDialogVisible" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="relatedBusinessInfo" ref="relatedBusinessInfo" label-width="80px">
          <el-form-item label="业务名称">
            <el-select v-model="relatedBusinessInfo.nameList" multiple filterable remote reserve-keyword
              placeholder="请输入关键词" :remote-method="searchRemoteRelatedBusiness" :loading="loading" style="width:100%;">
              <el-option v-for="item in relatedBusinessList" :key="item.id" :label="item.name" :value="item.id">
                <span style="float: left">{{ item.name }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;">{{ item.id }}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="submitRelatedBusiness">保存</el-button>
        <el-button class="fr" @click="relatedBusinessOut">关闭</el-button>
      </span>
    </el-dialog>
    <!-- 人员管理弹窗 -->
    <el-dialog :title="managementTitle" id="bizOpsMemberDialog" class="el-dialog-350w"
      :before-close="closePersonnelDuty" :visible.sync="PersonnelManagementDialogVisible" :modal-append-to-body="true"
      :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="personnelManagementInfo" ref="personnelManagementInfo" label-width="80px">
          <el-form-item label="姓名/工号">
            <el-select v-model="personnelManagementInfo.personnelManagementName" placeholder="请输入姓名或工号" multiple
              filterable remote reserve-keyword :remote-method="searchPersonnelManagement" :loading="loading"
              style="width:100%;" :disabled="disabledPerson">
              <el-option v-for="item in personnelManagementnameList" :key="item.userId" :label="item.userName"
                :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="职责">
            <el-select v-model="personnelManagementInfo.personnelDuty" style="width:100%" multiple filterable>
              <el-option v-for="item in PersonnelDutylist" :key="item.roleId" :label="item.roleName"
                :value="item.roleId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="addPersonnelDuty">保存</el-button>
        <el-button class="fr" @click="closePersonnelDuty">关闭</el-button>
      </span>
    </el-dialog>
    <!-- //人员复制弹窗 -->
    <person-clone @updatePerson="queryPersonnelManagement({ pageNumber: 1, pageSize: 20 });" :cloneWorkFlowModalStatus="cloneWorkFlowModalStatus" :closeModal="closeModal" :projectId="projectId"></person-clone>
  </div>
</template>

<script>
  // 设置入口文件
  import CustomFieldManagement from './CustomFieldManagement';
  import ProjectInfoManagement from './ProjectInfoManagement';
  import WorkFlowSetting from './WorkFlowSetting';
  import RoleManage from './RoleManage';
  import SprintInfoCustom from 'components/project/sprint/SprintInfoCustom.vue';
  import SprintStageManagement from './SprintStageManagement';
  import PersonClone from './PersonClone';
  import CustomSetting from './CustomSetting';

  export default {
    name: "personalManagementList",
    components: {
      CustomFieldManagement,
      ProjectInfoManagement,
      WorkFlowSetting,
      SprintInfoCustom,
      RoleManage,
      SprintStageManagement,
      PersonClone,
      CustomSetting
    },
    data() {
      return {
        managementTitle: '',
        loading: false,
        personnelManagementnameList: [],
        relatedBusinessList: [],
        PersonnelDutylist: [],
        shadeBtn: false,
        modaltobody: false,
        relatedBusinessData: { results: [], pageInfo: { pageNum: 1, pageSize: 20 }, total: 0, pages: 0 },
        personnelManagementData: { results: [], pageInfo: { pageNum: 1, pageSize: 15 }, total: 0, pages: 0 },
        relatedBusinessDialogVisible: false,
        relatedBusinessInfo: { nameList: [] },
        personnelManagementInfo: { personnelDuty: [], personnelManagementName: [] },
        search: '',
        PersonnelManagementDialogVisible: false,
        disabledPerson: false,
        projectId: this.getUrlParams().projectId,
        currentTab: 'biz', // 当前展示的 tab,
        cloneWorkFlowModalStatus: false,
      };
    },
    mounted() {
      this.projectId = this.getUrlParams().projectId;
      this.queryRelatedBusiness({ pageNumber: 1, pageSize: 20 });
      this.queryPersonnelManagement({ pageNumber: 1, pageSize: 20 });
      this.getUrlParams().key && this.getUrlParams().key == "sprint" ? this.currentTab = 'sprint' : this.currentTab = 'biz'
    },
    watch: {
      currentTab() {
        if(this.currentTab === 'user') {
          this.queryPersonnelManagementBtn();
          this.PersonnelDutylist = [];
          this.$nextTick(this.getPersonRoles);
        }
      }
    },
    methods: {
      //关闭复制项目成员的
      closeModal() {
        this.cloneWorkFlowModalStatus = false;
      },
      //复制项目成员
      copyProjectPerson() {
        this.cloneWorkFlowModalStatus = true;
      },
      queryRelatedBusinessBtn() {
        this.relatedBusinessData.pageInfo.pageNum = 1;
        this.queryRelatedBusiness({ pageNumber: 1, pageSize: this.relatedBusinessData.pageInfo.pageSize });
      },

      addRelatedBusiness() {
        this.relatedBusinessInfo.nameList = [];
        $http.post($http.api.project.coop_project_management_biz_available, { query: null }).then((res) => {
          this.relatedBusinessList = res.data;
        })
        this.relatedBusinessDialogVisible = true;
      },

      searchRemoteRelatedBusiness(query) {
        this.loading = true;
        $http.post($http.api.project.coop_project_management_biz_available, { query: query }).then((res) => {
          this.relatedBusinessList = res.data;
          this.loading = false;
        });
      },

      relatedBusinessOut() {
        this.relatedBusinessDialogVisible = false;
      },

      submitRelatedBusiness() {
        if (this.relatedBusinessInfo.nameList.length == 0) {
          this.$message({ message: '业务名称不能为空', type: 'warning' });
          return;
        }
        $http.post($http.api.project.coop_project_management_biz_assoc, {
          bizIds: this.relatedBusinessInfo.nameList, projectId: this.getUrlParams().projectId
        }).then((res) => {
          if (res.status === 200) {
            this.$message({ message: res.msg || '添加成功', type: 'success' });
            this.queryRelatedBusiness({
              pageNumber: this.relatedBusinessData.pageInfo.pageNum,
              pageSize: this.relatedBusinessData.pageInfo.pageSize
            });
            this.relatedBusinessOut();
          } else {
            this.$message({ message: res.msg || '添加失败', type: 'error' });
          }
        });
      },

      deleteRelatedBusiness(row) {
        // console.log(row);
        this.$confirm('此操作将删除该数据, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.project.coop_project_management_biz_disassoc, {
            bizId: row.id, projectId: this.getUrlParams().projectId
          }).then((res) => {
            if (res.status === 200) {
              this.$message({ message: res.msg || '删除成功', type: 'success' });
              this.queryRelatedBusiness({
                pageNumber: this.relatedBusinessData.pageInfo.pageNum,
                pageSize: this.relatedBusinessData.pageInfo.pageSize
              });
            } else {
              this.$message({ message: res.msg || '删除失败', type: 'error' });
            }
          });
        }).catch(() => {
        });
      },

      queryRelatedBusiness(payload) {
        let params = {
          projectId: this.getUrlParams().projectId,
          pageInfo: {
            pageNumber: payload.pageNumber,
            pageSize: payload.pageSize,
          },
          query: this.relatedBusinessInfo.name
        };
        $http.post($http.api.project.coop_project_management_biz_list, params).then((res) => {
          this.relatedBusinessData.results = res.data.results;
          this.relatedBusinessData.total = res.data.pageInfo.totalRecords;

          this.personnelManagementData.pageInfo.pageNum = 1;
          this.queryPersonnelManagement({
            pageNumber: 1,
            pageSize: this.personnelManagementData.pageInfo.pageSize
          });
        });
      },

      handleSizeChange(val) {
        this.relatedBusinessData.pageInfo.pageSize = val;
        this.relatedBusinessData.pageInfo.pageNum = 1;
        this.queryRelatedBusiness({ pageNumber: 1, pageSize: val });
      },
      handleCurrentChange(val) {
        this.relatedBusinessData.pageInfo.pageNum = val;
        this.queryRelatedBusiness({ pageNumber: val, pageSize: this.relatedBusinessData.pageInfo.pageSize });
      },


      queryPersonnelManagementBtn() {
        this.personnelManagementData.pageInfo.pageNum = 1;
        this.queryPersonnelManagement({ pageNumber: 1, pageSize: this.personnelManagementData.pageInfo.pageSize });
      },

      addPersonnelManagement() {
        this.personnelManagementInfo.personnelManagementName = [];
        this.personnelManagementInfo.personnelDuty = [];
        this.getPersonRoles();
        this.disabledPerson = false;
        this.managementTitle = '添加项目人员';
        this.PersonnelManagementDialogVisible = true;
      },

      getPersonRoles() {
        if(this.PersonnelDutylist.length > 0) {return ;}
        $http.get($http.api.AuthCustom.role_list).then((res) => {
          this.PersonnelDutylist = res.data;
        });
      },

      editPersonnelManagement(row) {
        // console.log(row);
        this.personnelManagementnameList = [row];
        this.personnelManagementInfo.personnelManagementName = [row.userId];
        this.getPersonRoles();
        row.roles.map(item => {
          this.personnelManagementInfo.personnelDuty.push(+item.roleId);
        })
        this.PersonnelManagementDialogVisible = true;
        this.disabledPerson = true;
      },

      searchPersonnelManagement(query) {
        if (query !== '') {
          this.loading = true;
          $http.get($http.api.user_info.get_search_users, { keyword: query }).then((res) => {
            this.personnelManagementnameList = res.data;
            this.loading = false;
          });
        }
      },

      closePersonnelDuty() {
        this.personnelManagementInfo.personnelDuty = [];
        this.personnelManagementInfo.personnelManagementName = [];
        this.PersonnelManagementDialogVisible = false;
      },

      addPersonnelDuty() {
        if (this.personnelManagementInfo.personnelManagementName.length === 0) {
          this.$message({ message: '姓名/工号不能为空', type: 'warning' });
          return;
        } else if (this.personnelManagementInfo.personnelDuty.length === 0) {
          this.$message({ message: '职责不能为空', type: 'warning' });
          return;
        } else if (this.personnelManagementInfo.personnelManagementName.length === 0 && this.personnelManagementInfo.personnelDuty.length === 0) {
          this.$message({ message: '姓名/工号不能为空,职责不能为空', type: 'warning' });
          return;
        }

        let params = {
          projectId: this.getUrlParams().projectId,
          userIds: this.personnelManagementInfo.personnelManagementName,
          roles: this.personnelManagementInfo.personnelDuty,
        };
        $http.post($http.api.project.coop_project_management_staff_roles_config, params).then((res) => {
          if (res.status === 200) {
            this.$message({
              message: res.msg || '添加或修改成功',
              type: 'success'
            });
            this.closePersonnelDuty();
            this.queryPersonnelManagement({
              pageNumber: this.personnelManagementData.pageInfo.pageNum,
              pageSize: this.personnelManagementData.pageInfo.pageSize
            });
          } else {
            this.$message({
              message: res.msg || '添加或修改失败',
              type: 'error'
            });
          }
        });
      },

      delPersonnelManagement(delUser) {
        let params = {
          userId: delUser.userId,
          projectId: this.getUrlParams().projectId
        };

        this.$confirm('此操作会将' + '【' + delUser.userName + '】' + "从项目中删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.post($http.api.project.coop_project_management_staff_remove, params).then((res) => {
            if (res.status === 200) {
              this.$message({
                message: res.msg || '删除成功',
                type: 'success'
              });
              this.queryPersonnelManagement({
                pageNumber: this.personnelManagementData.pageInfo.pageNum,
                pageSize: this.personnelManagementData.pageInfo.pageSize
              });
            } else {
              this.$message({
                message: res.msg || '删除失败',
                type: 'error'
              });
            }
          })
        }).catch(() => {
        });
      },

      queryPersonnelManagement(payload) {
        $http.post($http.api.project.coop_project_management_staff_list, {
          projectId: this.getUrlParams().projectId,
          pageInfo: {
            pageNumber: payload.pageNumber,
            pageSize: payload.pageSize,
          },
          query: this.search
        }).then((res) => {
          this.personnelManagementData.results = res.data.results;
          this.personnelManagementData.total = res.data.pageInfo.totalRecords;
        });
      },

      handleOpsSizeChange(val) {
        this.personnelManagementData.pageInfo.pageSize = val;
        this.personnelManagementData.pageInfo.pageNum = 1;
        this.queryPersonnelManagement({ pageNumber: 1, pageSize: val });
      },

      handleOpsCurrentChange(val) {
        this.personnelManagementData.pageInfo.pageNum = val;
        this.queryPersonnelManagement({ pageNumber: val, pageSize: this.personnelManagementData.pageInfo.pageSize });
      },

      arrayJoiner(inputArray) {
        let arr = [];
        inputArray.map((item) => {
          arr.push(item.roleName);
        })
        return arr.join(',');
      },

      fromBusiness(row) {
        if (row.fromBiz == true) {
          return '是'
        }
        if (row.fromBiz == false) {
          return '否'
        }
      },
    }
  };
</script>

<style lang="scss" scoped></style>