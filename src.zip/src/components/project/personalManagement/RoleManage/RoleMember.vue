<template>
  <div
    class="memeber-manage-box"
    v-loading="loading"
    element-loading-text
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)"
  >
    <div class="header">
      <span class="header-title">角色成员：{{memberCount}}</span>
      <el-button type="text" v-show="addAble" @click="addUser" slot="reference">+添加成员</el-button>
      <!-- <span>
        <el-popover
          placement="right"
          width="400"
          transition="auto"
          @show="beforeUpdate"
          @hide="afterClose"
          trigger="click">
          <div>
            <template v-for="item in projectUsers.list">
              <el-checkbox class="member-item-next-select" v-model="item.selected" :key="item.key">{{item.value}}</el-checkbox>
            </template>
          </div>
          <el-button type="text" v-show="addAble" slot="reference">+添加成员</el-button>
        </el-popover>
      </span> -->
    </div>
    <div class="member-list">
      <el-tag
        class="member-list-item"
        v-for="member in members"
        :key="member.value"
        :type="member.type"
        size="small"
      >
        <span>{{member.value}}({{member.key}})</span>
        <span v-show="deleteAble" class="member-delete cursor-pointer" @click="deleteMember(member)"><i class="el-icon-delete"></i></span>
      </el-tag>
    </div>
    <!-- 人员管理弹窗 -->
    <el-dialog title="添加成员" class="el-dialog-350w"
      :before-close="closePersonnelDuty" :visible.sync="PersonnelManagementDialogVisible" :modal-append-to-body="true"
      :close-on-click-modal='false'>
      <div class="form-iterm-box">
        <el-form label-width="80px">
          <el-form-item label="姓名/工号">
            <el-select v-model="personnelManagementName" placeholder="请输入姓名或工号" multiple
              filterable remote reserve-keyword :remote-method="searchPersonnelManagement" :loading="userloading"
              style="width:100%;">
              <el-option v-for="item in personnelManagementnameList" :key="item.userId" :label="item.userName"
                :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="addPersonnelDuty">保存</el-button>
        <el-button class="fr" @click="closePersonnelDuty">关闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 角色成员
 * @desc 
 * @author heyunjiang
 * @date 
 */
export default {
  name: "RoleMember",
  components: {},
  mixins: [],
  props: {
    projectId: {
      type: [String, Number],
      required: false
    },
    currentRoleInfo: {
      type: Object,
      required: true,
      desc: '当前选中角色'
    }
  },
  data() {
    return {
      // 项目内成员数据信息
      projectUsers: {
        list: [],
        pageInfo: { pageNum: 1, pageSize: 1000 }
      }, 
      members: [], // 当前角色成员列表
      loading: false,
      updatable: false, // 是否可以更新，用以控制在切换左侧列表时，导致的 popover 关闭触发的更新机制
      PersonnelManagementDialogVisible: false, // 添加成员 dialog
      personnelManagementName: [],
      personnelManagementnameList: [],
      userloading: false
    }
  },
  computed: {
    // 权限 - 是否可以添加
    addAble() {
      return this.authFunction('FUNC_COOP_PROJECT_SETTING_ROLE_MANAGE_STAFF_ADD', 3, this.projectId)
    },
    // 权限 - 是否可以删除
    deleteAble() {
      return this.authFunction('FUNC_COOP_PROJECT_SETTING_ROLE_MANAGE_STAFF_DELETE', 3, this.projectId)
    },
    // 人员数量统计
    memberCount() {
      return this.members.length;
    }
  },
  watch: {
    currentRoleInfo() {
      this.updatable = false;
      if(this.currentRoleInfo.key) {
        this.getSelectedMemberList();
      }
    }
  },
  mounted() {
    this.getMemberList();
    if(this.currentRoleInfo.key) {
      this.getSelectedMemberList();
    }
  },
  methods: {
    // popover 打开
    beforeUpdate() {
      this.updatable = true;
    },
    // popover 关闭
    afterClose() {
      this.$nextTick(this.updateMember)
    },
    // 获取项目内成员列表
    async getMemberList() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.post($http.api.project.coop_project_management_staff_list, {
          projectId: this.projectId || this.getUrlParams().projectId,
          pageInfo: { ...this.projectUsers.pageInfo },
          query: ''
        });
      } catch(_) {} finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取项目成员数据失败',
          type: 'error'
        })
        return;
      }
      this.projectUsers.list = result.data.results.map(item => {
        return {
          key: item.userId,
          value: item.userName,
          ...item
        }
      })
      this.generateListSelect();
    },
    // 获取当前角色对应的成员列表
    async getSelectedMemberList() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.get($http.api.AuthCustom.member_list, {
          projectId: this.projectId || this.getUrlParams().projectId,
          roleId: this.currentRoleInfo.key
        });
      } catch(_) {} finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取角色成员数据失败',
          type: 'error'
        })
        return;
      }
      this.members = result.data.map(item => {
        return {
          key: item.userId,
          value: item.userName,
          type: 'success',
          ...item
        }
      })
      this.generateListSelect();
    },
    // 删除成员
    async deleteMember(info) {
      const confirmResult = await this.confirmBeforeOperate(`确认删除成员${info.value}吗？`);
      if(!confirmResult) { return false; }
      let result = {}
      try {
        this.loading = true;
        const urlObj = {...$http.api.AuthCustom.member_delete};
        urlObj.url += '?roleId=' + this.currentRoleInfo.key + '&projectId=' + (this.projectId || this.getUrlParams().projectId) + '&userId=' + info.key;
        result = await $http.post(urlObj);
      } catch(_) {} finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '删除成员失败',
          type: 'error'
        })
        return;
      } else {
        this.$message({
          message: result.msg || '删除成员成功',
          type: 'success'
        });
        this.getSelectedMemberList();
        $utils.getUserInfo();
      }
    },
    // 更新成员
    async updateMember(user_poor = []) {
      // if(!this.updatable) {return ;}
      let result = {}
      try {
        this.loading = true;
        const urlObj = {...$http.api.AuthCustom.member_add};
        urlObj.url += '?roleId=' + this.currentRoleInfo.key + '&projectId=' + (this.projectId || this.getUrlParams().projectId);
        result = await $http.post(urlObj, [...this.members.map(item => item.key), ...user_poor]);
      } catch(_) {} finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '更新成员失败',
          type: 'error'
        })
        return;
      } else {
        this.$message({
          message: result.msg || '更新成员成功',
          type: 'success'
        });
        this.getSelectedMemberList();
        $utils.getUserInfo();
        this.closePersonnelDuty();
      }
    },
    // 更新所有人员列表是否选中值
    generateListSelect() {
      if(this.projectUsers.list.length === 0) {return ;}
      const selectedMemberIds = this.members.map(item => item.key);
      this.projectUsers.list = this.projectUsers.list.map(item => {
        return {
          ...item,
          selected: selectedMemberIds.includes(item.key)?true:false // selectedMemberIds.includes(item.key)
        }
      })
    },
    // dialog - 点击添加成员
    addUser() {
      this.PersonnelManagementDialogVisible = true;
    },
    // dialog - 关闭
    closePersonnelDuty() {
      this.personnelManagementName = [];
      this.PersonnelManagementDialogVisible = false;
    },
    // dialog - 搜索人员
    searchPersonnelManagement(query) {
      if (query !== '') {
        this.userloading = true;
        $http.get($http.api.user_info.get_search_users, { keyword: query }).then((res) => {
          this.personnelManagementnameList = res.data;
          this.userloading = false;
        });
      }
    },
    // 保存人员
    addPersonnelDuty() {
      this.updateMember(this.personnelManagementName);
    }
  }
}
</script>
<style lang="scss" scoped>
.memeber-manage-box {
  padding: 10px;
  background-color: #f9f9f9;
  .header {
    .header-title {
      font-size: 16px;
    }
  }
  .member-list {
    margin: 5px 0;
    padding: 10px 10px 5px;
    background-color: #ecf1f0;
    .member-list-item {
      margin: 0 10px 5px 0;
      font-size: 13px;
    }
    .member-delete {
      padding: 0 5px;
      &:hover {
        color: #409EFF;
      }
    }
  }
}
.member-item-next-select {
  margin: 0 10px 0 0;
}
</style>
