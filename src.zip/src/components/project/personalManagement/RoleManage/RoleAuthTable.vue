<template>
  <div
    class="auth-box"
    v-loading="loading"
    element-loading-text
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)"
  >
    <header>{{currentRoleInfo.value}}</header>
    <div>
      <el-table :data="authTable" style="width: 100%">
        <el-table-column prop="name" label="操作对象" width="180"></el-table-column>
        <el-table-column label="权限" min-width="180">
          <template slot-scope="scope">
            <el-checkbox v-for="item in scope.row.authList" v-model="item.authorized" :disabled="!updateAble" 
              @change="value => {itemSelect(scope.row)}" :key="item.authId"  class="auth-item-next-select">{{item.authName}}</el-checkbox>
          </template>
        </el-table-column>
        <el-table-column label="全选" width="100">
          <template slot-scope="scope">
            <el-checkbox v-model="scope.row.operate" :disabled="!updateAble" @change="value => {allSelect(value, scope.row)}"></el-checkbox>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <footer>
      <el-button type="primary" @click="updateAuthList" :disabled="!updateAble">保存</el-button>
    </footer>
  </div>
</template>
<script>
/**
 * @title 
 * @desc 
 * @author heyunjiang
 * @date 
 */
export default {
  name: "RoleAuthTable",
  components: {},
  mixins: [],
  props: {
    projectId: {
      type: [String, Number],
      required: false
    },
    currentRoleInfo: {
      type: Object,
      required: true,
      desc: '当前选中角色'
    }
  },
  data() {
    return {
      authTable: [],
      loading: false
    }
  },
  computed: {
    updateAble() {
      return this.authFunction('FUNC_COOP_PROJECT_SETTING_ROLE_MANAGE_FUNCTION_UPDATE', 3, this.projectId)
    }
  },
  watch: {
    currentRoleInfo() {
      if (this.currentRoleInfo.key) {
        this.getAuthList();
      }
    }
  },
  created() { },
  methods: {
    // 获取权限列表
    async getAuthList() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.get($http.api.AuthCustom.function_list, {
          projectId: this.projectId || this.getUrlParams().projectId,
          roleId: this.currentRoleInfo.key
        });
      } catch(_) {} finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取权限列表数据失败',
          type: 'error'
        })
        return;
      }
      this.authTable = Object.keys(result.data).map(item => {
        return {
          name: item,
          authList: result.data[item],
          operate: this.computedSelectAll(result.data[item])
        }
      })
    },
    // 更新权限列表数据
    async updateAuthList() {
      let result = {}
      try {
        this.loading = true;
        let functionIdList = [];
        this.authTable.forEach(item => {
          item.authList.forEach(jtem => {
            jtem.authorized&&(functionIdList.push(jtem.authId));
          })
        })
        result = await $http.post($http.api.AuthCustom.function_update, {
          projectId: this.projectId || this.getUrlParams().projectId,
          roleId: this.currentRoleInfo.key,
          functionIdList
        });
      } catch(_) {} finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '更新权限列表数据失败',
          type: 'error'
        })
        return;
      } else {
        this.$message({
          message: result.msg || '更新权限列表数据成功',
          type: 'success'
        });
        this.getAuthList();
        $utils.getUserInfo();
      }
    },
    // 某一项选中/反选 - 计算全选
    itemSelect(info) {
      info.operate = this.computedSelectAll(info.authList);
    },
    // 全选选中/反选 - 计算全选后续操作
    allSelect(value, info) {
      info.authList = info.authList.map(item => {
        return {
          ...item,
          authorized: value
        }
      })
      info.operate = value;
    },
    // 全选计算
    computedSelectAll(list) {
      if(!Array.isArray(list)) {return false;}
      if(list.some(item => !item.authorized)) {
        return false;
      }
      return true;
    }
  }
}
</script>
<style lang="scss" scoped>
.auth-box {
  padding: 10px;
  background-color: #f9f9f9;
  header {
    height: 30px;
    line-height: 30px;
    font-size: 16px;
  }
  footer {
    height: 50px;
    line-height: 50px;
    text-align: left;
  }
  .auth-item-next-select {
    margin: 0;
    display: inline-block;
    width: 150px;
    padding: 0 5px 0 0;
    box-sizing: border-box;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}
</style>
