<template>
  <div v-loading="loading"
    element-loading-text=""
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)">
    <div class="flow-header">
      <span class="flow-header-item" :class="{'flow-header-item-active': item.workItemType===activeType}" 
        v-for="item in types" :key="item.workItemType" @click="headerCardChange(item.workItemType)">{{item.name}}工作流</span>
    </div>
    <div class="flow-table-box">
      <div class="flow-table-header">
        <el-button type="primary" v-if="authFunction('FUNC_COOP_STATUS_CONFIG_CREATE', 3, projectId)" @click="statusAddClickHandle">新加工作流程</el-button>
        <el-button type="text" v-if="authFunction('FUNC_COOP_STATUS_CONFIG_PUBLIC', 3, projectId)" @click="setPublicClickHandle">{{asPublic?'取消公开':'设为公开'}}</el-button>
        <el-button type="text" v-if="authFunction('FUNC_COOP_STATUS_CONFIG_REPLICATE', 3, projectId)" @click="cloneDialogHandle">复制工作流</el-button>
      </div>
      <div class="flow-table-body">
        <el-table :data="workFlowInfo[activeType].defs" border>
          <el-table-column label="工作流名称" show-overflow-tooltip min-width="240">
            <template slot-scope="scope">
              <el-input v-if="scope.row.isnew" v-model="scope.row.name" placeholder="请输入工作流名称"></el-input>
              <global-input :initValue="scope.row.name" v-if="auth&&!scope.row.isnew"
                :onChange="(value)=>{updateStatu({name: value, tmplId: scope.row.tmplId, statusId: scope.row.statusId})}">
                <span class="table-input-edit-text cp c-blue-hover" slot>{{scope.row.name}}</span>
              </global-input>
              <span v-if="!auth&&!scope.row.isnew">{{scope.row.name}}</span>
            </template>
          </el-table-column>
          <el-table-column label="是否默认" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <span>{{scope.row.preset?'是':'否'}}</span>
            </template>
          </el-table-column>
          <el-table-column label="状态颜色" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <el-color-picker v-model="scope.row.color" :disabled="!auth" popper-class="flow-table-body-colorPicker" @change="(value)=>{colorChooseerHandle(value, scope.row)}" class="flow-table-body-coloritem"></el-color-picker>
            </template>
          </el-table-column>
          <el-table-column label="起始状态" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <el-radio :value="scope.row.init" :disabled="!auth" :label="true" @change="initRadioHandle(scope.row)">{{null}}</el-radio>
            </template>
          </el-table-column>
          <el-table-column label="结束状态" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <el-checkbox v-model="scope.row.end" :disabled="!auth" @change="value => {endCheckboxHandle(value, scope.row)}"></el-checkbox>
            </template>
          </el-table-column>
          <el-table-column label="取消状态" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <el-radio :value="scope.row.cancel" :disabled="!auth" :label="true" @change="cancelRadioHandle(scope.row)">{{null}}</el-radio>
              <!-- <el-checkbox v-model="scope.row.cancel" :disabled="!auth" @change="value => {cancelCheckboxHandle(value, scope.row)}"></el-checkbox> -->
            </template>
          </el-table-column>
          <el-table-column label="排序权重" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <el-input v-if="scope.row.isnew" v-model="scope.row.order" placeholder="请输入工作流权重"></el-input>
              <global-input :initValue="scope.row.order" v-if="auth&&!scope.row.isnew"
                :onChange="(value)=>{updateStatu({order: +value, tmplId: scope.row.tmplId, statusId: scope.row.statusId})}">
                <span class="table-input-edit-text cp c-blue-hover" slot>{{scope.row.order}}</span>
              </global-input>
              <span v-if="!scope.row.isnew&&!auth">{{scope.row.order}}</span>
            </template>
          </el-table-column>
          <el-table-column label="操作" show-overflow-tooltip align="center" width="100">
            <template slot-scope="scope">
              <span class="operatebtn" @click="newStatusRecordSaveHandle(scope.row)" v-if="scope.row.isnew&&auth">保存</span>
              <span class="operatebtn" @click="newStatusRecordCancelHandle" v-if="scope.row.isnew&&auth">取消</span>
              <span class="operatebtn" @click="deleteStatu(scope.row)" v-if="!scope.row.isnew&&!scope.row.preset&&deleteAble">删除</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="flow-staturule-box">
      <div class="flow-staturule-box-header">流转状态设置</div>
      <template v-for="item in workFlowInfo[activeType].transfers">
        <work-flow-setting-rule-item :objData="item" :nextDataPoor="workFlowInfo[activeType].defs"
          :addItem="addItem" :removeItem="removeItem" :key="item.def.statusId" :projectId="projectId"></work-flow-setting-rule-item>
      </template>
    </div>
    <work-flow-clone :cloneWorkFlowModalStatus="cloneWorkFlowModalStatus" :closeModal="cloneDialogHandle" 
      :projectId="projectId" :workItemType="activeType" :tmplId="tmplId" :successCallback="workflowCloneSuccess"></work-flow-clone>
  </div>
</template>
<script>
/**
 * @title 工作流状态设置
 * @desc 
 * @author heyunjiang
 * @date 2019.5.21
 */
import WorkFlowSettingRuleItem from './WorkFlowSettingRuleItem'
import WorkFlowClone from './WorkFlowClone'
import GlobalInput from '../../tool/FieldEdit/GlobalInput.vue'

export default {
  name: "WorkFlowSetting",
  components: {
    WorkFlowSettingRuleItem,
    GlobalInput,
    WorkFlowClone
  },
  mixins: [],
  props: {},
  data() {
    return {
      projectId: +this.getUrlParams().projectId,
      types: [
        {name: '需求', workItemType: 1},
        {name: '任务', workItemType: 2},
        {name: '缺陷', workItemType: 3}
      ],
      activeType: 1, // 默认需求是活跃
       // 工作流数据
      workFlowInfo: {
        1: {
          defs: [], // 工作流 table
          transfers: [] // 工作流状态流转
        },
        2: {
          defs: [], // 工作流 table
          transfers: [] // 工作流状态流转
        },
        3: {
          defs: [], // 工作流 table
          transfers: [] // 工作流状态流转
        }
      },
      tmplId: 1, // 当前模板 id ，不能确定是不是等同于 activeType
      asPublic: false, // 当前工作流是否已经公开
      loading: false,
      cloneWorkFlowModalStatus: false // 复制工作流是否展示 dialog
    }
  },
  computed: {
    // 权限 - 是否可以更新
    auth() {
      return this.authFunction('FUNC_COOP_STATUS_CONFIG_UPDATE', 3, this.projectId);
    },
    // 权限 - 是否可以删除
    deleteAble() {
      return this.authFunction('FUNC_COOP_STATUS_CONFIG_DELETE', 3, this.projectId)
    }
  },
  watch: {
    activeType() {
      this.$nextTick(this.init)
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.getWorkFlowInfo();
    },
    // 获取工作流信息
    async getWorkFlowInfo() {
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.work_status_fow.query, {
          projectId: +this.projectId,
          workItemType: +this.activeType
        })
      } catch(_) {}
      this.loading = false;
      if(result.status === 200) {
        this.workFlowInfo[this.activeType] = {
          defs: result.data.defs,
          transfers: result.data.transfers
        }
        this.tmplId = result.data.tmplId;
        this.asPublic = result.data.asPublic;
      }else {
        this.workFlowInfo[this.activeType] = {
          defs: [],
          transfers: {}
        }
      }
    },
    // 新加工作流程 - 点击新加工作流程
    statusAddClickHandle() {
      const isExistNewItem = this.workFlowInfo[this.activeType].defs.filter(item => item.isnew).length > 0;
      if(isExistNewItem) {
        this.$message({ message: "一次只可新增一条数据", type: 'error' })
        return ;
      }
      this.workFlowInfo[this.activeType].defs.push({
        name: '', preset: false, color: '#ffffff', init: false, end: false, cancel: false, order: 0, isnew: true
      })
    },
    // 新加工作流程 - 点击保存
    async newStatusRecordSaveHandle(info) {
      if(info.name.trim().length === 0) {
        this.$message({ message: "名称不能为空", type: 'error' })
        return false;
      }
      delete info.isnew
      delete info.preset
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.work_status_fow.statu_create, {...info, order: +info.order, projectId: this.projectId, tmplId: this.tmplId})
      } catch (_) {}
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "新增成功", type: 'success' })
      } else {
        this.$message({ message: result.msg || "新增失败", type: 'error' })
      }
      this.getWorkFlowInfo()
    },
    // 新加工作流程 - 点击取消
    newStatusRecordCancelHandle() {
      this.workFlowInfo[this.activeType].defs = this.workFlowInfo[this.activeType].defs.filter(item => !item.isnew);
      this.getWorkFlowInfo()
    },
    // 更新工作流程 - 取色器点击取值
    colorChooseerHandle(color, info) {
      if(!info.isnew) {
        this.updateStatu({
          color, 
          tmplId: info.tmplId, 
          statusId: info.statusId
        })
      }
    },
    // 新增/更新工作流程 - 起始状态
    initRadioHandle(info) {
      if(!this.auth) {return false;}
      this.workFlowInfo[this.activeType].defs.forEach(item => {
        if(item.statusId === info.statusId) {
          item.init = true
        } else {
          item.init = false
        }
      })
      if(!info.isnew) {
        this.updateStatu({
          init: true, 
          tmplId: info.tmplId, 
          statusId: info.statusId
        })
      }
    },
    // 新增/更新工作流程 - 结束状态
    endCheckboxHandle(value, info) {
      if(!this.auth) {return false;}
      if(!info.isnew) {
        this.updateStatu({
          end: value, 
          tmplId: info.tmplId, 
          statusId: info.statusId
        })
      }
    },
    // 新增/更新工作流程 - 取消状态 - 单选
    cancelRadioHandle(info) {
      if(!this.auth) {return false;}
      this.workFlowInfo[this.activeType].defs.forEach(item => {
        if(item.statusId === info.statusId) {
          item.cancel = true
        } else {
          item.cancel = false
        }
      })
      if(!info.isnew) {
        this.updateStatu({
          cancel: true, 
          tmplId: info.tmplId, 
          statusId: info.statusId
        })
      }
    },
    // 新增/更新工作流程 - 取消状态 - 多选
    cancelCheckboxHandle(value, info) {
      if(!this.auth) {return false;}
      if(!info.isnew) {
        this.updateStatu({
          cancel : value, 
          tmplId: info.tmplId, 
          statusId: info.statusId
        })
      }
    },
    // 更新工作流程 - 更新数据
    async updateStatu(info = {}) {
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.work_status_fow.statu_update, {...info, projectId: this.projectId})
      } catch (_) {}
      this.loading = false;
      if(result.status && result.status === 200) {
        this.$message({ message: result.msg || "更新成功", type: 'success' })
      } else {
        this.$message({ message: result.msg || "更新失败", type: 'error' })
      }
      this.getWorkFlowInfo()
    },
    // 删除工作流程
    async deleteStatu(info = {}) {
      const deleteResult = await this.confirmBeforeOperate(`确认删除状态-${info.name}`);
      if(!deleteResult) {return false;}
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.work_status_fow.statu_delete, {...info, projectId: this.projectId})
      } catch(_) {
        result = _;
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "删除成功", type: 'success' })
      } else {
        this.$message({ message: result.msg || "删除失败", type: 'error' })
      }
      this.getWorkFlowInfo()
    },
    // 操作前的确认
    async confirmBeforeOperate(text = '') {
      let result = null
      try {
        result = await this.$confirm(text, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: 'warning'
        })
      } catch (_) {
        result = false;
      }
      return result;
    },
    // 流转状态 - 新增
    async addItem(target, source) {
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.work_status_fow.rule_create, {
          projectId: this.projectId,
          tmplId: source.tmplId,
          fromId: source.statusId,
          toId: target.statusId
        })
      } catch (_) {}
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "新增成功", type: 'success' })
      } else {
        this.$message({ message: result.msg || "新增失败", type: 'error' })
      }
      document.documentElement.click()
      this.getWorkFlowInfo()
    },
    // 流转状态 - 删除
    async removeItem(target, source) {
      this.loading = true;
      let result = {}
      try {
        result = await $http.post($http.api.work_status_fow.rule_delete, {
          projectId: this.projectId,
          tmplId: source.tmplId,
          fromId: source.statusId,
          toId: target.statusId
        })
      } catch(_) {
        result = _;
      }
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || "删除成功", type: 'success' })
      } else {
        this.$message({ message: result.msg || "删除失败", type: 'error' })
      }
      document.documentElement.click()
      this.getWorkFlowInfo()
    },
    // 切换顶部 header
    headerCardChange(activeType) {
      this.activeType = activeType;
    },
    // 复制工作流 - 开/关 dialog
    cloneDialogHandle() {
      this.cloneWorkFlowModalStatus = !this.cloneWorkFlowModalStatus;
    },
    // 复制工作流 - 成功回调
    workflowCloneSuccess() {
      this.getWorkFlowInfo();
      this.cloneDialogHandle();
    },
    // 工作流公开/关闭公开, 增加 try catch 是为了处理服务器 500 错误，以后都增加一个
    async setPublicClickHandle() {
      const msg = this.asPublic?'取消':'设置'
      const confirmResult = await this.confirmBeforeOperate(`确定${msg}当前工作流公开`);
      if(!confirmResult) {return false;}
      this.loading = true;
      let result = {}
      try {
        result = await await $http.post($http.api.work_status_fow.flow_public, {
          projectId: this.projectId,
          tmplId: this.tmplId,
          workItemType: this.activeType,
          toPublic: !this.asPublic
        })
      } catch (_) {}
      this.loading = false;
      if(result.status === 200) {
        this.$message({ message: result.msg || msg + "成功", type: 'success' })
        this.asPublic = !this.asPublic;
      } else {
        this.$message({ message: result.msg || msg + "失败", type: 'error' })
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  @import '../../../base/style/common.scss';

  // 头部
  .flow-header {
    display: flex;
    flex-flow: row nowrap;
    justify-content: space-around;
    margin: 10px 0 20px;
    .flow-header-item {
      font-size: $font-size-large;
      color: $color-font-inactive-common;
      height: 70px;
      line-height: 70px;
      width: 200px;
      text-align: center;
      cursor: pointer;
      box-sizing: border-box;
      // border: 1px solid $color-border-bar;
      background-color: $color-inactive-background-common;
    }
    .flow-header-item-active {
      background-color: $color-active-background-common;
      position: relative;
      &:after {
        content: "";
        position: absolute;
        bottom: -8px;
        left: 45%;
        z-index: 2;
        width: 0;
        height: 0;
        border: 8px solid;
        border-color: $color-active-background-common;
        transform: rotate(45deg);
      }
    }
  }
  // 表格
  .flow-table-box {
    .flow-table-header {
      margin: 10px 0;
    }
    .flow-table-body {
      .flow-table-body-coloritem {
        position: relative;
        top: 2px;
      }
    }
    .operatebtn {
      cursor: pointer;
      color: $color-font-active-common;
    }
  }
  // 流转状态设置
  .flow-staturule-box {
    margin-top: 20px;
    .flow-staturule-box-header {
      height: 40px;
      line-height: 40px;
      font-size: $font-size-medium-x;
    }
  }
</style>
