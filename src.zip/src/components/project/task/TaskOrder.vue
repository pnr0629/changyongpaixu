<template>
  <div class="custom-order-box">
    <field-edit v-bind="FieldEditProps" :onChange="onFilterChange" class="custom-order-input"></field-edit>
    <span class="field-edit-asside">
      <i v-if='FieldEditProps.initValue !=="null" ' :class="headerIconClass" class="header-icon-class"
        @click="headerIconClick"></i>
    </span>
  </div>
</template>
<script>
  /**
   * @title 任务排序
   * @desc 
   * @author heyunjiang
   * @date 2019.7.29
   */
  import FieldEdit from '../../tool/FieldEdit'
  export default {
    name: "TaskOrder",
    components: {
      FieldEdit
    },
    mixins: [],
    props: {},
    data() {
      return {
        isSortAsc: true,    // 排序是否是升序
        FieldEditProps: {    // FieldEdit 组件 prop
          fieldType: 'select',
          initValue: 'null',
          selectValue: [
            { key: 'null', value: '默认排序' },
            { key: 'createTime', value: '创建时间' },
            { key: 'endTime', value: '结束时间' },
            { key: 'updateTime', value: '修改时间' },
            { key: 'priority', value: '优先级' },
          ]
        }
      }
    },
    computed: {
      headerIconClass: function () {
        return this.isSortAsc ? 'el-icon-arrow-down' : 'el-icon-arrow-up' // 后续再定方向
      }
    },
    watch: {},
    created() { },
    methods: {
      headerIconClick() {
        this.isSortAsc = !this.isSortAsc;
        this.$nextTick(function () {
          this.onFilterChange(this.FieldEditProps.initValue)
        })
      },
      onFilterChange(value) {
        let order = null;
        if (value !== 'null') {
          order = [{
            column: value,
            order: this.isSortAsc ? 'DESC' : 'ASC'
          }]
        } else {
          order = null;
        }
        this.FieldEditProps.initValue = value;
        this.$emit('orderChange', order)
      }
    }
  }
</script>
<style lang="scss" scoped>
  .custom-order-box {
    height: 28px;
    line-height: 28px;
    width: 200px;
    padding: 4px 0 8px;
    color: #40aaff;
  }

  .custom-order-input {
    vertical-align: middle;
  }

  .header-icon-class {
    cursor: pointer;

    &:hover {
      background-color: #ccc;
    }

    vertical-align: middle;
  }
</style>