<template>
  <div id="taskview">
    <header-filter :projectId="projectId" @newTaskBtnClick="newTaskBtnClick" @exportExcel="exportExcel" @orderChange="orderChange"
      :orderBtnShow="changeStatus!=='2'" @filterClick="selectHandle" @sprintTypeFun='sprintTypeFun'></header-filter>
    
    <el-tabs v-model="changeStatus" @tab-click="changePageHandle" class="footer-tab" type="border-card">
      <el-tab-pane label="状态视图" name="1">
        <div class="flexpaly scrollbal-common" v-show="changeStatus==='1'">
          <template v-for="item in statusViewDate.lane">
            <div class="flexpaly-item" :key="item.name">
              <div class="color">
                <span class="pending-disposal">{{item.name}}</span>
                <span v-show="changeStatus==='1'"
                  class="pending-disposal1">({{statusViewDate.task [item.name]?statusViewDate.task[item.name].length : 0 }})</span>
                <!-- <span class="el-icon-plus task-icon"></span> -->
              </div>
              <draggable class="box1" v-model="statusViewDate.task[item.name]"
                :options="{group:'people'}" @start="drag=false" @end="endHandle" :move="checkMove" :data-class="item.statusId">
                <div class="color-text" ref="boxBorder" :style="{backgroundColor:element.display.delayed?'#FFCC99':''}"
                  @click.stop="sendTaskHandle(element,$event)" :data-priority="element.display.assignUser"
                  v-for="element in statusViewDate.task[item.name]" :key="element.id" :data-id="element.id"
                  :data-statusId="element.statusId">
                  <p class="card-title">
                    <i :data-id="element.id" class="cp icon-title">{{element.display.title}}</i>
                  </p>
                  <p v-show="element.display&&element.display.parentTitle" class="card-title-parent ellipsis">
                    父需求：{{element.display&&element.display.parentTitle}}</p>
                  <div class="card-info" style="position:relative;bottom:2px;">
                    <span class="cursor-pointer fl task-priority"
                      v-html="initNameStatus(element.display.detail.priority.color,element.display.detail.priority.literal)"></span>
                    <span class="person">{{element.display.assignUser}}</span>
                    <div class="time" ref="time">{{element.endTime}}</div>
                  </div>
                </div>
              </draggable>
            </div>
          </template>
        </div>
      </el-tab-pane>
      <el-tab-pane label="人员视图" name="3">
        <div v-show="changeStatus==='3'" class="person-view">
          <div class="scoll-box" v-show="isScoll">
            <span class="scoll-bar"></span>
          </div>
          <div class="person-view-header">
            <div class="over-flow" v-for="(item,index) in personData.lane" :key="index">
              <div class="color">
                <span class="pending-disposal">{{item.name}}</span>
                <span v-show="changeStatus==='3'" class="pending-disposal1"></span>
              </div>
            </div>
          </div>
          <div class="person-view-content">
            <div v-for="(row,keyVal) in personData.task" :key="keyVal" style="border-bottom: 1px solid;">
              <div class="box">{{keyVal}}</div>
              <draggable class="box5" v-model="row.未处理" v-for="(item,index) in personData.lane"
                :data-class="item.statusId" :options="{group:keyVal}" @start="drag=false" @end="endHandle" :move="checkMove" :key="index">
                <!-- {{jtem}} -->
                <div class="color-text1" style="left:-4px;" @click.stop="sendTaskHandle(element,$event)"
                  v-for="element in row[item.name]" :key="element.id"
                  :style="{backgroundColor:element.display.delayed?'#FFCC99':''}" :data-id="element.id"
                  :data-statusId="element.statusId">
                  <p class="card-title">
                    <i :data-id="element.id" class="cp icon-title">{{element.display.title}}</i>
                  </p>
                  <p v-show="element.display&&element.display.parentTitle" class="card-title-parent ellipsis">
                    父需求：{{element.display&&element.display.parentTitle}}</p>
                  <div class="card-info" style="position:relative;bottom:2px;">
                    <span class="cursor-pointer fl task-priority"
                      v-html="initNameStatus(element.display.detail.priority.color,element.display.detail.priority.literal)"></span>
                    <span class="person">{{element.display.assignUser}}</span>
                    <div class="time" ref="time3">{{element.endTime}}</div>
                  </div>
                </div>
              </draggable>
            </div>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="列表视图" name="2">
        <div class="listView" v-if="changeStatus==='2'">
          <template>
            <el-table :data="taskList" border @sort-change="sortaChangeCallBack" style="width: 100%;">
              <el-table-column prop="id" show-overflow-tooltip label="任务ID" width="72px">
                <template slot-scope="scope">
                  <span @click.stop="sendTaskHandle(scope.row)" class="title-link-common cp c-blue-hover"
                    slot>{{scope.row.id}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="display.title" show-overflow-tooltip label="任务标题" min-width="400px">
                <template slot-scope="scope">
                  <global-input :initValue="scope.row.display.title"
                    :onChange="(value)=>{GlobalTaskUpdate({title: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTaskList})}">
                    <span @click.stop="sendTaskHandle(scope.row)"
                      class="table-input-edit-text title-link-common cp c-blue-hover"
                      slot>{{scope.row.display.title}}</span>
                  </global-input>
                </template>
              </el-table-column>
              <el-table-column prop="priority" sortable="custom" show-overflow-tooltip label="优先级" width="90">
                <template slot-scope="scope">
                  <span class="cursor-pointer"
                    v-html="initNameStatus(scope.row.display.detail.priority.color,scope.row.display.detail.priority.literal)"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'priority', getTaskList)">
                    <span class="mini-circle" :style="{backgroundColor:scope.row.display.detail.priority.color}"></span>
                    {{scope.row.display.priority}}
                  </span>
                </template>
              </el-table-column>
              <el-table-column prop="sprintId" sortable="custom" show-overflow-tooltip label="迭代" width="160">
                <template slot-scope="scope">
                  <span class="cursor-pointer table-column-padding"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'sprintId', getTaskList)">{{scope.row.display.sprint}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="assignUser" sortable="custom" show-overflow-tooltip label="处理人" width="160">
                <template slot-scope="scope">
                  <span class="cursor-pointer table-column-padding"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'assignUser', getTaskList)">{{scope.row.display.assignUser}}({{scope.row.assignUser}})</span>
                </template>
              </el-table-column>
              <el-table-column prop="statusId" sortable="custom" show-overflow-tooltip label="状态" width="80">
                <template slot-scope="scope">
                  <span class="cursor-pointer"
                    v-html="initNameStatus(scope.row.display.detail.status.color,scope.row.display.status)"
                    @click.stop="(e) => GlobalSelectTargetClick(scope.row, e, 'statusId', getTaskList)"></span>
                </template>
              </el-table-column>
              <!-- <el-table-column prop="progress" sortable="custom" show-overflow-tooltip label="进度(%)" width="100">
                <template slot-scope="scope">
                  <global-input :initValue="scope.row.progress || ''" inputType="progress"
                    :onChange="(value)=>{GlobalTaskUpdate({progress: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTaskList})}">
                    <span slot>{{scope.row.progress==undefined?'--':scope.row.progress}}</span>
                  </global-input>
                </template>
              </el-table-column> -->
              <el-table-column prop="endTime" sortable="custom" show-overflow-tooltip label="预计结束时间" width="125">
                <template slot-scope="scope">
                  <global-input :initValue="scope.row.endTime || ''" inputType="time"
                    :onChange="(value)=>{GlobalTaskUpdate({endTime: value, id: scope.row.id, projectId: scope.row.projectId, cb: getTaskList})}">
                    <span slot>{{scope.row.endTime || '--'}}</span>
                  </global-input>
                </template>
              </el-table-column>
              <el-table-column label="操作" show-overflow-tooltip width="100">
                <template slot-scope="scope">
                  <span class="link-common cp" @click.stop="sendTaskHandle(scope.row)">编辑</span>
                  <span class="link-common cp" @click="deleteTaskHandle(scope.row)">删除</span>
                </template>
              </el-table-column>
            </el-table>
            <!-- <div class="table_b_f_b">
              <el-pagination class="fr mr10 pageination-top" @size-change="handleTaskListSizeChange"
                             @current-change="handleTaskListPageChange" :current-page="taskListPageInfo.pageNumber" :page-sizes="[10, 20, 30]"
                             :page-size="taskListPageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="taskListPageInfo.total">
              </el-pagination>
            </div> -->
            <div class="table_b_f_b">
              <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleTaskListSizeChange"
                @current-change="handleTaskListPageChange" :current-page="taskListPageInfo.pageNumber"
                :page-sizes="[15, 30, 50]" :page-size="taskListPageInfo.pageSize"
                layout="total, sizes, prev, pager, next, jumper" :page-count="taskListPageInfo.totalPages">
              </el-pagination>
            </div>
          </template>
        </div>
      </el-tab-pane>
    </el-tabs>

    <slide :show="show" ref="side" :afterClose="HandleSide"
      :beforeClose="({cb}) => beforeSliderClose({ id: taskId, cb})" v-loading="loading" element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading" element-loading-background="rgb(255,255,255)">
      <div slot="task" class="taslinfo">
        <task-detail :taskId="taskId" :show="show" v-on:sendDate="sendDate" :restore="restore"
          v-on:HandleSide="HandleSide" @handlePririty="handlePririty" :operateCallback="refreshList"
          :titleNotice.sync="sliderBeforeCloseData.title" :descNotice.sync="sliderBeforeCloseData.desc"></task-detail>
      </div>
    </slide>
    <slide :show="taskAddSlideStatus.taskAddSlideProps.show"
      :afterClose="taskAddSlideStatus.taskAddSlideProps.afterClose"
      :beforeClose="({cb}) => beforeSliderClose({ id: -2, cb})" v-loading="taskAddSlideStatus.loading"
      element-loading-text="拼命加载中" element-loading-spinner="el-icon-loading"
      element-loading-background="rgb(255,255,255)">
      <div slot="task" class="taslinfo">
        <task-add :show="taskAddSlideStatus.taskAddSlideProps.show" @HandleSide="newTaskHandleClose"
          @HandleAddSuccess="newTaskHandleClose(true)" :projectId="getUrlParams().projectId"
          :titleNotice.sync="sliderBeforeCloseData.title" :descNotice.sync="sliderBeforeCloseData.desc"></task-add>
      </div>
    </slide>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
    <back-top :show="changeStatus==='3'"></back-top>
  </div>
</template>

<script>
  /**
   * 任务视图，也就是任务列表
   */
  import draggable from "vuedraggable";
  import slide from "components/tool/slideSlip";
  // import taskEdit from './taskEdit.vue'
  import HeaderFilter from "./HeaderFilter"
  import taskDetail from "./taskDetail.vue";
  import TaskOrder from "./TaskOrder";
  import TaskAdd from "./TaskAdd.vue";
  import GlobalSelect from "../../tool/FieldEdit/GlobalSelect.vue";
  import GlobalInput from "../../tool/FieldEdit/GlobalInput.vue";
  import ProjectCommonMixin from "../ProjectCommonMixin";
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import SprintMultipleSelect from "@/components/commonComponents/SprintMultipleSelect";

  export default {
    name: "demandView",
    components: {
      draggable,
      slide,
      // taskEdit
      taskDetail,
      GlobalSelect,
      GlobalInput,
      TaskAdd,
      TaskOrder,
      SprintMultipleSelect,
      HeaderFilter
    },
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    data() {
      return {
        //区分迭代归档未归档过滤信息
        isArchived:0, 
        projectId: this.getUrlParams().projectId,
        onlyDelay:false,//延期的任务
        isScoll: "", //滚动条是否显示
        loading: false,
        isnoshow: false,
        taskStatus: 1,
        allSprint: -1,
        allassignUser: null,
        Unplanned: 0,
        StatusNumerone: "",
        StatusNumertwo: "",
        StatusNumerthree: "",
        StatusNumerfour: "",
        sprintData: [],
        personchange: false,
        personName: [],
        personData: {
          task: []
        },
        show: false,
        count: 0,
        restore: 1,
        preID: null,
        isShow: false,
        taskId: null,
        //页面切换的值
        changeStatus: "1",
        value: "",
        value1: "", //时间绑定
        statusDate: "", //下拉绑定
        labelPosition: "right",
        taskList: [],
        screenHeight: "",
        //切换选项切换绑定的值
        radio3: "",
        radio2: "",
        // screenHeight:"",
        screenWidth: document.body.clientWidth,
        // 标题框绑定的值
        formInline: {
          projectId: null,
          sprintIds: [],
          assignUsers: [],
          orderBy: null,
          requireIds: [],
        },
        isOnlyMineTask: false, // 是否仅我的任务
        statusViewDate: [],
        assignUserData: [],
        // 分页及排序信息 - add by heyunjiang on 2019.5.8
        pageInation: {
          orderBy: null,
          pageInfo: {
            pageNumber: 1,
            pageSize: 10
          }
        },

        taskListPageInfo: {
          pageNumber: 1,
          totalPages: 0,
          pageSize: 18
        },
        // 创建任务 slider 状态信息
        taskAddSlideStatus: {
          taskAddSlideProps: {
            show: false,
            beforeClose: () => { },
            afterClose: this.newTaskHandleClose
          },
          loading: false
        },
        requirementData: [],
        search:"",
      };
    },
    computed: {
      // 权限 - 是否可以编辑
      editAble() {
        return this.authFunction('FUNC_COOP_TASK_DELETE', 3, this.projectId)
      },
      // 权限 - 是否可以删除
      deleteAble() {
        return this.authFunction('FUNC_COOP_TASK_DELETE', 3, this.projectId)
      }
    },
    watch: {
      show: function (newName, oldName) {
        if (newName) {
          this.$router.replace({ path: this.$route.path, query: { ...this.$route.query, taskId: this.taskId } })
        }
      },
      screenWidth(val) {
        // 为了避免频繁触发resize函数导致页面卡顿，使用定时器
        if (!this.timer) {
          // 一旦监听到的screenWidth值改变，就将其重新赋给data里的screenWidth
          this.screenWidth = val;
          this.timer = true;
          let that = this;
        }
      }
    },
    mounted() {
      // document.body.ondrop = function(event) {
      //   event.preventDefault();
      //   event.stopPropagation();
      // };
      this.getRequiremenList();
      this.getAssignUser();
      this.getSprintName();
      this.getTaskView();
      this.isTaskId = {
        id: this.getUrlParams().taskId
      };
      if (this.isTaskId.id) {
        this.sendTaskHandle(this.isTaskId);
      }
      const that = this;
      window.onresize = () => {
        return (() => {
          window.screenWidth = document.body.clientWidth;
          that.screenWidth = window.screenWidth;
        })();
      };
      this.screenHeight = window.screen.availHeight;
    },
    beforeRouteLeave(to, from, next) {
      // 如果存在内容在编辑，则不能离开
      if (this.sliderBeforeCloseData.title || this.sliderBeforeCloseData.desc) {
        return false;
      }
      next()
    },
    destroyed() {
      document.getElementById("sidebar").style.height = 100 + "%";
    },
    watch: {
      search(){
        this.getRequiremenList()
      },
      show: function (newName, oldName) {
        if (newName) {
          this.$router.replace({ path: this.$route.path, query: { ...this.$route.query, taskId: this.taskId } })
        }
      },
      screenWidth(val) {
        // 为了避免频繁触发resize函数导致页面卡顿，使用定时器
        if (!this.timer) {
          // 一旦监听到的screenWidth值改变，就将其重新赋给data里的screenWidth
          this.screenWidth = val;
          this.timer = true;
          let that = this;
        }
      }
    },
    methods: {
      //获取迭代过滤器类型
      sprintTypeFun(val){
        this.isArchived = val;
        // console.log('isArchived',val)
        
      },
      //获取赛选的需求列表
      getRequiremenList() {
        $http.get($http.api.task.requirement_list, { projectId: this.getUrlParams().projectId ,query:this.search}).then(res => {
          this.requirementData = res.data;
        })
      },
      // 排序
      orderChange(value) {
        this.formInline.orderBy = value;
        this.$nextTick(this.selectHandle);
      },
      //延期的任务
      deferreDtask() {
        this.onlyDelay = !this.onlyDelay;
        this.$nextTick(this.selectHandle)
      },
      // 导出 excel
      exportExcel() {
        let projectId = this.getUrlParams().projectId;
        let list = {
          projectId,
          assignUsers: this.formInline.assignUsers,
          sprintIds: this.formInline.sprintIds,
          "orderBy": this.pageInation.orderBy,
          "pageInfo": {
            "pageNumber": this.taskListPageInfo.pageNumber,
            "pageSize": this.taskListPageInfo.pageSize
          },
          requireIds:this.formInline.requirementId
        };
        this.fileDownLoadForGet($http.api.task.task_export.url, list, { projectId })
      },
      refreshList() {
        if (this.changeStatus == 1) {
          this.getTaskView();
        } else if (this.changeStatus == 2) {
          this.getTaskList();
        } else if (this.changeStatus == 3) {
          this.getPersonView();
        }
      },
      // 新建任务 - 点击新建任务按钮
      newTaskBtnClick() {
        this.taskAddSlideStatus.taskAddSlideProps.show = true;
      },
      // 新建任务 - 关闭
      newTaskHandleClose(bool = false) {
        this.taskAddSlideStatus.taskAddSlideProps.show = false;
        bool && this.selectHandle()
      },
      //自定义人员横向滚动条
      personCustomScoll() {
        this.$nextTick(() => {
          var boxl = document.getElementsByClassName("person-view")[0];
          var box = document
            .getElementsByClassName("person-view")[0]
            .getBoundingClientRect().width;
          var header = document.getElementsByClassName("person-view-header")[0];
          var content = document
            .getElementsByClassName("person-view-content")[0]
            .getBoundingClientRect().width;
          var contentw = document.getElementsByClassName(
            "person-view-content"
          )[0];
          var scollBox = document.getElementsByClassName("scoll-box")[0];
          var scollbar = document.getElementsByClassName("scoll-bar")[0];

          // console.log(document.getElementById('sidebar'))
          let height = contentw.getBoundingClientRect().height;
          let screenHeight = document.documentElement.clientHeight;
          let screenWidth = document.documentElement.clientWidth;
          boxl.style.height = contentw.getBoundingClientRect().height + 57 + "px";

          if (content > screenWidth) {
            this.isScoll = true;
          }
          if (height > screenHeight) {
            // document.getElementById("sidebar").style.height = height + "px";
          } else {
            document.getElementById("sidebar").style.height = document.getElementById("main-content").style.minHeight + "px";
          }
          if (this.isScoll) {
            var scollbar_len = (box / content) * box;
            scollbar.style.width = scollbar_len + "px";
            scollbar.onmousedown = function (e) {
              var beginX = e.clientX - scollbar.offsetLeft;
              document.onmousemove = function (e) {
                e = e || event;
                var endX = e.clientX - beginX;
                if (endX < 0) {
                  endX = 0;
                }
                if (endX >= box - scollbar.offsetWidth) {
                  endX = box - scollbar.offsetWidth;
                }
                scollbar.style.left = endX + "px";
                //内容走的距离 = （内容的长度 - 盒子的长度 ）/ （盒子的长度 - 滚动条的长度）*滚动条走的距离
                var contentL =
                  ((content - box) / (box - scollbar.offsetWidth)) * endX;
                contentw.style.left = -contentL + "px";
                header.style.left = -contentL + "px";
                window.getSelection
                  ? window.getSelection().removeAllRanges()
                  : document.selection.empty(); //防止拖动时选中内容
              };
              document.onmouseup = function (e) {
                e = e || event;
                document.onmousemove = null;
              };
            };
            var p = 0,
              t = 0,
              start_scoollbox_t = 0,
              start_scollbar_t = 0,
              start_header_t = 0;
            var finsh_scoollbox_t = 0,
              finsh_scollbar_t = 0,
              finsh_header_t = 0;
            start_scoollbox_t = scollBox.offsetTop;
            start_scollbar_t = scollbar.offsetTop;
            start_header_t = header.offsetTop;
            document.removeEventListener("scoll", scoll);
            document.addEventListener("scroll", scoll);
            function scoll(e) {
              var scrollTop =
                document.documentElement.scrollTop ||
                window.pageYOffset ||
                document.body.scrollTop;
              p = scrollTop;
              if (t <= p) {
                if (scrollTop >= 200) {
                  scollBox.style.width = box + "px";
                  scollBox.style.marginLeft = 110 + "px";
                  scollBox.style.position = "fixed";

                  header.style.position = "fixed";
                  header.style.marginLeft = 210 + "px";
                  return;
                  contentw.style;
                }
              } else {
                if (scrollTop <= 0) {
                  return;
                } else if (scrollTop <= 200 && scrollTop >= 0) {
                  scollBox.style.width = 100 + "%";
                  scollBox.style.marginLeft = 0;
                  scollBox.style.position = "absolute";
                  header.style.position = "absolute";
                  header.style.marginLeft = 110 + "px";
                }
              }
              setTimeout(function () {
                t = p;
              }, 0);
            }
          }
        })
      },
      // 获取状态视图
      getTaskView(filterInfo = {}) {
        this.formInline.projectId = this.getUrlParams().projectId;
        let status = {
          projectId: this.formInline.projectId || null,
          assignUsers: this.formInline.assignUsers || null,
          sprintIds: this.formInline.sprintIds || null,
          onlyDelay: this.onlyDelay,
          orderBy: this.formInline.orderBy,
          requireIds:this.formInline.requirementId,
          isArchived:this.isArchived
        };
        for (let i in this.formInline) {
          if (Array.isArray(this.formInline[i]) && this.formInline[i].length > 0) {
            if (this.formInline[i].includes("all")) {
              status[i] = []
            }
          }
        }
        this.loading = true;
        if(filterInfo.sprintIds){
          filterInfo.sprintIds = filterInfo.sprintIds.filter( item =>[-1,-2,-3,-4,-5].indexOf(item)==-1);
        }
        
        $http.post($http.api.task.task_view, {...status, ...filterInfo}).then(res => {
          this.loading = false;
          this.statusViewDate = res.data;
          this.taskViewHeight();
        });
      },
      //获取人员视图
      // 排序过滤
      sortaChangeCallBack(obj) {
        if (obj.prop) {
          this.pageInation.orderBy = [
            {
              column: obj.prop,
              order: obj.order === "descending" ? "DESC" : "ASC"
            }
          ];
        } else {
          this.pageInation.orderBy = [];
        }
        this.$nextTick(this.getTaskList);
      },
      //展开过滤条件
      onshowFrom() {
        this.isnoshow = false;
      },
      //收缩过滤条件
      onhideFrom() {
        this.isnoshow = true;
      },
      //仅我的查询
      userserch() {
        let user = $utils.getStorage(GLOBAL_CONST.USER_INFO);
        this.formInline.assignUsers = [user.userId];
        this.isOnlyMineTask = true;
        this.$nextTick(this.selectHandle)
      },
      taskViewHeight() {
        let dom = document.getElementsByClassName("box1");
        setTimeout(() => {
          for (let i = 0; i < dom.length; i++) {
            dom[i].style.minHeight = this.screenHeight - 369 + "px";
            dom[i].style.maxHeight = this.screenHeight - 369 + "px";
          }
        });
      },
      handlePririty() {
        let user = $utils.getStorage(GLOBAL_CONST.USER_INFO).userName;
      },
      HandleSide(e) {
        if (this.show) {
          this.show = false;
          this.count = 0;
          this.restore = Math.random() * 10;
          this.taskId = -1;
          // this.$refs.side.style.right = -51 + '%';
        }
        //隐藏上传&关联文档tips doc-upload
        this.publicHideTips(e)
      },
      remoteMethod(query) {
        this.getAssignUser(query);
      },
      // 查询任务数据 状态视图、人员视图、列表视图
      selectHandle(filterInfo) {
        // if (value && isCustom) {
        //   if (isCustom === 'assignUsers') { this.isOnlyMineTask = false; }
        //   let filterData = this.formInline;
        //   // 如果最后一个选中了全部
        //   if (value[value.length - 1] === "all") {
        //     filterData[isCustom] = ["all"];
        //     //this.formInline[isCustom] = [];
        //   }
        //   // 如果不是最后一个选中了全部
        //   if (
        //     filterData[isCustom].includes("all") &&
        //     filterData[isCustom].length > 1
        //   ) {
        //     filterData[isCustom] = filterData[isCustom].filter(
        //       item => item !== "all"
        //     );
        //   }
        // }
        if (this.changeStatus == 2) {
          this.getTaskList(filterInfo);
          document.getElementById("sidebar").style.height = 100 + "%";
        } else if (this.changeStatus == 1) {
          this.getTaskView(filterInfo);
          document.getElementById("sidebar").style.height = 100 + "%";
        } else if (this.changeStatus == 3) {
          this.getPersonView(filterInfo);
        }
      },
      sendDate() { },
      sendSelectHandle() {
        if (this.changeStatus == 2) {
          this.getTaskList();
        } else if (this.changeStatus == 1) {
          this.getTaskView();
        } else if (this.changeStatus == 3) {
          this.getPersonView();
          this.handlePririty();
        }
      },
      inputHandle() {
        //this.getSprintName()
      },
      getSprintName() {
        let projectId = this.getUrlParams().projectId;
        $http
          .get($http.api.sprint.list_sprint_name, { projectId, status: 1 })
          .then(res => {
            this.sprintData = res.data;
          });
      },
      getAssignUser(query) {
        let projectId = this.getUrlParams().projectId;
        // let query = this.formInline.assignUser
        let assData = {
          projectId: projectId,
          query: query || null
        };
        $http.post($http.api.project.assignUser, assData).then(res => {
          //todo cpp 这里应该获取自己的queryType=1
          this.assignUserData = res.data.map(item => {
            return {
              ...item,
              key: item.userId,
              value: item.userName + '(' + item.userId + ')'
            }
          });
        });
      },
      sendTaskHandle(data, e) {
        if (this.count === 0) {
          this.preID = data.id;
          this.show = !this.show;
          this.taskId = Number(data.id);
          this.restore = Math.random() * 10;
          // e.currentTarget.style.backgroundColor = '#93c36b';
          this.count++;
        } else {
          if (this.preID !== data.id) {
            this.preID = Number(data.id);
            // e.currentTarget.style.backgroundColor = '#93c36b';
            // this.show = !this.show;
            this.taskId = Number(data.id);
            this.restore = Math.random() * 10;
            if (this.changeStatus == 1) {
              this.getTaskView();
            } else if (this.changeStatus == 2) {
              this.getTaskList();
            } else if (this.changeStatus == 3) {
              this.getPersonView();
            }
          } else {
            // e.currentTarget.style.backgroundColor = '#93c36b';
            this.restore = Math.random() * 10;
            this.preID = Number(data.id);
            this.count = 0;
            this.show = !this.show;
            this.taskId = Number(data.id);
          }
        }
      },
      deleteTaskHandle(data) {
        this.$confirm("此操作将删除该数据, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            $http.get($http.api.task.deleteTask, { id: data.id }).then(res => {
              if (res.status === 200) {
                this.getTaskList();
              } else {
                this.$message({ message: res.msg, type: "error" });
              }
            });
          })
          .catch(() => { });
      },
      checkMove(ev){
        return ev.from.getAttribute("data-class") !== ev.to.getAttribute("data-class");
      },
      endHandle(ev) {
        let a = parseInt(ev.from.getAttribute("data-class"));
        let b = parseInt(ev.to.getAttribute("data-class"));
        let id = parseInt(ev.item.getAttribute("data-id"));
        // 如果拖到其他泳道
        if (a !== b ) {
          $http
            .post($http.api.task.taskUpdate, { id, statusId: b })
            .then(res => {
              if (res.status === 200) {
                this.$message({
                  message: res.msg || "操作成功",
                  type: "success"
                });
              } else {
                this.$message({ message: res.msg || "操作失败", type: "error" });
              }
              if (this.changeStatus === "1") {
                this.getTaskView();
              } else if (this.changeStatus === "3") {
                this.getPersonView();
              }
            })
            .catch(e => {
              if (this.changeStatus === "1") {
                this.getTaskView();
              } else if (this.changeStatus === "3") {
                this.getPersonView();
              }
            });
        }
      },
      onSubmit() { },
      changePageHandle(index) {
        // this.changeStatus = this.taskStatus;
        this.selectHandle();
      },
      handleTaskListSizeChange(val) {
        this.taskListPageInfo.pageSize = val;
        this.getTaskList();
      },
      handleTaskListPageChange(val) {
        this.taskListPageInfo.pageNumber = val;
        this.getTaskList();
        // console.log( this.taskListPageInfo.pageNum)
      },

      // 获取任务列表
      getTaskList(filterInfo = {}) {
        // let pageInfo = {
        //   pageNumber: this.taskListPageInfo.pageNumber,
        //   pageSize: this.taskListPageInfo.pageSize
        // };
        this.formInline.projectId = this.getUrlParams().projectId;
        let list = {
          projectId: this.formInline.projectId,
          assignUsers: this.formInline.assignUsers,
          sprintIds: this.formInline.sprintIds,
          onlyDelay: this.onlyDelay,
          requireIds: this.formInline.requirementId,
          isArchived:this.isArchived,
          "orderBy": this.pageInation.orderBy,
          "pageInfo": {
            "pageNumber": this.taskListPageInfo.pageNumber,
            "pageSize": this.taskListPageInfo.pageSize
          },
          ...filterInfo
        };
        for (let i in this.formInline) {
          if (Array.isArray(this.formInline[i]) && this.formInline[i].length > 0) {
            if (this.formInline[i].includes("all")) {
              list[i] = []
            }
          }
        }
        this.loading = true;
        list.sprintIds = list.sprintIds.filter(item => [-1,-2,-3,-4,-5].indexOf(item)==-1);
        $http.post($http.api.task.taskList, list).then(res => {
          this.loading = false;
          //todo cpp 这里应该获取自己的queryType=1
          this.taskList = res.data.result;
          this.taskListPageInfo = res.data.pageInfo;
        });
      },
      // 获取人员视图
      getPersonView(filterInfo = {}) {
        this.formInline.projectId = this.getUrlParams().projectId;
        let person = {
          projectId: this.formInline.projectId,
          assignUsers: this.formInline.assignUsers,
          sprintIds: this.formInline.sprintIds,
          onlyDelay: this.onlyDelay,
          requireIds: this.formInline.requirementId,
          orderBy: this.formInline.orderBy,
          isArchived:this.isArchived
        };
        for (let i in this.formInline) {
          if (Array.isArray(this.formInline[i]) && this.formInline[i].length > 0) {
            if (this.formInline[i].includes("all")) {
              person[i] = []
            }
          }
        }
        this.loading = true;
        person.sprintIds = person.sprintIds.filter(item => [-1,-2,-3,-4,-5].indexOf(item)==-1);
        $http.post($http.api.task.person_view, {...person, ...filterInfo}).then(res => {
          this.loading = false;
          this.personData.task = {};
          this.$nextTick(() => {
            this.personData = res.data;
            this.personCustomScoll();
          });
        });
      }
    }
  };
</script>
<style lang="scss" scoped>
  @import "../../../base/style/common";

  .person-view {
    overflow: hidden;
    position: relative;

    .scoll-box {
      width: 100%;
      height: 8px;
      background: #e8e8e8;
      border-radius: 8px;
      /* position: relative; */
      /* margin-left: 100px; */
      position: absolute;
      top: 0;
      left: 0;
      z-index: 3;

      /* padding-bottom:4px; */
      .scoll-bar {
        height: 8px;
        position: absolute;
        top: 0;
        left: 0;
        /* margin-left: 100px; */
        cursor: pointer;
        background: #000;
        border-radius: 8px;
        z-index: 3;
      }
    }

    .person-view-header {
      left: 0;
      top: 8px;
      width: max-content;
      position: absolute;
      overflow-y: auto;
      margin-left: 110px;
      z-index: 3;
    }

    .person-view-content {
      left: 0;
      top: 56px;
      width: max-content;
      position: absolute;
      overflow-y: auto;
    }
  }

  .over-flow {
    /* overflow: hidden; */
    width: 230px;
    display: inline-block;
    margin-left: 10px;
  }

  #taskview .active {
    color: $color-font-active-common;
  }

  #taskview .inactive {
    color: $color-font-inactive-common;
  }

  .taskinfo {
    height: 100%;
  }


  .btntext {
    color: #409eff;
    margin: 0 20px 0 0;
    cursor: pointer;
  }

  .content {
    height: 100%;
  }

  .btnBox {
    overflow: hidden;
    margin-left: 300px;
    margin-top: 20px;
  }

  .task-priority {
    margin-left: 9px;
  }

  .box1 {
    width: 230px;
    background-color: #eee;
    height: 100%;
    padding-bottom: 40px;
    overflow-y: auto;
    margin-top: 10px;
  }

  .box1::-webkit-scrollbar {
    width: 8px;
    height: 1px;
  }

  .box1::-webkit-scrollbar-thumb {
    border-radius: 10px;
    box-shadow: inset 0 0 5px rgba(0, 0, 0, 0.2);
    background: #999;
  }

  .box1::-webkit-scrollbar-track {
    background: #eee;
  }

  .box {
    width: 110px;
    min-height: 60px;
    font-size: 22px;
    color: #000;
    font-weight: 900;
    display: inline-block;
    vertical-align: top;
    padding-bottom: 10px;
  }

  .box5,
  .box6,
  .box7,
  .box8 {
    width: 230px;
    min-height: 60px;
    display: inline-block;
    margin-left: 10px;
    vertical-align: top;
    padding-bottom: 10px;
  }

  // 状态视图 - 任务泳道
  .flexpaly {
    display: flex;
    flex-flow: row nowrap;
    overflow-x: auto;
    min-width: 953px;
    height: 100%;

    .flexpaly-item {
      width: 230px;
      margin-left: 10px;

      .task-icon {
        color: #000;
        font-size: 14px;
        font-weight: 900;
        /* margin-left:76px; */
        position: absolute;
        right: 22px;
        top: 14px;
        cursor: pointer;
      }
    }
  }

  .flexpaly-header {
    width: 953px;
    display: flex;
    justify-content: space-around;
    margin-left: 100px;
    align-items: flex-start;
    height: 100%;
  }

  .line {
    margin: 10px 0;
  }

  .flexpaly1 {
    width: 100%;
    overflow: hidden;
    padding: 15px 0;
    border-bottom: 1px double rgba(121, 121, 121, 1);
  }

  .color-text {
    width: 210px;
    margin: 0 auto;
    border-radius: 5px;
    margin-top: 8px;
    overflow: hidden;
    position: relative;
    z-index: 2;
    background-color: #fff;
    cursor: pointer;
  }

  .over {
    overflow: hidden;
    padding-bottom: 8px;
  }

  .color-text1 {
    width: 210px;
    background-color: #eee;
    margin: 0 auto;
    border-radius: 5px;
    margin-top: 8px;
    position: relative;
    z-index: 2;
    cursor: pointer;
  }

  .danger-circle {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 1px solid red;
    float: right;
    position: absolute;
    top: 37px;
    right: 31px;
  }

  .danger-circle1 {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 1px solid rgba(255, 204, 0, 1);
    float: right;
    position: absolute;
    top: 37px;
    right: 31px;
  }

  .box-all {
    width: 300px;
  }

  p {
    margin-top: 3px;
  }

  .person {
    position: absolute;
    left: 50px;
  }

  .ax-box {
    width: 280px;
  }

  .time {
    left: 123px;
    position: absolute;
    width: 40%;
  }

  .color {
    width: 230px;
    background-color: #eee;
    box-sizing: border-box;
    color: #fff;
    font-weight: 900;
    padding-top: 11px;
    /* cursor: pointer; */
    position: relative;
  }

  .pending-disposal {
    text-align: center;
    display: inline-block;
    margin-left: 30px;
    margin-bottom: 11px;
    color: #333;
    font-size: 13px;
  }

  .pending-disposal1 {
    color: #333;
    font-size: 13px;
  }

  .icon {
    margin-left: 88px;
  }

  .viewChange {
    margin-left: 5px;
  }

  .taskView {
    margin-top: 20px;
  }

  .listView {
    width: 100%;
    height: 100%;
    min-height: 1000px;
  }

  .icon-title {
    width: 100%;
    display: inline-block;
    word-break: break-word;
    font-style: normal;
    position: relative;
    padding: 0 8px;
    box-sizing: border-box;
    font-weight: 900;
    top: 4px;
    color: black;
  }

  .reviwe-center {
    width: 100%;
    margin-top: 5px;
    padding: 5px 5px 2px 5px;
    height: auto;
  }

  .demo-form-inline {
    /* overflow: hidden; */
    display: inline-block;
    width: 100%;
  }

  // 新建任务按钮
  .new-button {
    position: relative;
    top: 5px;
    right: 18px;
  }

  // 卡片信息
  .card-info {
    overflow: hidden;
    margin: 0 0 5px 0;
  }

  // 卡片标题
  .card-title {
    margin: 3px 0 5px 0;
  }

  // 父需求
  .card-title-parent {
    margin: 0 0 5px 0;
    font-size: 12px;
    padding-left: 8px;
    color: #909090;
  }
</style>
