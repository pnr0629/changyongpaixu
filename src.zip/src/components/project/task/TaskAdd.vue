<template>
  <div class="detail-content bug-content-box" v-loading="loading" element-loading-text="拼命加载中"
    element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
    <div class="slide-header">
      <span class="taskinfo-title">新建任务</span>
      <div class="slide-header-right">
        <el-button-group>
          <el-button type="default" class="slider-header-btn" @click="handleTaskSave">保存</el-button>
          <el-button type="default" icon="el-icon-close" @click="taskClose"></el-button>
        </el-button-group>
      </div>
    </div>
    <el-row :gutter="10" class="detail-content-body">
      <el-col :xs="16" :sm="16" :md="16" :lg="16" :xl="18">
        <div class="detail-content-left">
          <!-- 标题 -->
          <div class="detail-content-header detail-content-header-inactive" style="padding-left:0;">
            <el-input ref="titleInput" class="title-input-active" placeholder="输入标题" size="large" @input="titleInput"
              v-model="detailInfo.title"></el-input>
            <div v-if="detailInfo.title.length > 50" class="warning warning-title">标题过长，请注意！！！</div>
          </div>
          <div class="detail-content-left-content" refs="bshaow">
            <!-- 缺陷描述 -->
            <tiny-mce :value="detailInfo.content" v-on:watch="editHnadle($event)"></tiny-mce>
          </div>
        </div>
      </el-col>
      <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6">
        <div class="detail-content-right">
          <!-- 基本信息 -->
          <div class="bug-basic-info">
            <p class="bug-basic-info-title">基本信息</p>
            <el-row :gutter="10">
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select">
                  <span class="bug-basic-info-item-label">处理人：</span>
                  <select-filter v-model="detailInfo.assignUser" class="bug-basic-info-item-select-width"
                    :selectList="assignUserList"></select-filter>

                  <!-- <el-select class="bug-basic-info-item-select-width" v-model="detailInfo.assignUser"
                    :popper-append-to-body="false">
                    <el-option v-for="jtem in assignUserList" :label="jtem.value" :key="jtem.key" :value="jtem.key">
                    </el-option>
                  </el-select> -->
                </div>
              </el-col>

              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select">
                  <span class="bug-basic-info-item-label">优先级：</span>
                  <el-select class="bug-basic-info-item-select-width" v-model="detailInfo.priority">
                    <el-option v-for="jtem in priorityList" :label="jtem.value" :key="jtem.key" :value="jtem.key">
                    </el-option>
                  </el-select>
                </div>
              </el-col>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select">
                  <span class="bug-basic-info-item-label">迭代：</span>
                  <el-select class="bug-basic-info-item-select-width" v-model="detailInfo.sprintId">
                    <el-option v-for="jtem in sprintIdList" :label="jtem.value" :key="jtem.key" :value="jtem.key">
                    </el-option>
                  </el-select>
                </div>
              </el-col>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select">
                  <span class="bug-basic-info-item-label">预计工时(h)：</span>
                  <!-- <el-input class="basic-title-input-active" placeholder="请输入工时/h" v-model="detailInfo.expectHour" @change="taskTimeChange('expectHour')"></el-input> -->
                  <expect-hour class="basic-title-input-active" v-bind:hour.sync="detailInfo.expectHour"
                    :changeCallback="()=>taskTimeChange('expectHour')"></expect-hour>
                </div>
              </el-col>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select">
                  <span class="bug-basic-info-item-label">预计开始日期：</span>
                  <custom-date class="basic-title-input-active" v-model="detailInfo.startTime" @change="taskTimeChange('startTime')">
                  </custom-date>
                </div>
              </el-col>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select">
                  <span class="bug-basic-info-item-label">预计结束日期：</span>
                  <custom-date class="basic-title-input-active" v-model="detailInfo.endTime"
                    @change="taskTimeChange('endTime')">
                  </custom-date>
                </div>
              </el-col>
              <!-- 新版自定义字段 -->
              <basic-info-custom-field customFieldInElRow :workItemType="2" detailType="editable" :detailInfo="detailInfo"
                :projectId="projectId" v-model="customFieldObj"></basic-info-custom-field>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item bug-basic-info-item-select" style="height: auto;">
                  <span class="bug-basic-info-item-label">相关人：</span>
                  <select-filter v-model="detailInfo.relevantUsers" class="bug-basic-info-item-select-width"
                    :selectList="assignUserList" :multiple="true"></select-filter>
                </div>
              </el-col>
            </el-row>
          </div>
          <!-- 附件上传部分-->
          <div class="bug-attachment">
            <p class="bug-attachment-title">
              附件
              <span class="bug-attachment-title-btn"
                @click="fileUpdaloadBoxStatusHandle">{{fileUpdaloadBoxStatus?'收起上传':'展开上传'}}</span>
            </p>
            <file-upload :fileUpdaloadBoxStatus="fileUpdaloadBoxStatus" :uploadedFileList="uploadedFileList"
              :handleFileDelete="handleFileDelete" :handleUploadSuccess="handleUploadSuccess" workItemType="3">
            </file-upload>
          </div>
        </div>
      </el-col>
    </el-row>
    <div class="detail-content-footer">
      <!-- 选择需求 -->
      <el-tabs value="code" type="border-card">
        <el-tab-pane label="选择父需求" name="code" disabled>
          <el-form :inline="true" @submit.native.prevent>
            <el-form-item class="header-input">
              <el-input placeholder="请输入需求标题关键字" v-model="searchInfo.title"></el-input>
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="searchRequrieList">查询</el-button>
            </el-form-item>
          </el-form>
          <div class="table-box-top">
            <el-table :data="requirementList" ref="assocRequireTableRef" style="width: 100%;height: 100%;">
              <el-table-column width="50" align="center">
                <template slot-scope="scope">
                  <el-radio v-model="detailInfo.requireId" :label="scope.row.id">{{null}}</el-radio>
                </template>
              </el-table-column>
              <el-table-column width="70" show-overflow-tooltip label="需求ID" prop="id">
                <template slot-scope="scope">
                  <span class="c-blue cp" @click.stop="assocItemClick(scope.row, 'requirement')">{{scope.row.id}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="display.title" show-overflow-tooltip label="需求标题" min-width="180">
                <template slot-scope="scope">
                  <span class="c-blue cp"
                    @click.stop="assocItemClick(scope.row, 'requirement')">{{scope.row.display.title}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="display.projectName" show-overflow-tooltip label="所属项目" min-width="80">
              </el-table-column>
              <el-table-column prop="display.assignUser" show-overflow-tooltip label="处理人" min-width="60">
              </el-table-column>
              <el-table-column prop="display.status" show-overflow-tooltip label="状态" width="80"></el-table-column>
            </el-table>
          </div>
          <div class="table_b_f_b">
            <el-pagination v-show="requirementList && requirementList.length>0" class="fr mr10" style="margin-top: 9px;"
              @size-change="handleRequirementListPageSizeChange" @current-change="handleRequirementListPageNumChange"
              :current-page="searchInfo.pageInfo.pageNumber" :page-sizes="[10, 20, 30]"
              :page-size="searchInfo.pageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper"
              :total="searchInfo.pageInfo.totalRecords"></el-pagination>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>
<script>
  /**
   * @title 创建任务
   * @desc 第一个开始使用 vuex 缓存数据的组件
   * @author heyunjiang
   * @date 2019.6.10
   */
  import TinyMce from "components/tool/tinymce";
  import ProjectCommonMixin from "../ProjectCommonMixin";
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import ExpectHour from '@/components/commonComponents/ExpectHour'
  import FileUpload from "@/components/commonComponents/FileUpload";
  import BasicInfoCustomField from "@/components/project/BasicInfoCustomField";
  import { mapState } from 'vuex'

  // 缺陷默认初始信息
  const resetInit = {
    title: "", // 标题
    content: "", // 内容
    priority: 80, // 优先级
    assignUser: "", // 处理人
    expectHour: 4, // 预计工时
    startTime: "", // 预计开始时间
    endTime: "", // 预计结束时间
    sprintId: "", // 迭代
    // statusId: "", // 状态
    requireId: null, // 所属需求 id
    bizId: 0, // 业务id
    id: -2
  };
  const WorkTtemType = 2;

  export default {
    name: "TaskAdd",
    components: {
      TinyMce,
      ExpectHour,
      FileUpload,
      BasicInfoCustomField
    },
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    props: {
      show: {
        type: Boolean,
        requireId: true,
        desc: '所属 slider 展开与否'
      },
      projectId: {
        type: [String, Number],
        requireId: true,
        desc: '项目id'
      }
    },
    data() {
      return {
        originalData: { ...resetInit },
        detailInfo: { ...resetInit }, // 任务详情
        loading: false,
        searchInfo: {
          title: '',
          pageInfo: {
            pageNumber: 1,
            pageSize: 10,
            totalRecords: 0
          }
        },
        requirementList: [], // 可以选择的父需求列表
        // 上传附件框-展示/隐藏
        fileUpdaloadBoxStatus: true,
        // 已经上传的附件信息
        uploadedFileList: [],
        customFieldObj: {}
      }
    },
    computed: {
      ...mapState({
        priorityList: state => state.pf.PROJECTFIELDSELECTVALUES.priorityList[WorkTtemType],
        assignUserList: state => state.pf.PROJECTFIELDSELECTVALUES.assignUserList[WorkTtemType],
        // statusIdList: state => state.pf.PROJECTFIELDSELECTVALUES.statusIdList[WorkTtemType],
        sprintIdList: state => state.pf.PROJECTFIELDSELECTVALUES.sprintIdList[WorkTtemType],
        expectHourList: state => state.pf.PROJECTFIELDSELECTVALUES.expectHourList[WorkTtemType],
      })
    },
    watch: {
      show() {
        this.show && this.initData()
      }
    },
    methods: {
      // 获取自定义模板内容
      queryDescTmpl() {
        $http.get($http.api.work_status_fow.descTmpl_query, { projectId: this.projectId, workItemType: 2 }).then((res) => {
          this.originalData.content = res.data.template;
          this.$nextTick(() => {
            this.detailInfo.content = res.data.template;
          })
        })
      },
      // 数据初始化
      async initData() {
        this.detailInfo = { ...resetInit };
        this.warningStatusTitle = false;
        this.searchInfo.title = '';
        this.uploadedFileList = [];
        // store state 数据初始化
        if (this.priorityList.length === 0) {
          this.loading = true;
          await this.$store.dispatch({
            type: 'initDataPROJECTFIELD', payload: {
              projectId: this.projectId,
              workItemType: WorkTtemType
            }
          })
          this.loading = false;
        }
        this.tinymceContentReset();
        this.queryDescTmpl();
        this.$nextTick(() => {
          this.setSelectInitValue();
          this.searchRequrieList();
        })
      },
      // 点击右上角关闭
      async taskClose() {
        let noticeTitle = '工作项';
        if (this.detailInfo.title !== this.originalData.title) {
          noticeTitle += '标题';
        }
        if (this.detailInfo.content !== this.originalData.content) {
          if (this.detailInfo.title !== this.originalData.title) {
            noticeTitle += '和描述';
          } else {
            noticeTitle += '描述';
          }
        }
        if (this.detailInfo.title !== this.originalData.title || this.detailInfo.content !== this.originalData.content) {
          const confirmResult = await this.confirmBeforeOperate(`${noticeTitle}已经填写/修改，请确认是否关闭`);
          if (!confirmResult) { return false; }
        }
        this.$emit('HandleSide')
        this.removeTinymceContent(this.detailInfo.id)
      },
      // 编辑器内容恢复
      async tinymceContentReset() {
        const exist = await this.isPreviousContentExist(this.detailInfo.id, 'task', true, this.detailInfo.content);
        if (exist) {
          this.detailInfo.content = exist;
        }
      },
      // 标题输入内容监听
      titleInput() {
        if (this.detailInfo.title !== this.originalData.title) {
          this.$emit('update:titleNotice', true);
        } else {
          this.$emit('update:titleNotice', false);
        }
      },
      // 编辑器监听
      editHnadle(data) {
        this.detailInfo.content = data;
        if (data !== this.originalData.content) {
          this.$emit('update:descNotice', true);
          this.saveTinymceContent({
            value: data,
            id: this.detailInfo.id,
            type: 'task', // 需求、任务、缺陷
            isNew: true
          })
        } else {
          this.$emit('update:descNotice', false);
          this.removeTinymceContent(this.detailInfo.id)
        }
      },
      // 设置初始默认值
      setSelectInitValue() {
        if (this.assignUserList.length > 0) { this.detailInfo.assignUser = $utils.getStorage(GLOBAL_CONST.USER_INFO).userId }
        // if(this.statusIdList.length > 0) {this.detailInfo.statusId = this.statusIdList[0].key}
        if (this.sprintIdList.length > 0) { this.detailInfo.sprintId = this.sprintIdList[0].key }
      },
      // 选择需求 - 点击查询
      searchRequrieList() {
        $http.post($http.api.requirement.parentable, {
          title: this.searchInfo.title,
          pageInfo: this.searchInfo.pageInfo,
          projectId: this.projectId
        }).then(res => {
          if (res.status === 200) {
            this.searchInfo.pageInfo = res.data.pageInfo;
            this.requirementList = res.data.result;
          } else {
            this.$message({
              message: res.msg || '没有满足条件的需求',
              type: 'error'
            })
            this.requirementList = []
          }
        });
      },
      // 分页
      handleRequirementListPageSizeChange(pageSize) {
        this.searchInfo.pageInfo.pageSize = pageSize;
        this.searchRequrieList();
      },
      // 分页
      handleRequirementListPageNumChange(pageNum) {
        this.searchInfo.pageInfo.pageNumber = pageNum;
        this.searchRequrieList();
      },
      // 保存任务
      handleTaskSave() {
        // 任务标题校验
        if (this.detailInfo.title.trim().length === 0) {
          this.$message({
            message: '标题不能为空',
            type: 'warning'
          })
          return false;
        }
        // 任务父需求校验
        if (this.detailInfo.requireId === null) {
          this.$message({
            message: '任务必须选择父需求',
            type: 'warning'
          })
          return false;
        }
        // 任务工时校验
        if (this.detailInfo.expectHour && this.detailInfo.expectHour % 2 > 0) {
          this.$message({
            message: '任务工时必须为2的倍数',
            type: 'warning'
          })
          return false;
        }
        this.loading = true;
        $http.post($http.api.requirement.createTask, {
          ...this.detailInfo,
          userDefinedAttrs: this.customFieldObj,
          attachments: this.uploadedFileList.map(item => item.id)
        }).then(result => {
          this.loading = false;
          if (result.status === 200) {
            this.$message({
              message: result.msg || "创建成功",
              type: "success"
            });
            this.$emit('update:titleNotice', false);
            this.$emit('update:descNotice', false);
            this.$nextTick(() => {
              this.$emit('HandleAddSuccess');
              this.removeTinymceContent(this.detailInfo.id)
            })
          } else {
            this.$message({
              message: result.msg || "创建失败",
              type: "error"
            });
          }
        });
      },
      // 任务联动
      async taskTimeChange(key) {
        let result = {};
        try {
          result = await this.time_linkage_calculate({
            startTime: this.detailInfo.startTime,
            endTime: this.detailInfo.endTime,
            expectHour: this.detailInfo.expectHour || 0,
            modifiedFiled: key || 'startTime'
          })
        } catch (_) { }
        if (result.status && result.status === 200) {
          this.detailInfo = {
            ...this.detailInfo,
            startTime: result.data.timeCalculateResult.startTime,
            endTime: result.data.timeCalculateResult.endTime,
            expectHour: result.data.timeCalculateResult.expectHour
          }
          this.originalData = {
            ...this.originalData,
            startTime: result.data.timeCalculateResult.startTime,
            endTime: result.data.timeCalculateResult.endTime,
            expectHour: result.data.timeCalculateResult.expectHour
          }
        } else {
          this.$message({
            message: result.msg || '时间计算出错，请自行选择',
            type: 'error'
          })
          this.detailInfo = {
            ...this.detailInfo,
            startTime: this.originalData.startTime,
            endTime: this.originalData.endTime,
            expectHour: this.originalData.expectHour
          }
        }
      },
      // 4 文件上传 - 成功处理函数
      handleUploadSuccess(res) {
        this.uploadedFileList.push({
          name: res.data.origName,
          url: res.data.url,
          id: res.data.id,
          createTime:res.data.createTime,
          createUser:res.data.display.createUser
        });
        this.$message({
          message: "文件上传成功",
          type: "success"
        });
      },
      // 4 文件上传 - 文件删除
      handleFileDelete(file) {
        this.uploadedFileList = this.uploadedFileList.filter(
          item => item.id !== file.id
        );
      },
      // 4 文件上传 - 上传框是否隐藏
      fileUpdaloadBoxStatusHandle() {
        this.fileUpdaloadBoxStatus = !this.fileUpdaloadBoxStatus;
      },
    }
  }
</script>
<style lang="scss" scoped>
  @import "../ProjectCommon.scss";

  .detail-content-footer {
    padding-bottom: 30px !important;
  }
</style>