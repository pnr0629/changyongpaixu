<template>
  <div id="taskEdit">

    <div class="left-box">
      <div class="slide-header">
        <div>
          <!-- <div class="left-line"></div> -->
          <div class="taskinfo-title">任务详情</div>
          <div class="el-icon-close close-slide" @click="HandleCloseSlide"></div>
        </div>
        <div class="line-border"></div>
      </div>
      <!-- <div class="over taskEdit-title">
        <span v-if="editTitle==1" class=" mt10 title-input" :title="sendPageData.title"><i @click.stop="changeEdithandle(1)"
            class="el-icon-edit-outline"></i><span class="ml5 task-title">{{sendPageData.title}}</span></span>
        <el-input v-if="editTitle==2" class="mt10 title-input" @focus="handlefocus($event)" @click.stop.native="HandleStop"
          @change="handleTitleChange" placeholder="请输入任务标题" v-model="sendPageData.title"></el-input>
      </div> -->
      <div class="slide-content">
        <div class="over taskEdit-title">
          <span v-if="editStatus==1" class="fl mt10 title-input" v-html="sendPageData.title"
            :title="sendPageData.title"></span>
          <el-input v-if="editStatus==2" class="fl mt5 title-input" placeholder="请输入任务标题" v-model="sendPageData.title">
          </el-input>
          <div class="fr button-box">
            <el-button v-show="editStatus==1" type="primary" class=" mt5" style="position: absolute; right: 0px;"
              @click="changeEdithandle(2)">编辑详情
            </el-button>
            <el-button v-show="editStatus==2" type="primary" class=" mt5" @click="sureEditHandle()">保存</el-button>
            <el-button v-show="editStatus==2" type="info" class=" mt5 mr5" @click="cancleEdithandle()">取消</el-button>
          </div>
        </div>
        <div class="wrap-edit">
          <div class="app-container">
            <div class="editcc">
              <!-- 组件有两个属性 value 传入内容双向绑定 setting传入配置信息 -->
              <!-- <editor v-if="editStatus==2" class="editor" :value="content" :setting="editorSetting" @input="(content)=> content = content"></editor>
                <textarea v-else style="width:100%;height: 400px;" :value="content" disabled></textarea> -->
              <editor v-if="editStatus==2" class="editor" :value="sendPageData.content"
                v-on:editHnadle="editHnadle($event)" :setting="editorSetting"
                @input="(content)=> sendPageData.content = content"></editor>
              <div class="edit-box" v-else v-html="sendPageData.content"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class=" right-box">
      <el-form label-width="90px" :model="sendPageData" ref="formdisabled">
        <!-- <div style="border-bottom: 2px solid #e4e7ed;text-align: center;margin-top:30px;">所属项目：{{projectName}}</div> -->
        <el-col :span="11">
          <el-form-item label="处理人">
            <el-select v-model="sendPageData.assignUser" :popper-append-to-body="false" style="width: 100%" filterable
              @change="handleAssignUserChange()">
              <el-option :value="data.userId" v-for="(data,index) in assignUserData" :key="index"
                :label="data.userName">
                <span style="float: left">{{ data.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px">{{ data.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="11" style="margin-left:8%;">
          <el-form-item label="状态">
            <!-- <div v-show="this.inputCount === 6"> -->
            <el-select v-model="sendPageData.statusId" style="width: 100%"
              @click.native="statusHandle(sendPageData.statusId)" class="h28" @change="handleStatusChange()">
              <el-option :label="status" :value="sendPageData.statusId">
                <template slot-scope="scope"><span style="float: left"><span class="mini-circle"
                      :style="{backgroundColor:color}"></span>{{status}}</span></template>
              </el-option>
              <el-option v-for="item in demandStatusData" :key=item.statusId :label="item.statusName"
                :value=item.statusId>
                <template slot-scope="scope"><span style="float: left"><span class="mini-circle"
                      :style="{backgroundColor:item.color}"></span>{{item.statusName}}</span></template>
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="11">
          <el-form-item label="优先级">
            <!-- <div v-show="this.inputCount ===2"> -->
            <el-select :popper-append-to-body="false" placeholder="请选择活动区域" v-model="sendPageData.priority" class="h28"
              style="width: 100%" @change="handlePriorityChange()">
              <el-option :label="data.literal" :value="data.priority" v-for="(data,index) in priorityList" :key="index">
                <template slot-scope="scope"><span style="float: left"><span class="mini-circle"
                      :style="{backgroundColor:data.color}"></span>{{data.literal}}</span></template>
              </el-option>
            </el-select>
          </el-form-item>


        </el-col>
        <el-col :span="11" style="margin-left:8%;">
          <el-form-item label="迭代">
            <!-- <div v-show="this.inputCount ===3"> -->
            <el-select placeholder="请选择活动区域" style="width: 100%" :popper-append-to-body="false"
              v-model="sendPageData.sprintId" @change="handleSprintChange()" class="h28">
              <el-option :label="data.name" :value="data.id" v-for="(data,index) in sprintData" :key="index">
              </el-option>
              <el-option label="未规划" v-bind:value="parseInteger(0)"></el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="11">
          <el-form-item label="预计工时(h)">
            <!-- <div v-show="this.inputCount === 8"> -->
            <!-- <el-input v-model="sendPageData.expectHour" @change="handleExpectHourChange()">
              </el-input> -->
            <el-select :popper-append-to-body="false" v-model="sendPageData.expectHour"
              @change="handleExpectHourChange()" style="width: 100%">
              <el-option v-for="item in expectHourList" :key="item.value" :value="item.value" :label="item.label">
                <span style="float: left;margin-right:20px;">{{ item.label }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px">{{ item.value }}h</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-col>
        <el-col :span="11" style="margin-left:8%;">

          <el-form-item label="实际工时(h)">
            <!-- <div v-show="this.inputCount === 9"> -->
            <el-input v-model="sendPageData.actualHour" @change="handleActualHourChange(sendPageData.actualHour)">
            </el-input>
            <!-- <i class="el-icon-close" @click="HandleCloseEdit()"></i> -->
            <!-- </div>
                <div class="input" v-show="this.inputCount !==9" @mouseenter="Handleenter(9)" @mouseleave='Handleleave()'>
                  <span>{{sendPageData.actualHour}}</span><i v-show="edit==9" @click="HandleEdit(9)" class="el-icon-edit"></i>
                </div> -->
          </el-form-item>
        </el-col>
        <el-col :span="11">
          <el-form-item label="开始时间">
            <el-date-picker v-model="sendPageData.startTime" type="date" prefix-icon="clean-icon"
              value-format="yyyy-MM-dd" @change="handleStartTimeChange()" placeholder="选择日期" style="width: 100%">
            </el-date-picker>
          </el-form-item>
        </el-col>
        <el-col :span="11" style="margin-left:8%;">
          <el-form-item label="结束时间">

            <!-- <div v-show="this.inputCount === 5"> -->
            <el-date-picker v-model="sendPageData.endTime" type="date" prefix-icon="clean-icon"
              value-format="yyyy-MM-dd" placeholder="选择日期" style="width: 100%" @change="handleEndTimeChange(1)">
            </el-date-picker>
          </el-form-item>
        </el-col>


        <el-col :span="11">
          <el-form-item label="进度(%)" prop="progress">
            <!-- <div v-show="this.inputCount === 7"> -->
            <el-input v-model="sendPageData.progress" @change="handleProgressChange(sendPageData.progress)">
            </el-input>
          </el-form-item>
        </el-col>
      </el-form>
    </div>

  </div>
</template>

<script>


  import editor from 'components/tool/markedit'

  export default {
    name: "taskEdit",
    props: {
      taskId: {
        type: Number,
        required: false,
      },
      projectId: {
        type: Number,
        required: false,
      },
      show: {
        type: Boolean,
        default: false
      },
      restore: {
        type: Number,
        required: false,
      }

    },
    data: function () {
      return {
        expectHourList: [
          {
            value: 4,
            label: '0.5天'
          },
          {
            value: 8,
            label: '1天'
          },
          {
            value: 12,
            label: '1.5天'
          },
          {
            value: 16,
            label: '2天'
          },
          {
            value: 20,
            label: '2.5天'
          },
          {
            value: 24,
            label: '3天'
          },
        ],
        circleClass: ["urgent-font", "hight-font", "middle-font", "min-font"],
        priorityDate: [
          {
            priority: 100,
            name: '紧急'
          },
          {
            priority: 90,
            name: '高'
          },
          {
            priority: 80,
            name: '中'
          },
          {
            priority: 70,
            name: '低'
          }

        ],
        color:"",
        editTitle: 1,
        assignUserData: [],
        allassignUser: null,
        inputCount: null,
        edit: true,
        tasdId: 0,
        priority: "",
        status: "",
        formdisabledchange: null,
        editStatus: 1,//是否处于编辑状态
        intermediateValue: '',//处理监听子组件返回的中间值
        statusDate: "",//下拉绑定
        labelPosition: 'right',
        sprintData: [],
        sprint: "",
        titleSure: '',
        assignUser: '',
        pageValueAll: "",
        demandStatusData: [],
        sendPageData: {
          title: null,
          content: null,
          statusId: null,
          expectHour: null,
          startTime: null,
          actualHour: null,
          sprintId: -1,
          sprintName: null,
          priority: null,
          progress: null,
          endTime: null,
          assignUser: null,
          id: null
        },
        updateTaskData: {
          id: null,
          projectId: null
        },
        field: {
          title: "title",
          content: "content",
          expectedTime: "expectedTime",
          assignUser: "assignUser",
          priority: "priority",
          category: "category",
          sprintId: "sprintId",
          startTime: "startTime",
          endTime: "endTime",
          statusId: "statusId",
          progress: "progress",
          expectHour: "expectHour",
          actualHour: "actualHour"
        },
        sprintDate: [],
        formLabelAlign: {
          name: '',
          region: '',
          type: ''
        },
        priorityList: [],//优先级列表
        projectName: "",
        //tinymce的配置信息 参考官方文档 https://www.tinymce.com/docs/configure/integration-and-setup/
        editorSetting: {
          height: 400,
        },

        statusDate: "",//下拉绑定
        projectIdvip: null,
      }
    },
    watch: {
      taskId: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          this.$nextTick(() => {
            this.getTaskInfo()
          })
        }
      },
      show: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          this.$nextTick(() => {
            this.getTaskInfo()
          })
        }
      },
      titleSure: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          // this.$emit()
        }
      },
      restore: function (newval, oldVal) {
        if (newval !== oldVal) {

          this.editStatus = 1;
        }
      }
    },
    mounted() {
      if (this.taskId) {
        this.getTaskInfo();
      }
      this.getPriorityList();
      // this.getAssignUser();

      this.$nextTick(() => {
        var a = document.getElementsByClassName("el-input__inner").height = 28

      })
    },
    methods: {
      //获取优先级列表
      getPriorityList() {
        let projectId = this.projectId
        $http.get($http.api.bug_info.priorityList, { projectId, workItemType: 1 }).then((res) => {  //todo cpp 这里应该获取自己的queryType=1
          this.priorityList = res.data;
          // console.log(res.data)
        })
      },
      HandleCloseSlide() {
        this.$emit("HandleSide")
      },
      handlefocus() {
        event.currentTarget.select();
      },
      handleTitleChange() {

        // this.titleSure = this.sendPageData.title;
        this.editTitle = 1;
        this.handleSendTitleDate()
      },
      HandleStop() {
      },
      // HandleSendTitle() {
      //   if (this.editTitle === 2) {
      //     this.edit = true;
      //     this.editTitle = 1;
      //     this.handleSendTitleDate()

      //   }
      // },
      handleSendTitleDate() {
        this.updateTaskData = {};
        this.updateTaskData.id = this.taskId;
        this.updateTaskData.projectId = this.projectId;

        this.updateTaskData.title = this.sendPageData.title;


        $http.post($http.api.task.taskUpdate, this.updateTaskData).then((res) => {
          this.$message({ message: '修改任务成功', type: 'success' });
          this.getTaskInfo()
        }).catch(e => {
          this.getTaskInfo()
        })

      },
      parseInteger(value) {
        return parseInt(value);
      },
      editHnadle(data) {
        this.intermediateValue = data;
      },
      Handleenter(index) {
        this.edit = index;

      },
      Handleleave(index) {
        this.edit = null;
        // this.inputCount = null;
      },
      HandleEdit(index) {
        this.inputCount = index;

      },
      HandleCloseEdit() {
        this.inputCount = null;
      },
      sprintHnadle() {
        // console.log(this.projectIdvip)
        this.getSprintName(this.projectIdvip)
      },
      statusHandle(statusId) {
        this.getNextStaus(statusId)
      },
      getNextStaus(statusId) {
        $http.post($http.api.status.list_updatable, {
          workItemType: 2,
          workItemId: this.taskId,
          statusId: statusId
        }).then((res) => {
          this.demandStatusData = res.data
        }).catch((e) => {
          this.$message({ message: '操作失败', type: 'error' });
        });
      },
      getSprintName(data) {
        let projectId = this.getUrlParams().projectId ? this.getUrlParams().projectId : data;

        $http.get($http.api.sprint.list_sprint_name, { projectId, status: 1 }).then((res) => {
          this.sprintData = res.data

        })
      },
      getAssignUser(projectId) {
        $http.post($http.api.project.assignUser, { projectId: projectId }
        ).then((res) => {  //todo cpp 这里应该获取自己的queryType=1
          this.assignUserData = res.data;
        })
      },
      getTaskInfo() {
        let id = this.taskId;
        $http.get($http.api.task.taskEdit, { id, projectId: this.projectId }).then((res) => {  //todo cpp 这里应该获取自己的queryType=1

          this.$nextTick(() => {
            this.sendPageData.content = res.data.display.content;
            this.projectName = res.data.display.projectName;
            this.sendPageData.title = res.data.display.title;
            this.sendPageData.assignUser = res.data.assignUser;
            this.assignUser = res.data.display.assignUser;
            this.sendPageData.priority = res.data.priority;

            this.priority = res.data.display.priority;

            this.sendPageData.sprintId = res.data.sprintId;
            this.sendPageData.sprintName = res.data.display.sprint;

            this.sprint = res.data.display.sprint;

            this.sendPageData.startTime = res.data.startTime;
            this.sendPageData.endTime = res.data.endTime;
            this.status = res.data.display.status;
            this.color = res.data.display.detail.status.color;
            this.sendPageData.statusId = res.data.statusId;

            this.sendPageData.progress = res.data.progress;
            this.sendPageData.expectHour = res.data.expectHour;
            this.sendPageData.actualHour = res.data.actualHour;
            this.projectIdvip = res.data.projectId;
            this.getAssignUser(this.projectIdvip);
            this.getSprintName(this.projectIdvip)
          })
        })
      },
      submitUpload() {
        this.$refs.upload.submit();
      },
      handleRemove(file, fileList) {

      },
      handlePreview(file) {

      },
      sureEditHandle() {
        this.edit = true;
        this.editStatus = 1;

        this.updateTaskData = {};
        this.updateTaskData.id = this.taskId;
        this.updateTaskData.projectId = this.projectId;
        this.updateTaskData.title = this.sendPageData.title;
        this.updateTaskData.content = this.intermediateValue;

        $http.post($http.api.task.taskUpdate, this.updateTaskData).then((res) => {
          this.$message({ message: '修改任务成功', type: 'success' });
          this.getTaskInfo()
        }).catch(e => {
          this.getTaskInfo()
        })

      },
      changeEdithandle(index) {
        this.edit = false;


        if (index === 1) {
          this.editTitle = 1;
        } else if (index === 2) {
          this.editStatus = 2;

        }

      },
      //获取今天明天后天的日期

      cancleEdithandle() {
        this.edit = true;
        this.editStatus = 1;
        this.getTaskInfo()
      },
      handlePriorityChange() {
        this.updateTaskOneField(this.field.priority, this.sendPageData.priority);
      },
      handleSprintChange() {
        this.updateTaskOneField(this.field.sprintId, this.sendPageData.sprintId);
      },
      _GetDateStr(AddDayCount) {
        let date = new Date(this.sendPageData.startTime)

        if (date) {
          date.setDate(date.getDate() + AddDayCount);
          let y = date.getFullYear();
          let m = date.getMonth() + 1;
          let d = date.getDate();
          return y + "-" + m + "-" + d;

        }
      },

      //选择工时得出截止日期
      selectExpectHour() {
        if (this.sendPageData.startTime) {
          if (this.sendPageData.expectHour == 4 || this.sendPageData.expectHour == 8) {
            this.sendPageData.endTime = this._GetDateStr(0);
          } else if (this.sendPageData.expectHour == 12 || this.sendPageData.expectHour == 16) {
            this.sendPageData.endTime = this._GetDateStr(1);
          } else if (this.sendPageData.expectHour == 20 || this.sendPageData.expectHour == 24) {
            this.sendPageData.endTime = this._GetDateStr(2);
          }
        }
        this.handleEndTimeChange()
      },

      handleStartTimeChange() {

        let nowDate = this.formatDate(new Date(), 'yyyyMMdd');

        let startTime = this.sendPageData.startTime.replace(/-/g, "");
        if (parseInt(nowDate.substring(0, 9)) > parseInt(startTime)) {
          this.$message({
            message: '预计开始日期不能小于当前日期',
            type: 'warning'
          })
          this.getTaskInfo()
          return;
        }
        this.updateTaskOneField(this.field.startTime, this.sendPageData.startTime);
        this.selectExpectHour()
      },
      handleEndTimeChange(data) {
        if (data) {
          let nowDate = this.formatDate(new Date(this.sendPageData.startTime), 'yyyyMMdd');
          let endTime = this.sendPageData.endTime.replace(/-/g, "");
          if (parseInt(nowDate.substring(0, 9)) > parseInt(endTime)) {
            this.$message({
              message: '预计结束日期不能小于开始日期',
              type: 'warning'
            });
            this.getTaskInfo()
            return;
          }
        }
        this.updateTaskOneField(this.field.endTime, this.sendPageData.endTime);
      },
      handleAssignUserChange() {
        this.updateTaskOneField(this.field.assignUser, this.sendPageData.assignUser);
        this.$emit('handlePririty')
      },
      handleStatusChange() {
        this.updateTaskOneField(this.field.statusId, this.sendPageData.statusId);
      },
      handleProgressChange(value) {
        var value = Number(value)
        var value = Number(value)
        // console.log(/^\d+$/.test(value))
        if (!/^\d+$/.test(value)) {
          this.$message({
            showClose: true,
            message: '进度必须是整数',
            type: 'warning'
          });
          return
        }
        if (value < 0 || value > 100) {
          this.$message({
            showClose: true,
            message: '进度只能在0到100之间',
            type: 'warning'
          });
          return
        }
        this.updateTaskOneField(this.field.progress, this.sendPageData.progress);
      },
      handleExpectHourChange() {

        this.selectExpectHour()
        this.updateTaskOneField(this.field.expectHour, this.sendPageData.expectHour);
      },
      handleActualHourChange(value) {
        var value = Number(value)
        // console.log(/^\d+$/.test(value))
        if (!/^\d+$/.test(value)) {
          this.$message({
            showClose: true,
            message: '实际工时必须是整数',
            type: 'warning'
          });
          return
        }
        if (value < 0) {
          this.$message({
            showClose: true,
            message: '实际工时必须大于等于0',
            type: 'warning'
          });
          return
        }
        this.updateTaskOneField(this.field.actualHour, this.sendPageData.actualHour);
      },
      updateTaskOneField(field, value) {
        this.updateTaskData = {};
        this.updateTaskData.id = this.taskId;
        this.updateTaskData.projectId = this.projectIdvip
        if (field == this.field.content) {
          this.updateTaskData.content = value;
        } else if (field == this.field.title) {
          this.updateTaskData.title = value;
        } else if (field == this.field.expectedTime) {
          this.updateTaskData.expectedTime = value;
        } else if (field == this.field.statusId) {
          this.updateTaskData.statusId = value;
        } else if (field == this.field.startTime) {
          this.updateTaskData.startTime = value;
        } else if (field == this.field.priority) {
          this.updateTaskData.priority = value;
        } else if (field == this.field.sprintId) {
          this.updateTaskData.sprintId = value;
        } else if (field == this.field.endTime) {
          this.updateTaskData.endTime = value;
        } else if (field == this.field.assignUser) {
          this.updateTaskData.assignUser = value;
        } else if (field == this.field.progress) {
          this.updateTaskData.progress = value;
        } else if (field == this.field.expectHour) {
          this.updateTaskData.expectHour = value;
        } else if (field == this.field.actualHour) {
          this.updateTaskData.actualHour = value;
        }

        $http.post($http.api.task.taskUpdate, this.updateTaskData).then((res) => {
          this.$message({ message: '修改任务成功', type: 'success' });
          this.getTaskInfo()
        }).catch(e => {
          this.getTaskInfo()
        })
      },
    },
    components: {
      'editor': editor
    }


  };

</script>

<style lang="scss" scoped>
  /* .line-border {
    height: 2px;
    width: 100%;
    background-color: #e4e7ed;
    background-color:#409EFF;
  } */

  .button-box {
    width: 150px;
    margin-top: 5px;
    position: relative;
  }

  .taskinfo-title {
    font-size: 20px;
    height: 53px;
    line-height: 49px;

    color: #000;
    /* font-weight: 900; */
    /* border-bottom: 2px solid #e4e7ed; */

    display: inline-block
  }

  .slide-header {
    position: relative;
    background-color: #f2f2f2;
    padding-top: 4px;
    top: -4px;
  }

  .close-slide {
    font-size: 20px;
    position: absolute;
    top: 17px;
    right: 5px;
  }

  .left-line {
    display: inline-block;
    width: 2px;
    height: 22px;
    background-color: #409EFF;
    ;
    position: relative;

    top: 4px;
  }

  .title-input {
    width: 69%;
    font-weight: 600;
    display: inline-block;
    font-size: 26px;
    /* overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap; */
    background-color: #fff;
  }

  .slide-content {
    width: 96%;
    margin: 0 auto;
  }

  .taskEdit-title {
    /* margin-left: 11px; */
    /* text-indent: 0.8em; */
  }

  .task-title {
    padding: 3px 10px 4px 2px;
    font-size: 26px;
    font-weight: 200;
    height: 38px;
    display: inline-block;
  }

  .el-icon-edit-outline {}

  .over {
    overflow: hidden;
  }

  .wrap-edit {
    width: 100%;
    background-color: #fff;
    height: 100%;
  }

  .editor {
    margin-top: 10px;
  }

  .app-container {
    width: 100%;
    margin-top: 10px;
  }

  .headername {
    padding-top: 15px;
    padding-left: 10px;
    line-height: 12px;
    float: left;
  }

  .left-box {
    /* width: 98%;
    margin: 0 auto; */
  }

  .right-box {
    /* overflow: hidden;
    background-color: #fff; */
    /* width: calc(25% - 20px); */
    /* width: 80%; */
    /* margin-left: 20px; */
    /* margin: 0 auto; */
    /* margin-top: 40px; */
    /* padding: 10px 0;
    position: absolute;
    right: 30px; */

    overflow: hidden;
    background-color: #fff;
    /* width: calc(25% - 20px); */
    width: 92%;
    /* margin-left: 20px; */
    /* margin: 0 auto; */
    /* margin-top: 40px; */
    padding: 10px 0;
    position: absolute;
    right: 15px;

  }

  .editcc {
    margin-top: 10px;
  }


  /* .el-upload-dragger {
    width: 976px !important;
    margin-top: 20px;
  } */

  .el-form-item {
    margin-bottom: 5px;
  }

  .input {
    height: 28px;
    width: 200px;
    position: relative;
    top: 6px;
    line-height: 28px;

    &:hover {
      background-color: #f1f1f1;
    }
  }

  .el-icon-edit {
    position: absolute;
    top: 6px;
    right: 2px;
  }

  textarea[disabled] {
    background-color: #fff !important;
    border: 1px solid #ccc;
  }

  .edit-box {

    width: 100%;
    min-height: 220px;
    /* border: 1px solid #ccc; */
    /* border-top: 1px solid #409EFF; */
    border-bottom: 1px solid #ccc;
    text-indent: 1em;
    font-size: 13px;
  }

  .urgent-font {
    background-color: #f85e5e;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 10px;
  }

  .hight-font {
    background-color: #f6a71f;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 10px;

  }

  .middle-font {
    background-color: #93c36b;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 10px;
  }

  .min-font {
    background-color: #97afd0;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 10px;
  }
</style>