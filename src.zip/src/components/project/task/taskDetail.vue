<template>
  <div class="detail-content bug-content-box detail-content-show" v-if="taskId"
    v-loading="loadingStatus.bugDetailLoading||loadingStatus.basicLoading" element-loading-text="拼命加载中"
    element-loading-spinner="el-icon-loading" element-loading-background="rgba(255,255,255, 0.5)">
    <div class="slide-header">
      <span class="taskinfo-title">任务详情</span>
      <div class="slide-header-right">
        <el-button-group>
          <el-button type="default"
            v-show="authFunction('FUNC_COOP_TASK_DELETE', 3, getUrlParams().projectId || projectId)"
            @click="handelTaskDelete">删除任务</el-button>
          <el-button class="close-slide-btn" type="default" icon="el-icon-close" @click="bugClose"></el-button>
        </el-button-group>

        <!-- <span class="el-icon-close close-slide" @click="bugClose"></span> -->
      </div>
    </div>
    <el-row :gutter="10" class="detail-content-body">
      <el-col :xs="16" :sm="16" :md="16" :lg="16" :xl="18">

        <div class="detail-content-left">
          <!-- 标题 -->
          <div class="detail-content-header">
            <span v-if="statusObject.titleInputShowActiveStatus==='inactive'"
              class="detail-content-header-id">#{{taskId}}</span>
            <!-- <span v-show="statusObject.titleInputShowActiveStatus==='inactive'"
              class="editable-field title-input-inactive cursor-pointer ellipsis" style="width: calc(100% - 0);"
              @click="showActiveStatusControl('titleInputShowActiveStatus', 'active')">{{detailInfo.display.title}}</span> -->
            <ellipsis-block :value="detailInfo.display.title || ''"
              v-if="statusObject.titleInputShowActiveStatus==='inactive'" class="editable-field title-input-inactive"
              @click="showActiveStatusControl('titleInputShowActiveStatus', 'active')"></ellipsis-block>
            <el-input v-show="statusObject.titleInputShowActiveStatus==='active'" ref="titleInput"
              class="title-input-active" placeholder="输入标题" size="large"
              @change="CHECKBEFORETITLEUPDATE('titleInputShowActiveStatus', 'inactive')"
              @blur="CHECKBEFORETITLEUPDATE('titleInputShowActiveStatus', 'inactive')"
              v-model="detailInfo.display.title">
            </el-input>
            <div v-if="warningStatusTitle" class="warning warning-title">标题过长，请注意！！！</div>
          </div>
          <div class="creat-title">
            <span>{{`${detailInfo.display.createUser}(${detailInfo.createUser}) `}}</span>创建于<span>{{detailInfo.createTime}}</span>
          </div>
          <div class="detail-content-left-content"
            :class="{'detail-content-left-content-inactive': statusObject.taskDescShowActiveStatus==='inactive'}">
            <!-- 任务描述 -->
            <div :class="{'edit-fullscreen': statusObject.fullScreen}">
              <span class="edit-box-bug-help-btn"
                :class="{'edit-box-bug-help-btn-save':statusObject.taskDescShowActiveStatus==='active'}"
                @click="showActiveStatusControl('taskDescShowActiveStatus', taskDescShowActiveStatusValue)">{{statusObject.taskDescShowActiveStatus==='inactive'?'编辑描述':'保存'}}</span>
              <span class="edit-box-bug-help-btn" style="right:75px;"
                @click="fullScreenMethod">{{!statusObject.fullScreen ?'全屏':'正常'}}</span>
              <span v-show="statusObject.taskDescShowActiveStatus==='active'" class="edit-box-bug-help-btn-cancel"
                @click="editCancel">取消</span>
              <show-larger v-show="statusObject.taskDescShowActiveStatus==='inactive'"
                :value="detailInfo.display.content"></show-larger>
              <tiny-mce v-if="statusObject.taskDescShowActiveStatus==='active'" :minHeigt='minHeight'
                :value="detailInfo.display.content" @watch="editHnadle($event)"></tiny-mce>
            </div>
          </div>
          <div class="detail-content-left-assoc">
            <!-- 关联工作项 -->
            <div class="bug-assoc-header">
              <span class="title-common">关联工作项</span>
              <el-button type="text fr" v-show="authFunction('FUNC_COOP_WORKITEM_ASSOC', 0)" @click="modalStatusChange">
                添加关联</el-button>
            </div>
            <div class="bug-assoc-body"
              v-if="assocObject.parentrequirements.length > 0 ||assocObject.requirements.length > 0 || assocObject.tasks.length > 0 || assocObject.defects.length > 0">
              <div class="bug-assoc-item" v-for="item in assocObject.parentrequirements" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'requirement')">{{item.id}}-父需求-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <!-- <span class="bug-assoc-item-delete" style="cursor: text;"><i class="el-icon-delete" style="color:#827b7b;"></i></span> -->
                <!-- <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'requirement')"><i class="el-icon-delete"></i></span> -->
              </div>
              <div class="bug-assoc-item" v-for="item in assocObject.requirements" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'requirement')">{{item.id}}-需求-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'requirement')"><i
                    class="el-icon-delete"></i></span>
              </div>
              <div class="bug-assoc-item" v-for="item in assocObject.tasks" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'task')">{{item.id}}-任务-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'task')"><i
                    class="el-icon-delete"></i></span>
              </div>
              <div class="bug-assoc-item" v-for="item in assocObject.defects" :key="item.id">
                <span class="bug-assoc-item-text"
                  @click.stop="assocItemClick(item, 'defect')">{{item.id}}-缺陷-{{item.display.title}}</span>
                <span class="bug-assoc-item-assiguser">{{item.display.assignUser}}</span>
                <span class="bug-assoc-item-status">{{item.display.status}}</span>
                <span class="bug-assoc-item-delete" @click.stop="assocItemDelete(item, 'defect')"><i
                    class="el-icon-delete"></i></span>
              </div>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :xs="8" :sm="8" :md="8" :lg="8" :xl="6">
        <div class="detail-content-right">
          <!-- 基本信息 -->
          <div class="bug-basic-info">
            <p class="bug-basic-info-title">基本信息</p>
            <el-row :gutter="10">
              <el-col :md="24" :lg="24" :xl="24" v-for="item in fieldEditObjectValues" :key="item.label">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">{{item.label}}：</span>
                  <field-edit v-bind="item.fieldEditProps" :onChange="(value)=>{taskUpdate(item.key, value)}">
                  </field-edit>
                </div>
              </el-col>
              <!-- <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">预计工时：</span>
                  <span class="bug-basic-info-item-static editable-field cursor-pointer"
                    v-show="statusObject.basicExpectHourActiveStatus==='inactive'"
                    @click="showActiveStatusControl('basicExpectHourActiveStatus', 'active')">{{detailInfo.expectHour}}</span>
                  <el-input v-show="statusObject.basicExpectHourActiveStatus==='active'" ref="basicExpectHour"
                    class="basic-title-input-active" placeholder="输入预计工时"
                    @change="CHECKBEFOREEXPECTHOURUPDATE('basicExpectHourActiveStatus', 'inactive')"
                    @blur="CHECKBEFOREEXPECTHOURUPDATE('basicExpectHourActiveStatus', 'inactive')"
                    v-model="detailInfo.expectHour"></el-input>
                </div>
              </el-col> -->
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">实际工时(h)：</span>
                  <span class="bug-basic-info-item-static editable-field cursor-pointer"
                    v-show="statusObject.basicActualyHourActiveStatus==='inactive'"
                    @click="showActiveStatusControl('basicActualyHourActiveStatus', 'active')">{{detailInfo.actualHour}}</span>
                  <el-input v-show="statusObject.basicActualyHourActiveStatus==='active'" ref="basicActualyHour"
                    class="basic-title-input-active" placeholder="输入实际工时"
                    @change="CHECKBEFOREACTUALHOURUPDATE('basicActualyHourActiveStatus', 'inactive')"
                    @blur="CHECKBEFOREACTUALHOURUPDATE('basicActualyHourActiveStatus', 'inactive')"
                    v-model="detailInfo.actualHour"></el-input>
                </div>
              </el-col>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">开始时间：</span>
                  <span class="bug-basic-info-item-static editable-field cursor-pointer"
                    v-show="statusObject.basicStartTimeActiveStatus==='inactive'"
                    @click="showActiveStatusControl('basicStartTimeActiveStatus', 'active')"
                    v-html="detailInfo.startTime?detailInfo.startTime:'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'"></span>
                  <custom-date v-show="statusObject.basicStartTimeActiveStatus==='active'" ref="basicStartTime"
                    class="basic-title-input-active" v-model="detailInfo.startTime"
                    @change="CHECKBEFORESTARTTIMEUPDATE('basicStartTimeActiveStatus', 'inactive')"
                    @blur="CHECKBEFORESTARTTIMEUPDATE('basicStartTimeActiveStatus', 'inactive')" placeholder="选择日期">
                  </custom-date>
                </div>
              </el-col>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">结束时间：</span>
                  <span class="bug-basic-info-item-static editable-field cursor-pointer"
                    v-show="statusObject.basicEndTimeActiveStatus==='inactive'"
                    @click="showActiveStatusControl('basicEndTimeActiveStatus', 'active')"
                    v-html="detailInfo.endTime?detailInfo.endTime:'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'"></span>
                  <custom-date v-show="statusObject.basicEndTimeActiveStatus==='active'" ref="basicEndTime"
                    class="basic-title-input-active" v-model="detailInfo.endTime"
                    @change="CHECKBEFOREFINISHTIMEUPDATE('basicEndTimeActiveStatus', 'inactive')"
                    @blur="CHECKBEFOREFINISHTIMEUPDATE('basicEndTimeActiveStatus', 'inactive')" placeholder="选择日期">
                  </custom-date>
                </div>
              </el-col>
              <!-- <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">进度(%)：</span>
                  <span class="bug-basic-info-item-static editable-field cursor-pointer"
                    v-show="statusObject.basicProcessActiveStatus==='inactive'"
                    @click="showActiveStatusControl('basicProcessActiveStatus', 'active')">{{detailInfo.progress}}</span>
                  <el-input v-show="statusObject.basicProcessActiveStatus==='active'" ref="basicProcess"
                    class="basic-title-input-active" placeholder="输入进度"
                    @change="CHECKBEFOREPROCESSUPDATE('basicProcessActiveStatus', 'inactive')"
                    @blur="CHECKBEFOREPROCESSUPDATE('basicProcessActiveStatus', 'inactive')"
                    v-model="detailInfo.progress"></el-input>
                </div>
              </el-col> -->
              <!-- 新版自定义字段 -->
              <basic-info-custom-field customFieldInElRow :workItemType="2" detailType="show" :detailInfo="detailInfo"
                :projectId="getUrlParams().projectId || projectId" :updateField="taskUpdate"></basic-info-custom-field>
              <el-col :md="24" :lg="24" :xl="24">
                <div class="bug-basic-info-item">
                  <span class="bug-basic-info-item-label">创建人：</span>
                  <span class="bug-basic-info-item-static"
                    :title="detailInfo.display.createUser">{{`${detailInfo.display.createUser}(${detailInfo.createUser})`}}</span>
                </div>
              </el-col>
            </el-row>
          </div>
          <!-- 附件上传部分-->
          <div class="bug-attachment">
            <p class="bug-attachment-title">
              附件
              <span class="bug-attachment-title-btn"
                @click="fileUpdaloadBoxStatusHandle">{{fileUpdaloadBoxStatus?'收起上传':'展开上传'}}</span>
            </p>
            <file-upload :fileUpdaloadBoxStatus="fileUpdaloadBoxStatus" :uploadedFileList="uploadedFileList"
              :handleFileDelete="handleFileDelete" :detailInfoId="taskId" :handleUploadSuccess="handleUploadSuccess"
              workItemType="2"></file-upload>
          </div>
        </div>
      </el-col>
    </el-row>
    <div class="detail-content-footer">
      <!-- 状态流转、操作记录 -->
      <el-tabs v-model="statusObject.activeTagName" type="border-card">
        <!-- <el-tab-pane label="状态流转" name="status">
          <record-chain :data="statusRecordInfo.statusRecordList" :loadmoreCallback="StatusRecordLoadmoreCallback"
            :isMore="statusRecordInfo.statusRecordPageInfo.isMore"></record-chain>
        </el-tab-pane> -->
        <el-tab-pane label="代码提交" name="code">
          <code-commit v-if="statusObject.activeTagName==='code'" :workItemId="taskId" :workItemType="2" :update="show"
            :projectId="projectId||this.getUrlParams().projectId"></code-commit>
        </el-tab-pane>
        <el-tab-pane label="操作记录" name="operate">
          <time-line :data="operateInfo.operateList" :loadmoreCallback="OperateLoadmoreCallback"
            :isMore="operateInfo.operatePageInfo.isMore"></time-line>
        </el-tab-pane>
        <el-tab-pane label="评论" name="0">
          <div class="detailed-information1" ref="detaild">
            <comment-list workItemType="2" :workItemId="taskId" :projectId="projectId||this.getUrlParams().projectId">
            </comment-list>
          </div>
        </el-tab-pane>
        <el-tab-pane label="修订列表" name="1">
          <div class="detailed-information1">
            <div>
              <el-table :data="revisedList" style="width: 100%">
                <el-table-column prop="version" label="修订版本"></el-table-column>
                <el-table-column prop="updateTime" label="修订时间"></el-table-column>
                <el-table-column prop="display.createUser" label="操作人"></el-table-column>
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <span class="cp c-blue" @click="viewRequireRevise(scope.row.id)">查看</span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="revisedList-paging">
              <el-pagination v-show="revisedList && revisedList.length != 0" class="fr" style="margin-top: 9px;"
                @size-change="handleRevisedPageSizeChange" @current-change="handleRevisedPageNumChange"
                :current-page="revisedPageInfo.pageNumber" :page-sizes="[10, 20, 30]"
                :page-size="revisedPageInfo.pageSize" layout="total, sizes, prev, pager, next, jumper"
                :total="revisedPageInfo.totalRecords"></el-pagination>
            </div>
          </div>
          <el-dialog title="修订详情" :visible.sync="revisedDialogVisible" class=" issuedialog"
            :modal-append-to-body="false">
            <div class="form-iterm-box" id="reviseDetail" :modal-append-to-body="false"></div>
          </el-dialog>
        </el-tab-pane>
      </el-tabs>
    </div>
    <el-dialog :visible.sync="assocRequireDialogVisible" title="关联任务与缺陷" class="el-dialog-880w"
      :modal-append-to-body="false">
      <div class="form-iterm-box" style="padding-top: 0px !important;">
        <el-form :inline="true" class="demo-form-inline mb10">
          <el-form-item label="关联向类型：" style="font-size:15px;color:#555;">
            <el-select placeholder="类型选择" style="width:200px;" v-model="assocRequireSearchInfo.type">
              <el-option v-for="item in assocType" :key="item.value" :label="item.name" :value="item.value"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="标题：">
            <el-input placeholder="请输入需求标题关键字" v-model="assocRequireSearchInfo.title"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="searchAssocRequrie">查询</el-button>
          </el-form-item>
        </el-form>
        <div class="table-box-top">
          <el-table :data="taskList" ref="assocRequireTableRef" style="width: 100%;height: 100%;">
            <el-table-column type="selection" width="40"></el-table-column>
            <el-table-column :label="assocRequireSearchInfo.labeId" width="70" prop="result.id">
              <template slot-scope="scope">
                <span class="c-blue cp">{{scope.row.id}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="display.title" show-overflow-tooltip :label="assocRequireSearchInfo.labelTitle" min-width="180">
              <template slot-scope="scope">
                <span class="c-blue cp">{{scope.row.display.title}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="display.projectName" show-overflow-tooltip label="所属项目" min-width="80"></el-table-column>
            <el-table-column prop="display.assignUser" show-overflow-tooltip label="处理人" min-width="80">
            </el-table-column>
            <el-table-column prop="display.status" label="状态" width="80"></el-table-column>
          </el-table>
        </div>
        <div class="table_b_f_b">
          <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleAssocRequirePageSizeChange"
            @current-change="handleAssocRequirePageNumChange" :current-page="assocRequirePageInfo.pageNumber"
            :page-sizes="[10, 20, 30]" :page-size="assocRequirePageInfo.pageSize"
            layout="total, sizes, prev, pager, next, jumper" :total="assocRequirePageInfo.totalRecords"></el-pagination>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="handleSureAssocRequrie()">关联</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
  /**
   * @title 任务详情模块
   * @desc 状态：展示、编辑
   * @author heyunjiang
   * @date 2019-3-22
   */
  import TinyMce from '@/components/tool/tinymce'
  import editor from "@/components/tool/markedit"
  import FieldEdit from "@/components/tool/FieldEdit"
  import RecordChain from "@/components/tool/RecordChain"
  import TimeLine from "@/components/tool/TimeLine"
  import ProjectCommonMixin from '../ProjectCommonMixin'
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin";
  import TaskMixin from './taskMixin'
  import BasicInfoCustomField from "@/components/project/BasicInfoCustomField";
  import CommentList from "@/components/commonComponents/CommentList"
  import CodeCommit from '@/components/commonComponents/CodeCommit'
  import FileUpload from "@/components/commonComponents/FileUpload"
  import ShowLarger from "@/components/commonComponents/ShowLarger";
  // 任务默认初始信息
  const resetInit = {
    title: null,
    content: null,
    statusId: '',
    expectHour: '',
    startTime: null,
    actualHour: null,
    sprintId: -1,
    sprintName: null,
    priority: '',
    progress: null,
    endTime: null,
    assignUser: '',
    relevantUserIdList: [],
    id: -2,
    display: {
      stage: null,
      title: null,
      content: null,
      priority: null,
      biz: null,
      createUser: null,
      sprint: null,
      status: null,
      assignUser: null,
      relevantUser:"",
    }
  }
  const taskWorkTtemType = 2

  export default {
    name: "TaskDetail",
    components: {
      TinyMce,
      editor,
      FieldEdit,
      RecordChain,
      TimeLine,
      CommentList,
      CodeCommit,
      FileUpload,
      ShowLarger,
      BasicInfoCustomField
    },
    props: {
      //当前 bug 详情，可选，但是不能再 detailType 为 show 时不传
      taskId: {
        type: Number,
        required: false
      },
      projectId: {
        type: Number,
        required: false
      },
      show: {
        type: Boolean,
        default: false
      },
      // 更新成功之后回调函数
      operateCallback: {
        type: Function,
        required: false
      }
    },
    mixins: [TaskMixin, ProjectCommonMixin, TinymceSaveMixin],
    data() {
      return {
        comment: "",
        taskList: [],
        assocType: [
          {
            name: '任务',
            value: 2,
          },
          {
            name: '缺陷',
            value: 3
          }
        ],
        assocRequireSearchInfo: {
          projectId: this.parseInteger(this.projectId || this.getUrlParams().projectId),
          title: null,
          isArchived: -1,
          pageInfo: {},
          type: 2,
          labeId: '任务ID',
          labelTitle: "任务标题"
        },
        assocRequireDialogVisible: false,
        assocRequireDataList: [],
        assocRequirePageInfo: { pageSize: 10, pageNumber: 1 },
        projectNameList: [],
        commentUpdata: false,
        commentPageInfo: { pageSize: 10, pageNum: 1 },
        revisedList: [], //修订列表
        middleValue: "",
        revisedPageInfo: { pageSize: 10, pageNumber: 1 },
        revisedDialogVisible: false,
        detailInfo: { ...resetInit },
        originalDetailInfo: {}, // 编辑前的历史数据，用于数据状态回滚
        statusObject: {
          titleInputShowActiveStatus: "inactive",
          taskDescShowActiveStatus: "inactive",
          taskFatherRquire: "inactive", // 基本信息 - 父需求
          basicExpectHourActiveStatus: "inactive", // 基本信息 - 预计工时
          basicActualyHourActiveStatus: "inactive", // 基本信息 - 实际工时
          basicStartTimeActiveStatus: "inactive", // 基本信息 - 开始时间
          basicEndTimeActiveStatus: "inactive", // 基本信息 - 结束时间
          basicProcessActiveStatus: "inactive", // 基本信息 - 进度
          activeTagName: "0", // 选项卡切换 operate status
          fullScreen: false, //全屏
        },
        // 已经关联工作项
        assocObject: {
          parentrequirements: [],
          requirements: [],
          tasks: [],
          defects: [],
          modalStatu: false // 模态框打开情况
        },
        // 基本信息 - 处理人、状态、优先级、迭代、预计工时
        fieldEditObject: {
          assignUser: {
            label: "处理人",
            key: 'assignUser',
            fieldEditProps: {
              initValue: resetInit.assignUser,
              selectValue: [],
              localSearch: true
            }
          },
          relevantUsers: {
            label: "相关人",
            key: 'relevantUsers',
            fieldEditProps: {
              initValue: resetInit.relevantUserIdList,
              initName: resetInit.display.relevantUsers,
              selectValue: [],
              localSearch: true,
              multiple: true,
            }
          },
          status: {
            label: '状态',
            key: 'statusId',
            fieldEditProps: {
              initValue: resetInit.statusId,
              initName: resetInit.display.status,
              selectValue: [],
              colorType: 'bg'
            }
          },
          priority: {
            label: '优先级',
            key: 'priority',
            fieldEditProps: {
              initValue: resetInit.priority,
              initName: resetInit.display.priority,
              selectValue: [],
              colorType: 'font'
            }
          },
          sprint: {
            label: "迭代",
            key: 'sprintId',
            fieldEditProps: {
              initValue: resetInit.sprintId,
              selectValue: []
            }
          },
          expectHour: {
            label: "预计工时",
            key: 'expectHour',
            fieldEditProps: {
              initValue: resetInit.expectHour,
              initName: '',
              customInput: true,
              customInputPlaceHolder: '自定义天数',
              customInputChange: this.customInputChange,
              selectValue: []
            }
          }
        },
        // 已经上传的附件信息
        uploadedFileList: [],
        // 状态流转数据信息
        statusRecordInfo: {
          statusRecordList: [],
          statusRecordPageInfo: {
            pageNum: 1,
            pageSize: 100,
            isMore: false
          }
        },
        // 操作记录数据信息
        operateInfo: {
          operateList: [],
          operatePageInfo: {
            pageNum: 1,
            pageSize: 20,
            isMore: false
          }
        },
        // loading 状态统一管理
        loadingStatus: {
          bugDetailLoading: false,
          basicLoading: false
        },
        // 上传附件框-展示/隐藏
        fileUpdaloadBoxStatus: true,
        minHeight: null, //编辑框的初始高度
      }
    },
    created: function () {
      this.initData({ ...resetInit })
    },
    computed: {
      // 任务描述状态控制
      taskDescShowActiveStatusValue: function () {
        return this.statusObject.taskDescShowActiveStatus === "inactive" ? "active" : "inactive"
      },
      // 文件上传 - 附带信息 (当切换任务时，保证上传信息也更新)
      uploadInfo: function () {
        return {
          uploadActionUrl: $http.api.attachment.upload.url,
          upoladID: {
            workItemType: taskWorkTtemType,
            workItemId: this.detailInfo.id || 0
          },
        }
      },
      // 警告状态-标题
      warningStatusTitle: function () {
        return this.detailInfo.display.title.length > 50 && (this.statusObject.titleInputShowActiveStatus === 'active' || this.detailType === 'editable')
      },
      fieldEditObjectValues: function () {
        return Object.values(this.fieldEditObject)
      }
    },
    watch: {
      taskId: function (newInfo, oldInfo) {
        if (newInfo !== oldInfo) {
          if (this.taskId == -1 || this.taskId == 0) { return; }
          this.resetData(resetInit)
          this.getTaskInfo();
          this.getRevisedList()
        }
      },
      show: function (newInfo, oldInfo) {
        // if (newInfo) {
        //   this.resetData(resetInit)
        //   this.getTaskInfo();
        //   this.getRevisedList()
        //   this.$emit('update:descNotice', false);
        // }
      },
      statusObject: {
        handler(newInfo, oldInfo) {
          if (newInfo.fullScreen) {
            document.getElementById('contentBox').style.overflowY = 'hidden';
          } else {
            document.getElementById('contentBox').style.overflowY = '';
          }
        },
        deep: true
      }
    },
    methods: {
    
      // 任务工时自定义输入
      customInputChange(value) {
        var expectHour = Number(value)
        if (!/^\d+$/.test(expectHour)) {
          this.$message({
            showClose: true,
            message: '工时天数必须是整数',
            type: 'warning'
          });
          return false;
        }
        if (expectHour <= 0) {
          this.$message({
            showClose: true,
            message: '工时天数必须大于0',
            type: 'warning'
          });
          return false;
        }
        this.taskUpdate('expectHour', expectHour * 8)
      },
      //是否全屏
      fullScreenMethod() {
        this.statusObject.fullScreen = !this.statusObject.fullScreen;
        if (this.statusObject.fullScreen) {
          this.minHeight = document.documentElement.clientHeight;
        } else {
          this.minHeight = null;
        }
      },
      // 编辑器内容恢复
      async tinymceContentReset() {
        const exist = await this.isPreviousContentExist(+this.taskId, 'task', false, this.middleValue);
        if (exist) {
          this.$nextTick(() => {
            this.middleValue = exist;
            this.detailInfo.display.content = exist;
            this.statusObject.taskDescShowActiveStatus = 'active';
          })
        }
      },
      //添加关联
      getTaskList() {
        let list = {
          projectId: this.assocRequireSearchInfo.projectId,
          title: this.assocRequireSearchInfo.title,
          "orderBy": [{
            "column": "createTime",
            "order": "DESC"
          }],
          "pageInfo": {
            "pageNumber": this.assocRequirePageInfo.pageNumber,
            "pageSize": this.assocRequirePageInfo.pageSize
          }
        }
        $http.post($http.api.task.taskList, list).then((res) => {  //todo cpp 这里应该获取自己的queryType=1
          this.taskList = res.data.result;
          this.assocRequirePageInfo = res.data.pageInfo;
        })
      },
      handleSureAssocRequrie() {
        let assocRequrieIds = [];
        this.$refs["assocRequireTableRef"].selection.forEach(item => {
          assocRequrieIds.push(item.id);
        });
        let requestParam = {
          origWorkItemType: 2,
          targetWorkItemIds: assocRequrieIds,
          targetWorkItemType: this.assocRequireSearchInfo.type,
          origWorkItemId: this.taskId
        };
        $http.post($http.api.requirement.assoc_require, requestParam)
          .then(res => {
            // console.log(res)
            this.getAssocList(this.detailInfo);
            this.assocRequireDialogVisible = false;
          });
      },
      getDefectList() {
        $http.post($http.api.defect.defect_list,
          {
            projectId: this.assocRequireSearchInfo.projectId,
            title: this.assocRequireSearchInfo.title,
            orderBy: [{
              column: "createTime",
              order: "DESC"
            }],
            pageInfo: {
              pageNumber: this.assocRequirePageInfo.pageNumber,
              pageSize: this.assocRequirePageInfo.pageSize
            }
          }).then(res => {
            this.taskList = res.data.result;
            // console.log(this.DefecectData)
            this.assocRequirePageInfo = res.data.pageInfo;
          })
      },
      searchAssocRequrie() {
        if (
          (!this.assocRequireSearchInfo.type ||
            this.assocRequireSearchInfo.type == 0) &&
          !this.assocRequireSearchInfo.title
        ) {
          this.$message({ message: "关联类型和标题不能同时为空", type: "warning" });
          return;
        }
        this.assocRequirePageInfo.pageNumber = 1;
        this.assocRequirePageInfo.pageSize = 10;
        if (this.assocRequireSearchInfo.type === 2) {
          this.getTaskList();
          this.assocRequireSearchInfo.labeId = '任务ID';
          this.assocRequireSearchInfo.labelTitle = '任务标题'
        } else if (this.assocRequireSearchInfo.type === 3) {
          this.getDefectList();
          this.assocRequireSearchInfo.labeId = '缺陷ID';
          this.assocRequireSearchInfo.labelTitle = '缺陷标题'
        }

      },
      handleAssocRequirePageSizeChange(pageSize) {
        this.assocRequirePageInfo.pageSize = pageSize;
        // this.getSearchAssocRequireList();
        this.senAssocRuquset()
      },
      senAssocRuquset() {
        if (this.assocRequireSearchInfo.type === 2) {
          this.getTaskList()
        } else if (this.assocRequireSearchInfo.type === 3) {
          this.getDefectList()
        }
      },
      handleAssocRequirePageNumChange(pageNum) {
        this.assocRequirePageInfo.pageNumber = pageNum;
        this.senAssocRuquset()
      },
      parseInteger(value) {
        let val = value || this.projectId;
        return parseInt(val);
      },
      modalStatusChange() {
        this.assocRequireDialogVisible = true;
        this.searchAssocRequrie();
        // this.getProjectList();
      },
      //修订记录
      viewRequireRevise(reviseId) {
        $http.get($http.api.requirement.reviseDetail, { id: reviseId }).then(res => {
          if (res.status == 200) {
            this.revisedDialogVisible = true;
            this.$nextTick(() => {
              let elementById = document.getElementById("reviseDetail");
              elementById.innerHTML = res.data.content;
              // console.log(res.data.content)
            });
          }
        })
      },
      handleRevisedPageSizeChange(pageSize) {
        this.revisedPageInfo.pageSize = pageSize;
        this.getRevisedList();
      },
      handleRevisedPageNumChange(pageNum) {
        this.revisedPageInfo.pageNumber = pageNum;
        this.getRevisedList();
      },
      getRevisedList() {
        let pageInfo = {
          pageNumber: this.revisedPageInfo.pageNumber,
          pageSize: this.revisedPageInfo.pageSize
        };
        $http.post($http.api.requirement.revisedList, {
          workItemType: 2,
          workItemId: this.taskId,
          projectId: this.projectId || this.getUrlParams().projectId,
          pageInfo
        }).then(res => {

          this.revisedList = res.data.results;
          this.revisedPageInfo = res.data.pageInfo;

        });
      },
      tabRelateditem() {
        $http.get($http.api.requirement.relateditem, { id: this.requireId, projectId: this.projectId || this.getUrlParams().projectId }).then(ret => {
          let data = ret.data
          this.panelabel.tesk = `任务分解(${data.taskCount})`
          this.panelabel.childrequrie = `子需求(${data.childReqtCount})`
          this.panelabel.discuss = `评论(${data.commentCount})`
          this.panelabel.correctlist = `修订列表(${data.workConentCount})`
          this.panelabel.operarecord = `操作记录(${data.operationLogCount})`
        })
      },
      //提交评论
      onSubmitComment() {
        if (this.comment.trim() != "") {
          $http
            .post($http.api.comment.add, {
              workItemType: 2,
              workItemId: this.taskId,
              comment: this.comment.trim(),
              projectId: this.projectId || this.getUrlParams().projectId
            })
            .then(res => {
              this.commentPageInfo.pageNum = 1;
              // this.getCommentList();
              this.comment = "";
              this.commentUpdata = !this.commentUpdata; // 更新评论列表
              // this.tabRelateditem();
            });

        }
      },
      // 标题变化检测
      CHECKBEFORETITLEUPDATE(key, value) {
        // 不能为空检测
        if (this.detailInfo.display.title.trim().length < 1) {
          this.httpErrorHandle('标题不能为空')
          this.detailInfo.display.title = this.originalDetailInfo.display.title
          return false;
        }
        // 没有改变检测
        if (this.detailInfo.display.title !== this.originalDetailInfo.display.title) {
          this.showActiveStatusControl(key, value)
        } else {
          this.statusObject[key] = value;
        }
      },
      // 预计工时变化检测
      CHECKBEFOREEXPECTHOURUPDATE(key, value) {
        var expectHour = Number(this.detailInfo.expectHour)
        if (!/^\d+$/.test(expectHour)) {
          this.$message({
            showClose: true,
            message: '预计工时必须是整数',
            type: 'warning'
          });
          return false
        }
        if (expectHour < 0) {
          this.$message({
            showClose: true,
            message: '预计工时必须大于等于0',
            type: 'warning'
          });
          return false
        }
        if (this.detailInfo.expectHour % 2 > 0) {
          this.$message({
            showClose: true,
            message: '预计工时必须为2的整数倍',
            type: 'warning'
          });
          return false
        }
        if (expectHour === 0) { this.detailInfo.expectHour = 0 }
        // 没有改变检测
        if (this.detailInfo.expectHour !== this.originalDetailInfo.expectHour) {
          this.showActiveStatusControl(key, value)
        } else {
          this.statusObject[key] = value;
        }
      },
      // 实际工时变化检测
      CHECKBEFOREACTUALHOURUPDATE(key, value) {
        var actualHour = Number(this.detailInfo.actualHour)
        if (!/^\d+$/.test(actualHour)) {
          this.$message({
            showClose: true,
            message: '实际工时必须是整数',
            type: 'warning'
          });
          return false
        }
        if (actualHour < 0) {
          this.$message({
            showClose: true,
            message: '实际工时必须大于等于0',
            type: 'warning'
          });
          return false
        }
        if (actualHour === 0) { this.detailInfo.actualHour = 0 }
        // 没有改变检测
        if (this.detailInfo.actualHour !== this.originalDetailInfo.actualHour) {
          this.showActiveStatusControl(key, value)
        } else {
          this.statusObject[key] = value;
        }
      },
      // 开始时间变化检测
      CHECKBEFORESTARTTIMEUPDATE(key, value) {
        if (!this.detailInfo.startTime) {
          this.statusObject[key] = value;
          return false;
        }
        // 没有改变检测
        if (this.detailInfo.startTime === this.originalDetailInfo.startTime) {
          this.statusObject[key] = value;
          return true;
        }
        let nowDate = this.formatDate(new Date(), 'yyyyMMdd');
        let startTime = this.detailInfo.startTime.replace(/-/g, "");
        if (parseInt(nowDate.substring(0, 9)) > parseInt(startTime)) {
          this.$message({
            message: '预计开始日期不能小于当前日期',
            type: 'warning'
          })
          this.detailInfo.startTime = this.originalDetailInfo.startTime;
          this.statusObject[key] = value;
          return false;
        }
        if (this.detailInfo.startTime !== this.originalDetailInfo.startTime) {
          this.showActiveStatusControl(key, value)
        }
      },
      // 结束时间变化检测
      CHECKBEFOREFINISHTIMEUPDATE(key, value) {

        if (!this.detailInfo.endTime) {
          this.statusObject[key] = value;
          return false;
        }
        // 没有改变检测
        if (this.detailInfo.endTime === this.originalDetailInfo.endTime) {
          this.statusObject[key] = value;
          return true;
        }
        let nowDate = this.formatDate(new Date(this.detailInfo.endTime), 'yyyyMMdd');
        let endTime = this.detailInfo.endTime.replace(/-/g, "");
        if (parseInt(nowDate.substring(0, 9)) > parseInt(endTime)) {
          this.$message({
            message: '预计结束日期不能小于开始日期',
            type: 'warning'
          })
          this.detailInfo.endTime = this.originalDetailInfo.endTime;
          this.statusObject[key] = value;
          return false;
        }
        // 没有改变检测
        if (this.detailInfo.endTime !== this.originalDetailInfo.endTime) {
          this.showActiveStatusControl(key, value)
        }
      },
      // 进度变化检测
      CHECKBEFOREPROCESSUPDATE(key, value) {
        var progressvalue = Number(this.detailInfo.progress)
        if (!/^\d+$/.test(progressvalue)) {
          this.$message({
            showClose: true,
            message: '进度必须是整数',
            type: 'warning'
          });
          return false
        }
        if (progressvalue < 0 || progressvalue > 100) {
          this.$message({
            showClose: true,
            message: '进度只能在0到100之间',
            type: 'warning'
          });
          return false
        }
        if (progressvalue === 0) { this.detailInfo.progress = 0 }
        // 没有改变检测
        if (this.detailInfo.progress !== this.originalDetailInfo.progress) {
          this.showActiveStatusControl(key, value)
        } else {
          this.statusObject[key] = value;
        }
      },
      // 数据重置
      resetData(detailInfo) {
        // 1. 操作记录
        this.operateInfo = {
          operateList: [],
          operatePageInfo: {
            pageNum: 1,
            pageSize: 20,
            isMore: false
          }
        }
        // 2. 状态流转
        this.statusRecordInfo = {
          statusRecordList: [],
          statusRecordPageInfo: {
            pageNum: 1,
            pageSize: 100,
            isMore: false
          }
        }
        // 3. 任务编辑回到展示状态
        this.statusObject.taskDescShowActiveStatus = 'inactive'
        // 4. 保存原始数据
        this.originalDetailInfo = {
          ...detailInfo,
          display: {
            ...detailInfo.display
          }
        }
        // 5. 设置任务默认详情
        this.detailInfo = {
          ...detailInfo,
          display: {
            ...detailInfo.display,
            title: ''
          }
        }
        // 6. 附件信息
        this.uploadedFileList = []
      },
      // 标题、描述、实际工时、开始时间、结束时间、进度状态控制，更新标题、描述内容 - 这个函数设计的有点垃圾
      showActiveStatusControl(key, value) {
        this.statusObject[key] = value;
        if (value === "active") {
          switch (key) {
            case 'titleInputShowActiveStatus': this.$nextTick(function () { this.$refs.titleInput.focus(); }); break; // 标题聚焦
            case 'taskFatherRquire': this.cloneRquireModalStatus = true; break; // 标题聚焦
            case 'basicExpectHourActiveStatus': this.$nextTick(function () { this.$refs.basicExpectHour.focus(); }); break; // 预计工时聚焦
            case 'basicActualyHourActiveStatus': this.$nextTick(function () { this.$refs.basicActualyHour.focus(); }); break; // 实际工时聚焦
            case 'basicStartTimeActiveStatus': this.$nextTick(function () { this.$refs.basicStartTime.focus(); }); break; // 开始时间聚焦
            case 'basicEndTimeActiveStatus': this.$nextTick(function () { this.$refs.basicEndTime.focus(); }); break; // 结束时间聚焦
            case 'basicProcessActiveStatus': this.$nextTick(function () { this.$refs.basicProcess.focus(); }); break; // 进度聚焦
            default: ;
          }
        }
        if (value === "inactive") {
          // 更新数据
          switch (key) {
            case 'titleInputShowActiveStatus': this.originalDetailInfo.display.title = this.detailInfo.display.title; this.taskUpdate('title', this.detailInfo.display.title); break;
            case 'taskDescShowActiveStatus': this.detailInfo.display.content = this.middleValue; this.originalDetailInfo.display.content = this.detailInfo.display.content;
              this.removeTinymceContent(this.taskId);
              this.taskUpdate('content', this.detailInfo.display.content); break;
            case 'basicExpectHourActiveStatus': this.originalDetailInfo.expectHour = this.detailInfo.expectHour; this.taskUpdate('expectHour', this.detailInfo.expectHour); break;
            case 'basicActualyHourActiveStatus': this.originalDetailInfo.actualHour = this.detailInfo.actualHour; this.taskUpdate('actualHour', this.detailInfo.actualHour); break;
            case 'basicStartTimeActiveStatus': this.originalDetailInfo.startTime = this.detailInfo.startTime; this.taskUpdate('startTime', this.detailInfo.startTime); break;
            case 'basicEndTimeActiveStatus': this.originalDetailInfo.endTime = this.detailInfo.endTime; this.taskUpdate('endTime', this.detailInfo.endTime); break;
            case 'basicProcessActiveStatus': this.originalDetailInfo.progress = this.detailInfo.progress; this.taskUpdate('progress', this.detailInfo.progress); break;
            default: ;
          }
        }
      },
      // 编辑器监听
      editHnadle(data) {
        this.middleValue = data;
        if (data !== this.originalDetailInfo.display.content) {
          this.$emit('update:descNotice', true);
          this.saveTinymceContent({
            value: data,
            id: this.taskId,
            type: 'task', // 需求、任务、缺陷
            isNew: false
          })
        } else {
          this.$emit('update:descNotice', false);
        }
      },
      //评论监听
      editComentLister(data) {
        this.comment = data;
      },
      // 编辑器点击取消
      editCancel() {
        this.detailInfo.display.content = this.originalDetailInfo.display.content;
        this.middleValue = this.originalDetailInfo.display.content;
        this.statusObject.taskDescShowActiveStatus = 'inactive';
        this.$emit('update:descNotice', false);
        this.removeTinymceContent(this.taskId)
      },
      // 初始化 - 在 created 和 activeBugInfo 变化的时候才能调用的初始化方法
      initData(detailInfo) {
        // 数据重置
        this.resetData(detailInfo)
        this.getTaskInfo()
      },
      // 获取任务详情
      getTaskInfo() {
        if (!this.taskId) { return false; }
        $http.get($http.api.task.taskEdit, { id: this.taskId, projectId: this.projectId || this.getUrlParams().projectId }).then((result) => {  //todo cpp 这里应该获取自己的queryType=1
          if (!result.data) { return false; }
          this.detailInfo = {
            ...result.data,
            display: { ...result.data.display }
          }
          this.middleValue = result.data.display.content;
          this.originalDetailInfo = {
            ...result.data,
            display: { ...result.data.display }
          }
          this.tinymceContentReset() // 在拿到内容之后再更新之前的，放置被后面获取到的内容给冲突了
          this.setFieldEditObjectInitData(result.data)
          this.getStatusUpdatableList(result.data)
          this.getUploadedFileList(result.data)
          // this.getBugStatusRecordList(result.data)
          this.getBugOperateRecordList(result.data)
          this.getAssocList(result.data)
          setTimeout(() => { this.getBasicData(result.data) }, 300) // 延迟发起请求，300ms 用户无感
        })
      },
      // 获取任务基本信息 - 指派人、迭代、严重程度、任务原因的可选项值信息
      getBasicData(detailInfo) {
        const promiseArr = [], fieldEditObjectKeys = []
        if (this.fieldEditObject.assignUser.fieldEditProps.selectValue.length === 0) {
          // 获取可指派人员列表
          promiseArr.push(this.getAssignUsersList(detailInfo.projectId))
          fieldEditObjectKeys.push('assignUser')
        }
        if (this.fieldEditObject.relevantUsers.fieldEditProps.selectValue.length === 0) {
          // 获取可指派人员列表
          promiseArr.push(this.getAssignUsersList(detailInfo.projectId))
          fieldEditObjectKeys.push('relevantUsers')
        }
        if (this.fieldEditObject.sprint.fieldEditProps.selectValue.length === 0) {
          // 获取迭代列表
          promiseArr.push(this.getSpritList())
          fieldEditObjectKeys.push('sprint')
        }
        if (this.fieldEditObject.priority.fieldEditProps.selectValue.length === 0) {
          // 获取严重程度列表
          promiseArr.push(this.getPriorityList(taskWorkTtemType))
          fieldEditObjectKeys.push('priority')
        }
        if (this.fieldEditObject.expectHour.fieldEditProps.selectValue.length === 0) {
          // 获取预计工时列表
          promiseArr.push(this.getExpectHourList())
          fieldEditObjectKeys.push('expectHour')
        }
        if (promiseArr.length === 0) { return; }

        this.loadingStatus.basicLoading = true
        Promise.all(promiseArr).then(lists => {
          this.loadingStatus.basicLoading = false
          lists.forEach((item, index) => {
            if (item.status === 200) {
              let keyName = '', valueName = ''
              switch (fieldEditObjectKeys[index]) {
                case 'assignUser': keyName = 'userId', valueName = 'userName'; break;
                case 'relevantUsers': keyName = 'userId', valueName = 'userName'; break;
                case 'sprint': keyName = 'id', valueName = 'name'; break;
                case 'priority': keyName = 'priority', valueName = 'literal'; break;
                case 'expectHour': keyName = 'key', valueName = 'value'; break;
                default: ;
              }
              this.fieldEditObject[fieldEditObjectKeys[index]].fieldEditProps.selectValue = item.data.map(jtem => {
                return {
                  key: jtem[keyName],
                  value: keyName === 'userId' ? (jtem[valueName] + '(' + jtem[keyName] + ')') : jtem[valueName],
                  ...jtem
                }
              })
              if (fieldEditObjectKeys[index] === 'sprint') {
                this.fieldEditObject.sprint.fieldEditProps.selectValue.unshift({
                  key: 0,
                  value: '未规划'
                })
              }
            } else {
              this.httpErrorHandle(item.msg)
            }
          })
        }).catch(e => {
          this.loadingStatus.basicLoading = false
          this.httpErrorHandle('网络又出问题了，请刷新页面重试')
        })
        console.log(this.fieldEditObjectKeys)
      },
      // 获取可变更状态，每当数据状态变更的时候，都需要重新获取一遍可变更状态
      getStatusUpdatableList(detailInfo) {
        return $http.post($http.api.status.list_updatable, {
          workItemType: taskWorkTtemType,
          workItemId: detailInfo.id,
          statusId: detailInfo.statusId,
          projectId: this.projectId || this.getUrlParams().projectId
        }).then(data => {
          if (data.status === 200) {
            this.fieldEditObject.status.fieldEditProps.selectValue = data.data.map(jtem => {
              return {
                key: jtem['statusId'],
                value: jtem['statusName'],
                color: jtem.color || null
              }
            })
          }
        })
      },
      // 更新任务 - 不包含附件
      taskUpdate(key, value) {
        let postObj = {
          id: this.taskId,
          projectId: this.projectId || this.getUrlParams().projectId, // 项目id
          [key]: value
        }
        if(typeof key === 'object') {
          postObj = {...postObj, ...key}
        }
        $http.post($http.api.task.taskUpdate, postObj).then(result => {
          if (result.status === 200) {
            this.$message({
              message: '更新成功',
              type: 'success'
            })
            this.detailInfo = {
              ...this.detailInfo,
              ...result.data
            }
            this.operateCallback && this.operateCallback()
            // 更新 initValue initName
            this.setFieldEditObjectInitData(result.data)
            // 如果更新的是状态，则要把可变更状态重新获取一次
            if (key === 'statusId') {
              this.getStatusUpdatableList(result.data)
            }
            // 更新状态流转及操作记录数据
            // this.getBugStatusRecordList(this.detailInfo)
            this.getBugOperateRecordList(this.detailInfo)
            this.getRevisedList()
          } else {
            this.httpErrorHandle(result.msg || '更新失败')
          }
          this.$emit('update:descNotice', false);
        }).catch(_ => console.log(_))
      },
      // 点击关闭按钮
      async bugClose() {
        if (this.middleValue !== this.originalDetailInfo.display.content) {
          const confirmResult = await this.confirmBeforeOperate(`工作项描述已经填写/修改，请确认是否关闭`);
          if (!confirmResult) { return false; }
        }
        this.removeTinymceContent(this.taskId);
        this.$emit('update:descNotice', false);
        // this.resetData(resetInit)
        this.$emit("HandleSide")
      },
      // 删除任务
      handelTaskDelete() {
        let info = this.detailInfo
        this.$confirm(`确认删除任务\"${info.display.title}\"吗？`, {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(async () => {
          this.loadingStatus.bugDetailLoading = true;
          const result = await $http.get($http.api.task.deleteTask, { id: info.id, projectId: this.projectId || this.getUrlParams().projectId })
          this.loadingStatus.bugDetailLoading = false;
          if (result.status === 200) {
            this.$message({
              message: result.msg || '任务删除成功',
              type: 'success'
            })
            // 关闭当前 slider
            if (this.getUrlParams().taskId) {
              this.$router.replace({ path: this.$route.path, query: { ...this.$route.query, taskId: null } })
            }
            this.operateCallback && this.operateCallback();
            this.bugClose()
          } else {
            this.$message({
              message: result.msg || '任务删除失败',
              type: 'warning'
            })
          }
        }).catch(e => { })
      },
      // 关联工作项-获取已经关联的列表
      getAssocList(detailInfo) {
        if (detailInfo.id === resetInit.id) { return; }
        this.assocItemGetHandle({
          workItemType: taskWorkTtemType,
          workItemId: detailInfo.id,
          projectId: this.projectId || this.getUrlParams().projectId
        }).then(result => {
          if (result.status === 200 && result.data !== null) {
            this.assocObject.parentrequirements = result.data.parent ? [{ ...result.data.parent }] : []
            this.assocObject.requirements = result.data.requirements || []
            this.assocObject.tasks = result.data.tasks || []
            this.assocObject.defects = result.data.defects || []
          } else {
            this.assocObject.requirements = []
            this.assocObject.tasks = []
            this.assocObject.defects = []
            this.httpErrorHandle(result.msg)
          }
        })
      },
      // 关联工作项-点击删除
      assocItemDelete(info, type) {

        this.$confirm('确认删除该关联?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {

          let targetWorkItemType = '1'
          switch (type) {
            case 'requirement': targetWorkItemType = '1'; break;
            case 'task': targetWorkItemType = '2'; break;
            case 'defect': targetWorkItemType = '3'; break;
          }
          this.assocItemDeleteHandle({
            targetId: info.id,
            targetType: +targetWorkItemType,
            originId: this.detailInfo.id,
            originType: taskWorkTtemType,
            projectId: this.projectId || this.getUrlParams().projectId
          }).then(result => {
            if (result.status === 200) {
              this.$message({
                message: '关联项删除成功',
                type: 'success'
              })
              this.getAssocList(this.detailInfo)
            } else {
              this.httpErrorHandle(result.msg)
            }
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });

      },
      // 基本信息 - 初始值更新
      setFieldEditObjectInitData(detailInfo) {
        this.fieldEditObject.status.fieldEditProps.initValue = detailInfo.statusId
        this.fieldEditObject.status.fieldEditProps.initName = `<span class="statusbox-common" style="background-color: ${detailInfo.display.detail.status.color}">${detailInfo.display.status}</span>`
        this.fieldEditObject.priority.fieldEditProps.initValue = detailInfo.priority
        let font = (detailInfo.display.detail.priority.font && JSON.parse(detailInfo.display.detail.priority.font)) || { bold: false, size: '14' }
        this.fieldEditObject.priority.fieldEditProps.initName = `<span class="statusbox-common" style="background-color: ${detailInfo.display.detail.priority.color};">${detailInfo.display.priority}</span>`
        this.fieldEditObject.assignUser.fieldEditProps.initValue = detailInfo.assignUser;
        this.fieldEditObject.assignUser.fieldEditProps.initName = detailInfo.display.assignUser + '';
        this.fieldEditObject.relevantUsers.fieldEditProps.initValue = detailInfo.relevantUserIdList ? detailInfo.relevantUserIdList: [];
        this.fieldEditObject.relevantUsers.fieldEditProps.initName = detailInfo.display.relevantUsers + '';
        this.fieldEditObject.sprint.fieldEditProps.initValue = detailInfo.sprintId
        this.fieldEditObject.sprint.fieldEditProps.initName = detailInfo.display.sprint + '';
        this.fieldEditObject.expectHour.fieldEditProps.initValue = detailInfo.expectHour;
        this.fieldEditObject.expectHour.fieldEditProps.initName = Number(detailInfo.expectHour) / 8 + '天';
      },
      // 文件上传 - 获取已经上传的文件列表
      getUploadedFileList(detailInfo) {
        if (detailInfo.id === resetInit.id) { return; }
        $http.post($http.api.attachment.query, {
          workItemId: detailInfo.id,
          workItemType: taskWorkTtemType,
          projectId: this.projectId || this.getUrlParams().projectId
        }).then(result => {
          if (result.status === 200) {
            this.uploadedFileList = result.data.map(item => {
              return { name: item.origName, url: item.url, createUser: item.display.createUser,createTime:item.createTime, size: item.size, id: item.id }
            })
          } else {
            this.uploadedFileList = []
          }
        })
      },
      // 文件上传 - 成功处理函数
      handleUploadSuccess(res) {
        this.uploadedFileList.push({ name: res.data.origName, url: res.data.url, id: res.data.id,createTime:res.data.createTime,createUser:res.data.display.createUser })
        this.$message({
          message: '文件上传成功',
          type: 'success'
        })
      },
      // 文件上传 - 文件删除
      handleFileDelete(file) {
        if (this.detailInfo.id === resetInit.id) { return; }
        $http.post($http.api.attachment.delete, {
          workItemId: this.detailInfo.id,
          workItemType: taskWorkTtemType,
          projectId: this.projectId,
          attachmentId: file.id
        }).then(result => {
          if (result.status === 200) {
            this.$message({
              message: '文件删除成功',
              type: 'success'
            })
            this.uploadedFileList = this.uploadedFileList.filter(item => item.id !== file.id)
          } else {
            this.httpErrorHandle(result.msg || '文件删除失败')
          }
        })
      },
      // 文件上传 - 上传框是否隐藏
      fileUpdaloadBoxStatusHandle() {
        this.fileUpdaloadBoxStatus = !this.fileUpdaloadBoxStatus;
      },
      // 状态流转记录 - 获取记录列表 - 排序是根据 id 排序，本该根据时间，但是时间同 id 是相同方向排序的
      getBugStatusRecordList(detailInfo) {
        if (detailInfo.id === resetInit.id) { return; }
        $http.get($http.api.bug_info.bug_status_list, {
          id: detailInfo.id,
          pageNum: this.statusRecordInfo.statusRecordPageInfo.pageNum,
          pageSize: this.statusRecordInfo.statusRecordPageInfo.pageSize,
          projectId: detailInfo.projectId
        }).then(result => {
          if (result.status === 200) {
            if (this.statusRecordInfo.pageNum === 1) {
              this.statusRecordInfo.statusRecordList = result.data.list.reverse()
            } else {
              // 需要去重
              let sessionList = [...this.statusRecordInfo.statusRecordList.reverse(), ...result.data.list]
              this.statusRecordInfo.statusRecordList = [...new Set(sessionList.map(item => item.id))].sort((a, b) => b - a).map(item => {
                let record = {}
                for (let i = 0; i < sessionList.length; i++) {
                  if (sessionList[i].id === item) {
                    record = sessionList[i];
                    break;
                  }
                }
                return record
              }).reverse()
            }
            this.statusRecordInfo.statusRecordPageInfo.isMore = result.data.total > (this.statusRecordInfo.statusRecordPageInfo.pageNum * this.statusRecordInfo.statusRecordPageInfo.pageSize)
          } else {
            this.statusRecordInfo.statusRecordList = []
            this.statusRecordInfo.statusRecordPageInfo.isMore = false
          }
        })
      },
      // 状态流转记录 - 加载更多
      StatusRecordLoadmoreCallback() {
        if (!this.statusRecordInfo.statusRecordPageInfo.isMore) { return false; }
        this.statusRecordInfo.statusRecordPageInfo.pageNum = this.statusRecordInfo.statusRecordPageInfo.pageNum + 1
        this.$nextTick(function () {
          this.getBugStatusRecordList(this.detailInfo)
        })
      },
      // 任务操作记录 - 获取记录列表
      getBugOperateRecordList(detailInfo) {
        if (detailInfo.id === resetInit.id) { return; }
        $http.get($http.api.bug_info.bug_operate_list, {
          workItemId: detailInfo.id,
          workItemType: taskWorkTtemType,
          pageNum: this.operateInfo.operatePageInfo.pageNum,
          pageSize: this.operateInfo.operatePageInfo.pageSize,
          projectId: detailInfo.projectId
        }).then(result => {
          if (result.status === 200) {
            if (this.operateInfo.pageNum === 1) {
              this.operateInfo.operateList = result.data.list
            } else {
              // 需要去重
              let sessionList = [...this.operateInfo.operateList, ...result.data.list]
              this.operateInfo.operateList = [...new Set(sessionList.map(item => item.id))].sort((a, b) => b - a).map(item => {
                let record = {}
                for (let i = 0; i < sessionList.length; i++) {
                  if (sessionList[i].id === item) {
                    record = sessionList[i];
                    break;
                  }
                }
                return record
              })
              // this.operateInfo.operateList = [...this.operateInfo.operateList, ...result.data.list]
            }
            this.operateInfo.operatePageInfo.isMore = result.data.total > (this.operateInfo.operatePageInfo.pageNum * this.operateInfo.operatePageInfo.pageSize)
          } else {
            this.operateInfo.operateList = []
            this.operateInfo.operatePageInfo.isMore = false
          }
        })
      },
      // 任务操作记录 - 加载更多
      OperateLoadmoreCallback() {
        if (!this.operateInfo.operatePageInfo.isMore) { return false; }
        this.operateInfo.operatePageInfo.pageNum = this.operateInfo.operatePageInfo.pageNum + 1
        this.$nextTick(function () {
          this.getBugOperateRecordList(this.detailInfo)
        })
      }
    }
  };
</script>
<style lang="scss" scoped>
  @import "../ProjectCommon.scss";

  .edit-fullscreen {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    overflow: auto;
    background-color: white;
    z-index: 99999;
  }
</style>