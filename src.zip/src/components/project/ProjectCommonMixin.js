/**
 * @title 项目协同通用 mixin
 * @desc workItemType 需求-1， 任务-2， 缺陷-3
 * @func 目前已经支持的：缺陷 table、需求 table、任务 table、迭代 table
 * @time 2019.4.23
 * @update 2019.5.16
 * @author heyunjiang
 */

const BUGLIST = 'bugList';
const REQUIREMENT = 'requirementList'
const TASKVIEW = 'taskView'

const data = function () {
  return {
    GlobalSelectProps: {
      onChange: this.GlobalUpdate,
      onOtherClose: this.GlobalSelectClose,
      selectValue: [],
      initValue: '',
      multiple: false,
      show: false,
      customInput: true, // 任务自定义
      customInputPlaceHolder: '自定义天数', // 任务自定义
      customInputChange: this.GlobalCustomInputChange, // 任务自定义
      position: {
        left: 0,
        top: 0
      },
      GlobalLoading: false, // 是否在获取当前状态数据
      target: document.documentElement
    },
    GlobalCurrentInfo: {}, // 当前点击的初始信息
    GlobalSelectCB: null, // 当更新 select 的 callback
    GlobalWorkItemType: 1, // 不能通过 route 去判断，必须要通过 GlobalSelectTargetClick 传入，因为在同一 table 中存在3种 type
    dataSava: {}, // 通用数据保存在内存中，不用每次都去获取
    // 右侧滑窗关闭提醒数据：使用方式为 v-bind:title.sync="sliderBeforeCloseData.title" ，在组件内部当值变化时设置为 true，当滑窗关闭前判断，只要有 true 的就做提示
    sliderBeforeCloseData: {
      title: false, // 标题
      desc: false // 描述
    }
  }
}
// 全局table单项修改 methods
const globalTable = {
  // 全局table单项修改 - 关闭选择 select 框
  GlobalSelectClose() {
    this.GlobalSelectProps.show = false
    this.GlobalSelectProps.target = document.documentElement
  },
  // 全局table单项修改 - select - 获取严重程度
  async GlobalGetPriorityList(obj) {
    if (this.dataSava.priorityList) {
      this.GlobalSelectProps.selectValue = this.dataSava.priorityList
    } else {
      const result = await $http.get($http.api.bug_info.priorityList, {
        projectId: obj.projectId,
        workItemType: obj.workItemType
      })
      if (result.status !== 200 || result.data === null) { return false; }
      let selectValue = result.data.map(item => {
        return {
          key: item.priority,
          value: item.literal,
          ...item
        }
      })
      this.dataSava.priorityList = selectValue
      this.GlobalSelectProps.selectValue = selectValue
    }
  },
  // 全局table单项修改 - select - 获取可变更状态
  async GlobalGetStatusList(obj) {
    this.GlobalSelectProps.GlobalLoading = true
    const result = await $http.post($http.api.bug_info.statusUpdatableList, {
      workItemType: obj.workItemType,
      workItemId: obj.workItemId,
      statusId: obj.statusId,
      projectId: obj.projectId
    })
    this.GlobalSelectProps.GlobalLoading = false
    if (result.status !== 200 || result.data === null) { return false; }
    this.GlobalSelectProps.selectValue = result.data.map(item => {
      return {
        key: item.statusId,
        value: item.statusName,
        updateName: 'statusId',
        ...item
      }
    })
  },
  // 全局table单项修改 - select - 获取缺陷原因
  async GlobalGetCauseList(obj) {
    if (this.dataSava.causeList) {
      this.GlobalSelectProps.selectValue = this.dataSava.causeList
    } else {
      let result = await $http.get($http.api.bug_info.causeList, {
        projectId: obj.projectId
      })
      if (result.status !== 200 || result.data === null) { return false; }
      const selectValue = result.data.map(item => {
        return {
          key: item.cause,
          value: item.literal,
          ...item
        }
      })
      this.dataSava.causeList = selectValue
      this.GlobalSelectProps.selectValue = selectValue
    }
  },
  // 全局table单项修改 - select - 获取有效迭代列表
  async GlobalGetSprintList(obj) {
    if (this.dataSava.spritList) {
      this.GlobalSelectProps.selectValue = this.dataSava.spritList
    } else {
      const result = await $http.get($http.api.bug_info.spritList, {
        projectId: obj.projectId,
        status: 1
      })
      if (result.status !== 200 || result.data === null) { return false; }
      let selectValue = result.data.map(item => {
        return {
          key: item.id,
          value: item.name,
          ...item
        }
      })
      this.dataSava.spritList = selectValue
      this.GlobalSelectProps.selectValue = selectValue
      // 增加未规划
      this.GlobalSelectProps.selectValue.unshift({
        key: 0,
        value: '未规划'
      })
    }
  },
  // 全局table单项修改 - select - 获取处理人列表
  async GlobalGetAssignUserList(obj) {
    if (this.dataSava.assignUsersList) {
      this.GlobalSelectProps.selectValue = this.dataSava.assignUsersList
    } else {
      const result = await $http.post($http.api.bug_info.assignUsersList, {
        projectId: obj.projectId,
        query: ''
      })
      if (result.status !== 200 || result.data === null) { return false; }
      let selectValue = result.data.map(item => {
        return {
          key: item.userId,
          value: item.userName + '(' + item.userId + ')',
          ...item
        }
      })
      this.dataSava.assignUsersList = selectValue
      this.GlobalSelectProps.selectValue = selectValue
    }

  },
  // 全局table单项修改 - select - 获取需求分类列表
  async GlobalGetCategoryList(obj) {
    const result = await $http.get($http.api.requirementCategory.list, {
      projectId: obj.projectId
    })
    if (result.status !== 200 || result.data === null) { return false; }
    this.GlobalSelectProps.selectValue = result.data.map(item => {
      let obj = {
        key: item.id,
        value: item.label,
        ...item
      }
      delete obj.label;
      return obj;
    })
  },
  // 全局table单项修改 - select - 获取预计工时列表
  GlobalGetExpectHourList(obj) {
    this.GlobalSelectProps.selectValue = this.$store.state.pf.expectHourList;
    // this.$set(this.GlobalSelectProps, )
    this.GlobalSelectProps.customInput = true;
  },
  //api文档状态
  GlobalGetFileStatusList(obj) {
    this.GlobalSelectProps.selectValue = [
      { key: "1", value: "已完成" },
      { key: "0", value: "未完成" },
    ]
  },

  // 全局修改表格单元格 - 点击具体元素 - select
  async GlobalSelectTargetClick(info, e, type, cb) {
    let workItemType
    switch (this.$route.name) {
      case REQUIREMENT: workItemType = info.workItemType || 1; break;
      case TASKVIEW: workItemType = info.workItemType || 2; break;
      case BUGLIST: workItemType = info.workItemType || 3; break;
      default: workItemType = info.workItemType || 1;
    }
    // 设置显示，设置初始值
    this.GlobalSelectProps.show = false;
    this.GlobalSelectProps = {
      onChange: this.GlobalUpdate,
      onOtherClose: this.GlobalSelectClose,
      selectValue: [],
      initValue: '',
      multiple: false,
      show: true,
      customInput: false,
      customInputPlaceHolder: '自定义天数', // 任务自定义
      customInputChange: this.GlobalCustomInputChange, // 任务自定义
      GlobalLoading: false,
      target: e.target // 临时添加，方便更好定位
    }
    // console.log(this.GlobalSelectProps)
    this.GlobalCurrentInfo = { ...info, type }
    this.GlobalSelectCB = cb ? cb : null
    this.GlobalWorkItemType = workItemType
    const projectId = this.getUrlParams().projectId || this.projectId;
    // 获取可选择列表数据
    switch (type) {
      // 严重程度、优先级
      case 'priority': this.GlobalGetPriorityList({ projectId, workItemType });
        this.$set(this.GlobalSelectProps, 'colorType', 'font');
        break;
      // 状态
      case 'statusId': this.GlobalGetStatusList({ projectId, workItemType, workItemId: info.id, statusId: info.statusId || 0 });
        this.$set(this.GlobalSelectProps, 'colorType', 'bg');
        workItemType === 3 && this.$set(this.GlobalSelectProps, 'beforeSelect', (...rest) => { this.bugStatusClickCallback(...rest, info) }); // 缺陷需要设置二级状态及添加评论
        break;
      // 缺陷原因
      case 'cause': this.GlobalGetCauseList({ projectId }); break;
      // 所属迭代
      case 'sprintId': this.GlobalGetSprintList({ projectId }); break;
      // 处理人
      case 'assignUser': this.GlobalGetAssignUserList({ projectId });
        this.$set(this.GlobalSelectProps, 'localSearch', true);
        break;
      // 需求分类
      case 'categoryId': this.GlobalGetCategoryList({ projectId }); break;
      // 预计工时
      case 'expectHour': this.GlobalGetExpectHourList({ projectId }); break;
      //接口分类
      case 'getproject': this.GlobalGetExpectHourList({ projectId }); break;
      case 'getfilestatus': this.GlobalGetFileStatusList({ projectId }); break;
      default: ;
    }
  },
  // 全局修改表格单元格 - 更新信息 - 组装信息
  GlobalUpdate(value) {
    switch (this.GlobalWorkItemType) {
      case 3: this.GlobalBugUpdate({ [this.GlobalCurrentInfo.type]: value }); break;
      case 2: this.GlobalTaskUpdate({ [this.GlobalCurrentInfo.type]: value }); break;
      case 1: this.GlobalRequirementUpdate({ [this.GlobalCurrentInfo.type]: value }); break;
    }
  },
  // 全局修改表格单元格 - 更新缺陷信息
  GlobalBugUpdate(obj) {
    let postObj = {
      id: this.GlobalCurrentInfo.id,
      projectId: this.GlobalCurrentInfo.projectId, // 项目id
      ...obj
    }
    $http.post($http.api.bug_info.update_bug_post, postObj).then(result => {
      if (result.status === 200) {
        // 1 提示更新成功
        this.$message({
          message: '更新成功',
          type: 'success'
        })
        // 2 更新当前列表
        obj.cb && obj.cb()
        this.GlobalSelectCB && this.GlobalSelectCB()
      } else {
        this.httpErrorHandle(result.msg || '更新失败')
      }
    }).catch(_ => console.log(_))
  },
  // 全局修改表格单元格 - 更新任务信息
  GlobalTaskUpdate(obj) {
    if (obj.expectHour) {
      if (!/^\d+$/.test(obj.expectHour)) {
        this.$message({
          showClose: true,
          message: '预计工时必须是整数',
          type: 'warning'
        });
        return false
      }
      if (obj.expectHour < 0) {
        this.$message({
          showClose: true,
          message: '预计工时必须大于等于0',
          type: 'warning'
        });
        return false
      }
      if (obj.expectHour % 2 > 0) {
        this.$message({
          showClose: true,
          message: '预计工时必须为2的整数倍',
          type: 'warning'
        });
        return false
      }
    }
    let postObj = {
      id: this.GlobalCurrentInfo.id,
      projectId: this.GlobalCurrentInfo.projectId, // 项目id
      ...obj
    }
    $http.post($http.api.task.taskUpdate, postObj).then(result => {
      if (result.status === 200) {
        // 1 提示更新成功
        this.$message({
          message: '更新成功',
          type: 'success'
        })
        // 2 更新当前列表
        obj.cb && obj.cb()
        this.GlobalSelectCB && this.GlobalSelectCB()
      } else {
        this.httpErrorHandle(result.msg || '更新失败')
      }
    }).catch(_ => console.log(_))
  },
  // 全局修改表格单元格 - 更新需求信息
  GlobalRequirementUpdate(obj) {
    let postObj = {
      id: this.GlobalCurrentInfo.id,
      projectId: this.GlobalCurrentInfo.projectId, // 项目id
      ...obj
    }
    $http.post($http.api.requirement.update, postObj).then(result => {
      if (result.status === 200) {
        // 1 提示更新成功
        this.$message({
          message: '更新成功',
          type: 'success'
        })
        // 2 更新当前列表
        obj.cb && obj.cb()
        this.GlobalSelectCB && this.GlobalSelectCB()
      } else {
        this.httpErrorHandle(result.msg || '更新失败')
      }
    }).catch(_ => console.log(_))
  },
  // 全局修改表格单元格 - 任务工时自定义输入
  GlobalCustomInputChange(value) {
    var expectHour = Number(value)
    if (!/^\d+$/.test(expectHour)) {
      this.$message({
        showClose: true,
        message: '工时天数必须是整数',
        type: 'warning'
      });
      return false;
    }
    if (expectHour <= 0) {
      this.$message({
        showClose: true,
        message: '工时天数必须大于0',
        type: 'warning'
      });
      return false;
    }
    this.GlobalUpdate(expectHour * 8)
  },
}

const methods = {
  sleep(time) {
    return new Promise((resolve) => {
      setTimeout(resolve, time)
    })
  },
  // 1 关联工作项 - 获取关联工作项
  assocItemGetHandle(obj = {
    workItemType: 1, // 源类型 需求-1， 任务-2， 缺陷-3
    workItemId: 0, // 源 id
    projectId: 1 // 项目id
  }) {
    return $http.get($http.api.bug_info.assoc_list, { ...obj })
  },
  // 1 关联工作项 - 点击删除
  assocItemDeleteHandle(obj = {
    targetId: 0, // 目标 id
    targetType: 1, // 目标类型 需求-1， 任务-2， 缺陷-3
    originId: 0, // 源 id
    originType: 1, // 源类型 需求-1， 任务-2， 缺陷-3
    projectId: 1 // 项目id
  }) {
    return $http.post($http.api.bug_info.remove_assoc_item, {
      origWorkItemType: obj.originType,
      origWorkItemId: obj.originId,
      targetWorkItemType: obj.targetType,
      targetWorkItemId: obj.targetId,
      projectId: obj.projectId
    })
  },
  // 1 关联工作项 - 点击某条关联项 requirement | task | defect
  assocItemClick(info, type) {
    if (this.assocClickCallback) {
      // 如果传了处理函数，则交给它处理
      this.assocClickCallback(info, type)
    } else {
      // 如果没有传处理函数，则自行默认跳转
      switch (type) {
        case 'requirement': this.goToNewWindowPage(this, "requirementList", { requireId: info.id, projectId: info.projectId || this.projectId }); break;
        case 'task': this.goToNewWindowPage(this, "taskView", { taskId: info.id, projectId: info.projectId || this.projectId }); break;
        case 'defect': this.goToNewWindowPage(this, "bugList", { bugId: info.id, projectId: info.projectId || this.projectId }); break;
      }
    }
  },
  // 2 需求 - 删除需求
  requirementDelete(obj = { id: 0 }) {
    return $http.get($http.api.requirement.delete, { ...obj })
  },
  // 2 需求 - 解除需求父子关系
  requirementUnbindParentChild(obj = {
    id: 0, // 子需求 id
    parentId: 0 // 父需求 id
  }) {
    return $http.post($http.api.requirement.unbindParentChild, { ...obj })
  },
  //全局修改table-优先级,严重程度,状态的样式
  initNameStatus(color, item) {
    // if(item.length>3){ 
    //   return `<span class="statusbox-list-common" style="background-color: ${color}" title = "${item}">${item.substring(0,2)+'...'}</span>`
    // }
    return `<span class="statusbox-list-common" style="background-color: ${color}">${item}</span>`
  },
  // 3 任务分解 - 时间联动
  time_linkage_calculate(obj = {
    startTime: null,
    endTime: null,
    expectHour: null,
    modifiedFiled: 'startTime'
  }) {
    return $http.get($http.api.task.time_linkage_calculate, { ...obj })
  },
  // 预计工时自定义扩展验证
  expectHourDayChangeValid(value) {
    return (+value) % 0.5 === 0
  },
  // 操作前的确认
  async confirmBeforeOperate(text = '') {
    let result = null
    try {
      result = await this.$confirm(text, {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: 'warning'
      })
    } catch (_) {
      result = false;
    }
    return result;
  },
  // slider 右侧滑窗关闭前判断
  async beforeSliderClose({ cb, id }) {
    let noticeTitle = '工作项';
    if (this.sliderBeforeCloseData.title) {
      noticeTitle += '标题';
    }
    if (this.sliderBeforeCloseData.desc) {
      if (this.sliderBeforeCloseData.title) {
        noticeTitle += '和描述';
      } else {
        noticeTitle += '描述';
      }
    }
    if (this.sliderBeforeCloseData.title || this.sliderBeforeCloseData.desc) {
      const confirmResult = await this.confirmBeforeOperate(`${noticeTitle}已经填写/修改，请确认是否关闭`);
      if (!confirmResult) { return false; }
      this.sliderBeforeCloseData.title = false;
      this.sliderBeforeCloseData.desc = false;
    }
    // 清除 localstorage 内容
    id && this.removeTinymceContent(id)
    // 执行回调
    cb && cb();
  },
  // 自定义字段 - 获取 select 可选 option 值，可用户基本信息 + 过滤器
  async getCustomFieldOptions({ projectId, workItemType, attrName }) {
    let arr = [];
    if(!attrName) {return arr;}
    let result = {};
    try {
      result = await $http.get($http.api.CustomField.custom_field_choices, {
        projectId: projectId || this.projectId,
        workItemType: workItemType || 1,
        attrName: attrName
      });
    } catch (_) {
      result.status = 0;
    }
    if (result.status === 200) {
      arr = result.data.map(item => {
        return {
          ...item,
          key: item.choice,
          value: item.value
        }
      });
    }
    return arr;
  },
  //隐藏上传&关联文档tips
  publicHideTips(e){
    if(!e){
      return false
    }
    let classList = [...document.getElementsByClassName("file-popper")]
    if(e.target.innerHTML== "附件上传"){
      classList.forEach(el => {
        el.style.display = 'block'
      });
    }else{
      classList.forEach(el => {
        el.style.display = 'none'
      });
    }  
  },
  // 获取自定义字段列表
  getCustomFieldList(workItemType = 1, projectId) {
    this.$store.dispatch({
      type: 'getCustomField',
      payload: { 
        workItemType:workItemType,
        projectId: projectId || this.projectId 
      }
    });
  },
  // 获取自定义字段默认值对象
  getCustomFieldsPresetValues(workItemType = 1) {
    const state = this.$store.state;
    const customFieldListOriginal = state.pf.CUSTOMFIELDSELECTVALUES[state.pf.workItemTypeMap[workItemType]];
    const obj = {};
    if(!customFieldListOriginal) {return obj;}
    customFieldListOriginal.filter(item => item.enabled).forEach(item => {
      let presetValue = {};
      try {
        presetValue = JSON.parse(item.presetValue);
      } catch (_) {}
      obj[item.attrName] = presetValue.key
    })
    return {userDefinedAttrs: {...obj}};
  },
  ...globalTable
}
export default {
  data,
  methods
}
