<template>
  <div class="BasicInfoCustomFieldBox" :class="{'customFieldInElRow': customFieldInElRow}">
    <template v-for="item in customFieldList">
      <div class="bug-basic-info-item" :class="{'bug-basic-info-item-select': detailType==='editable'}" :key="item.key">
        <ellipsis-block class="bug-basic-info-item-label" :value="item.value + ':'"></ellipsis-block>
        <field-edit v-if="detailType==='show'" v-bind="item.fieldEditProps"
            @FieldEditFieldClick="getSelectOptionList(item)"
            :onChange="(value)=>{updateInfoWhenShow(item.key, value)}"
        ></field-edit>
        <typed-form-item  v-else
          class="bug-basic-info-item-select-width"
          @change="updateModel"
          v-model="item.fieldEditProps.initValue"
          :type="item.attrValue"
          :selectList="item.fieldEditProps.selectValue"
          :filterField="false"></typed-form-item>
      </div>
    </template>
  </div>
</template>
<script>
/**
 * @title 自定义字段组件 - 基本信息
 * @desc 需求、任务、缺陷基本信息通用
 * @function 1. 支持新建、展示2种模式
 * @function 2. 支持新建时记录的 sessionStorage 数值
 * @author heyunjiang
 * @date 2019.8.30
 */
import { mapState } from 'vuex';
import FieldEdit from "@/components/tool/FieldEdit";

const attrValueToInputTypeMap = {
  SINGLE_TEXT: 'text',
  MULTI_TEXT: 'textarea',
  MEMBER_CHOICE: 'select',
  LITE_DATE_ATTR: 'date',
  BOOLEAN_ATTR: 'boolean',
  INT_ATTR: 'number',
  FLOAT_ATTR: 'number',
  SINGLE_CHOICE: 'select',
  MULTI_CHOICE: 'select'
}

export default {
  name: "BasicInfoCustomField",
  components: {
    FieldEdit
  },
  model: {
    prop: 'value',
    event: 'change'
  },
  mixins: [],
  props: {
    projectId: {
      type: [String, Number],
      required: true
    },
    workItemType: {
      type: [String, Number],
      required: true,
      desc: '工作项类型'
    },
    // 当前组件状态， show -> 展示， editable -> 新建
    detailType: {
      type: String,
      required: true,
      validator: function (value) {
        return ["show", "editable"].indexOf(value) !== -1;
      }
    },
    detailInfo: Object, // 基本信息数据源
    sessionStorageData: {
      type: Object,
      required: false,
      default: () => { return {} },
      desc: '缓存数据设置默认值'
    }, 
    updateField: Function, // 更新字段 -> 展示模式时
    customFieldInElRow: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否是在 element-ui 的 el-row 里面，如果是，则需要调整样式'
    }
  },
  data() {
    return {}
  },
  computed: {
    // ...mapState({
    //   customFieldListOriginal: state => state.pf.CUSTOMFIELDSELECTVALUES[state.pf.workItemTypeMap[this.workItemType]]
    // }),
    // 自定义字段列表
    customFieldList() {
      const state = this.$store.state;
      const customFieldListOriginal = state.pf.CUSTOMFIELDSELECTVALUES[state.pf.workItemTypeMap[this.workItemType]];
      if(!customFieldListOriginal) {return [];}
      return customFieldListOriginal.filter(item => item.enabled).map(item => {
        return {
          ...item,
          fieldEditProps: {
            initValue: ''
          }
        }
      })
    }
  },
  watch: {
    customFieldList() {
      this.setCustomFieldInitData();
    },
    detailInfo() {
      this.setCustomFieldInitData();
    }
  },
  mounted() {
    this.initList();
  },
  methods: {
    // 获取自定义字段列表
    initList() {
      this.$store.dispatch({
        type: 'getCustomField',
        payload: { 
          workItemType: this.workItemType,
          projectId: this.projectId 
        }
      });
      this.setCustomFieldInitData();
    },
    // 设置自定义字段 fieldEditProps 属性
    setCustomFieldInitData() {
      const detailType = this.detailType;
      const detailInfo = this.detailInfo;
      const sessionStorageData = this.sessionStorageData;
      const userDefinedAttrs = this.generateCustomFieldStruct((detailInfo.display && detailInfo.display.userDefinedAttrs) || []); // 封装自定义字段格式
      const customFieldInitTypeMap = this.$store.state.cm.customFieldInitTypeMap;
      this.customFieldList.forEach(item => {
        const fieldEditProps = {};
        const ismultiple = ['MULTI_CHOICE'].includes(item.attrValue);
        const surportLocalSearch = ['MEMBER_CHOICE'].includes(item.attrValue);

        const readValueKey = 'value'; // 暂时认为只有多选框才使用 values 属性
        let presetValue = {};
        try {
          presetValue = JSON.parse(item.presetValue);
        } catch (_) {}
        // 1. 设置初始值
        if(detailType === 'show') {
          let initValue = '';
          // 如果是展示模式，则从 detailInfo 里面拿初始数据
          let initName = (userDefinedAttrs[item.attrName] && userDefinedAttrs[item.attrName][readValueKey]);
          initName = Array.isArray(initName) ? initName.join(',') : initName; // 数组
          initName = typeof initName === 'boolean' ? (initName ? '是' : '否') : initName; // 布尔值
          try {
            initValue = (userDefinedAttrs[item.attrName] && userDefinedAttrs[item.attrName]['rawValue']);
            initName = initName.trim();
          } catch (_) {}
          // console.log(item.fieldName, initValue, presetValue, customFieldInitTypeMap[item.attrValue])
          fieldEditProps.initValue = initValue == undefined ? customFieldInitTypeMap[item.attrValue] : initValue;
          fieldEditProps.initName = String(initName);
        } else {
          // 如果是新建模式，则从 sessionStorageData, 远程获取 里面拿初始数据
          // 加层 try catch 是为了保护旧数据
          try {
            fieldEditProps.initValue = sessionStorageData[item.attrName] || presetValue.key;
          } catch (_) {}
        }
        // console.log(item.fieldName, fieldEditProps.initValue, presetValue.key)
        fieldEditProps.inputType = attrValueToInputTypeMap[item.attrValue];
        fieldEditProps.selectValue = item.fieldEditProps.selectValue || [];
        fieldEditProps.multiple = ismultiple;
        fieldEditProps.localSearch=surportLocalSearch;
        item.fieldEditProps = fieldEditProps;
        // 如果是新建模式，则需要获取 select 类型属性字段的可选择值
        if(detailType === 'editable') {
          this.getSelectOptionList(item);
        }
      })
      if(detailType === 'show') {
        this.$forceUpdate();
      }
      this.updateModel();
    },
    // 获取字段可选择值列表列表 - 在 for 循环里面执行 async 的一个场景
    async getSelectOptionList(field) {
      // 如果不是 select 类型的，则跳过
      if(attrValueToInputTypeMap[field.attrValue] !== 'select') {return ;}
      // 如果是人员选择，则去拿人员选择数据
      if(field.attrValue === 'MEMBER_CHOICE') {
        this.getAssignUsersList(field);
        return ;
      }
      let result = {};
      try {
        result = await $http.get($http.api.CustomField.custom_field_choices, {
          projectId: this.projectId,
          workItemType: this.workItemType,
          attrName: field.attrName
        });
      } catch(_) {
        result.status = 0;
      }
      if(result.status === 200) {
        const list = result.data.map(item => {
          return {
            ...item,
            key: item.choice,
            value: item.value
          }
        });
        const fieldEditProps = {
          selectValue: list
        }
        // if(!field.fieldEditProps.initValue && list.length > 0 && this.detailType==='editable') {
        //   fieldEditProps.initValue = field.fieldEditProps.multiple ? [list[0].key] : list[0].key;
        // }
        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps
        }
        this.$forceUpdate();
        this.updateModel();
      }
      return true;
    },
    // 获取人员列表
    async getAssignUsersList(field) {
      // 减少发起的请求，增加效率
      if(field.fieldEditProps.selectValue.length > 0) {return ;}
      const result = await $http.post($http.api.bug_info.assignUsersList, {
        projectId: this.projectId,
        query: ''
      });
      if (result.status && result.status === 200) {
        const list = result.data.map(item => {
          return {
            ...item,
            key: item.userId,
            value: item.userName  + "(" + item.userId + ")"
          }
        })
        const fieldEditProps = {
          selectValue: list
        }
        // if(!field.fieldEditProps.initValue && list.length > 0 && this.detailType==='editable') {
        //   fieldEditProps.initValue = field.fieldEditProps.multiple ? [list[0].key] : list[0].key;
        // }
        field.fieldEditProps = {
          ...field.fieldEditProps,
          ...fieldEditProps
        }
        this.$forceUpdate();
      }
    },
    // 封装自定义字段格式
    generateCustomFieldStruct(userDefinedAttrs) {
      const obj = {};
      userDefinedAttrs.forEach(item => {
        obj[item.attrName] = {...item}
      });
      return obj;
    },
    // 更新自定义字段值
    updateInfoWhenShow(key, value) {
      if(!this.updateField) {return ;}
      this.updateField({
        userDefinedAttrs: {
          [key]: value
        }
      })
    },
    // 更新 v-model 值
    updateModel() {
      const modelObj = {};
      Object.values(this.customFieldList).forEach(item => {
        modelObj[item.key] = item.fieldEditProps.initValue;
      })

      this.$emit('change', modelObj)
    },
  }
}
</script>
<style lang="scss" scoped>
@import "./ProjectCommon";

.bug-basic-info-item-input-box {
  display: inline-block;
  position: relative;
  height: 100%;
  box-sizing: border-box;
  padding: 0 5px;
}

// 只在当前模块有效
.bug-basic-info-item {
  height: auto !important;
  line-height: 22px !important;
  font-size: $font-size-medium;
  &.bug-basic-info-item-select {
    padding: 5px 0;
  }
  // lable
  .bug-basic-info-item-label {
    vertical-align: top;
    display: inline-block;
    min-width: 90px;
    max-width: 100px;
    overflow: hidden;
    @extend .list-item-ellipsis;
  }
  // 非 field-edit 字段样式
  .bug-basic-info-item-static {
    display: inline-block;
    padding: 0 10px;
    max-width: calc(100% - 123px);
    @extend .list-item-ellipsis;
  }
  // 新建缺陷时才有的
  .bug-basic-info-item-select-width {
    max-width: calc(100% - 105px);
    overflow: hidden;
    display: inline-block;
  }
  .basic-title-input-active {
    @extend .bug-basic-info-item-select-width;
  }
}

.customFieldInElRow {
  float: left;
  padding-left: 5px;
  padding-right: 5px;
  width: 100%;
}
</style>
