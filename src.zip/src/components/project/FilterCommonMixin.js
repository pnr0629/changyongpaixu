/**
 * 自定义过滤器通用 mixin
 * 场景：需求、任务、缺陷
 * time: 2019.8.31
 * author: heyunjiang
 */

const attrValueToInputTypeMap = {
  SINGLE_TEXT: 'text',
  MULTI_TEXT: 'textarea',
  MEMBER_CHOICE: 'select',
  LITE_DATE_ATTR: 'date',
  BOOLEAN_ATTR: 'boolean',
  INT_ATTR: 'number',
  FLOAT_ATTR: 'number',
  SINGLE_CHOICE: 'select',
  MULTI_CHOICE: 'select'
}

const props = {
  filterInitData: {
    type: Object,
    default: () => { return {} },
    desc: '过滤器默认值'
  },
  projectId: [String, Number],
}

const data = () => {
  return {
    customFilterList: [], // 过滤器列表
    filterTypeValue: '', // 过滤器列表选择值
    isFilterOpen: false, // 是否展开过滤器
    requirementFilterList: [], // 需求列表
    selectedCUSTOMFIELD: [], // 当前选中的 自定义字段 key 集合
    selectedCUSTOMFIELDVALUES: [], // 当前展示的自定义字段 list
    filterSaveDialog: {
      status: false,
      name: ''
    },
    saveLoading: false, // 保存过滤器
    getLoading: false, // 获取编辑器过滤器详情等
  }
}

const computed = {
  // 处理人
  assignUserFilterList() {
    return this.$store.state.pf.PROJECTFIELDSELECTVALUES.assignUserList[this.workItemType];
  },
  // 状态
  statusFilterList() {
    return this.$store.state.pf.PROJECTFIELDSELECTVALUES.statusIdList[this.workItemType];
  },
  // 优先级
  prioritiesFilterList() {
    return this.$store.state.pf.PROJECTFIELDSELECTVALUES.priorityList[this.workItemType];
  },
  // 自定义字段列表
  customFieldList() {
    const state = this.$store.state;
    const customFieldListOriginal = state.pf.CUSTOMFIELDSELECTVALUES[state.pf.workItemTypeMap[this.workItemType]];
    if(!customFieldListOriginal) {return [];}
    return customFieldListOriginal.filter(item => item.enabled).map(item => {
      return {
        ...item,
        fieldEditProps: {
          selectValue: []
        }
      }
    });
  },
  // 更多自定义字段按钮 props
  FieldEditProps() {
    return {
      initValue: this.selectedCUSTOMFIELD || [],
      initName: `<button type="button" class="el-button el-button--text" style="padding-left: 0 !important">更多自定义字段<i class="el-icon-caret-bottom"></i></button>`,
      selectValue: this.customFieldList || [],
      onChange: this.setSelectedCUSTOMFIELD,
      localSearch: true,
      showOuterBorder: false,
      multiple: true
    }
  },
}

const watch = {
  filterInitData() {
    this.updateFilterData(this.filterInitData);
  },
  // 及时获取自定义字段为选择框时，获取可选择的值
  customFieldList() {
    this.customFieldList.forEach(item => {
      this.getSelectOptionList(item);
    })
  }
}

const methods = {
  // 初始化过滤器
  initData() {
    // 获取自定义字段
    this.$store.dispatch({
      type: 'getCustomField',
      payload: { 
        workItemType: this.workItemType,
        projectId: this.projectId 
      }
    });
    // this.setCustomFieldInitData();
    // 获取优先级、状态等数据 list
    this.$store.dispatch({
      type: 'initDataPROJECTFIELD',
      payload: {
        projectId: this.projectId,
        workItemType: this.workItemType
      }
    });
    this.getRequireList();
    this.getFilterList();
    this.updateFilterData(this.filterInitData);
  },
  // 更新过滤器过滤值 - 必须传入一个整体结构，否则未传入的会被初始化
  updateFilterData(data = {}) {
    Object.keys(this.filterData).forEach(item => {
      if (Array.isArray(this.filterData[item])) {
        let initEmptyValue = ['all'];
        // 如果是时间，则默认值保持为空数组
        if(item.toLowerCase().indexOf('time') !== -1) {
          initEmptyValue = [];
        }
        this.filterData = {
          ...this.filterData,
          [item]: (!data[item] || data[item].length === 0) ? initEmptyValue : data[item]
        }
      } else {
        if(item === 'userDefinedAttrs') {
          // 设置自定义字段保存的值
          const userDefinedAttrs = data.userDefinedAttrs || {};
          Object.keys(userDefinedAttrs).forEach(jtem => {
            if (Array.isArray(userDefinedAttrs[jtem])) {
              let initEmptyValue = ['all'];
              // 如果是时间，则默认值保持为空数组
              if(jtem.toLowerCase().indexOf('time') !== -1) {
                initEmptyValue = [];
              }
              this.filterData.userDefinedAttrs[jtem] = (userDefinedAttrs[jtem] && userDefinedAttrs[jtem].length > 0) ? userDefinedAttrs[jtem] : initEmptyValue;
            } else {
              this.filterData.userDefinedAttrs[jtem] = userDefinedAttrs[jtem] || '';
            }
            if(!this.selectedCUSTOMFIELD.includes(jtem)) {this.selectedCUSTOMFIELD = [...this.selectedCUSTOMFIELD, jtem]}
          })
        } else {
          this.filterData[item] = data[item] || '';
        }
      }
    })
    this.setSelectedCUSTOMFIELD(this.selectedCUSTOMFIELD)
  },
  // 获取赛选的需求列表
  getRequiremenList(projectId) {
    return $http.get($http.api.task.requirement_list, { projectId })
  },
  // 获取需求列表
  async getRequireList() {
    let result = await this.getRequiremenList();
    if(result.status && result.status === 200) {
      this.requirementFilterList = result.data.map(item => {
        return {
          ...item,
          key: item.id,
          value: item.title
        }
      })
    }
  },
  // 获取过滤器列表
  async getFilterList() {
    let result = {};
    try {
      result = await $http.get($http.api.CustomFilter.custom_filter_list, {
        projectId: this.projectId,
        type: this.workItemType
      });
    } catch(_) {
      result.status = 0;
    }
    if(result.status === 200) {
      const list = [];
      list.push({
        label: '自定义过滤器',
        itemDetable: true,
        options: result.data.userFilterList.map(item => {
          return {
            ...item,
            key: item.id,
            value: item.filterName
          }
        })
      })
      list.push({
        label: '系统过滤器',
        itemDetable: false,
        options: result.data.systemFilterList.map(item => {
          return {
            ...item,
            key: item.id,
            value: item.filterName
          }
        })
      })
      this.customFilterList = list;
      // 清空过滤器中的名字
      if(this.filterTypeValue) {
        if(!list[0].options.find(item => item.key === this.filterTypeValue) && !list[1].options.find(item => item.key === this.filterTypeValue)) {
          this.filterTypeValue = '';
        }
      }
    }
  },
  // 获取字段可选择值列表列表 - 在 for 循环里面执行 async 的一个场景
  async getSelectOptionList(field) {
    // 如果不是 select 类型的，则跳过
    if(attrValueToInputTypeMap[field.attrValue] !== 'select') {return ;}
    // 如果是人员选择，则去拿人员选择数据
    if(field.attrValue === 'MEMBER_CHOICE') {
      this.getAssignUsersList(field);
      return ;
    }
    let result = {};
    try {
      result = await $http.get($http.api.CustomField.custom_field_choices, {
        projectId: this.projectId,
        workItemType: this.workItemType,
        attrName: field.attrName
      });
    } catch(_) {
      result.status = 0;
    }
    if(result.status === 200) {
      const list = result.data.map(item => {
        return {
          ...item,
          key: item.choice,
          value: item.value
        }
      });
      field.fieldEditProps.selectValue = list;
    }
    return true;
  },
  // 获取人员列表
  async getAssignUsersList(field) {
    // 减少发起的请求，增加效率
    if(field.fieldEditProps.selectValue.length > 0) {return ;}
    const result = await $http.post($http.api.bug_info.assignUsersList, {
      projectId: this.projectId,
      query: ''
    });
    if (result.status && result.status === 200) {
      const list = result.data.map(item => {
        return {
          ...item,
          key: item.userId,
          value: item.userName  + "(" + item.userId + ")"
        }
      })
      field.fieldEditProps.selectValue = list;
    }
  },
  // 选择过滤器 -> 需要展开当前过滤器，并且更新当前条件
  async customFilterChoose(value) {
    this.getLoading = true;
    let result = {};
    try {
      result = await $http.get($http.api.CustomFilter.custom_filter_detail, {
        projectId: this.projectId,
        type: this.workItemType,
        id: value
      });
    } catch(_) {
      result.status = 0;
    }
    this.getLoading = false;
    this.filterTypeValue = value;
    if (result.status && result.status === 200) {
      let obj = {
        userDefinedAttrs: {}
      }
      if(typeof result.data.systemFieldFilter === 'object') {
        obj = {
          ...result.data.systemFieldFilter,
          ...obj
        }
      }
      try {
        obj.userDefinedAttrs = JSON.parse(result.data.userFieldFilter);
      } catch (_) {}
      this.updateFilterData(obj);
      this.isFilterOpen = true;
    }
  },
  // 是否展开过滤器
  filterStatusChange() {
    // this.filterTypeValue = ''; // 清空过滤器选择值，当手动点击展开时，保证过滤器
    this.isFilterOpen = !this.isFilterOpen;
    if(this.isFilterOpen) {
      this.$emit('filterOpenChange')
    }
  },
  // 设置当前选中的自定义过滤条件
  setSelectedCUSTOMFIELD(value) {
    this.selectedCUSTOMFIELD = value;
    let values = [];
    // 先清除未选中的自定义过滤字段 custom
    // Object.keys(this.filterData.userDefinedAttrs).forEach(item => {
    //   if (!value.includes(item)) {
    //     this.$delete(this.filterData.userDefinedAttrs, item)
    //   }
    // })
    // 增加过滤字段
    this.customFieldList.forEach(item => {
      const key = item.key;
      const isChoice = ['MEMBER_CHOICE', 'SINGLE_CHOICE', 'MULTI_CHOICE'].includes(item.attrValue);
      const isDate = ['LITE_DATE_ATTR', 'LITE_DATE_RANGE_ATTR'].includes(item.attrValue);
      if(value.includes(key)) {
        values.push(item);
        // 如果已经设置了 custom，则忽略
        if (this.filterData.userDefinedAttrs[key]) { return true; }
        // 如果没有设置，则增加 custom
        this.$set(this.filterData.userDefinedAttrs, key, isChoice ? ['all'] : (isDate ? [] : ''));
      }
    })
    this.selectedCUSTOMFIELDVALUES = [...values];
  },
  // 控制全选 select ，同时支持固定字段与自定义字段
  handleSelectChange(value, key, isCustom) {
    let filterData = isCustom ? this.filterData.userDefinedAttrs : this.filterData
    // 如果最后一个选中了全部
    if (value[value.length - 1] === 'all') {
      filterData[key] = ['all']
    }
    // 如果不是最后一个选中了全部
    if (filterData[key].includes('all') && filterData[key].length > 1) {
      filterData[key] = filterData[key].filter(item => item !== 'all')
    }
  },
  // 删除过滤器
  async filterDeleteClick(info, e) {
    const confirmResult = await this.confirmBeforeOperate(`是否删除过滤器"${info.value}"?`);
    if(!confirmResult) { return false; }
    let result = {};
    this.getLoading = true;
    try {
      const urlObj = {...$http.api.CustomFilter.custom_filter_delete};
      urlObj.url += "?id=" + info.key;
      result = await $http.post(urlObj, {
        projectId: this.projectId,
        type: this.workItemType
      });
    } catch(_) {
      result.status = 0;
    }
    this.getLoading = false;
    if(result.status === 200) {
      this.getFilterList();
      this.$message({
        type: 'success',
        message: result.msg || '删除过滤器成功'
      })
    } else {
      this.$message({
        type: 'error',
        message: result.msg || '删除过滤器失败'
      })
    }
  },
  // 保存过滤器
  filterSaveClick() {
    if(this.filterTypeValue) {
      let selectedFilter;
      Object.values(this.customFilterList).forEach(item => {
        const reuslt = item.options.find(jtem => jtem.key === this.filterTypeValue);
        reuslt && (selectedFilter = reuslt);
      })
      this.filterSaveDialog.name = (selectedFilter&&selectedFilter.value) || '';
    }
    this.filterSaveDialog.status = true;
  },
  // 校验过滤器提交信息
  async beforePostFilterCustomInfo() {
    if(this.filterSaveDialog.name.length < 1) {
      this.$message({
        type: 'warning',
        message: '过滤器名称不能为空'
      })
      return ;
    }
    let isEmpty = true;
    Object.keys(this.filterData).forEach(item => {
      if (Array.isArray(this.filterData[item])) {
        if(this.filterData[item].length > 0 && !this.filterData[item].includes('all')) {
          isEmpty = false;
        }
      } else {
        if(item === 'userDefinedAttrs') {
          const userDefinedAttrs = this.filterData.userDefinedAttrs;
          Object.keys(userDefinedAttrs).forEach(jtem => {
            if (Array.isArray(userDefinedAttrs[jtem])) {
              if(userDefinedAttrs[jtem].length > 0 && !userDefinedAttrs[jtem].includes('all')) {
                isEmpty = false;
              }
            } else if(userDefinedAttrs[jtem] && userDefinedAttrs[jtem].length > 0) {
              isEmpty = false;
            }
          })
        } else if(this.filterData[item].length > 0) {
          isEmpty = false;
        }
      }
    })
    if(isEmpty) {
      const confirmResult = await this.confirmBeforeOperate(`您正在保存一个空的过滤器，要获得更准确的结果，请创建一个特定的查询`);
      if(!confirmResult) { return false; }
    }
    return true;
  },
  // 复制 this.filterData 对象，去掉 all
  copyFilterDataRemoveAll() {
    const obj = {
      userDefinedAttrs: {}
    };
    Object.keys(this.filterData).forEach(item => {
      if (Array.isArray(this.filterData[item])) {
        obj[item] = this.filterData[item].includes('all') ? [] : this.filterData[item];
      } else {
        if(item === 'userDefinedAttrs') {
          const userDefinedAttrs = this.filterData.userDefinedAttrs;
          Object.keys(userDefinedAttrs).forEach(jtem => {
            if (Array.isArray(userDefinedAttrs[jtem])) {
              obj.userDefinedAttrs[jtem] = userDefinedAttrs[jtem].includes('all') ? [] : userDefinedAttrs[jtem];
            } else {
              obj.userDefinedAttrs[jtem] = userDefinedAttrs[jtem];
            }
          })
        } else {
          obj[item] = this.filterData[item];
        }
      }
    })
    return obj;
  },
  // 构建格式 - 提交过滤器
  generatePostFilterCustomInfoObj() {
    const obj = this.copyFilterDataRemoveAll();
    const systemFieldFilter = {}
    Object.keys(obj).forEach(item => {
      if (item !== 'userDefinedAttrs') {
        systemFieldFilter[item] = obj[item]
      }
    })
    return {
      systemFieldFilter,
      userFieldFilter: JSON.stringify(obj.userDefinedAttrs)
    };
  },
  // 提交过滤器信息
  async postFilterCustomInfo( replaceSave = false) {
    const confirmResult = await this.beforePostFilterCustomInfo();
    if(!confirmResult) { return false; }
    const obj = this.generatePostFilterCustomInfoObj();
    let result = {};
    this.saveLoading = true;
    try {
      result = await $http.post($http.api.CustomFilter.custom_filter_save, {
        projectId: this.projectId,
        type: this.workItemType,
        filterName: this.filterSaveDialog.name,
        replaceSave: typeof replaceSave === 'boolean' ? replaceSave : false,
        systemFieldFilter: obj.systemFieldFilter,
        userFieldFilter: obj.userFieldFilter
      });
    } catch(_) {
      result.status = 0;
    }
    this.saveLoading = false;
    if(result.status === 200) {
      this.handleClose();
      this.getFilterList();
      this.$message({
        type: 'success',
        message: result.msg || '新建过滤器成功'
      })
    } else if(result.status === 620) {
      // 和系统内置名称重复了
      this.$message({
        type: 'error',
        message: result.msg || '不允许和系统过滤器"${this.filterSaveDialog.name}"重名'
      })
    } else if(result.status === 621) {
      // 和已有的自定义过滤器名称重复了
      const confirmResult = await this.confirmBeforeOperate(`已有过滤器"${this.filterSaveDialog.name}"，是否覆盖它`);
      if(!confirmResult) { return false; }
      this.postFilterCustomInfo(true)
    }
  },
  // 取消保存
  handleClose() {
    this.filterSaveDialog = {
      status: false,
      name: ''
    }
  }
}

export default {
  props,
  data,
  computed,
  watch,
  methods
}