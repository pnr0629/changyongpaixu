<template>
  <div class="control">
    <el-tooltip class="item" effect="dark" content="计算公式：已完成任务工时/任务总工时" placement="bottom">
      <i class="el-icon-info"></i>
    </el-tooltip>进度：
    <span class="progress-list">
      <el-progress :text-inside="true" :stroke-width="18" :percentage="sprintInfo.process"></el-progress>
    </span>
    <span class="ml30">周期：{{sprintInfo.startTime}} ~ {{sprintInfo.endTime}}</span>
    <span class="ml30">需求({{sprintInfo.completeRequires}}/{{sprintInfo.totalRequires}})</span>
    <span class="ml30">任务({{sprintInfo.completeTasks}}/{{sprintInfo.totalTasks}})</span>
    <span class="ml30">缺陷({{sprintInfo.closedDefect}}/{{sprintInfo.totalDefect}})</span>
    <span class="ml30">任务工时({{sprintInfo.completeTaskHours}}/{{sprintInfo.totalTaskHours}})</span>
    <div class="progress-time">
      <div>
        <div class="header">
          <span class="progress-title">当前阶段</span>
          <span style="color:#a09e9e;"
            v-show="authFunction('FUNC_COOP_SPRINT_STAGE_CURRENT_UPDATE', 3, data.projectId)">(点选时间节点修改迭代阶段时间)</span>
          <div class="template-select">
            <field-edit v-bind="FieldEditProps" :onChange="changeTemplate" class="template-select-input"></field-edit>
            <span class="template-select-title">当前使用模板:</span>
          </div>
          <span class="progress-btn cursor-pointer fr" @click="custormBtn">
            迭代模板设置&nbsp;<i class="el-icon-setting"></i>
          </span>
        </div>
        <div class="progress-dute" v-loading="loading"
          element-loading-text="updating..."
          element-loading-spinner="el-icon-loading"
          element-loading-background="rgba(255,255,255, 0.5)">
          <div class="progress-item" :class="{'progress-item-current': item.isCurrentStage || item.isCurrentStageActual}" v-for="(item,i) in progressVO" :key="i">
            <div class="progress-item-header">
              <div>计划日期</div>
              <div>实际日期</div>
            </div>
            <div class="progress-item-line progress-item-line-1"
              :class="{'progress-line-green':item.isPlanFinished,
                'progress-line-yellow':item.isCurrentStage,
                'progress-line-grey':!item.isPlanFinished&&!item.isCurrentStage?true:false }"></div>
            <div class="progress-item-line progress-item-line-2"
              :class="{'progress-line-green':item.isActualFinished,
                'progress-line-yellow':item.isCurrentStageActual,
                'progress-line-grey':!item.isActualFinished&&!item.isCurrentStageActual?true:false }"></div>
            <div class="progress-item-content">
              <div class="progress-item-content-tag-box">
                <el-tooltip placement="top">
                  <div slot="content">
                    <div>
                      <div style="font-size:14px;margin:0 10px;">{{item.stageInfo.name}}</div>
                      <div class="progress-tooltip-mr" style="margin:10px; ">
                        <span>计划开始时间：{{item.stageInfo.startTimePlan||'--'}}</span>&nbsp;
                        <span>实际开始时间：{{item.stageInfo.startTimeActual||'--'}}</span>
                      </div>
                    </div>
                  </div>
                  <div class="ui-tag ui-tag-grey progress-item-content-tag">{{item.stageInfo.name}}</div>
                </el-tooltip>
              </div>
              <div class="progress-item-content-plan" :class="{'progress-date-yellow':item.isCurrentStage,
                'progress-date-grey':!item.isPlanFinished&&!item.isCurrentStage?true:false }">
                <global-input v-if="hasAuth" :initValue="item.stageInfo.startTimePlan || ''" inputType="time" projectText="sprintTime"
                  :onChange="value => updateDate(value, item, 'startTimePlan')" :daisableTime="daisableTime">
                  <span class="cursor-pointer" slot>{{item.stageInfo.startTimePlan || EMPTYDATE}}</span>
                </global-input>
                <span v-else>{{item.stageInfo.startTimePlan || EMPTYDATE}}</span>
              </div>
              <div class="progress-item-content-real" :class="{'progress-date-yellow':item.isCurrentStageActual,
                'progress-date-grey':!item.isActualFinished&&!item.isCurrentStageActual?true:false }">
                <global-input v-if="hasAuth" :initValue="item.stageInfo.startTimeActual || ''" inputType="time" projectText="sprintTime"
                  :onChange="value => updateDate(value, item, 'startTimeActual')" :daisableTime="daisableTime">
                  <span slot>{{item.stageInfo.startTimeActual || EMPTYDATE}}</span>
                </global-input>
                <span v-else>{{item.stageInfo.startTimeActual || EMPTYDATE}}</span>
              </div>
              <div class="progress-item-content-delay" :class="{'progress-item-content-before': item.isCompletedBefore}" v-show="item.line3">{{item.line3}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 修改日期 date modified -->
    <!-- <date-modified :dateshow="dateshow" @func="getMsgFormSon"></date-modified>
    <progress-dialog :progressTab="progressTab" @func="getMsgFormSon"></progress-dialog> -->
  </div>
</template>
<script>
/**
 * @title 迭代详情
 * @desc
 * @author heyunjiang
 * @date
 */
import DateModified from "./SprintInfoDateModified";
import ProgressDialog from "./SprintInfoProgressdialog";
import CustormChar from '../chart/CustormChar';
import GlobalInput from '../../tool/FieldEdit/GlobalInput.vue'
import FieldEdit from '../../tool/FieldEdit'
export default {
  name: "SprintInfo",
  components: { 
    DateModified, 
    ProgressDialog,
    GlobalInput,
    FieldEdit
  },
  mixins: [],
  props: {
    sprintInfo: {
      type: Object,
      required: true,
      desc: "迭代详情展示"
    },
    projectId: {
      type: [Number, String],
      required: false
    }
  },
  data() {
    return {
      dateshow: false,//展示修改日期弹窗
      progress: [],//迭代阶段进度信息列表
      progressTab: {},
      loading: false,
      daisableTime:1,//标记迭代时间1:为已锁定和已归档
      progressList:null,//临时存迭代日期
      data: {
        projectId: this.getUrlParams().projectId,
        sprintId: this.getUrlParams().sprintId
      },
      EMPTYDATE: '未设置',
      FieldEditProps: {
        fieldType: 'select',
        initValue: '',
        selectValue: []
      }
    };
  },
  computed: {
    hasAuth() {
      return this.authFunction('FUNC_COOP_SPRINT_STAGE_TIME_UPDATE', 3, this.data.projectId)
    },
    // 迭代阶段 - VO，实现了绿线、灰线判断逻辑
    progressVO() {
      const planIndex = this.progress.findIndex(item => item.isCurrentStage);
      const actualIndex = this.progress.findIndex(item => item.isCurrentStageActual);
      if(this.progressList){
        return this.progressList
      }else{
        return this.progress.map((item, index) => {
          const planTime = new Date(item.stageInfo.startTimePlan);
          const actualTime = new Date(item.stageInfo.startTimeActual);
          return {
            ...item,
            isPlanFinished: (planIndex > -1) && (index < planIndex),
            isActualFinished: (actualIndex > -1) && (index < actualIndex),
            isCompletedBefore: actualTime < planTime
          }
        })
      }
     
    }
  },
  watch: {
    dateshow() {
      this.initProgressData(this.data);
    },
    sprintInfo() {
      this.getTemList();
      this.initProgressData(this.data);
      if(this.sprintInfo.isLocked == 1||this.sprintInfo.status == 2){
        this.daisableTime = 1
      }else{
        this.daisableTime = null
      }
    }
  },
  created() { },
  mounted() {
    let obj = {
      projectId: this.getUrlParams().projectId,
      sprintId: this.getUrlParams().sprintId
    }
    this.initProgressData(this.data);
    this.getTemList();
  },
  methods: {
    // 更新日期 - 点击日期项、更新日期 - add by heyunjiang
    async updateDate(value, info, key) {
      if(!key || !info.stageInfo) {return ;}
      let obj = {};
      obj = {
        sprintId: this.getUrlParams().sprintId,
        projectId: this.projectId || this.getUrlParams().projectId,
        stageTimeList: [{
          ...info.stageInfo,
          [key]: value
        }]
      };
      this.loading = true;
      let res = {};
      try {
        res = await $http.post($http.api.sprint.current_stage_update, obj);
        
      } finally {
        this.loading = false;
        const text = value == null ? '删除' : '修改';
        if (res.status === 200) {
          this.$message({ message: res.msg || `${text}成功`, type: "success" });
          this.$emit('dateUpdate');
          this.initProgressData(this.data);
          this.progressList = null
        } else {
          this.daisableTime = 1
          this.$message({ message: res.msg || `${text}失败`, type: 'error' });  
          this.progressList = JSON.parse(JSON.stringify(this.progressVO))      
        }
        
      }
    },
    dateModifiedBtn() {
      this.dateshow = true;
    },
    custormBtn() {
      this.goToPage(this, "personalManagementList", {
        projectId: this.getUrlParams().projectId,
        sprintId: this.getUrlParams().sprintId,
        key: "sprint"
      });
    },
    //进度阶段tab可编辑
    progressTagBtn(item) {
      if (!this.authFunction('FUNC_COOP_SPRINT_STAGE_CURRENT_UPDATE', 3, this.data.projectId)) {
        return;
      }
      this.progressTab = {
        show: true,
        data: item,
        list: this.progress
      }
    },
    getMsgFormSon(data) {
      this.dateshow = false;
      this.progressTab = {
        ...this.progressTab,
        show: false
      }
      if (!data) {
        this.initProgressData(this.data)
      }
    },
    //获取阶段进度初始数据
    initProgressData(obj) {
      $http.get($http.api.sprint.schedule_info_list, obj).then(res => {
        if (res.status == 200) {
          let show = true;
          this.progress = res.data.map(item => {
            // 只要有一个实际日期为空，后面的都为空
            if(item.stageInfo&&!item.stageInfo.startTimeActual) {show = false}
            return {
              ...item,
              show
            }
          });
        } else {
          // this.$message({ message: '搜索需求/任务失败', type: 'error' });
        }
      })
    },
    // 获取模板列表
    async getTemList() {
      let result = {}
      try {
        // this.loading = true;
        result = await $http.get($http.api.sprint.template_list, {
          projectId: this.projectId || this.getUrlParams().projectId
        });
      } catch(_) {} finally {
        // this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取迭代阶段模板列表数据失败',
          type: 'error'
        })
        return;
      }
      const list = result.data.map(item => {
        return {
          ...item,
          key: item.id,
          value: item.name
        }
      });
      const initvalue = list.find(item => +item.key === +this.sprintInfo.templateId);
      this.FieldEditProps.initValue = (initvalue&&initvalue.key) || '';
      this.FieldEditProps.selectValue = list;
      this.$forceUpdate();
    },
    // 更改当前迭代使用的模板
    async changeTemplate(value) {
      this.loading = true;
      let res = {};
      try {
        res = await $http.post($http.api.sprint.template_use, {
          projectId: this.projectId,
          sprintId: this.sprintInfo.id,
          templateId: value
        });
      } finally {
        this.loading = false;
        if (res.status === 200) {
          this.$message({ message: res.msg || "应用成功", type: "success" });
          this.FieldEditProps.initValue = value;
          this.$emit('templateUpdate');
        } else {
          this.$message({ message: res.msg || '应用失败', type: 'error' });
        }
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.control {
  margin-top: 20px;
}
.header {
  height: 34px;
  box-sizing: border-box;
  padding-top: 6px;
  .template-select {
    position: absolute;
    top: 0;
    right: 130px;
    height: 28px;
    line-height: 28px;
    width: 300px;
    padding: 6px 10px 0 0;
    color: #40aaff;
    .template-select-title {
      font-size: 14px;
      float: right;
      color: #606266;
      margin-right: 5px;
    }
    .template-select-input {
      float: right;
    }
  }
}


.progress-list {
  width: 150px;
  height: 18px;
  display: inline-block;
  border-radius: 0% !important;
  position: relative;
  top: -2px;
}
.progress-time {
  position: relative;
  height: 199px;
  border: 1px solid #ebeef5;
  width: 90%;
  margin-top: 20px;
  padding: 5px 13px;
  .progress-title {
    font-size: 14px;
    font-weight: bold;
  }
  .progress-btn {
    display: inline-block;
    margin: 0 15px;
    &:hover {
      color: #409eff;
    }
  }
  .ui-tag {
    font-size: 12px;
    height: 20px;
    line-height: 20px;
    border-radius: 20px;
    padding: 0px 8px;
    max-width: 165px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .ui-tag-grey {
    color: #909090;
    border: 1px solid #303030;
  }
  .ui-tag-red {
    color: #ea0d0d !important;
    border: 1px solid #ea0d0d !important;
    background: rgba(234, 13, 13, 0.05) !important;
    border-color: rgba(234, 13, 13, 0.05) !important;
    border-radius: 6px;
    padding: 1px 2px;
  }
  .ui-tag-green_1 {
    color: #24b47e;
    border: 1px solid #24b47e;
    background: rgba(194, 239, 222, 0.38);
    border-color: rgba(194, 239, 222, 0.38);
    border-radius: 6px;
    padding: 1px 2px;
  }
  .ui-tag-green {
    color: #24b47e;
    border: 1px solid #24b47e;
  }
  .ui-tag-yellow {
    color: #f0a100;
    border: 1px solid #f0a100;
  }
  // 新版迭代里程碑样式 - 两条线 add by heyunjiang
  .progress-dute {
    display: flex;
    flex-flow: row nowrap;
    justify-content: space-around;
    padding: 30px;
    background-color: #f9f9f9;
    .progress-item {
      flex: 1 1 auto; // 可以充满整个 Item
      font-size: 0;
      position: relative;
      // 当前阶段需要加大面积
      &.progress-item-current {
        .progress-item-content {
          width: 100px;
        }
        .progress-item-line {
          width: calc(100% - 100px);
        }
      }
      .progress-item-line-common {
        height: 28px;
        line-height: 28px;
        color: #909090;
      }
      // 头部：计划日期、实际日期
      .progress-item-header {
        display: none;
        width: 60px;
        font-size: 12px;
        vertical-align: top;
        position: relative;
        top: 22px;
        div {
          @extend .progress-item-line-common;
        }
      }
      .progress-item-content,
      .progress-item-line {
        display: inline-block;
      }
      .progress-item-content-tag,
      .progress-item-content-plan,
      .progress-item-content-real,
      .progress-item-content-delay {
        text-align: center;
        font-size: 12px;
      }
      .progress-item-content-plan,
      .progress-item-content-real {
        @extend .progress-item-line-common;
      }
      .progress-item-content {
        width: 90px;
        float: right;
      }
      // 内容超期
      .progress-item-content-delay {
        color: #ea0d0d;
        border: 1px solid rgba(234,13,13,.05);
        border-radius: 6px;
        background-color: rgba(234,13,13,.05);
        padding: 1px 2px;
        margin-top: 5px;
      }
      // 内容提前
      .progress-item-content-before {
        color: #24b47e;
        background-color: rgba(218,241,232,0.5);
      }
      // 连接线
      .progress-item-line {
        width: calc(100% - 90px);
        height: 1px;
        box-sizing: border-box;
        border-top: 1px solid red;
        position: absolute;
        left: 0;
        &.progress-item-line-1 {
          top: 36px;
        }
        &.progress-item-line-2 {
          top: 64px;
        }
      }
      // 设置第一个盒子展示数据
      &:first-of-type {
        flex: none;
        .progress-item-line {
          width: 0;
        }
        .progress-item-header {
          display: inline-block;
        }
      }
      .progress-line-dash {
        border-top-style: dashed;
      }
      .progress-line-yellow {
        border-top-color: #f0a100;
      }
      .progress-line-blue {
        border-top-color: #338fe5;
      }
      .progress-line-green {
        border-top-color: #24b47e;
      }
      .progress-line-grey {
        border-top-color: #909090;
      }
      .progress-date-yellow {
        color: #f0a100;
        font-size: 14px;
        font-weight: 700;
      }
      .progress-date-blue {
        color: #338fe5;
      }
      .progress-date-green {
        color: #24b47e;
      }
      .progress-date-grey {
        color: #909090;
      }
    }
  }
  // 已废弃
  .progress-img {
    // display: inline-flex;
    display: none;
    padding: 30px 8%;
    min-width: 100%;
    // .progress:first-child {
    //   margin-left: auto;
    // }
    // .progress:last-child {
    //   margin-right: auto;
    // }
    .progress {
      flex: 1 1 auto;
      display: flex;
      position: relative;
      max-width: 317px;
      min-width: 114px;
      .progress-common {
        flex: 0 0 auto;
        display: flex;
        justify-content: center;
        white-space: nowrap;
      }
      &:last-child {
        max-width: 6px;
        min-width: 6px;
      }
      .progress-point-container {
        width: 12px;
        display: flex;
        flex-direction: column;
        align-items: center;
      }
      .progress-show-date-label {
        flex: 0 0 auto;
      }
      .progress-show-date {
        margin-top: 10px;
        font-size: 12px;
        text-align: center;
        flex-wrap: wrap;
        @extend .progress-common;
      }
      .ProgressTag {
        flex: 0 0 auto;
      }
      .ProgressTag-container {
        margin-top: 5px;
        @extend .progress-common;
        cursor: pointer;
        .progress-tooltip-mr {
          margin: 10px;
          color: blue;
        }
      }
      .progress-point {
        flex: 0 0 auto;
        width: 6px;
        height: 6px;
        border-radius: 6px;
        border-width: 1px;
        border-style: solid;
        margin-top: 10px;
      }
      .progress-line {
        flex: 1 1 auto;
        margin-top: 33px;
        border-top: 1px solid transparent;
        .progress-line-dash {
          border-top-style: dashed;
        }
      }
      .progress-point-yellow {
        background: #f0a100;
        border-color: #fff;
      }
      .progress-point-yellow-notFill {
        border-color: #f0a100;
        background: #fff;
      }
      .progress-show-date-yellow {
        color: #f0a100;
      }
      .progress-show-date-blue {
        color: #338fe5;
      }
      .progress-line-yellow {
        border-top-color: #f0a100;
      }
      .progress-point-blue {
        background: #338fe5;
        border-color: #fff;
      }
      .progress-point-blue-notFill {
        border-color: #338fe5;
        background: #fff;
      }
      .progress-line-blue {
        border-top-color: #338fe5;
      }
      .progress-point-green {
        background: #24b47e;
        border-color: #fff;
      }
      .progress-point-green-notFill {
        border-color: #24b47e;
        background: #fff;
      }
      .progress-show-date-green {
        color: #24b47e;
      }
      .progress-line-green {
        border-top-color: #24b47e;
      }
      .progress-point-grey {
        background: #909090;
        border-color: #fff;
      }
      .progress-point-grey-notFill {
        border-color: #909090;
        background: #fff;
      }
      .progress-show-date-grey {
        color: #909090;
      }
      .progress-line-grey {
        border-top-color: #909090;
      }
    }
  }
}
.ml30 {
  margin-left: 30px;
}
</style>
