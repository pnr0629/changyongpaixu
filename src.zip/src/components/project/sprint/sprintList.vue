<template>
  <div id="sprintList" class="content-outer-box">
    <div class="x-arD content-box review-center">
      <div class="title" style="overflow:hidden;">
        <el-form :inline="true" style="margin-bottom:-20px;">
          <el-form-item label="迭代状态">
            <el-select placeholder="未结束的" style="width:200px;" v-model="sprintStatus"
              @change="getSprintList(sprintStatus)">
              <el-option label="全部" value="0"></el-option>
              <el-option label="未开始的" value="4"></el-option>
              <el-option label="已开始的" value="5"></el-option>
              <el-option label="已结束的" value="2"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="createSprint()" class="ml ml40"
              v-show="authFunction('PROJ_SPRINT_ADD', 3, projectId)">创建迭代
            </el-button>
          </el-form-item>
        </el-form>
      </div>
      <div class="content" v-for="(row,index) in sprintPageData" :key="index">
        <div class="mt10">
          <span class="font-desgin sprint-name c-blue cp" @click="toSprintDetail(row.id)">{{row.name}}
            <el-tooltip v-if="row.isLocked == 1" class="item" effect="dark" content="迭代已锁定" placement="bottom">
              <i class="iconfont icon-lock"></i>
            </el-tooltip>
          </span>
          <span class="fr mr10">
            <span class="font-desgin c-blue cp ml20" v-if="row.status != 2" @click="planSprint(row)"
              v-show="authFunction('PROJ_SPRINT_ADD_TASK', 3, projectId)">规划</span>
            <span class="font-desgin c-blue cp ml10" v-if="row.status != 2" @click="editSprint(row.id)"
              v-show="authFunction('PROJ_SPRINT_UPDATE', 3, projectId)">编辑</span>
            <span class="font-desgin c-blue cp ml10" v-if="row.status != 2" @click="deleteSprint(row)"
              v-show="authFunction('FUNC_COOP_PROJECT_SPRINT_DELETE', 3, projectId)">删除</span>
            <span class="font-desgin c-blue cp ml10" v-if="row.status != 2" @click="isLockSprint(row)"
              v-show="authFunction('FUNC_COOP_SPRINT_LOCK', 3, projectId)">{{row.isLocked ? '解锁':'锁定'}}</span>
            <span class="font-desgin c-blue cp ml10" v-if="row.status != 2" @click="stopSprint(row)"
              v-show="authFunction('PROJ_SPRINT_STOP', 3, projectId)">归档</span>
          </span>
        </div>
        <p class="content-item-p ml20 mt5" style="width:400px;">
          <span class>需求({{row.completeRequires}}/{{row.totalRequires}})</span>
          <span class="ml20">任务({{row.completeTasks}}/{{row.totalTasks}})</span>
          <span class="ml20">缺陷({{row.closedDefect}}/{{row.totalDefect}})</span>
          <span class="ml20">任务工时({{row.completeTaskHours}}/{{row.totalTaskHours}})</span>
          <br>
          <span>需求延期完成数：{{row.completeDelayRequires}}</span>&nbsp;
          <span class="ml20">任务延期完成数：{{row.completeDelayTasks}}</span>
        </p>
        <div style="width:180px;display: inline-block;">
          <div class="content-item-middle">
            <el-tooltip class="item" effect="dark" content="计算公式：已完成任务工时/任务总工时" placement="bottom">
              <i class="el-icon-info"></i>
            </el-tooltip>
            <span>进度</span>
            <div class="progress">
              <el-progress :text-inside="true" :stroke-width="18" :percentage="row.process"></el-progress>
            </div>
          </div>
          <div class="content-item-middle">
            <span>当前计划阶段：</span>
            <span class="ui-tag-yellow" :title="row.currentStage">{{row.currentStage ||'--'}}</span>
          </div>
        </div>
        <div style="width:270px;display: inline-block;">
          <span class="content-item-p">
            周期：{{row.startTime}}~{{row.endTime}}
            <span class>
              <span v-if="row.isDeadlineClose" class="dateTips">{{row.deadlineCloseDisplay}}</span>
              <span v-if="row.isOutOfDate" class="dateTipsred">{{row.outOfDateDisplay}}</span>
            </span>
          </span>
          <div class="content-item-middle">
            <span>当前实际阶段：</span>
            <span class="ui-tag-yellow" :title="row.currentStageActual">{{row.currentStageActual ||'--'}}</span>
          </div>
        </div>

        <div class="progress-user" style="width:150px;">
          <span class="content-item-p">
            <span>负责人：</span>
            <span>{{row.chargeUser}}</span>
          </span>
          <span class="content-item-p" style="visibility: hidden;">
            <span>负责人：</span>
            <span>{{row.chargeUser}}</span>
          </span>
        </div>
        <p class="sprint-desc ellipsis">描述：{{row.sprintDesc}}</p>
        <!-- <p class="content-item-p ml20">
          <span>任务按时完成数：{{row.completeInTimeTasks}}</span>
          <span>需求按时完成数：{{row.completeInTimeRequires}}</span>
        </p>-->
        <!-- <p class="content-item-p ml20">
          <span style="margin-left:26px;">按时完成数：{{row.completeInTimeRequires+row.completeInTimeTasks}}</span>
          <span style="margin-left:99px;">延期完成数：{{row.completeDelayRequires+row.completeDelayTasks}}</span>
        </p>-->
      </div>
    </div>
    <el-pagination @current-change="handleCurrentChange" :page-size="10" layout="total, prev, pager, next"
      :total="totalPage"></el-pagination>

    <el-dialog v-bind:title="dialogFormTitle" :visible.sync="dialogFormVisible" class="el-dialog-580w">
      <div class="form-iterm-box">
        <el-form :model="sprintForm" ref="sprintForm">
          <el-form-item label="迭代名称" label-width="80px" prop="name" :rules="[{ required: true, message: '迭代名称不能为空' }]">
            <el-input v-model="sprintForm.name" autocomplete="off" placeholder="选输入迭代名称"></el-input>
          </el-form-item>
          <el-form-item label="开始时间" label-width="80px" prop="startTime"  v-if="dialogFormVisible"
            :rules="[{ required: true, message: '开始时间不能为空' }]" class="date_start">
            <custom-date v-model="sprintForm.startTime"   style="width:100%;" >
            </custom-date>
          </el-form-item>
          <el-form-item label="结束时间" label-width="80px" prop="endTime" v-if="dialogFormVisible" :rules="[{ required: true, message: '结束时间不能为空'}]"
            class="date_start">
            <custom-date v-model="sprintForm.endTime"   style="width:100%;" >
            </custom-date>
          </el-form-item>
          <el-form-item label="负责人" label-width="80px" prop="endTime" :rules="[{ required: true, message: '负责人不能为空'}]">
            <el-select style="width:166px;" value-key="key" v-model="sprintForm.chargeUser">
              <el-option v-for="jtem in assignUserData" :label="jtem.value" :key="jtem.key" :value="jtem.key">
              </el-option>
            </el-select>
            <!-- <field-edit :initName="assignUser" :initValue="assignUser"
            :selectValue="assignUserData" :onChange="handleAssignerChange" localSearch></field-edit>-->
          </el-form-item>
          <el-form-item label="迭代描述" label-width="80px" prop="sprintDesc">
            <el-input type="textarea" v-model="sprintForm.sprintDesc" autocomplete="off" :rows="3" :max="200"
              placeholder="选输入迭代描述"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer" v-if="sprintForm.id > 0">
        <el-button type="primary" @click="sureUpdateSprint()" class="fr">确 定</el-button>
        <el-button @click="dialogFormVisible = false" class="fr mr10">取 消</el-button>
      </div>
      <div slot="footer" class="dialog-footer" v-else>
        <el-button type="primary" @click="sureAddSprint()" class="fr">确 定</el-button>
        <el-button @click="dialogFormVisible = false" class="fr mr10">取 消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  /**
     Auth: Lei.j1ang
     Created: 2018/1/19-14:54
     */
  import FieldEdit from "@/components/tool/FieldEdit";
  export default {
    name: "sprintList",
    components: { FieldEdit },
    data() {
      return {
        sprintStatus: "0",
        projectId: 0,
        totalPage: 0,
        currenPage: 1,
        userData: {},
        assignUserData: [],
        assignUser: 0,
        dialogFormVisible: false,
        dialogFormTitle: "创建迭代",
        sprintForm: {
          id: 0,
          projectId: "",
          name: "",
          startTime: "",
          endTime: "",
          chargeUser: "",
          sprintDesc: ""
        },
        params: {
          status: "",
          projectId: "",
          page: 1
        },
        sprintPageData: []
      };
    },
    mounted() {
      this.projectId = this.getUrlParams().projectId;
      // this.getSprintList();
      this.params.projectId = this.projectId;
      this.params.status = this.sprintStatus;
      this.getPageList(this.params);
      this.getAssignUser();
    },
    methods: {
      //锁定迭代和解绑迭代的方法
      isLockSprint(row) {
        let id = row.id;
        let name = row.name;
        let val = row.isLocked;
        if (val) {
          this.unLockSprint(id, name)
        } else {
          this.lockSprint(id, name)
        }
      },
      //锁定迭代
      // lockSprint(id) {
      //   console.log(id)
      //   $http.post($http.api.sprint.sprint_lock, {sprintId: id }, {type: 'form' }).then(res => {
      //     console.log(res.msg)
      //     if (res.msg == '需要执行强制锁定') {
      //       this.$confirm("是否强制锁定迭代?", "提示", {
      //         confirmButtonText: "确定",
      //         cancelButtonText: "取消",
      //         type: "warning"
      //       }).then(() => {
      //         this.forceLockSpring(id)
      //       })
      //     } else {
      //       this.getPageList(this.params)
      //     }
      //   }).catch(e => {
      //     console.log(e)
      //   })
      // },
      //解锁迭代
      // unLockSprint(id) {
      //   $http.post($http.api.sprint.sprint_unlock, { sprintId: id }, { type: 'form' }).then(res => {
      //     if (res.status === 200) {
      //       this.getSprintInfo()
      //       this.$message({
      //         message: '解锁迭代成功',
      //         type: 'success'
      //       });
      //     }
      //   });
      // },
      //强制锁定
      // forceLockSpring(id) {
      //   $http.post($http.api.sprint.sprint_force_lock, { sprintId: id }, { type: 'form' }).then(res => {
      //     if (res.status === 200) {
      //       this.getPageList(this.params)
      //     }
      //   });
      // },
      handleCurrentChange(val) {
        this.params.page = val;
        this.getPageList(this.params);
      },
      getPageList(params) {
        $http.get($http.api.sprint.page_list, params).then(res => {
          this.sprintPageData = res.data.results;
          this.totalPage = res.data.pageInfo.totalRecords;
        });
      },
      getSprintList() {
        this.params.page = 1;
        this.params.status = this.sprintStatus;
        this.getPageList(this.params);
      },
      //获取用户
      getAssignUser(value) {
        let projectId = this.getUrlParams().projectId;
        this.userData = $utils.getStorage(GLOBAL_CONST.USER_INFO);
        let query = value || null;
        $http
          .post($http.api.project.assignUser, { projectId, query })
          .then(res => {
            //todo cpp 这里应该获取自己的queryType=1

            this.assignUserData = res.data.map(item => {
              return {
                key: item.userId,
                value: item.userName + "(" + item.userId + ")"
              };
            });
            let data = this.userData.userId;
            let user = this.assignUserData.find(n => n.key == data);
            this.sprintForm.chargeUser = user.key;
          });
      },
      handleAssignerChange(value) {
        this.requirement.assignUser = value;
        this.prepareUpdateRequire(
          this.field.assignUser,
          this.requirement.assignUser
        );
        //this.sendUpdateRequireRequest();
      },
      sureAddSprint() {
        this.$refs["sprintForm"].validate(validate => {
          if (validate) {
            this.dialogFormVisible = false;
            this.sprintForm.projectId = this.projectId;
            this.sendAddSprintRequest();
          }
        });
      },
      sendAddSprintRequest() {
        $http.post($http.api.sprint.add_sprint, this.sprintForm).then(res => {
          if (res.status == 200) {
            this.getSprintList();
            this.$message({ message: res.msg || "添加迭代成功", type: "success" });
          } else {
            this.$message({ message: res.msg || "添加失败", type: "error" });
          }
        });
      },

      sendUpdateSprintRequest() {
        $http.post($http.api.sprint.update_sprint, this.sprintForm).then(res => {
          if (res.status == 200) {
            this.getSprintList();
            this.$message({ message: res.msg || "修改迭代成功", type: "success" });
          } else {
            this.$message({ message: res.msg || "修改失败", type: "error" });
          }
        });
      },

      toSprintDetail(sprintId) {
        this.goToPage(this, "sprintDetail", {
          sprintId: sprintId,
          projectId: this.projectId
        });
      },
      createSprint() {
        this.dialogFormVisible = true;
        this.dialogFormTitle = "创建迭代";
        this.sprintForm.id = 0;
        this.$nextTick(() => {
          this.$refs["sprintForm"].resetFields();
        });
      },
      sureUpdateSprint() {
        this.$refs["sprintForm"].validate(validate => {
          if (validate) {
            this.dialogFormVisible = false;
            this.sprintForm.projectId = this.projectId;
            this.sendUpdateSprintRequest();
          }
        });
      },
      editSprint(id) {
        this.dialogFormTitle = "编辑迭代";

        let params = { sprintId: id };
        $http.get($http.api.sprint.base_info, params).then(res => {
          this.$nextTick(()=>{
            this.sprintForm = res.data;
            this.dialogFormVisible = true;
          })
        });
       
      },
      lockSprint(id, name) {
        this.$confirm(
          `确定锁定迭代['${
          name
          }']吗？`
        ).then(() => {
          $http.post($http.api.sprint.sprint_lock, { sprintId: id }, { type: 'form' }).then(res => {
            if (res.msg == '需要执行强制锁定') {
              this.$confirm("迭代每个阶段的计划日期尚没有完全确定，是否强制锁定迭代?", "提示", {
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
              }).then(() => {
                this.forceLockSpring(id)
              })
            } else {
              this.$message({ message: res.msg || "操作成功", type: "success" });
              this.getPageList(this.params);
            }
          }).catch(e => {
          })
        });
      },
      //强制锁定
      forceLockSpring(id) {
        $http.post($http.api.sprint.sprint_force_lock, { sprintId: id }, { type: 'form' }).then(res => {
          if (res.status === 200) {
            this.$message({ message: res.msg || "操作成功", type: "success" });
            this.getPageList(this.params);
          }
        });
      },
      unLockSprint(id, name) {
        this.$confirm(
          `确定解锁迭代['${
          name
          }']吗？`
        )
          .then(_ => {
            $http
              .post(
                $http.api.sprint.sprint_unlock,
                { sprintId: id },
                { type: "form" }
              )
              .then(res => {
                this.$message({ message: res.msg || "操作成功", type: "success" });
                this.getPageList(this.params);
              });
          })
          .catch(_ => {
          });
      },
      stopSprint(row) {
        this.$confirm(
          `已归档迭代['${
          row.name
          }']及其所含需求/任务将被归档且无法修改，确认结束此迭代吗？`
        )
          .then(_ => {
            $http
              .post(
                $http.api.sprint.stop_sprint,
                { sprintId: row.id },
                { type: "form" }
              )
              .then(res => {
                this.$message({ message: res.msg || "操作成功", type: "success" });
                window.location.reload();
              });
          })
          .catch(_ => {
          });
      },
      deleteSprint(row) {

        this.$confirm(
          `删除迭代['${
          row.name
          }']，其所含需求/任务/缺陷的迭代属性将被置为未规划，确认删除此迭代吗？`
        )
          .then(_ => {
            $http
              .post(
                $http.api.sprint.defect_sprint,
                { sprintId: row.id },
                { type: "form" }
              )
              .then(res => {
                if(res.status == 200){
                  // 清空缺陷基本信息的 session 值
                  let getSession =JSON.parse(sessionStorage.getItem("LASTBUGCREATE"));
                  if(getSession&&getSession.sprintId == row.id){
                    getSession.sprintId = ''
                    sessionStorage.setItem("LASTBUGCREATE", JSON.stringify(getSession));
                  }
                }
                this.$message({ message: res.msg || "操作成功", type: "success" });
                window.location.reload();
              });
          })
          .catch(_ => {
          });
      },
      planSprint(row) {
        this.goToPage(this, "sprintPlan", {
          projectId: row.projectId,
          sprintId: row.id
        });
      }
    }
  };
</script>
<style lang="scss" scoped>
  .content {
    max-width: 1260px;
    position: relative;
    min-width: 960px;
    // height: 91px;
    height: 117px;
    border-width: 1px;
    border-style: solid;
    border-color: rgba(51, 153, 255, 1);
    margin-top: 10px;

    .content-item-p {
      margin: 0;
      height: 26px;
      line-height: 26px;
      display: inline-block;
      min-width: 160px;
    }

    .content-item-middle {
      height: 26px;
      line-height: 26px;
      // margin-top: 5px;
    }

    .progress-user {
      width: 270px;
      display: inline-block;
      position: relative;
      right: -30px;
      // position: absolute;
      // right: 25%;
      // bottom: 5px;
    }

    .dateTips {
      color: #fff;
      border-radius: 8px;
      padding: 1px 4px;
      font-size: 12px;
      background: #f0a100;
    }

    .dateTipsred {
      color: #fff;
      border-radius: 8px;
      padding: 1px 4px;
      font-size: 12px;
      background: #fa0b00;
    }

    .sprint-desc {
      height: 26px;
      line-height: 26px;
      padding-left: 20px;
      margin: 0;
    }
  }

  .font-desgin {
    font-size: 14px;
    color: #333;
    font-weight: 700;
    margin-left: 20px;
  }

  .sprint-name {
    width: calc(100% - 580px);
    display: inline-block;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .progress {
    width: 100px;
    height: 18px;
    display: inline-block;
    border-radius: 0% !important;
    position: relative;
    top: -2px;
  }

  .ml30 {
    margin-left: 30px;
  }

  .ml77 {
    margin-left: 77px;
  }

  .ui-tag-yellow {
    display: inline-block;
    max-width: 75px;
    line-height: 20px;
    box-sizing: border-box;
    color: #f0a100;
    border: 1px solid #f0a100;
    border-radius: 8px;
    padding: 0 4px;
    font-size: 12px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    vertical-align: middle;
    position: relative;
    top: -2px;
  }

  // .dialog {
  //   width: 600px;
  //   height: 300px;
  // }
  // .dialog-footer{
  //   float: right;
  // }
</style>