<template>
  <div v-loading="loading"
    element-loading-text
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)">
    <div class="custom-header">
      <el-button type="text" @click="backBtn">&lt;&lt; 返回</el-button>
      <el-form label-width="80px" class="header-form">
        <el-form-item label="模板名称">
          <el-input v-model.trim="form.name" @change="updateTemplate" @blur="updateTemplate" placeholder="请输入模板名称"></el-input>
        </el-form-item>
        <el-form-item label="模板描述">
          <el-input type="textarea" :rows="4" v-model="form.description" @change="updateTemplate" @blur="updateTemplate" placeholder="请输入模板描述"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <div class="list-contain">
      <el-table row-key="id" align="left" style="width: 100%">
        <el-table-column prop label="序号" width="60"></el-table-column>
        <el-table-column
          prop="stageName"
          :label="authFunction('FUNC_COOP_SPRINT_STAGE_SORT', 3, projectId)?'阶段名 (可拖拽名称进行排序)':'阶段名'"
          class-name="list-name"
        >
          <template slot-scope="scope">
            <span>{{scope.stageName}}</span>
          </template>
        </el-table-column>
        <el-table-column prop label="操作" width="120"></el-table-column>
      </el-table>
      <draggable
        :list="tableData"
        :disabled="false"
        class="list-group"
        ghost-class="ghost"
        :options="{filter:'.notdraggable'}"
        @end="endMove"
      >
        <ul v-for="(item,$index) in tableData" :key="item.id">
          <li
            :class="{'notdraggable': item.stageName=='未开始'||item.stageName=='已完成',
            'list-poniter': item.stageName!=='未开始'&&item.stageName!=='已完成'}"
          >
            <span class="sort-text">{{$index+1}}</span>
            <span style="width:31px;display: inline-block;"></span>
            <span v-if="item.showtext">{{item.stageName}}</span>
            <input type="text" v-model="item.stageName" v-if="!item.showtext">
            <span
              @click="handleDeleteClick(item)"
              class="list-delete"
              v-show="item.stageName=='未开始'?false:item.stageName=='已完成'?false:true"
              v-if="item.showtext && authFunction('FUNC_COOP_SPRINT_STAGE_DELETE', 3, projectId)"
            >删除</span>
            <span class="list-delete"></span>
            <span
              @click="handleEaitClick(item)"
              class="list-delete"
              v-show="item.stageName=='未开始'?false:item.stageName=='已完成'?false:true"
              v-if="item.showtext && authFunction('FUNC_COOP_SPRINT_STAGE_UPDATE', 3, projectId)"
            >编辑</span>
            <span
              class="list-delete"
              v-show="item.stageName=='未开始'?true:item.stageName=='已完成'?true:false"
            ></span>
            <span @click="cancleEaitClick(item)" class="list-delete" v-if="!item.showtext">取消</span>
            <span class="list-delete"></span>
            <span @click="saveEaitClick(item)" class="list-delete" v-if="!item.showtext">保存</span>
          </li>
        </ul>
      </draggable>
    </div>
    <footer class="footer">
      <el-button
        @click="creatBtn"
        type="text"
        class="new-stage"
        v-show="authFunction('FUNC_COOP_SPRINT_STAGE_ADD', 3, projectId)"
      >新建迭代阶段</el-button>
      <el-button
        @click="saveBtn"
        type="primary"
        class="save-stage"
        v-show="authFunction('FUNC_COOP_SPRINT_STAGE_ADD', 3, projectId) && type === 'add'"
      >保存</el-button>
    </footer>

    <el-dialog title="修改阶段" :visible.sync="diagloshow" width="26%">
      <div class="date-container">
        <div class="data-left">
          <span class="data-icon">阶段名：</span>
          <el-input v-model="stageName" placeholder="请输入内容" style="width:80%;"></el-input>
        </div>
        <!-- <div class="data-left" style="margin:10px 0;">
          <span
            class="data-icon"
            style="display: inline-block;margin-bottom: 18px;"
          >描 &nbsp;&nbsp;述：</span>
          <el-input type="textarea" placeholder="请输入内容" v-model="stageDesc" style="width:80%;"></el-input>
        </div>-->
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="cancleBtn">取 消</el-button>
        <el-button type="primary" @click="confirmBtn">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 迭代阶段模板详情
 * @desc
 * @author panhui | heyunjiang
 * @date 2019.7.29
 */
import Sortable from "sortablejs";
import draggable from "vuedraggable";
import GlobalInput from "../../tool/FieldEdit/GlobalInput.vue";
export default {
  name: "SprintInfoDateModified",
  components: { draggable, GlobalInput },
  mixins: [],
  props: {
    templateId: {
      type: [Number, String],
      required: true,
      desc: '模板 id'
    },
    type: {
      type: String,
      required: false,
      desc: '当前类型，新增或更新',
      default: 'add',
      validator: (value) => {
        return ['add', 'update'].includes(value)
      }
    }
  },
  data() {
    return {
      form: {
        name: '', // 模板名称
        description: '' // 模板描述
      },
      tableData: [], // 迭代阶段数据
      // dragging: false,
      diagloshow: false,
      stageName: "",
      stageDesc: "",
      showtext: true,
      sortShow: true,
      canDelete: true,
      deleteItem: {},
      projectId: this.getUrlParams().projectId,
      loading: false,
      addIdPoor: [], // 新建迭代阶段的临时 id 池
      cacheStageName: '' // 缓存数据，当点击取消时，回滚数据
    };
  },
  mounted() {
    this.initData();
  },
  computed: {},
  watch: {
    templateId() {
      this.initData();
    }
  },
  created() { },
  methods: {
    initData() {
      this.addIdPoor = [];
      if (this.type === 'add') {
        this.initStageList();
      } else {
        this.initTemplateInfo();
      }
    },
    // 修改时 - 初始化数据
    async initTemplateInfo() {
      if (this.templateId === -1) { return; }
      let result = {}
      try {
        this.loading = true;
        result = await $http.get($http.api.sprint.template_info, {
          projectId: this.projectId || this.getUrlParams().projectId,
          templateId: this.templateId
        });
      } finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取迭代阶段模板数据失败',
          type: 'error'
        })
        return;
      }
      this.form = { ...result.data.template };
      this.tableData = result.data.sprintStageList.map((item, index) => {
        return {
          ...item,
          showtext: true,
          sort: index
        }
      }) || [];
    },
    // 新增时 - 获取模板阶段列表数据
    async initStageList() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.get($http.api.sprint.stage_list, {
          projectId: this.projectId || this.getUrlParams().projectId,
          templateId: 0
        });
      } finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取迭代阶段模板初始数据失败',
          type: 'error'
        })
        return;
      }
      this.tableData = result.data.map((item, index) => {
        return {
          ...item,
          showtext: true,
          sort: index
        }
      })
    },
    // 拖拽结束处理 - 分为新建和更新2种处理
    endMove(evt) {
      if (!this.authFunction('FUNC_COOP_SPRINT_STAGE_SORT', 3, this.projectId)) {
        return false;
      }
      //移动之后改变序列号
      if (evt.newIndex == 0) {
        this.$message({ message: '不能调整至首位', type: 'info' });
        evt.newIndex = evt.oldIndex;
        return false;
      }
      if (evt.newIndex == this.tableData.length - 1) {
        this.$message({ message: '不能调整至末位', type: 'info' });
        evt.newIndex = evt.oldIndex;
        return false;
      }
      if (this.type === 'add') { return false; }
      $http.post($http.api.sprint.stage_sort, {
        templateId: this.templateId,
        stageIdList: this.tableData.map(item => item.id)
      }).then(res => {
        if (res.status == 200) {
          this.initData();
        } else {
        }
      });
    },
    // 新建迭代阶段 - 生成临时 id
    generateNewStageId() {
      let id = this.addIdPoor.length + 1;
      this.addIdPoor.push(id);
      return id;
    },
    // 新建迭代阶段 - 点击确定
    confirmBtn() {
      //新建阶段
      if (!this.stageName) {
        this.$message({ message: "请输入名称" });
        return false;
      }
      this.diagloshow = false;
      let obj = {
        stageName: this.stageName,
        stageDesc: this.stageDesc,
        templateId: this.templateId
      };
      if (this.type === 'add') {
        // 如果是新建，则直接更新 tableData 对象即可，在最后一个之前插入数据
        const position = this.tableData.length;
        this.tableData.splice(position - 1, 0, {
          id: this.generateNewStageId(),
          sort: position,
          stageDesc: this.stageDesc,
          stageName: this.stageName,
          templateId: 0,
          showtext: true
        })
      } else {
        $http.post($http.api.sprint.stage_add, obj).then(res => {
          if (res.status == 200) {
            this.$message({ message: res.msg || "新建迭代阶段成功", type: "success" });
            this.initData();
          } else {
            this.$message({ message: res.msg || "新建迭代阶段失败", type: "error" });
          }
        });
      }
    },
    // 新建迭代阶段 - 点击取消
    cancleBtn() {
      this.diagloshow = false;
    },
    // 操作前的确认
    async confirmBeforeOperate(text = '') {
      let result = null
      try {
        result = await this.$confirm(text, {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: 'warning'
        })
      } catch (_) {
        result = false;
      }
      return result;
    },
    // 点击顶部返回
    backBtn() {
      this.$emit('back');
    },
    //  新建迭代阶段 - 点击新建
    creatBtn() {
      this.diagloshow = true;
    },
    // 迭代阶段修改 - 点击编辑
    handleEaitClick(item) {
      this.cacheStageName = item.stageName;
      item.showtext = false;
      this.$forceUpdate(); //刷新列表
    },
    // 迭代阶段修改 - 点击保存
    saveEaitClick(item) {
      if (this.type === 'add') {
        // 如果是新建，则直接更新 tableData 对象即可
        this.tableData = this.tableData.map(jtem => {
          return {
            ...jtem,
            showtext: true,
            stageName: jtem.id === item.id ? item.stageName : jtem.stageName
          }
        })
      } else {
        let obj = { id: item.id, stageName: item.stageName, templateId: this.templateId };
        $http.post($http.api.sprint.stage_update, obj).then(res => {
          if (res.status == 200) {
            this.$message({ message: res.msg || "修改成功", type: "success" });
            this.initData();
          } else {
            this.$message({ message: res.msg || "修改失败", type: "success" });
          }
        });
      }
    },
    // 更新迭代阶段的名称、描述
    async updateTemplate() {
      if(this.type === 'add') {return ;}
      let result = {}
      try {
        this.loading = true;
        result = await $http.post($http.api.sprint.template_update, {
          projectId: this.projectId || this.getUrlParams().projectId,
          id: this.templateId,
          ...this.form,
          // sprintStageList: this.tableData
        });
      } finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '更新失败',
          type: 'error'
        })
      } else {
        this.$message({
          message: result.msg || '更新成功',
          type: 'success'
        });
        this.initData()
      }
    },
    // 迭代阶段修改 - 点击取消
    cancleEaitClick(item) {
      item.stageName = this.cacheStageName;
      item.showtext = true;
      this.$forceUpdate(); //刷新列表
    },
    // 迭代阶段修改 - 点击删除
    async handleDeleteClick(item) {
      const result = await this.confirmBeforeOperate(`确定删除阶段${item.stageName}吗？`);
      if(!result) {return ;}
      if (this.type === 'add') {
        // 如果是新建，则直接更新 tableData 对象即可
        this.tableData = this.tableData.filter(jtem => item.id !== jtem.id);
      } else {
        $http.post($http.api.sprint.stage_delete, { stageId: item.id, templateId: this.templateId }, { type: "form" }).then(res => {
          if (res.status == 200) {
            this.initData();
            this.$message({ message: res.msg || "删除成功", type: "success" });
            item.showtext = true;
          } else {
            this.$message({ message: res.msg || "删除失败", type: 'error' });
          }
        });
      }
    },
    // 点击保存
    async saveBtn() {
      if(this.form.name.length === 0) {
        this.$message({
          message: '模板名称不能为空',
          type: 'warning'
        })
        return ;
      }
      let result = {}
      try {
        this.loading = true;
        result = await $http.post($http.api.sprint.template_add, {
          projectId: this.projectId || this.getUrlParams().projectId,
          name: this.form.name,
          description: this.form.description,
          sprintStageList: this.tableData.map(item => item.stageName)
        });
      } finally {
        this.loading = false;
      }
      if (!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '创建失败',
          type: 'error'
        })
        return ;
      } else {
        this.$message({
          message: result.msg || '创建成功',
          type: 'success'
        })
        this.$emit('back')
      }
    }
  }
};
</script>
<style lang="scss" scoped>
// 顶部返回按钮和 form 表单
.custom-header {
  margin-bottom: 10px;
  font-size: 14px;
  .header-form {
    width: 400px;
  }
}
// table
.list-contain {
  position: relative;
  padding: 0 10px;
  .list-group {
    // position: absolute;
    // top: 42px;
    // left: 17px;
    background: #fff;
    // min-width: calc(100% - 85px);
    min-width: calc(100% - 20px);
    ul {
      list-style: none;
      margin: 0;
      padding: 0;
      border-bottom: 1px solid #eae9e9;
    }
    li {
      padding: 7px 0;
      width: calc(100% - 47px);
      .sort-text {
        padding-left: 11px;
        width: 25px;
        display: inline-block;
      }
    }
  }
  .list-name {
    div {
      // background: red !important;
    }
  }
  .list-delete {
    color: #409eff;
    cursor: pointer;
    float: right;
    width: 30px;
  }
  .list-poniter {
    cursor: pointer;
  }
}
.notdraggable {
  cursor: not-allowed;
}
footer {
  padding: 10px;
  .new-stage {
    float: left;
  }
  .save-stage {
    float: right;
  }
}
</style>
