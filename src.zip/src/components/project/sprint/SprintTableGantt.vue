<template>
  <div id="table-gantt" class="table-gantt-box" ref="tableGanttBox">
    <div class="scrollbar-box" :class="{'fixed-top': isScrollbarFixed}" v-show="showGantt" ref="scrollbarbox">
      <div class="scrollbar-item scrollbal-common scrollbar-left" ref="scrollbarleft">
        <div class="scrollbar-content" ref="scrollbarleftcontent"></div>
      </div>
      <div class="scrollbar-item scrollbal-common scrollbar-right" ref="scrollbarright">
        <div class="scrollbar-content" ref="scrollbarrightcontent"></div>
      </div>
    </div>
    <two-block-width-changer :initLeftWidth="showGantt?'50%':'100%'" :showRight="showGantt" :enableCollspan="showGantt" ref="TwoBlockWidthChanger" @dragend="refreshScrollBarWidth">
      <div ref="tableGanttLeft" slot="left">
        <tree-table
          :data="treeData"
          :expand-all="expandAll"
          border
          :isChecked="false"
          :ltype="2"
          @seeTaskHandle="seeTaskHandle"
          @HandleSide="HandleSide"
          :updateGlobalTitle="updateGlobalTitle"
          :sortaChangeCallBack="sortaChangeCallBack"
          :expandChangeCallBack="expandChangeCallBack"
        >
          <el-table-column
            label="优先级"
            prop="priority"
            sortable="custom"
            show-overflow-tooltip
            width="90"
          >
            <template slot-scope="scope">
              <span
                class="cursor-pointer"
                v-html="initNameStatus(scope.row.data.display.detail.priority.color,scope.row.data.display.detail.priority.literal)"
                @click.stop="(e) => GlobalSelectTargetClick(scope.row.data, e, 'priority', getBaseList)"
              ></span>
            </template>
          </el-table-column>
          <el-table-column
            label="状态"
            prop="statusId"
            sortable="custom"
            show-overflow-tooltip
            width="120"
          >
            <template slot-scope="scope">
              <span
                class="cursor-pointer"
                v-html="initNameStatus(scope.row.data.display.detail.status.color,scope.row.data.display.status)"
                @click.stop="(e) => GlobalSelectTargetClick(scope.row.data, e, 'statusId', getBaseList)"
              >{{scope.row.data.display.status}}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="处理人"
            prop="assignUser"
            sortable="custom"
            show-overflow-tooltip
            width="160"
          >
            <template slot-scope="scope">
              <span
                class="cursor-pointer"
                @click.stop="(e) => GlobalSelectTargetClick(scope.row.data, e, 'assignUser', getBaseList)"
              >{{scope.row.data.display.assignUser}} ({{scope.row.data.assignUser}})</span>
            </template>
          </el-table-column>
          <el-table-column
            label="任务总工时"
            prop="expectHour"
            show-overflow-tooltip
            width="90"
          >
            <template slot-scope="scope">
              <span v-if="scope.row.data.workItemType&&scope.row.data.workItemType === 2" class="cursor-pointer"
                @click.stop="(value)=>{GlobalSelectTargetClick(scope.row.data, value, 'expectHour', getBaseList)}">{{(scope.row.data.expectHour/8)+'天' || '--'}}</span>
              
              <!-- <global-input v-if="scope.row.data.workItemType&&scope.row.data.workItemType === 2" :initValue="scope.row.data.expectHour" 
                :onChange="(value)=>{GlobalTaskUpdate({expectHour: value, id: scope.row.data.id, projectId: scope.row.data.projectId, cb: getBaseList})}">
                <span class="ellipsis cursor-pointer" slot>{{scope.row.data.expectHour}}</span>
              </global-input> -->
              <span style="padding: 0 5px;" v-else>{{(scope.row.data.expectHour/8)+'天' || '--'}}</span>
            </template>
          </el-table-column>
          <el-table-column
            label="预计开始时间"
            prop="startTime"
            sortable="custom"
            show-overflow-tooltip
            width="125"
          >
            <template slot-scope="scope">
              <global-input
                :initValue="scope.row.data.startTime || ''"
                inputType="time"
                :onChange="(value)=>{GlobalInputTimeUpdate(scope.row.data, value, 'startTime', getBaseList)}"
              >
                <span slot>{{scope.row.data.startTime || '--'}}</span>
              </global-input>
            </template>
          </el-table-column>
          <el-table-column
            label="预计结束时间"
            prop="endTime"
            sortable="custom"
            show-overflow-tooltip
            width="125"
          >
            <template slot-scope="scope">
              <global-input
                :initValue="scope.row.data.endTime || ''"
                inputType="time"
                :onChange="(value)=>{GlobalInputTimeUpdate(scope.row.data, value, 'endTime', getBaseList)}"
              >
                <span slot>{{scope.row.data.endTime || '--'}}</span>
              </global-input>
            </template>
          </el-table-column>
        </tree-table>
      </div>
      <div :class="{'table-gantt-box-right-empty':ganttProps.tasks.length===0}" ref="tableGanttRight" slot="right">
        <Gantt v-show="ganttProps.tasks.length > 0" v-bind="ganttProps" />
        <div v-if="ganttProps.tasks.length===0" class="table-gantt-box-right-empty-text">暂无数据</div>
      </div>
    </two-block-width-changer>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
  </div>
</template>
<script>
/**
 * @title table && gantt 组件
 * @desc
 * @author heyunjiang
 * @date 2019.5.7
 */
import treeTable from "@/components/tool/TreeTable/ganttTable";
// import treeTable from '@/components/project/sprint/treeTable'
import GlobalSelect from "../../tool/FieldEdit/GlobalSelect.vue";
import GlobalInput from "../../tool/FieldEdit/GlobalInput.vue";
import ProjectCommonMixin from "@/components/project/ProjectCommonMixin";
import treeToArray from "@/components/tool/TreeTable/eval";
import TwoBlockWidthChanger from "@/components/tool/TwoBlockWidthChanger";
import Gantt from "./Gantt.vue";

export default {
  name: "SprintTableGantt",
  components: {
    treeTable,
    GlobalSelect,
    GlobalInput,
    Gantt,
    TwoBlockWidthChanger
  },
  mixins: [ProjectCommonMixin],
  props: {
    treeData: {
      type: Array,
      required: true,
      desc: "树形数据源"
    },
    dateList: {
      type: Array,
      required: false,
      desc: "日期数据源，如果为甘特图展示，则需要传 dateList"
    },
    seeTaskHandle: {
      type: Function,
      required: true,
      desc: "点击某条数据查看详情，使用原有方法就行了"
    },
    HandleSide: {
      type: Function,
      required: true,
      desc: "不太清楚功能"
    },
    sortaChangeCallBack: {
      type: Function,
      required: true,
      desc: "table 排序"
    },
    getBaseList: {
      type: Function,
      required: true,
      desc: "更新列表数据"
    },
    showGantt: {
      type: Boolean,
      required: false,
      default: false,
      desc: "是否展示甘特图"
    }
  },
  data() {
    return {
      expandAll: true, // 是否展开所有子数据
      treeArrayData: [], // treeData 经过 treeToArray 处理后的数据
      hiddenChildKeys: [], // 已经展示的后代key
      ganttProps: {
        tasks: [],
        dateList: [],
        scrollCallback: () => {},
        hoverCallback: this.ganttHoverCallback,
        activeRow: -1
      },
      tableGanttLeftTable: null, // 左侧 table container
      tableGanttLeftTableWrapper: null, // 左侧 table body
      ganttContainer: null, // 甘特图整体容器
      ganttBox: null, // 甘特图 svg 容器
      lastScrollTime: new Date().getTime(),
      tableGanttLeftTableTrs: [],
      isScrollbarFixed: false // 是否固定顶部滚动条 fix
    };
  },
  computed: {},
  watch: {
    treeData() {
      if(!this.showGantt) {return ;}
      this.ganttProps.dateList = this.dateList
      const treeArrayData = treeToArray.apply(null, [this.treeData, this.expandAll])
      this.treeArrayData = treeArrayData
      this.generateTasks(treeArrayData)
      this.$nextTick(()=> {
        this.tableGanttLeftTableTrs = Array.from(this.tableGanttLeftTable.querySelectorAll('tr'))
        this.$refs.TwoBlockWidthChanger.refreshMiddleLineHeight();
        this.refreshScrollBarContentWidth();
        // 设置顶部滚动条盒子宽度为具体 px 值
        this.$refs.scrollbarbox.style.width = this.$refs.tableGanttBox.getBoundingClientRect().width + 'px';
      })
    }
  },
  mounted() {
    this.init()
  },
  destroyed() {
    this.uninit()
  },
  methods: {
    uninit() {
      window.removeEventListener('scroll', this.scrollHandle)
    },
    // 初始化
    init() {
      if(!this.showGantt) {return ;}
      this.uninit();
      this.tableGanttLeftTableWrapper = this.$refs.tableGanttLeft.querySelector('.el-table__body-wrapper');
      const tableGanttLeftTable = this.$refs.tableGanttLeft.querySelector('.el-table__body');
      this.ganttContainer = this.$refs.tableGanttRight.querySelector('.gantt-container');
      this.ganttBox = this.$refs.tableGanttRight.querySelector('.gantt');
      this.tableGanttLeftTable = tableGanttLeftTable;
      // 初始化鼠标滚动事件
      // tableGanttLeftTable.removeEventListener('wheel', this.ganttTableScrollEvent)
      // tableGanttLeftTable.addEventListener('wheel', this.ganttTableScrollEvent)
      // 初始化中间栏拖拽事件
      // this.$nextTick(this.initMiddleLineProxyEvent)
      // window.addEventListener('resize', this.initMiddleLineProxyEvent)
      // 初始化鼠标悬浮事件
      tableGanttLeftTable.removeEventListener('mouseover', this.tableHoverEventHandle);
      tableGanttLeftTable.addEventListener('mouseover', this.tableHoverEventHandle);
      // 初始化鼠标移出事件
      tableGanttLeftTable.removeEventListener('mouseout', this.tableMouseoutEventHandle);
      tableGanttLeftTable.addEventListener('mouseout', this.tableMouseoutEventHandle);
      // 初始化顶部滚动条滚动事件
      this.$refs.scrollbarleft.removeEventListener('scroll', this.scrollbarleftScrollEvent)
      this.$refs.scrollbarleft.addEventListener('scroll', this.scrollbarleftScrollEvent)
      this.$refs.scrollbarright.removeEventListener('scroll', this.scrollbarrightScrollEvent)
      this.$refs.scrollbarright.addEventListener('scroll', this.scrollbarrightScrollEvent)
      // window 滚动设置顶部滚动条固定
      window.addEventListener('scroll', this.scrollHandle);
    },
    // 封装 this.ganttProps.tasks 
    generateTasks(tableData) {
      this.ganttProps.tasks = tableData.map(item => {
        // 是否是需求
        let isRequirement = item.data.workItemType&&item.data.workItemType===1?true:false
        let { start, end } = this.compareStarAndEndTime(item.data.startTime, item.data.endTime)
        // 如果是需求则需要计算起止时间
        let cbj = {}
        if(isRequirement) {
          // cbj = this.getStartAndEndForRequirement(item)
          // 如果是需求，则增加绘制一条实际开始结束时间
          cbj.realStart = item.data.taskStartTime || null
          cbj.realEnd = item.data.taskEndTime || null
        }
        let obj = {
          id: item.data.key + '',
          name: item.data.display.assignUser,
          start,
          end,
          barLength: item.data.barLength,
          startPosition: item.data.startPosition,
          progress: 100,
          custom_class: "bar-milestone", // optional
          ...cbj,
          isDelay: item.data.display && item.data.display.delayed,
          isParent: isRequirement // 是否是需求，放在最后面，是避免被 cbj 中的 isRequirement 冲销掉了
        }
        if(item.parent) {
          obj.dependencies = item.parent.data.key + ''
        }
        return obj
      });
    },
    // 全局更新标题 - add by heyunjiang on 2019.5.7
    updateGlobalTitle(info, value) {
      let originInfo = {};
      if (info.data) {
        originInfo = { ...info.data };
      } else {
        let workItemType = 1;
        switch (this.$route.name) {
          case REQUIREMENT:
            workItemType = info.workItemType || 1;
            break;
          case BUGLIST:
            workItemType = info.workItemType || 3;
            break;
        }
        originInfo = { ...info, workItemType };
      }
      let cb = this.getBaseList,
        updatefunc = this.GlobalRequirementUpdate;
      switch (+originInfo.workItemType) {
        case 1:
          updatefunc = this.GlobalRequirementUpdate;
          break;
        case 2:
          updatefunc = this.GlobalTaskUpdate;
          break;
        case 3:
          updatefunc = this.GlobalBugUpdate;
          break;
      }
      updatefunc({
        id: originInfo.id,
        title: value,
        projectId: originInfo.projectId || this.getUrlParams().projectId,
        cb
      });
    },
    // 全局更新时间 input - 迭代 - add by heyunjiang on 2019.5.7
    GlobalInputTimeUpdate(info, value, key, cb) {
      let func = this.GlobalRequirementUpdate;
      switch (+info.workItemType) {
        case 1:
          func = this.GlobalRequirementUpdate;
          break;
        case 2:
          func = this.GlobalTaskUpdate;
          break;
        case 3:
          func = this.GlobalBugUpdate;
          break;
      }
      func({
        [key]: value,
        id: info.id,
        projectId: info.projectId,
        cb
      });
    },
    // [已废弃] -  获取需求对应后代的最长时间、最短时间 - 入口
    getStartAndEndForRequirement(item) {
      let obj = {
        start: null,
        end: null,
        isRequirement: true
      }
      // 如果没有后代
      if(!item.children || !Array.isArray(item.children) || item.children.length === 0) {
        obj = {
          start: this.compareStarAndEndTime(item.data.startTime, item.data.endTime).start,
          end: this.compareStarAndEndTime(item.data.startTime, item.data.endTime).end,
          isRequirement: false
        }
      } else {
        // 如果有后代
        let first, last
        this.getChildsTime(item).forEach(jtem => {
          if(!first) {
            first = jtem
            last = jtem
            return ;
          }
          if(new Date(first) > new Date(jtem)) {
            first = jtem
          }
          if(new Date(jtem) > new Date(last)) {
            last = jtem
          }
        })
        obj = {
          start: first,
          end: last,
          isRequirement: true
        }
      }
      return obj
    },
    // [已废弃] -  获取需求及对应后代的所有时间
    getChildsTime(item) {
      let times = []
      let obj = this.compareStarAndEndTime(item.data.startTime, item.data.endTime)
      // 如果是有效时间
      if(obj.start) {
        times = [...times, obj.start, obj.end]
      }
      // 如果是有后代
      if(item.children && (Array.isArray(item.children)&&item.children.length > 0)) {
        item.children.forEach(jtem => {
          times = [...times, ...this.getChildsTime(jtem)]
        })
      }
      return times
    },
    // 获取需求及对应后代的key
    getChildskey(item) {
      let keys = []
      keys.push(item.data.key + '')
      // 如果是有后代
      if(item.children && (Array.isArray(item.children)&&item.children.length > 0)) {
        item.children.forEach(jtem => {
          keys = [...keys, ...this.getChildskey(jtem)]
        })
      }
      return keys
    },
    // 比较起止时间问题
    compareStarAndEndTime(start, end) {
      let obj = {}
      if(new Date(start) > new Date(end)) {
        obj = {
          start: null,
          end: null
        }
      } else {
        obj = {
          start,
          end
        }
      }
      // if(new Date() > new Date(end)) {
      //   obj.isDelay = true;
      // } else {
      //   obj.isDelay = false;
      // }
      return obj
    },
    // [已废弃] - 左侧 table 滚动监听事件
    ganttTableScrollEvent() {
      if(Math.abs(this.ganttContainer.scrollTop - this.tableGanttLeftTable.scrollTop) > 10) {
        this.ganttContainer.scrollTop = this.tableGanttLeftTable.scrollTop
      }
    },
    // [已废弃] - 甘特图滚动监听事件
    scrollCallback(top) {
      if(!this.tableGanttLeftTable) {return ;}
      if(Math.abs(top - this.tableGanttLeftTable.scrollTop) > 10) {
        this.tableGanttLeftTable.scrollTop = top
      }
    },
    // 收缩回调事件
    expandChangeCallBack(key, expanded) {
      const needShowTableDataSource = this.treeArrayData.filter(item => (item.data.key+'') === key)
      let childsKeys = this.getChildskey(needShowTableDataSource[0]).filter(item => item!==key)
      if(!expanded) {
        childsKeys = [...new Set([...this.hiddenChildKeys, ...childsKeys])]
      } else {
        childsKeys = this.hiddenChildKeys.filter(item => !childsKeys.includes(item))
      }
      this.hiddenChildKeys = childsKeys
      this.generateTasks(this.treeArrayData.filter(item => !childsKeys.includes(item.data.key+'')))
    },
    // 鼠标悬浮 - table 事件
    tableHoverEventHandle(e) {
      let num = null
      for(let i=0;i<this.tableGanttLeftTableTrs.length;i++) {
        if(this.tableGanttLeftTableTrs[i].contains(e.target)) {
          num = i;
          break;
        }
      }
      if(/\D/.test(num)) {return ;}
      this.table_row_active_set(num)
      this.ganttProps.activeRow = num
    },
    // 鼠标悬浮 - table 移出事件
    tableMouseoutEventHandle(e) {
      this.table_row_active_set(this.tableGanttLeftTableTrs.length)
      this.ganttProps.activeRow = this.tableGanttLeftTableTrs.length
    },
    // 鼠标悬浮 - table 选中行设置，允许传入一个大的 num 用于移除所有行的 el-table-active
    table_row_active_set(num) {
      if(/\D/.test(num)) {return ;}
      this.tableGanttLeftTableTrs.forEach((item, index) => {
        const className = item.getAttribute('class')
        if(className.indexOf('el-table-active') > -1 && num !== index) {
          item.setAttribute('class', className.replace(' el-table-active', ''))
        }
        if(index === num) {
          if(className.indexOf('el-table-active') > -1) {return ;}
          item.setAttribute('class', `${className} el-table-active`)
        }
      })
    },
    // 鼠标悬浮 - 甘特图
    ganttHoverCallback(num) {
      this.table_row_active_set(num)
    },
    // 顶部滚动条 - 计算滚动条内容宽度
    refreshScrollBarContentWidth() {
      this.$refs.scrollbarleftcontent.style.width = this.tableGanttLeftTable.getBoundingClientRect().width + 'px';
      this.$refs.scrollbarrightcontent.style.width = this.ganttBox.getBoundingClientRect().width + 'px';
    },
    // 顶部滚动条 - 计算滚动条宽度
    refreshScrollBarWidth(width) {
      this.$refs.scrollbarleft.style.width = width;
      this.$refs.scrollbarright.style.width = 'calc(100% - ' + width + ')';
    },
    // 顶部滚动条 - 左侧滚动事件
    scrollbarleftScrollEvent() {
      this.tableGanttLeftTableWrapper.scrollLeft = this.$refs.scrollbarleft.scrollLeft;
    },
    // 顶部滚动条 - 右侧滚动事件
    scrollbarrightScrollEvent() {
      this.ganttContainer.scrollLeft = this.$refs.scrollbarright.scrollLeft;
    },
    // 顶部滚动条 - 固定
    scrollHandle() {
      const sourceElement = this.$refs.tableGanttLeft
      if(sourceElement.getBoundingClientRect().top <= 14) {
        this.isScrollbarFixed = true;
      } else {
        this.isScrollbarFixed = false;
      }
    }
  }
};
</script>
<style lang="scss" scoped>
  // 滚动条样式
  .scrollbar-box {
    position: relative;
    display: inline-block;
    width: 100%;
    z-index: 2;
    .scrollbar-item {
      float: left;
      height: 10px;
      width: 50%;
      overflow-x: auto;
      overflow-y: hidden;
      .scrollbar-content {
        background: transparent;
        height: 1px;
      }
    }
  }
  // 甘特图左侧 table 样式
  .table-gantt-box {
    width: 100%;
    overflow: hidden;
    position: relative;
    font-size: 0;
    .table-gantt-box-right-empty {
      border: 1px solid #eef0f6;
      position: relative;
      height: 126px;
      .table-gantt-box-right-empty-text {
        position: absolute;
        top: 0;
        text-align: center;
        color: #c9cace;
        height: 126px;
        line-height: 126px;
        width: 100%;
        font-size: 14px;
      }
    }
  }
  .fixed-top {
    position: fixed;
    top: 0;
  }
</style>
<style lang="scss">
  // 去掉自带的滚动条
  #table-gantt {
    .is-scrolling-left,
    .gantt-container,
    .el-table__body-wrapper {
      overflow: hidden;
    }
  }
</style>

