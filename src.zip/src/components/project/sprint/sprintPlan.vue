<template>
  <div id="demand" class="content-outer-box" @click="HandleSide">
    <slide :show="show" @click.stop ref="side" :afterClose="HandleSide" v-loading="loading" element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading" element-loading-background="rgb(255,255,255)">
      <div slot="task" class="silder-box">
        <!-- <div class="taskinfo-title">编辑任务信息</div>
                        <div class="line-border"></div> -->
        <task-edit :taskId="taskId" :show="show" :restore="restore" v-on:HandleSide="HandleSide" v-if="workType===1">
        </task-edit>
        <!-- <task-edit :taskId="taskId" :projectId="projectId" :show="show" :restore="restore" ></task-edit> -->
        <bug-detail :detailType="detailType" :projectId="bugProjectId" :activeBugInfo="activeBugInfo"  @detailClose="HandleSide" :isSlider="true"
          v-else-if="workType===2" ></bug-detail>
          <demand-view  :requireId="taskId" :show="show" :restore="restore" v-on:HandleSide="HandleSide" v-else-if="workType===3"></demand-view>
      </div>

    </slide>
    <div class="x-arD content-box">
      <div class="review-treetable-all">
        <el-form :inline="true" :model="formInline">
          <el-form-item label="标题" class="mb10">
            <el-input v-model="formInline.title" style="width:120px;"></el-input>
          </el-form-item>
          <el-form-item label="迭代" class="mb10">
            <el-select v-model="formInline.sprintId" style="width: 100px">
              <el-option label="未规划" value="0"></el-option>
              <el-option v-for="item in sprintNameList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-button type="primary" @click="searchRequireTaskInfo" class="mb10" style="margin-top: 6px;">过滤</el-button>
          <el-button type="info" class="mb10" style="margin-top: 6px;" @click="returnBnt">返回</el-button>
        </el-form>
        <tree-table :data="searchRequireAndTaskInfo" :eval-args="args" :expand-all="expandAll"
          :show-check-box="showSearchCheckBox" ref="myTree" border style="width: 100%;margin-left: 0;" :ltype="2"
          @seeTaskHandle="seeTaskHandle" @HandleSide="HandleSide" :updateGlobalTitle="updateGlobalTitle" :sortaChangeCallBack="sortaChangeCallBackSearch">
          <!-- <el-table-column label="类型" width="60px">
            <template slot-scope="scope">
              {{ scope.row.data.workItemTypeDesc}}
            </template>
          </el-table-column> -->
          <el-table-column label="优先级" prop="priority" sortable="custom" width="90px">
            <template slot-scope="scope">
              <span
                class="cursor-pointer" v-html="initNameStatus(scope.row.data.display.detail.priority.color,scope.row.data.display.detail.priority.literal)"
                @click.stop="(e) => GlobalSelectTargetClick(scope.row.data, e, 'priority', searchRequireTaskInfo)">

              </span>
            </template>
          </el-table-column>
          <!--<el-table-column label="状态">-->
          <!--<template slot-scope="scope">-->
          <!--{{ scope.row.data.display.status}}-->
          <!--</template>-->
          <!--</el-table-column>-->
        </tree-table>
      </div>
      <div class="review-treetable-center">
        <div class="Shuttle" @click="addIntoSprint()">
          <i class="el-icon-d-arrow-right"></i>
        </div>
      </div>
      <div class="review-treetable-all">
        <div style="margin-bottom: 20px;margin-top: 10px;">
          <span class="sprint">{{sprintInfo.name}}</span>
          <span class="demand">需求：{{sprintInfo.totalRequires}}个</span>
          <span class="task">任务:{{sprintInfo.totalTasks}}个</span>
          <span class="bug">缺陷:{{sprintInfo.totalDefect}}个</span>
          <span class="datetime">周期：{{sprintInfo.startTime}}~{{sprintInfo.endTime}}</span>
        </div>
        <tree-table :data="requireAndTaskInfo" :eval-args="args" :expand-all="expandAll"
          :show-check-box="showSelectedCheckBox" border style="width: 100%;margin-left: 0;" :ltype="2"
          @seeTaskHandle="seeTaskHandle" @HandleSide="HandleSide" :updateGlobalTitle="updateGlobalTitle" :sortaChangeCallBack="sortaChangeCallBackRightTable">
          <!-- <el-table-column label="类型" width="60px">
            <template slot-scope="scope">
              {{ scope.row.data.workItemTypeDesc}}
            </template>
          </el-table-column> -->
          <el-table-column label="迭代" prop="sprintId" sortable="custom" show-overflow-tooltip width="100px">
            <template slot-scope="scope">
              <span class="cursor-pointer" @click.stop="(e) => GlobalSelectTargetClick(scope.row.data, e, 'sprintId', getRequireTaskInfo)">{{scope.row.data.display.sprint || '--'}}</span>
            </template>
          </el-table-column>
          <el-table-column label="优先级" prop="priority" sortable="custom" width="90px">
            <template slot-scope="scope">
              <span
                class="cursor-pointer" v-html="initNameStatus(scope.row.data.display.detail.priority.color,scope.row.data.display.detail.priority.literal)"
                @click.stop="(e) => GlobalSelectTargetClick(scope.row.data, e, 'priority', getRequireTaskInfo)"
              >

              </span>
            </template>
          </el-table-column>
          <!--<el-table-column label="状态">-->
          <!--<template slot-scope="scope">-->
          <!--<span @click="message(scope.row)">{{ scope.row.data.display.status}}</span>-->
          <!--</template>-->
          <!--</el-table-column>-->
          <el-table-column label="操作" width="60px">
            <template slot-scope="scope">
              <el-button type="text" @click="deleteFromSprint(scope.row)" v-if="deleteable(scope.row)">删除</el-button>
            </template>
          </el-table-column>
        </tree-table>
      </div>
    </div>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
  </div>
</template>

<script>

  import treeTable from '@/components/project/sprint/treeTable'
  import slide from 'components/tool/slideSlip'
  import taskEdit from 'components/project/task/taskDetail.vue'
  import bugDetail from 'components/project/bugManagement/BugDetail.vue'
  import demandView from 'components/project/requirement/requirementView.vue'
  import GlobalSelect from "../../tool/FieldEdit/GlobalSelect.vue"
  import ProjectCommonMixin from "@/components/project/ProjectCommonMixin"
  export default {
    name: 'sprintPlan',
    components: {
      treeTable,
      taskEdit,
      slide,
      bugDetail,
      demandView,
      GlobalSelect
    },
    mixins: [ProjectCommonMixin],
    data() {
      return {
        workType: null,
        detailType:'show',
        bugProjectId:null,
        activeBugInfo:null,
        urlParam: {
          projectId: 0,
          sprintId: 0,

        },
        workType:null,
        activeBugInfo:{},
        formInline: {
          projectId: 0,
          title: null,
          sprintId: "0",

        },
        sprintNameList: [],
        searchRequireAndTaskInfo: [],
        requireAndTaskInfo: [],
        sprintInfo: {},
        args: [null, null, 'timeLine'],
        expandAll: true,
        showSearchCheckBox: true,
        showSelectedCheckBox: false,
        selectedWorkItemData: [],
        deleteWorkItemData: [],
        count: 0,
        restore: 1,
        preID: null,
        show: false,
        taskId: null,
        loading: false
      }
    },
    mounted() {
      this.urlParam.projectId = this.getUrlParams().projectId;
      this.formInline.projectId = this.urlParam.projectId;
      this.urlParam.sprintId = this.getUrlParams().sprintId;

      this.getSprintNameList();
      this.getSprintInfo();
      this.getRequireTaskInfo();
      this.searchRequireTaskInfo();
    },
    watch: {
      show:
        function (newName, oldName) {
          if (newName !== true) {
            this.searchRequireTaskInfo()
            this.getRequireTaskInfo()
          }
        },
    },
    methods: {
      // 全局更新标题 - add by heyunjiang on 2019.5.8
      updateGlobalTitle(info, value) {
        let originInfo = { ...info.data };
        let cb = () => {
          this.getRequireTaskInfo()
          this.searchRequireTaskInfo()
        }
        let updatefunc = this.GlobalRequirementUpdate;
        switch (+originInfo.workItemType) {
          case 1:
            updatefunc = this.GlobalRequirementUpdate;
            break;
          case 2:
            updatefunc = this.GlobalTaskUpdate;
            break;
          case 3:
            updatefunc = this.GlobalBugUpdate;
            break;
        }
        updatefunc({
          id: originInfo.id,
          title: value,
          projectId: originInfo.projectId || this.getUrlParams().projectId,
          cb
        });
      },
      sortaChangeCallBackSearch(obj) {
        let param = {}
        if(obj.prop) {
          param = {
            column: obj.prop,
            order: obj.order==='descending'?'DESC':'ASC'
          }
        }
        this.$nextTick(() => {
          this.searchRequireTaskInfo(param)
        })
      },
      sortaChangeCallBackRightTable(obj) {
        let param = {}
        if(obj.prop) {
          param = {
            column: obj.prop,
            order: obj.order==='descending'?'DESC':'ASC'
          }
        }
        this.$nextTick(() => {
          this.getRequireTaskInfo(param)
        })
      },
      //查看任务
      seeTaskHandle(data, e) {

        if(data.workItemType ===2){
          this.workType = 1;
        }else if(data.workItemType === 3){
          this.workType = 2;
          this.bugProjectId = data.projectId
        }else{
          this.workType =3 ;
        }
        // this.goToPage(this, "taskEdit", {projectId: this.urlParam.projectId, taskId: id});
        if (e && e.stopPropagation) {//非IE浏览器
          e.stopPropagation();
        } else {//IE浏览器
          window.event.cancelBubble = true;
        }
        this.$nextTick(() => {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
          }, 500);
        })

        // let projectId = this.getUrlParams().projectId
        // this.goToNewWindowPage(thi s, "taskEdit", { taskId: data.id, projectId })

        if (this.count === 0) {

          this.preID = data.id
          this.show = !this.show;
          this.taskId = data.id;
          this.activeBugInfo = { id: data.id };
          this.restore = Math.random() * 10;
          this.count++;
        } else {
          if (this.preID !== data.id) {
            this.preID = data.id

            this.activeBugInfo = { id: data.id };
            // this.show = !this.show;
            this.taskId = data.id;
            this.restore = Math.random() * 10;

          } else {
            this.restore = Math.random() * 10;
            this.activeBugInfo = { id: data.id };
            this.preID = data.id
            this.count = 0;
            this.show = !this.show;
            this.taskId = data.id

          }

        }
      },
      HandleSide(e) {
        if (this.show) {
          this.show = false;
          this.count = 0;
          this.restore = Math.random() * 10;
          // this.$refs.side.style.right = -51 + '%';
        }
      },
      getSprintNameList() {
        $http.get($http.api.sprint.list_sprint_name, { projectId: this.urlParam.projectId }).then(res => {
          if (res.status == 200) {
            this.sprintNameList = res.data;
          } else {
            this.$message({ message: '获取迭代名称失败', type: 'error' });
          }
        })
      },
      getRequireTaskInfo(param) {
        $http.get($http.api.sprint.task_info, { sprintId: this.urlParam.sprintId, isShowDefect: 1, ...param }).then(res => {
          if (res.status == 200) {
            this.requireAndTaskInfo = res.data.tree;
          } else {
            this.$message({ message: '获取迭代名称失败', type: 'error' });
          }
        })
      },
      getSprintInfo() {
        $http.get($http.api.sprint.info, { sprintId: this.urlParam.sprintId }).then(res => {
          if (res.status == 200) {
            this.sprintInfo = res.data;
          } else {
            this.$message({ message: '获取迭代名称失败', type: 'error' });
          }
        })
      },
      searchRequireTaskInfo(param) {
        $http.get($http.api.sprint.search_task, {...this.formInline, ...param}).then(res => {
          if (res.status == 200) {
            this.searchRequireAndTaskInfo = res.data;
          } else {
            this.$message({ message: res.msg||'搜索需求/任务失败', type: 'error' });
          }
        })
      },
      addIntoSprint() {
        this.selectedWorkItemData = [];
        //筛选出的list

        let selectData = this.$refs['myTree'].getMultipleSelectData();

        selectData.forEach((item, index) => {
          this.selectedWorkItemData.push({
            sprintId: this.urlParam.sprintId,
            workItemId: item.data.id,
            workItemType: item.data.workItemType
          });
        });

        $http.post($http.api.sprint.add_task, this.selectedWorkItemData).then(res => {
          if (res.status == 200) {
            this.getSprintInfo();
            this.getRequireTaskInfo();
            this.searchRequireTaskInfo();
            this.$message({ message: res.msg||'操作成功', type: 'success' });
          } else {
            this.$message({ message: res.msg||'搜索需求/任务失败', type: 'error' });
          }
        })
      },
      deleteFromSprint(item) {
        this.deleteWorkItemData = [];
        this.deleteWorkItemData.push({
          sprintId: this.urlParam.sprintId,
          workItemId: item.data.id,
          workItemType: item.data.workItemType
        });

        $http.post($http.api.sprint.delete_task, this.deleteWorkItemData).then(res => {
          if (res.status == 200) {
            this.getSprintInfo();
            this.getRequireTaskInfo();
            this.searchRequireTaskInfo();
            this.$message({ message: res.msg||'操作成功', type: 'success' });
          } else {
            this.$message({ message: res.msg||'搜索需求/任务失败', type: 'error' });
          }
        })
      },
      deleteable(row) {
        if (row.data.sprintId == this.getUrlParams().sprintId) {
          if (row.data.workItemType == 1) {
            if (row.data.sprintId != 0) {
              return true;
            }
          } else {
            return true;
          }
        }
        return false;
      },

      returnBnt() {
        this.goToPage(this, "sprintList", { projectId: this.getUrlParams().projectId });
      }

    },
  }

</script>
<style lang="scss" scoped>
  .review-treetable-all {
    width: calc(50% - 25px);
    min-height: 300px;
    display: inline-block;
    vertical-align: top;
  }


  .review-treetable-center {
    width: 42px;
    min-height: 300px;
    display: inline-block;
    vertical-align: top;

    .Shuttle {
      margin-left: 10px;
      margin-top: 100px;
      color: #000;
      font-size: 22px;
      cursor: pointer;
      font-weight: 900
    }
  }


  .sprint {
    font-size: 16px;
    color: #000;
    font-weight: 900;
  }

  .sprintDetail {
    margin-top: 0px;
    margin-bottom: 10px;
    padding-top: 12px;
  }

  .demand,
  .task,
  .datetime,
  .bug {
    margin-left: 20px;
  }
</style>
