<template>
  <!-- <div id="sprintDetail" class="content-outer-box" :style="{minHeight:screenHeight}" @click="HandleSide"> -->
  <div
    id="sprintDetail"
    class="content-outer-box"
    v-loading="sprintDetailLoading"
    element-loading-text="拼命加载中"
    element-loading-spinner="el-icon-loading"
    element-loading-background="rgba(255,255,255, 0.5)"
  >
    <slide
      :show="show"
      @click.stop
      ref="side"
      :afterClose="HandleSide"
      v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgb(255,255,255)"
    >
      <div slot="task" class="silder-box">
        <!-- <div class="taskinfo-title">编辑任务信息</div>
        <div class="line-border"></div>-->
        <task-edit
          :taskId="taskId"
          :show="show"
          :restore="restore"
          v-on:HandleSide="HandleSide"
          :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc"
          v-if="workType===1"
        ></task-edit>
        <!-- <task-edit :taskId="taskId" :projectId="projectId" :show="show" :restore="restore" ></task-edit> -->
        <bug-detail
          :detailType="detailType"
          :projectId="bugProjectId"
          :activeBugInfo="activeBugInfo"
          @detailClose="HandleSide"
          :isSlider="true"
          :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc"
          v-else-if="workType===2"
        ></bug-detail>

        <demand-view
          :requireId="taskId"
          :show="show"
          :restore="restore"
          v-on:HandleSide="HandleSide"
          :titleNotice.sync="sliderBeforeCloseData.title"
          :descNotice.sync="sliderBeforeCloseData.desc"
          v-else-if="workType===3"
        ></demand-view>
      </div>
    </slide>
    <div class="x-arD content-box review-center">
      <div class="content">
        <div>
          <span class="font-desgin">{{sprintInfo.name}}</span>
          <i v-if="sprintInfo.isLocked == 1" class="iconfont icon-lock"></i>
          <el-button
            type="primary"
            style="margin-left:180px;"
            @click="planSprint"
            v-if="sprintInfo.status != 2"
            v-show="authFunction('PROJ_SPRINT_ADD_TASK', 3, projectId)"
          >规划迭代</el-button>

          <el-button
            type="primary"
            @click="lockSprint(sprintInfo.id)"
            v-if="sprintInfo.status != 2 && sprintInfo.isLocked == 0"
            v-show="authFunction('FUNC_COOP_SPRINT_LOCK', 3, projectId)"
          >锁定迭代</el-button>
          <el-button
            type="primary"
            @click="unLockSprint(sprintInfo.id)"
            v-if="sprintInfo.status != 2 && sprintInfo.isLocked == 1"
            v-show="authFunction('FUNC_COOP_SPRINT_UNLOCK', 3, projectId)"
          >解锁迭代</el-button>

          <el-button
            type="primary"
            @click="stopSprint()"
            v-if="sprintInfo.status != 2"
            v-show="authFunction('PROJ_SPRINT_STOP', 3, projectId)"
          >归档迭代</el-button>
        </div>
        <sprint-info :sprintInfo="sprintInfo" @dateUpdate="getSprintInfo" @templateUpdate="getSprintInfo"></sprint-info>
      </div>
      <!-- <div class="control">
        <el-radio-group
          class="mt10"
          text-color="#ffffff"
          fill="#409EFF"
          size="small "
          v-model="changeStatus"
          @change="changHandleTask()"
        >
          <el-radio-button label="0">需求与任务</el-radio-button>
          <el-radio-button label="3">缺陷</el-radio-button>
          <el-radio-button label="1">成员视图</el-radio-button>
          <el-radio-button label="2">进度图</el-radio-button>
          <el-radio-button label="code">代码统计</el-radio-button>
          <el-radio-button label="sprint">迭代跟踪日志</el-radio-button>
        </el-radio-group>
      </div> -->
      <el-tabs v-model="changeStatus" @tab-click="changHandleTask" class="footer-tab" type="border-card">
        <el-tab-pane label="需求与任务" name="0">
          <div>
            <div>
              <el-checkbox-group class="fl" v-model="checkList" @change="selectChange">
                <el-checkbox label="需求">
                  <i class="iconfont icon-requirement f13"></i>需求
                </el-checkbox>
                <el-checkbox label="任务" class="ml15">
                  <i class="iconfont icon-task f15"></i>任务
                </el-checkbox>
              </el-checkbox-group>
              <el-button class="fr mb10" 
                v-show="authFunction('FUNC_COOP_TASK_EXPORT', 3, getUrlParams().projectId)&&authFunction('FUNC_COOP_REQT_EXPORT', 3, getUrlParams().projectId)" 
                type="primary" @click="exportExcel">导出需求和任务</el-button>
            </div>
            <div class="treetable">
              <sprint-table-gantt
                :treeData="requireTaskData"
                :seeTaskHandle="seeTaskHandle"
                :HandleSide="HandleSide"
                :sortaChangeCallBack="(prop)=>{sortaChangeCallBack(prop, true)}"
                :getBaseList="getRequireTaskInfo"
                :showGantt="true"
                :dateList="dateList"
              ></sprint-table-gantt>
            </div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="缺陷" name="3">
          <el-table
            :data="defectData"
            border
            style="width: 100%"
            @sort-change="sortaChangeCallBack"
          >
            <el-table-column label="ID" show-overflow-tooltip width="70">
              <template slot-scope="scope">
                <span class="cp c-blue" @click="seeTaskHandle(scope.row,$event,1)">{{scope.row.id}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="display.title" label="标题" show-overflow-tooltip min-width="160">
              <template slot-scope="scope">
                <global-input
                  :initValue="scope.row.display.title"
                  :onChange="(value)=>{GlobalBugUpdate({title: value, id: scope.row.id, projectId: scope.row.projectId, cb: getDefectlist})}"
                >
                  <span
                    class="cp c-blue-hover"
                    @click="seeTaskHandle(scope.row,$event,1)"
                    slot
                  >{{scope.row.display.title}}</span>
                </global-input>
              </template>
            </el-table-column>
            <el-table-column
              prop="priority"
              sortable="custom"
              label="严重程度"
              show-overflow-tooltip
              width="100"
            >
              <template slot-scope="scope">
                <span
                  class="cursor-pointer"
                  @click.stop="(e) => GlobalSelectTargetClickForBug(scope.row, e, 'priority')"
                >
                  <span
                    v-html="initNameStatus(scope.row.display.detail.priority.color,scope.row.display.detail.priority.literal)"
                  ></span>
                </span>
              </template>
            </el-table-column>
            <el-table-column
              prop="statusId"
              sortable="custom"
              label="状态"
              show-overflow-tooltip
              width="120"
            >
              <template slot-scope="scope">
                <span
                  class="cursor-pointer"
                  v-html="initNameStatus(scope.row.display.detail.status.color,scope.row.display.status)"
                  @click.stop="(e) => GlobalSelectTargetClickForBug(scope.row, e, 'statusId')"
                >{{scope.row.display.status}}</span>
              </template>
            </el-table-column>
            <el-table-column
              label="处理人"
              prop="assignUser"
              sortable="custom"
              show-overflow-tooltip
              width="160"
            >
              <template slot-scope="scope">
                <span
                  class="cursor-pointer"
                  @click.stop="(e) => GlobalSelectTargetClickForBug(scope.row, e, 'assignUser')"
                >
                  {{scope.row.display.assignUser}}
                  ({{scope.row.assignUser}})
                </span>
              </template>
            </el-table-column>
            <el-table-column
              label="创建人"
              prop="createUser"
              sortable="custom"
              show-overflow-tooltip
              width="160"
            >
              <template
                slot-scope="scope"
              >{{scope.row.display.createUser}} ({{scope.row.createUser}})</template>
            </el-table-column>
            <el-table-column
              prop="createTime"
              sortable="custom"
              label="创建时间"
              show-overflow-tooltip
              width="160"
            ></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="成员视图" name="1">
          <el-form>
            <el-checkbox-group
              v-model="userCheckList"
              @change="userSelectChange"
            >
              <el-checkbox label="需求">
                <i class="iconfont icon-requirement f13"></i>需求
              </el-checkbox>
              <el-checkbox label="任务" class="ml15">
                <i class="iconfont icon-task f15"></i>任务
              </el-checkbox>
              <el-checkbox label="缺陷" class="ml15">
                <i class="iconfont icon-bug f14"></i>缺陷
              </el-checkbox>
            </el-checkbox-group>
          </el-form>
          <div class v-for="(row,index) in userTaskData" :key="index">
            <div>
              <h3 class="user-name">{{row.userName}}({{row.userId}})</h3>
            </div>
            <sprint-table-gantt
              :treeData="row.dataList"
              :seeTaskHandle="seeTaskHandle"
              :HandleSide="HandleSide"
              :sortaChangeCallBack="sortaChangeCallBack"
              :getBaseList="getUserTaskInfo"
            ></sprint-table-gantt>
          </div>
        </el-tab-pane>
        <el-tab-pane label="进度图" name="2">
          <div style="width: 50%; float:left">
            <div id="requieStatusChart" :style="{width: '100%', height: '300px'}"></div>
            <div id="taskStatusChart" :style="{width: '100%', height: '300px'}"></div>
          </div>
          <div style="width: 50%; float:right">
            <div id="reqNumBurnDownChart" :style="{width: '100%', height: '300px'}"></div>
            <div id="taskHourBurnDownChart" :style="{width: '100%', height: '300px'}"></div>
            <div id="taskNumBurnDownChart" :style="{width: '100%', height: '300px'}"></div>
          </div>
        </el-tab-pane>
        <el-tab-pane label="代码统计" name="code">
          <code-statistics v-if="changeStatus === 'code'"></code-statistics>
        </el-tab-pane>
        <el-tab-pane label="迭代跟踪日志" name="sprint">
          <sprint-log v-if="changeStatus === 'sprint'"></sprint-log>
        </el-tab-pane>
      </el-tabs>
    </div>
    <GlobalSelect v-bind="GlobalSelectProps"></GlobalSelect>
    <!-- 二级状态选择、添加评论 -->
    <comment-for-status v-bind="CommentForStatusInfo"></comment-for-status>
    <back-top></back-top>
  </div>
</template>

<script>
import treeTable from "@/components/tool/TreeTable";
import slide from "components/tool/slideSlip";
// import taskEdit from 'components/project/task/taskEdit.vue'
import taskEdit from "components/project/task/taskDetail.vue";
import bugDetail from "components/project/bugManagement/BugDetail.vue";
import demandView from "components/project/requirement/requirementView.vue";
import SprintTableGantt from "./SprintTableGantt";
import GlobalSelect from "../../tool/FieldEdit/GlobalSelect.vue";
import GlobalInput from "../../tool/FieldEdit/GlobalInput.vue";
import ProjectCommonMixin from "@/components/project/ProjectCommonMixin";
import CommentForStatus from '@/components/project/bugManagement/CommentForStatus.vue'
import SprintInfo from "./SprintInfo";
import CodeStatistics from './CodeStatistics.vue'
import SprintLog from './SprintLog.vue'
import StringView from '@/components/commonComponents/StringView'
var echarts = require("echarts");

const BUGLIST = "bugList";
const REQUIREMENT = "requirementList";

export default {
  components: {
    treeTable,
    taskEdit,
    slide,
    bugDetail,
    demandView,
    GlobalSelect,
    GlobalInput,
    SprintTableGantt,
    SprintInfo,
    CommentForStatus,
    CodeStatistics,
    SprintLog,
  },
  name: "sprintDetail",
  mixins: [ProjectCommonMixin],
  data() {
    return {
      CommentForStatusInfo: {
        isShow: false,
        statusInfo: {},
        onOk: this.bugStatusClickCallbackOnOk,
        onCancel: this.bugStatusClickCallbackOnCancel
      },
      workType: null,
      detailType: "show",
      activeBugInfo: {},
      defectData: [], //缺陷列表数据
      bugProjectId: null,
      sprintId: "",
      projectId: "",
      expandAll: true,
      changeStatus: "0",
      radio3: "1",
      checkList: ["需求", "任务"],
      isShowRequire: 1,

      isShowDefect: 1,
      sprintInfo: {
        status: "",
        name: "",
        process: 0,
        startTime: "",
        endTime: "",
        completeRequires: 0,
        completeInTimeRequires: 0,
        completeDelayRequires: 0,
        totalRequires: 0,
        completeTasks: 0,
        completeInTimeTasks: 0,
        completeDelayTasks: 0,
        totalTasks: 0,
        totalTaskHours: 0,
        completeTaskHours: 0
      },
      requireTaskData: [],
      dateList: [],

      userTaskData: [],
      userCheckList: ["需求", "任务", "缺陷"],
      userIsShowRequire: 1,
      userIsShowTask: 1,
      isShowTask: 1, // 兼容设置，兼容之前的前端代码，保证所有数据初始化在 data 对象内部 - add by heyunjiang
      userIsShowDefect: 1,
      jumpPage: "sprintUserTask",

      requireStatusDistributeChartData: {
        reqXAxis: [],
        reqYAxis: []
      },
      taskStatusDistributeChartData: {
        taskXAxis: [],
        taskYAxis: []
      },
      taskHourBurnDownChartData: {
        xAxis: [],
        taskY1Axis: [],
        taskY2Axis: []
      },
      taskNumBurnDownChartData: {
        xAxis: [],
        taskNumY1Axis: [],
        taskNumY2Axis: []
      },
      reqNumBurnDownChartData: {
        xAxis: [],
        reqY1Axis: [],
        reqY2Axis: []
      },
      count: 0,
      restore: 1,
      preID: null,
      show: false,
      taskId: null,
      loading: false,
      sprintDetailLoading: false,
      screenHeight: null
    };
  },
  watch: {
    show: function (newName, oldName) {
      if (newName !== true) {
        if (this.changeStatus === "0") {
          this.getRequireTaskInfo();
        } else if (this.changeStatus === "1") {
          this.getUserTaskInfo();
        } else if (this.changeStatus === "3") {
          this.getDefectlist();
        }
      }
    }
  },
  mounted() {
    this.sprintId = this.getUrlParams().sprintId;
    this.projectId = this.getUrlParams().projectId;

    this.getSprintInfo();
    this.screenHeight = window.screen.availHeight - 195 + "px";
    this.getRequireTaskInfo();

  },
  beforeRouteLeave(to, from, next) {
    // 如果存在内容在编辑，则不能离开
    if (this.sliderBeforeCloseData.title || this.sliderBeforeCloseData.desc) {
      return false;
    }
    next()
  },
  methods: {
    encodeString(str) {
      return encodeURIComponent(new StringView(str).toBase64());
    },
    //导出甘特图
    exportExcel() {
      let param = {
        orderList: this.param,
        sprintId: this.sprintId,
        isShowRequire: this.isShowRequire,
        isShowTask: this.isShowTask,
        isShowDefect: 0,
      }
      this.fileDownLoadForGet( $http.api.sprint.excel_export.url, param, { projectId:this.projectId })
    },
    //锁定迭代和解绑迭代的方法
    isLockSprint(id, val) {
      if (val) {
        this.unLockSprint(id)
      } else {
        this.lockSprint(id)
      }
    },
    //锁定迭代
    lockSprint(id) {
      this.$confirm("确定锁定该迭代吗？").then(() => {
        $http.post($http.api.sprint.sprint_lock, { sprintId: id }, { type: 'form' }).then(res => {
          if (res.msg == '需要执行强制锁定') {
            this.$confirm("迭代每个阶段的计划日期尚没有完全确定，是否强制锁定迭代?", "提示", {
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
            }).then(() => {
              this.forceLockSpring(id)
            })
          } else {
            this.$message({ message: res.msg || "操作成功", type: "success" });
            this.getSprintInfo()
          }
        }).catch(e => {
        })
      });
    },
    //解锁迭代
    unLockSprint(id) {
      this.$confirm("确定解锁该迭代吗？").then(() => {
        $http.post($http.api.sprint.sprint_unlock, { sprintId: id }, { type: 'form' }).then(res => {
          if (res.status === 200) {
            this.$message({ message: res.msg || "操作成功", type: "success" });
            this.getSprintInfo()
          } else {
            this.$message({ message: res.msg || "操作失败", type: "error" });
          }
        });
      })
    },
    //强制锁定
    forceLockSpring(id) {
      $http.post($http.api.sprint.sprint_force_lock, { sprintId: id }, { type: 'form' }).then(res => {
        if (res.status === 200) {
          this.$message({ message: res.msg || "操作成功", type: "success" });
          this.getSprintInfo()
        } else {
          this.$message({ message: res.msg || "操作失败", type: "error" });
        }
      });
    },
    // 更新缺陷 - 状态变化 - 添加二级状态及评论
    bugStatusClickCallback(info, cb) {
      // 如果不需要评论
      if (!info.toComment && (!info.children || info.children.length === 0)) {
        this.GlobalBugUpdate({
          [info.updateName]: info.key,
          cb: this.getDefectlist
        })
        cb(true)
      } else {
        // 如果需要评论，只要 toComment 为 true ，或者 children.length > 0
        this.CommentForStatusInfo = {
          isShow: true,
          statusInfo: { ...info },
          onOk: (value) => {
            this.bugStatusClickCallbackOnOk(value, cb)
          },
          onCancel: () => {
            this.bugStatusClickCallbackOnCancel(cb)
          }
        }
      }
    },
    // 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击确定
    bugStatusClickCallbackOnOk(value, cb) {
      this.CommentForStatusInfo.isShow = false
      let comment = value.comment.trim()
      if (value.statu !== null) {
        if (comment.length > 0) {
          this.GlobalBugUpdate({
            'statusId': value.statu,
            comment,
            cb: this.getDefectlist
          })
        } else {
          this.GlobalBugUpdate({
            'statusId': value.statu,
            cb: this.getDefectlist
          })
        }
      } else if (comment.length > 0) {
        this.GlobalBugUpdate({
          comment,
          statusId: value.statusId,
          cb: this.getDefectlist
        })
      }
      cb(true)
    },
    // 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击取消
    bugStatusClickCallbackOnCancel(cb) {
      this.CommentForStatusInfo.isShow = false
      cb(true)
    },
    // 全局更新缺陷 - 迭代 - add by heyunjiang on 2019.5.7
    GlobalSelectTargetClickForBug(info, e, type) {
      info = { ...info, workItemType: 3 };
      this.GlobalSelectTargetClick(info, e, type, this.getDefectlist);
    },
    // 排序变化 - add by heyunjiang on 2019.5.7
    sortaChangeCallBack(obj, isPost = false) {
      let func = this.getRequireTaskInfo,
        param = {};
      switch (this.changeStatus) {
        case "0":
          func = this.getRequireTaskInfo;
          break;
        case "1":
          func = this.getUserTaskInfo;
          break;
        case "3":
          func = this.getDefectlist;
          break;
      }
      if (obj.prop) {
        param = {
          column: obj.prop,
          order: obj.order === "descending" ? "DESC" : "ASC"
        };
        // 如果是 post 方式提交
        if (isPost) {
          param = {
            orderList: [param]
          }
        }
      }
      this.param = param;
      func(param);
    },
    //查看任务
    seeTaskHandle(data, e, num) {
      if (data.workItemType == 2) {
        this.workType = 1;
      } else if (data.workItemType == 3 || num == 1) {
        this.workType = 2;
        this.bugProjectId = data.projectId;
      } else {
        this.workType = 3;
      }
      // this.goToPage(this, "taskEdit", {projectId: this.urlParam.projectId, taskId: id});
      if (e && e.stopPropagation) {
        //非IE浏览器
        e.stopPropagation();
      } else {
        //IE浏览器
        window.event.cancelBubble = true;
      }
      this.$nextTick(() => {
        this.loading = true;
        setTimeout(() => {
          this.loading = false;
        }, 500);
      });

      // let projectId = this.getUrlParams().projectId
      // this.goToNewWindowPage(this, "taskEdit", { taskId: data.id, projectId })

      if (this.count === 0) {
        this.preID = data.id;
        this.show = !this.show;
        this.taskId = data.id;
        this.activeBugInfo = { id: data.id };
        this.restore = Math.random() * 10;
        this.count++;
      } else {
        if (this.preID !== data.id) {
          this.preID = data.id;

          this.activeBugInfo = { id: data.id };
          // this.show = !this.show;
          this.taskId = data.id;
          this.restore = Math.random() * 10;
        } else {
          this.restore = Math.random() * 10;
          this.preID = data.id;
          this.activeBugInfo = { id: data.id };
          this.count = 0;
          this.show = !this.show;
          this.taskId = data.id;
        }
      }
    },
    HandleSide(e) {
      if (this.show) {
        this.show = false;
        this.count = 0;
        this.restore = Math.random() * 10;
        // this.$refs.side.style.right = -51 + '%';
      }
    },
    selectChange(checkedList) {
      this.isShowRequire = 0;
      this.isShowTask = 0;
      checkedList.forEach(checked => {
        if (checked == "需求") {
          this.isShowRequire = 1;
        } else if (checked == "任务") {
          this.isShowTask = 1;
        }
      });

      this.getRequireTaskInfo();
    },
    userSelectChange(checkedList) {
      this.userIsShowRequire = 0;
      this.userIsShowTask = 0;
      this.userIsShowDefect = 0;
      checkedList.forEach(checked => {
        if (checked == "需求") {
          this.userIsShowRequire = 1;
        } else if (checked == "任务") {
          this.userIsShowTask = 1;
        } else if (checked == "缺陷") {
          this.userIsShowDefect = 1;
        }
      });

      this.getUserTaskInfo();
    },
    getSprintInfo() {
      let params = {
        sprintId: this.sprintId
      };
      $http.get($http.api.sprint.info, params).then(res => {
        this.sprintInfo = res.data;
      });
    },
    getDefectlist(obj = {}) {
      let params = {
        sprintId: this.sprintId,
        ...obj
      };
      $http.get($http.api.sprint.defect_list, params).then(res => {
        this.defectData = res.data;
      });
    },
    getRequireTaskInfo(obj = {
      orderList: [{
        column: "assignUser",
        order: "DESC"
      }]
    }) {
      let params = {
        sprintId: this.sprintId,
        isShowRequire: this.isShowRequire,
        isShowTask: this.isShowTask,
        isShowDefect: 0,
        ...obj
      };
      this.sprintDetailLoading = true;
      $http.post($http.api.sprint.task_info, params).then(res => {
        // $http.get($http.api.sprint.task_info, params).then(res => {
        this.sprintDetailLoading = false;
        this.$nextTick(() => {
          this.requireTaskData = res.data.tree;
          this.dateList = res.data.dateList;
        });
      });
    },
    getUserTaskInfo(obj = {}) {
      let params = {
        sprintId: this.sprintId,
        isShowRequire: this.userIsShowRequire,
        isShowTask: this.userIsShowTask,
        isShowDefect: this.userIsShowDefect,
        ...obj
      };
      $http.get($http.api.sprint.user_task, params).then(res => {
        this.userTaskData = [];
        this.userTaskData = res.data;
      });
    },
    getStatusDistributeInfo() {
      let params = {
        projectId: this.projectId,
        sprintId: this.sprintId
      };
      $http.get($http.api.sprint.status_distribute, params).then(res => {
        this.requireStatusDistributeChartData.reqXAxis = res.data.reqXAxis;
        this.requireStatusDistributeChartData.reqYAxis = res.data.reqYAxis;

        this.taskStatusDistributeChartData.taskXAxis = res.data.taskXAxis;
        this.taskStatusDistributeChartData.taskYAxis = res.data.taskYAxis;

        this.drawRequieStatusChart();
        this.drawTaskStatusChart();
      });
    },
    getBurnDownInfo() {
      let params = {
        projectId: this.projectId,
        sprintId: this.sprintId
      };
      $http.get($http.api.sprint.burn_down, params).then(res => {
        this.taskHourBurnDownChartData.xAxis = res.data.xaxis;
        this.taskNumBurnDownChartData.xAxis = res.data.xaxis;
        this.reqNumBurnDownChartData.xAxis = res.data.xaxis;
        this.reqNumBurnDownChartData.reqY1Axis = res.data.reqY1Axis;
        this.reqNumBurnDownChartData.reqY2Axis = res.data.reqY2Axis;
        this.taskHourBurnDownChartData.taskY1Axis = res.data.taskY1Axis;
        this.taskHourBurnDownChartData.taskY2Axis = res.data.taskY2Axis;
        this.taskNumBurnDownChartData.taskNumY1Axis = res.data.taskNumY1Axis;
        this.taskNumBurnDownChartData.taskNumY2Axis = res.data.taskNumY2Axis;

        this.drawBurnDownChart();
      });
    },
    stopSprint() {
      this.$confirm("确认归档迭代[" + this.sprintInfo.name + "]吗？")
        .then(_ => {
          $http
            .post(
              $http.api.sprint.stop_sprint,
              { sprintId: this.sprintId },
              { type: "form" }
            )
            .then(res => {
              this.$message({ message: res.msg || "操作成功", type: "success" });
              window.location.reload();
            });
        })
        .catch(_ => {
        });
    },
    planSprint() {
      this.goToPage(this, "sprintPlan", {
        projectId: this.getUrlParams().projectId,
        sprintId: this.sprintId
      });
    },
    changHandleTask() {
      if (this.changeStatus == "0") {
        this.getRequireTaskInfo();
      } else if (this.changeStatus == "1") {
        this.getUserTaskInfo();
      } else if (this.changeStatus == "2") {
        this.getStatusDistributeInfo();
        this.getBurnDownInfo();
      } else if (this.changeStatus == "3") {
        this.getDefectlist();
      } else if (this.changeStatus == 'code') {

      }
    },
    drawBurnDownChart() {
      let taskHourBurnDownChart = echarts.init(
        document.getElementById("taskHourBurnDownChart")
      );
      taskHourBurnDownChart.setOption({
        title: {
          text: "任务工时燃尽图",
          left: "center"
        },
        tooltip: {
          trigger: "axis",
          formatter: "{a} <br/>{b} : {c}"
        },
        xAxis: {
          type: "category",
          // name: 'x',
          boundaryGap: false,
          splitLine: { show: false },
          data: this.taskHourBurnDownChartData.xAxis
        },
        yAxis: {},
        legend: {
          left: "center",
          top: "30",
          data: ["未完成任务工时", "任务工时基准线"]
        },
        series: [
          {
            name: "未完成任务工时",
            type: "line",
            itemStyle: {
              normal: { areaStyle: { type: 'default' }, color: 'rgba(144,197,237,0.8)' }
            },
            data: this.taskHourBurnDownChartData.taskY1Axis
          },

          {
            name: "任务工时基准线",
            type: "line",
            lineStyle: {
              color: 'gray'
            },
            itemStyle: {
              normal: { label: { show: false } }
            },
            data: this.taskHourBurnDownChartData.taskY2Axis
          }
        ]
      });

      let taskNumBurnDownChart = echarts.init(
        document.getElementById("taskNumBurnDownChart")
      );
      taskNumBurnDownChart.setOption({
        title: {
          text: "任务数量燃尽图",
          left: "center"
        },
        tooltip: {
          trigger: "axis",
          //formatter: "{a} <br/>{b} : {c}"
        },
        xAxis: {
          type: "category",
          // name: 'x',
          boundaryGap: false,
          splitLine: { show: false },
          data: this.taskNumBurnDownChartData.xAxis
        },
        yAxis: {},
        legend: {
          left: "center",
          top: "30",
          data: ["未完成任务数量", "任务数量基准线"]
        },
        series: [
          {
            name: "未完成任务数量",
            type: "line",
            itemStyle: {
              normal: { areaStyle: { type: 'default' }, color: 'rgba(144,197,237,0.8)' }
            },
            data: this.taskNumBurnDownChartData.taskNumY1Axis
          },

          {
            name: "任务数量基准线",
            type: "line",
            lineStyle: {
              color: 'gray'
            },
            itemStyle: {
              normal: { label: { show: false } }
            },
            data: this.taskNumBurnDownChartData.taskNumY2Axis
          }
        ]
      });

      let reqNumBurnDownChart = echarts.init(
        document.getElementById("reqNumBurnDownChart")
      );
      reqNumBurnDownChart.setOption({
        title: {
          text: "需求数量燃尽图",
          left: "center"
        },
        tooltip: {
          trigger: "axis",
          formatter: "{a} <br/>{b} : {c}"
        },
        xAxis: {
          type: "category",
          // name: 'x',
          boundaryGap: false,
          splitLine: { show: false },
          data: this.reqNumBurnDownChartData.xAxis
        },
        yAxis: {},
        legend: {
          left: "center",
          top: "30",
          data: ["未完成需求数量", "需求数量基准线"]
        },
        series: [
          {
            name: "未完成需求数量",
            type: "line",
            data: this.reqNumBurnDownChartData.reqY1Axis,
            itemStyle: {
              normal: { areaStyle: { type: 'default' }, color: 'rgba(144,197,237,0.8)' }
            },
          },

          {
            name: "需求数量基准线",
            type: "line",
            lineStyle: {
              color: 'gray'
            },
            itemStyle: {
              normal: { label: { show: false } }
            },
            data: this.reqNumBurnDownChartData.reqY2Axis
          }
        ]
      });
    },
    drawRequieStatusChart() {
      // 基于准备好的dom，初始化echarts实例
      let requieStatusChart = echarts.init(
        document.getElementById("requieStatusChart")
      );
      // 绘制图表
      requieStatusChart.setOption({
        color: ["#3398DB"],
        title: {
          text: "需求状态分布图",
          left: "center"
        },
        legend: {
          left: "center",
          top: "30",
          data: ["需求"]
        },
        tooltip: {},
        xAxis: {
          data: this.requireStatusDistributeChartData.reqXAxis,
          axisLabel: {
            showMaxLabel: true,
            rotate: 40,
            interval: 0,
          },
        },
        yAxis: {},
        series: [
          {
            //name: '需求',
            type: "bar",
            barMaxWidth: 34,
            data: this.requireStatusDistributeChartData.reqYAxis,
            label: {
              normal: {
                show: false,
                position: "inside"
              }
            }
          }
        ]
      });
    },
    drawTaskStatusChart() {
      // 基于准备好的dom，初始化echarts实例
      let taskStatusChart = echarts.init(
        document.getElementById("taskStatusChart")
      );
      // 绘制图表
      taskStatusChart.setOption({
        color: ["#3398DB"],
        title: {
          text: "任务状态分布图",
          left: "center"
        },
        legend: {
          left: "center",
          top: "30",
          data: ["任务"]
        },
        tooltip: {},
        xAxis: {
          data: this.taskStatusDistributeChartData.taskXAxis,
          axisLabel: {
            showMaxLabel: true,
            rotate: 40,
            interval: 0,
          },
        },
        yAxis: {},
        series: [
          {
            //name: '任务',
            type: "bar",
            barMaxWidth: 34,
            data: this.taskStatusDistributeChartData.taskYAxis,
            label: {
              normal: {
                show: false,
                position: "inside"
              }
            }
          }
        ]
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.footer-tab {
  margin-top: 20px;
}
.circle-user {
  width: 50px;
  height: 50px;
  border: 1px solid #ccc;
  border-radius: 100%;
}

.f13 {
  font-size: 13px;
}

.f14 {
  font-size: 14px;
}

.f15 {
  font-size: 15px;
}

.content {
  /*width: 70%;*/
  width: 100%;
  margin-top: 10px;
}

.control {
  /*margin-left: 26px;*/
  margin-top: 20px;
}

.treetable {
  /* width: 1300px; */
  /*margin-left: 26px;*/
  // margin-top: 20px;
  // min-height: 900px;
}

.user-name {
  font-size: 16px;
  font-weight: 900;
}

.font-desgin {
  font-size: 14px;
  color: #333;
  font-weight: 700;
  /*margin-left: 30px;*/
}

.ml30 {
  margin-left: 30px;
}

.ml77 {
  margin-left: 77px;
}

.dialog {
  width: 600px;
  height: 300px;
}

.ml15 {
  margin-left: 15px;
}

.border {
  /* height: 1px;
    width: 100%;
    background-color: black; */
}
</style>

