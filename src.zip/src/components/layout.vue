<template>
  <div class="layOut">
    <div id="header">
      <h3 id="logo">哥伦布系统</h3>
      <el-menu class="el-menu-demo" background-color="#333744" active-text-color="#409EFF" text-color="#fff"
        mode="horizontal" @select='selectMenu' :default-active="headerDefaultActive">
        <el-menu-item index="mine" v-show="authMenu('MENU_SYS_MINE',0)">工作台</el-menu-item>
        <el-menu-item index="projectList" v-show="authMenu('MENU_SYS_PROJECT',0)">项目</el-menu-item>
        <el-menu-item index="bizList" v-show="authMenu('MENU_SYS_BIZS',0)">业务</el-menu-item>
        <el-menu-item index="metric">度量</el-menu-item>
        <el-menu-item index="manage" v-show="(authMenu('MENU_SYS_MANAGE',0))">管理</el-menu-item>
        <el-popover placement="top-start" trigger="click" visible-arrow="false">
          <template slot-scope="content">
            <div class="home-cotent" v-if="datalist && datalist.length != 0">
              <div class="product-right">
                <div class="content" v-for="(domain,index) in datalist">
                  <div class="mt10">
                    <span :class="domain.typeIcon"></span>
                    <span class="fontsize-content">{{domain.typeName}}</span>
                  </div>
                  <div style="margin-top: 20px;">
                    <ul class="product-ul">
                      <li class="product-li" :style="(index+1)%4==0?marginRight:''" v-for="(item,index) in domain.productResponseList">
                        <span class="span-div" @click="goToproductDetail(item.productUrl)">{{item.productName}}</span>
                      </li>
                      <div style="clear:both;"></div>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <span v-if="!datalist || datalist.length == 0" style="width: 100px;margin-left: 22px;font-size: 16px;">暂无文档信息!</span>
          </template>
          <a slot="reference" style="margin-right: 10px;margin-left: 8px;font-size: 14px;display: inline-block;" class="cp" @click="getDocInfo">使用文档</a>
        </el-popover>
      </el-menu>

      <div class="user-info">
        <el-dropdown size="large" trigger="click" @command="handleEventDropdown">
          <span class="el-dropdown-link">{{userData.userName}}<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown" style="margin-top:0px;">
            <el-dropdown-item command='logout'>退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>

      <el-popover placement="bottom" width="100%;" class="" trigger="hover" @show="getUnTreatedDeployNoteList">
        <div>
          <h4 style="margin-block-start: 0.33em;margin-block-end: 0.33em;">
            &nbsp;<span style="color: red;">
              {{totalUnTreatedDeployNoteCount}}
            </span>
            项待处理发布单
          </h4>
        </div>
        <hr>
        <span>
          <el-table :data="unTreatedDeployNoteList" size="small" :show-header="false">
            <el-table-column>
              <template slot-scope="scope">
                <span style="color: #4d9bff;cursor: pointer;width: 100%;" @click="toDeployList(scope.row)">
                  <span style="float: left; width:100px;overflow:hidden;text-overflow:ellipsis;white-space: nowrap"
                    :title="scope.row.bizName">{{scope.row.bizName}}</span>
                  <span
                    style="color:red;float: right;font-size: 16px;">{{(scope.row.unTreatedDeployNoteCount?scope.row.unTreatedDeployNoteCount:'0')}}</span>
                </span>
              </template>
            </el-table-column>
          </el-table>
        </span>
        <div class="btn-popver" slot="reference">
          <span class="user-alarm" :style="{'right':totalUnTreatedDeployNoteCount<=0?'145px':'170px'}">
            <div>
              <span class="icon-alarm iconfont fl" style="margin-left: 10px;"></span>
              <el-badge :value="totalUnTreatedDeployNoteCount" :max="99"
                style="color: red;float: right;margin-right:10px;margin-top: 4px;"
                :hidden="totalUnTreatedDeployNoteCount <= 0"></el-badge>
            </div>
          </span>
        </div>
      </el-popover>
      <div class="user-info btn-popver" v-show="isImpersonating()" style="width: 30px;margin-right: 0px;">
        <span class="el-icon-view" style="font-size: 22px;margin-top: 14px" @click="impersionateStop()" />
      </div>

    </div>
    <div class="page-body">
      <div id="sidebar" v-show="showSideBar">
        <el-menu class="el-menu-vertical-demo" background-color="#333744" text-color="rgb(255, 255, 255)"
          active-text-color="#409EFF" :default-active="sideBarDefaultActive" @select="handleSelect">
          <template v-for="(menu,index) in bizMenuList">
            <el-menu-item :index='menu.name' :key="index" :name='menu.name' v-show="menu.show" :class="menuWidth?'w156':''"
              v-if="!menu.hasSubMenu">
              <template slot="title">
                <i :class="menu.icon"></i><span v-if="isCollapse == false">&nbsp;&nbsp;&nbsp;{{menu.text}}</span>
              </template>
            </el-menu-item>
            <el-submenu :index="menu.name" :name='menu.name' :key="index" v-show="menu.show" v-if="menu.hasSubMenu"
              class="sub-menu-class">
              <template slot="title">
                <i :class="menu.icon"></i><span v-if="isCollapse == false">&nbsp;&nbsp;&nbsp;{{menu.text}}</span>
              </template>
              <el-menu-item :index='subMenu.name' :name='subMenu.name' v-for="(subMenu,subIndex) in menu.subMenus"
                :key="subIndex">
                <template slot="title">
                  <i :class="subMenu.icon"></i><span
                    v-if="isCollapse == false">&nbsp;&nbsp;&nbsp;{{subMenu.text}}</span>
                </template>
              </el-menu-item>
            </el-submenu>
          </template>
        </el-menu>
        <div class="arrowparent" v-if="showIcon===1">
          <el-button type="info" :icon="isCollapse ? 'el-icon-d-arrow-right arrowbtn' : 'el-icon-d-arrow-left arrowbtn'"
            @click="foldHandle()" circle></el-button>
        </div>
      </div>
      <div id="main-content"
        :style="showSideBar?{'width': siderBarWidth,'min-height':height_s,'-webkit-min-height':height_s}:{'width': '100%','min-height':height_s}">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'layOut',
    data() {
      return {
        userData: {},
        height_s: '',
        showIcon: 0,
        headerDefaultActive: '',
        sideBarDefaultActive: '',
        isCollapse: false,
        showSideBar: false,
        showGitlab: false,
        siderBarWidth: '80%',

        bizMenuList: [
          { text: '需求', name: 'requirementList', icon: 'iconfont icon-requirement', show: false },
          { text: '任务', name: 'taskView', icon: 'iconfont icon-task', show: false },
          { text: '缺陷', name: 'bugList', icon: 'iconfont icon-bug', show: false },
          { text: '迭代', name: 'sprintList', icon: 'iconfont icon-sprint', show: false },
          { text: "报表", name: 'bugChart', icon: 'iconfont icon-chart', show: false },
          { text: '文档', name: 'fileInfo', icon: 'iconfont icon-folder', show: false },
          // { text: '文档', name: 'fileList', icon: 'iconfont icon-requirement', show: false },
          { text: "设置", name: 'personalManagementList', icon: 'iconfont icon-settings', show: false },
          { text: '应用', name: 'appList', icon: 'iconfont icon-app', show: false },
          { text: '发布', name: 'deployNote', icon: 'iconfont icon-deploy', show: false },
          { text: '业务设置', name: 'bizSetting', icon: 'iconfont icon-settings', show: false },
          { text: 'GitLab账号注册', name: 'gitLabRegister', icon: 'iconfont icon-gitlab', show: false },
          { text: '绑定CMDB', name: 'manageCmdb', icon: 'iconfont icon-machine', show: false },
          { text: '人员管理', name: 'memberManage', icon: 'iconfont icon-user', show: false },
          { text: '角色管理', name: 'roleManage', icon: 'iconfont icon-role', show: false },
          { text: '权限管理', name: 'authSetManage', icon: 'iconfont icon-task', show: false },
          { text: '菜单管理', name: 'menuManage', icon: 'iconfont icon-menu', show: false },
          { text: '功能管理', name: 'functionManage', icon: 'iconfont icon-func', show: false },
          {
            text: 'Sonar管理', name: 'sonarTaskManage', icon: 'iconfont icon-sonarqube', show: false, hasSubMenu: true,
            subMenus: [
              { text: '任务管理', name: 'sonarTaskManage', icon: 'iconfont icon-sonartask', show: false },
              { text: '系统管理', name: 'sonarSystemManage', icon: 'iconfont icon-sonarsystem', show: false },
            ]
          },
          {text: '镜像管理', name: 'imageManage',icon: 'iconfont icon-fullscreen2', show: false},
          {text: '应用管理', name: 'appManage',icon: 'iconfont icon-chart', show: false},
        ],

        totalUnTreatedDeployNoteCount: 0,
        unTreatedDeployNoteList: [],
        menuWidth: false,

        /**/
        iconlist: ['el-icon-rank', 'el-icon-refresh', 'el-icon-share', 'el-icon-upload', 'el-icon-warning', 'el-icon-success', 'el-icon-question'],
        datalist: [],
        marginRight: 'margin-right: 0px',
        typeNameList: [],
        topPx: 'position: relative;',
        typeIndex: 0,
      }
    },
    mounted() {
      // this.getDocInfo()
      this.renderSubMenu()
      this.height_s = (document.body.offsetHeight - 50) + 'px';
      let height = document.getElementById('main-content').offsetHeight
      document.getElementById('sidebar').style.height = height;
      this.userData = $utils.getStorage(GLOBAL_CONST.USER_INFO);
      $utils.getUserInfo();
      this.getUnTreatedDeployNoteList();
      window.removeEventListener('resize', this.siderBarWidthSetting);
      window.addEventListener('resize', this.siderBarWidthSetting);
    },
    destroyed() {
      window.removeEventListener('resize', this.siderBarWidthSetting);
    },
    watch: {
      '$route'(to, from) {
        this.renderSubMenu();
        if(this.$route.meta.parent) {
          switch (this.$route.meta.parent) {
            case 'bizList':
            case 'deployNote':
            case 'appList':
            case 'apiList':
            case 'bizSetting':
            case 'manage': this.showIcon = 1; this.menuWidth = false; break;
            default: this.showIcon = 0;this.isCollapse = false;
          }
        }
        this.$nextTick(this.siderBarWidthSetting);
      },
      // 动态设置右侧内容宽度
      showSideBar(value) {
        if(value) {
          setTimeout(this.siderBarWidthSetting)
        }
      },
      // 动态设置右侧内容宽度
      isCollapse() {
        this.$nextTick(this.siderBarWidthSetting)
      }
    },
    computed: {},
    methods: {
      // 设置右侧内容宽度 - add by heyunjiang on 2019.6.26
      siderBarWidthSetting() {
        const sideBar = document.getElementById('sidebar');
        if(sideBar) {
          this.siderBarWidth = 'calc(100% - '+ sideBar.getBoundingClientRect().width +'px)';
        }
      },
      goToproductDetail(url) {
        window.open(url)
      },

      getDocInfo() {
        $http.get($http.api.other.get_doc_info).then((res) => {
          this.datalist = res.data
        }).catch(e => {
          this.dataList = []
        })
      },
      selectMenu(index, indexPath) {
        if (index != 'help') {
          this.$router.push({ name: index })
        }
      },
      showCmdb() {
        return (this.authWithOutDataId('FUNC_SYS_IDENTITY_ADMIN', 0) || this.authWithOutDataId('FUNC_SYS_IDENTITY_OPE', 0));
      },
      showGitLabRegister() {
        //return (this.authWithOutDataId('FUNC_BIZ_IDENTITY_ADMIN', 1) || this.authWithOutDataId('FUNC_SYS_IDENTITY_ADMIN', 0));
        return (this.authFunction('FUNC_BIZ_IDENTITY_ADMIN', 1, this.$route.query.bizId) || this.authFunction('FUNC_SYS_IDENTITY_ADMIN', 0));
      },
      renderSubMenu() {
        let topMenu = $utils.getTopMenu(this.$route);
        this.headerDefaultActive = topMenu.name
        if (this.$route.meta.parent) {
          let tempSubMenuList = $utils.getSubMenuList(topMenu)
          let tempShowSide = false;
          this.bizMenuList.forEach((m) => {
            m.show = false;
            tempSubMenuList.some((sm) => {
              if (sm.name == m.name) {
                if (sm.name == 'manageCmdb') {
                  if (this.showCmdb()) {
                    m.show = true;
                    tempShowSide = true;
                    return true;
                  }
                } else if ((sm.name == 'memberManage') || (sm.name == 'roleManage') || (sm.name == 'menuManage') || (sm.name == 'authSetManage')
                  || (sm.name == 'functionManage') || (sm.name == 'sonarTaskManage') || (sm.name == 'sonarSystemManage')
                  || sm.name == 'imageManage' || sm.name == 'appManage') {
                  if (this.authFunction('FUNC_SYS_IDENTITY_ADMIN', 0, -1)) {
                    m.show = true;
                    tempShowSide = true;
                    return true;
                  }
                } else if (sm.name == 'gitLabRegister') {
                  if (this.showGitLabRegister()) {
                    this.showGitlab = true;
                    m.show = true;
                    tempShowSide = true;
                    return true;
                  }
                } else {
                  m.show = true;
                  tempShowSide = true;
                  return true;
                }
              }
            });
          });
          this.showSideBar = tempShowSide;
        } else {
          this.showSideBar = false;
        }
        if (this.$route.meta.parent && this.$route.meta.parent == topMenu.name) {
          this.sideBarDefaultActive = this.$route.name
        } else {
          this.sideBarDefaultActive = this.$route.meta.parent
        }
      },
      authWithOutDataId(funcId, funcType) {
        let permissionInfo = $utils.getStorage(GLOBAL_CONST.USER_PERMISSION_INFO);
        let show = false;
        if (permissionInfo) {
          if (permissionInfo.isAdmin && permissionInfo.isAdmin == 1) {
            return true;
          }
          let functionList = permissionInfo.funcInfos;
          if (functionList) {
            functionList.some((func) => {
              if (func.type == funcType && func.id == funcId) {
                show = true;
                return true;
              }
            })
          }
        }
        return show;
      },

      handleEventDropdown(command) {
        if (command == 'logout') {
          window.location.href = "/logout";
        }
      },
      foldHandle() {
        this.isCollapse = !this.isCollapse;
      },
      handleSelect(index) {
        this.$router.push({
          name: index,
          query: {
            bizId: this.$route.query.bizId,
            projectId: this.$route.query.projectId
          }
        })
      },
      isImpersonating() {
        if (this.userData.isImpersonating === 1) {
          return true;
        } else {
          return false;
        }
      },
      async refreshUser() {
        await $utils.getUserInfo();
        window.location.href = "/manage/user"
      },
      //模拟结束
      impersionateStop() {
        $http.get($http.api.user.impersionate_stop).then((res) => {
          this.refreshUser();
        }).catch(() => {
          this.$message({
            type: 'error',
            message: '模拟结束异常'
          });
        });
      },
      getUnTreatedDeployNoteList() {
        $http.get($http.api.deploy_note.getUnTreatedDeployNoteList).then(res => {
          if (res.status == 200) {
            this.unTreatedDeployNoteList = res.data;
            if (this.unTreatedDeployNoteList) {
              this.totalUnTreatedDeployNoteCount = 0;
              this.unTreatedDeployNoteList.forEach((item, index) => {
                if (item.unTreatedDeployNoteCount) {
                  this.totalUnTreatedDeployNoteCount = this.totalUnTreatedDeployNoteCount + item.unTreatedDeployNoteCount;
                }
              });
            }
          } else {
            console.error("获取待处理发布单的提醒出现异常，错误信息：" + res.msg);
          }
        });
      },
      toDeployList(val) {
        const { href } = this.$router.resolve({ name: "deployNoteList", query: { bizId: val.bizId }, params: { type: 1 } });
        window.location.href = href;
      },
    }
  }
</script>

<style lang="scss" scoped>
  $headerHeight: 46px;
  $menuActiveColor: #3c85d2;

  .w156 {
    width: 156px;
  }

  .demo-spin-icon-load {
    animation: ani-demo-spin 1s linear infinite;
  }

  @keyframes ani-demo-spin {
    from {
      transform: rotate(0deg);
    }

    50% {
      transform: rotate(180deg);
    }

    to {
      transform: rotate(360deg);
    }
  }

  .address select {
    height: 34px !important;
    font-size: 12px !important;
    width: 49%;
    box-sizing: border-box;
    display: inline-block;
  }

  .layOut {
    background: #333744;
  }

  #header {
    width: 100%;
    height: $headerHeight;
    line-height: $headerHeight;
    background-color: #fff;
    box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
    // position: fixed;
    top: 0;
    left: 0;
    z-index: 100;
    background-color: #333744;
    color: #fff;

    h3 {
      font-size: 20px;
      text-indent: 20px;
      font-weight: 400;
      float: left;
      height: 100%;
      line-height: $headerHeight;
      margin-block-start: 0;
      margin-block-end: 0;

    }

    .el-menu-demo {
      display: inline-block;
      min-width: 400px;
      margin-left: 3%;
      background: #333744;
      border: none;

      .el-menu-item {
        border-bottom: none;
        height: $headerHeight !important;
        line-height: $headerHeight !important;
      }

      .is-active {
        background: $menuActiveColor !important;
        color: #fff !important;
      }
    }

    .user-info {
      float: right;
      height: 100%;
      margin-right: 20px;
      text-align: center;

      .el-dropdown-link {
        cursor: pointer;
        color: #409EFF;
      }

      .el-icon-arrow-down {
        font-size: 12px;
      }
    }

    .btn-popver {
      width: 80px;
      height: $headerHeight;
      float: right;
      margin-right: 5px;

      .user-alarm {
        cursor: pointer;
        text-align: center;

        .span {
          float: left;
          font-size: 20px;
          padding: 3px;
          display: block;
          margin-top: 16px;
          margin-left: 15px;
        }

      }
    }

    .btn-popver:hover {
      background: #495060;
      cursor: pointer;
    }

  }

  .page-body {
    overflow: hidden;
    /* position: relative;
    z-index: 5;  */
    .sideBar {
      position: absolute;
      top: $headerHeight;
      left: 0;
      bottom: 30px;
      background: #b2c3fa;
    }

    .el-menu-vertical-demo {
      .is-active {
        background: $menuActiveColor !important;
        color: #fff !important;
      }
    }

    #main-content {
      height: fit-content;
      float: left;
      box-sizing: border-box;

      background: #fff;
      padding-bottom: 30px;

      .part {
        margin-bottom: 20px;
      }

      .row {
        margin-bottom: 20px;
      }

      ._table {
        margin-bottom: 10px;
      }

      ._btn-group {
        position: fixed;
        left: 200px;
        right: 20px;
        bottom: 40px;
        z-index: 100;
      }
    }
  }

  .footer {
    bottom: 0;
    left: 0;
    height: 30px;
    line-height: 30px;
    font-size: 14px;
    color: #333;
    text-align: center;
    width: 100%;
    border-top: 1px solid #ddd;
    // ==================================
    display: inline-block;
    width: calc(100% - 180px);
    float: right;
    // background: #f2f6fd;
  }

  #sidebar {
    background: #333744;
    height: 100%;
    min-width: 50px;
    max-width: 180px;
    float: left;
    position: relative;
    z-index: 5;
    .el-menu {
      border-right: none;
    }

    .el-menu-vertical-demo {
    }

    .el-menu-item-group__title {
      float: right !important;
      margin-right: 5px !important;
      color: white !important;
    }

    .el-menu-item {
      padding-left: 12px !important;
      height: 40px !important;
      line-height: 36px !important;
    }

    .el-submenu {
      .el-menu-item {
        padding-left: 12px !important;
        padding-right: 20px !important;
        min-width: 50px;
        height: 40px !important;
        line-height: 36px !important;
      }
    }

    .arrowbtn {
      padding: 4px !important;
      margin-left: calc(45% - 12px);
      margin-top: 5px;
      margin-bottom: 5px;
      overflow: hidden;
      font-size: 20px;
      line-height: 12px;
      color: #fff;
      cursor: pointer;
    }

    .arrowparent {
      width: 100%;
      height: 30px;
      opacity: 0.6;

      .el-button.is-circle {
        padding: 5px !important;
        margin-top: 2px;
        margin-left: calc(50% - 15px);
      }
    }

    .arrowparent:hover {
      background: rgb(41, 44, 54);
    }

  }
</style>

<style lang="scss">
  .sub-menu-class>.el-submenu__title {
    padding-left: 12px !important;
    height: 40px !important;
    line-height: 36px !important;
  }

  .sub-menu-class>.el-submenu__title>.el-submenu__icon-arrow {
    right: 10px !important;
  }

  .home-cotent {
    width: 100%;
    height: 100%;
    font-size: 14px;

    .product-left {
      float: left;
      height: 800px;
      width: 256px;
      background-color: #f7f7f7;
      margin-top: 10px;
      display: block;
      vertical-align: top;
      top: 0px;

      .type-ul {
        list-style: none;
        height: 100%;

        .type-li {
          height: 44px;
          line-height: 44px;
          font-size: 16px;
          font-weight: 600;

          .span-div {
            display: inline-block;
            margin-top: 10px;
            color: #373d41;
            cursor: pointer;
          }

          .span-div:hover {
            color: #00b7d3;
          }
        }
      }
    }

    .product-right {
      float: right;
      width: 850px;
      vertical-align: top;

      .content {
        width: 100%;
        margin-bottom: 7px;
        display: inline-block;
        vertical-align: top;

        .product-ul {
          width:100%;
          min-height: 32px;
          list-style: none;
          font-size: 16px;
          height: auto;
          border: 1px solid hsla(210,3%,85%,.8);
          padding: 14px 0px 14px 23px;
          box-sizing: border-box!important;

          .product-li {
            float: left;
            width: 22%;
            height: 32px;
            line-height: 32px;
            font-size: 14px;
            margin-right: 4%;
            overflow: hidden;
            text-overflow: ellipsis;

            .span-div {
              display: inline-block;
              color: #373d41;
              cursor: pointer;
            }

            .span-div:hover {
              color: #00b7d3;
            }
          }
        }

        .fontsize-content {
          font-size: 18px;
          margin-left: 6px;
          color: #373d41;
          font-weight: 600;
        }
      }

    }

    .cp {
      cursor: pointer;
    }
  }
</style>
