<template>
  <div>
    <div>
      <div class="table-box-top-bs">
        <el-table :data="wait2DeployListData.list" style="width:100%;height:100%;overflow:auto;">

          <el-table-column prop="applicationVersionBo.appCode" label="应用ID" min-width="150" v-if="fromDeployNote">
          </el-table-column>

          <el-table-column prop="applicationVersionBo.versionName" label="版本名称" min-width="150">
          </el-table-column>

          <el-table-column prop="releaseBranch" label="分支名称" min-width="150">
            <template slot-scope="scope">
              <el-popover
                placement="right"
                :title="scope.row.releaseBranch + ' 分支组合'"
                width="550"
                trigger="hover"
                v-if="scope.row.applicationVersionBo.extendData"
                :open-delay="200">
                <el-table :data="JSON.parse(scope.row.applicationVersionBo.extendData)">
                  <el-table-column property="branch" label="分支名称" width="400"></el-table-column>
                  <el-table-column property="integratedCommitId" label="CommitId">
                    <template slot-scope="scope2">
                      {{scope2.row.integratedCommitId ? scope2.row.integratedCommitId.substring(0,8) : ""}}
                    </template>>
                  </el-table-column>
                </el-table>
                <a slot="reference" :href="scope.row.applicationVersionBo.gitBranchCommitsUrl" target="_blank" class="c-blue cp">{{scope.row.releaseBranch}}</a>
              </el-popover>
              <span v-else>{{scope.row.releaseBranch}}</span>
            </template>
          </el-table-column>

          <el-table-column label="描述" min-width="150">
            <template slot-scope="scope">
              {{(!scope.row.expand && scope.row.applicationVersionBo.versionDesc.length > 30) ?
              scope.row.applicationVersionBo.versionDesc.substring(0,20) + '...' :
              scope.row.applicationVersionBo.versionDesc}}
              <span class="c-blue cp"
                    v-if="!scope.row.expand && scope.row.applicationVersionBo.versionDesc.length > 30"
                    @click="expandDescInfo(scope.row)">查看全部
              </span>
              <span class="c-blue cp" v-if="scope.row.expand" @click="unExpandDescInfo(scope.row)">收起</span>
            </template>
          </el-table-column>

          <el-table-column prop="applicationVersionBo.updateTime" label="测试通过时间" width="150">
          </el-table-column>

          <el-table-column prop="applicationVersionBo.testPassedUser" label="测试通过人" min-width="60">
          </el-table-column>

          <el-table-column prop="mergedMaster" label="已合入主干" width="90">
            <template slot-scope="scope">{{scope.row.mergedMaster ? "是" : "否"}}</template>
          </el-table-column>

          <el-table-column prop="containsDeleteUnMergedMasterReleaseBranch" min-width="70"
                           :render-header="tableHeaderRender">
            <template slot-scope="scope">
              <span v-html="transferBoolean2HtmlWord(scope.row.containsDeleteUnMergedMasterReleaseBranch)"></span>
            </template>
          </el-table-column>

          <el-table-column label="操作" min-width="120">
            <template slot-scope="scope">

              <el-popover
                placement="left"
                :title="scope.row.releaseBranch + ' 发布情况'"
                width="550"
                trigger="hover"
                :open-delay="200" @show="getVersionDeployNoteInfo(scope.row.applicationVersionBo.versionId)">
                <div v-loading="deployNoteListLoading" element-loading-text="拼命加载中">
                  <el-table :data="deployNoteList">
                    <el-table-column property="deployNoteDesc" label="发布单标题"></el-table-column>
                    <el-table-column property="deployNoteStatusName" label="状态"></el-table-column>
                  </el-table>
                </div>

                <span slot="reference" class="c-blue cp" v-show="!fromDeployNote && authFunction('FUNC_BIZ_DEPLOY_CREATE', 1)" @click="generateDeployNote(scope.row)">
                  一键生成发布单&nbsp;&nbsp;&nbsp;
                </span>
              </el-popover>

              <span class="c-blue cp" v-show="authFunction('FUNC_APP_RELEASE_BRANCH_WAIT_TO_DEPLOY_MERGE_MASTER', 2, scope.row.appId) && !scope.row.mergedMaster" @click="showBranchDiff(scope.row)">
                查看分支对比&nbsp;&nbsp;&nbsp;
              </span>

              <span class="c-blue cp" v-show="authFunction('FUNC_APP_RELEASE_BRANCH_WAIT_TO_DEPLOY_MERGE_MASTER', 2, scope.row.appId) && !scope.row.mergedMaster" @click="showMergeMasterDialog(scope.row)">
                合并主干&nbsp;&nbsp;&nbsp;
              </span>
              <span class="c-blue cp" v-show="authFunction('FUNC_APP_RELEASE_BRANCH_WAIT_TO_DEPLOY_DELETE', 2, scope.row.appId)" @click="showDeleteVersionDialog(scope.row)">删除</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="table_b_f_b">
        <el-pagination
          class="fr"
          style="margin-top: 9px;"
          @size-change="handleListSizeChange"
          @current-change="handleListPageChange"
          :current-page="wait2DeployListData.pageNum"
          :page-sizes="[10, 20, 30]"
          :page-size="wait2DeployListData.pageSize"
          layout="total, sizes, prev, pager, next, jumper"
          :total="wait2DeployListData.total">
        </el-pagination>
      </div>
    </div>

    <el-dialog
      title="提示"
      :visible.sync="deleteVersionDialogVisible"
      width="30%"
      :before-close="closeDeleteVersionDialog"
      :close-on-click-modal="false"
      :append-to-body="true"
    >
      <el-row>
        <h4>确认删除所选版本？</h4>
        <el-form ref="deleteVersionFormRef" :model="deleteForm">
          <el-form-item prop="alsoDeleteGit">
            <el-checkbox v-model="deleteForm.alsoDeleteGit">
              <h4>同步删除Git仓库分支</h4>
            </el-checkbox>
          </el-form-item>
        </el-form>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDeleteVersionDialog">取 消</el-button>
        <el-button type="primary" @click="deleteReleaseVersion">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="合并主干"
      class="el-dialog-640w"
      :visible.sync="mergeMasterDialogVisible"
      :before-close="closeMergeMasterDialog"
      :close-on-click-modal="false"
      :append-to-body="true"
    >
      <div>
        <span>待自动删除的特性分支列表</span>
        <div class="mt5 table-box-top-bs" v-loading="wait2DeletedFeatureBranchListLoading" element-loading-text="拼命加载中">
          <el-table :data="wait2DeletedFeatureBranchList" border>
            <el-table-column property="featureBranch" label="分支名称" width="240"></el-table-column>
            <el-table-column property="changeReason" label="变更原因" width="240"></el-table-column>
            <el-table-column property="stillExists" label="仍在使用中">
              <template slot-scope="scope">
                <el-popover
                  v-if="scope.row.stillExists"
                  placement="top"
                  :title="scope.row.featureBranch + ' 仍在以下应用中使用，将暂时不删除GitLab原始分支'"
                  width="550"
                  trigger="hover"
                  :open-delay="200">
                  <el-table :data="scope.row.existsBranchApplicationBos" v-if="scope.row.stillExists">
                    <el-table-column property="application.appCode" label="应用ID" width="210"></el-table-column>
                    <el-table-column property="application.appName" label="应用名称" width="210"></el-table-column>
                    <el-table-column property="statusName" label="分支状态"></el-table-column>
                  </el-table>
                  <span style="color: #ff6900 !important;" slot="reference" v-if="scope.row.stillExists">是<i class="el-icon-warning"></i></span>
                </el-popover>
                <span v-else>否</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="mt20">
        <span>合并主干操作步骤</span>
        <el-steps :active="mergeMasterActiveStep" finish-status="success" simple>
          <el-step title="提Merge Request"></el-step>
          <el-step title="打标签"></el-step>
        </el-steps>
        <div v-show="mergeMasterActiveStep===0" class="mt5">
          <div>
            <span>请输入Merge Request标题</span>
            <div class="mt5">
              <el-input v-model="mergeMasterMRTitle" placeholder="合并主干时Merge Request的标题，留空表示使用系统默认值" style="width:100%;"></el-input>
            </div>
          </div>
          <div class="mt5" style="text-align: right;">
            <el-button @click="closeMergeMasterDialog()">取 消</el-button>
            <el-button type="primary" @click="mergeMasterNextStep()">下一步</el-button>
          </div>
        </div>
        <div v-show="mergeMasterActiveStep===1" class="mt5">
          <div>
            <span>请输入标签名</span>
            <div class="mt5">
              <el-input v-model="mergeMasterTagName" placeholder="合并主干后将自动进行打标签操作，留空表示不打标签"
                        style="width:100%;" @input="checkGitLabelName()"></el-input><br/>
              <span style="color: red;" v-show="mergeMasterTagNameErrorMsg">{{mergeMasterTagNameErrorMsg}}</span>
            </div>
          </div>
          <div class="mt5" v-show="mergeMasterTagName">
            <span>请输入标签描述说明（Release Notes）</span>
            <div class="mt5">
              <el-input type="textarea" v-model="mergeMasterTagReleaseNotes" :autosize="{ minRows: 1, maxRows: 6}"
                        resize="vertical !important" placeholder="标签的描述信息（Release Notes），留空表示使用系统默认值" style="width:100%;"></el-input>
            </div>
          </div>
          <div class="mt5 mr20" style="text-align: right;">
            <el-button @click="closeMergeMasterDialog()">取 消</el-button>
            <el-button type="primary" @click="mergeMasterPreStep()">上一步</el-button>
            <el-button type="primary" @click="mergeMaster()">确 定</el-button>
          </div>
        </div>
      </div>
    </el-dialog>

    <el-dialog title='分支对比' :visible.sync="featureDiffBranchDialogVisible" class="issuedialog el-dialog-740w"
               :before-close="handFeatureDiffCloseDialog" :modal-append-to-body="true" :close-on-click-modal='false'>
      <div class="form-iterm-box">
        <el-table :data="featureDiffBranchList" style="width: 100%;height: 100%;overflow:auto;">
          <el-table-column prop="featureBranch" label="特性分支名称" min-width="80">
          </el-table-column>
          <el-table-column prop="originalBranch" label="仓库分支名称" min-width="80">
          </el-table-column>
          <el-table-column prop="createTime" label="主干分支" min-width="80">
            <template slot-scope="scope">
              <span>master</span>
            </template>
          </el-table-column>
          <el-table-column width="120" align="left" label="操作">
            <template slot-scope="scope">
              <span class="c-blue cp" @click="goGitlabDiffDialog(scope.row)">对比详情</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
         <el-button @click="handFeatureDiffCloseDialog">关闭</el-button>
       </span>
    </el-dialog>
  </div>
</template>
<script>

  export default {
    name: "FeatureBranchWaitDeployTable",
    components: {  },
    mixins: [],
    props: {
      bizId: {
        type: [Number, String],
        required: true
      },
      fromDeployNote: {
        type: Boolean,
        required: false,
        default: false
      },
      wait2DeployListData: {
        type: [Object],
        required: true
      },
    },
    data() {
      return {
        deleteForm: {
          releaseBranchId: -1,
          versionId: -1,
          alsoDeleteGit: false,
        },
        deleteVersionDialogVisible: false,

        deployNoteList: [],
        deployNoteListLoading: false,

        mergeMasterDialogVisible: false,
        wait2DeletedFeatureBranchListLoading: false,
        wait2DeletedFeatureBranchList: [],
        featureDiffBranchDialogVisible: false,
        featureDiffBranchListLoading: false,
        featureDiffBranchList: [],
        mergeMasterMRTitle: '',
        mergeMasterTagName: '',
        mergeMasterTagReleaseNotes: '',
        mergeMasterReleaseId: 0,
        mergeMasterTagNameErrorMsg: '',
        mergeMasterActiveStep: 0,
      }
    },

    watch: {

    },
    created() {

    },

    methods: {
      renderTable() {
        this.$emit('renderTable')
      },

      handleListSizeChange(newPageSize) {
        this.$emit('handleListSizeChange', newPageSize)
      },

      handleListPageChange(newPageNum) {
        this.$emit('handleListPageChange', newPageNum)
      },

      expandDescInfo(row) {
        this.$set(row, 'expand', true);
      },
      unExpandDescInfo(row) {
        this.$set(row, 'expand', false);
      },

      mergeMasterNextStep() {
        this.mergeMasterActiveStep++;
      },

      mergeMasterPreStep() {
        this.mergeMasterActiveStep--;
      },

      closeMergeMasterDialog() {
        this.mergeMasterDialogVisible = false;
        this.mergeMasterReleaseId =  0;
        this.wait2DeletedFeatureBranchListLoading = false;
        this.wait2DeletedFeatureBranchList = [];
        this.mergeMasterTagName = '';
        this.mergeMasterTagNameErrorMsg = '';
        this.mergeMasterActiveStep = 0;
        this.mergeMasterMRTitle = '';
        this.mergeMasterTagReleaseNotes = '';
      },

      handFeatureDiffCloseDialog(){
        this.featureDiffBranchDialogVisible = false;
      },

      showBranchDiff(data){
        this.featureDiffBranchDialogVisible = true;
        this.getFeatureBranchListByReleaseBranch(data.id);
      },

      goGitlabDiffDialog(data){
        let params = {
          featureBranch: data.originalBranch,
          sourceRepo: data.sourceRepo
        };
        $http.get($http.api.feature_branch.featureMasterCompare, params).then(response => {
          if(response.status === 200){
            window.open(response.data, "_blank");
          }else{
            this.$message({
              message: "获取对比详情失败",
              type: "error"
            });
          }
        });
      },

      showMergeMasterDialog(data) {
        this.mergeMasterReleaseId =  data.id;
        this.mergeMasterDialogVisible = true;
        this.getWait2DeletedFeatureBranchList();
      },

      getFeatureBranchListByReleaseBranch(id) {
        this.featureDiffBranchListLoading = true;
        let params = {
          id: id,
        };
        $http.get($http.api.feature_branch.getFeatureBranchListByReleaseBranch, params).then(response => {
          this.featureDiffBranchList = response.data;
          this.featureDiffBranchListLoading = false;
        });
      },

      getWait2DeletedFeatureBranchList() {
        this.wait2DeletedFeatureBranchListLoading = true;
        let params = {
          id: this.mergeMasterReleaseId,
        };
        $http.get($http.api.feature_branch.mergeMasterWaitToDeleteFeatureBranch, params).then(response => {
          this.wait2DeletedFeatureBranchList = response.data;
          this.wait2DeletedFeatureBranchListLoading = false;
        });
      },

      mergeMaster() {
        let formData = new FormData();
        formData.append("id", this.mergeMasterReleaseId);
        formData.append("mrTitle", this.mergeMasterMRTitle);
        formData.append("tagName", this.mergeMasterTagName);
        formData.append("tagReleaseNotes", this.mergeMasterTagReleaseNotes);
        $http.post($http.api.feature_branch.wait2DeployMergeMaster, formData).then(response => {
          if (response.status == 200) {
            this.$message({
              message: "合并主干成功",
              type: "success"
            });
            this.closeMergeMasterDialog();
            this.renderTable();
          }
        });
      },

      tableHeaderRender(h, { column, $index }) {
        return (<el-tooltip effect="dark" content="包含已删除且未合并主干的release版本内容" placement="top"><span>包含已删除版本</span></el-tooltip>)
      },

      checkGitLabelName() {
        var reg = /^(([a-zA-Z0-9_.\-]+)|(\s*))$/;
        if (reg.test(this.mergeMasterTagName)) {
          this.mergeMasterTagNameErrorMsg = '';
        } else {
          this.mergeMasterTagNameErrorMsg = "标签名格式不正确";
        }
      },

      transferBoolean2HtmlWord(value) {
        return value ? "<span style='color: red;'>是</span>" : "否";
      },

      generateDeployNote(data) {
        //设置一键生成发布单所需部分参数，采用sessionStorage存储，使用完毕后，务必主动进行清理
        sessionStorage.setItem("DEPLOY_NOTE_ONE_CLICK_GENERATE", "true");
        sessionStorage.setItem("DEPLOY_NOTE_BIZ_ID", this.bizId);
        sessionStorage.setItem("DEPLOY_NOTE_APP_ID", data.appId);
        sessionStorage.setItem("DEPLOY_NOTE_VERSION_ID", data.applicationVersionBo.versionId);
        sessionStorage.setItem("DEPLOY_NOTE_VERSION_NAME", data.applicationVersionBo.versionName);
        //跳转到生成发布单页面
        this.goToPage(this, 'deployNoteManage', {bizId: this.bizId})
      },

      showDeleteVersionDialog(releaseAppversionInfo) {
        this.deleteForm.releaseBranchId = releaseAppversionInfo.id;
        this.deleteForm.versionId = releaseAppversionInfo.applicationVersionBo.versionId;
        this.deleteVersionDialogVisible = true;
      },

      closeDeleteVersionDialog() {
        this.deleteVersionDialogVisible = false;
        this.$refs['deleteVersionFormRef'].resetFields();
      },

      deleteReleaseVersion() {
        let formData = new FormData();
        formData.append("id", this.deleteForm.releaseBranchId);
        formData.append("versionId", this.deleteForm.versionId);
        formData.append("alsoDeleteGit", this.deleteForm.alsoDeleteGit);
        $http.post($http.api.feature_branch.wait2DeployDelete, formData).then(response => {
          if (response.status == 200) {
            this.$message({
              message: "删除成功",
              type: "success"
            });
            this.deleteVersionDialogVisible = false;
            this.renderTable();
          }
        });
      },

      getVersionDeployNoteInfo(versionId) {
        this.deployNoteListLoading = true;
        this.deployNoteListLoading = [];
        $http.get($http.api.deploy_note.getDeployNoteListByVersion, {"bizId": this.bizId, "versionId": versionId}).then(res => {
          if (res.status == 200) {
            this.deployNoteList = res.data;
          } else {
            this.$message({
              message: "获取版本关联的发布单情况异常，错误信息：" + res.msg,
              type: "error"
            });
          }
          this.deployNoteListLoading = false;
        });
      },

    }
  };
</script>
<style lang="scss" scoped>
  .el-step__title {
    max-width: 70% !important;
  }
</style>
