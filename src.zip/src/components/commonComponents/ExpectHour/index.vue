<template>
  <el-select v-model="value" ref="hourSelect" @change="onchange">
    <el-option
      v-for="item in expectHourListResult"
      :key="item.key"
      :value="item.key"
      :label="item.value"
    >
      <span style="float: left;margin-right:20px;">{{ item.value }}</span>
      <span style="float: right; color: #8492a6; font-size: 13px;">{{ item.key }}h</span>
    </el-option>
    <el-option value="search" v-show="customInput" disabled>
      <el-input placeholder="自定义天数" v-model="customDays" @change="customInputChange"></el-input>
    </el-option>
    <el-option value="0" disabled>
      <div class="showmore" @click="showmoreClick">{{showMore?'收起':'更多'}}</div>
    </el-option>
  </el-select>
</template>
<script>
/**
 * @title 预计工时组件
 * @desc 用于分解任务、创建任务
 * @author heyunjiang
 * @date 2019.6.12
 */
import { mapState } from 'vuex'
export default {
  name: "ExpectHour",
  components: {},
  mixins: [],
  props: {
    hour: {
      type: Number,
      required: true
    },
    changeCallback: {
      type: Function,
      required: false
    },
    customInput: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否允许自定义输入'
    }
  },
  data() {
    return {
      value: 4,
      showMore: false,
      customDays: null
    };
  },
  computed: {
    expectHourListResult() {
      return this.expectHourList.filter(item => {
        if (!this.showMore) {
          return !item.showMore;
        } else {
          return true;
        }
      })
    },
    ...mapState({
      expectHourList: state => state.pf.expectHourList
    })
  },
  watch: {
    hour() {
      this.value = this.hour / 8 + '天';
    }
  },
  created() { },
  methods: {
    onchange() {
      this.$emit('update:hour', this.value);
      this.changeCallback()
    },
    showmoreClick() {
      this.showMore = !this.showMore;
    },
    // 自定义天数回调
    customInputChange() {
      var expectHour = Number(this.customDays)
      if (!/^\d+$/.test(expectHour)) {
        this.$message({
          showClose: true,
          message: '工时天数必须是整数',
          type: 'warning'
        });
        return false;
      }
      if (expectHour <= 0) {
        this.$message({
          showClose: true,
          message: '工时天数必须大于0',
          type: 'warning'
        });
        return false;
      }
      this.$emit('update:hour', expectHour * 8);
      this.changeCallback();
      this.$refs.hourSelect.blur();
      this.customDays = null;
    }
  }
};
</script>
<style lang="scss" scoped>
.showmore {
  cursor: pointer;
  text-align: center;
}
</style>
