<template>
  <div>
    <div  class="edit-box-bug-inactive scrollbal-common" v-html="value"
      @click="clickImg($event)">
    </div>
    <el-dialog :visible.sync="imgDialog" class="el-dialog-img" :fullscreen='true' :modal-append-to-body="modaltobody"
      :close-on-click-modal="shadeBtn" :show-close=false> 
      <img style="width: 100%;" @click="closeImgDialog()" :src='imgPath' />
    </el-dialog>
  </div>
</template>
<script>
  export default {
    data() {
      return {
        modaltobody: false,
        shadeBtn: true,
        imgPath: '',
        imgDialog: false,
      }
    },
    props: {
      value: String,
      require: true
    },
    methods: {
      closeImgDialog() {
        this.imgDialog = false;
        this.imgPath = '';
      },
      clickImg(event) {
        if (event.target.nodeName == 'IMG') {
          this.imgPath = event.target.src;
          let imgDialog = document.getElementsByClassName('el-dialog-img')[0].getElementsByClassName('el-dialog')[0]
          imgDialog.setAttribute('style', 'width: ' + (event.target.naturalWidth + 30) + 'px;height: ' + (event.target.naturalHeight + 25) + 'px')
          this.imgDialog = true;
        }
      },
    },
  }
</script>
<style scoped lang="scss">
  @import "../../project/ProjectCommon.scss";
</style>