<template>
  <div>
    <!-- 非多仓库关联应用弹窗 -->
    <el-dialog title='关联应用' :visible.sync="dialogVisible_correlation" class="el-dialog-1180w"
               :before-close="handleClose_correlation" :modal-append-to-body="modaltobody"
               :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div style="padding-top:5px;">
          <!-- <div> -->
          <!--<span class="fl mt5 ml5">关联应用设置列表</span>-->
          <el-button type="primary" class="fr mr5 mb5" @click="addCorrelation()">添加关联应用</el-button>
          <!-- </div> -->
          <el-table
            :span-method="spanMethod"
            :data="correlationInfo_list">
            <el-table-column prop="branch" label="源分支" min-width="160"></el-table-column>
            <el-table-column prop="relatedBizCode" label="关联业务编码" min-width="160"></el-table-column>
            <el-table-column prop="relatedAppCode" label="关联应用ID" min-width="160"></el-table-column>
            <el-table-column prop="relatedSourceRepo" label="关联源码仓库" min-width="180"></el-table-column>
            <el-table-column prop="relatedBranch" label="关联应用分支" min-width="180"></el-table-column>
            <el-table-column prop="gitRepoUrl" label="操作" min-width="120">
              <template slot-scope="scope">
                <span class="c-blue cp" @click="editCorrelation(scope.row)">编辑</span>
                <span class="c-blue cp" @click="deleteCorrelation(scope.row)">删除</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="handleClose_correlation">关闭</el-button>
            </span>
    </el-dialog>

    <!-- 添加关联应用 -->
    <el-dialog title='关联应用' :visible.sync="dialogVisible_correlation_a" class="el-dialog-880w"
               :before-close="handleClose_correlation_a" :modal-append-to-body="modaltobody"
               :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="correlationInfo_a" ref="correlationInfo_a">
          <el-form-item label="源分支" label-width="110px" prop="branchName" style="margin-bottom: 10px;"
                        :rules="[
                            { required: true, message: '源分支不能为空' }
                        ]">
            <el-autocomplete
              class="inline-input"
              v-model="correlationInfo_a.branchName"
              :fetch-suggestions="queryBranchNameSearch"
              placeholder="请输入内容"
              @select="handleBranchNameSelect"
              :disabled="sourceDisabled"
              style="width:60%;"
            >
              <template slot-scope="{ item }">
                <div>{{ item.name }}</div>
              </template>
            </el-autocomplete>
            <span class="c-red">支持输入通配符，如feature/*</span>
          </el-form-item>
          <el-row>
            <el-col :span="12" style="width: 55%;">
              <el-form-item label="关联应用" label-width="110px" prop="bizId" style="margin-bottom: 10px;"
                            :rules="[
                            { required: true, message: '业务列表不能为空' }
                        ]">
                <el-select v-model="correlationInfo_a.bizId" placeholder="请选择"
                           @change="changebizCode(correlationInfo_a.bizId)" style="width:60%;">
                  <el-option
                    v-for="item in correlationInfo_list_c"
                    :key="item.bizId"
                    :label="item.bizName"
                    :value="item.bizId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12" style="margin-left: -230px; width: 55%;">
              <el-form-item label="" label-width="110px" prop="appId" style="margin-bottom: 10px;"
                            :rules="[{ required: true, message: '关联应用不能为空', trigger: 'blur'}]">
                <el-select v-model="correlationInfo_a.appId" placeholder="请选择"
                           @change="changeAppId(correlationInfo_a.appId)" style="width:60%;">
                  <el-option
                    v-for="item in correlationInfo_list_a"
                    :key="item.appId"
                    :label="item.appCode"
                    :value="item.appId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-form-item label="关联应用分支" label-width="110px" prop="name" :rules="[
                            { required: true, message: '关联应用分支不能为空', trigger: 'blur'}]">
            <el-select v-model="correlationInfo_a.name" placeholder="请选择" style="width:60%;">
              <el-option
                v-for="item in correlationInfo_list_b"
                :key="item.name"
                :label="item.name"
                :value="item.name">
              </el-option>
            </el-select>
            <el-button type="primary" class="fr mr10" style="margin-top: 10px;" :disabled="sourceClearDisabled"
                       @click="clearCorrelation_list_selected">清空
            </el-button>
            <el-button type="primary" class="fr mr10" style="margin-top: 10px;" @click="addCorrelation_list_selected">
              添加
            </el-button>
          </el-form-item>
        </el-form>
        <el-table
          :data="correlationInfo_list_selected">
          <el-table-column label="关联业务" min-width="160">
            <template slot-scope="scope">
              {{getBizName(scope.row)}}
            </template>
          </el-table-column>
          <el-table-column label="关联应用" min-width="160">
            <template slot-scope="scope">
              {{getAppCode(scope.row)}}
            </template>
          </el-table-column>
          <el-table-column prop="relatedBranch" label="关联应用分支" min-width="180"></el-table-column>
          <el-table-column prop="gitRepoUrl" label="操作" min-width="120">
            <template slot-scope="scope">
              <span class="c-blue cp" @click="moveUpSelected(scope.row.order)">上移</span>
              <span class="c-blue cp" @click="moveDownSelected(scope.row.order)">下移</span>
              <span class="c-blue cp" @click="deleteSelectedCorrelation(scope.row)">删除</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
           <el-button type="primary" @click="saveCorrelation_list_selected"
                      :loading='packBtn_correlation_loading_a'>保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>

export default {
  name: "ApplicationAssociation",
  components: {},
  mixins: [],
  props: {
    modaltobody: {
      type: Boolean,
      required: true
    },
    shadeBtn: {
      type: Boolean,
      required: true
    },
    dialogVisible_correlation: {
      type: Boolean,
      required: true,
      desc: 'dialog 是否显示'
    },
    handleClose_correlation: {
      type: Function,
      required: false,
      default: () => {},
      desc: '关闭dialog回调函数'
    }
  },
  data() {
    return {
      bizId: 0,
      appId: 0,

      sourceDisabled: false,
      sourceClearDisabled: false,
      correlationInfo: {},
      packBtn_correlation_loading: false,
      correlationInfo_list: [],
      correlationInfo_list_selected: [],
      dialogVisible_correlation_a: false,
      correlationInfo_a: {
        branchName: '',
        bizId: '',
        appId: '',
        name: ''
      },
      packBtn_correlation_loading_a: false,
      correlationInfo_list_a: [],
      correlationInfo_list_b: [],
      correlationInfo_list_c: [],


      appType: 0,
      tableList: {
        appType: 0,
        data: [],
      },

    }
  },
  computed: {

  },
  watch: {},
  created() {},
  methods: {
    // 初始化
    init(bizId, appId) {
      this.bizId = bizId;
      this.appId = appId;

      this.getBranchList();

      this.getCorrelation({
        appId: this.appId
      });

    },

    spanMethod({row, column, rowIndex, columnIndex}) {
      if (columnIndex === 0 || columnIndex === 5) {
        if (row.key1span != 0) {
          return [row.key1span, 1];
        } else {
          return [0, 0];
        }
      }
    },

    //添加关联应用
    addCorrelation() {
      this.dialogVisible_correlation_a = true;
      this.correlationInfo_list_selected = [];
      this.sourceDisabled = false;
      this.sourceClearDisabled = false;
      this.get_associated_usiness();
    },

    //获取非多仓库关联应用信息
    getCorrelation(val) {
      let params = val;
      $http.get($http.api.appdate.api_application_relate_app_list, params).then(res => {
        if (res.status == 200) {
          let tempList = res.data;
          let counter = {};
          if (tempList && tempList.length !== 0) {
            for (let item of tempList) {
              if (!counter[item.branch]) {
                counter[item.branch] = 1;
              } else {
                counter[item.branch] = counter[item.branch] + 1;
              }
            }
          }

          let lastObj = null;
          for (let item of tempList) {
            if (!lastObj) {
              item.key1span = counter[item.branch];
            } else if (lastObj.branch == item.branch) {
              item.key1span = 0;
            } else {
              item.key1span = counter[item.branch];
            }
            lastObj = item;
          }
          this.correlationInfo_list = res.data;
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },


    //获取当前应用可关联的业务列表
    get_associated_usiness() {
      $http.get($http.api.appdate.api_app_relate_app_available_biz_list, {}).then(res => {
        if (res.status == 200) {
          this.correlationInfo_list_c = res.data;
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },

    //选择可关联的业务加载关联应用
    changebizCode(val) {
      this.getCorlist(val);
    },

    clearCorrelation_list_selected() {
      this.sourceDisabled = false;
      this.correlationInfo_list_selected = [];
    },

    queryBranchNameSearch(queryString, cb){
      var restaurants = this.tableList.data;
      var results = queryString ? restaurants.filter(this.createBranchNameFilter(queryString)) : restaurants;
      // 调用 callback 返回建议列表的数据
      cb(results);
    },
    createBranchNameFilter(queryString) {
      return (restaurant) => {
        return (restaurant.name.toLowerCase().indexOf(queryString.toLowerCase()) === 0);
      };
    },

    handleBranchNameSelect(item) {
      this.correlationInfo_a.branchName = item.name;
    },


    addCorrelation_list_selected(val) {
      this.$refs['correlationInfo_a'].validate((valid) => {
        if (valid) {
          let params = {
            appId: this.appId,
            branch: this.correlationInfo_a.branchName,
            relatedBizId: this.correlationInfo_a.bizId,
            relatedAppId: this.correlationInfo_a.appId,
            relatedBranch: this.correlationInfo_a.name,
            order: this.correlationInfo_list_selected === null ? 1 : this.correlationInfo_list_selected.length + 1,
          };
          this.correlationInfo_list_selected = this.correlationInfo_list_selected.filter(item => {
            return item.relatedBranch !== params.relatedBranch || item.relatedAppId !== params.relatedAppId || item.relatedBizId !== params.relatedBizId;
          });
          this.correlationInfo_list_selected.push(params);
        }
        this.sourceDisabled = true;
      });
    },

    saveCorrelation_list_selected() {
      let orderNumber = 1;
      for (let item of this.correlationInfo_list_selected) {
        item.order = orderNumber;
        orderNumber = orderNumber + 1;
      }
      let param = {};
      param.appId = this.appId;
      param.branch = this.correlationInfo_a.branchName;
      param.relatedApps = this.correlationInfo_list_selected;
      if(param.relatedApps.length === 0){
        this.$message({
          message: "关联列表为空",
          type: "warning"
        });
        return;
      }
      $http.post($http.api.appdate.api_application_relate_apps_add, param).then(res => {
        if (res.status == 200) {
          this.correlationInfo_list_selected = [];
          this.dialogVisible_correlation_a = false;
          this.getCorrelation({
            appId: this.appId
          });
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },

    //获取关联应用列表
    getCorlist(val) {
      this.correlationInfo_a.appId = '';
      this.correlationInfo_list_a = [];
      let params = {
        bizId: val
      }
      $http.get($http.api.appdate.api_application_relate_app_available_app_list, params).then(res => {
        if (res.status == 200) {
          let allList = res.data;
          let realList = [];
          if (allList && allList.length != 0) {
            allList.forEach(item => {
              if (item.appId != this.appId) {
                realList.push(item);
              }
            })
          }
          this.correlationInfo_list_a = realList;
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },

    //选择关联应用
    changeAppId(val) {
      this.getCorMaster({appId: val});
    },

    //管理应用分支列表
    getCorMaster(val) {
      this.$set(this.correlationInfo_a, 'name', '');
      let param = {};
      param.appId = val.appId;
      param.bizId = this.correlationInfo_a.bizId;
      $http.get($http.api.appdate.appBranchList, param).then(res => {
        if (res.status == 200) {
          this.correlationInfo_list_b = res.data.data;
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },

    //取消添加关联应用
    handleClose_correlation_a() {
      this.dialogVisible_correlation_a = false;
      this.$refs['correlationInfo_a'].resetFields();
      this.correlationInfo_list_a = [];
      this.correlationInfo_list_b = [];
    },

    //上移
    moveUp(val) {
      let params = {relatedId: val.relatedId, command: '0'}
      $http.post($http.api.appdate.api_application_relate_app_update_order, params).then(res => {
        if (res.status == 200) {
          this.getCorrelation({
            appId: this.appId,
            branch: this.correlationInfo.branch
          });
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },
    //下移
    moveDown(val) {
      let params = {relatedId: val.relatedId, command: '1'}
      $http.post($http.api.appdate.api_application_relate_app_update_order, params).then(res => {
        if (res.status == 200) {
          this.getCorrelation({
            appId: this.appId,
            branch: this.correlationInfo.branch
          });
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      });
    },

    moveUpSelected(val) {
      if (val !== 1) {
        let tempOption = this.correlationInfo_list_selected[val - 2]; //存储前一个
        this.correlationInfo_list_selected[val - 2] = this.correlationInfo_list_selected[val - 1];
        this.correlationInfo_list_selected[val - 2].order = val - 1;
        this.correlationInfo_list_selected[val - 1] = tempOption;
        this.correlationInfo_list_selected[val - 1].order = val;
        this.correlationInfo_list_selected = this.correlationInfo_list_selected.concat([]);
      }
    },

    moveDownSelected(val) {
      if (val !== this.correlationInfo_list_selected.length) {
        let tempOption = this.correlationInfo_list_selected[val]; //存储前一个
        this.correlationInfo_list_selected[val] = this.correlationInfo_list_selected[val - 1];
        this.correlationInfo_list_selected[val].order = val + 1;
        this.correlationInfo_list_selected[val - 1] = tempOption;
        this.correlationInfo_list_selected[val - 1].order = val;
        this.correlationInfo_list_selected = this.correlationInfo_list_selected.concat([]);
      }
    },

    deleteSelectedCorrelation(val) {
      this.$confirm("确定要删除吗？", "删除提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        this.correlationInfo_list_selected = this.correlationInfo_list_selected.filter(item => {
          return item.relatedBranch !== val.relatedBranch || item.relatedAppId !== val.relatedAppId || item.relatedBizId !== val.relatedBizId;
        });
      }).catch(() => {
      });
    },
    editCorrelation(val) {
      this.get_associated_usiness();
      this.correlationInfo_list_selected = [];
      for (let item of this.correlationInfo_list) {
        if (item.branch === val.branch) {
          this.correlationInfo_list_selected.push({
            'appId': item.appId,
            'branch': item.branch,
            'relatedBizId': item.relatedBizId,
            'relatedAppId': item.relatedAppId,
            'relatedAppCode': item.relatedAppCode,
            'relatedBranch': item.relatedBranch,
            'order': item.order,
          });
          this.correlationInfo_a.branchName = val.branch;
        }
      }
      this.sourceDisabled = true;
      this.sourceClearDisabled = true;
      this.dialogVisible_correlation_a = true;
    },
    //删除关联应用
    deleteCorrelation(val) {
      this.$confirm("确定要删除吗？", "删除提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      }).then(() => {
        $http.post($http.api.appdate.api_application_relate_app_remove, {
          appId: val.appId,
          branch: val.branch
        }).then(res => {
          if (res.status == 200) {
            this.getCorrelation({
              appId: this.appId,
              branch: this.correlationInfo.branch
            });
            this.$message({
              message: '删除成功',
              type: "success"
            });
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      }).catch(() => {
      });

    },

    //添加关联应用确定按钮
    submitSure() {
      this.$refs['correlationInfo_a'].validate((valid) => {
        if (valid) {
          let params = {
            appId: this.appId,
            branch: this.correlationInfo.branch,
            relatedBizId: this.correlationInfo_a.bizId,
            relatedAppId: this.correlationInfo_a.appId,
            relatedBranch: this.correlationInfo_a.name,
          }
          $http.post($http.api.appdate.api_application_relate_app_add, params).then(res => {
            if (res.status == 200) {
              this.$refs['correlationInfo_a'].resetFields();
              this.$message({
                message: '关联应用成功',
                type: "success"
              });
              this.getCorrelation({
                appId: this.appId,
                branch: this.correlationInfo.branch
              });
            } else {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            }
          });
          this.handleClose_correlation_a();
        }
      });
    },

    getBizName(row) {
      for (let item of this.correlationInfo_list_c) {
        if (item.bizId === row.relatedBizId) {
          return item.bizName
        }
      }
    },
    getAppCode(row) {
      if (row.relatedAppCode) {
        return row.relatedAppCode;
      }
      for (let item of this.correlationInfo_list_a) {
        if (item.appId === row.relatedAppId) {
          return item.appCode
        }
      }
    },


    //获取分支列表
    getBranchList() {
      let params = {appId: this.appId};
      $http.get($http.api.appdate.appBranchList, params).then((res) => {
        if (res.status == 200) {
          this.appType = res.data.appType;
          if (res.data.appType != 5) {
            let data = res.data.data;
            data.sort((a, b) => {
              if (a.name == 'master' && b.name != 'master') {
                return -1;
              } else if (a.name != 'master' && b.name == 'master') {
                return 1;
              } else if (!a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                return -1;
              } else if (a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                return 1;
              } else if (!a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                return a.name.localeCompare(b.name);
              } else if (a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                return a.name.localeCompare(b.name);
              }
            })
            this.tableList = res.data;

            //data替换为分支名称排序后的
            this.tableList.data = data;
          } else if (res.data.appType == 5) {
            let data = res.data.data;
            data.sort((a, b) => {
              return a.subAppId.localeCompare(b.subAppId);
            })
            res.data.data.forEach((subApp, index_i) => {
              if (subApp.branchBos.length > 0) {
                subApp.branchBos.forEach((oneBranch, index) => {
                  if (oneBranch.sourceBranch == 'master') {
                    subApp.branchBosidCommitId = oneBranch.commitId;
                    subApp.branchBosid = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                    subApp.branchBoCommitMsg = oneBranch.commitMsg;
                  }
                  oneBranch.commitIdWithIndex = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                })
              }
            })
            this.tableList = res.data;
            this.tableList.data = data;
          }

          this.correlationInfo.appId = this.tableList.appCode;
        } else {
          this.$message({
            message: res.msg,
            type: "warning"
          });
        }
      }).catch(_ => {
      });
    },


  }
}
</script>
<style lang="scss" scoped>
</style>
