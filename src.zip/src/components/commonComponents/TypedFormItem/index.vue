<template>
  <div>
    <!-- 单行文本框 -->
    <el-input v-if="type === 'SINGLE_TEXT' && !showFilterField" @change="updateModel" v-model="componentValue"></el-input>
    <!-- 多行富文本框 -->
    <el-input v-if="type === 'MULTI_TEXT' && !showFilterField" type="textarea" @change="updateModel" v-model="componentValue"></el-input>
    <!-- 成员选择框 -->
    <select-filter v-if="type === 'MEMBER_CHOICE' && !showFilterField" @change="updateModel" v-model="componentValue" 
     :selectList="selectList"></select-filter>
    <!-- 简单时间框 -->
    <custom-date v-if="type === 'LITE_DATE_ATTR' && !showFilterField" @change="updateModel" 
      v-model="componentValue"></custom-date>
    <!-- 时间区间框 -->
    <custom-date v-if="type === 'LITE_DATE_RANGE_ATTR' && !showFilterField" type="daterange" @change="updateModel" 
      v-model="componentValue"></custom-date>
    <!-- 布尔值选择框 -->
    <el-radio-group v-if="type === 'BOOLEAN_ATTR' && !showFilterField" @change="updateModel" v-model="componentValue">
      <el-radio :label="true">是</el-radio>
      <el-radio :label="false">否</el-radio>
    </el-radio-group>
    <!-- 整数输入框, 浮点数输入框 -->
    <el-input type="number" v-if="(type === 'INT_ATTR' || type === 'FLOAT_ATTR') && !showFilterField" 
      @change="updateModel" v-model.number="componentValue"></el-input>
    <!-- 单选框 -->
    <el-select v-if="type === 'SINGLE_CHOICE' && !showFilterField" @change="updateModel" v-model="componentValue">
      <el-option v-for="jtem in selectList" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
    </el-select>
    <!-- 多选框 -->
    <el-select v-if="type === 'MULTI_CHOICE' && !showFilterField" @change="updateModel" multiple v-model="componentValue">
      <el-option v-for="jtem in selectList" :label="jtem.value" :key="jtem.key" :value="jtem.key"></el-option>
    </el-select>
    <!-- 过滤器中：多选、全部、过滤 -->
    <select-filter v-if="showFilterField" multiple @change="handleSelectChange" v-model="componentValue" 
     :selectList="selectList">
      <el-option label="全部" value="all" slot></el-option>
     </select-filter>
  </div>
</template>
<script>
/**
 * @title 全局组件 - 动态字段组件
 * @desc 
 * @author heyunjiang
 * @date 
 */
export default {
  name: "TypedFormItem",
  components: {},
  model: {
    prop: 'value',
    event: 'change'
  },
  mixins: [],
  props: {
    value: { validator: (value) => { return true; } },
    type: {
      type: String,
      required: false,
      default: 'SINGLE_TEXT',
      desc: '字段类型，默认普通 input 框'
    },
    selectList: {
      type: Array,
      default: () => {
        return [];
      }
    },
    filterField: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否应用在过滤器中，过滤器中就需要全部是多选，并且拥有过全部这个 option'
    }
  },
  data() {
    return {
      componentValue: ''
    }
  },
  computed: {
    showFilterField() {
      return ['MEMBER_CHOICE', 'SINGLE_CHOICE', 'MULTI_CHOICE'].includes(this.type) && this.filterField;
    }
  },
  watch: {
    value() {
      this.generateValue();
    }
  },
  mounted() {
    this.generateValue();
  },
  methods: {
    generateValue() {
      this.componentValue = typeof this.value === 'undefined' ? this.$store.state.cm.customFieldInitTypeMap[this.type] : this.value;
    },
    updateModel(value) {
      this.$emit('change', value)
    },
    // 控制全选 select
    handleSelectChange(value) {
      // 如果最后一个选中了全部
      if (value[value.length - 1] === 'all') {
        this.componentValue = ['all']
      }
      // 如果不是最后一个选中了全部
      if (this.componentValue.includes('all') && this.componentValue.length > 1) {
        this.componentValue = this.componentValue.filter(item => item !== 'all')
      }
      this.$emit('change', this.componentValue)
    }
  }
}
</script>
<style lang="scss" scoped>

</style>
