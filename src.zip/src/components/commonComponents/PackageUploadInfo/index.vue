<template>
  <el-dialog
    title="包上传详情"
    :visible.sync="dialogVisible"
    class="el-dialog-1180w"
    :before-close="dialogClose"
    :modal-append-to-body="false"
    :close-on-click-modal="false"
  >
    <div>
      <div style="background:rgb(230, 233, 239);;padding-top:5px;">
        <div>
          <span class="fl mt5 ml5">包存储信息</span>
          <el-button type="primary" class="fr mr5 mb5" @click="refresh(1)">刷新</el-button>
        </div>
        <el-table :data="packageUploadList">
          <el-table-column prop="versionName" label="应用版本名称" min-width="150"></el-table-column>
          <el-table-column prop="idcName" label="机房名称" min-width="100"></el-table-column>
          <el-table-column prop="uploadEnv" label="上传环境" min-width="80"></el-table-column>
          <el-table-column label="上传状态" min-width="120">
            <template slot-scope="scope">
              <span>{{uploadStatusInfo[scope.row.uploadStatus]}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="uploadMsg" label="上传信息" min-width="120"></el-table-column>
          <el-table-column prop="startTime" label="开始时间" min-width="140"></el-table-column>
          <el-table-column label="结束时间" min-width="140">
            <template slot-scope="scope">
              <span>{{(scope.row.uploadStatus == 2 || scope.row.uploadStatus == 3) ? scope.row.endTime : ""}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="gitRepoUrl" label="操作" min-width="80">
            <template slot-scope="scope" v-if="scope.row.uploadStatus == '3'">
              <span class="c-blue cp" @click="reUpload(scope.row, 1)">重新上传</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="form-iterm-box" v-if="imageUploadHarbor">
      <div style="background:rgb(230, 233, 239);;padding-top:5px;">
        <div>
          <span class="fl mt5 ml5">镜像存储信息</span>
          <el-button type="primary" class="fr mr5 mb5" @click="refresh(2)">刷新</el-button>
        </div>
        <el-table :data="imageUploadList">
          <el-table-column prop="versionName" label="应用版本名称" min-width="150"></el-table-column>
          <el-table-column prop="uploadEnv" label="上传环境" min-width="80"></el-table-column>
          <el-table-column label="上传状态" min-width="120">
            <template slot-scope="scope">
              <span>{{uploadStatusInfo[scope.row.imageUploadStatus]}}</span>
            </template>
          </el-table-column>
          <el-table-column prop="imageUploadMsg" label="上传信息" min-width="120"></el-table-column>
          <el-table-column prop="gitRepoUrl" label="操作" min-width="80">
            <template slot-scope="scope" v-if="scope.row.imageUploadStatus == '3'">
              <span class="c-blue cp" @click="reUpload(scope.row, 2)">重新上传</span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button @click="dialogClose">关闭</el-button>
    </span>
  </el-dialog>
</template>
<script>
/**
 * @title 包上传详情组件
 * @desc 历史打包记录、镜像存储信息
 * @author heyunjiang
 * @date 2019.7.8
 */

export default {
  name: "PackageUploadInfo",
  components: {},
  mixins: [],
  props: {
    dialogVisible: {
      type: Boolean,
      required: true,
      desc: 'dialog 是否显示'
    },
    dialogClose: {
      type: Function,
      required: false,
      default: () => {},
      desc: '关闭dialog回调函数'
    }
  },
  data() {
    return {
      packageUploadList: [], // 包存储列表

      imageUploadList: [], // 镜像存储信息
      versionId: 0, // 当前查看的版本 id
      type: -1, // 用于控制需要展示的列表类型, type 为0 则全部更新 1 更新包存储信息 2 更新镜像上传信息
      loading: false,
      uploadStatusInfo: {
        '0': '新建',
        '1': '上传中',
        '2': '上传成功',
        '3': '上传失败'
      }
    }
  },
  computed: {
    // 是否展示镜像存储信息
    imageUploadHarbor() {
      return this.imageUploadList.length > 0;
    }
  },
  watch: {},
  created() {},
  methods: {
    // 初始化
    init(versionId, type) {
      this.versionId = versionId;
      this.type = type;
      this.imageUploadList = [];
      this.packageUploadList = [];
      this.loading = false;
      this.$nextTick(this.getUploadInfo)
    },
    // 获取/更新 包列表、镜像列表
    getUploadInfo(type = this.type) {
      if(this.versionId === 0) {return ;}
      this.loading = true;
      $http.get($http.api.appdate.api_app_version_upload_detail_list, { versionId: this.versionId }).then(res => {
        this.loading = false;
        if (res.status == 200) {
          if (type === 0 || type === 1) { // type 为0 则全部更新 1 更新包存储信息 2 更新镜像上传信息
            this.packageUploadList = res.data;
          }
          
          if (type === 0 || type === 2) {
            this.imageUploadList = res.data.filter(item => item.imageUploadStatus !== -1);
          }
        } else {
          this.$message({
            message: res.msg || '获取数据失败',
            type: "error"
          });
        }
      });
    },
    // 点击刷新
    refresh(type = this.type) {
      this.getUploadInfo(type)
    },
    // 点击重新上传
    reUpload(val, type) {
      this.loading = true;
      $http.post($http.api.appdate.api_app_version_upload_detail_re_upload, {
        versionId: val.versionId,
        id: val.id,
        type: type
      }).then(res => {
        this.loading = false;
        if (res.status == 200) {
          this.getUploadInfo(type);
        } else {
          this.$message({
            message: res.msg || '重新上传失败',
            type: "error"
          });
        }
      });
    },
  }
}
</script>
<style lang="scss" scoped>
</style>
