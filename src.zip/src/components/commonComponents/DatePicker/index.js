import DatePicker from './src/picker/date-picker';

/**
 * @title element-ui 2.4.11 日期组件
 * @function2 日期做周末、节假日标注功能
 * @author heyunjiang
 * @date 2019.8.20
 */
DatePicker.install = function install(Vue) {
  Vue.component(DatePicker.name, DatePicker);
};

export default DatePicker;
