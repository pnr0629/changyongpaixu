<template>
  <div>
    <person-edit v-if="projectId" :workItemId="workItemId" :workItemType="workItemType" @updata="initData" :projectId="projectId"></person-edit>
    <div class="comment-box" v-for="(item,index) in commentDataList" :key="index">
      <div class="comment-box-header">
        <div class="comment-box-header-person">{{item.createUserName}}&nbsp;({{(item.createUser)}})</div>
        <div class="comment-box-header-remark" v-if="item.remark">{{item.remark}}</div>
        <div class="comment-box-header-time">{{item.createTime}}</div>
        <div class="comment-box-header-index fr">#{{commentDataList.length-index }}</div>
      </div>
      <div class="comment-box-content" v-html="item.comment"></div>
    </div>
    <div class="fr comment-pagination">
      <el-pagination
        @size-change="handleCommentPageSizeChange"
        @current-change="handleCommentPageNumChange"
        v-if="commentDataList.length > 0"
        small
        :current-page="paginationInfo.pageNum"
        :page-sizes="[10, 20, 30]"
        :page-size="paginationInfo.pageSize"
        layout="prev, pager, next"
        :total="paginationInfo.total"
      ></el-pagination>
     
    </div>
  </div>
</template>
<script>
/**
 * @title 评论列表组件
 * @author heyunjiang
 * @date 2019.4.11
 */
import PersonEdit from './PersonEdit.vue'
export default {
  name: "CommentList",
  components:{
    PersonEdit
  },
  props: {
    workItemType: {
      type: [Number, String],
      required: true,
      desc: '类型，需求-1， 任务-2， 缺陷-3'
    },
    workItemId: {
      type: [Number, String],
      required: true,
      desc: 'id'
    },
    update: {
      type: Boolean,
      required: false,
      default: true,
      desc: '父组件更新这个值，即可更新列表数据，临时方法，找不到更好的解决方案'
    },
    projectId: {
      type: [Number, String]
    }
  },
  data() {
    return {
      paginationInfo: {
        pageNum: 1,
        pageSize: 20,
        total: 0
      },
      commentDataList: []
    };
  },
  watch: {
    workItemId() {
      this.initData()
    },
    workItemType() {
      this.initData()
    },
    update() {
      this.getCommentList()
    }
  },
  created() {
    this.initData()
  },
  methods: {
    // 初始化
    initData() {
      this.paginationInfo = {
        pageNum: 1,
        pageSize: 20,
        total: 0
      }
      this.$nextTick(this.getCommentList)
    },
    // 获取评论列表
    async getCommentList() {
      let obj = {
        workItemType: +this.workItemType,
        workItemId: +this.workItemId,
        pageNum: this.paginationInfo.pageNum,
        pageSize: this.paginationInfo.pageSize,
        projectId: +this.projectId
      }
      let data = await $http.get($http.api.comment.list, {...obj})
      if(data.status === 200) {
        this.commentDataList = data.data.list
        this.paginationInfo.total = data.data.total
        this.$emit('discussFun',data.data)
      } else {
        this.commentDataList = []
        this.paginationInfo.total = 0
      }
    },
    // 分页变化-pageSize
    handleCommentPageSizeChange(pageSize) {
      this.paginationInfo.pageSize = pageSize
      this.$nextTick(this.getCommentList)
    },
    // 分页变化-pageNum
    handleCommentPageNumChange(pageNum) {
      this.paginationInfo.pageNum = pageNum
      this.$nextTick(this.getCommentList)
    }
  }
};
</script>
<style lang="scss" scoped>
  @import '../../../base/style/common';
  .comment-box {
    margin-top: 10px;
    padding: 10px;
    background-color: $color-mo-bg-common;
    &:first-of-type {
      margin-top: 0;
    }
    .comment-box-header {
      color: rgb(153, 153, 153);
      div {
        display: inline-block;
      }
      .comment-box-header-remark,
      .comment-box-header-time {
        margin-left: 10px;
      }
    }
    .comment-box-content {
      margin: 10px 0;
      padding-left: 0;
      word-wrap:break-word;
      p{
        word-wrap:break-word;
      }
    }
  }
  .comment-pagination {
    margin-top: 10px;
  }
</style>
