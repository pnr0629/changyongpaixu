<template>
  <div id="comment-submit">
    <select-filter v-model="informant" multiple @focus="fous" @blur="blur" @change="informantFunc"
      placeholder="通知人" style="width: 400px" :selectList="assignUserData"></select-filter>
    <div class="top-tiny">
      <tiny-mce :value="comment" @watch="editComentLister($event)" :minHeigt='200' style="margin-top: 15px;"></tiny-mce>
    </div>
    <div id="bottom-tiny" @click="fousClick">
    </div>
    <el-button type="primary" @click="onSubmitComment" style="padding: 10px 40px;display: block;margin: 10px 0;">提交评论
    </el-button>
  </div>
</template>
<script>
  import TinyMce from "components/tool/tinymce";
  export default {
    name: 'PersonEdit',
    components: {
      TinyMce
    },
    props: {
      workItemType: {
        type: [Number, String],
        required: true,
        desc: '类型，需求-1， 任务-2， 缺陷-3'
      },
      workItemId: {
        type: [Number, String],
        required: true,
        desc: 'id'
      },
      projectId: {
        type: [Number, String],
      }
    },
    data() {
      return {
        assignUserData: [],//项目内所有成员
        informant: [],//通知人
        comment: ""//评论数据
      }
    },
    watch:{
      workItemId(){
        this.comment ="";
        this.informant = [];
      }
    },
    mounted() {
      this.assignUsersList()
    },
    methods: {

      fousClick() {
        document.getElementById("bottom-tiny").style.display = 'none'
      },
      fous() {
        document.getElementById("bottom-tiny").style.display = 'block'
      },
      blur() {
        document.getElementById("bottom-tiny").style.display = 'block'
      },
      assignUsersList(query) {
        let projectId = this.projectId;
        $http.post($http.api.bug_info.assignUsersList, { projectId, query: query ? query : '' }).then(res => {
          this.assignUserData = res.data.map(item => {
            return {
              ...item,
              key: item.userId,
              value: item.userName + '(' + item.userId + ')'
            }
          });
        })
      },
      //评论通知人搜索
      remoteMethod(query) {
        this.query = query;
        this.assignUsersList(query);
      },
      //
      informantFunc() {
        // console.log(this.fieldEditObject.assignUser.selectValue)
      },
      //编辑评论tinymce返回数据
      editComentLister(data) {
        this.comment = data;
      },
      //提交评论
      onSubmitComment() {
        if (this.comment.trim() != "") {
          $http.post($http.api.comment.add, {
            workItemType: this.workItemType,
            workItemId: this.workItemId,
            comment: this.comment.trim(),
            projectId: this.projectId,
            workNumberIds: this.informant,
            workItemUrl: window.location.href
          }).then(res => {
            this.comment = "";
            this.informant = [];
            if (res.status === 200) {
              this.$emit('updata')
            } else {
              this.$message({ type: 'error', message: res.msg })
            }
          });
        }else{
          this.$message({type:'warning',message:"内容不能为空"})
        }
      },
    },
  }
</script>
<style lang="scss" scoped>
  .tinymce-editor {
    min-height: 200px;
  }

  #comment-submit {
    position: relative;
  }

  #bottom-tiny {
    display: none;
    height: 200px;
    opacity: 0.5;
    height: 200px;
    /* opacity: -0.5; */
    background: #000;
    opacity: 0;
    position: absolute;
    top: 43px;
    z-index: 1300;
    width: 100%;
  }
</style>