<template>
  <div>
    <div class="title-detaile">部署历史</div>
    <el-table key="deployHistoryTable" :data="deploy_history_list.result">
      <el-table-column prop="appVersion" label="版本名称" min-width="200"></el-table-column>
      <el-table-column prop="ip" label="发布机器" min-width="120"></el-table-column>
      <el-table-column prop="instanceId" label="实例id" min-width="120"></el-table-column>
      <el-table-column prop="confEnv" label="配置环境" min-width="120"></el-table-column>
      <el-table-column prop="confVersion" label="配置版本" min-width="120"></el-table-column>
      <el-table-column prop="operator" label="操作人" min-width="120"></el-table-column>
      <el-table-column label="操作时间" min-width="140">
        <template slot-scope="scope">
          <span>{{scope.row.deployTime?scope.row.deployTime.substring(0,16):''}}</span>
        </template>
      </el-table-column>
      <el-table-column label="部署结果" min-width="100">
        <template slot-scope="scope">
          <span :class="scope.row.result?'':'c-red'">{{scope.row.result?'SUCCESS':'FAIL'}}</span>
          <el-tooltip class="item" placement="top">
            <div slot="content" v-if="!scope.row.result" v-html="getFailMsg(scope.row)"></div>
            <i class="el-icon-warning" v-if="!scope.row.result"></i>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column label="操作" min-width="130px">
        <template slot-scope="scope">
          <span class="c-blue cp" @click="getPaaSLogLink(scope.row,true)">部署日志</span>
          <span
            class="c-blue cp"
            style="margin-left: 4px"
            @click="getPaaSLogLink(scope.row,false)"
          >实例日志</span>
        </template>
      </el-table-column>
    </el-table>
    <div class="table_b_f_b">
      <el-pagination
        class="fr mr10"
        style="margin-top: 9px;"
        :current-page="deploy_history_list.pageNum"
        :page-sizes="[5, 10, 15]"
        :page-size="deploy_history_list.pageSize"
        @current-change="handleDeployHistoryPageChange"
        @size-change="handleDeployHistorySizeChange"
        layout="total, sizes, prev, pager, next, jumper"
        :total="deploy_history_list.total"
      ></el-pagination>
    </div>
    <el-dialog
      title="部署日志"
      class="el-dialog-1200w"
      :visible.sync="deployLogDialogVisible"
      :before-close="handleCloseDeployLog"
      :modal-append-to-body="false"
    >
      <div>
        <div style="height: 100%;overflow:auto;overflow-x:hidden;">
          <iframe
            :src="deployLogSrc"
            width="100%"
            :height="logHeight"
            style="background: white"
            frameborder="no"
            border="0"
            id="logIFrame"
          ></iframe>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 部署历史 table
 * @desc
 * @author heyunjiang
 * @date
 */
export default {
  name: "DeployLogTable",
  components: {},
  mixins: [],
  props: {
    deploy_history_list: {
      type: Object,
      required: true,
      desc: '发布历史 table 数据，包含分页信息'
    },
    currentSelectedWorkflow: {
      type: Object,
      required: true,
      desc: '当前活跃的 task'
    },
  },
  data() {
    return {
      deployLogSrc: '',
      logHeight: '',
      deployLogDialogVisible: false,
    }
  },
  computed: {},
  watch: {},
  created() { },
  methods: {
    getFailMsg(item) {
      return item.msg ? item.msg.replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>") : "";
    },
    // 获取部署日志 iframe url
    getPaaSLogLink(deploy, isDeployLog) {
      let params = {
        appId: this.getUrlAppId(),
        instanceId: deploy.instanceId,
        env: deploy.env
      };
      if (isDeployLog) {
        params.deployId = deploy.id;
        this.logHeight = "615px";
      } else {
        this.logHeight = "650px";
      }
      $http.post($http.api.appdate.getPaaSLogLink, params, { type: 'form' }).then(res => {
        this.deployLogSrc = res.data;
        this.deployLogDialogVisible = true;
      })
    },
    // 关闭部署日志窗口
    handleCloseDeployLog() {
      this.deployLogDialogVisible = false;
      this.deployLogSrc = null;
    },
    handleDeployHistoryPageChange(newPageNum) {
      this.$emit('handleDeployHistoryPageChange', {newPageNum})
    },
    handleDeployHistorySizeChange(newPageSize) {
      this.$emit('handleDeployHistoryPageChange', {newPageNum})
    }
  }
}
</script>
<style lang="scss" scoped>
  .title-detaile {
    color: #544c4c;
    font-size: 14px;
    font-weight: 700;
    margin-top: 10px;
    height: 30px;
  }
</style>
