<template>
  <div class="stage-box">
    <div class="stage-item" v-for="(item,index) in stageRunningVoList" :key="item.id">
      <div
        class="box-card"
        @click="stageClick(item.id)"
        :class="{'active':item.id == currentSelectedStage.id}"
      >
        <div class="box-card-title">{{item.name}}</div>
        <el-progress
          type="circle"
          :percentage="item.percentage"
          class="mt20"
          :width="100"
          color="#67C23A"
          status="text"
        >
          <span v-html="item.desc"></span>
        </el-progress>
        <div class="circle-time" v-if="item.executeTime>0">{{item.executeTime}}秒</div>
        <span :class="{'triangle':item.id == currentSelectedStage.id}"></span>
        <span :class="{'triangle2':item.id == currentSelectedStage.id}"></span>
      </div>
      <div class="box-card-arrow" v-if="index != stageRunningVoList.length-1">→</div>
    </div>
  </div>
</template>
<script>
/**
 * @title 阶段过渡
 * @desc
 * @author heyunjiang
 * @date
 */
export default {
  name: "StageFlow",
  components: {},
  mixins: [],
  props: {
    stageRunningVoList: {
      type: Array,
      required: true,
      desc: 'stage 运行时的 vo 信息'
    },
    currentSelectedStage: {
      type: Object,
      required: true,
      desc: '当前运行中/选中的 stage 信息'
    }
  },
  data() {
    return {};
  },
  computed: {},
  watch: {},
  created() {},
  methods: {
    stageClick(id) {
      this.$emit('stageClick', id);
    }
  }
};
</script>
<style lang="scss" scoped>
  .stage-box {
    max-height: 230px;
    overflow-x: auto;
    overflow-y: hidden;
    white-space: nowrap;
    padding-bottom: 10px;
    // background: rgba(243, 246, 252, 0.7);
    // padding: 10px;
    .stage-item {
      width: 320px;
      height: 180px;
      display: inline-block;
      color: #606266;
      margin-left: 10px;
      cursor: pointer;
      &:first-of-type {
        margin-left: 0;
      }
      // 盒子
      .box-card {
        width: 270px;
        height: 150px;
        padding: 10px;
        display: inline-block;
        border: 2px solid #d6d9e0;
        .box-card-title {
          border-bottom: 2px solid #d6d9e0;
          padding-bottom: 8px;
        }
        .circle-time {
          width: 80px;
          height: 40px;
          float: right;
          margin-top: 58px;
          font-size: 18px;
          font-weight: 600;
          color: #606266;
        }
        .triangle {
          width: 0px;
          height: 0px;
          border: 10px solid #409EFF;
          border-top-color: #409EFF;
          border-bottom-color: transparent;
          border-left-color: transparent;
          border-right-color: transparent;
          position: relative;
          top: 38px;
          left: -10px;
        }
        .triangle2 {
          width: 0px;
          height: 0px;
          border: 8px solid #F2F6FC;
          border-top-color: #F2F6FC;
          border-bottom-color: rgba(200, 200, 200, 0);
          border-right-color: rgba(200, 200, 200, 0);
          border-left-color: rgba(200, 200, 200, 0);
          position: relative;
          top: 34px;
          left: -28px;
        }
      }
      .box-card.active {
        border: 2px solid #409EFF;
        box-shadow: 0 0 10px #409EFF;
      }
      // 箭头
      .box-card-arrow {
        width: 40px;
        height: 180px;
        display: inline-block;
        vertical-align: top;
        line-height: 210px;
        font-size: 26px;
        padding-bottom: 2px;
      }
    }
  }
</style>
