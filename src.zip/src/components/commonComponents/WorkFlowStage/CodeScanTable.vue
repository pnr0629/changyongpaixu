<template>
  <div>
    <div
      style="height:100%;"
      class="common-table-box"
      v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.CODE_SCANNING) && ifCurrentWorkflowTypeCodeScanningFindBugs()"
    >
      <span class="common-table-title">代码扫描(FindBugs)执行详情</span>
      <el-table key="codeScanResultTable" :data="find_bugs_result_list.list">
        <el-table-column prop="name" label="名称" min-width="120"></el-table-column>
        <el-table-column label="负责人" min-width="120">
          <template slot-scope="scope">
            <span>{{scope.row.createUserName + '(' + scope.row.createUser + ')'}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="startTime" label="开始时间" min-width="120"></el-table-column>
        <el-table-column prop="during" label="运行时间" min-width="120"></el-table-column>
        <el-table-column align="left" prop="confVersion" label="扫描结果" min-width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.scanResult != null">
              <div>{{'总共：' +( scope.row.scanResult.totalWarnings!=null? scope.row.scanResult.totalWarnings:'')}}</div>
              <div>{{'高危：' + (scope.row.scanResult.highPriorityWarnings!=null?scope.row.scanResult.highPriorityWarnings:'')}}</div>
              <div>{{'中危：' + (scope.row.scanResult.mediumPriorityWarnings!=null?scope.row.scanResult.mediumPriorityWarnings:'')}}</div>
              <div>{{'低危：' + (scope.row.scanResult.lowPriorityWarnings!=null?scope.row.scanResult.lowPriorityWarnings:'')}}</div>
            </span>
          </template>
        </el-table-column>
        <el-table-column prop="status" label="状态" min-width="60">
          <template slot-scope="scope">
            <span>{{scope.row.status!= null?innerface_status_findings[scope.row.status.toLowerCase()]:'未开始'}}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" min-width="140">
          <template slot-scope="scope">
            <span
              class="c-blue cp"
              @click="openUrlInNewWindow(scope.row.jenkinsLog)"
              v-if="scope.row.status != null"
            >运行日志</span>
            <span
              class="c-blue cp"
              @click="openUrlInNewWindow(scope.row.reportDetailUrl)"
              v-if="scope.row.status == null||scope.row.status != WORKFLOW_TASK_STATUS.RUNNING"
            >运行详情</span>
            <span
              class="c-blue cp"
              @click="openUrlInNewWindow(scope.row.reportUrl)"
              v-if="scope.row.status == null||scope.row.status != WORKFLOW_TASK_STATUS.RUNNING"
            >报告</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- ======================================== -->
    <div
      style="height:100%;"
      class="common-table-box"
      v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.CODE_SCANNING) && ifCurrentWorkflowTypeCodeScanningSonarQube()"
    >
      <span class="common-table-title">代码扫描(SonarQube)执行详情</span>
      <el-table key="codeScanResultTable" :data="sonarqube_result_list.list">
        <el-table-column prop="projectKey" label="项目Key" min-width="120"></el-table-column>
        <el-table-column prop="projectName" label="项目名称" min-width="120"></el-table-column>
        <el-table-column prop="taskCurrentStage" label="任务所处阶段" min-width="120"></el-table-column>
        <el-table-column prop="status" label="任务状态" min-width="120"></el-table-column>
        <el-table-column prop="qualityGateStatus" label="扫描结果" min-width="120"></el-table-column>
        <el-table-column prop="totalTime" label="总耗时" min-width="120"></el-table-column>
        <el-table-column label="操作" min-width="120">
          <template slot-scope="scope">
            <span
              class="c-blue cp"
              @click="openUrlInNewWindow(scope.row.projectUrl)"
              v-if="scope.row.projectUrl"
            >报告</span>
          </template>
        </el-table-column>
      </el-table>
    </div>


    <div style="height:100%;"
         v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.CODE_SCANNING) && ifCurrentWorkflowTypeCodeScanSafetyScan()">
                <span class="title-detaile">
                    安全扫描(SecurityScan)执行详情
                </span>
      <el-table :data="safety_scan_result_list.list" key="codeScanResultTable" :default-sort = "{prop: 'scanResult.ts', order: 'descending'}">
        <el-table-column label="任务名称">
          <template slot-scope="scope">
            <div v-if="scope.row.scanResult">{{scope.row.scanResult.taskName != null ? scope.row.scanResult.taskName : ""}}</div>
          </template>
        </el-table-column>
        <el-table-column label="任务完成时间" sortable prop = "scanResult.ts">
          <template slot-scope="scope">
            <div v-if="scope.row.scanResult">{{dateFormat(scope.row.scanResult.ts)}}</div>
          </template>
        </el-table-column>
        <el-table-column label="安全扫描任务ID">
          <template slot-scope="scope">
            <div v-if="scope.row.scanResult">{{scope.row.scanResult.taskId != null ? scope.row.scanResult.taskId : ""}}</div>
          </template>
        </el-table-column>
        <el-table-column label="文件数量">
          <template slot-scope="scope">
            <div v-if="scope.row.scanResult">{{scope.row.scanResult.fileNum != null ? scope.row.scanResult.fileNum : ""}}</div>
          </template>
        </el-table-column>
        <el-table-column label="扫描行数">
          <template slot-scope="scope">
            <div v-if="scope.row.scanResult">{{scope.row.scanResult.rowNum != null ? scope.row.scanResult.rowNum : ""}}</div>
          </template>
        </el-table-column>
        <el-table-column label="扫描语言">
          <template slot-scope="scope">
            <div v-if="scope.row.scanResult">{{languageFormat(scope.row.scanResult.language)}}</div>
          </template>
        </el-table-column>
        <el-table-column label="扫描结果">
          <template slot-scope="scope" v-if="scope.row.scanResult">
            <div>
                        <span style="color:#F56C6C">高危缺陷数：{{scope.row.scanResult.bugNumSerious != null
                        ? scope.row.scanResult.bugNumSerious : ""}}
                      </span>
            </div>
            <div>
                        <span style="color:#E6A23C">中级缺陷数：{{scope.row.scanResult.bugNumMedium != null
                        ? scope.row.scanResult.bugNumMedium : ""}}
                      </span>
            </div>
            <div>
                        <span style="color:#67C23A">低级缺陷数：{{scope.row.scanResult.bugNumLow != null
                        ? scope.row.scanResult.bugNumLow : ""}}
                      </span>
            </div>
            <div>
              <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.scanResult.downloadPath)">报告</span>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- ======================================== -->
  </div>


</template>
<script>
  /**
   * @title 代码扫描模块
   * @desc
   * @author heyunjiang
   * @date 2019.7.3
   */
  const innerface_status_findings = {
    'failure': '失败',
    'success': '成功',
    'running': '执行中'
  }
  export default {
    name: "CodeScanTable",
    components: {},
    mixins: [],
    props: {
      currentSelectedWorkflow: {
        type: Object,
        required: true,
        desc: '当前活跃的 task'
      },
      find_bugs_result_list: {
        type: Object,
        required: true,
        desc: '代码扫描 find bugs'
      },
      sonarqube_result_list: {
        type: Object,
        required: true,
        desc: '代码扫描 find bugs'
      },
      safety_scan_result_list: {
        type: Object,
        required: true,
        desc: '代码扫描 safety scan'
      }
    },
    data() {
      return {
        WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
        WORKFLOW_TASK_STATUS: GLOBAL_CONST.WORKFLOW_TASK_STATUS,
        CODE_SCANNING_TYPE: GLOBAL_CONST.CODE_SCANNING_TYPE,
      }
    },
    computed: {},
    watch: {},
    created() {
    },
    methods: {
      // 辅助 - 当前任务是否有如下 type
      ifCurrentWorkflowTypeIn(arr) {
        if (this.currentSelectedWorkflow.task) {
          return arr.indexOf(this.currentSelectedWorkflow.task.type) > -1
        }
        return false;
      },
      // 辅助 - 当前任务是否属于代码扫描 qube
      ifCurrentWorkflowTypeCodeScanningSonarQube() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting && setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE) {
              return true;
            }
          }
        }
        return false;
      },
      // 辅助 - 当前任务是否属于代码扫描 findbugs
      ifCurrentWorkflowTypeCodeScanningFindBugs() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting && setting.taskType == this.CODE_SCANNING_TYPE.FIND_BUGS) {
              return true;
            }
          }
        }
        return false;
      },

      ifCurrentWorkflowTypeCodeScanSafetyScan() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting && setting.taskType == this.CODE_SCANNING_TYPE.SAFETY_SCAN) {
              return true;
            }
          }
        }
        return false;
      },

      dateFormat(timeStamp){
        var date = new Date(timeStamp * 1000);
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var hour = this.timeFormat(date.getHours());
        var minutes = this.timeFormat(date.getMinutes());
        var seconds = this.timeFormat(date.getSeconds())
        return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
      },

      timeFormat(time){
        if(time < 10){
          return "0" + time;
        }
        return time;
      },

      languageFormat(language){
        var language = "Java";
        switch(language){
          case 0:
            language = "Java";
            break;
          case 1:
            language= "C/C++";
            break;
          case 2:
            language = "C#";
            break;
          case 3:
            language = "Python";
            break;
          case 4:
            language = "PHP";
            break;
          case 5:
            language = "Objective-C";
            break;
          case 6:
            language = "Cobol";
            break;
          case 9:
            language = "NodeJS";
            break;
          case 15:
            language = "Swift";
            break;
          default:
            break;
        }
        return language;
      },

      //新窗口打开页面
      openUrlInNewWindow(val) {
        val && window.open(val);
      },
    }
  }
</script>
<style lang="scss" scoped>
  .common-table-box {
    padding: 10px;
    background-color: #ecf1f0;
    margin-top: 10px;

    .common-table-title {
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 5px;
      // text-align: center;
    }
  }
</style>
