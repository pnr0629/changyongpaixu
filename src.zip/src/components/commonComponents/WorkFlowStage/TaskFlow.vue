<template>
  <div class="task-flow-box">
    <div class="circle-line" v-for="(item,index) in currentSelectedWorkflowList" :key="item.id">
      <div class="circle-head"
        @click="workflowClick(item.id)"
        :class="{'circle-active':item.id == currentSelectedWorkflow.id}"
        v-html="item.task.showName"
      ></div>
      <span :class="{'triangleBtn':item.id == currentSelectedWorkflow.id}"></span>
      <span :class="{'triangleBtn2':item.id == currentSelectedWorkflow.id}"></span>
      <div
        class="line-head"
        v-if="currentSelectedWorkflowList.length-1  != index"
        :style="{'margin-left':item.id == currentSelectedWorkflow.id?'-40px':'-4px'}"
      ></div>
    </div>
  </div>
</template>
<script>
/**
 * @title 任务过渡
 * @desc
 * @author heyunjiang
 * @date
 */
export default {
  name: "TaskFlow",
  components: {},
  mixins: [],
  props: {
    currentSelectedWorkflowList: {
      type: Array,
      required: true,
      desc: '当前选中 stage 下面的 task list'
    },
    currentSelectedWorkflow: {
      type: Object,
      required: true,
      desc: '当前选中的 task'
    }
  },
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() { },
  methods: {
    workflowClick(id) {
      this.$emit('workflowClick', id);
    }
  }
}
</script>
<style lang="scss" scoped>
  .task-flow-box {
    min-height: 50px;
    padding-top: 10px;
    overflow-y: hidden;
    white-space: nowrap;
  }
  .circle-line {
    display: inline-block;
    .circle-head {
      height: 30px;
      min-width: 60px;
      padding-left: 5px;
      padding-right: 5px;
      border: 2px solid #d6d9e0;
      display: inline-block;
      text-align: center;
      line-height: 25px;
      margin-bottom: 10px;
      border-radius: 5px;
      cursor: pointer;
    }
    .circle-head.circle-active {
      border: 2px solid #409eff;
      box-shadow: 0 0 10px #409eff;
    }
    .triangleBtn {
      width: 0;
      height: 0;
      border: 10px solid #409eff;
      border-top-color: #409eff;
      border-bottom-color: transparent;
      border-left-color: transparent;
      border-right-color: transparent;
      position: relative;
      top: 38px;
      right: 50px;
    }
    .triangleBtn2 {
      width: 0;
      height: 0;
      border: 8px solid #f2f6fc;
      border-top-color: #fff;
      border-bottom-color: hsla(0,0%,78%,0);
      border-right-color: hsla(0,0%,78%,0);
      border-left-color: hsla(0,0%,78%,0);
      position: relative;
      top: 34px;
      right: 68px;
    }
    .line-head {
      height: 2px;
      width: 100px;
      background: #d6d9e0;
      display: inline-block;
      vertical-align: text-top;
      margin-top: 10px;
    }
  }
</style>
