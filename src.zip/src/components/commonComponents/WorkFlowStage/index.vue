<template>
  <div>
    <div class="pipeline-flow-box">
      <stage-flow
        :stageRunningVoList="stageRunningVoList"
        :currentSelectedStage="currentSelectedStage"
        @stageClick="stageClick"
        v-show="inited"
      ></stage-flow>
      <task-flow
        :currentSelectedWorkflowList="currentSelectedWorkflowList"
        :currentSelectedWorkflow="currentSelectedWorkflow"
        @workflowClick="workflowClick"
        v-show="inited"
      ></task-flow>
      <task-log-table
        :lastWorkflowOperation="lastWorkflowOperation"
        :deployInfo="deployInfo"
        :currentSelectedWorkflow="currentSelectedWorkflow"
        :containsAppVersion="containsAppVersion"
        :appVersionInfo="appVersionInfo"
        @doExecuteWorkflow="doExecuteWorkflow"
        @stopTaskExecute="stopTaskExecute"
        v-show="lastWorkflowOperation.length > 0"
      ></task-log-table>
    </div>
    <slot></slot>
    <!-- ==================================== -->
    <div
      style="min-height:40px;"
      class="pipeline-flow-box common-table-box"
      v-if="ifCurrentWorkflowTypeIn([WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT, WORKFLOW_TASK_TYPE.SUBMIT_TEST, WORKFLOW_TASK_TYPE.PASS_TEST])"
    >
      <div class="title-detaile">可操作人信息</div>
      <el-tag type="info">{{operatorInfo}}</el-tag>
    </div>
    <deploy-log-table
      :deploy_history_list="deploy_history_list"
      :currentSelectedWorkflow="currentSelectedWorkflow"
      @handleDeployHistoryPageChange="handleDeployHistoryPageChange"
      class="pipeline-flow-box common-table-box"
      v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.DEPLOY)"
    ></deploy-log-table>
    <code-scan-table
      :currentSelectedWorkflow="currentSelectedWorkflow"
      :find_bugs_result_list="find_bugs_result_list"
      :sonarqube_result_list="sonarqube_result_list"
      :safety_scan_result_list="safety_scan_result_list"
    ></code-scan-table>
  </div>
</template>
<script>
/**
 * @title 流水线构建组件，内部 4 个组件可独立运行，需要动态传入 prop
 * @desc 用于从构建到部署过程中，每个阶段任务执行切换，复用的是 appVersionPipline.vue 中的逻辑，有修改
 * @function 暴露出去的实例方法有 init() ，用于启动展示流水线构建、部署相关信息
 * @author heyunjiang
 * @date 2019.7.2
 */
import StageFlow from "./StageFlow";
import TaskFlow from "./TaskFlow";
import TaskLogTable from "./TaskLogTable"
import DeployLogTable from "./DeployLogTable"
import CodeScanTable from "./CodeScanTable"
export default {
  name: "WorkFlowStage",
  components: {
    StageFlow,
    TaskFlow,
    TaskLogTable,
    DeployLogTable,
    CodeScanTable
  },
  mixins: [],
  props: {},
  data() {
    return {
      WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
      WORKFLOW_TRIGGER_TYPE: GLOBAL_CONST.WORKFLOW_TRIGGER_TYPE,
      STAGE_STATUS: GLOBAL_CONST.STAGE_STATUS,
      WORKFLOW_TASK_STATUS: GLOBAL_CONST.WORKFLOW_TASK_STATUS,
      TRANSFER_TYPE: GLOBAL_CONST.TRANSFER_TYPE,
      EXECUTE_TYPE: GLOBAL_CONST.EXECUTE_TYPE,
      CODE_SCANNING_TYPE: GLOBAL_CONST.CODE_SCANNING_TYPE,

      pipelineName: '', // 流水线名称
      workflowId: 0, // 流水线对应的 trigger id
      stageRunningDetailLst: [], // 流水线 stage 及 task 运行信息
      stageRunningVoList: [], // 流水线 stage 及 task 的 VO 运行信息，增加了一些运行时的信息
      stageList: [], // 流水线阶段及子任务基本信息
      appVersionInfo: {}, // app 基本信息
      inited: false, // 是否已经在跑流水线了
      workflowAutoTransfer: true, // 当前 task 是否可以自动流转
      currentSelectedWorkflow: {}, // 当前选中的 task 信息
      currentSelectedStage: {}, // 当前选中的 stage 信息
      containsAppVersion: false,
      lastWorkflowOperation: [], // 当前 task 状态 table
      deployInfo: '', // 任务类型 table 的 tooltip
      operatorInfo: '',    //人工卡点等类型的操作信息 - 可能没有什么用
      deploy_history_list: {
        pageNum: 1,
        pageSize: 5,
        total: 0,
        result: []
      }, // 部署历史 table 内容
      find_bugs_result_list: {
        pageNum: 1,
        pageSize: 5,
        total: 0,
        list: []
      }, // 代码扫描结果 find_bugs table 内容
      sonarqube_result_list: {
        pageNum: 1,
        pageSize: 5,
        total: 0,
        list: []
      }, // 代码扫描结果 safety scan 内容
      safety_scan_result_list: {
        pageNum: 1,
        pageSize: 5,
        total: 0,
        list: []
      },
      currentWorkflowInterval: null, // task interval 事件句柄
      currentPipelineInterval: null, // 更新任务对应 table 状态句柄
    };
  },
  computed: {
    // 流水线任务 map, id-名称
    pipelineTaskMap() {
      let tempWorkflowMap = {}
      this.stageList.forEach((stage) => {
        stage.pipelineTaskLst.forEach((pipelineTask) => {
          tempWorkflowMap[pipelineTask.id] = pipelineTask
        })
      })
      return tempWorkflowMap;
    },
    currentSelectedWorkflowList() {
      return this.currentSelectedStage.workflowTaskLst || [];
    },
    // 真实的最新任务节点
    pipelineWorkflow() {
      let temp
      this.stageRunningDetailLst.some((stageRunning) => {
        temp = stageRunning.workflowTaskLst.find((workflow) => {
          return this.ifWorkflowCurrent(workflow);
        })
        if (temp && temp.id) {
          return true;
        }
      })
      return temp;
    }
  },
  watch: {
    currentSelectedWorkflow(newWorkflow, oldWorkflow) {
      if(!newWorkflow.id) {return ;}
      this.refreshWorkflow();
    },
  },
  created() { },
  beforeDestroy: function () {
    this.currentPipelineInterval && clearInterval(this.currentPipelineInterval);
    this.currentWorkflowInterval && clearInterval(this.currentWorkflowInterval);
  },
  methods: {
    init(workflowId, pipelineId) {
      this.inited = false;
      this.stageList = [];
      this.stageRunningDetailLst = [];
      this.stageRunningVoList = [];
      this.currentSelectedStage = {}; //当前选中的stage
      this.currentSelectedWorkflow = {};
      this.workflowAutoTransfer = true;

      this.pipelineName = "";
      this.appVersionInfo = {};
      this.containsAppVersion = false;

      this.workflowId = workflowId;

      this.$nextTick(() => {
        this.getVersionPipelineOverview(workflowId, pipelineId)
      })
    },
    // 执行 - 再次执行当前任务、流转到下一阶段，只有在任务状态 table 中才能调用该方法
    doExecuteWorkflow() {
      if (this.pipelineWorkflow && this.currentSelectedWorkflow && this.pipelineWorkflow.id == this.currentSelectedWorkflow.id) {
        this.workflowAutoTransfer = true;
      }
      let formData = new FormData();
      formData.set('workflowId', this.currentSelectedWorkflow.workflowId);
      formData.set('workflowTaskId', this.currentSelectedWorkflow.id);
      $http.post($http.api.appdate.apipipelineexecute, formData).then(res => {
        this.currentSelectedWorkflow.workflowTaskStatus = this.WORKFLOW_TASK_STATUS.RUNNING; // 重置当前任务状态，方便后续调用循环
        this.$emit('initLog')// 重置当前任务日志
        this.refreshWorkflow(); // 开始渲染任务对应的基本信息
        // 获取流水线 stage 信息，调用 reGenerateStageRunningVo 生成 vo 信息
        this.getPipelineDetail();
        this.$message({
          message: '执行指令已发送',
          type: 'info'
        })
      });
    },
    // 执行 - 停止执行
    stopTaskExecute(val) {
      if (val.manualStop == 1) {
        return false;
      }

      this.workflowAutoTransfer = false;
      let formData = new FormData();
      formData.set('workflowId', this.currentSelectedWorkflow.workflowId);
      formData.set('workflowTaskId', this.currentSelectedWorkflow.id);
      if (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.AUTO_TEST) {
        formData.set('updateStatus', 'true');
      }

      $http.post($http.api.pipeline.stopWorkflowTask, formData).then(res => {
        this.$message({
          message: '停止指令已发送，请等待任务停止执行',
          type: 'info'
        });
      });
    },
    // 查询 - 流水线概要信息
    getVersionPipelineOverview(workflowId, pipelineId) {
      let url = $http.api.pipeline.workflowExecOverview;
      let param = { workflowId };

      if (pipelineId) {
        url = $http.api.feature_branch.pipelineOverview;
        param = { pipelineId };
      }

      $http.get(url, param).then(res => {
        if (res.status == 200) {
          this.pipelineName = res.data.pipelineDTO.name;
          this.stageRunningDetailLst = res.data.stageRunningDetailsLst;
          this.stageList = res.data.pipelineDTO.stageLst;
          // 更新 stage 和 task 状态，实现自动流转
          this.reGenerateStageRunningVo(res.data.stageRunningDetailsLst);

          if (this.inited) { return; }
          this.inited = true;

          if (res.data.appVersionInfo != "") {
            this.appVersionInfo = JSON.parse(res.data.appVersionInfo);
            this.containsAppVersion = true;
          }

          // 找出当前应该选中的 stage 和 workflow，即正在运行的一个或者最后一个
          this.stageRunningVoList.some((stageRunningVo, index) => {
            if (stageRunningVo.stageRunningStatus != this.STAGE_STATUS.SUCCESS || index == this.stageRunningVoList.length - 1) {
              this.currentSelectedStage = stageRunningVo;
              stageRunningVo.workflowTaskLst.some((workflow, wIndex) => {
                // 完成流转未执行或者完成成功流转不成功
                if (this.ifWorkflowCurrent(workflow) || wIndex == stageRunningVo.workflowTaskLst.length - 1) {
                  this.currentSelectedWorkflow = workflow;
                  return true;
                }
              });
              return true;
            }
          });
        } else {
          this.$message({
            message: res.msg || '获取构建信息失败',
            type: "warning"
          });
        }
      });
    },
    // 查询 - 流水线 stage 的运行信息
    getPipelineDetail() {
      if (!this.workflowId || this.workflowId <= 0) {
        this.workflowId = this.currentSelectedWorkflow.workflowId;
      }
      // console.log(this.workflowId)
      if(this.workflowId && this.workflowId > 0){
        $http.get($http.api.pipeline.stagesExecOverview, { workflowId: this.workflowId }).then(res => {
          this.stageRunningDetailLst = res.data;
          this.reGenerateStageRunningVo(res.data)
        })
      }
    },
    // 查询 - task 状态操作信息（当前只有最后一次）
    getWorkflowTaskDetail(val) {
      $http.get($http.api.appdate.apipipelineexectaskdetails, { workflowTaskId: val }).then(res => {
        let detail = res.data;
        // 如果任务执行过程中生成了版本，则需要更新全局的版本信息
        if(detail.result && detail.result.length > 0 && !this.containsAppVersion) {
          try {
            const versionInfo = JSON.parse(detail.result);
            if(versionInfo.versionId) {
              this.appVersionInfo = versionInfo;
              this.containsAppVersion = true;
            }
          } catch (e) {
            console.log(e)
          }
        }
        this.lastWorkflowOperation = [
          {
            workflowTaskType: this.currentSelectedWorkflow.task.type,
            workflowTaskTypeName: this.getWorkflowTaskTypeName(this.currentSelectedWorkflow.task.type),
            startTime: detail.startTime,
            transferType: this.getTransferTypeDesc(detail.transferType),
            executeType: (this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.autoExec) ? '自动触发' : '手动触发',
            triggerUser: detail.triggerUser ? (detail.triggerUserName + '(' + detail.triggerUser + ')') : '-',
            workflowTaskStatus: detail.workflowTaskStatus,
            showStatus: this.getWorkflowTaskStatus(detail.workflowTaskStatus, this.currentSelectedWorkflow.task.type),
            errorMsg: detail.errorMsg,
            result: detail.result,
            executeName: this.getExecuteName(detail),
            stopName: this.getStopName(detail),
            manualStop: detail.manualStop,
          }
        ]
      });
    },
    // 查询 - 部署历史信息
    getDeployHistory(params) {
      $http.get($http.api.appdate.apiinstancedeploy_history, params).then(res => {
        if (res.status == 200) {
          //拼接环境
          if (res.data && res.data.result) {
            for (let i = 0; i < res.data.result.length; i++) {
              let item = res.data.result[i];
              item.env = params.env;
            }
          }
          this.deploy_history_list = res.data;
        }
      });
    },
    // 查询 - 代码扫描执行结果FindBugs
    getCodeScanningFindBugsResult(params) {
      $http.get($http.api.appdate.apipipelinetestfindbugstaskresult, params).then(res => {
        if (res.status == 200) {
          this.find_bugs_result_list = res.data;
        }
      });
    },
    // 查询 - 代码扫描执行结果SonarQube
    getCodeScanningSonarQubeResult(params) {
      $http.get($http.api.appdate.apipipelinesonartaskresult, params)
        .then(res => {
          if (res.status == 200) {
            this.sonarqube_result_list = res.data;
          }
        });
    },
    getCodeScanSafetyScanResult(params) {
      $http.get($http.api.appdate.apipipelinetestsafetyscantaskresult, params)
          .then(res => {
            if (res.status == 200) {
              this.safety_scan_result_list = res.data;
            }
          });
    },
    ifSafetyScanEnd() {
      var isEnd = true;
      if(this.ifCurrentWorkflowTypeCodeScanSafetyScan()) {
        if(this.safety_scan_result_list.list != null && this.safety_scan_result_list.list.length > 0){
          this.safety_scan_result_list.list.forEach(item=>{
            if(item.scanResult == null || item.scanResult == ""){
              isEnd = false;
            }
          });
        } else{
          isEnd = false;
        }
      }
      return isEnd;
    },
    // 更新日志
    getWorkflowLog() {
      this.$emit('taskTransfer', {
        ...this.currentSelectedWorkflow,
        stageName: this.currentSelectedStage.name
      });
    },
    // 刷新当前任务的展示详情，3种情况: 当前活跃任务变更的时候、点击任务项、重新执行当前任务的时候
    refreshWorkflow() {
      this.renderWorkflowDetail();
      // 启动循环更新当前任务信息
      this.currentWorkflowInterval && clearInterval(this.currentWorkflowInterval)
      if (this.currentSelectedWorkflow.workflowTaskStatus === this.WORKFLOW_TASK_STATUS.RUNNING) {
        this.currentWorkflowInterval = setInterval(() => {
          if (this.currentSelectedWorkflow.workflowTaskStatus !== this.WORKFLOW_TASK_STATUS.RUNNING && this.ifSafetyScanEnd()) {
            clearInterval(this.currentWorkflowInterval);
            return;
          }
          this.renderWorkflowDetail();
        }, 1500);
      }
      // 更新日志信息
      this.currentSelectedWorkflow.id && this.getWorkflowLog();
    },
    // 渲染当前 task 对应的信息：状态 table, 部署历史 table, 代码扫描 (日志已经单独拎出去了)，任务对象本身信息还是通过 reGenerateStageRunningVo 来更新的
    renderWorkflowDetail() {
      //假如不存在的话，不要刷新
      if (!this.currentSelectedWorkflow || !this.currentSelectedWorkflow.task) {
        return;
      }
      let itemType = this.currentSelectedWorkflow.task.type;
      let workflowTaskId = this.currentSelectedWorkflow.id;

      setTimeout(() => {
        // 更新 task workflow 的操作记录
        this.getWorkflowTaskDetail(workflowTaskId);
      }, 200)

      this.deployInfo = '';
      if (itemType === this.WORKFLOW_TASK_TYPE.DEPLOY) {
        let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
        if (setting) {
          this.deployInfo = '部署环境：' + (setting.environment == 'dev' ? '开发' : '测试');
          if (this.containsAppVersion) {
            this.getDeployHistory({
              appVersion: this.appVersionInfo.versionName,
              pageNum: 1,
              pageSize: 10,
              env: setting.environment
            }); //部署历史
          }
        }
      } else if (itemType === this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT || itemType === this.WORKFLOW_TASK_TYPE.SUBMIT_TEST
        || itemType === this.WORKFLOW_TASK_TYPE.PASS_TEST) {
        let setting = JSON.parse(this.currentSelectedWorkflow.task.setting)
        let gatekeeperType = "角色";
        let gatekeeperTitle = "类型名称";
        let gatekeeper = "";
        if (setting.type == 0) {
          gatekeeper = setting.role;
        } else {
          gatekeeperType = "人员";
          gatekeeperTitle = "工号";
          gatekeeper = setting.people;
        }
        this.operatorInfo = `类型：【${gatekeeperType}】 ${gatekeeperTitle}：${gatekeeper}`;
      } else if (itemType === this.WORKFLOW_TASK_TYPE.CODE_SCANNING) {
        let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
        if (setting) {
          if (setting.taskType == this.CODE_SCANNING_TYPE.FIND_BUGS) {
            this.getCodeScanningFindBugsResult({
              pageNum: 1,
              pageSize: 5,
              workflowTaskId: workflowTaskId
            });
          } else if (setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE || setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE_OPPO_RULE ) {
            this.getCodeScanningSonarQubeResult({
              pageNum: 1,
              pageSize: 5,
              workflowTaskId: workflowTaskId
            });
          } else if (setting.taskType == this.CODE_SCANNING_TYPE.SAFETY_SCAN) {
            this.getCodeScanSafetyScanResult({
              pageNum: 1,
              pageSize: 5,
              workflowTaskId: workflowTaskId
            });
          } else {
            console.error("暂不支持的代码扫描类型" + setting.taskType);
          }
        }
      }
    },
    // 部署历史分页
    handleDeployHistoryPageChange(obj = {
      newPageNum: this.deploy_history_list.pageNum,
      newPageSize: this.deploy_history_list.pageSize
    }) {
      if (this.containsAppVersion) {
        let deploySetting = this.currentSelectedWorkflow.task.setting;
        if (deploySetting) {
          let env = JSON.parse(deploySetting).environment;
          this.getDeployHistory({
            pageNum: obj.newPageNum,
            pageSize: obj.newPageSize,
            appVersion: this.appVersionInfo.versionName,
            env: env
          });
        } else {
          this.$message({
            message: '获取部署设置环境参数失败, deploySetting:' + deploySetting,
            type: "error"
          });
        }
      }
    },
    // stage 点击事件
    stageClick(stageId) {
      let changeSuccess = false;  //如果stage未开始，不能点击
      this.stageRunningVoList.some((stage) => {
        if (stage.id == stageId) {
          if (stage.stageRunningStatus == this.STAGE_STATUS.NOT_RUNNING) {
            return true;
          }
          changeSuccess = true;
          if (this.currentSelectedStage && this.currentSelectedStage.id != stage.id) {
            this.workflowAutoTransfer = false;
          }
          this.currentSelectedStage = stage;
          return true;
        }
      })

      if (!changeSuccess) {
        this.$message({
          message: '该阶段任务尚未开始！',
          type: 'info'
        })
        return;
      }
      this.currentSelectedWorkflow = this.currentSelectedWorkflowList.find((workflow, index) => {
        return this.ifWorkflowCurrent(workflow) || index == this.currentSelectedWorkflowList.length - 1;
      })
    },
    // task 点击事件
    workflowClick(workflowId) {
      //如果没变化，手动触发刷新
      if (this.currentSelectedWorkflow.id == workflowId) {
        this.refreshWorkflow();
      }
      this.currentSelectedWorkflow = this.currentSelectedWorkflowList.find((workflow) => {
        return workflow.id == workflowId;
      })
      if (this.pipelineWorkflow && this.pipelineWorkflow.id != this.currentSelectedWorkflow.id) {
        this.workflowAutoTransfer = false;
      } else {
        this.workflowAutoTransfer = true;
      }
    },
    // 辅助 - 是否是当前正在运行的 stage
    ifStageCurrent(stage) {
      return stage.stageRunningStatus == this.STAGE_STATUS.RUNNING
        || stage.stageRunningStatus == this.STAGE_STATUS.WAIT
        || stage.stageRunningStatus == this.STAGE_STATUS.FAILURE;
    },
    // 辅助 - 是否是当前正在运行的 task
    ifWorkflowCurrent(workflow) {
      // 完成流转成功或失败  完成且成功流传不成功
      return (workflow.transferType == this.TRANSFER_TYPE.FINISHED_TRANSFER
        && workflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.SUCCESS
        && workflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.FAILURE)
        || (workflow.transferType == this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER
          && workflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.SUCCESS);
    },
    // 辅助 - 当前任务是否已经结束
    ifWorkflowFinish(workflow) {
      return workflow.transferType == this.TRANSFER_TYPE.UNFINISHED_TRANSFER
        || (workflow.transferType == this.TRANSFER_TYPE.FINISHED_TRANSFER
          && workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE)
        || workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS;
    },
    // 辅助 - 当前运行任务的中文名
    getWorkflowTaskStatus(status, type) {
      switch (status) {
        case this.WORKFLOW_TASK_STATUS.RUNNING:
          return '<i class="el-icon-loading"></i>';
        case this.WORKFLOW_TASK_STATUS.SUCCESS:
          return '成功';
        case this.WORKFLOW_TASK_STATUS.FAILURE:
          return '失败';
        case this.WORKFLOW_TASK_STATUS.NEW:
          return '未开始';
        case this.WORKFLOW_TASK_STATUS.WAIT:
          return '等待执行';
        case this.WORKFLOW_TASK_STATUS.MANUAL_STOP:
          return '手工暂停';
      }
    },
    // 生成/刷新 当前阶段的运行情况
    reGenerateStageRunningVo(newVal) {
      let pipelineRunningWorkflow; // 流水线正在运行的 task
      let pipelineRunningStage; // 当前流水线正在运行的 stage
      let findRunning = false; // 是否有正在运行的 task

      newVal.forEach(stageRunning => {
        let stageRunningWorkflow; // stage 正在运行的 task
        let finish = 0; // 已经结束的任务数量

        //stage如果在running的状态的情况
        if (this.ifStageCurrent(stageRunning) && !pipelineRunningStage) {
          pipelineRunningStage = stageRunning;
        }

        // 遍历 stage 下面的任务列表：填充信息、寻找正在运行时的信息
        stageRunning.workflowTaskLst.forEach((workflow) => {
          // 填充运行时信息的基本信息
          workflow.task = this.pipelineTaskMap[workflow.pipelineTaskId]

          if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING) { findRunning = true; }

          if (this.ifWorkflowFinish(workflow)) { finish++; }

          if (this.ifWorkflowCurrent(workflow)) {
            if (!pipelineRunningWorkflow) { pipelineRunningWorkflow = workflow; }
            if (!stageRunningWorkflow) { stageRunningWorkflow = workflow; }
          }

          // 处理名称
          if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS) {
            workflow.task.showName = '<i class="iconfont icon-status-success-sm"></i>&nbsp;' + workflow.task.name;
          } else if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE) {
            workflow.task.showName = '<i class="iconfont icon-status-fail-sm"></i>&nbsp;' + workflow.task.name;
          } else if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING) {
            workflow.task.showName = '<i class="el-icon-loading"></i>&nbsp;' + workflow.task.name;
          } else if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.WAIT) {
            workflow.task.showName = '<i class="iconfont icon-status-waiting-sm"></i>&nbsp;' + workflow.task.name;
          } else {
            workflow.task.showName = '<i class="iconfont icon-status-init-sm" style="font-size:12px;"></i>&nbsp;' + workflow.task.name;
          }
        })

        // 如果没有找到，则直接显示最后一个
        if (!stageRunningWorkflow) {
          stageRunningWorkflow = stageRunning.workflowTaskLst[stageRunning.workflowTaskLst.length - 1];
        }

        // 封装在 stage box 中的显示信息
        if (stageRunning.stageRunningStatus == this.STAGE_STATUS.NOT_RUNNING) {
          stageRunning.percentage = 0;
          stageRunning.desc = '未开始';
        } else {
          stageRunning.percentage = Math.round((finish * 100) / stageRunning.workflowTaskLst.length);
          stageRunning.percentage = stageRunning.percentage == 0 ? 1 : stageRunning.percentage;

          let clazz = '';
          let taskName = stageRunningWorkflow.task.name;
          let statusDesc = this.getWorkflowTaskStatus(stageRunningWorkflow.workflowTaskStatus);
          if (stageRunningWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE) {
            clazz = 'c-red';
          }
          stageRunning.desc = `<span class="task-name ${clazz}" title="${taskName}">${taskName}</span><br/><span class="${clazz}">${statusDesc}</span>`;
        }
      })

      // 如果有正在运行的 task ，则启动循环获取流水线 stage 信息
      this.currentPipelineInterval&&clearInterval(this.currentPipelineInterval)
      if (findRunning || (pipelineRunningWorkflow &&
        (pipelineRunningWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING
          || pipelineRunningWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.NEW))) {
        this.currentPipelineInterval = setInterval(() => {
          this.getPipelineDetail()
        }, 1500)
      } else {
        this.$emit('ALLTASKEND')
      }

      let fresh = true;
      // 如果可以自动流转，自动显示当前活跃的 stage 和 task - 在非单个任务执行，即流水线自动执行会跑下面逻辑
      if (this.workflowAutoTransfer) {
        if (pipelineRunningWorkflow && pipelineRunningWorkflow.id != this.currentSelectedWorkflow.id) {
          this.currentSelectedWorkflow = pipelineRunningWorkflow;
          fresh = false;
        }

        if (pipelineRunningStage && pipelineRunningStage.id != this.currentSelectedStage.id) {
          this.currentSelectedStage = pipelineRunningStage;
        }

      }

      if (fresh) {
        // 刷新最新的任务信息 currentSelectedWorkflow，任务 id 还是保持不变 - 在单个任务重新执行的时候会执行下面逻辑
        newVal.some((stage) => {
          if (this.currentSelectedStage && stage.id == this.currentSelectedStage.id) {
            this.currentSelectedStage = stage;
            stage.workflowTaskLst.some((workflow) => {
              if (workflow.pipelineTaskId == this.currentSelectedWorkflow.task.id) {
                if (this.currentSelectedWorkflow.workflowTaskStatus != workflow.workflowTaskStatus) {
                  this.currentSelectedWorkflow = workflow;
                }
                return true;
              }
            });
            return true;
          }
        })
      }

      this.stageRunningVoList = newVal;
    },
    // 辅助 - 任务再执行中文名称
    getExecuteName(taskDetail) {
      if (taskDetail.type == this.WORKFLOW_TASK_TYPE.BUILD) {
        return taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新构建" : "构建";
      } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
        let envName = '';
        if (this.currentSelectedWorkflow) {
          let deploySetting = this.currentSelectedWorkflow.task.setting;
          let env = JSON.parse(deploySetting).environment;
          envName = (env == 'dev' ? '开发' : env == 'test' ? '测试' : '');
        }
        return (taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新部署" : "部署") + envName;
      } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.SUBMIT_TEST) {
        return "提测";
      } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.PASS_TEST) {
        return "测试通过";
      } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.UNIT_TEST) {
        return taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新执行" : "执行";
      } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.AUTO_TEST) {
        return "";
      } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE) {
        return taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新集成" : "集成";
      }
      return "执行";
    },
    // 辅助 - 任务停止状态中文名称
    getStopName(taskDetail) {
      if (taskDetail.manualStop == 1 && taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING) {
        return "停止中..."
      }

      return "停止";
    },
    // 辅助 - 任务状态流转中文名称
    getTransferTypeDesc(transferType) {
      switch (transferType) {
        case this.TRANSFER_TYPE.FINISHED_TRANSFER:
          return '完成流转';
        case this.TRANSFER_TYPE.UNFINISHED_TRANSFER:
          return '未完成流转';
        case this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER:
          return '完成且成功流转';
      }
    },
    // 辅助 - 任务结束状态中文名称
    getWorkflowTaskStatus(status, type) {
      switch (status) {
        case this.WORKFLOW_TASK_STATUS.RUNNING:
          return '<i class="el-icon-loading"></i>';
        case this.WORKFLOW_TASK_STATUS.SUCCESS:
          return '成功';
        case this.WORKFLOW_TASK_STATUS.FAILURE:
          return '失败';
        case this.WORKFLOW_TASK_STATUS.NEW:
          return '未开始';
        case this.WORKFLOW_TASK_STATUS.WAIT:
          return '等待执行';
        case this.WORKFLOW_TASK_STATUS.MANUAL_STOP:
          return '手工暂停';
      }
    },
    // 辅助 - 任务状态中文名称
    getWorkflowTaskTypeName(type) {
      switch (type) {
        case this.WORKFLOW_TASK_TYPE.BUILD:
          return '构建';
        case this.WORKFLOW_TASK_TYPE.DEPLOY:
          return '部署';
        case this.WORKFLOW_TASK_TYPE.CODE_SCANNING:
          return '代码扫描';
        case this.WORKFLOW_TASK_TYPE.INTF_AUTO_TEST:
          return '接口自动化测试';
        case this.WORKFLOW_TASK_TYPE.UI_AUTO_TEST:
          return 'UI自动化测试';
        case this.WORKFLOW_TASK_TYPE.VOICE_ASSISTANT_AI_AUTO_TEST:
          return '语音助手AI自动化测试';
        case this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT:
          return '人工卡点';
        case this.WORKFLOW_TASK_TYPE.SUBMIT_TEST:
          return '提测';
        case this.WORKFLOW_TASK_TYPE.PASS_TEST:
          return '测试通过';
        case this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT:
          return '自定义脚本';
        case this.WORKFLOW_TASK_TYPE.UNIT_TEST:
          return '单元测试';
        case this.WORKFLOW_TASK_TYPE.AUTO_TEST:
          return '自动化测试';
        case this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE:
          return '分支管理器';
        case this.WORKFLOW_TASK_TYPE.MVN_DEPLOY:
          return '上传mvn仓库';
      }
    },
    // 辅助 - 当前任务是否有如下 type
    ifCurrentWorkflowTypeIn(arr) {
      if (this.currentSelectedWorkflow.task) {
        return arr.indexOf(this.currentSelectedWorkflow.task.type) > -1
      }
      return false;
    },

    getPipelineStageList() {
      return this.stageList;
    },

    //对外暴露流水线的整体运行状态
    //如果返回为this.STAGE_STATUS.SUCCESS，则流水线上一流程执行完了（或者从未执行）
    //可以直接开始流水线的下一次执行
    getPipelineOverallRunningStatus() {
      let lastStageStatus = this.STAGE_STATUS.SUCCESS;
      for(let i =0; i < this.stageRunningDetailLst.length; i++) {
        let curStage = this.stageRunningDetailLst[i];
        if(!curStage) {
          continue;
        }

        if(i == 0 && curStage.stageRunningStatus == this.STAGE_STATUS.NOT_RUNNING) {
          break;
        }

        if(curStage.stageRunningStatus == this.STAGE_STATUS.RUNNING
          || curStage.stageRunningStatus == this.STAGE_STATUS.WAIT
          || curStage.stageRunningStatus == this.STAGE_STATUS.FAILURE
          || (curStage.stageRunningStatus == this.STAGE_STATUS.NOT_RUNNING && i != 0)) {
          lastStageStatus = curStage.stageRunningStatus;
          break;
        }
      }
      return lastStageStatus;
    },
  }
};
</script>
<style lang="scss" scoped>
  .title-detaile {
    color: #544c4c;
    font-size: 14px;
    font-weight: 700;
    /*margin-top: 10px;*/
    margin-bottom: 5px;
    /*display: inline-block;*/
  }
  .pipeline-flow-box {
    padding: 10px;
    background-color: #f9f9f9;
  }
  .common-table-box {
    margin-top: 10px;
  }
</style>
