<template>
  <div>
    <el-table :data="lastWorkflowOperation">
      <el-table-column label="任务类型" min-width="100">
        <template slot-scope="scope">
          <el-tooltip
            class="item"
            effect="dark"
            placement="top"
            :content="deployInfo"
            v-if="deployInfo.length > 0"
          >
            <span>{{scope.row.workflowTaskTypeName}}</span>
          </el-tooltip>
          <span v-else>{{scope.row.workflowTaskTypeName}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="executeType" label="触发类型" min-width="60"></el-table-column>
      <el-table-column label="流转方式" min-width="100">
        <template slot-scope="scope">
          <el-tooltip class="item" effect="dark" placement="top">
            <div slot="content">
              未完成流转：执不执行都会流转到下一任务
              <br>完成流转：执行完成了（成功或失败都会）流转下一任务
              <br>完成且成功流转：执行成功了才会流转下一任务
            </div>
            <span v-html="scope.row.transferType"></span>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column prop="triggerUser" label="最后操作人" min-width="180"></el-table-column>
      <el-table-column prop="startTime" label="操作时间" min-width="180"></el-table-column>
      <el-table-column label="状态" min-width="180">
        <template slot-scope="scope">
          <span v-html="scope.row.showStatus"></span>
          <el-tooltip
            class="item"
            effect="dark"
            placement="top"
            v-if="scope.row.errorMsg && scope.row.errorMsg.length > 0"
          >
            <div slot="content">{{scope.row.errorMsg}}</div>
            <i class="el-icon-warning"></i>
          </el-tooltip>
        </template>
      </el-table-column>
      <el-table-column label="操作" min-width="140">
        <template slot-scope="scope">
          <template v-if="ifDeployTestOrCanGo(scope.row)">
            <!-- 手动部署时，部署测试或部署开发 -->
            <span
              class="c-blue cp"
              v-show="canExecute(scope.row)"
              @click="executeWorkflow(scope.row)"
            >{{scope.row.executeName}}</span>

            <span
              :class="(scope.row.manualStop != 1) ? 'c-blue cp' : 'c-disabled cursor-default'"
              v-show="canExcuteTaskStop(scope.row)"
              @click="stopTaskExecute(scope.row)"
            >{{scope.row.stopName}}</span>

            <!-- 自动部署时，显示手动部署按钮 -->
            <span class="c-blue cp" @click="manualDeploy" v-show="canManualDeploy(scope.row)">手动部署</span>
            &nbsp;&nbsp;
            <span
              class="c-blue cp"
              @click="doExecuteWorkflow"
              v-show="canExecuteNextWorkflow(scope.row)"
            >流转下一阶段</span>
            <!-- 下载单元测试报告 -->
            <span
              class="c-blue cp"
              @click="openUrlInNewWindow(getUnitTestReportsDownloadUrl(scope.row.result))"
              v-show="canDownloadUnitTestReports(scope.row)"
            >下载报告</span>
            <!-- 重新执行自动化测试 -->
            <span
              class="c-blue cp"
              @click="doExecuteWorkflow"
              v-show="canExecuteAutoTestReRun(scope.row)"
            >重新执行</span>
          </template>
          <template v-else>
            <span class="c-red">只有应用测试人员才能部署测试环境</span>
          </template>
        </template>
      </el-table-column>
    </el-table>
    <paas-deploy ref="paasDeploy"></paas-deploy>
  </div>
</template>
<script>
/**
 * @title 任务状态 table
 * @desc
 * @author heyunjiang
 * @date
 */
import paasDeploy from '@/components/biz/app/paasDeploy';

export default {
  name: "TaskLogTable",
  components: {
    paasDeploy
  },
  mixins: [],
  props: {
    lastWorkflowOperation: {
      type: Array,
      required: true,
      desc: '任务状态变化 table'
    },
    deployInfo: {
      type: String,
      required: false,
      default: '',
      desc: '触发类型 tooptip'
    },
    currentSelectedWorkflow: {
      type: Object,
      required: true,
      desc: '当前活跃的 task'
    },
    containsAppVersion: {
      type: Boolean,
      required: true,
      desc: '是否包含可用版本'
    },
    appVersionInfo: {
      type: Object,
      required: true,
      desc: 'app 可用版本信息'
    }
  },
  data() {
    return {
      WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
      WORKFLOW_TASK_STATUS: GLOBAL_CONST.WORKFLOW_TASK_STATUS,
    }
  },
  computed: {},
  watch: {},
  created() { },
  methods: {
    // 辅助 - 是否可以部署测试
    ifDeployTestOrCanGo(val) {
      if (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.DEPLOY) {
        if (this.currentSelectedWorkflow && this.currentSelectedWorkflow.type && this.currentSelectedWorkflow.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
          if (this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.setting) {
            let deploySetting = this.currentSelectedWorkflow.task.setting;
            let env = JSON.parse(deploySetting).environment;
            //部署测试，开始校验
            if (env == 'test') {
              return this.authFunction('FUNC_APP_DEPLOY_TEST', 2, this.appId);
            }
          }
          return true;
        }
      }
      return true;
    },
    // 辅助 - 是否可以执行
    canExecute(val) {
      return val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE
        || val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.WAIT
        || (this.currentSelectedWorkflow.task
          && this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.DEPLOY
          && !this.currentSelectedWorkflow.task.autoExec
          && val.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.NEW)
    },
    // 辅助 - 是否可以停止，只有运行中的构建任务才显示停止按钮
    canExcuteTaskStop(val) {
      return (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING
        && (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.BUILD
          || val.workflowTaskType == this.WORKFLOW_TASK_TYPE.UNIT_TEST
          || val.workflowTaskType == this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT
          || val.workflowTaskType == this.WORKFLOW_TASK_TYPE.AUTO_TEST));
    },
    // 辅助 - 是否可以手动部署
    canManualDeploy(val) {
      //部署类型、自动任务、成功或失败
      return (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.DEPLOY
        && this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.autoExec
        && (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS || val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE))
    },
    // 辅助 - 是否可以流转下一阶段
    canExecuteNextWorkflow(val) {
      return (val.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.SUCCESS && val.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.NEW &&
        val.workflowTaskType == this.WORKFLOW_TASK_TYPE.DEPLOY && this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.autoExec == false)
    },
    // 辅助 - 是否可以重新执行
    canExecuteAutoTestReRun(val) {
      return (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE &&
        val.workflowTaskType == this.WORKFLOW_TASK_TYPE.AUTO_TEST)
    },
    // 辅助 - 是否可以下载测试报告
    canDownloadUnitTestReports(val) {
      return (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.UNIT_TEST && (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS || val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE))
    },
    // 辅助 - 获取下载url
    getUnitTestReportsDownloadUrl(val) {
      if (!val) { return ""; }
      return JSON.parse(val).unitTestReportUrl;
    },
    // 辅助 - 新窗口打开页面
    openUrlInNewWindow(val) {
      val && window.open(val);
    },
    // 手动部署
    manualDeploy() {
      if (!this.containsAppVersion) {
        this.$message({
          message: '当前流水线无可用应用版本，无法执行部署操作',
          type: "error"
        });
        return;
      }

      let deploySetting = this.currentSelectedWorkflow.task.setting;
      if (deploySetting) {
        let env = JSON.parse(deploySetting).environment;
        this.$refs.paasDeploy.setDeployUrl(this.appVersionInfo.versionId, env)
      } else {
        this.$message({
          message: '获取部署设置环境参数失败, deploySetting:' + deploySetting,
          type: "error"
        });
      }
    },
    // 执行 - 再次执行当前任务或者流转到下一阶段
    doExecuteWorkflow() {
      this.$emit('doExecuteWorkflow')
    },
    // 执行 - 停止执行
    stopTaskExecute(info) {
      this.$emit('stopTaskExecute', info)
    },
    // 执行 - 重新集成、重新构建等再次执行当前任务
    async executeWorkflow(val) {
      // 如果是部署，则触发手动部署
      if (this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.DEPLOY
        && !this.currentSelectedWorkflow.task.autoExec) {
        this.manualDeploy();
        return;
      }

      // // 更新日志内容
      // if (this.currentSelectedWorkflow.task
      //   && (this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.BUILD
      //     || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.UNIT_TEST
      //     || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT
      //     || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE
      //     || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.CODE_SCANNING)) {
      //   this.$emit('initLog')
      // }

      // 测试通过命令 - 发送前增加一个confirm操作
      if (this.currentSelectedWorkflow.task
        && this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.PASS_TEST) {
        let confirmResult;
        try {
          confirmResult = await this.$confirm("确认对当前版本进行“测试通过”操作？", "提示", {
            distinguishCancelAndClose: true,
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          });
        } catch (e) {
          //do nothing
        }
        if (!confirmResult) {
          return false;
        }
      }
      this.doExecuteWorkflow();
    },
  }
}
</script>
<style lang="scss" scoped>
</style>
