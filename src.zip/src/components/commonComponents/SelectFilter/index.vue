<template>
  <el-select v-model="selectValue" :multiple="multiple" @change="selectChange" @focus="focus" @blur="blur" :disabled="disabled" :placeholder="placeholder">
    <el-option value="search" disabled>
      <el-input placeholder="搜索" v-model.trim="filterString"></el-input>
    </el-option>
    <div class="select-scroll scrollbal-common">
    <slot></slot>
      <el-option v-for="(data) in selectListVo" :key="data.key" :value="data.key" :label="data.value" >{{data.value}}</el-option>
    </div>
    
  </el-select>
</template>
<script>
/**
 * @title 基于 elementui select 的 filter 组件
 * @desc 支持单选、多选、过滤
 * @author heyunjiang
 * @date 2019.7.23
 * @update 2019.8.22
 */
export default {
  name: "SelectFilter",
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: [String, Array],
    disabled: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否禁用'
    },
    multiple: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否多选'
    },
    selectList: {
      type: Array,
      required: true,
      desc: 'select option source data'
    },
    placeholder: String
  },
  components: {},
  mixins: [],
  data() {
    return {
      selectValue: this.value,
      filterString: ''
    }
  },
  computed: {
    selectListVo() {
      if(this.filterString.length === 0) {return this.selectList;}
      return this.selectList.filter(item => {
        return item.value.indexOf(this.filterString) !== -1;
      })
    }
  },
  watch: {
    value() {
      this.selectValue = this.multiple?[...this.value]:this.value;
    }
  },
  created() { },
  methods: {
    selectChange() {
      this.$emit('change', this.selectValue)
    },
    blur(value) {
      this.$emit('blur', value)
    },
    focus(value) {
      this.$emit('focus', value)
    },
  }
}
</script>
<style lang="scss" scoped>
.select-scroll{
height: 180px;
overflow: auto;
// display: inline-block;
}
</style>
