import EleMultiCascader from "./main/main.vue";
/**
 * @title element-ui 2.4.11 cascader 多选组件
 * @author heyunjiang
 * @date 2019.8.20
 */
export default {
  install(Vue) {
    const name = EleMultiCascader.name;
    Vue.component(name, EleMultiCascader);
  }
}
