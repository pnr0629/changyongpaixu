export default {
  methods: {
    // 保存编辑器内容到 localstorage
    saveTinymceContent(obj = {
      value: '',
      id: -1, // 新建时，需求 -1， 任务 -2， 缺陷 -3
      type: 'requirement', // 需求、任务、缺陷
      isNew: false // 是否是新建
    }) {
      localStorage.setItem('tinymceContent_'+obj.id, JSON.stringify(obj));
    },
    // 清楚编辑器缓存内容 - 在每次
    removeTinymceContent(id=-1) {
      localStorage.removeItem('tinymceContent_'+id);
    },
    // 是否有上次未保存的内容
    async isPreviousContentExist(id=-1, type="requirement", isNew=false, value='') {
      const tinymceContent = JSON.parse(localStorage.getItem('tinymceContent_'+id) || '{}');
      if(tinymceContent.value === value) {return false}
      if(id === +tinymceContent.id || (type === tinymceContent.type && isNew)) {
        const confirmResult = await this.confirmBeforeOperate(`编辑器存在上次未保存的内容，是否恢复`);
        this.removeTinymceContent(id);
        if(!confirmResult) {
          return false;
        }
        return tinymceContent.value;
      }
      return false;
    }
  }
}