<template>
  <div class="custom-statu" ref="statusBox" :style="boxPostion">
    <div class="custom-statu-left" @click="prevetEvent($event)">
      <div class="custom-item" @click="customChoose(item)" v-for="item in stausData" :key="item.type"
        :style="{background:item.color} " :class="{'border-class': currentItem === item.statusId}"  >
        <!-- :style="{background: currentItem === item.statusId ? 'yellowgreen' : ''} " -->
        {{item.statusName}}
      </div>
    </div>
    <div class="custom-statu-right" @click="prevetEvent($event)">
      <el-form ref="form" :model="form" style="margin-top: 16px;">
        <el-form-item label="处理人" label-width="90px">
          <el-select v-model='form.user' ref="canleSelect" clearable filterable @focus="fous" @blur="blur" 
            style="width:250px;" placeholder="处理人">
            <el-option v-for="(item,index) in assignUserData" :key="index" :value="item.userId" :label="item.userName">
              <template slot-scope="scope">{{item.userName}}({{item.userId}})</template>
            </el-option>
          </el-select>
        </el-form-item>
        <template v-for="item in attachFields">
          <el-form-item v-if="item.choice && statusShow" :label="item.label+' '" label-width="90px" :key="item.key">
            <el-select v-model="form.cause" class="header-input" style="width:250px;">
              <el-option v-for="jtem in item.selectValue" :key="jtem.key" :label="jtem.value" :value="Number(jtem.key)">
              </el-option>
            </el-select>
          </el-form-item>
        </template>
        <el-form-item label="通知人" label-width="90px">
          <el-select v-model='form.messger' ref="canleSelect" @focus="fous" @blur="blur" filterable 
            style="width:250px;"  multiple placeholder="通知人">
            <el-option label="全部" value="all"></el-option>
            <el-option v-for="(item,index) in assignUserData" :key="index" :value="item.userId" :label="item.userName">
              <template slot-scope="scope">{{item.userName}}({{item.userId}})</template>
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div id="bottom-tiny" @click="fousClick" v-show="show">
      </div>
      <tiny-mce :value="form.comment" @watch="editComentLister($event)" :maxHeigt="200" :minHeigt='200'
        :toolbar="toolBar">
      </tiny-mce>
      <div class="btn-footer">
        <el-button type="success" @click="sendInformation">确定</el-button>
        <el-button type="info" @click="closeStatus">取消</el-button>
      </div>
    </div>
  </div>
</template>
<script>
  import BugCustomFieldsMixin from "../../project/bugManagement/BugCustomFieldsMixin.js";

  import TinyMce from 'components/tool/tinymce';
  export default {
    name: "CustomStatus",
    components: {
      TinyMce,
    },
    props: {
      parentInfo: {
        type: Object,
        required: false,
        default: () => {
          return {}
        },
        desc: "状态对应的整体详细信息，用于拿附加字段的初始值"
      },
      statusShow: {
        type: Boolean,
        default: false,
        required: false,
      },
      workItemType: {
        type: [String, Number],
        required: false,
      },
      workItemId: {
        type: [String, Number],
        required: false,
        default: null,
      },
      statusId: {
        type: [String, Number],
        required: false
      },
      statusHeight: {
        type: String,
        default: 0,
      },
      statusleft: {
        type: String,
      },
      projectId: {
        type: [String, Number],
        required: false,
        default: false,
      },
      updateData: {
        type: Function,
        required: false
      }
    },
    mixins: [BugCustomFieldsMixin],
    data() {
      return {
        form: {
          user: "",
          messger: "",
          comment: "",
          cause: 1,
        },
        assignUserData: [],
        currentItem: "",//
        stausData: "",
        attachFields: [], // 附件字段，包含评论
        show: false,
        // visible:false,
        toolBar: 'undo redo | bold italic  bullist  numlist  lists  imageCustom  fullscreen',
      }
    },
    computed: {
      boxPostion() {
        return {
          top: this.statusHeight,
          left: this.statusleft
        }
      }
    },

    mounted() {
      this.getNextStatus();
      this.assignUsersList();
      setTimeout(() => {
        document.body.removeEventListener('click', this.closeStatus);
        document.body.addEventListener('click', this.closeStatus);
        this.resetPosition();
      }, 0)
    },
    destroyed() {
      document.body.removeEventListener('click', this.closeStatus);
    },

    methods: {
      // 计算是否超出浏览器边框位置了
      resetPosition() {
        const dom = this.$refs.statusBox;
        const rect = dom.getBoundingClientRect();
        const originTop = Number(this.statusHeight.split('px')[0]);
        if(rect.top < 50 && originTop) {
          dom.style.top = originTop - rect.top + 50 + 'px'; // 增加50 ，是保证不被导航栏遮住
        }
      },
      sendInformation() {
        if (this.currentItem === 121 || this.currentItem === 81 && this.workItemType === 3) {
          if (!this.form.comment.trim()) {
            this.$message({ type: 'warning', message: "打回或重打开必须填写评论" })
            return
          }
        }
        if (this.workItemType === 1) {
          this.updateRequir()
        } else if (this.workItemType === 2) { }
        else if (this.workItemType === 3) {
          this.updateDefect()
        }
        this.onSubmitComment();
      },
      onSubmitComment() {
        $http.post($http.api.comment.add, {
          workItemType: this.workItemType,
          workItemId: this.workItemId,
          comment: this.form.comment.trim(),
          projectId: this.projectId,
          workNumberIds: this.form.messger,
          workItemUrl: window.location.href
        }).then(res => {
          if (res.status === 200) {
            this.closeStatus();
            this.comment = "";
            this.informant = [];
          } else {
            this.$message({ type: 'error', message: res.msg })
          }
        });
      },
      //更新缺陷
      updateDefect() {
        let postObj = {
          projectId: this.projectId,
          id: this.workItemId,
          statusId: this.currentItem,
          assignUser: this.form.user,
          ...this.values
        };
        this.updateData(postObj)
      },
      //更新需求
      updateRequir() {
        $http.post($http.api.requirement.update, { projectId: this.projectId, statusId: this.currentItem, assignUser: this.form.user, id: this.workItemId }).then(res => {
          if (res.status === 200) {
            this.$message({ message: '修改需求成功', type: 'success' });
            this.updateData();
          } else {
            this.$message({ message: res.msg, type: 'error' });
          }
        })
      },
      fousClick() {
        this.show = false;
      },
      fous() {
        this.show = true;
      },
      blur() {
        this.show = true;
      },
      prevetEvent(e) {
        e.stopPropagation()
      },
      // 字段初始化
      closeStatus() {
        this.$emit('closeStatus')
      },
      async fieldInit() {
        // 数据初始化
        this.attachFields = [];
        this.values = { comment: "" };
        this.loading = true;
        let result = await this.getCustomFiledInfo(this.parentInfo.projectId);
        this.loading = false;
        if (result.status !== 200 || result.data === null) { return false; }
        result = result.data;
        // 封装 this.attachFields 对象
        try {
          const required = this.statusInfo.fields.value.required; // 需要展示的字段集合
          const attachFields = [];
          required.forEach(item => {
            if (item === 'comment') {
              attachFields.push({
                key: item,
                label: '评论'
              })
              this.$set(this.values, 'comment', '')
            } else {
              if (result.def[item]) {
                attachFields.push({
                  key: item,
                  label: result.def[item].fieldName,
                  choice: result.def[item].choice,
                  selectValue: []
                })
                this.$set(this.values, item, this.parentInfo[item] || '')
              }
            }
          })
          // 获取预加载值
          attachFields.filter(item => item.choice).forEach(async item => {
            const result = await this.getPresetDataForSelect(item.key);
            item.selectValue = result.choices.map(jtem => {
              return {
                key: jtem.fieldValue,
                value: jtem.fieldDisplay,
                ...jtem
              }
            })
            this.$set(this.values, item.key, item.selectValue[0].key)
          })
          this.attachFields = attachFields

        } catch (_) { }
      },
      // 获取下拉框 select options 值
      async getPresetDataForSelect(fieldId) {
        const result = await this.getCustomFiledSelectList(fieldId, this.parentInfo.projectId);
        if (result.status === 200) {
          return result.data;
        }
        return [];
      },
      customChoose(item) {
        this.currentItem = item.statusId;
        this.statusInfo = item;
        this.fieldInit();

      },
      getObjectKeys(object) {
        let keys = []
        for (let property in object)
          keys.push(property)
        return keys
      },
      assignUsersList(query) {
        let projectId = this.projectId;
        $http.post($http.api.bug_info.assignUsersList, { projectId, query: query ? query : '' }).then(res => {
          this.assignUserData = res.data;
        })
      },
      getNextStatus() {

        let param = {
          workItemType: this.workItemType,
          workItemId: this.workItemId,
          statusId: this.statusId,
          projectId: this.projectId
        }
        $http.post($http.api.bug_info.statusUpdatableList, param).then(res => {
          this.stausData = res.data;
          this.currentItem = res.data[0].statusId

          if (this.currentItem === 81 || this.currentItem === 121) {
            this.statusInfo = res.data[0];
            this.$nextTick(() => {
              this.fieldInit()
            })
          }
        })
      },
      editComentLister(data) {
        this.form.comment = data;
      },
      //评论通知人搜索
      remoteMethod(query) {
        this.query = query;
        this.assignUsersList(query);
      },
    },
  }
</script>
<style lang="scss" scoped>
  .custom-statu {
    height: 420px;
    position: absolute;
    background-color: #fff;
    box-shadow: 0 -1px 0 rgba(255, 255, 255, 0.9) inset;
    border: 1px solid #ccc;
    z-index: 999;
    width: 617px;
    .custom-statu-left {
      width: 170px;
      height: 100%;
      /* display: inline-block; */
      float: left;
      background-color: #f3f3f3;

      .custom-item {
        margin: 0 auto;
        width: 130px;
        height: 30px;
        line-height: 30px;
        cursor: pointer;
        text-align: center;
        /* background-color: lightslategray; */
        margin-top: 20px;
        color: whitesmoke;
        border-radius: 4px;

        &:hover {
          border: 1px solid yellowgreen；
        }

        &:first-child {
          /* margin-top: 0; */
        }
      }
    }

    .custom-statu-right {
      width: 445px;
      box-sizing: border-box;
      padding: 0 20px;
      height: 100%;
      float: right;
      position: relative;
    }

    .btn-footer {
      float: right;
      /* margin-right: 30px; */
      margin-top: 20px;
    }
  }

  #bottom-tiny {
    height: 200px;
    /* opacity: -0.5; */
    width: 404px;
    background: #000;
    opacity: 0;
    position: absolute;
    top: 116px;
    z-index: 1300;
  }
  .border-class{
    border: 1px solid;
    border-color:blue;
  }
</style>