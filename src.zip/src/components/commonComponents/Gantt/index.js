import date_utils from './date_utils';
import { $, createSVG } from './svg_utils';
import Bar from './bar';
import Arrow from './arrow';
import Popup from './popup';

import './gantt.scss';
/**
 * @title 甘特图源组件
 * @author heyunjiang
 * @date 2019.8.20
 */
export default class Gantt {
  constructor(wrapper, tasks, options, dateList) {
    this.setup_wrapper(wrapper);
    this.setup_options(options);
    this.setup_tasks(tasks);
    // initialize with default view mode
    this.change_view_mode();
    this.bind_events();
    // 外部传入的日期，用于替换 lower_text, upper_text 值，展示周数据
    if(dateList) {
      this.dateList = dateList
      this.rows = []
    }
  }

  // 初始化 - 设置渲染的dom节点
  setup_wrapper(element) {
    let svg_element, wrapper_element;

    // CSS Selector is passed
    if (typeof element === 'string') {
      element = document.querySelector(element);
    }

    // get the SVGElement
    if (element instanceof HTMLElement) {
      wrapper_element = element;
      svg_element = element.querySelector('svg');
    } else if (element instanceof SVGElement) {
      svg_element = element;
    } else {
      throw new TypeError(
        'Frappé Gantt only supports usage of a string CSS selector,' +
        " HTML DOM element or SVG DOM element for the 'element' parameter"
      );
    }

    // svg element
    if (!svg_element) {
      // create it
      this.$svg = createSVG('svg', {
        append_to: wrapper_element,
        class: 'gantt'
      });
    } else {
      this.$svg = svg_element;
      this.$svg.classList.add('gantt');
    }

    // wrapper element
    this.$container = document.createElement('div');
    this.$container.classList.add('gantt-container');
    this.$container.classList.add('scrollbal-common');
    
    // gantt header container 拆分 header ，用于固定定位
    this.$headercontainer = document.createElement('div');
    this.$headercontainer.classList.add('gantt-header-container');

    const parent_element = this.$svg.parentElement;
    // parent_element.appendChild(this.$headercontainer);
    parent_element.appendChild(this.$container);
    this.$container.appendChild(this.$headercontainer);
    this.$container.appendChild(this.$svg);

    this.$headerSvg = createSVG('svg', {
      append_to: this.$headercontainer,
      class: 'gantt-header'
    });

    // popup wrapper
    this.popup_wrapper = document.createElement('div');
    this.popup_wrapper.classList.add('popup-wrapper');
    this.$container.appendChild(this.popup_wrapper);
  }

  // 初始化 - 设置选项 this.options
  setup_options(options) {
    const default_options = {
      header_height: 50,
      column_width: 30,
      step: 24,
      view_modes: [
        'Quarter Day',
        'Half Day',
        'Day',
        'Week',
        'Month',
        'Year'
      ],
      bar_height: 20,
      bar_corner_radius: 3,
      arrow_curve: 5,
      padding: 18,
      view_mode: 'Day',
      date_format: 'YYYY-MM-DD',
      popup_trigger: 'click',
      custom_popup_html: null,
      language: 'en'
    };
    this.options = Object.assign({}, default_options, options);
  }

  // 初始化 - 任务 data
  setup_tasks(tasks) {
    // prepare tasks
    this.tasks = tasks.map((task, i) => {
      // convert to Date objects
      task._start = date_utils.parse(task.start);
      task._end = date_utils.parse(task.end);
      if(task.realStart&&task.realEnd) {
        task._realStart = date_utils.parse(task.realStart);
        task._realEnd = date_utils.parse(task.realEnd);
      }

      // make task invalid if duration too large
      if (date_utils.diff(task._end, task._start, 'year') > 10) {
        task.end = null;
      }

      // cache index
      task._index = i;

      // invalid dates
      if (!task.start && !task.end) {
        const today = date_utils.today();
        task._start = today;
        task._end = date_utils.add(today, 2, 'day');
      }

      if (!task.start && task.end) {
        task._start = date_utils.add(task._end, -2, 'day');
      }

      if (task.start && !task.end) {
        task._end = date_utils.add(task._start, 2, 'day');
      }

      // 如果结束时间没有设置时分秒，则增加时分秒，保证是完整的一天
      // e.g: 2018-09-09 becomes 2018-09-09 23:59:59
      const task_end_values = date_utils.get_date_values(task._end);
      if (task_end_values.slice(3).every(d => d === 0)) {
        task._end = date_utils.add(task._end, 24, 'hour');
      }
      if(task.realStart&&task.realEnd) {
        const task_realend_values = date_utils.get_date_values(task._realEnd);
        if (task_realend_values.slice(3).every(d => d === 0)) {
          task._realEnd = date_utils.add(task._realEnd, 24, 'hour');
        }
      }
      // invalid flag
      if (!task.start || !task.end) {
        task.invalid = true;
      }

      // dependencies
      if (typeof task.dependencies === 'string' || !task.dependencies) {
        let deps = [];
        if (task.dependencies) {
          deps = task.dependencies
            .split(',')
            .map(d => d.trim())
            .filter(d => d);
        }
        task.dependencies = deps;
      }

      // uids
      if (!task.id) {
        task.id = generate_id(task);
      }

      return task;
    });

    this.setup_dependencies();
  }

  // 初始化 - 依赖 data
  setup_dependencies() {
    this.dependency_map = {};
    for (let t of this.tasks) {
      for (let d of t.dependencies) {
        this.dependency_map[d] = this.dependency_map[d] || [];
        this.dependency_map[d].push(t.id);
      }
    }
  }

  // 更新 - 任务 data + view_mode
  refresh(tasks, dateList) {
    this.setup_tasks(tasks);
    // 外部传入的日期，用于替换 lower_text, upper_text 值，展示周数据
    if(dateList) {
      this.dateList = dateList
    }
    this.change_view_mode();
  }

  // 设置 view_mode ，及 view_mode 带来的改变
  change_view_mode(mode = this.options.view_mode) {
    if(this.tasks.length < 1) { return false;}
    this.update_view_scale(mode);
    this.setup_dates();
    this.render();
    // fire viewmode_change event
    this.trigger_event('view_change', [mode]);
  }

  // 根据 view_mode 设置 this.options step, column_width
  update_view_scale(view_mode) {
    this.options.view_mode = view_mode;
    if (view_mode === 'Day') {
      this.options.step = 24;
      this.options.column_width = 38;
    } else if (view_mode === 'Half Day') {
      this.options.step = 24 / 2;
      this.options.column_width = 38;
    } else if (view_mode === 'Quarter Day') {
      this.options.step = 24 / 4;
      this.options.column_width = 38;
    } else if (view_mode === 'Week') {
      this.options.step = 24 * 7;
      this.options.column_width = 140;
    } else if (view_mode === 'Month') {
      this.options.step = 24 * 30;
      this.options.column_width = 120;
    } else if (view_mode === 'Year') {
      this.options.step = 24 * 365;
      this.options.column_width = 120;
    }
  }

  // 设置日期
  setup_dates() {
    this.setup_gantt_dates();
    this.setup_date_values();
  }

  // 设置日期 - this.gantt_start this.gantt_end 对象
  setup_gantt_dates() {
    this.gantt_start = this.gantt_end = null;
    if(this.dateList && this.dateList.length > 1) {
      this.gantt_start = date_utils.parse(this.dateList[0].date)
      this.gantt_end = date_utils.parse(this.dateList[this.dateList.length - 1].date)
      return ;
    }
    // 先找到所有任务的最长事件及最短时间
    for (let task of this.tasks) {
      // set global start and end date
      if (!this.gantt_start || task._start < this.gantt_start) {
        this.gantt_start = task._start;
      }
      if (!this.gantt_end || task._end > this.gantt_end) {
        this.gantt_end = task._end;
      }
    }
    // 获取开始、结束的 年月日，不包含时分秒
    this.gantt_start = date_utils.start_of(this.gantt_start, 'day');
    this.gantt_end = date_utils.start_of(this.gantt_end, 'day');

    // add date padding on both sides
    if (this.view_is(['Quarter Day', 'Half Day', 'Day'])) {
      this.gantt_start = date_utils.add(this.gantt_start, 0, 'day');
      this.gantt_end = date_utils.add(this.gantt_end, 0, 'day');
    } else if (this.view_is('Week')) {
      this.gantt_start = date_utils.add(this.gantt_start, -7, 'day');
      this.gantt_end = date_utils.add(this.gantt_end, 7, 'day');
    } else if (this.view_is('Month')) {
      this.gantt_start = date_utils.start_of(this.gantt_start, 'year');
      this.gantt_end = date_utils.add(this.gantt_end, 1, 'year');
    } else if (this.view_is('Year')) {
      this.gantt_start = date_utils.add(this.gantt_start, -2, 'year');
      this.gantt_end = date_utils.add(this.gantt_end, 2, 'year');
    } else {
      this.gantt_start = date_utils.add(this.gantt_start, -1, 'month');
      this.gantt_end = date_utils.add(this.gantt_end, 1, 'month');
    }
  }

  // 设置日期 -  this.dates 数组值
  setup_date_values() {
    this.dates = [];
    let cur_date = null;
    while (cur_date === null || cur_date < this.gantt_end) {
      if (!cur_date) {
        cur_date = date_utils.clone(this.gantt_start);
      } else {
        if (this.view_is('Year')) {
          cur_date = date_utils.add(cur_date, 1, 'year');
        } else if (this.view_is('Month')) {
          cur_date = date_utils.add(cur_date, 1, 'month');
        } else {
          cur_date = date_utils.add(
            cur_date,
            this.options.step,
            'hour'
          );
        }
      }
      this.dates.push(cur_date);
    }
  }

  // 初始化 - 绑定事件
  bind_events() {
    this.bind_grid_click();
    this.bind_bar_events();
    this.bind_grid_scroll();
  }

  render() {
    this.clear();
    this.setup_layers();
    this.make_grid();
    this.make_dates();
    this.make_bars();
    this.make_arrows();
    this.map_arrows_on_bars();
    this.set_width();
    this.set_scroll_position();
  }

  // 绘制svg - layer 层， g 对象，属性设置：class, 添加到的父节点 this.$svg，包含 grid, date, arrow, progress, bar, details
  setup_layers() {
    this.layers = {};
    const layers = ['headergrid', 'grid', 'date', 'arrow', 'progress', 'bar', 'details'];
    // make group layers
    for (let layer of layers) {
      let box = this.$svg
      if(['date', 'headergrid'].includes(layer)) {
        box = this.$headerSvg
      }
      this.layers[layer] = createSVG('g', {
        class: layer,
        append_to: box
      });
    }
  }

  // 绘制底层 grid table
  make_grid() {
    this.make_grid_background();
    this.make_grid_rows();
    this.make_grid_header();
    this.make_grid_ticks();
    this.make_grid_highlights();
    this.make_grid_holidays();
  }

  // 绘制底层 - 整体高度
  make_grid_background() {
    const grid_width = this.dates.length * this.options.column_width;
    const grid_height =
      this.options.header_height +
      (this.options.bar_height + this.options.padding) *
      this.tasks.length;

    createSVG('rect', {
      x: 0,
      y: 0,
      width: grid_width,
      height: grid_height,
      class: 'grid-background',
      append_to: this.layers.grid
    });

    $.attr(this.$svg, {
      height: grid_height + 7,
      // height: grid_height + this.options.padding + 100,
      width: '100%'
    });
    $.attr(this.$headerSvg, {
      height: this.options.header_height + 10,
      width: '100%'
    });
    this.$headercontainer.style.height = this.options.header_height + 10 + 'px';
  }

  // 绘制底层 - rows 行
  make_grid_rows() {
    const rows_layer = createSVG('g', { append_to: this.layers.grid });
    const lines_layer = createSVG('g', { append_to: this.layers.grid });

    const row_width = this.dates.length * this.options.column_width;
    const row_height = this.options.bar_height + this.options.padding;

    let row_y = this.options.header_height + this.options.padding / 2;

    for (let task of this.tasks) {
      const row = createSVG('rect', {
        x: 0,
        y: row_y,
        width: row_width,
        height: row_height,
        class: 'grid-row',
        append_to: rows_layer
      });

      createSVG('line', {
        x1: 0,
        y1: row_y + row_height,
        x2: row_width,
        y2: row_y + row_height,
        class: 'row-line',
        append_to: lines_layer
      });
      this.rows.push(row)
      row_y += this.options.bar_height + this.options.padding;
    }

    // 绑定 row 鼠标悬浮事件
    this.bind_mouseover_events()
  }

  // 绘制底层 - rows header
  make_grid_header() {
    const header_width = this.dates.length * this.options.column_width;
    const header_height = this.options.header_height + 10;
    createSVG('rect', {
      x: 0,
      y: 0,
      width: header_width,
      height: header_height,
      class: 'grid-header',
      append_to: this.layers.headergrid
      // append_to: this.layers.grid
    });
  }

  // 绘制底层 - 竖线
  make_grid_ticks() {
    let tick_x = 0;
    let tick_y = this.options.header_height + this.options.padding / 2;
    let tick_height =
      (this.options.bar_height + this.options.padding) *
      this.tasks.length;

    for (let date of this.dates) {
      let tick_class = 'tick';
      // thick tick for monday
      if (this.view_is('Day') && date.getDate() === 1) {
        tick_class += ' thick';
      }
      // thick tick for first week
      if (
        this.view_is('Week') &&
        date.getDate() >= 1 &&
        date.getDate() < 8
      ) {
        tick_class += ' thick';
      }
      // thick ticks for quarters
      if (this.view_is('Month') && (date.getMonth() + 1) % 3 === 0) {
        tick_class += ' thick';
      }

      createSVG('path', {
        d: `M ${tick_x} ${tick_y} v ${tick_height}`,
        class: tick_class,
        append_to: this.layers.grid
      });

      if (this.view_is('Month')) {
        tick_x +=
          date_utils.get_days_in_month(date) *
          this.options.column_width /
          30;
      } else {
        tick_x += this.options.column_width;
      }
    }
  }
 
  // 绘制底层 - 高亮今天这行
  make_grid_highlights() {
    // highlight today's date
    if (this.view_is('Day')) {
      const x =
        date_utils.diff(date_utils.today(), this.gantt_start, 'hour') /
        this.options.step *
        this.options.column_width;
      const y = 0;

      const width = this.options.column_width;
      const height =
        (this.options.bar_height + this.options.padding) *
        this.tasks.length +
        this.options.header_height +
        this.options.padding / 2;

      createSVG('rect', {
        x,
        y,
        width,
        height,
        class: 'today-highlight',
        append_to: this.layers.grid
      });
    }
  }
  // 绘制底层 - 周六周天背景色
  make_grid_holidays() {
    if (this.view_is('Day')&&this.dateList) {
      const weekends = this.dateList.filter(item => [6, 7].includes(item.week))
      weekends.forEach(item => {
        const x =
          date_utils.diff(date_utils.parse(item.date), this.gantt_start, 'hour') /
          this.options.step *
          this.options.column_width;
        const y = 0;

        const width = this.options.column_width - 1;
        const height =
          (this.options.bar_height + this.options.padding) *
          this.tasks.length +
          this.options.header_height +
          this.options.padding / 2;

        createSVG('rect', {
          x,
          y,
          width,
          height,
          class: 'weekend-highlight',
          append_to: this.layers.grid
        });
      })
    }
  }

  // 绘制日期
  make_dates() {
    const headerTickHeight = this.options.header_height + 10
    for (let date of this.get_dates_to_draw()) {
      let dateClass = 'lower-text';
      date.workday&&(dateClass += ' lower-text-opacity')
      createSVG('text', {
        x: date.lower_x,
        y: date.lower_y,
        innerHTML: date.lower_text,
        class: dateClass,
        append_to: this.layers.date
      });
      if (date.upper_text) {
        const $upper_text = createSVG('text', {
          x: date.upper_x,
          y: date.upper_y,
          innerHTML: date.upper_text,
          class: 'upper-text',
          append_to: this.layers.date
        });
        // remove out-of-bound dates
        if (
          $upper_text.getBBox().x2 > this.layers.grid.getBBox().width
        ) {
          $upper_text.remove();
        }
      }
      if (date.upper_text && this.dateList) {
        createSVG('path', {
          d: `M ${date.upper_x - this.options.column_width} 0 v ${headerTickHeight}`,
          class: 'upper-tick',
          append_to: this.layers.date
        });
      }
    }
  }

  // 绘制日期 - 获取需要绘制的日期
  get_dates_to_draw() {
    let last_date = null;
    const dates = this.dates.map((date, i) => {
      const d = this.get_date_info(date, last_date, i);
      last_date = date;
      return d;
    });
    return dates;
  }

  // 绘制日期 - 获取日期详细信息
  get_date_info(date, last_date, i) {
    if (!last_date) {
      last_date = date_utils.add(date, 1, 'year');
    }
    const dayLowerInfo = this.get_date_from_dateList(date);
    const dayUperInfo = this.get_date_from_dateList(date, false);

    const date_text = {
      'Quarter Day_lower': date_utils.format(
        date,
        'HH',
        this.options.language
      ),
      'Half Day_lower': date_utils.format(
        date,
        'HH',
        this.options.language
      ),
      Day_lower: dayLowerInfo.text,
      Week_lower:
        date.getMonth() !== last_date.getMonth()
          ? date_utils.format(date, 'D MMM', this.options.language)
          : date_utils.format(date, 'D', this.options.language),
      Month_lower: date_utils.format(date, 'MMMM', this.options.language),
      Year_lower: date_utils.format(date, 'YYYY', this.options.language),
      'Quarter Day_upper':
        date.getDate() !== last_date.getDate()
          ? date_utils.format(date, 'D MMM', this.options.language)
          : '',
      'Half Day_upper':
        date.getDate() !== last_date.getDate()
          ? date.getMonth() !== last_date.getMonth()
            ? date_utils.format(date, 'D MMM', this.options.language)
            : date_utils.format(date, 'D', this.options.language)
          : '',
      Day_upper: dayUperInfo.text,
      Week_upper:
        date.getMonth() !== last_date.getMonth()
          ? date_utils.format(date, 'MMMM', this.options.language)
          : '',
      Month_upper:
        date.getFullYear() !== last_date.getFullYear()
          ? date_utils.format(date, 'YYYY', this.options.language)
          : '',
      Year_upper:
        date.getFullYear() !== last_date.getFullYear()
          ? date_utils.format(date, 'YYYY', this.options.language)
          : ''
    };

    const base_pos = {
      x: i * this.options.column_width,
      lower_y: this.options.header_height,
      upper_y: this.options.header_height - 25
    };

    const x_pos = {
      'Quarter Day_lower': this.options.column_width * 4 / 2,
      'Quarter Day_upper': 0,
      'Half Day_lower': this.options.column_width * 2 / 2,
      'Half Day_upper': 0,
      Day_lower: this.options.column_width / 2,
      // Day_upper: this.options.column_width * 30 / 2,
      Day_upper: this.options.column_width,
      Week_lower: 0,
      Week_upper: this.options.column_width * 4 / 2,
      Month_lower: this.options.column_width / 2,
      Month_upper: this.options.column_width * 12 / 2,
      Year_lower: this.options.column_width / 2,
      Year_upper: this.options.column_width * 30 / 2
    };

    return {
      upper_text: date_text[`${this.options.view_mode}_upper`],
      lower_text: date_text[`${this.options.view_mode}_lower`],
      upper_x: base_pos.x + x_pos[`${this.options.view_mode}_upper`],
      upper_y: base_pos.upper_y,
      lower_x: base_pos.x + x_pos[`${this.options.view_mode}_lower`],
      lower_y: base_pos.lower_y,
      workday: dayLowerInfo.workday
    };
  }

  // 绘制日期 - 从 this.dateList 拿数据
  get_date_from_dateList (date, isupper = true) {
    // const week_number_upper = {
    //   1: '一',
    //   2: '二',
    //   3: '三',
    //   4: '四',
    //   5: '五',
    //   6: '六',
    //   7: '天'
    // }
    if(this.dateList) {
      const date_string = date_utils.to_string(date)
      let info = this.dateList.filter(item => item.date === date_string)
      if(info.length === 1) {
        const today = date_utils.format(date, 'D', this.options.language);
        const yearMonth = date_utils.format(date, 'YYYY-MM', this.options.language);
        // return week?`周${week_number_upper[info[0].week]}`:(info[0].week===1?info[0].date:'')
        return {
          text: isupper?today:(today==='01'?yearMonth:''),
          workday: !info[0].workday
        }
      }
    }
    // return date_utils.format(date, 'D', this.options.language);
    // if(week) {
    //   return date.getDate() !== last_date.getDate()
    //     ? date_utils.format(date, 'D', this.options.language)
    //     : ''
    // } else {
    //   return date.getMonth() !== last_date.getMonth()
    //     ? date_utils.format(date, 'MMMM', this.options.language)
    //     : ''
    // }
  }

  // 绘制 bar
  make_bars() {
    this.bars = this.tasks.map(task => {
      // console.log(task)
      const bar = new Bar(this, task);
      this.layers.bar.appendChild(bar.group);
      return bar;
    });
  }

  // 绘制依赖箭头
  make_arrows() {
    this.arrows = [];
    for (let task of this.tasks) {
      let arrows = [];
      arrows = task.dependencies
        .map(task_id => {
          const dependency = this.get_task(task_id);
          if (!dependency || dependency.isParent) return;
          const arrow = new Arrow(
            this,
            this.bars[dependency._index], // from_task
            this.bars[task._index] // to_task
          );
          this.layers.arrow.appendChild(arrow.element);
          return arrow;
        })
        .filter(Boolean); // filter falsy values
      this.arrows = this.arrows.concat(arrows);
    }
  }

  map_arrows_on_bars() {
    for (let bar of this.bars) {
      bar.arrows = this.arrows.filter(arrow => {
        return (
          arrow.from_task.task.id === bar.task.id ||
          arrow.to_task.task.id === bar.task.id
        );
      });
    }
  }

  set_width() {
    const cur_width = this.$svg.getBoundingClientRect().width;
    const actual_width = this.$svg
      .querySelector('.grid .grid-row')
      .getAttribute('width');
    this.$svg.setAttribute('width', actual_width);
    this.$headerSvg.setAttribute('width', actual_width);
    // if (cur_width < actual_width) {
    //   this.$svg.setAttribute('width', actual_width);
    //   this.$headerSvg.setAttribute('width', actual_width);
    // }
  }

  set_scroll_position() {
    const parent_element = this.$svg.parentElement;
    if (!parent_element) return;

    const hours_before_first_task = date_utils.diff(
      this.get_oldest_starting_date(),
      this.gantt_start,
      'hour'
    );

    const scroll_pos =
      hours_before_first_task /
      this.options.step *
      this.options.column_width -
      this.options.column_width;

    parent_element.scrollLeft = scroll_pos;
  }

  // 绑定 grid popup_trigger 事件(由 option 传入的事件) 到指定节点上
  bind_grid_click() {
    $.on(
      this.$svg,
      this.options.popup_trigger,
      '.grid-row, .grid-header',
      () => {
        this.unselect_all();
        this.hide_popup();
      }
    );
  }

  // 绑定 bar 操作事件，主要是内部的操作，用于增加 bar 长度
  bind_bar_events() {
    return ;
    let is_dragging = false;
    let x_on_start = 0;
    let y_on_start = 0;
    let is_resizing_left = false;
    let is_resizing_right = false;
    let parent_bar_id = null;
    let bars = []; // instanceof Bar
    this.bar_being_dragged = null;

    function action_in_progress() {
      return is_dragging || is_resizing_left || is_resizing_right;
    }

    $.on(this.$svg, 'mousedown', '.bar-wrapper, .handle', (e, element) => {
      const bar_wrapper = $.closest('.bar-wrapper', element);

      if (element.classList.contains('left')) {
        is_resizing_left = true;
      } else if (element.classList.contains('right')) {
        is_resizing_right = true;
      } else if (element.classList.contains('bar-wrapper')) {
        is_dragging = true;
      }

      bar_wrapper.classList.add('active');

      x_on_start = e.offsetX;
      y_on_start = e.offsetY;

      parent_bar_id = bar_wrapper.getAttribute('data-id');
      const ids = [
        parent_bar_id,
        ...this.get_all_dependent_tasks(parent_bar_id)
      ];
      bars = ids.map(id => this.get_bar(id));

      this.bar_being_dragged = parent_bar_id;

      bars.forEach(bar => {
        const $bar = bar.$bar;
        $bar.ox = $bar.getX();
        $bar.oy = $bar.getY();
        $bar.owidth = $bar.getWidth();
        $bar.finaldx = 0;
      });
    });

    $.on(this.$svg, 'mousemove', e => {
      if (!action_in_progress()) return;
      const dx = e.offsetX - x_on_start;
      const dy = e.offsetY - y_on_start;

      bars.forEach(bar => {
        const $bar = bar.$bar;
        $bar.finaldx = this.get_snap_position(dx);

        if (is_resizing_left) {
          if (parent_bar_id === bar.task.id) {
            bar.update_bar_position({
              x: $bar.ox + $bar.finaldx,
              width: $bar.owidth - $bar.finaldx
            });
          } else {
            bar.update_bar_position({
              x: $bar.ox + $bar.finaldx
            });
          }
        } else if (is_resizing_right) {
          if (parent_bar_id === bar.task.id) {
            bar.update_bar_position({
              width: $bar.owidth + $bar.finaldx
            });
          }
        } else if (is_dragging) {
          bar.update_bar_position({ x: $bar.ox + $bar.finaldx });
        }
      });
    });

    document.addEventListener('mouseup', e => {
      if (is_dragging || is_resizing_left || is_resizing_right) {
        bars.forEach(bar => bar.group.classList.remove('active'));
      }

      is_dragging = false;
      is_resizing_left = false;
      is_resizing_right = false;
    });

    $.on(this.$svg, 'mouseup', e => {
      this.bar_being_dragged = null;
      bars.forEach(bar => {
        const $bar = bar.$bar;
        if (!$bar.finaldx) return;
        bar.date_changed();
        bar.set_action_completed();
      });
    });

    this.bind_bar_progress();
  }

  // 绑定滚动事件，设置 header top
  bind_grid_scroll() {
    const scrollEvent = () => {
      this.$headercontainer.style.top = this.$container.scrollTop + 'px'
      if(this.options.scrollCallback) {
        this.options.scrollCallback(this.$container.scrollTop)
      }
    }
    this.$container.removeEventListener('scroll', scrollEvent)
    this.$container.addEventListener('scroll', scrollEvent)
  }

  // 绑定鼠标悬浮事件
  bind_mouseover_events() {
    const mouseoverEvent = (e) => {
      if(e.target.getAttribute('class').indexOf('grid-row') === -1) {return ;}
      let num = null;
      for(let i=0;i<this.rows.length;i++) {
        if(this.rows[i].isEqualNode(e.target)) {
          num = i;
          break;
        }
      }
      if(/\D/.test(num)) {return ;}
      this.row_active_set(num)
      this.options.hoverCallback&&this.options.hoverCallback(num)
    }
    const mouseOutEvent = () => {
      this.row_active_set(this.rows.length)
      this.options.hoverCallback&&this.options.hoverCallback(this.rows.length)
    }
    this.layers.grid.removeEventListener('mouseover', mouseoverEvent)
    this.layers.grid.addEventListener('mouseover', mouseoverEvent)
    this.layers.grid.removeEventListener('mouseout', mouseOutEvent)
    this.layers.grid.addEventListener('mouseout', mouseOutEvent)
    this.options.activeSet&&this.options.activeSet(this.row_active_set.bind(this))
  }
  // 设置当前活跃的 row, 允许传入一个大的 num 用于移除所有行的 el-table-active
  row_active_set(num) {
    if(/\D/.test(num)) {return ;}
    this.rows.forEach((item, index) => {
      if(item.getAttribute('class').indexOf('grid-row-active') > -1) {
        item.setAttribute('class', 'grid-row')
      }
      if(index === num) {
        item.setAttribute('class', 'grid-row grid-row-active')
      }
    })
  }

  bind_bar_progress() {
    return ;
    let x_on_start = 0;
    let y_on_start = 0;
    let is_resizing = null;
    let bar = null;
    let $bar_progress = null;
    let $bar = null;

    $.on(this.$svg, 'mousedown', '.handle.progress', (e, handle) => {
      is_resizing = true;
      x_on_start = e.offsetX;
      y_on_start = e.offsetY;

      const $bar_wrapper = $.closest('.bar-wrapper', handle);
      const id = $bar_wrapper.getAttribute('data-id');
      bar = this.get_bar(id);

      $bar_progress = bar.$bar_progress;
      $bar = bar.$bar;

      $bar_progress.finaldx = 0;
      $bar_progress.owidth = $bar_progress.getWidth();
      $bar_progress.min_dx = -$bar_progress.getWidth();
      $bar_progress.max_dx = $bar.getWidth() - $bar_progress.getWidth();
    });

    $.on(this.$svg, 'mousemove', e => {
      if (!is_resizing) return;
      let dx = e.offsetX - x_on_start;
      let dy = e.offsetY - y_on_start;

      if (dx > $bar_progress.max_dx) {
        dx = $bar_progress.max_dx;
      }
      if (dx < $bar_progress.min_dx) {
        dx = $bar_progress.min_dx;
      }

      const $handle = bar.$handle_progress;
      $.attr($bar_progress, 'width', $bar_progress.owidth + dx);
      $.attr($handle, 'points', bar.get_progress_polygon_points());
      $bar_progress.finaldx = dx;
    });

    $.on(this.$svg, 'mouseup', () => {
      is_resizing = false;
      if (!($bar_progress && $bar_progress.finaldx)) return;
      bar.progress_changed();
      bar.set_action_completed();
    });
  }

  get_all_dependent_tasks(task_id) {
    let out = [];
    let to_process = [task_id];
    while (to_process.length) {
      const deps = to_process.reduce((acc, curr) => {
        acc = acc.concat(this.dependency_map[curr]);
        return acc;
      }, []);

      out = out.concat(deps);
      to_process = deps.filter(d => !to_process.includes(d));
    }

    return out.filter(Boolean);
  }

  get_snap_position(dx) {
    let odx = dx,
      rem,
      position;

    if (this.view_is('Week')) {
      rem = dx % (this.options.column_width / 7);
      position =
        odx -
        rem +
        (rem < this.options.column_width / 14
          ? 0
          : this.options.column_width / 7);
    } else if (this.view_is('Month')) {
      rem = dx % (this.options.column_width / 30);
      position =
        odx -
        rem +
        (rem < this.options.column_width / 60
          ? 0
          : this.options.column_width / 30);
    } else {
      rem = dx % this.options.column_width;
      position =
        odx -
        rem +
        (rem < this.options.column_width / 2
          ? 0
          : this.options.column_width);
    }
    return position;
  }

  unselect_all() {
    [...this.$svg.querySelectorAll('.bar-wrapper')].forEach(el => {
      el.classList.remove('active');
    });
  }

  view_is(modes) {
    if (typeof modes === 'string') {
      return this.options.view_mode === modes;
    }

    if (Array.isArray(modes)) {
      return modes.some(mode => this.options.view_mode === mode);
    }

    return false;
  }

  get_task(id) {
    return this.tasks.find(task => {
      return task.id === id;
    });
  }

  get_bar(id) {
    return this.bars.find(bar => {
      return bar.task.id === id;
    });
  }

  show_popup(options) {
    if (!this.popup) {
      this.popup = new Popup(
        this.popup_wrapper,
        this.options.custom_popup_html
      );
    }
    this.popup.show(options);
  }

  hide_popup() {
    this.popup && this.popup.hide();
  }

  trigger_event(event, args) {
    if (this.options['on_' + event]) {
      this.options['on_' + event].apply(null, args);
    }
  }

  /**
   * Gets the oldest starting date from the list of tasks
   *
   * @returns Date
   * @memberof Gantt
   */
  get_oldest_starting_date() {
    return this.tasks
      .map(task => task._start)
      .reduce(
        (prev_date, cur_date) =>
          cur_date <= prev_date ? cur_date : prev_date
      );
  }

  /**
   * Clear all elements from the parent svg element
   *
   * @memberof Gantt
   */
  clear() {
    this.$svg.innerHTML = '';
  }
}

function generate_id(task) {
  return (
    task.name +
    '_' +
    Math.random()
      .toString(36)
      .slice(2, 12)
  );
}
