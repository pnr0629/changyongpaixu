<template>
  <!-- 文件上传框 -->
  <div class="doc-upload">
    <div ref="fileUploadBox">
    <!-- <el-upload
      class="bug-attachment-upload-box fileUploadBoxMini"
      :class="{'el-upload-hidden': !fileUpdaloadBoxStatus}"
      multiple
      drag
      :show-file-list="false"
      list-type="text"
      :action="uploadInfo.uploadActionUrl"
      :data="uploadInfo.upoladID"
      :on-progress="fileuploadprocess"
      :on-success="handleUploadSuccess"
      :before-upload="sizecheck"
    >
      <template v-if="!uploading.type">
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">
          将文件拖到此处，或
          <em>点击上传</em>
        </div>
      </template>
      <template v-else>
        <el-progress class="file-upload-process" :percentage="uploading.process"></el-progress>
      </template>
    </el-upload> -->
    <el-popover
      placement="bottom"
      popper-class="file-popper"
      trigger="click">
      <div class="cursor-pointer file-plus-hover" @click="docVisible=true">关联文档</div>
      <el-upload
      style="display: inline-block;"
      class="bug-attachment-upload-box fileUploadBoxMini"
      :class="{'el-upload-hidden': !fileUpdaloadBoxStatus}"
      multiple
      drag
      :show-file-list="false"
      list-type="text"
      :action="uploadInfo.uploadActionUrl"
      :data="uploadInfo.upoladID"
      :on-progress="fileuploadprocess"
      :on-success="handleUploadSuccess"
      :before-upload="sizecheck"
    >
      <template v-if="!uploading.type">
        <div class="cursor-pointer file-plus-hover" @click="uploadDocFun">上传文档</div>
      </template>
      <template v-else>
        <el-progress class="file-upload-process" :percentage="uploading.process"></el-progress>
      </template>
    </el-upload>
      
      <span slot="reference" style="vertical-align: top;" class="upload-btn">附件上传</span>
    </el-popover>
    
    <el-upload
      class="bug-attachment-upload-box fileUploadBoxMini"
      :class="{'el-upload-hidden': !fileUpdaloadBoxStatus}"
      multiple
      drag
      :show-file-list="false"
      :action="uploadInfo.uploadActionUrl"
      :data="uploadInfo.upoladID"
      :on-progress="fileuploadprocess"
      :on-success="handleUploadSuccess"
      :before-upload="sizecheck"
    >
      <template v-if="!uploading.type">
        <!-- <i class="el-icon-upload"></i> -->
        <div class="el-upload__text">
          或拖拽文件到此处上传（大小限制为250M)
        </div>
      </template>
      <template v-else>
        <el-progress class="file-upload-process" :percentage="uploading.process"></el-progress>
      </template>
    </el-upload>
    <div class="filelist-box">
      <div class="filelist-item" v-for="item in fileList" :key="item.id">
        <div class="fl" style="margin-top: 10px;">
          <!-- <i class="iconfont" style="font-size: 26px;"
           :class="iconClass[item.typeName]?iconClass[item.typeName]:'#icon-TET'"
           ></i> -->
           <svg class="icon" aria-hidden="true" style="font-size: 30px;"> <use :xlink:href="iconClass[item.typeName]?iconClass[item.typeName]:'#icon-TET'"></use></svg>
        </div>
        <div>
          <span class="filelist-item-title ellipsis docellipsis"
           @click.stop="handleFileDownload(item)" :title="item.name" style="color:#484747;vertical-align: text-top;">{{item.name}}</span>
          <div class="filelist-doc-box">
            <div class="filelist-doc-box-title docellipsis" :title="item.createUser.concat(' ',item.createTime)">
              {{item.createUser}}&nbsp;{{item.createTime}}
              <!-- <span class="filelist-doc-item  docellipsis" style=""></span> -->
            </div>
            <span class="file-delete-btn link-common" @click.stop="handleFileBeforeRemove(item, 'task')">
              <i class="el-icon-delete"></i>
            </span>
          </div>
        </div>
      </div>
    </div>
    
  </div>
   <!-- 关联文档弹窗 -->
    <el-dialog title="关联文档" :visible.sync="docVisible"
    :modal-append-to-body="false"
     width="500px" >
     
       <el-input v-model="docSearch" placeholder="" suffix-icon="el-icon-search"></el-input>
       <div style="height: 300px;overflow: auto;" class="scrollbal-common">
          <el-tree :data="docTreeData" :props="defaultProps" node-key="key" :check-strictly="true" default-expand-all
            v-loading="loading" 
            :filter-node-method="filterNode" 
            ref="docTree"
            @check-change="checkChange"
            show-checkbox>
            <div class="iconmorebox" slot-scope="scope">
              <i class="iconfont icon-folder" v-if="scope.data.nodeType"></i>
              <i class="iconfont icon-wenjian" v-else></i>
              <span>{{scope.node.label}}</span>
            </div>
          </el-tree>
        </div>
     
      <span slot="footer" class="dialog-footer">
        <el-button @click="docVisible = false">取 消</el-button>
        <el-button type="primary" @click="docSuerBtn">确 定</el-button>
      </span>
    </el-dialog>
  </div>
  
</template>

<script>
/**
 * @title 关联工作项
 * @desc 缺陷：只能关联一种类型、选择一页的数据关联
 * @desc 2019-8-21修改上传附件并添加button
 * @author heyunjiang
 * @date 2019-3-28
 */
export default {
  name: "FileUpload",
  props: {
    fileUpdaloadBoxStatus: {
      type: Boolean,
      required: false,
      default: true,
      desc: '缺陷上传框是否展示'
    },
    uploadedFileList: {
      type: Array,
      required: true,
      desc: '已经上传的文件列表'
    },
    handleFileDelete: {
      type: Function,
      required: true,
      desc: '删除文件的回调'
    },
    handleUploadSuccess: {
      type: Function,
      required: true,
      desc: '上传文件成功的回调'
    },
    detailInfoId: {
      type: [Number, String],
      required: false,
      default: 0,
      desc: '当前文件上传框所属需求/任务/缺陷/其他 的 id，可不传，默认为0，则为新建'
    },
    workItemType: {
      type: [Number, String],
      required: true,
      desc: '当前文件上传框所属需求/任务/缺陷/其他 的 类型，分别对应 0,1,2'
    }
  },
  data() {
    return {
      uploading: {
        type: false,
        process: 0,
      },
      docSearch:'',
      docVisible:false,
      defaultProps:{},
      docTreeData:[],
      loading:false,
      docPucbli:{},//临时存储关联文档公共数据
      iconClass:{'xlsx':'#icon-ECEL',
        'json':'#icon-zonghewendang',
        'ppt':'#icon-PPT',
        'txt':'#icon-TET',
        'png':'#icon-PNG',
        'gif':'#icon-GIF',
        'jpge':'#icon-JPG',
        'zip':'#icon-ZIP',
        'mp4':'#icon-VIDEO'
      }
    };
  },
  computed: {
    // 文件上传 - 附带信息 (当切换缺陷时，保证上传信息也更新)
    uploadInfo: function() {
      return {
        uploadActionUrl: $http.api.attachment.upload.url,
        upoladID: {
          workItemType: +this.workItemType,
          workItemId: +this.detailInfoId
        }
      };
    },
    fileList: function() {
      return this.uploadedFileList.map(item => {
        return {
          ...item,
          name: item.name || item.origName,
          typeName:item.name?item.name.substring(item.name.lastIndexOf(".")+1,item.name.length):item.origName.substring(item.origName.lastIndexOf(".")+1,item.origName.length)
        };
      });
    }
  },
  watch: {
    docVisible:function(newVal, oldVal){
      if(newVal){
        this.getDocTreeQuery();
        this.hideTips();
        // this.docTreeData[0].children.push([]);
        // this.$nextTick(()=>{
        //   this.$refs.docTree.setCheckedKeys([]);
        // })
      }
    },
    docSearch:function(newVal, oldVal) {
      this.$refs.docTree.filter(newVal);
    }
  },
  methods: {
    // 文件上传 - 文件删除之前判断
    handleFileBeforeRemove(file) {
      let that = this
      this.$confirm(`确定移除 ${file.name}？`).then(function() {
        that.handleFileDelete(file)
      }).catch(_=>_)
    },
    // 文件上传 - 文件下载
    handleFileDownload(file) {
      const url = file.url;
      const targetElement = this.$refs.fileUploadBox;
      if (
        !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) &&
        document.body.clientWidth < 769
      ) {
        window.location.href = url;
      }
      let tempLink = document.createElement("a");
      tempLink.style.display = "none";
      tempLink.href = url;
      tempLink.setAttribute("download", "");
      if (typeof tempLink.download === "undefined") {
        tempLink.setAttribute("target", "_blank");
      }
      targetElement.appendChild(tempLink);
      tempLink.click();
      targetElement.removeChild(tempLink);
    },
    // 文件上传 - 上传进度控制
    fileuploadprocess(process) {
      if(process && process.percent && process.percent < 100) {
        this.uploading = {
          type: true,
          process: process.percent.toFixed(0)
        }
      } else {
        this.uploading = {
          type: false,
          process: 0
        }
      }
    },
    // 文件上传 - 大小控制 256m
    sizecheck(file) {
      if(file.size && file.size < 256000000) {
        return true;
      }
      this.$message({
        message: '允许上传文件的大小上限为 256 M',
        type: 'error'
      })
      return false;
    },
    //获取关联文档信息
    getDocTreeQuery(){
      this.loading = true;
      $http.get($http.api.document.doc_tree_query,{projectId:this.getUrlParams().projectId}).then(res =>{
        if (res.status==200){
          this.docTreeData = [{id: -32, key:'e', projectId: 100001,nodeType: 1,disabled: true,name: "全部文件", label: "全部文件", parentId: 0, children: [...res.data]}]
          this.loading = false;
        }
      }).catch(e =>{

      })
    },
    //搜索关联文档
    filterNode(value, data) {
      if (!value) return true;
      return data.label.indexOf(value) !== -1;
    },
    //关联文档多选只能单选
    checkChange(data,checked,child){  
      if (checked) {
        let arr = [data.id];
        this.docPucbli=data;
        this.$refs.docTree.setCheckedKeys([]);
        this.$refs.docTree.setCheckedKeys(arr);
        
      }
    },
    //点击上传文档时隐藏tips
    uploadDocFun(){
      this.hideTips();
    },
    //隐藏tips
    hideTips(){
      let classList = [...document.getElementsByClassName("file-popper")]
      classList.forEach(el => {
        el.style.display = 'none'
      });
    },
    //关联文档
    // associatedDocFun(data){
    //   this.docPucbli = data;
    //   this.hideTips();
    // },
    //确认关联文档
    docSuerBtn(){
      let data = this.docPucbli
      if(!data.id){
        this.$message({
          type: 'info',
          message: '请选择关联的文档'
        });
        return false;
      }
      let obj = {
        documentId:data.id,
        workItemType:parseInt(this.workItemType),
        workItemId:parseInt(this.detailInfoId)
      }
      $http.post($http.api.document.doc_association,obj,{type:'form'}).then(res =>{
        if (res.status==200){
          let typeName = res.data.origName.split('.')[1]
          let data = {...res.data,name:res.data.origName,createUser:res.data.display.createUser,typeName}
          this.uploadedFileList.push(data);
          this.$message({
            type: 'success',
            message: '关联文档成功!'
          });
          this.docVisible = false;
          this.docPucbli = {};
          this.$refs.docTree.setCheckedKeys([]);
        }
      }).catch(e =>{

      })
    }
  }
};

</script>

<style lang="scss" scoped>
@import "../../../base/style/common";
.file-upload-process {
  top: 50%;
  transform: translateY(-50%);
}
.file-plus-hover{
  display: block;
  margin-left: 1px;
  padding:2px 10px !important;
  &:hover{
    background: #409EFF;
    color: #ffffff;
  }
}
.docellipsis{
      padding: 0 3px !important;
}
.filelist-box {
  .filelist-item {
    margin: 0;
    padding: 0;
    // height: 30px;
    // line-height: 30px;
    // height: 30px;
    line-height: 15px;
    font-size: 0;
    .filelist-item-title {
      cursor: pointer;
      max-width: calc(100% - 60px);
      display: inline-block;
      font-size: 16px;
      height: 18px;
      &:hover {
        color: $color-font-active-common;
        text-decoration: underline;
      }
    }
    .filelist-doc-item{
      cursor: pointer;
      max-width: calc(100% - 60px);
      display: inline-block;
      font-size: 12px;
    }
    .filelist-doc-box{
      display: inline-block;
      margin-top: 4px;
      width: calc(100% - 60px);
      .filelist-doc-box-title{
        display: inline-block;
        max-width: calc(100% - 40px);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color:#797777;
        font-size: 10px;
      }
    }
    .file-delete-btn {
      float: right;
      // padding: 0 10px;
      font-size: 14px;
    }
  }
}
//icon
.bule{
  color:red;
}
.upload-btn{
    display: inline-block;
    vertical-align: top;
    padding: 5px 10px;
    background: #20a0ff;
    color: #ffffff;
    border-radius: 4px;
    cursor: pointer;
    &:hover{
      background: #038fec;
    }
}
</style>
