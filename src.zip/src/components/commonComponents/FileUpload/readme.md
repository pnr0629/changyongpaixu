# 文件上传组件

time: 2019.4.8  
author: heyunjiang

## 说明

通用文件上传组件

## 使用方式

```vue
<template>
    <file-upload :fileUpdaloadBoxStatus="fileUpdaloadBoxStatus" :uploadedFileList="uploadedFileList" :handleFileDelete="handleFileDelete"
              :detailInfoId="detailInfo.id" :handleUploadSuccess="handleUploadSuccess" workItemType="3"></file-upload>
</template>

import FileUpload from './FileUpload'

export default {
  name: "xxxx",
  components: {
    FileUpload
  }
}
```