<template>
  <div class="log-box" ref="logDetail">
    <p v-html="logDetail" style="word-wrap: break-word;word-break: break-all;"></p>
    <p v-show="offsets > 0">
      <i class="el-icon-loading"></i>
    </p>
  </div>
</template>
<script>
/**
 * @title 日志展示组件
 * @desc 是否获取整页数据，还是分当前阶段获取，需要后端判断
 * @desc 提供给外界可以动态初始化日志的接口: 提供 method init ，使用方式 this.$refs.logBox.init(), this.$refs.logBox.stop()
 * @method 支持的方法：init(), stop()
 * @author heyunjiang
 * @date 2019.7.1
 */
export default {
  name: "LogBox",
  components: {},
  mixins: [],
  props: {
    workflowTaskId: {
      type: [String, Number],
      required: true,
      desc: "task id"
    },
    currentSelectedWorkflow: {
      type: Object,
      required: true,
      desc: '当前活跃的 task'
    },
  },
  data() {
    return {
      WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
      logDetail: "",
      offsets: 0,
      loading: false, // 表示上次发的请求是否成功
      workflowInterval: null // 循环获取日志事件柄
    };
  },
  computed: {},
  watch: {
    workflowTaskId() {
      if (!this.workflowTaskId) { return; }
      this.loading = false;
      this.init();
    },
    logDetail() {
      this.$nextTick(() => {
        let logDetailDiv = this.$refs.logDetail;
        if (logDetailDiv) {
          logDetailDiv.scrollTop = logDetailDiv.scrollHeight
        }
      })
    }
  },
  mounted() { },
  beforeDestroy() {
    this.stop();
  },
  methods: {
    // 初始化，同时也是父组件调用的初始化方法
    init() {
      this.logDetail = "";
      this.offsets = 0;
      this.$nextTick(() => {
        this.getWorkflowLog();
        this.stop();
        this.workflowInterval = setInterval(() => {
          if(this.loading) {return ;}
          this.getWorkflowLog()
        }, 1500)
      })
    },
    stop() {
      if (this.workflowInterval) {
        clearInterval(this.workflowInterval);
      }
    },
    // 定义获取日志的事件
    // 查询流水线执行日志
    getWorkflowLog() {
      if (this.offsets == -1) {
        this.stop();
        return ;
      }
      let params = {
        workflowTaskId: this.workflowTaskId,
        offset: this.offsets
      };
      this.loading = true;
      $http.get($http.api.appdate.apipipelinelogs, params).then(res => {
        this.loading = false;
        if (res.status !== 200) {
          this.stop();
          return;
        }
        let str = res.data.logs;
        if (str && str.length > 0) {
          let lineArr = str.split("\n");
          let newStr = "";
          if (lineArr.length > 0) {
            lineArr.forEach(line => {
              if (line && line.length > 0) {
                if (
                  line.indexOf("[WARN]") > -1 ||
                  line.indexOf("[WARNING]") > -1
                ) {
                  newStr += '<span class="c-yellow">' + line + "</span><br/>";
                } else if (line.indexOf("[ERROR]") > -1) {
                  newStr += '<span class="c-error">' + line + "</span><br/>";
                } else {
                  newStr += line + "<br/>";
                }
              }
            });
          }

          this.logDetail += newStr;
        }
        this.offsets = res.data.offset;
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.log-box {
  display: inline-block;
  width: 100%;
  padding-left: 5px;
  min-height: 300px;
  max-height: 500px;
  overflow: auto;
  background: black;
  border-left: 0;
  color: aliceblue;
  word-wrap: break-word;
  word-break: break-word;
}
</style>
