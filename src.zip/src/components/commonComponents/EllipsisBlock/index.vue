<template>
  <div class="tooltip" ref="tooltip">
    <div @click.stop="spanClick" class="cursor-pointer"><span v-show="!showToolTip" ref="tooltipItem">{{value}}</span></div>
    <el-tooltip effect="dark" placement="top-start" v-show="showToolTip">
      <span class="tooltip-slot" slot="content">{{value}}</span>
      <span class="cursor-pointer" ref="tooltipInnerItem" @click.stop="spanClick">{{value}}</span>
    </el-tooltip>
  </div>
</template>
<script>
/**
 * @title 文字省略组件
 * @desc 用于需求分类树、滑窗工作项title
 * @author heyunjiang
 * @date 2019.6.17
 */
export default {
  name: "EllipsisBlock",
  components: {},
  mixins: [],
  props: {
    value: {
      type: String,
      required: true
    }
  },
  data() {
    return {
      showToolTip: false
    }
  },
  computed: {},
  watch: {
    value() {
      this.$nextTick(this.computedshowToolTip)
    }
  },
  mounted() {
    this.computedshowToolTip()
  },
  methods: {
    spanClick() {
      this.$emit('click');
    },
    computedshowToolTip() {
      const parentwidth = this.$refs.tooltip.getBoundingClientRect().width;
      let childWidth = 0;
      if(this.showToolTip) {
        childWidth = this.$refs.tooltipInnerItem.getBoundingClientRect().width;
      } else {
        childWidth = this.$refs.tooltipItem.getBoundingClientRect().width;
      }
      if(parentwidth < childWidth) {
        this.showToolTip = true;
      } else {
        this.showToolTip = false;
      }
    }
  }
}
</script>
<style lang="scss" scoped>
  .tooltip {
    display: inline-block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .tooltip-slot {
    display: inline-block;
    max-width: 100vw;
    box-sizing: border-box;
    padding: 0 10px;
  }
</style>
