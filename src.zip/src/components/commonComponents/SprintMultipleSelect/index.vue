<template>
  <ele-multi-cascader :options="sprintData" v-model="mulValue" :panelWidth="panelWidth" placeholder="选择迭代" :selectChildren="true"
    :clearable="true" @clickItem="itemClick"  @change="changeHandle" ></ele-multi-cascader>
</template>
<script>
  /**
   * @title 迭代多选：支持全部、已归档、未归档迭代
   * @desc 使用 EleMultiCascader 组件
   * @author heyunjiang
   * @date 2019.8.9
   */
  export default {
    name: "SprintMultipleSelect",
    components: {},
    model: {
      prop: 'value',
      event: 'change'
    },
    mixins: [],
    props: {
      value: Array,
      panelWidth:{
        type:[String,Number]
      },
      selectAllInit: {
        type: Boolean,
        required: false,
        default: false,
        desc: '是否初始选中全部'
      }
    },
    data() {
      return {
        mulValue: [-4],
        sprintData: [], // 封装好的数据格式
        sprintDataOriginal: [], // 保存获取到的数据
        lastCheckedInfo: {}, // 最后一次点击数据
        // isCheck:true
        recordData:[],//已归档数据
        unrecordData:[]//未归档数据
      }
    },
    computed: {},
    watch: {
      value(newVal,oldVal) {
        // console.log('value change', this.value,newVal,oldVal)
        // this.mulValue = [...this.value];
      },
    },
    mounted() {
      if (this.value.length > 0) {
        // this.mulValue = [...this.value]
      } else if (this.selectAllInit) {
        this.mulValue = [];
      }
      this.getSprintName();
    },
    methods: {
      changeHandle(val) { 
        const info = this.lastCheckedInfo;
        let result = [],childArr = [],arr = [];
        //获取全部已归档id
        this.recordData = JSON.parse(this.sprintData[1].children[0].data).map((item)=>{
          return item.id
        })
        //获取全部未归档id
        this.unrecordData = JSON.parse(this.sprintData[2].children[0].data).map((item)=>{
          return item.id
        })
        if(info.data){
          arr = JSON.parse(info.data)
        }
        // 如果选中或者反选了全部，则直接置空
        if (info.id === -1) {
          if(info.checked){
            result = [...this.unrecordData,...this.recordData,info.id,-3,-5]
          // result = result.filter(item => item !== -4)
            this.mulValue = result;
            this.$emit('recordFun', -1);
          }else{
            this.mulValue = [];
            this.$emit('recordFun', 0);
          }
          this.$emit('change', this.mulValue);
          //父级联全选被选中时隐藏全选tag
          this.displayTag('none')
        } else if(info.id === -3||info.id === -5){
          
          childArr=arr.map((item)=>{
            return item.id
          })
          if(!info.checked){
            // 未归档选框子联级全部checkbox取消选中时
            this.mulValue = this.mulValue.filter(item => !childArr.some(Ite => Ite === item));
            this.$emit('change', this.mulValue);
          }else{
            //为了隐藏已归档里的全部和已归档tag显示在select中
            this.displayTag('none')
            //已归档全部选中时
            result = this.mulValue.filter(item => item !== 'all');
            this.mulValue = result;
            this.mulValue.push(...childArr)
            this.mulValue.push(info.id)
            this.$emit('change', [...new Set(this.mulValue.filter(item => item !== -2 || item !== -4))]);
          } 
        }else {
          result = this.mulValue.filter(item => item !== 'all');
          this.mulValue = result;
          if(info.parent){
            if(info.checked){
              this.recordData.push(info.id)
            }else{
              this.recordData.splice(this.recordData.indexOf(info.id),1);
            } 
          }
          this.$emit('change', result.filter(item => item !== -3));
        }
        //判断输入框清空时mulValue是否有缓存数据
        if(this.mulValue.length>0&&val.length ==0){
          this.mulValue = val
          this.$emit('change', this.mulValue);
          this.$emit('recordFun', 0);
        }
        //判断选择的是未归档还是已归档
        let list = this.mulValue.filter(item => !this.unrecordData.some(Ite => Ite === item))//只留未归档
        let list1 = list.filter(item=>item !== -3 && item !== -2&&item !== "all"&&item !== -5)
        let list2 = this.mulValue.filter(item => this.unrecordData.some(Ite => Ite === item))//只留已归档
        if(list1.length>0&&list2.length>0){
          this.$emit('recordFun', -1);
        }else if(list1.length>0&&list2.length==0){
          this.$emit('recordFun', 0);
        }else if(list2.length>0&&list1.length==0){
          this.$emit('recordFun', 1);
        }else{
          this.$emit('recordFun', 0);
        }
        
      },
      //控制select的tag显示
      displayTag(text){
        let tagId = document.getElementById('selectMult');
        let tagPreant = tagId.children[0].getElementsByClassName('el-tag el-tag--info el-tag--mini')
        this.$nextTick(()=>{
          let tagText = tagId.children[0].getElementsByClassName('el-select__tags-text');
          for(let i=0;i<tagText.length;i++){
            if(['已归档','全部','未归档'].indexOf(tagText[i].innerHTML)!==-1){
              tagPreant[i].style.display = text
            } 
            if(tagText[i].innerHTML=='全部 ' ||tagText[i].innerHTML==' 全部'){
              tagPreant[i].style.display = text
            }
          }
        })
      },
      itemClick(info) {
        this.lastCheckedInfo = {...info};
      },
      // 初始化 - 获取迭代列表 - 首次获取第一页数据及总页数
      getSprintName() {
        $http.get($http.api.sprint.list_sprint_name).then(res => {
          if (res.status === 200 && Array.isArray(res.data)) {
            this.sprintDataOriginal = [...res.data];
            this.generateData()
          }
        });
      },
      // 封装数据格式
      generateData() {
        const originData = this.sprintDataOriginal;
        const activeData = originData.filter(item => item.status === 1); // 未归档迭代
        const inactiveData = originData.filter(item => item.status !== 1); // 已归档迭代
        this.sprintData = [
          { label: " 全部", id: -1, children: null, value: -1, isLeaf: true },
          {
            label: "已归档", id: -2,value: -2, isLeaf: false, children: [
              { label: '全部', id: -3, children: null, value: -3, isLeaf: true,data:JSON.stringify(
                  inactiveData.map(item => {
                    return { label: item.name, id: item.id, children: null, value: item.id, isLeaf: true }
                  })
                )}
                ,...inactiveData.map(item => {
                  return { label: item.name, id: item.id, children: null, value: item.id, isLeaf: true }
                })
            ]
            
          },
          {
            label: "未归档", id: -4,value: -4, isLeaf: false, children: [
              { label: '全部 ', id: -5, children: null, value: -5, isLeaf: true,data:JSON.stringify(
                  activeData.map(item => {
                    return { label: item.name, id: item.id, children: null, value: item.id, isLeaf: true }
                  })
                )}
                ,...activeData.map(item => {
                  return { label: item.name, id: item.id, children: null, value: item.id, isLeaf: true }
                })
            ]
            
          },
        ]
      }
    }
  }
</script>
<style lang="scss" scoped>
</style>