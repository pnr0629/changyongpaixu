<template>
  <date-picker ref="basicEndTime" :popper-class="popperClass" size="mini" v-model="dateValue" :type="type" prefix-icon="clean-icon" 
    value-format="yyyy-MM-dd" @change="selectChange" @blur="selectBlur" placeholder="选择日期" 
    :picker-options="pickerOptions" :rangeSeparator="rangeSeparator" :startPlaceholder="startPlaceholder" :endPlaceholder="endPlaceholder">
  </date-picker>
</template>
<script>
/**
 * @title 全局日期组件
 * @function1 日期增加今天、明天、可清空等功能
 * @function2 日期做周末、节假日标注功能
 * @author chengxuecheng、heyunjiang
 * @date 2019.8.20
 */
  import DatePicker from '../DatePicker/src/picker/date-picker';

  export default {
    name: "CustomDate",
    model: {
      prop: 'value',
      event: 'hello'
    },
    props: {
      value: [String, Date, Array],
      type: {
        type: String,
        default: 'date'
      },
      rangeSeparator: {
        type: String,
        default: '至'
      },
      startPlaceholder: {
        type: String,
        default: '开始日期'
      },
      endPlaceholder: {
        type: String,
        default: '结束日期'
      },
      popperClass: {
        type: String,
        default: 'el-date-default-popper-class'
      }
    },
    components: {
      DatePicker
    },
    data() {
      return {
        pickerOptions: {
          shortcuts: [{
            text: '今天',
            onClick(picker) {
              picker.$emit('pick', new Date());
            }
          },
          {
            text: '明天',
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() + 3600 * 1000 * 24);
              picker.$emit('pick', date);
            }
          },
          {
            text: '后天',
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() + 3600 * 1000 * 24 * 2);
              picker.$emit('pick', date);
            }
          },
          {
            text: '三天后',
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() + 3600 * 1000 * 24 * 3);
              picker.$emit('pick', date);
            }
          },
          {
            text: '一周后',
            onClick(picker) {
              const date = new Date();
              date.setTime(date.getTime() + 3600 * 1000 * 24 * 7);
              picker.$emit('pick', date);
            }
          },
          ]
        },
        dateValue:this.value,
      }
    },
    watch: {
      value() {
        this.dateValue = this.value;
      }
    },
    methods: {
      // 调用 element date-picker 的 focus method
      focus() {
        this.$refs.basicEndTime.focus()
      },
      //触发change外部传入的change事件
      selectChange(value){
        this.$emit('hello',value)
        this.$emit('change',value)
        // console.log('change',value)
      },
      //触发外部的blur方法
      selectBlur(value){
        this.$emit('blur',value)
        // console.log('blur',value)
      },
    }
  }
</script>
<style lang="scss" scope>
    @import "../../project/ProjectCommon.scss";
</style>