import XsStaffing from './Staffing.vue'

XsStaffing.install = function (Vue) {
  Vue.component('XsStaffing', XsStaffing);
};

// 导出组件
export default XsStaffing
