<template>
  <!--人员设置-->
  <el-dialog :title="staffingTitle"
             class="el-dialog-740w"
             :before-close="handleClose"
             :visible.sync="dialogVisible" :modal-append-to-body="true"
             :close-on-click-modal='shadeBtn'>
    <div class="form-iterm-box">
      <div class="label-name">
        <span class="label-title">开发人员：{{getDevName()}}</span>
      </div>
      <div class="label-name">
        <span class="label-title">测试人员：{{getTestName()}}</span>
      </div>
      <div class="tab-box">
        <el-tabs v-model="activeTab" type="border-card">
          <el-tab-pane label="开发人员管理" name="开发人员管理">
            <el-transfer
              filterable
              :titles="['未选开发人员', '已选开发人员']"
              filter-placeholder="请输入开发人员姓名"
              v-model="selectDevList"
              :data="devList">
            </el-transfer>
          </el-tab-pane>
          <el-tab-pane label="测试人员管理" name="测试人员管理">
            <el-transfer
              :titles="['未选测试人员', '已选测试人员']"
              filterable
              filter-placeholder="请输入测试人员姓名"
              v-model="selectTestList"
              :data="testList">
            </el-transfer>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
    <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr" @click="handleSure()">保存</el-button>
				<el-button class="fr mr10" @click="handleClose()">关闭</el-button>
			</span>
  </el-dialog>
</template>

<script>


  export default {
    name: "Staffing",

    data() {
      return {
        selectTestList: [],
        selectDevList: [],
        dialogVisible: false,  //通过确定弹窗
        shadeBtn: false, //禁止点击遮罩层关闭弹窗
        personList: [],
        activeTab: '开发人员管理',
      };
    },

    props: {
      staffingTitle: {
        type: String,
        default: function () {
          return "";
        }
      },
      devList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      initSelectDevList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      testList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      initSelectTestList: {
        type: Array,
        default: function () {
          return [];
        }
      },
      confirmClick: {
        type: Function,
        default: function (val1, val2) {
        }
      }
    },

    watch: {
      initSelectTestList() {
        this.selectTestList = this.initSelectTestList;
      },
      initSelectDevList() {
        this.selectDevList = this.initSelectDevList;
      }
    },

    mounted() {

    },

    computed: {},

    methods: {
      //人员设置弹窗
      showcCldProdRight_s() {
        this.dialogVisible = true;
      },

      //关闭弹窗
      handleClose() {
        this.dialogVisible = false;
      },
      getDevName() {
        if (this.selectDevList && this.selectDevList.length !== 0) {
          let arr = [];
          this.selectDevList.forEach(item => {
            this.devList.forEach(item1 => {
              if (item === item1.key) {
                arr.push(item1.label);
              }
            });
          });
          return arr.join("、");
        } else {
          return "";
        }
      },
      getTestName() {
        if (this.selectTestList && this.selectTestList.length !== 0) {
          let arr = [];
          this.selectTestList.forEach(item => {
            this.testList.forEach(item1 => {
              if (item === item1.key) {
                arr.push(item1.label);
              }
            });
          });
          return arr.join("、");
        } else {
          return "";
        }
      },

      //保存已选人员
      handleSure() {
        if (this.activeTab=='开发人员管理') {
          if (!this.selectDevList || this.selectDevList.length === 0) {
            this.$message({
              message: '请选择开发人员',
              type: 'warning'
            });
            return;
          }
          if (this.confirmClick) {
            this.confirmClick(1,this.selectDevList);
          }
        } else {
          if (!this.selectTestList || this.selectTestList.length === 0) {
            this.$message({
              message: '请选择测试人员',
              type: 'warning'
            });
            return;
          }
          if (this.confirmClick) {
            this.confirmClick(2,this.selectTestList);
          }
        }


      }
    }
  };
</script>

<style lang="scss">
  .label-name {
    display: inline-block;
    width: 100%;

    .label-title {
      margin: 5px 10px 5px 0px;
      display: inline-block;
    }

    .persName {
      display: inline-block;
      margin-left: 10px;
    }
  }

  .tab-box {
    min-height: 470px;
    margin-top: 10px;

    .el-tabs--top {
      min-height: 500px;
    }
  }
</style>
