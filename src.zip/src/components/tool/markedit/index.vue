<template>
  <div>
    <div class="editorclass">
      <quill-editor v-model="data" ref="myQuillEditor" :options="editorOption" @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
        @change="onEditorChange($event)" @paste="handlePaste($event)">
      </quill-editor>
      <el-upload style="display:none"  :action="uploadActionUrl" :data="upoladID" :show-file-list="false"
                 :before-upload='beforeUpload'  :on-success='uploadSuccess' ref="elUploadUd" class="elUploadUd">
      </el-upload >
    </div>
  </div>
</template>
<script>
  import {quillEditor} from 'vue-quill-editor'
  import Quill from 'quill';
  import { ImageDrop } from 'quill-image-drop-module';
  //import ImageResize from 'quill-image-resize-module-withfix';

  Quill.register('modules/imageDrop', ImageDrop);
  //Quill.register('modules/imageResize', ImageResize);

  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';

  export default {
    components: {
      quillEditor
    },
    props: {
      value: {
        type: String,
        default: ''
      },
    },
    watch: {
      data: {
        handler(newName, oldName) {
          if (oldName !== newName) {
            this.$emit("editHnadle", this.data)
          }
        },
        immediate: true
      },
      value() {
        this.data = this.value;
      }
    },
    data() {
      return {
        data: "",
        uploadActionUrl: $http.api.attachment.upload.url,
        upoladID: {
          workItemType: 16,
          workItemId: 0
        },
        editorOption: {
          modules: {
            imageDrop: true,
            // imageResize:{
            //   modules: [ 'Resize', 'DisplaySize', 'Toolbar' ],
            // },
            toolbar: {
              container: [
                ['bold', 'italic', 'underline', 'strike', 'image'],        // toggled buttons
                ['blockquote', 'code-block'], [{'list': 'ordered'}, {'list': 'bullet'}],
              ],
              handlers: {
                "image": this.imageHandlerCallback
              }
            },
          },
          placeholder: '在这里输入内容',
        }
      }
    },

    mounted() {
      this.data = this.value;
      // console.log($http.api.attachment.upload.url)
      this.$refs.myQuillEditor.quill.root.removeEventListener('paste', this.$refs.myQuillEditor.quill.getModule("imageDrop").handlePaste, false);
      this.handlePaste = this.handlePaste.bind(this.$refs.myQuillEditor);
      this.$refs.myQuillEditor.quill.root.addEventListener('paste', this.handlePaste, false);
    },
    methods: {
      // img 图标点击回调处理函数，用于触发 element-ui 的 upload 方法
      imageHandlerCallback(value) {
        if (value) {
          this.$refs.elUploadUd.$el.querySelector('.elUploadUd input').click();
        } else {
          this.$refs.myQuillEditor.quill.format('image', false);
        }
      },
      //自定义粘贴文件处理
      handlePaste(evt){
        evt.preventDefault();
        if (evt.clipboardData && evt.clipboardData.files && evt.clipboardData.files.length) {
          //文件对象上传，存储在ceph服务器中
          this.uploadPasteImage(evt.clipboardData.files[0]);
         
        }else if (evt.clipboardData && evt.clipboardData.items && evt.clipboardData.items.length) {
          evt.clipboardData.items[0].getAsString((data)=>{
            let myQuillEditor = this.$refs.myQuillEditor;
            let index = myQuillEditor.quill.selection.savedRange.index;
            this.$refs.myQuillEditor.quill.insertText(index,data);
          })
        }
      },
      //自定义粘贴文件上传
      uploadPasteImage(data) {
        let formData = new FormData;
        formData.append('file', data);
        formData.append("workItemType", this.upoladID.workItemType);
        formData.append("workItemId", this.upoladID.workItemId);
        let config = {'Content-Type': 'multipart/form-data'};
        if (this.beforeUpload(data)){
          $http.post($http.api.attachment.upload, formData,config).then(res => {
            this.uploadSuccess(res);
          }).catch(e => {
            this.$message.error('上传失败');
          })
        }
      },
      //上传图片前的检查
      beforeUpload(file){
        const isJPG = file.type === 'image/jpeg' || file.type ===  'image/png';
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isJPG) {
          this.$message.error('上传图片只能是 JPG或PNG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      },
      //上传图片成功回调
      uploadSuccess(response){
        if(response.status===200){
          var addImgRange = this.$refs.myQuillEditor.quill.getSelection();
          // console.log(this.$refs.myQuillEditor)
          this.$refs.myQuillEditor.quill.insertEmbed(addImgRange != null?addImgRange.index:0, 'image',response.data.url)
        }
      },
      onEditorReady(editor) { // 准备编辑器
      },
      onEditorBlur() { }, // 失去焦点事件
      onEditorFocus() { }, // 获得焦点事件
      onEditorChange() { }, // 内容改变事件
      escapeStringHTML(str) {
        str = str.replace(/&lt;/g, '<');
        str = str.replace(/&gt;/g, '>');
        return str;
      }
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
    }
  }
</script>
<style scoped>
  .editorclass {
    /* width: 400px;
    height: 400px; */
  }

  .ql-editor {
    min-height: 400px;
  }
</style>
