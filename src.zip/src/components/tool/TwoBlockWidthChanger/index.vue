<template>
  <div class="block-box" ref="blockBox">
    <span class="opreatebtn opreatebtn-left" v-show="enableCollspan&&!isLeftHidden" @click="handleLeft" ref="operatebtnLeft">
      <i :class="{'el-icon-d-arrow-left':!isLeftHidden, 'el-icon-d-arrow-right':isLeftHidden}" class="opreatebtn-icon"></i>
    </span>
    <span class="opreatebtn opreatebtn-right" v-show="enableCollspan&&!isRightHidden" @click="handleRight" ref="operatebtnRight">
      <i :class="{'el-icon-d-arrow-left':isRightHidden, 'el-icon-d-arrow-right':!isRightHidden}" class="opreatebtn-icon"></i>
    </span>
    <div class="block-box-left" :class="{'block-box-full':!showRight, 'left-box-fixed': isLeftBoxTop}" ref="blockBoxLeft">
      <slot name="left"></slot>
    </div>
    <div class="block-box-middle" :class="{'hidden': isLeftBoxTop, 'block-box-middle-tiny': barType==='tiny'}" v-show="showRight" ref="middleLine"></div>
    <div class="block-box-middle-proxy" :class="{'hidden': isLeftBoxTop, 'block-box-middle-tiny': barType==='tiny'}" v-show="showRight" ref="middleLineProxy"></div>
    <div class="block-box-right" v-show="showRight" ref="blockBoxRight">
      <slot name="right"></slot>
    </div>
  </div>
</template>
<script>
/**
 * @title 边界拖拽组件
 * @desc 
 * @author heyunjiang
 * @date 2019.7.23
 */
const barConfig = {
  tiny: 1,
  middle: 8
}
export default {
  name: "TwoBlockWidthChanger",
  components: {},
  mixins: [],
  props: {
    initLeftWidth: {
      type: [String, Number],
      required: false,
      desc: '初始时左侧block宽度，支持详细 px 值及百分比',
      default: 200
    },
    showRight: {
      type: Boolean,
      required: false,
      desc: '是否展示右侧部分',
      default: true
    },
    fixedLeft: {
      type: Boolean,
      required: false,
      desc: '是否在有需要时，固定左侧部分',
      default: false
    },
    enableCollspan: {
      type: Boolean,
      required: false,
      desc: '是否需要展开/收缩功能',
      default: false
    },
    barType: {
      type: String,
      required: false,
      desc: '中间 bar 类型',
      default: 'middle',
      validator: (value) => {
        return ['tiny', 'middle'].includes(value)
      }
    }
  },
  data() {
    return {
      isLeftBoxTop: false, // 左侧是否滚动到顶部了
      initWidthTypeNumber: true, // 初始左侧 block 宽度是否传入的是像素，不是百分比
      isLeftHidden: false, // 左侧是否隐藏
      isRightHidden: false, // 右侧是否隐藏
      letfBoxHeight: 0,
      rightBoxHeight: 0
    }
  },
  computed: {},
  watch: {
    initLeftWidth() {
      setTimeout(() => {
        this.middleLineDragEnd(this.computedLeftWidth(this.initLeftWidth));
        this.refreshMiddleLineHeight();
      })
    }
  },
  mounted() {
    this.init();
  },
  beforeDestroy() {
    this.uninit();
  },
  methods: {
    uninit() {
      try {
        window.removeEventListener('resize', this.initMiddleLineProxyEvent);
        this.fixedLeft&&window.removeEventListener('scroll', this.scrollHandle);
      } catch (e) {
        console.log(e)
      }
    },
    // 初始化
    init() {
      this.uninit();
      // 计算左侧初始宽度 - 不能保持父节点宽度不变化，所以有可能计算出来的百分比有点问题
      setTimeout(() => {
        this.middleLineDragEnd(this.computedLeftWidth(this.initLeftWidth));
      })
      this.$nextTick(() => {
        // 初始化中间栏拖拽事件
        this.initMiddleLineProxyEvent();
        // 计算 middleLine 和 middleLineProxy 的高度
        this.refreshMiddleLineHeight()
      });
      window.addEventListener('resize', this.initMiddleLineProxyEvent);
      this.fixedLeft&&window.addEventListener('scroll', this.scrollHandle);
    },
    // 中间栏拖拽 - 事件处理
    initMiddleLineProxyEvent() {
      const middleLine = this.$refs.middleLineProxy;
      const blockBoxLeft = this.$refs.blockBoxLeft;
      const blockBox = this.$refs.blockBox;
      const mousedownHandleEvent = event => {
        const middleLineRect = middleLine.getBoundingClientRect();
        const boxLeft = blockBoxLeft.getBoundingClientRect().left;
        const boxWidth = blockBox.getBoundingClientRect().width;
        const dragState = {
          startMouseLeft: event.clientX,
          startLeft: middleLineRect.left,
          endLeft: middleLineRect.left,
          canMoveLine: false
        }
        // 去掉默认的可选择、可拖拽功能
        document.onselectstart = function() { return false; };
        document.ondragstart = function() { return false; };

        const handleMouseMove = (e) => {
          if(this.isLeftHidden || this.isRightHidden) {return false;}
          const deltaLeft = e.clientX - dragState.startMouseLeft; // 鼠标移动 event 偏移量
          const proxyLeft = dragState.startLeft + deltaLeft - boxLeft;
          let leftWidth = Math.min(boxWidth - 100, Math.max(boxLeft, proxyLeft)) // 最短不能到左边框，最长不能到右边框
          leftWidth = this.computedLeftWidth(leftWidth);
          dragState.endLeft = leftWidth;
          dragState.canMoveLine = true;
          middleLine.style.left = leftWidth + 'px';
        }
        const handleMouseUp = () => {
          dragState.canMoveLine&&this.middleLineDragEnd(dragState.endLeft)
          document.removeEventListener('mousemove', handleMouseMove);
          document.removeEventListener('mouseup', handleMouseUp);
          document.onselectstart = null;
          document.ondragstart = null;
        }
        document.addEventListener('mousemove', handleMouseMove);
        document.addEventListener('mouseup', handleMouseUp);
      }
      middleLine.removeEventListener('mousedown', mousedownHandleEvent)
      middleLine.addEventListener('mousedown', mousedownHandleEvent)
    },
    // 中间栏拖拽 - 拖拽结束处理
    middleLineDragEnd(leftWidth) {
      leftWidth = Number(leftWidth);
      const leftWidthP = this.initWidthTypeNumber?(leftWidth + 'px'):(leftWidth + '%');

      this.$refs.operatebtnLeft.style.left = 'calc(' + leftWidthP +' - 11px)';
      this.$refs.operatebtnRight.style.left = 'calc(' + leftWidthP +' + 8px)';
      this.$refs.middleLine.style.left = leftWidthP;
      this.$refs.middleLineProxy.style.left = leftWidthP;
      this.$refs.blockBoxLeft.style.width = leftWidthP;
      this.$refs.blockBoxRight.style.width = this.initWidthTypeNumber?'calc(100% - ' + (8+leftWidth) + 'px)':'calc(' + (100 - (+leftWidth)) + '% - 8px)';
      this.$emit('dragend', leftWidthP)
    },
    // 滚动事件处理
    scrollHandle() {
      // 若果左块高度大于右块，则会出现界面闪烁
      if(this.letfBoxHeight > this.rightBoxHeight) {return ;}
      const sourceElement = this.$refs.blockBox
      if(sourceElement.getBoundingClientRect().top <= 0) {
        this.isLeftBoxTop = true;
      } else {
        this.isLeftBoxTop = false;
      }
    },
    // 计算左侧 block width 百分比
    computedLeftWidth(width) {
      if(/\%$/.test(width)) {
        this.initWidthTypeNumber = false;
        return width.replace(/\%/, '');
      } else {
        this.initWidthTypeNumber = true;
        return width;
      }
      
      // const boxWidth = this.$refs.blockBox.getBoundingClientRect().width;
      // width = Number(width);
      // return ((width*100)/boxWidth).toFixed(2);
    },
    // 计算中间线高度 - 保持跟左侧 block 一样高
    refreshMiddleLineHeight() {
      const boxLeftHeight = this.$refs.blockBoxLeft.getBoundingClientRect().height;
      this.$refs.middleLine.style.height = boxLeftHeight + 'px';
      this.$refs.middleLineProxy.style.height = boxLeftHeight + 'px';
      this.letfBoxHeight = boxLeftHeight;
      this.rightBoxHeight = this.$refs.blockBoxRight.getBoundingClientRect().height;
    },
    // 收起/展开 - 点击向左
    handleLeft() {
      // 如果右侧已经隐藏了
      if(this.isRightHidden) {
        this.middleLineDragEnd(this.computedLeftWidth(this.initLeftWidth));
        this.isRightHidden = false;
      } else {
        // 如果右侧没有隐藏，则为初始状态
        this.middleLineDragEnd(this.computedLeftWidth('0'));
        this.isLeftHidden = true;
      }
    },
    // 收起/展开 - 点击向右
    handleRight() {
      // 如果左侧已经隐藏了
      if(this.isLeftHidden) {
        this.middleLineDragEnd(this.computedLeftWidth(this.initLeftWidth));
        this.isLeftHidden = false;
      } else {
        // 如果左侧没有隐藏，则为初始状态
        this.middleLineDragEnd(this.computedLeftWidth('100%'));
        this.isRightHidden = true;
      }
    },
  }
}
</script>
<style lang="scss" scoped>
$header-height: 0;

.block-box {
  display: inline-block;
  width: 100%;
  overflow: hidden;
  position: relative;
  .block-box-left {
    float: left;
    width: 50%;
    min-height: $header-height;
    overflow: auto;
  }
  .block-box-full {
    width: 100%;
    height: auto;
  }
  .block-box-middl-common {
    position: absolute;
    display: inline-block;
    left: calc(50%);
    width: 8px;
    min-height: $header-height;
    box-sizing: border-box;
    cursor: col-resize;
    background: rgba(#d1d1d1, 0.2);
    z-index: 3;
    transition: background .3s ease-out;
  }
  .block-box-middle {
    @extend .block-box-middl-common;
  }
  .block-box-middle-proxy {
    @extend .block-box-middl-common;
    &:hover {
      background: #d1d1d1;
    }
  }
  .block-box-middle-tiny {
    width: 4px;
    border-left: 1px solid rgba(#d1d1d1, 0.2);
    background: transparent;
    &:hover {
      background: transparent;
    }
  }
  .block-box-right {
    @extend .block-box-left;
    float: right;
    box-sizing: border-box;
    width: calc(50% - 8px);
    margin-left: 8px;
    overflow: auto;
  }
  .left-box-fixed {
    position: fixed;
    top: 0;
  }
  .hidden {
    visibility: hidden;
  }
  // 收起功能
  .opreatebtn {
    position: absolute;
    top: 10px;
    display: inline-block;
    width: 11px;
    height: 35px;
    text-align: center;
    border-radius: 5px;
    color: white;
    background-color: #ccc;
    // border: 1px solid #ccc;
    z-index: 10;
    font-size: 12px;
    box-sizing: border-box;
    cursor: pointer;
    transition: background-color .1s ease-out;
    left: 0;
    &:hover {
      background-color: #9a9898;
    }
    .opreatebtn-icon {
      width: 10px;
      height: 35px;
      line-height: 35px;
    }
  }
  .opreatebtn.opreatebtn-left {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }
  .opreatebtn.opreatebtn-right {
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }
}
</style>
