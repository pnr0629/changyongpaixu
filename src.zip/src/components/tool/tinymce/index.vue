<template>
  <div class="tinymce-editor">
    <editor v-model="myValue" :init="init" :disabled="disabled">
    </editor>
    <el-upload style="display:none" :action="uploadActionUrl" :data="upoladID" :show-file-list="false"
      :before-upload='beforeUpload' :on-success='uploadSuccess' ref="elUploadUd" class="elUploadUd">
    </el-upload>
  </div>
</template>
<script>
  import tinymce from 'tinymce/tinymce'
  import Editor from '@tinymce/tinymce-vue'
  import 'tinymce/themes/silver'
  import './image'
  // import 'tinymce/plugins/media'
  import 'tinymce/plugins/table'
  import 'tinymce/plugins/lists'
  import 'tinymce/plugins/paste'
  import 'tinymce/plugins/autoresize'
  // import 'tinymce/plugins/contextmenu'
  import 'tinymce/plugins/wordcount'
  // import 'tinymce/plugins/colorpicker'
  // import 'tinymce/plugins/textcolor'
  import 'tinymce/plugins/fullscreen'
  // import 'tinymce/skins/content/default/content.css'
  // var imageSelector;
  // var imageSelectedCallback = null;


  export default {
    components: {
      Editor
    },
    props: {
      //传入一个value，使组件支持v-model绑定
      value: {
        type: String,
        default: ''
      },
      disabled: {
        type: Boolean,
        default: false
      },
      plugins: {
        type: [String, Array],
        default: 'lists image    wordcount  paste autoresize fullscreen'
      },
      toolbar: {
        type: [String, Array],
        default: 'undo redo | bold italic forecolor backcolor bullist  numlist  lists  imageCustom  fullscreen'
      },
      minHeigt: {
        type: [String, Number, Boolean],
      },
      maxHeigt: {
        type: [String, Number, Boolean],
      }, 
    },
    data() {
      return {
        //初始化配置
        uploadActionUrl: $http.api.attachment.upload.url,
        upoladID: {
          workItemType: 16,
          workItemId: 0
        },
        init: {
          language_url: '/static/langs/zh_CN.js',
          language: 'zh_CN',
          skin_url: '/static/tinymce/skins/ui/oxide',
          min_height: this.minHeigt ? this.minHeigt : 400,
          plugins: this.plugins,
          toolbar: this.toolbar,
          paste_data_images: true,
          branding: false,
          font: 14,
          menubar: false,
          convert_urls: false,
          content_css: false,
          setup: this.registerBtn,
          max_height: this.maxHeigt ? this.maxHeigt : null,
          //此处为图片上传处理函数
          images_upload_handler: (blobInfo, success, failure) => {
            var formData = new FormData();
            formData.append('file', blobInfo.blob(), blobInfo.filename());
            formData.append("workItemType", this.upoladID.workItemType);
            formData.append("workItemId", this.upoladID.workItemId);
            let config = { 'Content-Type': 'multipart/form-data' };
            $http.post($http.api.attachment.upload, formData, config).then(res => {
              success(res.data.url)
            }).catch(e => {
              this.$message.error('上传失败');
            })
          },

        },
        myValue: this.value,
        editor: null
      }
    },
    mounted() {
      tinymce.init({})
    },
    methods: {
      registerBtn(editor) {
        !this.editor && (this.editor = editor)
        editor.ui.registry.addButton('imageCustom', {
          icon: 'image',
          onAction: () => { this.imageHandlerCallback(editor) }
        })
      },
      mceFullScreenFuc() {
        // console.log(tinyMCE)
        tinyMCE.execCommand('mceFullScreen', true);
        //  tinyMCE.get('fullscreen').execCommand('mceFullScreen');
      },
      // img 图标点击回调处理函数，用于触发 element-ui 的 upload 方法
      imageHandlerCallback(value) {
        this.$refs.elUploadUd.$el.querySelector('.elUploadUd input').click();
      },
      // 图片上传前的格式检测
      beforeUpload(file) {
        const isJPG = file.type === 'image/jpeg' || file.type === 'image/png';
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isJPG) {
          this.$message.error('上传图片只能是 JPG或PNG 格式!');
        }
        if (!isLt2M) {
          this.$message.error('上传图片大小不能超过 2MB!');
        }
        return isJPG && isLt2M;
      },
      //上传图片成功回调
      uploadSuccess(response) {
        if (response.status === 200) {
          this.editor.execCommand('mceInsertContent', false, '<img alt="img" src="' + response.data.url + '"/>');
        }
      },
      //可以添加一些自己的自定义事件，如清空内容
      clear() {
        this.myValue = ''
      }
    },
    watch: {
      value(newValue) {
        this.myValue = this.value;
      },
      myValue: {
        handler(newName, oldName) {
          if (oldName !== newName) {
            this.$emit("watch", this.myValue);
          }
        },
        imediate: true
      }
    }
  }

</script>
<style scoped>
  .tinymce-editor {
    min-height: 200px;
  }
</style>
