<template>
  <div class="back-top-box" v-show="boxShow" @click="backTop">
    <i class="el-icon-arrow-up"></i>
  </div>
</template>
<script>
/**
 * @title 一键回到顶端
 * @desc 
 * @author heyunjiang
 * @date 
 */
export default {
  name: "BackTop",
  components: {},
  mixins: [],
  props: {
    show: {
      type: Boolean,
      required: false,
      default: true,
      desc: '是否展示'
    }
  },
  data() {
    return {
      documentElementScrollTopEnough: false
    }
  },
  computed: {
    boxShow() {
      return this.show && this.documentElementScrollTopEnough
    }
  },
  watch: {},
  mounted() {
    document.removeEventListener('scroll', this.scrollHandle)
    document.addEventListener('scroll', this.scrollHandle)
  },
  beforeDestroy() {
    document.removeEventListener('scroll', this.scrollHandle)
  },
  methods: {
    scrollHandle() {
      if(document.documentElement.scrollTop > 100) {
        this.documentElementScrollTopEnough = true;
      } else {
        this.documentElementScrollTopEnough = false;
      }
    },
    backTop() {
      document.documentElement.scrollTop = 0;
    }
  }
}
</script>
<style lang="scss" scoped>
  @keyframes colorChange {
    from {
      color: #ccc;
      // box-shadow: 2px 4px 4px #ccc;
    }
    to {
      color: #307FE2;
      // box-shadow: 1px 1px 4px #ccc;
    }
  }
  .back-top-box {
    position: fixed;
    display: inline-block;
    box-sizing: border-box;
    bottom: 50px;
    right: 50px;
    height: 50px;
    line-height: 50px;
    width: 50px;
    // border: 1px solid #ccc;
    border-radius: 3px;
    box-shadow: 2px 4px 4px #ccc;
    cursor: pointer;
    z-index: 9999;
    font-size: 30px;
    text-align: center;
    color: #ccc;
    animation: colorChange 2s alternate-reverse infinite;
    &:hover {
      background: #f3f5f2;
    }
  }
</style>
