<template>
  <div
    class="sider-right bug-content-box scrollbal-common"
    ref="side"
    id="contentBox"
  >
    <slot name="task"></slot>
  </div>
</template>
<script>
/**
 * author: heyunjiang
 * time: 2019.4.3
 */

export default {
  props: {
    show: {
      type: Boolean,
      default: false
    },
    beforeClose: {
      type: Function,
      desc: '关闭前的钩子，如果要做关闭前的判断，成功时可以调用 callback 来关闭滑块，也可以直接控制 show 来关闭滑块',
      required: false
    },
    afterClose: {
      type: Function,
      desc: '关闭后的钩子',
      required: false
    },
    screenHeight: String
  },
  data() {
    return {
      beforeBodyClass: '',
      slideShow: false, // 滑块是否关闭
      bindEventDom: document.getElementById('app') || document.documentElement,
      canCloseSlider: false // 是否可以关闭 slider ，搭配 mouseup mousedown 使用
    };
  },
  created: function() {
    document.body.className = document.body.className.replace(/[modal\-open]/g, '')
  },
  watch: {
    // 为什么需要从 show 到 slideShow 的中转，因为一个是 props ，一个是 data
    show: function(newName, oldName) {
      this.slideShow = newName
    },
    slideShow: function(newName, oldName) {
      if (newName) {
        this.handlerSileShow();
      } else {
        this.handlerSileHide();
      }
    }
  },
  methods: {
    // 展开滑块
    handlerSileShow() {
      // 滚动条
      this.beforeBodyClass = document.body.className.replace(/[modal\-open]/g, '')
      document.body.className = document.body.className + ' modal-open'
      // 偏移
      this.$refs.side.style.right = 0;
      this.$refs.side.style.minHeight = this.screenHeight;
      // 绑定事件
      let that = this
      this.bindEventDom.removeEventListener('mousedown', that.handerSliderMouseDown)
      this.bindEventDom.removeEventListener('mouseup', that.handerSliderClose)
      setTimeout(()=>{
        this.bindEventDom.addEventListener('mousedown', that.handerSliderMouseDown)
        this.bindEventDom.addEventListener('mouseup', that.handerSliderClose)
      })
    },
    // 关闭滑块
    handlerSileHide() {
      document.body.className = this.beforeBodyClass
      this.$refs.side.style.right = -71 + "%";
      // 关闭事件
      let that = this
      this.bindEventDom.removeEventListener('mousedown', that.handerSliderMouseDown)
      this.bindEventDom.removeEventListener('mouseup', that.handerSliderClose)
    },
    // 事件 mousedown handle ，绑定到 documentElement 上的事件，点击任意位置关闭
    handerSliderMouseDown(e) {
      if(this.$refs.side && this.$refs.side.contains(e.target)) {
        this.canCloseSlider = false; 
      } else {
        this.canCloseSlider = true;
      }
    },
    // 事件 handle ，绑定到 documentElement 上的事件，点击任意位置关闭
    handerSliderClose(e) {
      if(!this.canCloseSlider) {
        return false;
      } else {
        this.canCloseSlider = false
      }
      // debugger
      try {
        if(this.beforeClose) {
          this.beforeClose({
            cb: () => {
              this.slideShow = false
              this.afterClose&&this.afterClose()
            }
          })
        } else {
          this.slideShow = false
          this.afterClose&&this.afterClose()
        }
      } catch(_) {}
    }
  }
};
</script>
<style rel="stylesheet/css" scoped>
  .sider-right {
    width: 68%;

    background-color: #fff;

    position: fixed;
    z-index: 1099;
    right: -71%;
    overflow: hidden;
    transition: all 0.3s cubic-bezier(1, 0.5, 0.8, 1);

    overflow-y: auto;
    box-shadow: 0 1px 3px #ddd, inset 0 0 3px var(--color-white, #fff);
    border-left: 1px solid #dcdee3;
    bottom: 0;
    top: 0;
  }
</style>
