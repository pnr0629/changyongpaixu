<template>
  <div class="chain-box">
    <div class="chain-item" :class="{'chain-item-first':index===0}" v-for="(item, index) in data" :key="item.id">
      <div 
        class="chain-item-statubox" 
        :class="{'after-chain-line':index!==0}" 
        :style="{backgroundColor: JSON.parse(item.remark).color, color: 'white'}"
        v-if="item.remark&&JSON.parse(item.remark).color">{{item.changeValue}}</div>
      <div class="chain-item-statubox" :class="{'after-chain-line':index!==0}" v-else>{{item.changeValue}}</div>
      <div class="chain-item-footer">
        <span>{{item.opUserName}}</span>
        <span class="chain-item-footer-date">{{item.changeTime.split(' ')[0]}}</span>
        <span>{{item.changeTime.split(' ')[1]}}</span>
      </div>
    </div>
    <div class="load-more" @click="loadMore">{{isMore?'查看更早数据':'已无更多数据'}}</div>
  </div>
</template>

<script>
  /**
  * @title step 记录组件
  * @author heyunjiang
  * @date 2019-3-7
  */
  export default {
    name: "RecordChain",
    props: {
      data: {
        type: Array,
        required: true
      },
      loadmoreCallback: Function, // 加载更多
      isMore: {
        type: Boolean, // 是否有更多数据
        default: true
      }
    },
    data() {
      return {}
    },
    computed: {},
    created: function () {},
    methods: {
      loadMore() {
        this.isMore&&this.loadmoreCallback()
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../base/style/common';

  $chainLineWidth: 40px; // 连接线宽度

  .chain-box {
    padding: 10px 0 0;
    display: inline-block; // 构建 BFC
    width: 100%;
    .chain-item {
      float: left;
      min-width: 80px;
      padding: 0;
      margin: 0 0 20px $chainLineWidth;
      .chain-item-statubox {
        padding: 5px 10px;
        margin-bottom: 10px;
        box-sizing: border-box;
        text-align: center;
        box-shadow: 0 0 1px $color-text-bar;
        position: relative;
      }
      .chain-item-footer {
        span {
          display: block;
          text-align: center;
          height: 20px;
          line-height: 20px;
        }
      }
      .chain-item-footer-date {
        font-weight: bold;
      }
    }
    .chain-item-first {
      margin: 0;
    }
    .load-more {
      display: none;
      margin-left: 120px;
      margin-top: 10px;
      transform: translateX(-30px);
      color: $color-gray-common;
      font-size: $font-size-medium;
      cursor: pointer;
    }
  }
  .after-chain-line:before {
    content: '';
    position: absolute;
    top: 50%;
    left: -$chainLineWidth;
    width: $chainLineWidth;
    height: 1px;
    border-bottom: 1px solid $color-border-common;
  }
</style>
