# RecordChain

time: 2019.3.7  
author: heyunjiang

## 组件说明

一种记录信息流水组件，比如状态流转、操作步骤等
