<template>
  <div class="steps">
    <div class="node-line " :style="{'top':lifeCycleList.length<2?'29px':'29px'}">
        <!-- <span v-bind:style="{'display':config.isHaveSearch ? 'block':'none'}" >搜索</span> -->


    </div>
    <div class="step " v-for="(data,index) in lifeCycleList" :key="index">
      <div class="node-name ">
        {{data.title}}
      </div>
      <div class="circle">
        <div :class="index===0?a:b">
        </div>
      </div>

      <div class="node-content " v-html="data.content">
        <!-- {{data.content}} -->
      </div>

    </div>

  </div>
</template>
<script>

  export default {
    props: {
      show: {
        type: Boolean,
        default: false
      },
      lifeCycleList:{
        type: [Array, Object],
        required: false
       
      },
      screenHeight: String

    },
    data() {
      return {
        a: 'node-circle',
        b: 'node-circle1',
        loading: false,
        list: [],
      
      }
    },
    mounted(){
      // this.list = this.lifeCycleList
      // console.log(this.list)
    },
    updated() {
     
    },
    watch: {

    },
    methods: {
      
    }
  }

</script>
<style rel="stylesheet/css" scoped>
  .steps {
    position: relative;
    width: 500px;
  }

  .step {
    /* height: 120px; */
    /* line-height: 120px; */
    height: 120px;
  }

  .circle {
    display: inline-block;
    width: 30px;
    height: 30px;
    margin-left: 4%;
  }

  .node-name {
    color: #000;
    font-size: 22px;
    display: inline-block;
    text-align: center;
    width: 100px;
    
    /*
   height: 100px;
   line-height: 100px; */
  }

  .node-circle {
    width: 15px;
    height: 15px;
    border-radius: 100%;
    border: 3px solid #B0B0B0;
    display: inline-block;
    position: absolute;
    top: 8px;
  }

  .node-circle1 {
    width: 16px;
    height: 16px;
    border-radius: 100%;
    background-color: rgb(176, 176, 176);
    background-color: #666;
    display: inline-block;
    margin-left: 4%;
    position: relative;
    left: 2px;
    z-index: 2;
  }

  .node-line {
    position: absolute;
    left: 133px;
    /* top: 51px; */
    width: 4px;
    height: calc(100% - 50px);
    background: inherit;
    background-color: rgba(176, 176,176,1);
    background-color: #666;
  
    /* background-color: rgb(210, 210, 210); */
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    z-index: 1;

    border-radius: 0px;
    -webkit-box-shadow: none;
    box-shadow: none;
  }

  .node-content {
    width: 300px;
    min-width: 100px;
    padding: 15px 0;
    /* word-wrap: break-word; */
    /* min-height: 80px; */
    text-align: center;
    /* height: 20px; */
    /* line-height: 72px; */
    display: inline-block;
    word-wrap: break-word;
    background: #f5f5f5;
    border-radius: 10px;
    box-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
    margin-left: 6%;

  }
</style>