<template>
  <div class="field-edit-box" :class="{'editable-field':showOuterBorder && showText, 'field-input-box': inputType !== 'select'}">
    <span ref="selectBoxSibling" v-if="showText"
      class="cursor-pointer editable-field-label editable-field-label-ellipsis"
      @click="fieldClick" v-html="value"></span>
    <template v-if="status === 'active'">
      <!-- 单选、多选 -->
      <select-box v-if="inputType === 'select'"
        :colorType="colorType" 
        :localSearch="localSearch" 
        :selectValue="selectValue" 
        :onChange="onFieldValueChange" 
        :currentValue="initValue"
        :customInput="customInput"
        :customInputPlaceHolder="customInputPlaceHolder"
        :customInputChange="onCustomInputChange"
        :multiple="multiple"></select-box>
      <!-- 普通文本框、textarea输入 -->
      <el-input v-if="['text', 'textarea'].includes(inputType)" :type="inputType" v-model="inputTypeValue" class="editable-input el-input-lowheight"
        placeholder="请输入内容" @blur="unEditable" @change="unEditable" ref="textInput"></el-input>
      <!-- 简单时间框 -->
      <custom-date v-if="['date'].includes(inputType)" class="editable-input el-input-lowheight" v-model="inputTypeValue" 
        @blur="unEditable" placeholder="选择日期" ref="dateInput"></custom-date>
      <!-- 布尔值选择框 -->
      <!-- <el-radio-group v-if="type === 'BOOLEAN_ATTR' && !showFilterField" @change="updateModel" v-model="componentValue">
        <el-radio :label="true">是</el-radio>
        <el-radio :label="false">否</el-radio>
      </el-radio-group> -->
      <div @click.stop>
        <el-radio-group v-if="['boolean'].includes(inputType)" @change="unEditable" v-model="inputTypeValue">
          <el-radio :label="true">是</el-radio>
          <el-radio :label="false">否</el-radio>
        </el-radio-group>
      </div>
      <!-- 整数输入框, 浮点数输入框 -->
      <el-input type="number" v-if="['number'].includes(inputType)" @blur="unEditable" @change="unEditable" 
        class="editable-input el-input-lowheight" v-model.number="inputTypeValue" ref="numberInput"></el-input>
    </template>
  </div>
</template>

<script>
  /**
  * @title select 组件
  * @desc 缺陷：展示与否应该通过 props 更新，而不是自己控制，目前只支持在缺陷内部使用
  * @desc 目前支持功能：
  * @func 1 单选、多选、普通文本输入、日期输入、布尔输入、富文本输入、数字输入
  * @func 2 小圆圈、背景色、文字颜色
  * @func 3 展示值html可自行传入
  * @func 4 可搜索
  * @func 5 点击选项钩子
  * @func 6 点击展示值的事件 FieldEditFieldClick
  * @author heyunjiang
  * @date 2019-3-5
  * @update 2019.4.23
  */
  import SelectBox from './SelectBox'
  export default {
    name: "FieldEdit",
    components: {
      SelectBox
    },
    props: {
      inputType: {
        type: String,
        required: false,
        default: 'select',
        validator: value => {
          return ['select', 'text', 'textarea', 'boolean', 'number', 'date'].includes(value);
        }
      },
      initValue: {
        validator: (value) => { return true; },
        required: true,
        desc: '当前选择框的值，多选必须是 array'
      },
      initName: {
        type: String,
        required: false,
        desc: '当前选择框展示的值，名字取错了，不是初始值，是外部控制它的选中的展示值'
      },
      selectValue: {
        type: Array,
        required: false,
        default: () => {
          return [];
        },
        validator: function (value) {
          // 后面再验证，要求是 [{key, value}] 格式，并且 length > 1
          return true
        },
        desc: '选择框的所有选项'
      },
      onChange: {
        type: Function,
        required: false,
        default: function () {},
        desc: 'value 选择之后回调函数'
      },
      beforeSelect: {
        type: Function,
        required: false,
        desc: 'value 选择之前回调函数'
      },
      // select item 样式
      colorType: {
        type: String,
        required: false,
        desc: '目前支持小圆圈、背景、字体3种状态，默认无',
        validator: function(value) {
          return ['circle', 'bg', 'font'].indexOf(value) !== -1
        }
      },
      // 是否支持过滤
      localSearch: {
        type: Boolean,
        required: false,
        desc: '是否支持本地搜索',
      },
      // 是否展示鼠标悬浮外框
      showOuterBorder: {
        type: Boolean,
        required: false,
        default: true,
        desc: '是否展示鼠标悬浮外框'
      },
      multiple: {
        type: Boolean,
        required: false,
        default: false,
        desc: '是否支持多选'
      },
      customInput: {
        type: Boolean,
        required: false,
        default: false,
        desc: '是否允许自定义输入'
      },
      customInputPlaceHolder: {
        type: String,
        required: false,
        default: '自定义',
        desc: '是否允许自定义输入 placeholder'
      },
      customInputChange: {
        type: Function,
        required: false,
        desc: '自定义输入变化回调'
      },
    },
    data() {
      return {
        inputTypeValue: '',
        type: 'text',
        status: 'inactive' // inactive, active
      }
    },
    computed: {
      // 设置当前展示的 name
      value() {
        // console.log(this.selectValue)
        const selected = this.selectValue.filter(item => {
          return this.multiple?this.initValue.includes(item.key):item.key === this.initValue
        })
       // colorType
        return this.initName?this.initName:(selected.length>0?selected[0].value:'--')
      },
      // 绑定关闭的 dom ：#app, .bug-content-box
      listenerDom() {
        let arr = [document.getElementById('app')];
        if(this.$refs.selectBoxSibling) {
          arr.push(this.$refs.selectBoxSibling.closest('.bug-content-box'))
        }
        return arr;
      },
      // 是否展示 selectBoxSibling 文字，只有在 select 和 非 select 且 status 为 inactive 时展示
      showText() {
        return this.inputType === 'select' || (this.inputType !== 'select' && this.status === 'inactive');
      }
    },
    watch: {
      status() {
        if(this.status === 'inactive') {
          this.listenerDom.forEach(item => {
            item&&item.removeEventListener('click', this.bodyEvent)
          })
        } else {
          setTimeout(()=>{
            this.listenerDom.forEach(item => {
              item&&item.addEventListener('click', this.bodyEvent)
            })
          })
        }
      },
      // 当 initValue 变化时，更新 inputTypeValue 值
      initValue() {
        this.inputTypeValue = this.initValue;
      }
    },
    methods: {
      // 点击编辑框，进入编辑状态
      fieldClick() {
        this.status = 'active';
        this.$emit('FieldEditFieldClick');
        // 设置聚焦
        this.$nextTick(() => {
          let elementDom = null;
          switch(this.inputType) {
            case 'text' :
            case 'textarea' : elementDom = this.$refs.textInput;break;
            case 'date' : elementDom = this.$refs.dateInput;break;
            case 'number' : elementDom = this.$refs.numberInput;break;
          }
          elementDom && elementDom.focus()
        })
      },
      // select 值变化操作，只考虑点击项的时候做关闭前的钩子，不考虑点击任意位置关闭的钩子
      onFieldValueChange(result) {
        if(this.beforeSelect) {
          this.beforeSelect(result, hookResult => {
            if(hookResult && !this.multiple) {
              this.status = 'inactive';
            }
          })
        } else {
          if(!this.multiple) {
            this.status = 'inactive';
            this.onChange&&this.onChange(result.key);
          } else {
            this.onChange&&this.onChange(result);
          }
        }
      },
      // 输入框完成事件处理
      unEditable() {
        this.status = 'inactive';
        if(this.inputTypeValue === this.initValue) {return ;}
        this.onChange&&this.onChange(this.inputTypeValue);
      },
      // selectbox 展示框事件监听函数
      bodyEvent: function (e) {
        if(e.target.hasAttribute('data-type')&&e.target.getAttribute('data-type').indexOf('select-box')!==-1) {
        } else {
          // 外部任意位置点击
          this.status = 'inactive'
        }
      },
      // 自定义输入变化回调
      onCustomInputChange(value) {
        this.status = 'inactive';
        this.customInputChange&&this.customInputChange(value)
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../base/style/common';

  .field-edit-box {
    display: inline-block;
    padding: 0 5px;
    position: relative;
    height: 100%;
    box-sizing: border-box;
  }
  .editable-field {
    max-width: calc(100% - 105px); // 最大宽度
  }
  .editable-field:hover {
    box-shadow: 0 0 0 1px $color-gray-common;
  }
  .editable-field.active {
    box-shadow: 0 0 0 0 transparent;
  }
  // 如果为 input 类型的框
  .field-input-box {
    max-width: calc(100% - 105px); // 最大宽度
    vertical-align: top;
    .editable-input {
      width: 100%;
    }
  }
  .cursor-pointer {
    cursor: pointer;
  }
  .editable-field-label-ellipsis {
    width: 100%;
    display: inline-block;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 0 5px;
  }
</style>
