<template>
  <div class="table-input-edit-box pointerhover">
    <template v-if="!isEditable">
      <template v-if="['text'].includes(inputType)">
        <slot></slot>
        <i class="el-icon-edit table-input-edit-icon" @click="editable"></i>
      </template>
      <template v-else>
        <span @click="editable" class="ellipsis">
          <slot></slot>
        </span>
      </template>
    </template>
    <template v-if="isEditable">
      <el-input v-if="['text', 'progress'].includes(inputType)" v-model="currentData" class="editable-input"
        placeholder="请输入内容" @blur="unEditable" @change="unEditable" ref="editable"></el-input>
      <custom-date v-else ref="globalDatepicker" class="globalDatepicker" 
        v-model="currentData"   @blur="unEditable" 
        ></custom-date>
    </template>
  </div>
</template>
<script>
  /**
   * @title 支持 文本、日期
   * @desc
   * @author heyunjiang
   * @date
   */
  export default {
    name: "GlobalInput",
    components: {},
    mixins: [],
    props: {
      initValue: {
        type: [String, Number, Date],
        required: true,
        desc: "当前输入的初始值"
      },
      onChange: {
        type: Function,
        required: true,
        desc: "value 变化之后回调函数"
      },
      inputType: {
        type: String,
        required: false,
        default: "text",
        validator: value => {
          return ["text", "time", "progress"].includes(value);
        }
      },
      projectText:{
        type: String,
        required: false,
        default: "text",
      },
      daisableTime:{
        type: [String, Number],
        required: false,
        default: null,
      }
    },
    data() {
      return {
        isEditable: false, // 是否在编辑状态
        originalData: "",
        currentData: ""
      };
    },
    computed: {},
    watch: {
      initValue() {
        this.initData();
      },
    },
    created() { },
    mounted() {
      this.initData();
    },
    methods: {
      // 初始化數據
      initData() {
        this.originalData = this.initValue + "";
        this.currentData = this.initValue + "";
      },
      // 进入编辑状态
      editable() {
        this.isEditable = true;
        this.$nextTick(() => {
          ['text', 'progress'].includes(this.inputType) && this.$refs.editable.focus();
          this.inputType === 'time' && this.$refs.globalDatepicker.focus();
        });
      },
      // 编辑结束，进入未编辑状态
      unEditable() {
        this.isEditable = false;
        if (this.inputType === 'text' &&  this.currentData.trim().length === 0 ) {
          this.$message({
            message: "长度不能为0",
            type: "error"
          });
          this.currentData = this.originalData;
          return false;
        }
        if (this.inputType === 'progress' && (+this.currentData < 0 || +this.currentData > 100 || isNaN(+this.currentData))) {
          this.$message({
            message: "数字需要在 0-100 之间",
            type: "error"
          });
          this.currentData = this.originalData;
          return false;
        }
       
        if(this.currentData === this.originalData) {return ;}
        // 如果有修改内容
        if(!this.currentData){
          this.projectText == "sprintTime"?this.currentData = null:this.currentData = '2001-01-01'; 
          this.onChange(this.currentData);
          
        }else if (this.currentData !== this.originalData) {
          this.onChange(this.currentData);
        }
        if(this.daisableTime == 1){
          this.currentData = this.originalData;
        }
      }
    }
  };
</script>
<style lang="scss" scoped>
  .globalDatepicker {
    max-width: 100%;
  }

  // .pointerhover {
  //   cursor: pointer;
  //   padding: 1px;

  //   .ellipsis {
  //     &:hover {
  //       box-shadow: 0 0 0 1px #ccc;
  //     }
  //   }

  // }
</style>