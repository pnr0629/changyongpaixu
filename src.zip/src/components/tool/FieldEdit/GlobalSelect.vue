<template>
  <div class="global-belctbox" :style="currentPosition" v-show="show">
    <select-box
      :colorType="colorType"
      :localSearch="localSearch"
      :selectValue="selectValue"
      :onChange="onFieldValueChange"
      :currentValue="initValue"
      :multiple="multiple"
      :GlobalLoading="GlobalLoading"
      :show="show"
      :customInput="customInput"
      :customInputPlaceHolder="customInputPlaceHolder"
      :customInputChange="onCustomInputChange"
    ></select-box>
  </div>
</template>

<script>
/**
 * @title 全局 select 组件
 * @desc 目前支持功能：
 * @func 1 单选、多选
 * @func 2 小圆圈、背景色、文字颜色
 * @func 3 可搜索
 * @func 4 点击选项钩子
 * @author heyunjiang
 * @date 2019.4.26
 */
import SelectBox from "./SelectBox";
import { mapState } from 'vuex';

export default {
  name: "GlobalSelect",
  components: {
    SelectBox
  },
  props: {
    initValue: {
      type: [String, Number, Array],
      required: true,
      desc: "当前选择框的值，多选必须是 array"
    },
    selectValue: {
      type: Array,
      required: true,
      validator: function (value) {
        // 后面再验证，要求是 [{key, value}] 格式，并且 length > 1
        return true;
      },
      desc: "选择框的所有选项"
    },
    onChange: {
      type: Function,
      required: false,
      default: function () { },
      desc: "value 选择之后回调函数"
    },
    beforeSelect: {
      type: Function,
      required: false,
      desc: "value 选择之前回调函数"
    },
    onOtherClose: {
      type: Function,
      required: true,
      desc: "点击任意地方可以关闭"
    },
    // select item 样式
    colorType: {
      type: String,
      required: false,
      desc: "目前支持小圆圈、背景、字体3种状态，默认无",
      validator: function (value) {
        return ["circle", "bg", "font"].indexOf(value) !== -1;
      }
    },
    // 是否支持过滤
    localSearch: {
      type: Boolean,
      required: false,
      desc: "是否支持本地搜索"
    },
    multiple: {
      type: Boolean,
      required: false,
      default: false,
      desc: "是否支持多选"
    },
    show: {
      type: Boolean,
      required: true,
      desc: "是否展示"
    },
    GlobalLoading: {
      type: Boolean,
      required: false,
      default: false,
      desc: 'loading'
    },
    target: {
      type: [HTMLHtmlElement, HTMLSpanElement],
      required: true,
      desc: "点击的目标节点"
    },
    customInput: {
      type: Boolean,
      required: false,
      default: false,
      desc: '是否允许自定义输入'
    },
    customInputPlaceHolder: {
      type: String,
      required: false,
      default: '自定义',
      desc: '是否允许自定义输入 placeholder'
    },
    customInputChange: {
      type: Function,
      required: false,
      desc: '自定义输入变化回调'
    }
  },
  data() {
    return {
      currentPosition: {},
      listenerDom: []
    };
  },
  mounted() {
    // 绑定关闭的 dom ：#app
    const domArray = [];
    domArray.push(document.getElementById("app"));
    domArray.push(this.$el.closest(".bug-content-box")); // slider
    this.listenerDom = domArray;
  },
  watch: {
    show() {
      if (!this.show) {
        this.listenerDom.forEach(item => {
          item && item.removeEventListener("click", this.bodyEvent);
        });
      } else {
        setTimeout(() => {
          this.listenerDom.forEach(item => {
            item && item.addEventListener("click", this.bodyEvent);
          });
        });
      }
    },
    target(newT, oldT) {
      this.$nextTick(this.globalSelectDisplayHandle);
    },
    selectValue() {
      this.$nextTick(this.globalSelectDisplayHandle);
    },
    '$route'(to, from) {
      this.onOtherClose()
    }
  },
  beforeDestroy() {
    if (this.show) {
      document.body.removeChild(this.$el);
    }
  },
  methods: {
    // select 值变化操作，只考虑点击项的时候做关闭前的钩子，不考虑点击任意位置关闭的钩子
    onFieldValueChange(result) {
      if (this.beforeSelect) {
        this.beforeSelect(result, hookResult => {
          if (hookResult && !this.multiple) {
            this.onOtherClose();
          }
        });
      } else {
        if (!this.multiple) {
          this.onOtherClose();
          this.onChange && this.onChange(result.key);
        } else {
          this.onChange && this.onChange(result);
        }
      }
    },
    // selectbox 展示框事件监听函数
    bodyEvent: function (e) {
      if (
        e.target.hasAttribute("data-type") &&
        e.target.getAttribute("data-type").indexOf("select-box") !== -1
      ) {
      } else {
        // 外部任意位置点击
        this.onOtherClose();
      }
    },
    // select 渲染
    globalSelectDisplayHandle() {
      if (this.target.tagName.toLowerCase() !== "span") {
        return;
      }

      this.currentPosition = this.position;
      // 判断 target 距离 table 底部距离
      const targetRect = this.target.getBoundingClientRect();
      const tableRect = this.target.closest(".el-table__body").getBoundingClientRect();
      const selectRect = this.$el.querySelector(".select-box").getBoundingClientRect();
      const isOverTable = tableRect.bottom - targetRect.bottom > selectRect.height; // 是否超出了 table 底部边框
      const isOverBody = window.innerHeight - tableRect.bottom > selectRect.height; // 距离底部距离是否足够

      const sliderElement = document.querySelector(".sider-right");
      const parentRect = sliderElement ? sliderElement.getBoundingClientRect() : {};
      if (sliderElement && parentRect.left < window.innerWidth) {
        // 如果是在 slider 层渲染
        const top = isOverTable
          ? targetRect.top + sliderElement.scrollTop
          : targetRect.top + sliderElement.scrollTop - selectRect.height - 34;
        this.currentPosition = {
          left: targetRect.left - parentRect.left + "px",
          top: top + "px",
          zIndex: isOverTable ? "999" : "1999"
        };
        sliderElement.appendChild(this.$el);
      } else {
        // 如果是在普通 body 渲染
        let top = isOverTable
          ? targetRect.top + document.documentElement.scrollTop
          : targetRect.top +
          document.documentElement.scrollTop -
          34 -
          selectRect.height;
        if (!isOverTable && isOverBody) {
          top = targetRect.top + document.documentElement.scrollTop;
        }
        this.currentPosition = {
          left: targetRect.left + "px",
          top: top + "px",
          zIndex: isOverTable ? "999" : "1999"
        };
        document.body.appendChild(this.$el);
      }
    },
    // 自定义输入变化回调
    onCustomInputChange(value) {
      this.onOtherClose();
      this.customInputChange && this.customInputChange(value)
    }
  }
};
</script>

<style lang="scss" scoped>
@import "../../../base/style/common";
.global-belctbox {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
}
</style>
