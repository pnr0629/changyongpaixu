<template>
  <div data-type="select-box" @click.stop ref="selectBox" class="select-box scrollbal-common">
    <el-input v-if="localSearch" data-type="select-box-filter" class="select-box-input" v-model="filter" placeholder="搜索"></el-input>
    <div class="select-box-child scrollbal-common">
      <div v-if="GlobalLoading" class="loading-text">数据加载中</div>
      <div class="select-box-item" 
        :class="{'select-box-item-active': currentSelectValue.includes(item.key),'statusbox-list-common':colorType==='font'||colorType==='bg', 'select-box-item-label':isNeddShowLabel}"
        :style="{backgroundColor: colorType==='bg'||colorType==='font'?item.color:''}"
        v-for="item in selectList" :key="item.key"
        @click="itemClick(item)"
        data-type="select-box-item">
        <span class="mini-circle" :style="{backgroundColor: item.color}" v-if="item.color&&colorType==='circle'"></span>
        <span :style="{color: colorType==='font'?'':item.color}" v-if="colorType==='font'&&item.color&&item.font">{{item.value}}</span>
        <span v-else>{{item.value}}</span>
        <span class="showmore-label" v-if="isNeddShowLabel">{{item.label}}</span>
        <i class="el-icon-check" v-if="currentSelectValue.includes(item.key)"></i>
      </div>
      <div class="select-box-item select-box-item-custom" v-show="customInput" data-type="select-box-item">
        <el-input @change="customInputChange" v-model="customValue" :placeholder="customInputPlaceHolder"></el-input>
      </div>
      <div class="select-box-item showmore" v-if="isNeddShowMore" @click="showmoreClick">{{showMore?'收起':'更多'}}</div>
    </div>
  </div>
</template>

<script>
  /**
  * @title field 编辑组件 - select 模块
  * @desc 该模块作为普通 field-edit 和 globalSelect 组件的最终 select 选择组件；自己有定位，并且 globalselect 也有定位
  * @author heyunjiang
  * @date 2019-3-5
  * @update 2019.6.19
  */
  import Config from 'base/js/config.js'

  export default {
    name: "SelectBox",
    props: {
      onChange: Function,
      selectValue: Array,
      currentValue: {validator: (value) => { return true; }},
      colorType: String,
      localSearch: Boolean,
      multiple: Boolean,
      GlobalLoading: Boolean,
      show: {
        type: Boolean,
        required: false,
        default: false,
        desc: 'select 框是否显示，可读，不可写'
      },
      customInput: {
        type: Boolean,
        required: false,
        default: false,
        desc: '是否允许自定义输入'
      },
      customInputPlaceHolder: {
        type: String,
        required: false,
        default: '自定义',
        desc: '是否允许自定义输入 placeholder'
      },
      customInputChange: {
        type: Function,
        required: false,
        default: () => {},
        desc: '自定义输入变化回调'
      },
    },
    data() {
      return {
        currentSelectValue: [],
        filter: '',
        showMore: false,
        customValue: null
      }
    },
    created: function () {
      this.setCurrentValue()
    },
    computed: {
      selectList() {
        let result =  this.selectValue;
        // 如果过滤
        if(this.filter.trim().length > 0) {
          result =  this.selectValue.filter(item => {
            return item.value.indexOf(this.filter) !== -1
          })
        }
        // 如果需要展示更多操作
        if(result.filter(item => item.showMore).length > 0) {
          result = result.filter(item => {
            if(!this.showMore) {
              return !item.showMore;
            } else {
              return true;
            }
          })
        }
        return result;
      },
      isMultiple() {
        return this.multiple
      },
      // 是否需要展示更多模式，当字段存在 showMore 时，则需要点击更多才能展示
      isNeddShowMore() {
        return this.selectValue.filter(item => item.showMore).length > 0;
      },
      // 是否需要展示 label 模式
      isNeddShowLabel() {
        return this.selectValue.filter(item => item.label).length > 0;
      }
    },
    watch: {
      currentValue() {
        this.setCurrentValue()
      },
      show() {
        if(!this.show) {
          this.filter = '';
          this.customValue = null;
        }
      },
      selectValue() {
        this.filter = '';
        this.$nextTick(this.resetPosition);
      }
    },
    mounted: function () {
      this.resetPosition();
    },
    methods: {
      // 重新渲染位置
      resetPosition() {
        if(!this.$parent.$refs.selectBoxSibling) {return ;}   
        const selectRect = this.$refs.selectBox.getBoundingClientRect();
        const transformObj = {
          x: '-5px',
          y: '0'
        }
        if(selectRect.right > window.innerWidth) {
          transformObj.x = window.innerWidth - selectRect.right + 'px';
        }
        if(selectRect.bottom > window.innerHeight) {
          transformObj.y = window.innerHeight - selectRect.bottom + 'px';
        }
        if(selectRect.right > window.innerWidth || selectRect.bottom > window.innerHeight) {
          this.$refs.selectBox.style.transform = "translate("+ transformObj.x + ", " + transformObj.y +")";
        }
      },
      itemClick: function (item) {
        let result = [...this.currentSelectValue]
        if(this.currentSelectValue.includes(item.key)) {
          // 如果是多项选择，则删除，单项选择，则不删除
          if(this.isMultiple) {
            result = result.filter(jtem => jtem!==item.key)
            this.currentSelectValue = [...result]
          } else {
            this.currentSelectValue = []
          }
        } else {
          result.push(item.key)
        }
        // 兼容一些写法
        if(this.isMultiple) {
          this.onChange(result)
        } else {
          this.onChange(item)
        }
      },
      // 设置当前选中值，可以是单选或多选
      setCurrentValue() {
        if(this.isMultiple) {
          this.currentSelectValue = Array.isArray(this.currentValue) ? this.currentValue : [];
        } else {
          this.currentSelectValue = [this.currentValue]
        }
      },
      showmoreClick() {
        this.showMore = !this.showMore;
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import '../../../base/style/common';
  $select-box-item-height: 28px;

  .select-box {
    position: absolute;
    top: 30px;
    left: 0;
    min-width: 122px;
    // min-height: 200px;
    // max-height: 300px;
    margin: 0;
    padding: 10px 0;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px #ccc;
    background-color: #fff;
    
    box-sizing: border-box;
    z-index: 1100;
    .select-box-child{
      overflow-x: hidden;
      overflow-y: auto;
      max-height: 300px;
      background-color: #fff;
      padding: 10px;
    }
    .select-box-input {
      display: block;
      width: 92%;
      margin-left: 3%;
    }
    .select-box-item {
      text-align: center;
      padding: 1px 15px;
      line-height: 28px;
      cursor: pointer;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      position: relative;
      margin-top: 10px;
      // height: $select-box-item-height;
      // line-height: $select-box-item-height;
      &:hover {
        background-color: #f8f8f8;
      }
      &:first-of-type {
        margin-top: 0;
      }
    }
    .select-box-item-label {
      display: flex;
      flex-flow: row nowrap;
      justify-content: space-between;
    }
    .select-box-item-active {
      // background-color: #f8f8f8;
      // color: #ebf2f9 !important;
      // padding-right: 30px;
      .el-icon-check {
        position: absolute;
        right: 0px;
        top: 8px;
        color: gray;
      }
    }
    .select-box-item-bgtype {
      padding-left: 5px;
      color: $color-font-white-common;
    }
    .select-box-item-custom {
      min-width: 80px;
    }
    .loading-text {
      text-align: center;
      font-size: 12px;
    }
  }
  .showmore {
    cursor: pointer;
    text-align: center;
  }
  .showmore-label {
    color: #8492a6; 
    font-size: 13px;
  }
</style>
