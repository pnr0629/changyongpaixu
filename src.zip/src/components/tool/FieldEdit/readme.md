# FieldEdit 组件

time: 2019.3.5  
update: 2019.4.9  
author: heyunjiang

## 1 组件说明

组件类型：全局通用组件

组件功能：下拉框、inupt、boolean 等输入自定义实现

## 2 使用方式

参考 `project/bugManagement/LeftList` ，传入对应的 props 则可

## 3 组件缺陷

不支持多选 - 已支持

## 4 后续扩展

1. 支持自定义传入高宽
2. 支持自定义内容 - 已支持
3. 支持 input 输入 - 已支持
