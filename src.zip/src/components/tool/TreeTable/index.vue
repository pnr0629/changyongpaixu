<template>
  <el-table :data="formatData" ref="multipleTable" :row-style="showRow" v-bind="$attrs"
    @selection-change="handleSelectionChange" border @sort-change="sortaChangeCallBack">
    <!-- :row-key="(row)=>{ return row.id || row.data.key}" -->
    <el-table-column type="selection" width="55" :selectable="selectableFunction" v-if="isChecked">
    </el-table-column>
    <el-table-column width="72" label="ID" show-overflow-tooltip>
      <template slot-scope="scope">
        <span @click="handleClickItem(scope.row,$event)" class="c-blue-hover cp"> {{ getId(scope.row)}}</span>
      </template>
    </el-table-column>
    <el-table-column v-if="columns.length===0" label="标题" show-overflow-tooltip min-width="240px">
      <template slot-scope="scope">
        <global-input :initValue="getTitle(scope.row)" v-if="!scope.row.isNewAdd"
          :onChange="(value)=>{updateGlobalTitle(scope.row, value)}">
          <span class="table-input-edit-text c-blue-hover" slot>
            <span v-for="space in scope.row._level" :key="space" class="ms-tree-space" />
            <span v-if="iconShow(0,scope.row)" class="tree-ctrl" @click="toggleExpanded(scope.$index)">
              <i v-if="!scope.row._expanded" class="el-icon-plus" />
              <i v-else class="el-icon-minus" />
            </span>
            <el-tooltip v-if="scope.row && scope.row.display && scope.row.display.delayed" class="item" effect="dark"
              content="已过期" placement="top-start">
              <i class="el-icon-warning warning"></i>
            </el-tooltip>
            <span v-if="scope.row.data && scope.row.data.isNewAdd" class="inputSet">
              <el-input v-model="scope.row.data.title" placeholder="请输入标题"></el-input>
            </span>

            <span v-else @click.stop="handleClickItem(scope.row,$event)" class="cp c-blue-hover">
              <span :class="getworkItemType(scope.row.data)" class=" c-blue cp"></span>
              <span>{{ getTitle(scope.row)}}</span>
            </span>
          </span>
        </global-input>
        <span v-if=" scope.row.isNewAdd">
          <el-input v-model="scope.row.title" @change="changeTitle" placeholder="必须填写标题" class="editable-input">
          </el-input>
        </span>
      </template>
    </el-table-column>
    <el-table-column show-overflow-tooltip v-for="(column, index) in columns" v-else :key="column.value"
      :label="column.text" :width="column.width">
      <template slot-scope="scope">
        <!-- <span v-for="space in scope.row._level" v-if="index === 0" :key="space" class="ms-tree-space"/> -->
        <span v-if="iconShow(index,scope.row)" class="tree-ctrl" @click="toggleExpanded(scope.$index)">
          <i v-if="!scope.row._expanded" class="el-icon-plus" />
          <i v-else class="el-icon-minus" />
        </span>
        {{ scope.row[column.value] }}
      </template>
    </el-table-column>
    <slot />
  </el-table>
</template>
<script>
  import treeToArray from '@/components/tool/TreeTable/eval'
  import GlobalInput from '../FieldEdit/GlobalInput.vue'
  import merge from 'webpack-merge';
  export default {
    name: 'TreeTable',
    components: {
      GlobalInput
    },
    props: {
      /* eslint-disable */
      data: {
        type: [Array, Object],
        required: false
      },
      columns: {
        type: Array,
        default: () => []
      },
      evalFunc: Function,
      evalArgs: Array,
      // multipleSelection: Array,
      expandAll: {
        type: Boolean,
        default: false
      },
      isChecked: {
        type: Boolean,
        default: true
      },
      jumpPage: {
        type: String,
        default: null
      },
      ltype: {
        type: Number,
        default: null
      },
      updateGlobalTitle: {
        type: Function,
        required: true
      },
      sortaChangeCallBack: {
        type: Function,
        required: false,
        default: () => { }
      }
    },
    data() {
      return {
        multipleSelection: [],
      }
    },
    computed: {
      // 格式化数据源
      formatData: function () {
        if (!this.data) {
          return [];
        }
        let tmp
        if (!Array.isArray(this.data)) {
          tmp = [this.data]
        } else {
          tmp = this.data
        }
        const func = this.evalFunc || treeToArray
        const args = this.evalArgs ? Array.concat([tmp, this.expandAll], this.evalArgs) : [tmp, this.expandAll]
        return func.apply(null, args)
      }
    },
    methods: {
      changeTitle(val) {
        this.$emit('updataTitle', val)
      },
      getworkItemType(row) {
        if (row != undefined) {
          if (row && row.workItemType == 1) {
            return 'iconfont icon-requirement';
          } else if (row && row.workItemType == 2) {
            return 'iconfont icon-task';
          } else if (row && row.workItemType == 3) {
            return 'iconfont icon-bug'
          }
        }

      },
      getId(data) {
        if (data.id) {
          return data.id;
        } else if (data.data && data.data.id) {
          return data.data.id;
        } else if (data.display && data.display.id) {
          return data.display.id;
        } else {
          return "";
        }
      },
      getTitle(data) {
        if (data.title) {
          return data.title;
        } else if (data.display && data.display.title) {
          return data.display.title;
        } else if (data.data && data.data.title) {
          return data.data.title;
        } else {
          return "";
        }
      },
      indexHandle(data) {
      },
      getMultipleSelectData() {
        return this.multipleSelection;
      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      showRow: function (row) {
        const show = (row.row.parent ? (row.row.parent._expanded && row.row.parent._show) : true)
        row.row._show = show
        return show ? 'animation:treeTableShow 1s;-webkit-animation:treeTableShow 1s;' : 'display:none;'
      },
      // 切换下级是否展开
      toggleExpanded: function (trIndex) {
        const record = this.formatData[trIndex]
        record._expanded = !record._expanded
      },
      // 图标显示
      iconShow(index, record) {
        return (index === 0 && record.children && record.children.length > 0)
      },
      selectableFunction(row, index) {
        // if(row.data.workItemType == 1){      //需求
        //   if ( row.data.hierarchyRole == 0){   //叶子节点
        //     return true;
        //   } else{   //非叶子节点
        //     return false;
        //   }
        // }else {   //任务
        //   return true;
        // }
        return true;
      },

      handleClickItem(row, e) {
        // if (this.jumpPage) {
        //   if (this.jumpPage === "mineRequirementView") { //我的面板-需求查看
        //     this.goToNewWindowPage(this, "mineRequirementView", { requireId: row.data.id });
        //     return;
        //   }
        // }

        // if(!this.ltype){
        //   this.$emit("seeTaskHandle", null, null);
        // }
        // :projectId="rootNode.projectId" :requireId="requireId"
        this.$router.push({
          query: merge(this.$route.query, { 'requireId': row.id })
        })
        this.$emit('cancleCreateRequire')
        if (this.ltype == 1) {
          this.$emit("seeTaskHandle", row, e)
          return
        }
        if (row.data && row.data.workItemType == 1) {
          this.$emit("seeTaskHandle", row.data, e)
          return
        } else if (row.data && row.data.workItemType == 2) {
          if (this.ltype == 2) {
            this.$emit("seeTaskHandle", row.data, e)
            return
          }
        } else {
          this.$emit("seeTaskHandle", row.data, e)
          return
        }
      }
    }
  }
</script>
<style rel="stylesheet/css">
  @keyframes treeTableShow {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }

  @-webkit-keyframes treeTableShow {
    from {
      opacity: 0;
    }

    to {
      opacity: 1;
    }
  }
</style>
<style lang="scss" rel="stylesheet/scss" scoped>
  $color-blue: #2196F3;
  $space-width: 18px;

  .ms-tree-space {
    position: relative;
    top: 1px;
    display: inline-block;
    font-style: normal;
    font-weight: 400;
    line-height: 1;
    width: $space-width;
    height: 14px;

    &::before {
      content: ""
    }
  }

  .processContainer {
    width: 100%;
    height: 100%;
  }

  table td {
    line-height: 26px;
  }

  .tree-ctrl {
    position: relative;
    cursor: pointer;
    color: $color-blue;
    margin-left: -$space-width;
  }

  .inputSet {
    position: relative;
    bottom: 10px;
  }
</style>