<template>
  <div id="demandReview" class="content-outer-box">
    <div class="content-box">
      <div class="function-bar page-content-box-width" style="border-bottom:2px solid #d6d9e0;">
        <span class="ml mt5" style="font-size: 16px;display: inline-block; font-weight: 900;">需求评审</span>
      </div>
      <div style="font-size: 18px;" class="mt20 center page-content-box-width">
        <span>{{reviewData.title}}</span>
      </div>
      <div class="mt20 basic-box page-content-box-width" style="overflow: hidden;">
        <el-row :gutter="10">
          <el-col :span="24" class="basic-box-item">
            <span class="font-title">发起人:</span>
            <span class="font-reset">{{reviewData.createUserName}}</span>
          </el-col>
          <el-col :span="24" class="basic-box-item">
            <span class="font-title">评审人员:</span>
            <span class="font-reset" v-for="(user, index) in reviewData.reviewUserList" :key="index">{{user.reviewUserName}}</span>
          </el-col>
          <el-col :span="24" class="basic-box-item">
            <span class="font-title">时间地点:</span>
            <span class="font-reset">{{reviewData.reviewTime}}</span>
            <span class="font-reset">{{reviewData.reviewAddress}}</span>
          </el-col>
          <el-col :span="24" class="basic-box-item">
            <span class="font-title">备注:</span><span class="font-reset">{{reviewData.remark}}</span>
          </el-col>
        </el-row>
      </div>
      <div class="list-box-header page-content-box-width">
        <span class="list-box-header-title">待评审需求列表</span>
        <el-button type="primary" v-if="reviewData.status != 1" disabled @click="fatherReviewHandle()"
                   class="fr list-box-header-btn">快速创建需求并加入审评
        </el-button>
        <el-button type="primary" v-else @click="fatherReviewHandle()" class="fr list-box-header-btn">快速创建需求并加入审评</el-button>
      </div>
      <div class="page-content-box-width">
        <tree-table
          border
          :class="{'tree-table-left-none':reviewTableData.length == 0,'tree-table-right-none':reviewTableData.length != 0}"
          :data="reviewTableData"
          :eval-args="args"
          :isChecked="isChecked"
          :jumpPage="jumpPage"
          :expand-all="expandAll">
          <el-table-column label="当前状态">
            <template slot-scope="scope">
              <span v-if="scope.row.data.isNewAdd"></span>
              <span v-else>{{getStatus(scope.row)}} </span>
            </template>
          </el-table-column>
          <el-table-column label="所属项目" min-width="100">
            <template slot-scope="scope">

              <el-select v-if="scope.row.data.isNewAdd" class="fl ml10 mt10" v-model="scope.row.data.projectId">
                <el-option v-for="item in projectNameList" :key="item.id" :label="item.name"
                           :value="item.id"></el-option>
              </el-select>
              <span v-else>{{scope.row.data.display.projectName}}</span>
            </template>
          </el-table-column>
          <el-table-column label="提出人" min-width="100">
            <template slot-scope="scope">
              <span v-if="scope.row.data.isNewAdd"></span>
              <span v-else>{{scope.row.data.display.createUser}} ({{scope.row.data.createUser}})</span>
            </template>
          </el-table-column>
          <el-table-column label="评审备注" width="300">
            <template slot-scope="scope">
              <span v-if="scope.row.data.isNewAdd"></span>
              <el-input v-else-if="scope.row.data.reviewStatus == scope.row.data.reviewedStatusId" type="textarea"
                        disabled v-model="scope.row.data.comment"></el-input>
              <el-input v-else-if="scope.row.data.reviewStatus == scope.row.data.refusedStatusId" type="textarea"
                        disabled v-model="scope.row.data.comment"></el-input>
              <el-input v-else-if="scope.row.data.reviewStatus == scope.row.data.initStatusId" type="textarea" disabled
                        v-model="scope.row.data.comment"></el-input>
              <span v-else-if="scope.row.data.statusId != scope.row.data.initStatusId"></span>
              <el-input v-else type="textarea" v-model="scope.row.data.comment"></el-input>

            </template>
          </el-table-column>
          <el-table-column label="操作" width="240">
            <template slot-scope="scope">
              <div v-if="scope.row.data.isNewAdd" ref="childrenDemand">
                <span class="cp c-blue " @click="createRequire(scope.row)">保存</span>
                <span class="cp c-blue" @click="cancleHandle(scope.row)">取消</span>
              </div>
              <span v-else-if="scope.row.data.reviewStatus == scope.row.data.reviewedStatusId">
                通过
              </span>
              <span v-else-if="scope.row.data.reviewStatus == scope.row.data.refusedStatusId">
                拒绝
              </span>
              <div v-else-if="scope.row.data.reviewStatus == scope.row.data.initStatusId">
                待定
                <span class="cp c-blue"
                      v-if="reviewData.status == 1"
                      @click="adoptHandle(scope.row,getId(scope.row))">
                  通过
                </span>
                <span class="cp c-blue"
                      v-if="reviewData.status == 1"
                      @click="refuseHandle(scope.row,getId(scope.row))">
                  拒绝
                </span>
              </div>
              <div v-else-if="scope.row.data.statusId != scope.row.data.initStatusId">
              </div>
              <span v-else>
                <span class="cp c-blue" @click="adoptHandle(scope.row,getId(scope.row))">通过</span>
                <span class="cp c-blue" @click="undeterminedHandle(scope.row,getId(scope.row))">待定</span>
                <span class="cp c-blue" @click="refuseHandle(scope.row,getId(scope.row))">拒绝</span>
                <span class="cp c-blue" @click="createChildrenHandle(scope.row)">快速创建子需求</span>
              </span>
            </template>
          </el-table-column>
        </tree-table>
      </div>
      <div class="fotter">
        <el-button type="info"  @click="returnBtn">返回</el-button>
        <el-button type="primary" v-if="reviewData.status == 1" @click="completeReview()">完成评审</el-button>
        <el-button type="primary" v-else disabled @click="completeReview()">完成评审</el-button>
      </div>
    </div>
  </div>

</template>

<script>
  import TreeTable from '@/components/tool/TreeTable'
  // import treeToArray from '@/components/mine/review/customEval'

  export default {

    name: "reviewDetail",
    components: {TreeTable},
    data() {
      return {
        urlParam: {
          reviewId: 0
        },
        onOnece: true,
        isChecked: false,
        jumpPage: "mineRequirementView",
        bizId: "",
        expandAll: true,
        args: [null, null, 'timeLine'],
        reviewData: {
          id: 0,
          title: "",//会议室
          createUserName: "",
          reviewUserList: [],
          reviewTime: "",//时间
          reviewAddress: "",//地点
          remark: ""
        },
        reviewTableData: [],
        projectNameList: [],
        createRequireData: {
          data: {
            isNewAdd: true,
            id: " ",
            title: "",
            bizId: 0,
            parentId: 0,
            reviewId: 0,
            status: "未审评",
            comment: "",
          },
          parent: [],
          children: [],
        },
        table_loading: false,
      };
    },
    mounted() {
      this.urlParam.reviewId = this.getUrlParams().reviewId;

      this.getReviewData();
      this.getReviewRequireData();

      $http.get($http.api.project.projectList).then(res => {
        this.projectNameList = res.data;
      })
    },
    methods: {
      getId(data) {
        if (data.id) {
          return data.id;
        } else if (data.data.id) {
          return data.data.id;
        } else if (data.display.id) {
          return data.display.id;
        } else {
          return "";
        }
      },
      getStatus(data) {
        if (data.status) {
          return data.status;
        } else if (data.data.status) {
          return data.data.status;
        } else if (data.data.display.status) {
          return data.data.display.status;
        } else {
          return "";
        }
      },
      //待定
      undeterminedHandle(row, id) {
        let status = row.data.currentStatusId;
        let requireId = id;
        let comment = row.data.comment
        let reviewId = this.urlParam.reviewId
        $http.post($http.api.review.save_review_result, {status, requireId, comment, reviewId}).then((res) => {
          this.$message({message: '操作成功', type: 'success'});
          this.getReviewRequireData()
        }).catch(e => {

        });
      },
      //通过
      adoptHandle(row, id) {
        let status = row.data.reviewedStatusId;
        let requireId = id;
        let comment = row.data.comment
        let reviewId = this.urlParam.reviewId

        $http.post($http.api.review.save_review_result, {status, requireId, comment, reviewId}).then((res) => {
          this.$message({message: '操作成功', type: 'success'});
          this.getReviewRequireData()
        }).catch(e => {
          this.getReviewRequireData()
        })
      },
      //拒绝
      refuseHandle(row, id) {
        let status = row.data.refusedStatusId;
        let requireId = id;
        let comment = row.data.comment
        let reviewId = this.urlParam.reviewId

        if (comment) {
          $http.post($http.api.review.save_review_result, {status, requireId, comment, reviewId}).then((res) => {
            this.$message({message: '操作成功', type: 'success'});
            this.getReviewRequireData()
          }).catch(e => {
            this.getReviewRequireData()
          });
        } else {
          this.$message({message: '拒绝必须在评审备注填写拒绝理由', type: 'error'});
        }

      },
      //评审人员信息
      getReviewData() {
        let reviewId = this.getUrlParams().reviewId;
        $http.get($http.api.review.brief_info, {reviewId: reviewId}).then((res) => {
          this.reviewData = res.data;

        }).catch(e => {

        });
      },
      //评审详情表格数据
      getReviewRequireData() {
        let reviewId = this.getUrlParams().reviewId;
        $http.get($http.api.review.require_detail_info_tree, {reviewId: reviewId}).then((res) => {
          this.reviewTableData = res.data

        }).catch(e => {

        });
      },
      //快速创建需求
      fatherReviewHandle() {
        if (this.onOnece) {

          this.createRequireData.parent = null;
          this.createRequireData.children = [];

          this.reviewTableData.push(this.createRequireData)
          this.onOnece = false
        } else {
          this.$message({message: '一次只能添加一条需求', type: 'warning'})
        }
      },

      //创建子需求
      createChildrenHandle(data) {
        if (this.onOnece) {
          this.createRequireData.parent = data;
          this.createRequireData.children = [];

          if (data.children) {
            data.children.push(this.createRequireData);
          } else {
            data.children = [];
            data.children.push(this.createRequireData);
          }
          this.onOnece = false;
        } else {
          this.$message({message: '一次只能添加一条需求', type: 'warning'});
        }
      },
      //确定
      createRequire(row) {

        if (!row.data.title) {
          this.$message({message: '需求标题不能为空', type: 'error'});
          return;
        }

        let parentId = null;
        let projectId = row.data.projectId;

        if (row.parent) {
          parentId = row.parent.data.id
        }

        this.onOnece = true;
        $http.post($http.api.requirement.create, {
          reviewId: this.getUrlParams().reviewId,
          title: row.data.title,
          projectId: projectId,
          parentId: parentId
        }).then(res => {
          this.$message({message: '添加需求成功', type: 'success'});

          if (res.status === 200) {
            this.getReviewRequireData()
          }
        })
      },
      //取消
      cancleHandle(data) {
        if (data.parent) {
          data.parent.children.pop()
        } else {
          this.reviewTableData.pop()
        }

        this.onOnece = true;
      },
      //完成评审
      completeReview() {
        $http.post($http.api.review.complete_review, {reviewId: this.reviewData.id}, {type: 'form'}).then((res) => {
          this.$message({message: '操作成功', type: 'success'});
          this.goToPage(this, "mine");
        })
      },

      returnBtn() {
        this.goToPage(this, "mine", {reviewId: this.getUrlParams().reviewId});
      }
    }
  };
</script>

<style lang="scss" scoped>
  $BASICBOXBG: #f9f9f9; // #ECF1F0
  // 评审基本信息
  .basic-box {
    background-color: $BASICBOXBG;
    border: 1px solid #E2E7E6;
    padding: 10px;
    .basic-box-item {
      // height: 30px;
      // line-height: 30px;
      margin: 5px 0;
    }
  }
  // 表头
  .list-box-header {
    overflow: hidden;
    position: relative;
    margin-top: 20px;
    margin-bottom: 10px;
    padding-bottom: 10px;
    border-bottom: 1px solid #d6d9e0;
    .list-box-header-title {
      font-size: 14px;
      display: inline-block; 
      font-weight: 900;
      position: absolute; 
      bottom: 10px; 
      left: 0;
    }
    .list-box-header-btn {}
  }

  .font-reset {
    font-size: 13px;
    color: #555;
    margin-left: 10px;
  }

  .font-title {
    font-size: 13px;
    font-weight: 700;
  }

  .demand-review-people {
    float: left;
    margin-left: 10%;
  }


  .tip {
    float: right;
    margin-right: 50px;
    margin-top: 72px
  }

  .create-review {
    float: right;
    margin-top: 80px;
    margin-bottom: 10px;
    margin-right: 10%;
  }


  .fotter {
    float: right;
    margin-top: 10px;
    margin-right: 10%;
  }
</style>
