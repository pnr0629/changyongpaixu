<template>
  <div id="demand" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar page-content-box-width">
        <span class="reverse-css" v-if="this.reviewId > 0">修改评审</span>
        <span class="reverse-css" v-else>发起评审</span>
      </div>
      <div class="content page-content-box-width">
        <div style="width: 100%;height: 100%;">
          <div style="height: 40px;">
            <span class="fl mt15" style="width: 80px;">评审标题</span>
            <el-input v-model="review.title" class="fl ml10 mt10" style="width:400px;" placeholder="请输入评审标题"></el-input>
          </div>
          <div style="min-height: 40px;overflow: hidden;">
            <span class="fl mt15" style="width: 80px;">需求评审人</span>
            <el-select v-model="review.reviewUserList" multiple filterable remote :reserve-keyword="reserveKeyword"
              placeholder="请输入姓名或邮箱关键词" :remote-method="getReviewUsers" :loading="loading" class="ml10 fl mt10"
              style="width:400px;">
              <el-option v-for="item in reviewUsers" :key="item.value" :label="item.label" :value="item.value">
                <template>
                  {{item.label}}({{item.value}})
                </template>
              </el-option>
            </el-select>
          </div>
          <div style="height: 40px;">
            <span class="fl mt15" style="width:80px;">时间地点</span>
            <el-date-picker v-model="review.reviewTime" type="datetime" placeholder="请选择评审时间" default-time="09:00:00" class="fl ml10 mt10"
              style="width:190px;" prefix-icon="clean-icon">
            </el-date-picker>
            <el-input v-model="review.reviewAddress" class="fl ml10 mt10" style="width:200px;" placeholder="请输入评审地点"
              maxlength="20"></el-input>
          </div>
          <div style="height: 100px;">
            <span class="fl mt10" style="width: 80px;">备注</span>
            <textarea type="textarea" v-model="review.remark" class="remarks" maxlength="100"></textarea>
          </div>
        </div>
        <div class="revew-all-left-right">
          <div class="font-title">需求列表</div>
          <div style="height:50px;background:#fff;white-space: nowrap">
            <span class="fl mt15">项目</span>
            <el-select class="fl ml10 mt10 mr20" filterable v-model="projectId" style="width: 140px;">
              <el-option label="全部项目" value="-1"></el-option>
              <el-option v-for="item in projecInfoList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
            <span class="fl mt15">标题</span>
            <el-input class="fl ml10 mt10" style="width:140px" v-model="requireTitle"></el-input>
            <el-button type="primary" class="fl mt10 ml10" @click="getSearchRequires">查询</el-button>
          </div>
          <tree-table :data="requireData" :eval-args="args" :expand-all="expandAll" ref="myTree" :show-check-box="showSearchCheckBox"
            :class="{'tree-table-left-none':requireData.length == 0}" border style="width: 100%;margin-left: 0">
            <el-table-column label="所属项目">
              <template slot-scope="scope">
                <!-- <span style="color:sandybrown">{{ scope.row.event }}</span> -->
                {{ scope.row.data.display.projectName}}
              </template>
            </el-table-column>
            <el-table-column label="提出人">
              <template slot-scope="scope">
                {{scope.row.data.display.createUser}} ({{scope.row.data.createUser}})
              </template>
            </el-table-column>
          </tree-table>
          <!--=============-->
        </div>
        <div style="width: 40px;display: inline-block;height: 300px;vertical-align: top">
          <div class="Shuttle" @click="shuttlehandle()">
            <i class="el-icon-d-arrow-right"></i>
          </div>
        </div>
        <div class="revew-all-left-right">
          <div class="font-title" style="margin-bottom: 50px;">已选需求</div>
          <tree-table :data="selectedRequireData" :eval-args="args" :expand-all="expandAll" :show-check-box="showSelectedCheckBox"
            :class="{'tree-table-left-none':selectedRequireData.length == 0}" border style="margin-left: 0;width: 100%;">

            <el-table-column label="所属项目">
              <template slot-scope="scope">
                <!-- <span style="color:sandybrown">{{ scope.row.event }}</span> -->
                {{ scope.row.data.display.projectName}}
              </template>
            </el-table-column>
            <el-table-column label="提出人">
              <template slot-scope="scope">
                {{scope.row.data.display.createUser}} ({{scope.row.data.createUser}})
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button type="text" @click="deleteRequire(scope.row)" v-if="deleteable(scope.row)">删除</el-button>
              </template>
            </el-table-column>
          </tree-table>
          <el-button type="primary" v-if="reviewId > 0" @click="updateReview" class="fr mt10">确定修改</el-button>
          <el-button type="primary" v-else @click="createReview" class="fr mt10">发起评审</el-button>
          <el-button type="info" @click="goPrePage" class="fr mr10 mt10">取消</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  import treeTable from '@/components/mine/review/treeTable'
  // import treeToArray from '@/components/mine/review/customEval'

  export default {
    name: 'CustomTreeTableDemo',
    components: { treeTable },
    data() {
      return {
        reserveKeyword: false,
        review: {
          title: "",//会议室
          requireIdList: [],
          reviewUserList: [],
          reviewTime: "",//时间
          reviewAddress: "",//地点
          remark: ""
        },
        reviewId: 0,
        projectId: "-1",
        requireTitle: null,
        reviewUsers: [],
        projecInfoList: [],
        // func: treeToArray,
        expandAll: true,
        showSearchCheckBox: true,
        showSelectedCheckBox: false,
        requireData: [],
        multipleSelection: [],
        selectedRequireData: [],
        args: [null, null, 'timeLine'],
        loading: false,
        childIdListOfDelete: []
      }
    },
    mounted() {
      this.reviewId = this.getUrlParams().reviewId;
      if (this.reviewId > 0) {   //编辑评审
        //评审的基本信息
        this.getReviewInfo(this.reviewId);

        //评审中的需求信息
        $http.get($http.api.review.require_info_tree, { reviewId: this.reviewId }).then(res => {
          this.selectedRequireData = res.data;
        })
      }

      $http.get($http.api.project.projectList).then(res => {
        this.projecInfoList = res.data;
      })

      this.getSearchRequires();
    },
    methods: {
      // 返回上一页
      goPrePage() {
        this.$router.go(-1);
      },
      getReviewInfo(reviewId) {
        let params = {
          reviewId: reviewId
        };
        $http.get($http.api.review.brief_info, params).then((res) => {
          this.review = res.data;
          this.review.reviewUserList = this.review.reviewUserList.map(item => {
            this.reviewUsers.push({ label: item.reviewUserName, value: item.reviewUser })
            return item.reviewUser;
          });
        })
      },
      getSearchRequires() {
        // if ((!this.projectId || this.projectId == 0)&& !this.requireTitle) {
        //   this.$message({message: '项目和标题不能同时为空',type: 'warning'});
        //   return
        // }

        let params = {
          projectId: this.projectId,
          title: this.requireTitle
        };
        $http.get($http.api.review.search_require, params).then((res) => {
          this.requireData = res.data;

        })
      },
      getReviewUsers(query) {
        if (query !== '') {
          this.loading = true;
          let params = { keyword: query };
          $http.get($http.api.user_info.get_search_users, params).then((res) => {
            this.reviewUsers = res.data.map(item => {
              return { value: item.userId, label: item.userName };
            });
            this.loading = false;
          })
        } else {
          this.reviewUsers = [];
        }
      },
      selectedRequireDataToIdList() {
        let requireIds = [];
        this.selectedRequireData.forEach((item) => {

          this.iterationMethod(requireIds, item);
        });
        return requireIds;
      },
      iterationMethod(requireIds, node) {
        requireIds.push(node.data.id);
        if (node.children == null || node.children === "[]") {
          return;
        } else {
          node.children.forEach((item) => {
            this.iterationMethod(requireIds, item)
          })
        }
      },
      shuttlehandle() {
        let requireList = [];

        //筛选出的list
        let selectData = this.$refs['myTree'].getMultipleSelectData();
        selectData.forEach((item, index) => {
          requireList.push(item.data.id);
        });

        //已选择的list
        this.selectedRequireDataToIdList().forEach((item, index) => {
          requireList.push(item);
        })

        this.convertToTree(requireList);
      },
      deleteRequire(row) {
        this.childIdListOfDelete = [];
        this.childIdListOfDelete.push(row.data.id);
        this.getChildIdList(row);
        let requireList = this.selectedRequireDataToIdList();

        this.childIdListOfDelete.forEach(childId => {
          requireList.splice(requireList.findIndex((value) => {
            return value == childId;
          }), 1);
        })

        this.convertToTree(requireList);
      },
      convertToTree(requireList) {
        $http.post($http.api.review.convert_to_tree, JSON.stringify(requireList)).then((res) => {
          if (res.data == null) {
            this.selectedRequireData = [];
          } else {
            this.selectedRequireData = res.data;
          }
        })
      },
      checkReview() {
        this.review.reviewTime = new Date(this.review.reviewTime);
        if (this.review.title == null || this.review.title.trim().length < 1) {
          this.$message({ message: '评审标题不能为空！', type: 'error' });
          return false
        }
        if (this.review.reviewTime == null) {
          this.$message({ message: '评审时间不能为空！', type: 'error' });
          return false
        }
        if (this.review.reviewAddress == null || this.review.reviewAddress.trim().length < 1) {
          this.$message({ message: '评审地点不能为空！', type: 'error' });
          return false
        }
        if (this.review.reviewUserList == null || this.review.reviewUserList.length < 1) {
          this.$message({ message: '评审人不能为空！', type: 'error' });
          return false
        }
        if (this.selectedRequireData == null || this.selectedRequireData.length < 1) {
          this.$message({ message: '评审需求不能为空！', type: 'error' });
          return false
        }

        return true;
      },
      createReview() {  //发起评审
        if (this.checkReview()) {

          this.review.requireIdList = this.selectedRequireDataToIdList();

          this.sendCreateReviewRequest();
        }
      },
      sendCreateReviewRequest() {
        $http.post($http.api.review.add_review, this.review).then((res) => {
          if (res.status === 200) {
            this.$message({
              message: '发起评审成功',
              type: 'success'
            });
            this.goToPage(this, "mine");
          } else {
            this.$message({
              message: res.msg,
              type: 'success'
            })
          }
        }).catch((e) => {
          this.$message({
            message: '发起评审失败',
            type: 'error'
          });
        });
      },
      updateReview() {
        if (this.checkReview()) {

          this.review.requireIdList = this.selectedRequireDataToIdList();

          this.sendUpdateReviewRequest();
        }
      },
      sendUpdateReviewRequest() {
        $http.post($http.api.review.update_review, this.review).then((res) => {
          if (res.status === 200) {
            this.$message({
              message: '修改评审成功',
              type: 'success'
            })
            this.goToPage(this, "mine");
          } else {
            this.$message({
              message: res.msg,
              type: 'success'
            })
          }
        }).catch((e) => {
          this.$message({
            message: '修改评审失败',
            type: 'error'
          });
        });
      },
      deleteable(row) {
        // if (row.data.sprintId == this.getUrlParams().sprintId){
        //   return true;
        // }else{
        //   return false;
        // }
        return true;
      },
      getChildIdList(row) {
        if (!row.children) return;

        row.children.forEach(child => {
          this.childIdListOfDelete.push(child.data.id);
          this.getChildIdList(child);
        })
      }
    }
  }

</script>
<style lang="scss" scoped>
  .reverse-css {
    font-size: 16px;
    font-weight: 900;
    margin-top: 10px;
    float: left;
  }

  .content {
    .revew-all-left-right {
      width: calc(50% - 25px);
      display: inline-block;
      height: 100%;
      vertical-align: top;

      .font-title {
        font-size: 14px;
        font-weight: 900;
        line-height: 28px;
      }
    }
  }


  .counite-button {
    margin-left: 480px;
    margin-top: 20px;
  }


  .remarks-font {
    margin-top: 10px;
  }

  .cancle-modify {
    margin-top: 20px;
    margin-left: 10px;
  }

  .headername {
    margin-left: 296px;
    font-size: 16px;
    line-height: 40px;
    font-weight: 900;
  }

  .father {
    display: flex;
    justify-content: space-between;
  }

  .Shuttle {
    font-size: 30px;
    font-weight: 600;
    margin-top: 130px;
    margin-left: 5px;
    cursor: pointer;
  }


  .remarks {
    width: 395px;
    margin-top: 10px;
    margin-left: 10px;
    min-height: 60px;
    border: 1px solid #DDE5EF;
    border-radius: 2px;
  }
</style>
