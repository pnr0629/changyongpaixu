<template>
  <div style="width:600px;">
    <el-table :data="formatData" ref="multipleTable" :row-style="showRow" v-bind="$attrs"
              @selection-change="handleSelectionChange" @select="onSelectFun">

      <el-table-column type="selection" width="55" :selectable="selectableFunction" v-if="showCheckBox">
      </el-table-column>
      <el-table-column width="70" label="ID">
        <template slot-scope="scope">
          <span @click="handleClickItem(scope.row)" class="c-blue cp"> {{ getId(scope.row)}}</span>
        </template>
        <!--<template slot-scope="scope" v-else-if="scope.row.id != null">-->
        <!--{{ scope.row.id}}-->
        <!--</template>-->
      </el-table-column>
      <el-table-column v-if="columns.length===0" width="150px" label="标题">
        <template slot-scope="scope">
          <span v-for="space in scope.row._level" :key="space" class="ms-tree-space"/>
          <span v-if="iconShow(0,scope.row)" class="tree-ctrl" @click="toggleExpanded(scope.$index)">
              <i v-if="!scope.row._expanded" class="el-icon-plus"/>
              <i v-else class="el-icon-minus"/>
            </span>
          <span @click="handleClickItem(scope.row)" class="c-blue cp"> {{ getTitle(scope.row)}}</span>
        </template>
      </el-table-column>
      <el-table-column v-for="(column, index) in columns" v-else :key="column.value" :label="column.text"
                       :width="column.width">
        <template slot-scope="scope">
          <!-- Todo -->
          <!-- eslint-disable-next-line vue/no-confusing-v-for-v-if -->
          <span v-for="space in scope.row._level" v-if="index === 0" :key="space" class="ms-tree-space"/>
          <span v-if="iconShow(index,scope.row)" class="tree-ctrl" @click="toggleExpanded(scope.$index)">
              <i v-if="!scope.row._expanded" class="el-icon-plus"/>
              <i v-else class="el-icon-minus"/>
            </span>
          {{ scope.row[column.value] }}
        </template>
      </el-table-column>
      <slot/>
    </el-table>
  </div>
</template>
<script>
  import treeToArray from '@/components/tool/TreeTable/eval'

  export default {
    data() {
      return {
        multipleSelection: [],
      }
    },
    name: 'TreeTable',
    props: {
      /* eslint-disable */
      data: {
        type: [Array, Object],
        required: true
      },
      columns: {
        type: Array,
        default: () => []
      },
      evalFunc: Function,
      evalArgs: Array,
      // multipleSelection: Array,
      expandAll: {
        type: Boolean,
        default: false
      },
      showCheckBox: {
        type: Boolean,
        default: false
      }
    },
    computed: {
      // 格式化数据源
      formatData: function () {
        let tmp
        if (!Array.isArray(this.data)) {
          tmp = [this.data]
        } else {
          tmp = this.data
        }
        const func = this.evalFunc || treeToArray
        const args = this.evalArgs ? Array.concat([tmp, this.expandAll], this.evalArgs) : [tmp, this.expandAll]
        return func.apply(null, args)
      }
    },
    methods: {
      getId(data) {
        if (data.id) {
          return data.id;
        } else if (data.data.id) {
          return data.data.id;
        } else if (data.display.id) {
          return data.display.id;
        } else {
          return "";
        }
      },
      getTitle(data) {
        if (data.title) {
          return data.title;
        } else if (data.data.title) {
          return data.data.title;
        } else if (data.display.title) {
          return data.display.title;
        } else {
          return "";
        }
      },
      getMultipleSelectData() {
        return this.multipleSelection;
      },
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      showRow: function (row) {
        const show = (row.row.parent ? (row.row.parent._expanded && row.row.parent._show) : true)
        row.row._show = show
        return show ? 'animation:treeTableShow 1s;-webkit-animation:treeTableShow 1s;' : 'display:none;'
      },
      // 切换下级是否展开
      toggleExpanded: function (trIndex) {
       
        const record = this.formatData[trIndex]
        record._expanded = !record._expanded
      },
      // 图标显示
      iconShow(index, record) {
        return (index === 0 && record.children && record.children.length > 0)
      },
      selectableFunction(row, index) {
        // let reviewId = this.getUrlParams().reviewId;
        // if (row.data.reviewId == reviewId){
        //   return false;
        // }else{
        //   return true;
        // }
        return true;
      },
      onSelectFun(selection, row) {
        let select = false;
        selection.forEach(item => {
          if (item.data.id == row.data.id) {
            select = true;
          }
        });

        if (select) {  //选中
          //子需求处理
          this.selectChild(row);

          //父需求处理
          let parent = row.parent;
          while (parent) {
            this.$refs.multipleTable.toggleRowSelection(parent, true);
            parent = parent.parent;
          }

        } else { //取消
          // 子需求处理
          this.unSelectChild(row);
        }
      },
      unSelectChild(item) {
        if (!item.children) return;

        item.children.forEach(child => {
          this.$refs.multipleTable.toggleRowSelection(child, false);
          this.unSelectChild(child);
        })
      },
      selectChild(item) {
        if (!item.children) return;
        item.children.forEach(child => {
          this.$refs.multipleTable.toggleRowSelection(child, true);
          this.selectChild(child);
        })
      },
      handleClickItem(row) {
        this.goToNewWindowPage(this, "mineRequirementView", {requireId: row.data.id});
      }
    }
  }
</script>
<style rel="stylesheet/css">
  @keyframes treeTableShow {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }

  @-webkit-keyframes treeTableShow {
    from {
      opacity: 0;
    }
    to {
      opacity: 1;
    }
  }
</style>
<style lang="scss" rel="stylesheet/scss" scoped>
  $color-blue: #2196F3;
  $space-width: 18px;
  .ms-tree-space {
    position: relative;
    top: 1px;
    display: inline-block;
    font-style: normal;
    font-weight: 400;
    line-height: 1;
    width: $space-width;
    height: 14px;

    &::before {
      content: ""
    }
  }

  .processContainer {
    width: 100%;
    height: 100%;
  }

  table td {
    line-height: 26px;
  }

  .tree-ctrl {
    position: relative;
    cursor: pointer;
    color: $color-blue;
    margin-left: -$space-width;
  }
</style>
