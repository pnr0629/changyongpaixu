<template>
  <div class="content-outer-box">
    <div class="x-arD content-box">
      <slide :show="show" @click.stop ref="side" :beforeClose="handleSliderBeforeClose" :afterClose="HandleSide"
        v-loading="loading" element-loading-text="拼命加载中" element-loading-spinner="el-icon-loading"
        element-loading-background="rgb(255,255,255)">
        <div slot="task" class="silder-box">
          <task-edit :taskId="taskId" :projectId="projectId" :show="show" @HandleSide="HandleSide" :restore="restore"
            v-if="workType===1" :titleNotice.sync="sliderBeforeCloseData.title"
            :descNotice.sync="sliderBeforeCloseData.desc"></task-edit>
          <bug-detail :projectId="bugProjectId" :isSlider="true" @operateCallback="sendUpdateDefectRequest"  @refeshBug="updateDefectList"
            :detailType="detailType" :activeBugInfo="activeBugInfo" @detailClose="HandleSide" v-else-if="workType===2"
            :titleNotice.sync="sliderBeforeCloseData.title" :descNotice.sync="sliderBeforeCloseData.desc"></bug-detail>
          <Require-detail v-else-if="workType===3" :requireId="projectId1" :projectId="detaliId1"
            @HandleSide="HandleSide" :titleNotice.sync="sliderBeforeCloseData.title"
            :descNotice.sync="sliderBeforeCloseData.desc"></Require-detail>
        </div>

      </slide>
      <div class="page-content-box-width">
        <div class="demand-review" v-if="false">
          <div class="fl mine-demand">
            <div class="over">
              <div class="demand-title">我提出的需求</div>
              <el-button type="primary" class="intent-demand" @click="demandHandle">提需求</el-button>
            </div>
            <div class="serach over">
              <!-- <span class="fl ml10" style="line-height: 28px;">标题</span> -->
              <el-input class="fl ml10 " style="width:200px;" v-model="requireSearch.title" placeholder="请输入需求标题">
              </el-input>
              <!-- <span class="fl  ml10" style="line-height: 28px;">状态</span> -->
              <el-select class="fl ml10 " style="width:200px;" v-model="requireSearch.status" placeholder="请选择需求状态">
                <el-option value="" label="全部"></el-option>
                <el-option v-for="item in requireStatusList" :key=item.statusId :label="item.statusName"
                  :value=item.statusId>
                  <template slot-scope="scope"><span style="float: left"><span class="mini-circle"
                        :style="{backgroundColor:item.color}"></span>{{item.statusName}}</span></template>
                </el-option>
              </el-select>
              <el-button type="success" class="fl  ml10" @click="handleSearchRequire()">查询</el-button>
            </div>
            <div class="table-outer-box">
              <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
                <div class="table-box-top">
                  <el-table :data="requireData1">
                    <!-- <el-table-column prop="id" label="需求ID" width="80px">
                    <template slot-scope="scope">
                      <span @click="toRequireDetail(scope.row.id, scope.row.projectId)" class="c-blue cp">{{scope.row.id}}</span>
                    </template>
                  </el-table-column> -->
                    <el-table-column label="需求标题" prop="display.title" min-width="200px">
                      <template slot-scope="scope">
                        <span @click="toRequireDetail(scope.row.id, scope.row.projectId)" class="c-blue cp title-elips"
                          :title="scope.row.display.title">{{scope.row.display.title}}</span>
                      </template>
                    </el-table-column>
                    <!-- <el-table-column prop="display.projectName" label="项目">
                  </el-table-column> -->
                    <el-table-column prop="display.createUser" label="当前处理人" width="140">
                      <template slot-scope="scope">
                        <span> {{scope.row.display.createUser}} ({{scope.row.createUser}})</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="expectedTime" label="预计完成时间" width="100">
                    </el-table-column>
                    <el-table-column label="状态" width="60">
                      <template slot-scope="scope">
                        <span class="title-elips">{{scope.row.display.status}}</span>
                      </template>

                    </el-table-column>
                    <el-table-column label="操作" width="60">
                      <template slot-scope="scope">
                        <span class="c-blue cp" v-if="userData.userId == scope.row.createUser"
                          @click="deleteRequire(scope.row)">删除</span>
                        <span class="c-blue cp" @click="refuseRequire(scope.row.id,scope.row.display.title)"
                          v-if="!done && !created && userData.userId != scope.row.createUser">拒绝</span>
                        <!--已完成和我创建的，屏蔽”拒绝“按钮-->
                      </template>
                    </el-table-column>

                  </el-table>
                </div>
                <div class="table_b_f_b ">
                  <el-pagination v-show="requireData1.length != 0" class="pagination"
                    @size-change="handleRequirePageSizeChange1" @current-change="handleRequirePageNumChange1"
                    :current-page="requirePageInfo1.pageNum" :page-sizes="[5]" :page-size="requirePageInfo1.pageSize"
                    layout="total, prev, next" :total="requirePageInfo1.total" prev-text="上一页" next-text='下一页'>
                  </el-pagination>
                </div>
              </div>
            </div>
          </div>
          <!-- 需求评审 -->
          <div class="fl review">
            <div class="over">
              <div class="review-title">需求评审</div>
              <el-button type="primary" class="intent-demand" @click="reviewHandle" v-show="workBenchProjectAuth">发起评审
              </el-button>
            </div>

            <div class="control-left">
              <el-radio-group text-color='#ffffff' fill='#409EFF' v-model="radio4" size="small"
                @change="changeStausHandle()">
                <el-radio-button label="5" style="display:block;">待处理</el-radio-button>
                <el-radio-button label="6" class="radio-button">已完成</el-radio-button>
              </el-radio-group>
            </div>
            <div class="review-right">
              <div class="serach over">
                <!-- <span class="fl ml10" style="line-height: 28px;">标题</span> -->
                <el-input class="fl ml10 " style="width:200px;" v-model="reviewSearch.title" placeholder="请输入评审标题">
                </el-input>
                <!-- <span class="fl  ml10" style="line-height: 28px;">状态</span>
                      <el-select class="fl ml10 " style="width:200px;" v-model="requireSearch.status" placeholder="请选择需求状态">
                        <el-option v-for="item in requireStatusList" :key=item.statusId :label="item.statusName" :value=item.statusId></el-option>
                      </el-select> -->
                <el-button type="success" class="fl ml10" @click="handleSearchReview()">查询</el-button>
              </div>
              <div class=" ">
                <div class="table-box" v-loading="table_loading" show-header="false" element-loading-text="拼命加载中">
                  <div class="table-box-top">
                    <div class="review-box" v-for="(data,index) in reviewData">

                      <div class="review-l">
                        <span class="ml10 c-blue cp" @click="toReviewDetail(data.id)"> {{data.title}}</span>
                        <span class="ml10">{{data.createUserName}}({{data.createUser}})&nbsp;发起</span>
                        <span class="ml10"><span class="font-weight">时间：</span>{{data.reviewTime}}</span>
                        <span class="ml10"><span class="font-weight">地点：</span>{{data.reviewAddress}}</span>

                        <span class="c-blue ml10 cp" @click="editReview(data.id)"
                          v-if="userData.userId === data.createUser">编辑</span>

                      </div>


                    </div>
                    <div v-if="reviewData.length <= 0" class="tip-info">暂无数据</div>
                    <!-- <span class="c-blue cp" @click="editReview(scope.row.id)" v-if="userData.userId == scope.row.createUser">编辑</span> -->
                    <!-- <el-table :data="reviewData">
                    <el-table-column label="评审标题" prop="title" min-width="200px">
                      <template slot-scope="scope">
                        <span @click="toReviewDetail(scope.row.id)" class="c-blue cp">{{scope.row.title}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="reviewTime" label="时间" width="140">
                      <template slot-scope="scope">
                        <span>{{scope.row.reviewTime}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="reviewAddress" label="地点">
                      <template slot-scope="scope">
                        <span>{{scope.row.reviewAddress}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="createUserName" label="发起人" width="140">
                      <template slot-scope="scope">
                        <span> {{scope.row.createUserName}} ({{scope.row.createUser}})</span>
                      </template>
                    </el-table-column>
                  
                    <el-table-column width="120" label="操作" v-if="mineFlag===0">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="editReview(scope.row.id)" v-if="userData.userId == scope.row.createUser">编辑</span>

                      </template>
                    </el-table-column>
                  </el-table> -->
                  </div>
                  <div class="table_b_f_b">
                    <el-pagination v-show="reviewData.length != 0" class="pagination"
                      @size-change="handleReviewPageSizeChange" @current-change="handleReviewPageNumChange"
                      :current-page="reviewPageInfo.pageNum" :page-sizes="[5]" :page-size="reviewPageInfo.pageSize"
                      layout="total, prev, next" :total="reviewPageInfo.total" prev-text="上一页" next-text='下一页'>
                    </el-pagination>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 需求池 -->
        <div class="demand-pool" v-show="workBenchProjectAuth" v-if="false">
          <div class="over">
            <div class="demand-title">需求池</div>
            <div class="fr mt13 mr20">
              <el-select class="fl ml10 " style="width:200px;" v-model="requirePoolSearch.statusId"
                placeholder="请选择需求状态">
                <el-option v-for="item in requirePoolStatus" :key=item.statusId :label="item.statusName"
                  :value=item.statusId></el-option>
              </el-select>
              <el-input class="fl ml10 " style="width:200px;" v-model="requirePoolSearch.title" placeholder="请输入需求标题">
              </el-input>
              <!-- <span class="fl  ml10" style="line-height: 28px;">状态</span> -->
              <el-button type="success" class="fl  ml10" @click="handlesearchPoolRequire()">查询</el-button>
            </div>
          </div>

          <el-radio-group text-color='#ffffff' fill='#409EFF' v-model="requirePoolProjectId" size="small">
            <el-radio-button label="-1">全部</el-radio-button>
            <el-radio-button label="0">仅指派给我的</el-radio-button>
            <el-radio-button :label="data.id" v-for="(data,index) in projectListData" :key="index">{{data.name}}
            </el-radio-button>
          </el-radio-group>
          <!-- <div class="dpool-serach over">
            <span class="fl  " style="line-height: 28px;">标题</span>
            <el-input class="fl ml10 " style="width:200px;" v-model="requirePoolSearch.title" placeholder="请输入需求标题"></el-input>
           
            <el-button type="success" class="fl  ml10" @click="handlesearchPoolRequire()">查询</el-button>
          </div> -->
          <div class="white-box table-outer-box" style="margin-top:10px;">
            <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
              <div class="table-box-top">
                <el-table :data="requirePoolData">
                  <el-table-column label="标题" prop="title" min-width="200px">
                    <template slot-scope="scope">
                      <span @click="toRequireDetail(scope.row.id, scope.row.projectId)"
                        class="c-blue cp">{{scope.row.display.title}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="提出人" width="140">
                    <template slot-scope="scope">
                      <span> {{scope.row.display.createUser}} ({{scope.row.createUser}})</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="指派项目" width="140">
                    <template slot-scope="scope">
                      <span> {{scope.row.display.projectName}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="指派人" width="140">
                    <template slot-scope="scope">
                      <span> {{scope.row.display.assignUser}} ({{scope.row.assignUser}})</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="期望完成时间" width="140">
                    <template slot-scope="scope">
                      <span>{{scope.row.expectedTime}}</span>
                    </template>
                  </el-table-column>

                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination v-show="requirePoolData.length != 0" class="pagination"
                  @size-change="handleRequirepPoolPageSizeChange" @current-change="handleRequirePoolPageNumChange"
                  :current-page="requirePoolPageInfo.pageNum" :page-sizes="[5]"
                  :page-size="requirePoolPageInfo.pageSize" layout="total, prev, next"
                  :total="requirePoolPageInfo.total" prev-text="上一页" next-text='下一页'>
                </el-pagination>
              </div>
            </div>
          </div>
        </div>
        <!-- 工作项 v-show="authMenu('SYS_WORKBENCH_REQUIRE_POOL', 0)"-->
        <div class="work-item">
          <div class="over">
            <h2 class="demand-title">工作项</h2>
          </div>
          <div class="wItem-status">
            <div :class="itemFlag===1 ? 'witem-box1' : 'witem-box' " @click.stop="handItemStausChange(1)">
              <div class="left_25pMb">
                <div class="total_2aKSL">
                  {{statisticsData.unhandleRequireCount+statisticsData.unhandleTaskCount+statisticsData.unhandledDefectCount}}
                </div>
                <div class="title_FveyG">待处理</div>
              </div>
              <div class="right_2jSLI">
                <div class="type_1fIGk"><a @click.stop="unhandleRequireSerach()"
                    :style="{'text-decoration':unhandleItem===1 ? 'underline':'none'}">
                    <i class="iconfont icon-requirement f13"></i>需求&nbsp;:&nbsp;{{statisticsData.unhandleRequireCount}}
                  </a>
                </div>

                <div class="type_1fIGk">
                  <a @click.stop="unhandleTaskSerach"
                    :style="{'text-decoration':unhandleItem===2 ? 'underline':'none'}">
                    <i class="iconfont icon-task f14"></i>任务&nbsp;:&nbsp;{{statisticsData.unhandleTaskCount}}
                  </a>
                </div>
                <div class="type_1fIGk">
                  <a @click.stop="unhandleDefectSerach"
                    :style="{'text-decoration':unhandleItem===7 ? 'underline':'none'}">
                    <i class="iconfont icon-bug f14"></i>缺陷&nbsp;:&nbsp;{{statisticsData.unhandledDefectCount}}
                  </a>
                </div>
              </div>
            </div>
            <div :class="itemFlag===3 ? 'witem-box1' : 'witem-box' " @click.stop="handItemStausChange(3)">
              <div class="left_25pMb">
                <div class="total_2aKSL">
                  {{statisticsData.handledRequireCount+statisticsData.handledTaskCount+statisticsData.handledDefectCount}}
                </div>
                <div class="title_FveyG">已完成</div>
              </div>
              <div class="right_2jSLI">
                <div class="type_1fIGk">
                  <a @click.stop="finshRequireSerach()"
                    :style="{'text-decoration':unhandleItem===5? 'underline':'none'}">
                    <i class="iconfont icon-requirement f13"></i>需求&nbsp;:&nbsp;{{statisticsData.handledRequireCount}}
                  </a>
                </div>

                <div class="type_1fIGk">
                  <a @click.stop="finshTaskSerach" :style="{'text-decoration':unhandleItem===6 ? 'underline':'none'}">
                    <i class="iconfont icon-task f14"></i>任务&nbsp;:&nbsp;{{statisticsData.handledTaskCount}}
                  </a>
                </div>
                <div class="type_1fIGk">
                  <a @click.stop="finshDefectSerach" :style="{'text-decoration':unhandleItem===9? 'underline':'none'}">
                    <i class="iconfont icon-bug f14"></i>缺陷&nbsp;:&nbsp;{{statisticsData.handledDefectCount}}
                  </a>
                </div>
              </div>
            </div>
            <div :class="itemFlag===2 ? 'witem-box1' : 'witem-box' " @click.stop="handItemStausChange(2)">
              <div class="left_25pMb">
                <div class="total_2aKSL">
                  {{statisticsData.createRequireCount+statisticsData.createTaskCount+statisticsData.createDefectCount}}
                </div>
                <div class="title_FveyG">我创建</div>
              </div>
              <div class="right_2jSLI">
                <div class="type_1fIGk">
                  <a @click.stop="createleRequireSerach()"
                    :style="{'text-decoration':unhandleItem===3 ? 'underline':'none'}">
                    <i class="iconfont icon-requirement f13"></i>需求&nbsp;:&nbsp;{{statisticsData.createRequireCount}}
                  </a>
                </div>

                <div class="type_1fIGk">
                  <a @click.stop="createTaskSerach" :style="{'text-decoration':unhandleItem===4 ? 'underline':'none'}">
                    <i class="iconfont icon-task f14"></i>任务&nbsp;:&nbsp;{{statisticsData.createTaskCount}}
                  </a>
                </div>
                <div class="type_1fIGk">
                  <a @click.stop="createDefectSerach" :style="{'text-decoration':unhandleItem===8? 'underline':'none'}">
                    <i class="iconfont icon-bug f14"></i>缺陷&nbsp;:&nbsp;{{statisticsData.createDefectCount}}
                  </a>
                </div>
              </div>
            </div>
          </div>
          <!--  -->
          <div v-if="itemFlag===1" style="width: 70%;display: inline-block">
            <div class="witem-choose">
              <el-radio-group text-color='#ffffff' fill='#409EFF' v-model="wItemProjectId" size="small">
                <el-radio-button label="-1">全部</el-radio-button>
                <el-radio-button :label="data.id" v-for="(data,index) in wItemCount" :key="index"
                  :style="{'display':data.description==0? 'none':'inline-block'}">
                  {{data.name}}({{data.description}})</el-radio-button>
              </el-radio-group>
            </div>
            <div>
              <div class="witem-list" v-for="(data,index) in unhandleWorkitemData" :key="index">
                <div class="witem">
                  <div class="over">
                    <div class="fl witem-left">
                      <i v-if="data.workItemType===1" class="iconfont icon-requirement"></i>
                      <i v-else-if="data.workItemType===2" class="iconfont icon-task"></i>
                      <i v-else-if="data.workItemType===3" class="iconfont icon-bug"></i>
                      <el-dropdown @command="handleChooseRquireItem" :popper-append-to-body="false" trigger="click"
                        placement="bottom-start" v-if="data.workItemType===1">
                        <el-button type="primary"
                          :style="{backgroundColor:data.display.detail.status.color,borderColor:data.display.detail.status.color}"
                          class="w85" @click="getNextStatusList(data.statusId,data.id)">
                          {{data.display.status}}<i class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item :command="data.statusId" v-for="(data,index) in nextStatusList"
                            :key="index"><span class="mini-circle"
                              :style="{backgroundColor:data.color}"></span>{{data.statusName}}</el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                      <el-dropdown @command="handleChooseTaskItem" trigger="click" placement="bottom-start"
                        v-else-if="data.workItemType===2">
                        <el-button type="primary" class="w85"
                          :style="{backgroundColor:data.display.detail.status.color,borderColor:data.display.detail.status.color}"
                          @click="getNextStaus(data.statusId,data.id)">
                          <span :title="data.display.status">{{data.display.status}}</span> <i
                            class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item :command="data.statusId" v-for="(data,index) in taskStatusData"
                            :key="index"><span class="mini-circle"
                              :style="{backgroundColor:data.color}"></span>{{data.statusName}}</el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                      <el-dropdown @command="(info)=>{handleChooseDefectItem(info, data)}" trigger="click"
                        placement="bottom-start" v-else-if="data.workItemType===3">
                        <el-button type="primary" class="w85"
                          :style="{backgroundColor:data.display.detail.status.color,borderColor:data.display.detail.status.color}"
                          @click="getNexDefectStatus(data.statusId,data.id)">
                          {{data.display.status}}<i class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item :command="data" v-for="(data,index) in defectStatusData" :key="index"><span
                              class="mini-circle" :style="{backgroundColor:data.color}"></span>{{data.statusName}}
                          </el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                    </div>
                    <div class="fl witem-middle" @click="toTaskDetail(data, $event,1)" v-if="data.workItemType===1">
                      <div class="item-text">
                        {{data.display.title}}
                      </div>
                    </div>
                    <div class="fl witem-middle" @click="toTaskDetail(data,$event,2)" v-else-if="data.workItemType===2">
                      <div class="item-text">
                        {{data.display.title}}
                      </div>
                    </div>
                    <div class="fl witem-middle" @click="toTaskDetail(data,$event,3)" v-else-if="data.workItemType===3">
                      <div class="item-text">
                        {{data.display.title}}
                      </div>
                    </div>
                    <div class="fr witem-right">
                      <div>
                        <div class=" item-project">
                          {{data.display.projectName}}
                        </div>
                        <span> <span class="mini-circle"
                            :style="{backgroundColor:data.display.detail.priority.color}"></span><span>{{data.display.detail.priority.literal}}</span></span>
                      </div>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
          <div v-else style="width: 70%;display: inline-block">
            <div class="witem-choose">
              <el-radio-group text-color='#ffffff' fill='#409EFF' v-model="wItemProjectType" size="small"
                @change="changeTyepeHandle()">
                <el-radio-button label="1">需求</el-radio-button>
                <el-radio-button label="2">任务</el-radio-button>
                <el-radio-button label="3">缺陷</el-radio-button>
              </el-radio-group>
            </div>
            <!-- 需求 -->
            <div v-if="wItemProjectType===1">
              <div class="witem-list" v-for="data in requireData" :key="data.id">
                <div class="witem">
                  <div class="over">
                    <div class="fl witem-left">
                      <i class="iconfont icon-requirement"></i>
                      <!-- <i v-else-if="data.workItemType===2" class="iconfont icon-task"></i> -->
                      <el-dropdown @command="handleChooseRquireItem" :popper-append-to-body="false" trigger="click"
                        placement="bottom-start">
                        <el-button type="primary" class="w85"
                          :style="{backgroundColor:data.display.detail.status.color,borderColor:data.display.detail.status.color}"
                          @click="getNextStatusList(data.statusId,data.id)">
                          <span class=""></span> {{data.display.status}}<i
                            class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item :command="data.statusId" v-for="(data,index) in nextStatusList"
                            :key="index"><span class="mini-circle"
                              :style="{backgroundColor:data.color}"></span>{{data.statusName}}</el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                    </div>
                    <div class="fl witem-middle">
                      <div class="fl cp" @click="toTaskDetail(data, $event,1)">
                        <div class="item-text">
                          {{data.display.title}}
                        </div>
                      </div>
                    </div>
                    <div class="fr witem-right">
                      <div>
                        <div class=" item-project">
                          {{data.display.projectName}}
                        </div>
                        <span> <span class="mini-circle"
                            :style="{backgroundColor:data.display.detail.priority.color}"></span><span>{{data.display.detail.priority.literal}}</span></span>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="table_b_f_b" style="background:#fff;width:calc(100% - 21px);margin-left:21px;">
                <el-pagination v-show="requireData.length != 0" class="pagination"
                  @size-change="handleRequirePageSizeChange" @current-change="handleRequirePageNumChange"
                  :current-page="requirePageInfo.pageNum" :page-sizes="[20]" :page-size="requirePageInfo.pageSize"
                  layout="total, prev, next" :total="requirePageInfo.total" prev-text="上一页" next-text='下一页'>
                </el-pagination>
              </div>
              <!-- <div class="table_b_f_b">
                <el-pagination v-show="requireData.length != 0" class="fr mr10" style="margin-top: 9px;" @size-change="handleRequirePageSizeChange"
                  @current-change="handleRequirePageNumChange" :current-page="requirePageInfo.pageNum" :page-sizes="[10, 20, 30]"
                  :page-size="requirePageInfo.pageSize" layout="total, sizes, prev, next" :total="requirePageInfo.total"
                  prev-text="上一页" next-text='下一页'>

                </el-pagination>
              </div> -->
            </div>
            <!-- 任务 -->
            <div v-else-if="wItemProjectType===2">
              <div class="witem-list" v-for="(data,index) in taskData" :key="data.id">
                <div class="witem">
                  <div class="over">
                    <div class="fl witem-left">
                      <i class="iconfont icon-task"></i>
                      <el-dropdown @command="handleChooseTaskItem" :popper-append-to-body="false" trigger="click"
                        placement="bottom-start">
                        <el-button type="primary" class="w85"
                          :style="{backgroundColor:data.display.detail.status.color,borderColor:data.display.detail.status.color}"
                          @click="getNextStaus(data.statusId,data.id)">
                          {{data.display.status}}<i class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item :command="data.statusId" v-for="(data,index) in taskStatusData"
                            :key="index"><span class="mini-circle"
                              :style="{backgroundColor:data.color}"></span>{{data.statusName}}</el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                    </div>
                    <div class="fl witem-middle" @click="toTaskDetail(data,$event,2)">
                      <div class="item-text">
                        {{data.display.title}}
                      </div>

                    </div>
                    <div class="fr witem-right">
                      <div>
                        <div class=" item-project">
                          {{data.display.projectName}}
                        </div>
                        <span> <span class="mini-circle"
                            :style="{backgroundColor:data.display.detail.priority.color}"></span><span>{{data.display.detail.priority.literal}}</span></span>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="table_b_f_b" style="background:#fff;width:calc(100% - 21px);margin-left:21px;">
                <el-pagination v-show="taskData.length != 0" class="pagination" @size-change="handleTaskPageSizeChange"
                  @current-change="handleTaskPageNumChange" :current-page="taskPageInfo.pageNum" :page-sizes="[20]"
                  :page-size="taskPageInfo.pageSize" layout="total, prev, next" :total="taskPageInfo.total"
                  prev-text="上一页" next-text='下一页'>
                </el-pagination>
              </div>
            </div>
            <!-- 缺陷 -->
            <div v-else-if="wItemProjectType===3">
              <div class="witem-list" v-for="(data) in DefecectData" :key="data.id">
                <div class="witem">
                  <div class="over">
                    <div class="fl witem-left">
                      <i class="iconfont icon-bug"></i>
                      <el-dropdown @command="(info)=>{handleChooseDefectItem(info, data)}" trigger="click"
                        placement="bottom-start">
                        <el-button type="primary" class="w85"
                          :style="{backgroundColor:data.display.detail.status.color,borderColor:data.display.detail.status.color}"
                          @click="getNexDefectStatus(data.statusId,data.id)">
                          {{data.display.status}}<i class="el-icon-arrow-down el-icon--right"></i>
                        </el-button>
                        <el-dropdown-menu slot="dropdown">
                          <el-dropdown-item :command="data" v-for="(data,index) in defectStatusData" :key="index"><span
                              class="mini-circle" :style="{backgroundColor:data.color}"></span>{{data.statusName}}
                          </el-dropdown-item>
                        </el-dropdown-menu>
                      </el-dropdown>
                    </div>
                    <div class="fl witem-middle" @click="toTaskDetail(data,$event,3)">
                      <div class="item-text">
                        {{data.display.title}}
                      </div>
                    </div>
                    <div class="fr witem-right">
                      <div>
                        <div class=" item-project">
                          {{data.display.projectName}}
                        </div>
                        <span> <span class="mini-circle"
                            :style="{backgroundColor:data.display.detail.priority.color}"></span><span>{{data.display.detail.priority.literal}}</span></span>
                      </div>

                    </div>
                  </div>
                </div>
              </div>
              <div class="table_b_f_b" style="background:#fff;width:calc(100% - 21px);margin-left:21px;">
                <el-pagination v-show="DefecectData.length != 0" class="pagination"
                  @size-change="handleDefectPageSizeChange" @current-change="handleDefectPageNumChange"
                  :current-page="defectPageInfo.pageNum" :page-sizes="[20]" :page-size="defectPageInfo.pageSize"
                  layout="total, prev, next" :total="defectPageInfo.total" prev-text="上一页" next-text='下一页'>
                </el-pagination>
              </div>
            </div>

          </div>
          <!--收藏应用-->
          <div style="float: right;vertical-align: top;margin-top: 10px;margin-right: 5px;width: calc(100% - 72%);">
            <el-table :data="collectionAppsPageInfo.list">
              <el-table-column prop="appCode" label="我收藏的应用" min-width="80">
                <template slot-scope="scope">
                  <span class="cp-only c-blue" @click="goToAppDetail(scope.row)">{{scope.row.appCode}}</span>
                </template>
              </el-table-column>
            </el-table>
            <div class="table_b_f_b">
              <el-pagination class="fr" style="margin-top: 5px;" @size-change="handleCollectAppsSizeChange"
                @current-change="handleCollectAppsPageChange" :current-page="collectionAppsPageInfo.pageNum"
                :page-size="collectionAppsPageInfo.pageSize" :page-sizes="[10,20]"
                layout="total, sizes, prev, pager, next" :total="collectionAppsPageInfo.total">
              </el-pagination>
            </div>
          </div>

        </div>
      </div>
    </div>
    <!-- 二级状态选择、添加评论 -->
    <comment-for-status v-bind="CommentForStatusInfo"></comment-for-status>
  </div>
</template>

<script>
  import Distpicker from "v-distpicker";
  import slide from 'components/tool/slideSlip'
  import taskEdit from 'components/project/task/taskDetail.vue'
  import bugDetail from 'components/project/bugManagement/BugDetail.vue'
  import RequireDetail from 'components/project/requirement/requirementView'
  import CommentForStatus from 'components/project/bugManagement/CommentForStatus.vue'
  import ProjectCommonMixin from "components/project/ProjectCommonMixin"
  import TinymceSaveMixin from "@/components/commonComponents/TinymceSaveMixin"

  export default {
    name: "buildingAtask",
    components: {
      "v-distpicker": Distpicker,
      taskEdit,
      slide,
      bugDetail,
      RequireDetail,
      CommentForStatus
    },
    mixins: [ProjectCommonMixin, TinymceSaveMixin],
    data() {
      return {
        // 缺陷二级状态选择及评论
        CommentForStatusInfo: {
          isShow: false,
          statusInfo: {},
          parentInfo: {},
          onOk: this.bugStatusClickCallbackOnOk,
          onCancel: this.bugStatusClickCallbackOnCancel
        },
        requirePoolData: [],//需求池
        detailType: 'show',
        activeBugInfo: {
          id: null
        },
        tabDisplay: false,
        workType: null,
        projectId1: null,
        tableHeight: window.innerHeight - 100,
        requireSearch: { title: "", status: null },
        reviewSearch: { title: "" },
        requirePoolStatus: [{ statusId: 1, statusName: "未评审" }, { statusId: 21, statusName: "已评审(未规划)" }],
        requirePoolSearch: { statusId: 1, title: "" },
        requireStatusList: [],
        todo: true,
        done: false,
        created: false,

        table_loading: false,
        tableList: {},
        requirePoolProjectId: -1, //切换绑定
        workBenchProjectAuth: false,

        requireData: [],
        requireData1: [],
        requireCount: 0,
        requirePageInfo: { pageNum: 1, pageSize: 20, pages: 0, total: 0 },
        requirePageInfo1: { pageNum: 1, pageSize: 5, pages: 0, total: 0 },
        taskData: [],
        taskCount: 0,
        requirePoolPageInfo: { pageNum: 1, pageSize: 5, pages: 0, total: 0 },
        unhandleWorkitemData: [],
        reviewData: [],
        wItemCount: [],
        reviewPageInfo: { pageNum: 1, pageSize: 5, pages: 0, total: 0 },
        taskPageInfo: { pageNum: 1, pageSize: 20, pages: 0, total: 0 },
        defectPageInfo: { pageNum: 1, pageSize: 20, pages: 0, total: 0 },
        mineFlag: 0,

        radio4: 5,
        refuseDialogVisible: false,
        refuseRequireForm: {
          requireId: 0,
          refuseRequireTitle: "",
          refuseReason: ""
        },

        reversedWidth: '',
        userData: {},
        count: 0,
        restore: 1,
        preID: null,
        show: false,
        taskId: null,
        statusId: null,
        requireId: null,
        detaliId1: null,//评审详情id
        projectId: null,
        defectId: null,
        loading: false,
        projectListData: [],
        statisticsData: [],//统计数
        wItemType: -1,
        bugProjectId: null,//传给缺陷的项目ID
        wItemProjectId: -1,
        nextStatusList: [],
        itemFlag: 1,//选项切换
        InterfaceChange: 1,//接口切换
        taskStatusData: [], //任务状态数据
        wItemProjectType: 1,//区分我创建和已完成的需求与任务
        unhandleItem: -1,//区分待处理 全部 需求 任务
        defectStatusData: [],//下个缺陷状态数据
        DefecectData: [],//缺陷列表数据

        collectionAppsPageInfo: {
          pageNum: 1,
          pageSize: 10,
        },
      };
    },
    watch: {
      show: function (newName, oldName) {
        if (newName !== true) {
          if (this.itemFlag === 1) {
            this.getStatistics()
            this.getunhandleWorkitem()
          } else {
            this.getStatistics()
            this.getTaskList()
            this.getDefectList()
          }
        }
      },
      requirePoolProjectId: function (newVal, oldVal) {
        if (newVal !== oldVal) {
          this.requirePoolPageInfo.pageNum = 1;
          this.getRequirePool()
        }
      },
      wItemProjectId: function (newVal, oldVal) {
        if (newVal !== oldVal) {

          this.getunhandleWorkitem()
        }
      }
    },
    mounted() {
      this.userData = $utils.getStorage(GLOBAL_CONST.USER_INFO);
      this.getSearchStatusList();
      this.getMineRequire();
      this.getWorkBenchProjectAuth();
      this.getWorkBenchItemCount();
      this.getReviewList();
      this.getStatistics();
      this.getunhandleWorkitem();
      this.getMyCollectApps()
    },
    beforeRouteLeave(to, from, next) {
      // 如果存在内容在编辑，则不能离开
      if (this.sliderBeforeCloseData.title || this.sliderBeforeCloseData.desc) {
        return false;
      }
      next()
    },
    methods: {
      //删除刷新缺陷
      updateDefectList() {
        this.fuc && this.fuc()
        switch (this.itemFlag) {
          case 1:
            this.unhandleDefectSerach();
            break;
          case 2:
            this.createDefectSerach();
            break;
          case 3:
            this.finshDefectSerach();
            break;
          default:
            break;
        }
      },
      // slider 关闭前的回调 - 用于数据缓存清除
      handleSliderBeforeClose({ cb }) {
        let id;
        switch (this.workType) {
          case 1: id = this.taskId; break;
          case 2: id = this.activeBugInfo.id; break;
          case 3: id = this.projectId1; break;
        }
        if (!id) { return; }
        this.beforeSliderClose({ id, cb })
      },
      unhandleRequireSerach(e) {
        this.itemFlag = 1;
        this.unhandleItem = 1;
        this.wItemType = 1;
        this.getunhandleWorkitem()
        this.getWorkBenchItemCount();

      },
      unhandleTaskSerach() {

        this.itemFlag = 1;
        this.unhandleItem = 2;
        this.wItemType = 2;
        this.getunhandleWorkitem()
        this.getWorkBenchItemCount();

      },
      unhandleDefectSerach() {
        this.itemFlag = 1;
        this.unhandleItem = 7;
        this.wItemType = 3;
        this.getunhandleWorkitem()
        this.getWorkBenchItemCount();
      },
      createleRequireSerach() {
        this.itemFlag = 2;
        this.unhandleItem = 3;
        this.wItemProjectType = 1;
        this.requirePageInfo.pageNum = 1;
        this.changeTyepeHandle()
      },
      createTaskSerach() {
        this.itemFlag = 2;
        this.unhandleItem = 4;
        this.wItemProjectType = 2;
        this.taskPageInfo.pageNum = 1;
        this.changeTyepeHandle()

      },
      createDefectSerach() {
        this.itemFlag = 2;
        this.unhandleItem = 8;
        this.wItemProjectType = 3;
        this.defectPageInfo.pageNum = 1;
        this.changeTyepeHandle()
      },
      finshRequireSerach() {
        this.itemFlag = 3;
        this.unhandleItem = 5;
        this.wItemProjectType = 1;
        this.requirePageInfo.pageNum = 1;
        this.changeTyepeHandle()
      },
      finshTaskSerach() {
        this.itemFlag = 3;
        this.unhandleItem = 6;
        this.wItemProjectType = 2;
        this.requirePageInfo.pageNum = 1;

        this.changeTyepeHandle()
        // this.handItemStausChange()
      },
      finshDefectSerach() {
        this.itemFlag = 3;
        this.unhandleItem = 9;
        this.wItemProjectType = 3;
        this.requirePageInfo.pageNum = 1;
        this.changeTyepeHandle()

        // this.handItemStausChange()
      },

      handItemStausChange(data) {
        this.unhandleItem = 0;
        // this.unhandleItem = -1;
        this.itemFlag = data
        if (this.itemFlag === 1) {
          this.wItemType = -1;
          this.getunhandleWorkitem();

        } else if (this.itemFlag === 2) {
          // this.InterfaceChange = 2
          this.created = true;
          this.done = false;

          if (this.wItemProjectType === 1) {
            this.getRequireList()
          } else if (this.wItemProjectType === 2) {
            this.getTaskList()
          } else {
            this.getDefectList()
          }
        } else if (this.itemFlag === 3) {
          this.done = true;
          this.created = false;

          if (this.wItemProjectType === 1) {
            this.getRequireList()
          } else if (this.wItemProjectType === 2) {
            this.getTaskList()
          } else {
            this.getDefectList()
          }
        }
      },
      handleChooseRquireItem(statusId) {
        this.sendUpdateRequireRequest(statusId, this.requireId);
      },
      handleChooseTaskItem(statusId) {
        this.sendUpdateTaskRequest(statusId, this.taskId)
      },
      handleChooseDefectItem(info, data) {
        // 如果不需要评论
        if (!info.fields.present) {
          this.sendUpdateDefectRequest(info.statusId, this.defectId)
        } else {
          // 如果需要评论，只要 toComment 为 true ，或者 children.length > 0
          this.CommentForStatusInfo = {
            isShow: true,
            statusInfo: { ...info, key: info.statusId },
            parentInfo: data,
            onOk: this.bugStatusClickCallbackOnOk,
            onCancel: this.bugStatusClickCallbackOnCancel
          }
        }
        // this.sendUpdateDefectRequest(statusId, this.defectId)
      },
      // 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击确定
      bugStatusClickCallbackOnOk(value, cb) {
        this.CommentForStatusInfo.isShow = false
        this.sendUpdateDefectRequest(value.statusId, this.defectId, value)
        cb && cb(true)
      },
      // 更新缺陷 - 状态变化 - 添加二级状态及评论 - modal 点击取消
      bugStatusClickCallbackOnCancel() {
        this.CommentForStatusInfo.isShow = false
      },
      sendUpdateDefectRequest(statusId, id, obj = {}) {
        $http.post($http.api.defect.update_list, { statusId, id, ...obj }).then((res) => {
          this.$message({ message: '修改缺陷成功', type: 'success' });
          if (this.itemFlag === 1) {
            this.getunhandleWorkitem();
          } else {
            this.getDefectList()
          }
          this.getStatistics()
          this.getWorkBenchItemCount()
        }).catch(e => {
          this.$message({ message: e, type: 'warning' });
        })
      },
      sendUpdateTaskRequest(statusId, id) {
        $http.post($http.api.task.taskUpdate, { statusId, id }).then((res) => {
          this.$message({ message: '修改任务成功', type: 'success' });
          if (this.itemFlag === 1) {
            this.getunhandleWorkitem();
          } else {
            this.getTaskList();
          }
          this.getStatistics()
          this.getWorkBenchItemCount()
        }).catch(e => {
          this.$message({ message: e, type: 'warning' });
        })
      },
      sendUpdateRequireRequest(statusId, id) {
        $http.post($http.api.requirement.update, { statusId, id }).then(res => {
          this.getunhandleWorkitem()
          this.$message({ message: '修改需求成功', type: 'success' });
          if (this.itemFlag === 1) {
            this.getunhandleWorkitem();
          } else {
            this.getRequireList();
          }
          this.getStatistics()
          this.getWorkBenchItemCount()
        }).catch(e => {
          // this.requirement.sprintId = this.editBackupValue;
          // this.requirement.statusId = this.statusValue;
          this.$message({ message: e, type: 'warning' });
        })
      },

      getNextStaus(statusId, id) {
        this.taskId = id;
        $http.post($http.api.status.list_updatable, {
          workItemType: 2,
          workItemId: this.taskId,
          statusId: statusId
        }).then((res) => {
          this.taskStatusData = res.data
        }).catch((e) => {
          this.$message({ message: '操作失败', type: 'error' });
        });
      },

      getNexDefectStatus(statusId, id) {

        this.defectStatusData = []
        this.defectId = id;
        $http.post($http.api.status.list_updatable, {
          workItemType: 3,
          workItemId: this.defectId,
          statusId: statusId
        }).then((res) => {

          this.defectStatusData = res.data;
        }).catch((e) => {
          this.$message({ message: '操作失败', type: 'error' });
        });
      },
      getNextStatusList(statusId, id) {
        this.statusId = statusId;
        this.requireId = id;

        //未评审状态，不能在这里修改状态
        if (statusId === 1) {
          this.nextStatusList = [];
          return
        }
        $http.post($http.api.status.list_updatable, {
          workItemType: 1,
          workItemId: this.requireId,
          statusId: this.statusId
        }).then(res => {
          this.nextStatusList = [];
          this.nextStatusList = res.data;

        })
      },
      // 获取项目列表
      getProjectList() {
        $http.get($http.api.mine.requirePoolProjectList).then((res) => {
          this.projectListData = res.data;

        })
      },
      // 获取待处理工作项
      getunhandleWorkitem() {
        $http.get($http.api.mine.unhandle_workitem, {
          workItemType: this.wItemType,
          projectId: this.wItemProjectId,
        }).then(res => {
          this.$nextTick(() => {
            this.unhandleWorkitemData = res.data;
          })

        })
      },
      getSearchStatusList() {
        $http.post($http.api.status.workbench_status, {
          workItemType: 1,
          workBench: { todo: false, done: false, created: true }
        }).then(res => {
          this.requireStatusList = res.data;
        })
      },
      // 跳转到
      intentDemandList(requireId, projectId, type) {
        // let projectId = data.id;

        this.goToPage(this, "requirementView", { requireId, projectId })


      },
      //跳转到审评页面
      reviewHandle() {
        this.$router.push({ name: 'review' });
      },
      //跳转到需求页面 
      demandHandle() {
        this.$router.push({ name: 'requirementCreate' });
      },
      //跳转到评审详情页面
      toReviewDetail(reviewId) {
        const { href } = this.$router.resolve({
          name: "reviewDetail",
          query: { reviewId: reviewId }
        });
        window.open(href, '_blank');
      },
      toRequireDetail(requireId, e, projectId) {//toTaskDetail
        // const { href } = this.$router.resolve({
        //   name: "mineRequirementView",
        //   query: { requireId: requireId, projectId: projectId }
        // });
        // window.open(href, '_blank');

        this.toTaskDetail(requireId, e, projectId)
      },
      HandleSide(e) {

        if (this.show) {
          this.show = false;
          this.count = 0;
          this.restore = Math.random() * 10;
          // this.$refs.side.style.right = -51 + '%';
        }

      },
      toTaskDetail(data, e, number) {
        if (!data.id) {
          this.$message({ type: "error", message: "服务器返回数据错误" })
          return
        }
        if (number == 2) {
          this.workType = 1;
          this.projectId = data.projectId;
        } else if (number == 3) {
          this.workType = 2;
          // console.log('缺陷')
          this.bugProjectId = data.projectId
        } else {

          this.workType = 3;
          this.detaliId1 = data.projectId;
          this.projectId1 = data.id;
        }
        // const {href} = this.$router.resolve({
        //   name: "taskEdit",
        //   query: {taskId: taskId, projectId: projectId}
        // });
        // window.open(href, '_blank');
        if (e && e.stopPropagation) {//非IE浏览器
          e.stopPropagation();
        } else {//IE浏览器
          window.event.cancelBubble = true;
        }
        this.$nextTick(() => {
          this.loading = true;

          setTimeout(() => {
            this.loading = false;
          }, 500);
        })

        // let projectId = this.getUrlParams().projectId
        // this.goToNewWindowPage(thi s, "taskEdit", { taskId: data.id, projectId })

        if (this.count === 0) {
          this.preID = data.id
          this.show = !this.show;
          this.activeBugInfo = { id: data.id };
          this.taskId = data.id;
          this.restore = Math.random() * 10;
          this.count++;

        } else {
          if (this.preID !== data.id) {
            this.preID = data.id
            this.activeBugInfo = { id: data.id };
            // this.show = !this.show;
            this.taskId = data.id;
            this.restore = Math.random() * 10;

          } else {
            this.restore = Math.random() * 10;
            this.preID = data.id
            this.count = 0;
            this.show = !this.show;
            this.taskId = data.id
            this.activeBugInfo = { id: data.id };

          }

        }
      },

      changeStausHandle() {
        if (this.radio4 == 5) {
          this.mineFlag = 0;
          this.getReviewList();
        } else {
          this.mineFlag = 1;
          this.getReviewList()
        }
      },
      changeTyepeHandle() {

        if (this.wItemProjectType == 1) {
          if (this.itemFlag === 2) {
            this.unhandleItem = 3;
            this.done = false;
            this.created = true;
          } else if (this.itemFlag === 3) {
            this.unhandleItem = 5;
            this.done = true;
            this.created = false;
          }

          this.wItemProjectType = 1;
          this.getRequireList()
          // console.log('需求')
        } else if (this.wItemProjectType == 2) {
          if (this.itemFlag === 2) {
            this.unhandleItem = 4;
            this.done = false;
            this.created = true;
          } else if (this.itemFlag == 3) {
            this.unhandleItem = 6;
            this.done = true;
            this.created = false;
          }
          // console.log('任务')
          this.getTaskList()
          this.wItemProjectType = 2;

        } else if (this.wItemProjectType == 3) {
          if (this.itemFlag === 2) {
            this.unhandleItem = 8;
            this.done = false;
            this.created = true;
          } else if (this.itemFlag == 3) {
            this.unhandleItem = 9;
            this.done = true;
            this.created = false;
          }
          // console.log('缺陷')

          this.getDefectList()
          this.wItemProjectType = 3;
        }
      },
      getWorkBenchItemCount() {
        $http.get($http.api.mine.workbenchCount, {
          workItemType: -1,
          workItemType: this.wItemType,
        }).then(res => {
          // this.requireCount = res.data.requireCount;
          // this.taskCount = res.data.taskCount;
          // console.log(res.data)
          this.wItemCount = res.data;
        }).catch(e => {

        })
      },
      handleSearchRequire() {
        this.requirePageInfo1.pageNum = 1;
        this.getMineRequire();
      },
      handleSearchReview() {
        this.reviewPageInfo.pageNum = 1;
        this.getReviewList()
      },
      handlesearchPoolRequire() {
        this.requirePoolPageInfo.pageNum = 1;
        this.getRequirePool()
      },
      getDefectList() {
        // return ;
        $http.post($http.api.defect.defect_list,
          JSON.stringify({

            workBench: {
              // todo: this.todo,
              done: this.done,
              created: this.created
            },
            orderBy: [{
              column: "createTime",
              order: "DESC"
            }],
            pageInfo: {
              pageNumber: this.defectPageInfo.pageNum,
              pageSize: this.defectPageInfo.pageSize
            }
          })).then(res => {
            this.DefecectData = res.data.result;
            // console.log(this.DefecectData)
            this.defectPageInfo.pageNum = res.data.pageInfo.pageNumber;
            this.defectPageInfo.pageSize = res.data.pageInfo.pageSize;
            this.defectPageInfo.pages = res.data.pageInfo.totalPages;
            this.defectPageInfo.total = res.data.pageInfo.totalRecords;
          })
      },
      handleDefectPageSizeChange(pageSize) {
        this.defectPageInfo.pageSize = pageSize;
        this.getDefectList();
      },
      handleDefectPageNumChange(pageNum) {
        this.defectPageInfo.pageNum = pageNum;
        this.getDefectList();
      },
      getRequireList() {
        $http.post($http.api.mine.minedDemand,
          JSON.stringify({

            workBench: {
              // todo: this.todo,
              done: this.done,
              created: this.created
            },
            orderBy: [{
              column: "createTime",
              order: "DESC"
            }],
            pageInfo: {
              pageNumber: this.requirePageInfo.pageNum,
              pageSize: this.requirePageInfo.pageSize
            }
          })).then(res => {

            this.requireData = res.data.result;
            // console.log(this.requireData)
            this.requirePageInfo.pageNum = res.data.pageInfo.pageNumber;
            this.requirePageInfo.pageSize = res.data.pageInfo.pageSize;
            this.requirePageInfo.pages = res.data.pageInfo.totalPages;
            this.requirePageInfo.total = res.data.pageInfo.totalRecords;
          })
      },
      handleRequirePageSizeChange(pageSize) {
        // console.log(pageSize)
        this.requirePageInfo.pageSize = pageSize;
        this.getRequireList();
      },
      handleRequirePageNumChange(pageNum) {
        this.requirePageInfo.pageNum = pageNum;
        this.getRequireList();
      },
      getMineRequire() {
        $http.post($http.api.mine.minedDemand,
          JSON.stringify({
            title: this.requireSearch.title,
            statusId: this.requireSearch.status,
            workBench: {
              todo: false,
              done: false,
              created: true
            },
            orderBy: [{
              column: "createTime",
              order: "DESC"
            }],
            pageInfo: {
              pageNumber: this.requirePageInfo1.pageNum,
              pageSize: this.requirePageInfo1.pageSize
            }
          })).then(res => {
            this.$nextTick(() => {
              this.requireData1 = res.data.result;
              // console.log(this.requireData1)
              this.requirePageInfo1.pageNum = res.data.pageInfo.pageNumber;
              this.requirePageInfo1.pageSize = res.data.pageInfo.pageSize;
              this.requirePageInfo1.pages = res.data.pageInfo.totalPages;
              this.requirePageInfo1.total = res.data.pageInfo.totalRecords;
            })
          })
      },

      handleRequirePageSizeChange1(pageSize) {
        this.requirePageInfo1.pageSize = pageSize;
        this.getMineRequire();
      },
      handleRequirePageNumChange1(pageNum) {
        this.requirePageInfo1.pageNum = pageNum;
        this.getMineRequire();
      },
      getWorkBenchProjectAuth() {

        $http.get($http.api.mine.workBenchProjectAuth).then(res => {
          if (res.data) {
            this.workBenchProjectAuth = true;
            this.getRequirePool();
            this.getProjectList();
          }
        })
      },

      getRequirePool() {
        $http.post($http.api.mine.minedDemand,
          JSON.stringify({
            title: this.requirePoolSearch.title,
            statusId: this.requirePoolSearch.statusId,
            requirePool: { projectId: this.requirePoolProjectId },
            workBench: {
              todo: true,
              done: false,
              created: false
            },
            orderBy: [{
              column: "createTime",
              order: "DESC"
            }],
            pageInfo: {
              pageNumber: this.requirePoolPageInfo.pageNum,
              pageSize: this.requirePoolPageInfo.pageSize
            }
          })).then(res => {
            this.requirePoolData = res.data.result;
            // console.log(res.data)
            this.requirePoolPageInfo.pageNum = res.data.pageInfo.pageNumber;
            this.requirePoolPageInfo.pageSize = res.data.pageInfo.pageSize;
            this.requirePoolPageInfo.pages = res.data.pageInfo.totalPages;
            this.requirePoolPageInfo.total = res.data.pageInfo.totalRecords;
          })
      },

      handleRequirepPoolPageSizeChange(pageSize) {
        this.requirePoolPageInfo.pageSize = pageSize;
        this.getRequirePool();
      },
      handleRequirePoolPageNumChange(pageNum) {
        this.requirePoolPageInfo.pageNum = pageNum;
        this.getRequirePool();
      },
      // 获取统计数
      getStatistics() {
        $http.get($http.api.mine.statistics).then(res => {
          // console.log(res.data)
          this.statisticsData = res.data
          // console.log(this.statisticsData)
        })
      },
      getTaskList() {
        $http.post($http.api.mine.mineTask,
          JSON.stringify({
            workBench: {
              // todo: this.todo,
              done: this.done,
              created: this.created
            },
            orderBy: [{
              column: "createTime",
              order: "DESC"
            }],
            pageInfo: {
              pageNumber: this.taskPageInfo.pageNum,
              pageSize: this.taskPageInfo.pageSize
            }
          })).then(res => {
            this.taskData = res.data.result;
            this.taskPageInfo.pageNum = res.data.pageInfo.pageNumber;
            this.taskPageInfo.pageSize = res.data.pageInfo.pageSize;
            this.taskPageInfo.pages = res.data.pageInfo.totalPages;
            this.taskPageInfo.total = res.data.pageInfo.totalRecords;
          })
      },
      handleTaskPageSizeChange(pageSize) {
        this.taskPageInfo.pageSize = pageSize;
        this.getTaskList();
      },
      handleTaskPageNumChange(pageNum) {
        this.taskPageInfo.pageNum = pageNum;
        this.getTaskList();
      },
      getReviewList() {
        $http.get($http.api.mine.reviewList, {
          title: this.reviewSearch.title,
          flag: this.mineFlag,
          pageNum: this.reviewPageInfo.pageNum,
          pageSize: this.reviewPageInfo.pageSize
        }).then((res) => {

          this.reviewData = res.data.list;
          this.reviewPageInfo.pageNum = res.data.pageNum;
          this.reviewPageInfo.pageSize = res.data.pageSize;
          this.reviewPageInfo.pages = res.data.pages;
          this.reviewPageInfo.total = res.data.total;

        })
      },
      handleReviewPageSizeChange(pageSize) {
        this.reviewPageInfo.pageSize = pageSize;
        this.getReviewList();
      },
      handleReviewPageNumChange(pageNum) {
        this.reviewPageInfo.pageNum = pageNum;
        this.getReviewList();
      },


      editReview(id) {
        this.goToPage(this, "review", { reviewId: id })
      },
      // deleteReview(row) {
      //   this.$confirm('确认删除评审单[' + row.title + ']吗？').then(_ => {
      //     $http.post($http.api.review.delete_review, { reviewId: row.id }, { type: 'form' }).then((res) => {
      //       this.$message({ message: '删除评审成功', type: 'success' });
      //       this.getReviewList();
      //     })
      //   }).catch(_ => {

      //   });
      // },
      deleteRequire(row) {
        this.$confirm('确认删除需求[' + row.display.title + ']吗？').then(_ => {
          $http.get($http.api.requirement.delete, { id: row.id }).then((res) => {
            this.$message({ message: '删除需求成功', type: 'success' });
            this.getMineRequire();
          })
        }).catch(_ => {

        });
      },
      deleteTask(row) {
        this.$confirm('确认删除任务[' + row.display.title + ']吗？').then(_ => {
          $http.get($http.api.task.deleteTask, { id: row.id }).then((res) => {
            this.$message({ message: '删除任务成功', type: 'success' });
            this.getTaskList();
          })
        }).catch(_ => {

        });

      },
      refuseRequire(id, title) {
        this.refuseRequireForm.requireId = id;
        this.refuseRequireForm.refuseRequireTitle = title;
        this.refuseDialogVisible = true;
      },
      sureRefuseRequire() {
        this.$refs['refuseReasonForm'].validate(validate => {
          if (validate) {
            $http.post($http.api.requirement.update, {
              id: this.refuseRequireForm.requireId,
              statusId: 62,
              comment: this.refuseRequireForm.refuseReason
            }).then(res => {
              this.getRequireList();
              this.refuseDialogVisible = false;
            })
          }
        })
      },

      getMyCollectApps() {
        $http.get($http.api.app.get_my_collect_apps, { pageNum: this.collectionAppsPageInfo.pageNum, pageSize: this.collectionAppsPageInfo.pageSize }).then((res) => {
          this.collectionAppsPageInfo = res.data
        }).catch(e => {
          this.$message({ message: '获取我的收藏应用失败！', type: 'error' });
        })
      },
      handleCollectAppsSizeChange(val) {
        this.collectionAppsPageInfo.pageSize = val
        this.getMyCollectApps()
      },
      handleCollectAppsPageChange(val) {
        this.collectionAppsPageInfo.pageNum = val
        this.getMyCollectApps()
      },
      goToAppDetail(val) {
        this.goToNewWindowPage(this, "appVersions", { appId: val.appId, bizId: val.bizId });
      },
    }
  };
</script>

<style lang="scss" scoped>
  //tab显示/隐藏
  .tabDisplay {
    display: none;
  }

  .w1366 {
    width: 80%;
    margin: 0 auto;
  }

  .f13 {
    font-size: 13px;
  }

  .f14 {
    font-size: 14px;
  }

  .f15 {
    font-size: 15px;
  }

  .w85 {
    width: 105px;
  }

  .over {
    overflow: hidden;
  }

  .fl {
    float: left;
  }

  .fr {
    float: right;
  }

  .mt13 {
    margin-top: 13px;
  }

  .cp {
    cursor: pointer;
    width: 66%;
  }

  .title-elips {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .tip-info {
    text-align: center;
    padding-top: 20px;
  }

  .ml10 {
    margin-left: 10px;
  }

  .serach {
    /* margin-left: 10px;
    width: calc(99% - 10px); */
    width: 100%;
    ;
    background-color: #fff;
    padding: 5px 0 5px 0;


  }

  .font-weight {
    font-weight: 900;
    color: #000;
  }

  .review-box {
    padding: 5px;

    .review-l {
      border-bottom: 1px solid #ccc;
      padding-bottom: 10px;
    }
  }

  .wItem-status {
    display: flex;
    width: 60%;
  }

  .witem-box {
    margin-left: 20px;
    color: #999;
    cursor: pointer;
    background: #f5f5f5;
    border: 1px solid #e8e8e8;
    border-radius: 3px;
    flex: 1;
    position: relative;
    padding: 10px;
    min-width: 150px;
  }

  .witem-box1 {
    margin-left: 20px;
    color: #999;
    cursor: pointer;
    background: #fff;
    border: 1px solid #e8e8e8;
    border-radius: 3px;
    flex: 1;
    position: relative;
    padding: 10px;
    min-width: 150px;
  }

  .witem-choose {
    margin-top: 15px;
    margin-left: 20px;
  }

  .witem-box1:before,
  .witem-box1:hover:before {
    content: "";
    position: absolute;
    bottom: -8px;
    left: 45%;
    z-index: 2;
    width: 0;
    height: 0;
    border: 8px solid;
    border-color: #fff transparent;
    border-bottom: 0;
  }

  .witem-box:hover:before {
    content: "";
    position: absolute;
    bottom: -8px;
    left: 45%;
    z-index: 2;
    width: 0;
    height: 0;
    border: 8px solid;
    border-color: #fff transparent;
    border-bottom: 0;

  }

  .witem-box:hover {
    background-color: #fff;
  }

  /* .witem-box:after, .witem-box:hover:after {
    content: "";
    position: absolute;
    bottom: -10px;
    left: 44%;
    z-index: 1;
    width: 0;
    height: 0;
    border: 10px solid;
    border-color: rgba(102,102,102,.5) transparent;
    border-bottom: 0;
} */
  .left_25pMb {
    float: left;
    width: 50%;
    margin: 0;
    color: #999;
    text-align: center;
  }

  .total_2aKSL {
    font-size: 30px;
    font-weight: 700;
    line-height: 46px;
    font-family: impact;
  }

  .title_FveyG {
    font-size: 14px;
    line-height: 26px;
    overflow: hidden;
    white-space: nowrap;
  }

  .right_2jSLI {
    float: right;
    width: 45%;
    height: 100%;
    margin: 0;
    color: #999;
    text-align: left;
    display: flex;
    flex-direction: column;
  }

  .right_2jSLI {
    .type_1fIGk {
      flex: 1;
      font-size: 12px;
      width: 100%;
      vertical-align: middle;
      margin-top: 4px;

      a {
        &:hover {
          text-decoration: underline !important;
        }
      }
    }
  }

  .item-list {
    margin: 5px;

  }


  .dpool-serach {
    /* margin-left: 10px;
    width: calc(100% - 15px); */
    background-color: #fff;
    padding: 5px 0 5px 10px;

  }

  .demand-review {
    overflow: hidden;
    margin-top: 20px;
    max-height: 366px;
    min-height: 200px;
    // display: none;
  }

  .pagination {
    /* float: right; */
    float: right;
    margin-top: 2px;
    margin-right: 10px;
  }

  .mine-demand,
  .review {
    background-color: rgba(242, 242, 242, 1);
    height: 100%;
    width: 48.5%;
    float: left;
    /* min-height: 300px;
    max-height: 100%; */
    overflow: hidden;
    margin-left: 1%;
    border-style: solid;
    border-width: 1px;
    border-color: rgba(242, 242, 242, 1);
    /* border-bottom: none */
  }

  .review-title,
  .demand-title {
    /* padding-left: 10px; */
    float: left;
    padding: 10px 0 10px 20px;
    font-size: 16px;
    font-weight: 900;
  }

  .intent-demand,
  .intent-review {
    float: right;
    margin-top: 6px;
    margin-right: 20px;
  }

  .demand-pool {
    display: none;
  }

  .demand-pool,
  .work-item {
    width: 98%;
    min-height: 300px;
    background-color: rgba(242, 242, 242, 1);
    margin-top: 20px;
    margin-left: 1%;
    margin-right: 1%;
    padding-bottom: 20px;
    border: 1px solid rgba(242, 242, 242, 1);
    overflow: hidden;
  }

  .witem {
    background-color: #fff;
    width: 100%;
    padding: 10px;
    border-bottom: 1px solid #ccc;
    box-sizing: border-box;
  }

  .witem-list {
    margin-left: 21px;

    .witem-left {}

    .witem-middle {
      @extend .cp;
      width: 60%;
    }

    .witem-right {}
  }

  .item-text {
    font-size: 15px;
    color: #333;
    font-weight: 500;
    padding-left: 20px;
  }

  .item-recods {
    font-size: 12px;
    color: #999;
    padding-left: 20px;
    padding-top: 5px;
  }

  .item-time {
    font-size: 12px;
    color: #999;
    padding-left: 10px;
    padding-top: 5px;
  }

  .item-project {
    background: var(--color-fill1-2, #F2F3F7);
    border-radius: 4px;
    padding: 2px 10px;
    margin-right: 10px;

    display: inline-block;
  }

  .urgent-font {
    border: 2px solid #f85e5e;
    width: 11px;
    height: 11px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 6px;
    position: relative;
    top: 3px;
  }

  .hight-font {
    border: 1px solid #f6a71f;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 6px;
    position: relative;
    top: 3px;
  }

  .middle-font {
    border: 1px solid #93c36b;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 6px;
    position: relative;
    top: 3px;
  }

  .min-font {
    border: 1px solid #97afd0;
    width: 10px;
    height: 10px;
    border-radius: 50%;
    display: inline-block;
    margin-right: 6px;
    position: relative;
    top: 3px;
  }

  .silder-box {
    /* width: calc(100% - 185px); */
    overflow-x: hidden;
  }

  .control-left {
    /* width: 110px; */
    /* margin-top: 9px; */
    float: left;
    width: 84px;

  }

  .review-right {
    float: left;
    width: calc(100% - 84px);
  }




  .radio-button {
    display: block;
    border-left: 1px solid #dcdfe6;
    border-radius: 0 4px 4px 4px;
    ;
  }


  .control-right {
    float: right;
    width: calc(100% - 110px);
  }

  .cp-only {
    cursor: pointer;
  }
</style>