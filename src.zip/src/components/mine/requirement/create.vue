<template>
  <div id="demand" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar page-content-box-width">
        <span class="fl mt10" style="font-size: 16px;font-weight: 900;">提需求</span>
      </div>
      <div class="page-content-box-width">
        <div class="fl left-box">
          <div style="height:50px;background:#fff;">
            <span class="tit fl mt10 " style="font-size: 14px;line-height: 28px;">标题</span>
            <el-input class="fl ml10 mt10" v-model="requirement.title" style="width:500px;"
                      placeholder="请输入需求标题"></el-input>
            <el-button class="fr mt10" type="primary" @click="saveRequire()">保存</el-button>
            <el-button type="info" class="fr mt10 mr10" @click="goPrePage">取消</el-button>
          </div>
          <div class="wrap-edit">
            <div class="app-container">
              <div class="editcc">
                <editor class="editor" v-model="requirement.content" v-on:editHnadle="editHnadle($event)" ref="fullTextEditor"></editor>
              </div>
            </div>
          </div>

          <div class="Enclosure">
            <div class="appendix-name">附件</div>
            <el-upload class="upload-demo" multiple drag ref="upload" v-bind:action="uploadActionUrl"
                       :on-success="handleUploadSuccess"
                       :auto-upload="true" :data="upoladID" accept :show-file-list="false">
              <i class="el-icon-upload"></i>
              <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
            </el-upload>
          </div>
          <div class="fileList" v-for="(row,index) in fileDataList" :key="createRequirement" @mouseenter="Handleenter(row)"
               @mouseleave='Handleleave()'>
            <div class="fl list">
              {{row.origName}}
            </div>
            <div class="fl list">{{row.size}}KB</div>
            <div class="fl list">{{row.display.createUser}}({{row.createUser}})</div>
            <i v-show="deleteShow == row.id" class="el-icon-close" style="line-height:25px;"
               @click="deleteAttachment(row.id)"></i>
            <!-- <el-button @click="deleteAttachment(row.id)">删除</el-button> -->
          </div>
        </div>
        <div class="fr right-box">
          <el-radio-group v-model="assignRadio" @change="handleAssignRadioChange">
            <el-radio :label="1">指派人</el-radio>
            <el-radio :label="2">指派项目</el-radio>
          </el-radio-group>
          <div v-show="assignRadio == 1" class="mt20">
            <span class="tit fl mt10 " style="line-height:28px;width:80px;">处理人</span>
            <el-select placeholder="请选择需求处理人" filterable class="fl ml10 mt10" v-model="requirement.team.assignUser"
                       style="width:calc(100% - 90px);">
              <el-option
                v-for="(row,index) in requirement.team.assignUserList"
                :key="row.userId"
                :label="row.userName"
                :value="row.userId">
                <span style="float: left">{{ row.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px">{{ row.userId }}</span>
              </el-option>
            </el-select>
            <span class="tit fl mt10 " style="line-height:28px;width:80px;">期望完成时间</span>
            <el-date-picker
              v-model="requirement.team.expectedTime"
              type="date"
              value-format="yyyy-MM-dd"
              class="fl ml10 mt10"
              align="bottom"
              placeholder="选择日期"
              prefix-icon="clean-icon"
              style="width:calc(100% - 90px);">
            </el-date-picker>
          </div>
          <div v-show="assignRadio == 2" class="mt20">
            <span class="tit fl mt10 " style="line-height:28px;width:80px;">指派项目</span>
            <el-select placeholder="选择需求指派项目" class="fl ml10 mt10" style="width:calc(100% - 90px);"
                       v-model="requirement.projectId"
                       @change="handleProjectSelectChange">
              <el-option
                v-for="(row,index) in assignProjectList"
                :key="row.id"
                :label="row.name"
                :value="row.id">
              </el-option>
            </el-select>
            <span class="tit fl mt10 " style="line-height:28px;width:80px;">处理人</span>
            <el-select placeholder="选择需求处理人" class="fl ml10 mt10" style="width:calc(100% - 90px);"
                       v-model="requirement.project.assignUser">
              <el-option
                v-for="(row,index) in requirement.project.assignUserList"
                :key="row.userId"
                :label="row.userName"
                :value="row.userId">
                <span style="float: left">{{ row.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px">{{ row.userId }}</span>
              </el-option>
            </el-select>
            <span class="tit fl mt10 " style="line-height:28px;width:80px;">期望完成时间</span>
            <el-date-picker
              style="width:calc(100% - 90px);"
              v-model="requirement.project.expectedTime"
              type="date"
              value-format="yyyy-MM-dd"
              class="fl ml10 mt10"
              align="bottom"
              prefix-icon="clean-icon"
              placeholder="选择日期">
            </el-date-picker>
          </div>
        </div>
        <div style="clear: both"></div>
      </div>
    </div>
  </div>
</template>

<script>

  import editor from '@/components/tool/markedit'

  export default {
    name: "editor-demo",
    data() {
      return {
        deleteShow: false,
        intermediateValue: '',//处理监听子组件返回的中间值
        requirement: {
          title: "",
          content: "",
          expectedTime: "",
          teamId: null,
          projectId: null,
          assignUser: "",
          attachments: [],
          team: {assignUser: "", assignUserList: [], expectedTime: ""},
          project: {assignUser: "", assignUserList: [], expectedTime: ""}
        },
        assignRadio: 1,
        editorSetting: {
          height: 400,
        },
        upoladID: {
          workItemType: 0,
          workItemId: 0
        },
        fileDataList: [],
        uploadActionUrl: $http.api.attachment.upload.url,
        assignTeamList: [],
        assignProjectList: [],
        userInfo: {userId: 0}
      }
    },
    mounted() {
      this.getLoginUserInfoAndInit();
      this.getRequreReceiveUsers();

    },
    methods: {
      getLoginUserInfoAndInit() {
        $http.get($http.api.user_info.get_user_info, {}).then(res => {
          if (res.data.toAssignProject) {
            this.assignRadio = 2;
            this.userInfo.userId = res.data.userId;
            this.getAssignProjectList();
          }

        })
      },
      editHnadle(data) {
        this.requirement.content = data;

      },
      Handleenter(row) {
        this.deleteShow = row.id;
      },
      Handleleave() {
        this.deleteShow = false;
      },
      getAssignTeamList() {
        $http.get($http.api.project.assign_team_list).then(res => {
          this.assignTeamList = res.data;
        })
      },
      getAssignProjectList() {
        $http.get($http.api.project.assign_project_list).then(res => {
          this.assignProjectList = res.data;
        })
      },
      handleAssignRadioChange() {
        if (this.assignRadio == 1) {
          this.getAssignTeamList();
        } else {
          this.getAssignProjectList();
        }
      },
      handleTeamSelectChange() {
        this.assignTeamList.forEach(item => {
          if (item.id == this.requirement.teamId) {
            this.assignUserList = item.users;
          }
        })
      },
      getRequreReceiveUsers() {
        $http.post($http.api.project.query_assign_user, {query: null}).then(res => {
          this.requirement.team.assignUserList = res.data;
        })
      },
      handleProjectSelectChange() {
        this.assignProjectList.forEach(item => {
          if (item.id == this.requirement.projectId) {
            this.requirement.project.assignUserList = item.users;

            if (item.users.contains(this.userInfo.userId)) {
              this.requirement.project.assignUser = this.userInfo.userId;
            }
          }
        })
      },
      handleUploadSuccess(res) {
        this.fileDataList.push(res.data)
      },
      checkRequire() {
        if (this.requirement.title == "") {
          this.$message({message: "需求标题不能为空", type: 'error'});
          return false
        }
        if (this.requirement.content == "") {
          this.$message({message: "需求内容不能为空", type: 'error'});
          return false
        }

        if (this.assignRadio == 1) {
          if (!this.requirement.team.assignUser) {
            this.$message({message: "指派人时，处理人不能为空", type: 'error'});
            return false
          }
          if (!this.requirement.team.expectedTime) {
            this.$message({message: "指派人时，期望完成时间不能为空", type: 'error'});
            return false
          }

          this.requirement.projectId = 0;
          this.requirement.assignUser = this.requirement.team.assignUser;
          this.requirement.expectedTime = this.requirement.team.expectedTime;
        } else {
          if (!this.requirement.projectId) {
            this.$message({message: "指派项目时，项目不能为空", type: 'error'});
            return false
          }
          if (!this.requirement.project.assignUser) {
            this.$message({message: "指派项目时，处理人不能为空", type: 'error'});
            return false
          }
          if (!this.requirement.project.expectedTime) {
            this.$message({message: "指派人时，期望完成时间不能为空", type: 'error'});
            return false
          }

          this.requirement.teamId = null;
          this.requirement.assignUser = this.requirement.project.assignUser;
          this.requirement.expectedTime = this.requirement.project.expectedTime;
        }
        return true;
      },
      // 返回上一页
      goPrePage() {
        this.$router.go(-1);
      },
      saveRequire() {

        if (!this.checkRequire()) return;

        this.requirement.attachments = [];
        this.fileDataList.forEach(fileData => {
          this.requirement.attachments.push(fileData.id);
        })

        $http.post($http.api.requirement.create, this.requirement).then(ret => {
          this.$message({message: '添加需求成功', type: 'success'});
          this.goToPage(this, "mine", {});
        })
      },
      deleteAttachment(id) {
        let oldList = this.fileDataList;
        this.fileDataList = [];
        oldList.forEach(attach => {
          if (attach.id != id) {
            this.fileDataList.push(attach);
          }
        })
      }
    },
    components: {
      editor
    }
  };

</script>

<style lang="scss" scoped>
  .fileList {
    /* display:  flex;
      justify-content: space-between; */

    margin-top: 10px;
    margin-left: 36px;
    overflow: hidden;
    height: 24px;

    &:hover {
      background-color: #f1f1f1;
    }
  }

  .list {
    width: 32%;
    /* text-indent: 2em; */
    margin-top: 5px;
    cursor: pointer;
  }

  .list:nth-of-type(2),
  .list:nth-of-type(3) {
    text-align: center;

  }

  .wrap-edit {
    width: 100%;
    background-color: #fff;
    height: 100%;
  }

  .editor {
    margin-top: 10px;
  }

  .headername {
    margin-left: 240px;
    font-size: 16px;
    font-weight: 900;
  }

  .app-container {
    width: 100%;

    margin-top: 10px;
  }


  .appendix-name {
    margin-top: 4px;
    font-size: 15px;
    margin-right: 10px;
    font-weight: 900;
  }

  .left-box {
    width: calc(75% - 20px);
    margin-right: 20px;

    .Preservation {
      padding: 8px 30px;
      margin-top: 10px;
    }
  }

  .right-box {
    width: 25%;
    margin-top: 55px;
  }


  .editcc {

    margin-top: 10px;
  }

  .Enclosure {
    margin-top: 20px;
    background-color: #fff;
    width: 100%;
    overflow: hidden;
  }

  .el-upload-dragger {
    width: 976px !important;
    margin-top: 20px;
  }

  .el-icon-close {
    cursor: pointer;
  }

  .date-icon {

  }
</style>
