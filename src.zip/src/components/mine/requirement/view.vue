<template>
  <div id="demand" class="content-outer-box" style="overflow:hidden;">
    <div class="x-arD content-box">
      <div class="function-bar page-content-box-width">
        <span class="fl mt10" style="font-size: 20px;font-weight: 900;position: relative;top: -10px;">需求详情</span>
      </div>
      <div class="demand page-content-box-width" style="overflow:hidden;">
        <div class="fl left-box">
          <div class="base-info">
            <div class="base-line">
            </div>
            <div class="base-content">
              基本信息
            </div>
          </div>
          <div style="height:50px;background:#fff;">
            <span class="fl mt10" style="font-size: 15px;width: calc(100% - 140px);">
              标题:<el-input class="ml10" :disabled="titleEditDisable" v-model="requireInfo.display.title" 
              :title="requireInfo.display.title"  style="width: calc(100% - 50px);" id="requireTitle" placeholder="请输入需求标题">
              </el-input>
            </span>

            <el-button size="big" type="primary" v-if="requireInfo.display.stage===0 && editStatus==1" class="tit fr mt10"
              @click="changeEditStatusHandle()">编辑内容
            </el-button>
            <el-button v-if="editStatus==2" type="primary" class="tit fr mt10" @click="handleSaveEdit">保存</el-button>
            <el-button v-if="editStatus==2" type="info" class="tit fr mt10 mr10" @click="handleCancelEdit()">取消
            </el-button>
          </div>
          <div class="wrap-edit">
            <div class="app-container">
              <div class="editcc">
                <!-- 组件有两个属性 value 传入内容双向绑定 setting传入配置信息 -->
                <editor v-if="editStatus==2" class="editor" ref="contentEditor" v-on:editHnadle="editHnadle($event)"
                  v-model="requireInfo.display.content"></editor>
                <!-- <textarea v-else style="width:100%;height: 400px;" :value="requireInfo.display.content" disabled></textarea> -->
                <div v-else style="width:100%;min-height: 400px;border:1px solid #ccc;padding-left:5px;box-sizing: border-box;"
                  v-html="requireInfo.display.content"></div>
              </div>
            </div>
            <div class="right-box">
              <el-form label-width="80px" label-position="left" style="margin-left:40px !important;margin-right: 40px !important;">
                <div v-if="requireInfo.display.stage != 0">
                  <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mt10">
                    <el-form-item label="所属项目" class="el-form--line">
                      <span>{{requireInfo.display.projectName}}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12" class="mt10">
                    <el-form-item label="状态" class="el-form--line">
                      <span>{{requireInfo.display.status}}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
                    <el-form-item label="迭代" class="el-form--line">
                      <span>{{requireInfo.display.sprint}}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
                    <el-form-item label="处理人" class="el-form--line">
                      <span>{{requireInfo.display.assignUser}}</span>
                    </el-form-item>
                  </el-col>

                  <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">

                    <el-form-item label="开始时间" class="el-form--line">
                      <span>{{requireInfo.startTime?requireInfo.startTime:'--'}}</span>
                    </el-form-item>
                  </el-col>
                  <el-col :xs="24" :sm="24" :md="24" :lg="12" :xl="12">
                    <el-form-item label="结束时间" class="el-form--line">
                      <span>{{requireInfo.endTime?requireInfo.endTime:'--'}}</span>
                    </el-form-item>
                  </el-col>

                </div>
                <div v-else-if="requireInfo.display.stage===0">
                  <div style="margin:10px 20px;">
                    <el-radio-group v-model="assignRadio" @change="handleAssignRadioChange">
                      <el-radio :label="1">指派人</el-radio>
                      <el-radio :label="2">指派项目</el-radio>
                    </el-radio-group>
                  </div>
                  <div class="right-box1" v-show="assignRadio == 1">
                    <div style="overflow:hidden;">
                      <span class="tit fl mt10 " style="line-height: 28px;margin-left: 39px;">处理人</span>
                      <el-select placeholder="请选择需求处理人" filterable class="fl ml10 mt10 w200" v-model="team.assignUser"
                        @change="handleTeamAssignUserChange">
                        <el-option v-for="(row,index) in team.assignUserList" :key="row.userId" :label="row.userName"
                          :value="row.userId">
                          <template>
                            <span style="float: left">{{ row.userName }}</span>
                            <span style="float: right; color: #8492a6; font-size: 13px">{{ row.userId }}</span>
                          </template>
                        </el-option>
                      </el-select>
                    </div>
                    <div class="block">
                      <span class="tit fl mt10 " style="line-height: 28px;">期望完成时间</span>
                      <el-date-picker v-model="team.expectedTime" prefix-icon="clean-icon" type="date" value-format="yyyy-MM-dd"
                        class="fl ml10 mt10 w200" align="bottom" placeholder="选择日期" @change="handleTeamExpectTimeChange"></el-date-picker>
                    </div>
                  </div>
                  <div class=" right-box1" v-show="assignRadio == 2">
                    <div style="overflow:hidden;">
                      <span class="tit fl mt10 " style="line-height: 28px;margin-left: 26px;">指派项目</span>
                      <el-select placeholder="选择需求指派项目" class="fl w200 ml10 mt10" v-model="requireInfo.projectId"
                        @change="handleProjectSelectChange">
                        <el-option v-for="(row,index) in assignProjectList" :key="row.id" :label="row.name" :value="row.id"></el-option>
                      </el-select>
                    </div>
                    <div style="overflow:hidden;">
                      <span class="tit fl mt10 " style="line-height: 28px;margin-left: 39px;">处理人</span>
                      <el-select placeholder="选择需求处理人" class="fl ml10 mt10 w200" v-model="project.assignUser" @change="handleProjectAssignUserChange">
                        <el-option v-for="(row,index) in project.assignUserList" :key="row.userId" :label="row.userName"
                          :value="row.userId">
                          <span style="float: left">{{ row.userName }}</span>
                          <span style="float: right; color: #8492a6; font-size: 13px">{{ row.userId }}</span>
                        </el-option>
                      </el-select>
                    </div>
                    <div class="block">
                      <span class="tit fl mt10 " style="line-height: 28px;">期望完成时间</span>
                      <el-date-picker v-model="project.expectedTime" type="date" prefix-icon="clean-icon" value-format="yyyy-MM-dd"
                        class="fl ml10 mt10 w200" align="bottom" placeholder="选择日期" @change="handleProjectExpectTimeChange"></el-date-picker>
                    </div>
                  </div>
                </div>
              </el-form>
            </div>
            <div style="padding-bottom: 30px;">
              <div class="Enclosure" ref="enc" v-if="requireInfo.display.stage===0">
                <div class="flleName" style="margin-top: 4px;"><span class="cp fl" style="font-size:15px;font-weight:900;">附件</span>
                  <div class="fl" style="margin-left:5px;">
                    <el-upload class="upload-demo" multiple action="uploadActionUrl" v-bind:action="uploadActionUrl"
                      :data="upoladID" :on-success="handleSuccess" accept :show-file-list="false" :auto-upload="true">
                      <span size="small" type="primary" class="c-blue" style="line-height:22px;">本地上传</span>
                    </el-upload>
                  </div>
                  <div class="cp fl c-blue" style="margin-left:8px;line-height: 22px;" @click="HandleShow">拖拽上传</div>
                </div>
              </div>
              <el-table :data="fileDataList" v-if="fileDataList.length>=1">
                <el-table-column prop="origName" label="附件名称">
                </el-table-column>
                <el-table-column label="附件大小">
                  <template slot-scope="scope">
                    {{scope.row.size}}KB
                  </template>
                </el-table-column>
                <el-table-column label="上传人">
                  <template slot-scope="scope">
                    {{scope.row.display.createUser}}({{scope.row.createUser}})
                  </template>
                </el-table-column>


                <el-table-column width="120" label="操作">
                  <template slot-scope="scope">
                    <span class="c-blue cp" @click="downloadHandle(scope.row)">下载</span>
                    <span class="c-blue cp" @click="deleteAttachment(scope.row.id)">删除</span>
                  </template>
                </el-table-column>
              </el-table>

              <el-upload v-if="fileListShow" class="upload-demo" drag ref="upload" v-bind:action="uploadActionUrl"
                :data="upoladID" :on-preview="handlePreview" :on-remove="handleRemove" :on-success="handleSuccess"
                :auto-upload="true" accept=".*" :show-file-list="false">
                <i class="el-icon-upload"></i>
                <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>

              </el-upload>
            </div>
          </div>
        </div>
        <div class="fr">
          <div class="base-info">
            <div class="base-line"></div>
            <div class="base-content">时间轴</div>
          </div>
          <steps :lifeCycleList="lifeCycleList"></steps>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
  import editor from '@/components/tool/markedit'
  import steps from '@/components/tool/steps'

  export default {
    name: "editor-demo",
    data: function () {
      return {
        fileListShow: false,
        intermediateValue: '',//处理监听子组件返回的中间值
        deleteShow: false,//控制附件删除的显示
        requireId: 0,
        titleEditDisable: true,
        editTitleBackupValue: null, //编辑标题的备份数据，点击取消后 展示该值
        editStatus: 1,  //1处于只读状态，2处于可编辑状态
        editBackupValue: null, //编辑内容的备份数据，点击取消后 展示该值
        uploadActionUrl: $http.api.attachment.upload.url,
        field: {
          title: "title",
          content: "content",
          expectedTime: "expectedTime",
          assignUser: "assignUser",
          priority: "priority",
          sprintId: "sprintId",
          startTime: "startTime",
          endTime: "endTime",
          statusId: "statusId",
          projectId: "projectId"
        },
        status: 1,
        editorSetting: {
          height: 400,
        },
        fileDataList: [],
        upoladID: {
          workItemType: 1,
          workItemId: this.getUrlParams().requireId
        },
        requireInfo: {
          projectId: 888,
          title: "",
          display: {
            title: ""
          },
        },
        team: { assignUser: "", assignUserList: [], expectedTime: "" },
        project: { assignUser: "", assignUserList: [], expectedTime: "" },
        requireUpdateInfo: {
          id: 0,
        },
        assignRadio: 1,  //1,团队  2  项目
        assignTeamList: [],
        assignProjectList: [],
        lifeCycleList: [],
      }
    },
    mounted() {
      this.requireId = this.getUrlParams().requireId;

      this.getRequireInfoAndInit();
      this.getAttachmentList()
      this.getLifeCycle()
      this.getRequreReceiveUsers();
    },
    methods: {
      HandleShow() {
        this.fileListShow = !this.fileListShow;
      },
      editHnadle(data) {
        this.intermediateValue = data;

      },
      getLifeCycle() {
        let requireId = this.getUrlParams().requireId
        $http.get($http.api.requirement.life_cycle, { workItemType: 1, workItemId: requireId }).then(res => {
          this.$nextTick(function () {
            this.lifeCycleList = res.data

          })
        })
      },
      getAssignTeamList() {
        $http.get($http.api.project.assign_team_list).then(res => {
          this.assignTeamList = res.data;
        })
      },
      getAssignProjectList() {
        $http.get($http.api.project.assign_project_list).then(res => {
          this.assignProjectList = res.data;
        })
      },
      handleAssignRadioChange() {
        if (this.assignRadio == 1) {
          this.getAssignTeamList();
        } else {
          this.getAssignProjectList();
        }
      },
      handleTeamSelectChange() {
        this.assignTeamList.forEach(item => {
          if (item.id == this.requireInfo.teamId) {
            this.assignUserList = item.users;
          }
        })
      },
      getRequreReceiveUsers() {
        $http.post($http.api.project.query_assign_user, { query: null }).then(res => {
          this.team.assignUserList = res.data;
        })
      },
      handleProjectSelectChange() {
        if (this.project.assignUser) {
          this.updateRequire(this.field.projectId, this.requireInfo.projectId);
        }
        this.assignProjectList.forEach(item => {
          if (item.id == this.requireInfo.projectId) {
            this.project.assignUserList = item.users;
          }
        })
      },
      handleProjectAssignUserChange() {
        this.requireUpdateInfo = {};
        this.requireUpdateInfo.id = this.requireId;
        this.requireUpdateInfo.projectId = this.requireInfo.projectId;
        this.requireUpdateInfo.assignUser = this.project.assignUser;
        this.requireUpdateInfo.expectedTime = this.project.expectedTime;

        $http.post($http.api.requirement.update, this.requireUpdateInfo).then(res => {
          this.$message({ message: '修改需求成功', type: 'success' });
        })
      },
      handleProjectExpectTimeChange() {
        if (this.project.assignUser) {
          this.updateRequire(this.field.expectedTime, this.project.expectedTime);
        }
      },
      handleTeamAssignUserChange() {
        this.requireUpdateInfo = {};
        this.requireUpdateInfo.id = this.requireId;
        this.requireUpdateInfo.projectId = 0;
        this.requireUpdateInfo.assignUser = this.team.assignUser;
        this.requireUpdateInfo.expectedTime = this.team.expectedTime;

        $http.post($http.api.requirement.update, this.requireUpdateInfo).then(res => {
          this.$message({ message: '修改需求成功', type: 'success' });
        })
      },
      handleTeamExpectTimeChange() {
        if (this.team.assignUser) {
          this.updateRequire(this.field.expectedTime, this.team.expectedTime);
        }
      },
      // 更改为编辑状态
      changeEditStatusHandle() {
        this.editTitleBackupValue = this.requireInfo.display.title;
        this.titleEditDisable = !this.titleEditDisable;
        this.editStatus = 2;
      },
      handleCancelEdit() {
        this.titleEditDisable = !this.titleEditDisable;
        this.editStatus = 1;

        this.requireInfo.display.title = this.editTitleBackupValue;
      },
      handleSaveEdit() {
        this.requireInfo.display.content = this.intermediateValue;
        this.editStatus = 1;
        this.titleEditDisable = !this.titleEditDisable;

        this.requireUpdateInfo = {};
        this.requireUpdateInfo.id = this.requireId;
        this.requireUpdateInfo.title = this.requireInfo.display.title;
        this.requireUpdateInfo.content = this.intermediateValue;
        $http.post($http.api.requirement.update, this.requireUpdateInfo).then(res => {
          this.$message({ message: '修改需求成功', type: 'success' });
        })
      },
      downloadHandle(row) {
        window.location.href = row.url;
      },
      getRequireInfoAndInit() {
        $http.get($http.api.requirement.seeDemand, { id: this.requireId }).then((res) => {  //todo cpp 这里应该获取自己的queryType=1
          this.requireInfo = res.data;
          this.requireInfo.teamId = null;

          if (this.requireInfo.display.stage == 0) { //评审阶段
            if (this.requireInfo.projectId > 0) {  //指派的是项目
              this.assignRadio = 2;
              this.project.assignUser = res.data.assignUser;
              this.project.expectedTime = res.data.expectedTime;

              $http.get($http.api.project.assign_project_list).then(res => {
                this.assignProjectList = res.data;

                this.assignProjectList.forEach(item => {
                  if (item.id == this.requireInfo.projectId) {
                    this.project.assignUserList = item.users;

                  }
                })
              })
            } else {

              this.requireInfo.projectId = null;
              this.assignRadio = 1;
              this.team.assignUser = res.data.assignUser;
              this.team.expectedTime = res.data.expectedTime;

            }
          }

          // this.$nextTick(() => {
          //   document.getElementById("requireContentTextarea").innerHTML = this.requireInfo.display.content
          // })
        })
      },
      getAttachmentList() {
        $http.post($http.api.mine.attachmentsList,
          {
            workItemType: 1,
            workItemId: this.requireId
          }).then(res => {
            this.fileDataList = res.data;
          })
      },
      Handleenter(row) {
        this.deleteShow = row.id;
      },
      Handleleave() {
        this.deleteShow = false;
      },
      downloadHandle(row) {
        window.location.href = row.url;
      },
      submitUpload() {
        this.$refs.upload.submit();
      },
      handleRemove(file, fileList) {

      },
      handlePreview(file) {

      },
      handleSuccess(res) {
        this.fileDataList.push(res.data)
      },
      updateRequire(field, value) {
        this.requireUpdateInfo = {};
        this.requireUpdateInfo.id = this.requireId;

        if (field == this.field.content) {
          this.requireUpdateInfo.content = value;
        } else if (field == this.field.title) {
          this.requireUpdateInfo.title = value;
        } else if (field == this.field.expectedTime) {
          this.requireUpdateInfo.expectedTime = value;
        } else if (field == this.field.statusId) {
          this.requireUpdateInfo.statusId = value;
        } else if (field == this.field.startTime) {
          this.requireUpdateInfo.startTime = value;
        } else if (field == this.field.priority) {
          this.requireUpdateInfo.priority = value;
        } else if (field == this.field.sprintId) {
          this.requireUpdateInfo.sprintId = value;
        } else if (field == this.field.endTime) {
          this.requireUpdateInfo.endTime = value;
        } else if (field == this.field.assignUser) {
          this.requireUpdateInfo.assignUser = value;
        } else if (field == this.field.projectId) {
          this.requireUpdateInfo.projectId = value;
        }

        $http.post($http.api.requirement.update, this.requireUpdateInfo).then(res => {
          this.$message({ message: '修改需求成功', type: 'success' });
        })
      },
      deleteAttachment(id) {
        this.$confirm('此操作将删除该文件, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.attachment.delete, {
            attachmentId: id,
            workItemType: 1,
            workItemId: this.requireId
          }).then(ret => {
            if (ret.status == 200) {
              let oldList = this.fileDataList;
              this.fileDataList = [];
              oldList.forEach(attach => {
                if (attach.id != id) {
                  this.fileDataList.push(attach);
                }
              })
            }
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });


      },
    },
    components: {
      'editor': editor,
      steps
    }
    // props: ['requireId','projectId'],


  };

</script>

<style lang="scss" scoped>
  .base-info {
    padding: 10px 0;
  }

  .base-line {
    background-color: rgba(0, 153, 255, 1);
    height: 20px;
    width: 3px;
    display: inline-block;
  }

  .base-content {
    color: #333;
    font-size: 16px;
    display: inline-block;
    position: relative;
    top: -4px;
    font-weight: 900;
    /* margin: 0;
    padding: 0; */
  }

  .fileList {
    margin-top: 10px;
    margin-left: 20px;
    height: 24px;

    &:hover {
      background-color: #f1f1f1;
    }
  }

  .list {
    width: 32%;
    margin-top: 5px;
    cursor: pointer;
  }

  .w200 {
    width: 200px;
  }

  .list:nth-of-type(2),
  .list:nth-of-type(3) {
    text-align: center;

  }

  .wrap-edit {
    width: 100%;
    background-color: #fff;
    height: 100%;
    overflow: hidden;
    /*加了一个overlow*/
  }

  .editor {
    margin-top: 10px;
    min-height: 400px;
  }

  .app-container {
    width: 100%;
    margin-top: 10px;
  }

  .headername {
    margin-left: 254px;
    font-size: 16px;
    line-height: 40px;
    font-weight: 900;
  }

  .block {
    overflow: hidden;
  }

  .left-box {
    width: calc(100% - 600px);
    min-width: 400px;

    .Preservation {
      padding: 8px 30px;
      margin-top: 100px;
    }
  }

  .right-box {
    overflow: hidden;
    background-color: #f9f9f9;
    width: 100%;
    /* margin-top: 59px; */
    padding-bottom: 13px;
    margin-top: 20px;
    margin-bottom: 20px;
    /* min-height: 390px; */
    /* margin-left: 20px; */
  }

  .editcc {
    margin-top: 10px;
  }

  .right-box1 {
    margin-left: 20px;
    margin-top: 30px;
  }

  .Enclosure {
    margin-top: 10px;
    /* margin-left: 19px; */
    background-color: #fff;
    width: 100%;
    overflow: hidden;

  }

  .ml20 {
    margin-left: 20px;
  }

  .el-upload-dragger {
    width: 976px !important;
    margin-top: 20px;
  }

  .el-icon-close,
  .el-icon-download {
    cursor: pointer;
  }

  .el-icon-download {
    margin-right: 5px;
  }

  .appendix-name {
    margin-top: 4px;
    font-size: 15px;
    margin-right: 10px;
  }

  textarea[disabled] {
    background-color: #fff !important;
    border: 1px solid #ccc;
  }

  .el-form--line {
    margin-bottom: 0 !important;
    padding-left: 40px !important;
    color: #909399;
  }

  .el-form--line:hover {
    background: #e4e7ed;
  }
</style>