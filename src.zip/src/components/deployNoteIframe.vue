<template>
  <div id="deployNoteIframe">
    <div
      style="border:1px solid #e4e7ed;width:300px;height:93vh;display:inline-block;vertical-align: top;background: #545c64;overflow: auto">
      <el-menu
        style="height: 100%"
        default-active="0_0_0"
        @select="menuSelect"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b">
        <el-submenu :index="''+index1+'_'" :key="''+index1+'_'" v-for="(level1,index1) in deployNoteForm.data"
                    class="deploy_item_1">
          <template slot="title">
            <span
              style="font-size: 16px;">{{!deployNoteForm.isAppView?getZoneNameByCode(level1.label):level1.label}}</span>
          </template>

          <el-submenu :index="index1+'_'+index2" :key="index1+'_'+index2" class="deploy_item_2"
                      v-for="(level2,index2) in level1.children">
            <template slot="title">
              <span style="font-size: 14px;">
                    {{deployNoteForm.isAppView?getZoneNameByCode(level2.label):level2.label}}
                  </span>
            </template>

            <el-menu-item :index="index1+'_'+index2+'_'+index3" :key="index1+'_'+index2+'_'+index3" class="deploy_item_3"
                          v-for="(level3,index3) in level2.children">
              <template slot="title">
                <p style="font-size: 12px;word-break: break-all;white-space:normal;line-height: 20px;padding-right: 3px">
                  {{getVersionDisplayStr(index1,index2,index3)}}</p>
              </template>
            </el-menu-item>
          </el-submenu>
        </el-submenu>
      </el-menu>
    </div>
    <form style="display: none" target="passDeployIFrame" v-bind:action="passDeployUrl" id="passHideForm"
          method="post">
      <input id="appId" name="appId" v-model="passForm.appId">
      <input id="packageSrc" name="packageSrc" v-model="passForm.packageSrc">
      <input name="md5" id="md5" v-model="passForm.md5">
      <input name="version" id="version" v-model="passForm.version">
      <input name="versionDesc" id="versionDesc" v-model="passForm.versionDesc">
      <input name="deployInfo" id="deployInfo" v-model="passForm.deployInfo">
      <input name="ts" id="time" v-model="passForm.ts">
      <input name="app_sign" id="app_sign" v-model="passForm.app_sign">
      <input name="uid" id="uid" v-model="passForm.uid">
      <input name="app_key" id="app_key" v-model="passForm.app_key">
      <input name="cpid" id="cpid" v-model="passForm.cpid">
      <input name="cmdbId" id="cmdbId" v-model="passForm.cmdbId">
      <input name="configCenterAppId" id="configCenterAppId" v-model="passForm.configCenterAppId">
      <input name="incrPublish" id="incrPublish" v-model="passForm.incrPublish">
    </form>

    <div style="width:calc(100% - 315px);display:inline-block;vertical-align: top;min-height: 400px;">
      <iframe :src="passIframeUrl" style="width:100%;height: 90vh;border:none" id="passDeployIFrame"
              name="passDeployIFrame"></iframe>
    </div>
  </div>
</template>

<script>
  export default {
    name: "deployNoteIframe",
    data() {
      return {
        now:'',
        userId:'',
        zoneList: [],
        deployNoteId: null,
        passForm: {},
        passDeployUrl: '',
        passIframeUrl: '',
        deployNoteForm: { //发布弹窗
          data: [],
          isAppView: true,
        },
      };
    },


    mounted() {
      this.deployNoteId = this.getUrlParams().deployNoteId;
      this.bizId = this.getUrlBizId();
      this.getLoginUserInfo();
      this.getZoneList();
    },

    methods: {
      async getLoginUserInfo() {//获取当前登陆用户信息
        await $http.get($http.api.user.getLoginUserInfo).then((res) => {
          this.userId = res.data.systemUser.userId;
        })
      },
      getVersionDisplayStr(index1, index2, index3) {
        let item = this.deployNoteForm.data[index1].children[index2].children[index3].item;
        if (item.configEnv && item.configEnv != '' && item.configVersion && item.configVersion != '') {
          return item.version + '[' + item.configEnv + ':' + item.configVersion + ']';
        } else {
          return item.version;
        }
      },
      getZoneList() {
        $http.get($http.api.app.getZoneList, {env: 'online'}).then(res => {
          this.zoneList = res.data;
          this.getDeployNoteDetail();
        }).catch((e) => {
          this.$message({
            message: '获取机房失败',
            type: 'error'
          });
          return true;
        });
      },

      getZoneNameByCode(zoneCode) {
        let zoneName = zoneCode;
        this.zoneList.forEach(zone => {
          if (zone.code == zoneCode) {
            zoneName = zone.name;
          }
        })
        return zoneName;
      },

      getDeployNoteDetail() {
        // if (!this.canDeploy(deployNote)) {
        //   this.$message({
        //     message: '未到设定的发布时间',
        //     type: 'warning'
        //   });
        //   return;
        // }
        this.passIframeUrl = '';
        this.deployNoteForm = {
          data: [],
          isAppView: true,
        };
        $http.get($http.api.deploy_note.getDeployNoteDetail, {deployNoteId: this.deployNoteId}).then(res => {
          let detail = res.data;
          this.deployNoteForm.isAppView = detail.deployNoteView == 0;
          this.deployNoteForm.bizId = detail.bizId;
          detail.deployAppModules = JSON.parse(detail.deployNoteResult).deployAppModules;
          this.deployNoteForm.data = this.assembleTreeData(detail.deployAppModules, this.deployNoteForm.isAppView);
          this.menuSelect('0_0_0');
        });
      },

      assembleTreeData(deployAppModules, isAppView) {//组装树形数据
        let list = this.transferDataToList(deployAppModules);
        let key1Name = isAppView ? 'appCode' : 'zone';
        let key2Name = isAppView ? 'zone' : 'appCode';
        let map = new Map();//key1,key2,list
        list.forEach(item => {
          let val1 = item[key1Name];
          let val2 = item[key2Name];

          if (!map.has(val1)) {
            let map2 = new Map();
            map2.set(val2, [item])
            map.set(val1, map2);
            return;
          }

          let map2 = map.get(val1);
          if (!map2.has(val2)) {
            map2.set(val2, [item])
          } else {
            map2.get(val2).push(item);
          }
        })

        let data = [];
        map.forEach((map2, label1) => {
          let item1 = {label: label1, children: []};
          data.push(item1);
          map2.forEach((itemList, label2) => {
            let item2 = {label: label2, children: []};
            item1.children.push(item2);
            itemList.forEach(item => {
              item2.children.push({label: item.version, item: item});
            })
          })
        });
        return data;
      },

      transferDataToList(deployAppModules) { //把数据转换为列表结构
        let list = [];
        deployAppModules.forEach(module => {
          if (module.deployInfo && module.deployInfo.length != 0) {
            module.deployInfo.forEach(zone => {
              let zoneName = "";
              if (this.zoneList) {
                this.zoneList.forEach(item => {
                  if (item.code == zone.zone) {
                    zoneName = item.name;
                  }
                })
              }

              list.push({
                zone: zone.zone,
                zoneName: zoneName,
                configEnv: zone.configEnv,
                configVersion: zone.configVersion,
                appId: module.appId,
                appCode: module.appCode,
                appName: module.appName,
                updateDesc: module.updateDesc,
                version: module.version,
                versionDesc: module.versionDesc,
                versionId: module.versionId,
                deployOrder: module.deployOrder,
                cmdbPath: module.cmdbPath,
                deployInfo: module.deployInfo,
                repoUrl: module.repoUrl,
                MD5: module.MD5,
              });
            })
          }
        });
        return list;
      },

      menuSelect(key, keyPath) {
        let paths = key.split("_");
        if (paths.length === 3) {
          this.onDeployVersionClick(this.deployNoteForm.data[parseInt(paths[0])].children[parseInt(paths[1])].children[parseInt(paths[2])]);
        }
      },

      onDeployVersionClick(itemSelect) {
        if (itemSelect.item) {//叶子节点被点击了
          this.getServerTime();
          let item = itemSelect.item;
          this.passDeployUrl = '';
          this.passForm = {};
          this.passForm.appId = item.appCode;
          this.passForm.version = item.version;
          this.passForm.packageSrc = item.repoUrl;
          this.passForm.md5 = item.MD5;
          this.passForm.deployInfo = JSON.stringify(item.deployInfo);
          this.passForm.ts = this.now;
          this.passForm.app_key = "columbus";
          this.passForm.cpid = this.deployNoteForm.bizId;
          this.passForm.uid = this.userId;
          this.passForm.cmdbId = item.cmdbId;
          this.passForm.versionDesc = encodeURIComponent(item.versionDesc);

          $http.get($http.api.creat_yy.apiapplicationgetappinfo, {appId: item.appId}).then(res => {
            this.passForm.configCenterAppId = res.data.applicationBasicInfoForm.configCenter;
            this.passForm.incrPublish = res.data.applicationDeployConfig.incr;
            $http.get($http.api.deploy_note.generateSign, this.passForm).then(res => {
              this.$set(this.passForm, 'app_sign', res.data);
              this.passForm.app_sign = res.data;
              this.passForm.app_sign = res.data;
              $http.post($http.api.deploy_note.getPaasServerUrl, {env: "online"}, {type: 'form'}).then(res => {
                this.passDeployUrl = res.data + '/appmanage/instance/columbus';
                let iframeForm = document.getElementById("passHideForm");
                iframeForm.setAttribute("action", this.passDeployUrl);
                iframeForm.submit();
              })
            })
          })
        }
      },
      async getServerTime() {//获取服务器时间
        this.now = new Date().getTime();
        await $http.get($http.api.system.get_server_time).then((res) => {
          this.now = res.data.timestamp;
        });
      },
    }
  };
</script>

<style lang="scss">

  .deploy_item_1 > .el-submenu__title {
    height: 40px;
    line-height: 40px;
    padding-left: 10px !important;
  }

  .deploy_item_2 > .el-submenu__title {
    height: 40px;
    line-height: 40px;
    padding-left: 20px !important;
  }

  .deploy_item_3 {
    min-height: 40px;
    display: flex !important;
    align-items: center !important;
    height: auto !important;
    padding-right: 0 !important;
    padding-left: 30px !important;
  }

  .deploy_item_3 > p {
    word-break: break-all !important;
    margin: auto 0 !important;
    vertical-align: center !important;
  }

</style>
