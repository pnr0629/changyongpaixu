<template>
  <div>apiList</div>
</template>
<script>
/**
 * @title 
 * @desc 
 * @author dengpan
 * @date 
 */
export default {
  name: "",
  components: {},
  mixins: [],
  props: {},
  data() {
    return {}
  },
  computed: {},
  watch: {},
  created() {},
  methods: {}
}
</script>
<style lang="scss" scoped>

</style>
