<template>
  <div id="bizInstanceTagTemplateList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
            <div class="table-box" v-if="showBtn == '0'">
              <div class="createBtn">
                <el-button type="success" class="mb10" @click="createBizInstanceTag()">创建实例标签模板</el-button>
              </div>
              <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                <div class="table-box-top-bs">
                  <el-table :data="bulidingList_a" style="width:100%;height:100%;overflow:auto;">
                    <el-table-column type="index" label="序号" min-width="50">
                    </el-table-column>
                    <el-table-column prop="templateName" label="模板名称" min-width="180">
                    </el-table-column>
                    <el-table-column prop="createUserId" label="创建人" min-width="180">
                    </el-table-column>
                    <el-table-column prop="createTime" label="创建时间" min-width="180">
                    </el-table-column>
                    <el-table-column prop="modifyTime" label="更新时间" min-width="180">
                    </el-table-column>
                    <el-table-column prop="time" label="操作" width="120">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="editBizInstanceTag(scope.row)">编辑</span>
                        <span class="c-blue cp" @click="deleteBizInstanceTag(scope.row)">删除</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>

            <div class="table-box deployinfoclass" v-if="showBtn == '1'">
              <div>
                <span style="font-size: 18px;font-weight: 600;" class="ml40" v-if="btnshow == 'edit'">编辑实例标签模板</span>
                <span style="font-size: 18px;font-weight: 600;" class="ml40" v-if="btnshow == 'keep'">创建实例标签模板</span>
                <span class="ml10 c-blue cp" @click="handleClose_bs()">&lt;&lt;返回</span>
              </div>
              <el-form :model="bizInstanceTagInfo" ref="bizInstanceTagInfoForm" label-width="120px" style="height:50%;">
                <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="模板名称" label-width="120px" prop="templateName" :rules="[
                                            { required: true, message: '模板名称不能为空', trigger: 'blur' }
                                        ]">
                      <el-input placeholder="请输入模板名称" v-model="bizInstanceTagInfo.templateName"
                                style='width:500px;'></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>


                <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="实例标签" label-width="120px" required>
                      <span @click="addTag()" class="c-blue cp"><i class="el-icon-plus"></i>添加标签</span>
                    </el-form-item>
                  </el-col>
                </el-row>

              </el-form>


              <el-col :span="24" v-for="(item,index) in bizInstanceTagInfo.tagCodes" :key="index" class="tag_list">
                <el-form>
                  <el-form-item class=”mb15“ label-width="120px">
                    <el-input placeholder="请输入内容" style="margin-left: 5px" v-model="bizInstanceTagInfo.tagCodes[index]" clearable
                              class="width-input-select"></el-input>
                    <span class="c-red cp" @click="delTag(index)">删除</span>
                  </el-form-item>
                </el-form>
              </el-col>
              <div class="foot" style="height:10%;text-align: center;">
                <el-button type="primary" class="mt20 mb20" @click="updateBtn()" style="margin-right:20px;"
                           v-if="btnshow == 'edit'">保存
                </el-button>
                <el-button type="primary" class="mt20 mb20" @click="keepBtn()" style="margin-right:20px;"
                           v-if="btnshow == 'keep'">保存
                </el-button>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>


  </div>
</template>

<script>
  // import Distpicker from 'v-distpicker'
  export default {
    name: "bizInstanceTagSetting",
    data() {
      return {
        showBtn: "0",
        table_loading: false,
        dialogVisible_zj: false,
        modaltobody: false,
        shadeBtn: false,
        dialogVisible_sl: false,
        activeName: "first",
        bizInstanceTagInfo: {
          templateId: '',
          templateName: '',
          userId: '',
          tagCodes: []
        },
        bulidingList_a: [],
        currentUser: {},
        btnshow: '',
        templateId: '',
        bizId: ''
      };
    },

    mounted() {
      this.initParamAndPage();
    },

    methods: {


      getRef(row) {
        return 'multipleTable' + row.$index;
      },


      initParamAndPage() {
        let urlParams = this.getUrlParams();
        this.bizId = urlParams.bizId;
        this.getLoginUserInfo();
        this.getBizInstanceTags();
      },

      getLoginUserInfo() {//获取当前登陆用户信息
        $http.get($http.api.user.getLoginUserInfo).then((res) => {
          if (res.status != 200) {
            this.$message({
              message: "获取当前登录用户信息失败",
              type: "warning"
            });
          } else {
            this.currentUser = res.data.systemUser;
          }
        })
      },

      //查询标签模板列表
      getBizInstanceTags() {
        this.bulidingList_a = [];
        var params = {bizId: this.bizId}
        $http.get($http.api.biz.get_biz_instance_tag_list, params).then(res => {
          if (res.status == 200) {
            this.bulidingList_a = res.data;
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }

        });
      },

      //删除
      deleteBizInstanceTag(val) {
        this.$confirm('确定要删除标签模板' + val.templateName + '吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.get($http.api.biz.del_biz_instance_tag, {
            templateId: val.templateId
          }).then(res => {
            if (res.status != 200) {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            } else {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.getBizInstanceTags();
            }
          });
        }).catch(() => {
        });
      },


      //编辑列表
      editBizInstanceTag(val) {
        let params = {
          templateId: val.templateId
        }
        $http.get($http.api.biz.get_biz_instance_tag_info, params).then(res => {
          if (res.status == 200) {
            this.showBtn = "1";
            this.btnshow = 'edit';
            this.templateId = res.data.templateId;
            //标签列表
            this.bizInstanceTagInfo = res.data;

          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      //创建标签模板
      createBizInstanceTag() {
        this.bizInstanceTagInfo = {
          templateName: '',
          tagCodes:[]
        };
        this.showBtn = "1";
        this.btnshow = 'keep';
      },


      //添加标签
      addTag() {
        this.bizInstanceTagInfo.tagCodes.push("");
      },

      delTag(index) {
        this.bizInstanceTagInfo.tagCodes.splice(index, 1);
      },


      //创建实例标签模板
      keepBtn() {
        if (!this.checkData()) {
          return;
        }
        this.$refs['bizInstanceTagInfoForm'].validate(() => {
          let params = {
            bizId: this.bizId,
            templateName: this.bizInstanceTagInfo.templateName,
            tagCodes: new Set(this.bizInstanceTagInfo.tagCodes),
            userId: this.currentUser.userId
          };
          $http.post($http.api.biz.add_biz_instance_tag, params).then(res => {
            if (res.status == 200) {
              this.$message({
                message: "保存成功",
                type: "success"
              });
              this.getBizInstanceTags();
              this.showBtn = "0";
            } else {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            }
          });
        });
      },


      //更新按钮
      updateBtn() {
        if (!this.checkData()) {
          return;
        }

        this.$refs['bizInstanceTagInfoForm'].validate(() => {
          let params = {
            templateId: this.templateId,
            bizId: this.bizId,
            templateName: this.bizInstanceTagInfo.templateName,
            userId: this.currentUser.userId,
            tagCodes: new Set(this.bizInstanceTagInfo.tagCodes)
          };
          $http.post($http.api.biz.edit_biz_instance_tag, params).then(res => {
            if (res.status == 200) {
              this.$message({
                message: "更新成功",
                type: "success"
              });
              this.getBizInstanceTags();
              this.showBtn = "0";
            } else {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            }

          });
        });
      },

      checkData(){
        if(this.bizInstanceTagInfo.templateName.trim() === ""){
          this.$message({
            message: "模板名称不允许为空！",
            type: "warning"
          });
          return false;
        }
        if (this.bizInstanceTagInfo.tagCodes.length === 0) {
          this.$message({
            message: "标签列表不允许为空！",
            type: "warning"
          });
          return false;
        }

        for(var item of this.bizInstanceTagInfo.tagCodes){
          if (item.trim() === "") {
            this.$message({
              message: "标签值不允许为空！",
              type: "warning"
            });
            return false;
          }
          var reg = /^(\w){1,64}$/;
          if(!reg.test(item.trim())){
            this.$message({
              message: "标签值只能是1-64个字母、数字、下划线！",
              type: "warning"
            });
            return false;
          }

        }

        if (this.bizInstanceTagInfo.tagCodes.length !== (new Set(this.bizInstanceTagInfo.tagCodes).size)) {
          this.$message({
            message: "添加的标签值不允许有重复",
            type: "warning"
          });
          return false;
        }

        return true;

      },
      //返回模板列表页面
      handleClose_bs() {
        this.getBizInstanceTags();
        this.showBtn = "0";
        this.bizInstanceTagInfo.tagCodes = [];
      },

    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  .el-form-item--mini{
    margin-bottom: 6px !important;
  }
</style>
