<template>
  <div id="bizInfoSetting" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="function-bar" style="border-bottom:none;height:40px;">
          <span style="float:left;margin-top:5px;font-size:16px;color:#606266"><b>回调地址设置</b></span>
          <el-button type="success" class="ml10 mt15 fr" v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)" @click="showAddCallbackDialog">添加机房回调地址</el-button>
        </div>
        <el-table :data="callbackList">
          <el-table-column label="机房名称" min-width="120" prop="zoneName"></el-table-column>
          <el-table-column label="回调地址" min-width="120" prop="deployCallback"></el-table-column>
          <el-table-column label="操作" v-if="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)" min-width="120">
            <template slot-scope="scope">
              <span @click="showUpdateCallbackDialog(scope.row)" v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)" class="c-blue cp">编辑</span>
              <span @click="showDeleteCallBackDialog(scope.row)" v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)" class="c-blue cp">删除</span>
            </template>
          </el-table-column>
        </el-table>

        <el-dialog
          :title="isCallbackInsert?'新增回调地址':'修改回调地址'"
          :visible.sync="callbackDialogVisible "
         class="el-dialog-350w"
          :before-close="closeAddCallbackDialog">
          <div class="form-iterm-box">
             <el-form  ref="popCallbackForm" :model="popCallback">
              <el-form-item label="机房" prop="zoneCode"
                            ref="zoneItem"
                            v-if="isCallbackInsert">
                <el-select v-model="popCallback.zoneCode" placeholder="请选择"
                          style="width:100%">
                  <el-option v-for="item in filterTotalZoneList" :key="item.code" :label="item.name"
                            :value="item.code"></el-option>
                </el-select>
              </el-form-item>

              <el-form-item v-if="!isCallbackInsert">
                <el-input v-model="popCallback.zoneName" v-if="!isCallbackInsert" disabled></el-input>
              </el-form-item>

              <el-form-item ref="deployCallbackItem" label="回调地址" prop="deployCallback"
                            :rules="[{ required: true, message: '请输入回调地址',trigger: 'blur' }]">
                <el-input v-model="popCallback.deployCallback"></el-input>
              </el-form-item>
          </el-form>
          <span slot="footer">
            <el-button  class="fr  ml10" type="primary" @click="saveOrUpdateCallback">保存</el-button>
            <el-button class="fr" @click="closeAddCallbackDialog">关闭</el-button>
          </span>
          </div>
        </el-dialog>


        <div class="function-bar" style="margin-top: 16px">
          <span style="float:left;margin-top:5px;margin-right:10px;font-size:16px;color:#606266"><b>发布单模板设置</b></span>
        </div>
        <div class="mt5 ml5 mb10" v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)">
          <el-tooltip class="item" placement="top-start">
            <div slot="content">发布单发布完成后，可触发特性分支应用下的release分支执行合并代码及删除分支等操作</div>
            <span>发布完成后合并代码：</span>
          </el-tooltip>
          <el-switch
            v-model="deployFinishedMergeCode"
            active-color="#13ce66"
            inactive-color="#ff4949"
            @change="updateDeployDescTemp"
          >
          </el-switch>
        </div>
        <el-form label-width="100px" label-position="top">
          <el-form-item style="width: 800px">
            <el-input type="textarea" :rows="20" v-model="deployDescTemp" placeholder="设置发布单模板"></el-input>
          </el-form-item>
        </el-form>
        <div style="width: 800px">
          <el-button type="primary" style="float: right" v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)" @click="updateDeployDescTemp">保存</el-button>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
  export default {
    name: "bizInfoSetting",
    data() {
      return {
        callbackDialogVisible: false,
        isCallbackInsert: true,
        popCallback: {
          deployCallback:"",
          zoneName:"",
          zoneCode:""
        },
        editCallBack: {},
        totalZoneList: [],
        filterTotalZoneList: [],
        callbackList: [],
        deployDescTemp: '',
        deployFinishedMergeCode: false,
        bizId: null
      };
    },

    mounted() {
      this.bizId = this.$route.query.bizId;
      this.tabChanged();
    },

    methods: {
      resetvalidate(formName){
        if(this.$refs[formName]!==undefined){
          //this.$refs[formName].resetFields();//如果只是清除表单验证用
          this.popCallback.deployCallback="";
          this.$refs[formName].clearValidate();
        }
      },

      getZoneList() {
        $http.get($http.api.app.getZoneList, {env: 'online'}).then(res => {
          this.totalZoneList = res.data;
          this.doZoneFilter();
        }).catch((e) => {
          this.$message({
            message: '获取机房失败',
            type: 'error'
          });
        });
      },
      showAddCallbackDialog() {
        this.popCallback.deployCallback="" ;
        this.popCallback.zoneCode="" ;
        this.popCallback.zoneName="" ;
        this.isCallbackInsert = true;
        this.callbackDialogVisible = true;
        this.getZoneList();
      },
      deleteCallback(item) {
        $http.post($http.api.biz.deleteBizDeployCallback, {bizId: item.bizId, zoneCode: item.zoneCode}).then(res => {
          this.callbackList = res.data;
        }).then((res) => {
          this.getBizDeployCallbacks();
          this.$message({
            message: '删除回调地址成功',
            type: 'success'
          });
        }).catch(() => {
          this.$message({
            message: '删除回调地址失败',
            type: 'error'
          });
        });
      },
      showDeleteCallBackDialog(item) {
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          this.deleteCallback(item);
        }).catch(() => {
        });
      },
      showUpdateCallbackDialog(item) {
        this.isCallbackInsert = false;
        this.editCallBack = item;
        this.popCallback.zoneName = item.zoneName;
        this.popCallback.zoneCode = item.zoneCode;
        this.popCallback.deployCallback = item.deployCallback;
        this.callbackDialogVisible = true;
      },
      closeAddCallbackDialog() {
        this.resetvalidate("deployCallbackItem");
        this.callbackDialogVisible = false;
      },
      handleChange() {
      },
      saveOrUpdateCallback() {
        this.$refs['popCallbackForm'].validate(validate => {
          if (validate) {
            let params = {
              bizId: this.bizId,
              deployCallback: this.popCallback.deployCallback,
            };
            if (this.isCallbackInsert) {
              if (!this.popCallback.zoneCode){
                this.$message({
                  message: '机房不能为空',
                  type: 'warning'
                });
                return;
              }
              this.totalZoneList.forEach(value => {
                if (value.code === this.popCallback.zoneCode) {
                  params.zoneCode = value.code;
                  params.zoneName = value.name;
                }
              });
            } else {
              params.zoneCode = this.editCallBack.zoneCode;
              params.zoneName = this.editCallBack.zoneName;
            }

            this.closeAddCallbackDialog();
            let isInsert = this.isCallbackInsert;
            $http.post($http.api.biz.updateBizDeployCallback, params).then(res => {
              this.getBizDeployCallbacks();
              this.$message({
                message: isInsert ? '新增回调地址成功' : '修改回调地址成功',
                type: 'success'
              });
            }).catch(() => {
              this.$message({
                message: isInsert ? '新增回调地址失败' : '修改回调地址失败',
                type: 'error'
              });
            });
          }
        });

      },
      doZoneFilter() {
        this.filterTotalZoneList = [];
        this.totalZoneList.forEach(zoneItem => {
          let contains = false;
          this.callbackList.forEach(callbackItem => {
            if (zoneItem.code === callbackItem.zoneCode) {
              contains = true;
            }
          })
          if (!contains) {
            this.filterTotalZoneList.push(zoneItem);
          }
        })
      },
      getBizDeployCallbacks() {
        $http.get($http.api.biz.getBizDeployCallbacks, {bizId: this.bizId}).then(res => {
          this.callbackList = res.data;
          this.doZoneFilter();
        }).catch(() => {
          this.$message({
            message: '获取回调地址设置失败',
            type: 'error'
          });
        });
      },
      getDeployDescTemp() {
        $http.get($http.api.biz.getDeployDescTemp, {bizId: this.bizId}).then(res => {
          this.deployDescTemp = res.data.deployDescTemp;
          this.deployFinishedMergeCode = res.data.deployFinishedMergeCode;
        }).catch(() => {
          this.$message({
            message: '获取发布单模板失败',
            type: 'error'
          });
        });
      },
      updateDeployDescTemp() {
        $http.post($http.api.biz.updateDeployDescTemp, {
          bizId: this.bizId,
          deployDescTemp: this.deployDescTemp,
          deployFinishedMergeCode: this.deployFinishedMergeCode,
        }).then(res => {
          this.$message({
            message: '保存成功',
            type: 'success'
          });
          this.getDeployDescTemp();
        }).catch(() => {
          this.$message({
            message: '保存失败',
            type: 'error'
          });
        });
      },
      tabChanged() {
        this.getBizDeployCallbacks();
        this.getDeployDescTemp();
      }

    }

  };
</script>
