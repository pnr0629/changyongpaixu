<template>
  <div id="bizList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="white-box-left">
          <el-input v-model="search"
                    class="fr mt5 mr5 white-box-left-search"
                    placeholder="请输入应用ID搜索"
                    @input="getAppListByKeyWord()"></el-input>
          <el-tabs>
            <el-tab-pane label="应用列表">
              <div class="table-box-top">
                <div class="table-box">
                  <el-table :data="appData.list"
                            border
                            :class="{'el-table-left-none':appData.list.length == 0}">
                    <el-table-column prop="appCode" label="应用ID" min-width="100">
                      <template slot-scope="scope">
                        <i v-if="!scope.row.collected" class="el-icon-star-off c-blue cp" @click="changeAppCollection(scope.row.appId)" title="点击星标收藏应用"/>
                        <i v-if="scope.row.collected" class="el-icon-star-on c-blue cp" @click="changeAppCollection(scope.row.appId)" title="点击星标取消收藏应用"/>
                        <span class="c-blue cp" @click="toApp(scope.row)" title="点击星标收藏应用">{{scope.row.appCode}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="bizName" label="所属业务" min-width="100">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="toBiz(scope.row)">{{scope.row.bizName}}</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="table_b_f_b">
                  <el-pagination
                    class="fr white-box-left-pagination"
                    @size-change="handleAppSizeChange"
                    @current-change="handleAppPageChange"
                    :current-page="appData.pageNum"
                    :pager-count="5"
                    :page-sizes="[10, 20, 30]"
                    :page-size="appData.pageSize"
                    layout="total, prev, pager, next"
                    :total="appData.total"
                  ></el-pagination>
                </div>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="white-box-right">
          <el-button type="success" class="fr mb10 mt5 mr5 white-box-right-button" v-show="authFunction('FUNC_SYS_ADD',0)"
                     @click="showCreateBizDialog()">创建业务</el-button>
          <el-tabs>
            <el-tab-pane label="业务列表">
              <div class="table-box-top">
                <div class="table-box">
                  <el-table :data="bizData.list"
                            border
                            :class="{'el-table-left-none':bizData.list.length == 0}">
                    <el-table-column prop="bizName" label="业务名称" width="200">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="toAppList(scope.row)">{{scope.row.bizName}}</span>
                      </template>
                    </el-table-column>
                    <el-table-column prop="appNumber" label="应用数量" width="80"></el-table-column>
                    <el-table-column prop="teamName" label="所属团队" min-width="100"></el-table-column>
                    <el-table-column label="业务管理员" width="400">
                      <template slot-scope="scope">
                        {{(!scope.row.expand && getBizOwnerStr(scope.row.bizMembers).length > 35) ?
                        getBizOwnerStr(scope.row.bizMembers).substring(0,25) + '...' :
                        getBizOwnerStr(scope.row.bizMembers)}}
                        <span class="c-blue cp"
                              v-if="!scope.row.expand && getBizOwnerStr(scope.row.bizMembers).length > 35"
                              @click="expandInfo(scope.row)">
                        查看全部
                      </span>
                        <span class="c-blue cp" v-if="scope.row.expand" @click="unExpandInfo(scope.row)">收起</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="table_b_f_b">
                  <el-pagination
                    class="fr white-box-right-pagination"
                    @size-change="handleBizSizeChange"
                    @current-change="handleBizPageChange"
                    :current-page="bizData.pageNum"
                    :pager-count="5"
                    :page-sizes="[10, 20, 30]"
                    :page-size="bizData.pageSize"
                    layout="total, prev, pager, next"
                    :total="bizData.total">
                  </el-pagination>
                </div>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>

    <!--创建业务-->
    <el-dialog
      title="创建业务"
      :visible.sync="dialogVisible"
      class="el-dialog-580w issuedialog"
      :before-close="closeCreateBizDialog"
      :modal-append-to-body="modaltobody"
      :close-on-click-modal="shadeBtn"
    >
      <div class="form-iterm-box">
        <el-form :model="creatInfo" ref="creatInfoForm" label-width="100px" label-position="right">
          <el-form-item
            label="业务分类"
            class="mb20"
            prop="teamId"
            :rules="[{ required: true, message: '业务分类不能为空', trigger: 'blur'}]"
          >
            <el-select
              v-model="creatInfo.teamId"
              filterable
              placeholder="请选择业务分类"
              style="width:100%;"
              @change="addBizFrefix"
            >
              <el-option
                v-for="item in teamList"
                :key="item.teamId"
                :label="item.teamName"
                :value="item.teamId"
              >
                <span style="float: left">{{ item.teamName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px"></span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            label="业务编码"
            class="mb20"
            prop="bizCode"
            :rules="rulesCustom.bizCode"
          >
            <el-input v-model="creatInfo.bizCode" placeholder="请输入业务编号">
              <template slot="prepend">{{bizCodePrefix}}</template>
            </el-input>
          </el-form-item>
          <el-form-item
            label="业务名称"
            class="mb15"
            prop="bizName"
            :rules="rulesCustom.bizName"
          >
            <el-input v-model="creatInfo.bizName" placeholder="请输入业务名称">
              <template slot="prepend">{{bizNamePrefix}}</template>
            </el-input>
          </el-form-item>
          <el-form-item
            label="业务管理员"
            class="mb15"
            prop="userIds"
            :rules="[{ type:'array', required: true, message: '业务管理员不能为空', trigger: 'blur' }]"
          >
            <el-select
              v-model="creatInfo.userIds"
              filterable
              :filter-method="getUserList"
              multiple
              placeholder="请选择业务管理员"
              style="width:100%;"
            >
              <el-option v-for="item in filterUserList" :key="item.userId" :label="item.userName" :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right: 25px">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item
            label="业务描述"
            class="mb15"
            prop="bizDesc"
            :rules="[{ required: true, message: '业务描述不能为空', trigger: 'blur'}]"
          >
            <el-input
              type="textarea"
              placeholder="请输入业务描述"
              style="margin-top: 10px"
              :rows="5"
              v-model="creatInfo.bizDesc"
            ></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeCreateBizDialog">关闭</el-button>
        <el-button type="primary" @click="saveBiz">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "bizList",
    data() {
      let isBizCodeAvailable = (rule, value, callback) => {
        var a = new Array("$", "@", "#", "!", "~", "`", "^", "&", "*", " ");
        for (let i = 0; i < a.length; i++) {
          if (value.indexOf(a[i]) >= 0) {
            callback(new Error("不能包含空格和特殊字符"));
            return;
          }
        }
        if(value.length > 50){
          callback(new Error("名称超过最大长度,最大50个字符"));
          return;
        }
        callback();
      };
      return {
        bizCodePrefix: "",
        bizNamePrefix: "",
        modaltobody: false,
        shadeBtn: false,
        creatInfo: {
          bizCode: "",
          bizName: "",
          bizDesc: "",
          teamId: "",
          userIds: []
        },
        filterUserList: [],
        teamList: [],
        bizData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        appData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        dialogVisible: false,
        search: "",
        activeName: "first",
        isSearching: false,
        rulesCustom: {
          bizCode: [{required: true, message: '业务编码不能为空', trigger: 'blur'}, {validator: isBizCodeAvailable, trigger: 'blur'}],
          bizName: [{required: true, message: '业务名称不能为空', trigger: 'blur'}, {validator: isBizCodeAvailable, trigger: 'blur'}]
        },
        teamId2Prefix: []
      };
    },

    mounted() {
      this.getBizList();
      this.getAppList();
    },

    methods: {
      changeAppCollection(val) {
        $http.get($http.api.app.change_app_collection, {appId: val}).then(res => {
          let status = res.data.status
          if (status) {
            this.$message({message: res.data.msg, type: "success"})
          } else {
            this.$message({message: res.data.msg, type: "error"})
          }
          this.getAppList();
        }).catch(e => {
          this.$message({message: "接口请求失败！", type: "error"})
        })
      },
      expandInfo(row) {
        this.$set(row, 'expand', true);
      },
      unExpandInfo(row) {
        this.$set(row, 'expand', false);
      },
      handleClick(val) {
        if (val.name == 'first') {
          this.getBizList();
        } else if (val.name == 'second') {
          this.getAppList();
          this.search = "";
        }
      },

      toAppList(biz) {
        this.goToPage(this, "appList", {bizId: biz.bizId});
      },
      handleBizPageChange(val) {
        this.bizData.pageNum = val;
        this.getBizList();
      },
      handleBizSizeChange(val) {
        this.bizData.pageSize = val;
        this.getBizList();
      },
      getBizList() {
        let params = {
          pageNum: this.bizData.pageNum,
          pageSize: this.bizData.pageSize
        };
        $http.get($http.api.biz.getBizList, params).then(res => {
          this.bizData = res.data;
        });
      },
      toApp(val) {
        if (val.appId && val.bizId) {
          let appDetailsDefaultDestination = "appVersions";
          if(val.developMode && val.developMode == 1) {
            appDetailsDefaultDestination = "featureBranchList";
          }

          this.goToPage(this, appDetailsDefaultDestination, {
            appId: val.appId,
            bizId: val.bizId
          });
        } else {
          this.$message({
            message: "应用所属业务为空，不允许查看当前应用",
            type: "error"
          });
        }
      },
      toBiz(val) {
        if (val.bizId) {
          this.goToPage(this, "appList", {bizId: val.bizId});
        }
      },
      handleAppPageChange(val) {
        this.appData.pageNum = val;
        this.getAppList();
      },
      handleAppSizeChange(val) {
        this.appData.pageSize = val;
        this.getAppList();
      },
      getAppListByKeyWord() {
        if (this.isSearching) {
          return;
        }
        this.isSearching = true;
        setTimeout(() => {
          this.$nextTick(() => {
            this.getAppList();
          });
        }, 800);
      },
      getAppList() {
        this.isSearching = true;
        let params = {
          pageNum: this.appData.pageNum,
          pageSize: this.appData.pageSize,
          keyword: this.search
        };
        $http.get($http.api.biz.getAppList, params).then(res => {
          this.appData = res.data;
          this.isSearching = false;
        });
      },
      getBizOwnerStr(list) {
        if (!list || list.length === 0) {
          return "";
        }
        var arr = [];
        list.forEach(item => {
          var temp = item.userName + "(" + item.userId + ")";
          arr.push(temp);
        });
        return arr.join("、");
      },
      getAppCreateUser(val) {
        return val.createUserName + '(' + val.createUser + ')';
      },
      getTeamList() {
        $http
          .get($http.api.team.getTeamList, {})
          .then(res => {
            this.teamList = res.data;
          })
          .catch(e => {
            this.$message({
              message: "获取团队失败",
              type: "error"
            });
          });
      },
      getUserList(val) {
        let params = {
          keyWord: val
        };
        $http
          .get($http.api.biz.getAllUser, params)
          .then(res => {
            this.filterUserList = res.data;
          })
          .catch(e => {
            this.$message({
              message: "获取人员失败",
              type: "error"
            });
          });
      },
      sendBizRequest() {
        this.saveBizInfo = {
          bizCode: "",
          bizName: "",
          bizDesc: "",
          teamId: "",
          userIds: []
        };
        this.saveBizInfo.bizCode = this.bizCodePrefix + this.creatInfo.bizCode;
        this.saveBizInfo.bizName = this.bizNamePrefix + this.creatInfo.bizName;
        this.saveBizInfo.bizDesc = this.creatInfo.bizDesc;
        this.saveBizInfo.teamId = this.creatInfo.teamId;
        this.saveBizInfo.userIds = this.creatInfo.userIds;
        $http
          .post($http.api.biz.addBiz, this.saveBizInfo)
          .then(res => {
            if (res.status == 200) {
              this.closeCreateBizDialog();
              this.getBizList();
              this.$message({
                message: "添加业务成功",
                type: "success"
              });
            } else {
              this.$message({
                message: res.msg,
                type: "error"
              });
            }
          })
          .catch(e => {
            this.$message({
              message: "添加业务失败",
              type: "error"
            });
          });
      },

      //点击确定按钮关闭标签管理弹窗
      submitBtn() {
        this.handleClose();
      },
      saveBiz() {
        this.$refs["creatInfoForm"].validate(validate => {
          if (validate) {
            this.sendBizRequest();
          }
        });
      },
      //点击关闭按钮关闭标签管理弹窗
      closeCreateBizDialog() {
        this.creatInfo = {
          bizCode: "",
          bizName: "",
          bizDesc: "",
          teamId: "",
          userIds: []
        };
        this.dialogVisible = false;
      },

      //创建业务
      showCreateBizDialog() {
        this.getUserList();
        this.getTeamList();
        this.getAllPrefix();
        this.dialogVisible = true;
      },

      getAllPrefix() {
        this.teamId2Prefix.push({teamId: 1, bizCode: "browser_", bizName: "浏览器-"});
        this.teamId2Prefix.push({teamId: 2, bizCode: "search_", bizName: "搜索-"});
        this.teamId2Prefix.push({teamId: 3, bizCode: "system_security_", bizName: "系统与安全-"});
        this.teamId2Prefix.push({teamId: 4, bizCode: "ads_", bizName: "广告-"});
        this.teamId2Prefix.push({teamId: 5, bizCode: "user_center_", bizName: "用户中心-"});
        this.teamId2Prefix.push({teamId: 6, bizCode: "cdo_", bizName: "内容分发-"});
        this.teamId2Prefix.push({teamId: 7, bizCode: "finance_", bizName: "金融-"});
        this.teamId2Prefix.push({teamId: 8, bizCode: "www_", bizName: "官网-"});
        this.teamId2Prefix.push({teamId: 9, bizCode: "community_", bizName: "OPPO"});
        this.teamId2Prefix.push({teamId: 10, bizCode: "push_", bizName: "PUSH-"});
        this.teamId2Prefix.push({teamId: 11, bizCode: "ocloud_", bizName: "云服务-"});
        this.teamId2Prefix.push({teamId: 12, bizCode: "AI_", bizName: "智能平台-"});
        this.teamId2Prefix.push({teamId: 13, bizCode: "IoT_", bizName: "IoT-"});
        this.teamId2Prefix.push({teamId: 14, bizCode: "security_", bizName: "安全-"});
        this.teamId2Prefix.push({teamId: 15, bizCode: "basic_", bizName: "基础技术-"});
        this.teamId2Prefix.push({teamId: 16, bizCode: "data_center_", bizName: "数据中心-"});
        this.teamId2Prefix.push({teamId: 17, bizCode: "it_", bizName: "IT-"});
        this.teamId2Prefix.push({teamId: 18, bizCode: "strategy_", bizName: "战略-"});
        this.teamId2Prefix.push({teamId: 19, bizCode: "operation_", bizName: "运维-"});
        this.teamId2Prefix.push({teamId: 20, bizCode: "test_", bizName: "互联网测试-"});
      },

      addBizFrefix() {
        for (let i = 0; i < this.teamList.length; i++) {
          if (this.teamList[i].teamId === this.creatInfo.teamId) {
            this.bizCodePrefix = this.teamList[i].codePrefix;
            this.bizNamePrefix = this.teamList[i].namePrefix;
            return;
          }
        }
      },

      //点击应用ID跳转到版本列表
      routerBtn(val) {
        this.goToPage(this, "appList", val);
      }
    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  #bizList {
  .white-box {
    height: -webkit-calc(100% - 45px);
    margin-left: 10%;
    margin-right: 10%;
  .white-box-left {
    width: calc(38% - 8px);
    display: inline-block;
    vertical-align: top;
    margin: 10px 0px 10px 0px;
  .white-box-left-search {
    width: 260px;
    position: absolute;
    right: 59.7%;
    top: 12px;
    z-index: 999;
  }
  .white-box-left-pagination {
    margin-top: 9px;
    margin-bottom: 9px;
  }
  }
  .white-box-right {
    width: calc(62% - 10px);
    display: inline-block;
    margin-left: 2px;
    margin-left: 10px;
    margin-top: 10px;
  .white-box-right-button {
    position: absolute;
    right: 10.2%;
    top: 12px;
    z-index: 999;
  }
  .white-box-right-pagination {
    margin-top: 9px;
    margin-bottom: 9px;
  }
  }
  }
  }
  .issuedialog {
  .addclassTap {
    height: 40px;
    margin-bottom: 10px;
    border-bottom: 2px solid #d8dee5;

  .tapTitile {
    font-size: 16px;
    font-weight: 400;
  }

  .addtap {
    float: right;
  }
  }

  .tabtable {
    height: 490px;
  //   background: red;
  }
  }

  .el-tabs-wai {
    height: 100%;

  .el-tabs__content {
    height: calc(100% - 55px);
    overflow: hidden;
    overflow: auto;

  .el-tab-pane {
    height: calc(100% - 10px);
  }
  }
  }

  .paintermouse {
    cursor: pointer;
  }

  .paintermouse:hover {
    color: #409eff;
  }
</style>
