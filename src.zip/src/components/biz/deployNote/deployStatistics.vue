<template>
  <div id="deployNoteList" class="content-outer-box">
    <div class="white-box table-outer-box">
      <div class="mt0">
        <!--发布统计-->
        <span style="line-height: 28px;">统计时间范围</span>
        <el-select style="width:80px;" v-model="statisticsFW" @change="statisticsFWChange">
          <el-option label="月度" value="1"/>
          <el-option label="周度" value="2"/>
        </el-select>
        <span style="line-height: 28px;margin-left: 10px;">年份</span>
        <el-select style="width:80px;" v-model="selectedYear" @change="yearChange">
          <el-option v-for="item in yearList" :label="item" :value="item" :key="'year' + item"/>
        </el-select>
        <div style="display: inline-block" v-if="statisticsFW == 1">
          <span style="line-height: 28px;margin-left: 10px;">月份</span>
          <el-select style="width:80px;" v-model="selectedMonth">
            <el-option v-for="item in monthList" :label="item.value" :value="item.key" :key="'month' + item.key"/>
          </el-select>
        </div>
        <div style="display: inline-block" v-if="statisticsFW == 2">
          <span style="line-height: 28px;margin-left: 10px;">周</span>
          <el-select style="width:230px;" v-model="selectedWeek">
            <el-option v-for="item in weekList" :label="'第' + item.week + '周(' + item.startDate + '-' + item.endDate + ')'" :value="item.startDate + ':' + item.endDate" :key="'week' + item.startDate"/>
          </el-select>
        </div>
        <el-button class="checkbox-button" type="primary" @click="getDeployStatistics">查询</el-button>
        <el-button class="checkbox-button" type="primary" @click="goToPaas">跳转paas查看发布详情</el-button>

        <el-table style="width: 850px;margin-top: 8px"
          :data="statisticsVo.deployNoteStatisticsBos.slice((deployStatisticsPageInfo.pageNum-1) * deployStatisticsPageInfo.pageSize,
          deployStatisticsPageInfo.pageNum*deployStatisticsPageInfo.pageSize > deployStatisticsPageInfo.total ? deployStatisticsPageInfo.total :
          deployStatisticsPageInfo.pageNum*deployStatisticsPageInfo.pageSize)">
          <el-table-column prop="deployNoteDesc" :label="'发布单(' + deployStatisticsPageInfo.total + ')'" width="300">
            <template slot-scope="scope">
              <span class="c-blue cp" @click="showDeployDetails(scope.row)">{{scope.row.deployNoteDesc}}</span>
            </template>
          </el-table-column>
          <el-table-column :label="'紧急发布(' + statisticsVo.urgentTotalCount + ')'" width="150">
            <template slot-scope="scope">
              {{scope.row.urgentCount > 0 ? '是' : '否'}}
            </template>
          </el-table-column>
          <el-table-column :label="'超频发布(' + statisticsVo.overTotalCount + ')'" width="150">
            <template slot-scope="scope">
              {{scope.row.overFreqCount > 0 ? '是' : '否'}}
            </template>
          </el-table-column>
          <el-table-column :label="'回滚(' + statisticsVo.rollBackTotalCount + ')'" width="150">
            <template slot-scope="scope">
              {{scope.row.rollBackcount > 0 ? '是' : '否'}}
            </template>
          </el-table-column>
        </el-table>
        <div class="table_b_f_b">
          <el-pagination
            style="margin-top: 9px;"
            v-show="deployStatisticsPageInfo.total != 0"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="deployStatisticsPageInfo.pageNum"
            :page-sizes="[10, 20]"
            :page-size="deployStatisticsPageInfo.pageSize"
            layout="total, sizes, prev, pager, next"
            :total="deployStatisticsPageInfo.total">
          </el-pagination>
        </div>

      </div>
    </div>

    <!-- 发布日志弹窗 -->
    <el-dialog :title="deployDetailTitle" id="dialog_deploy_detail" :visible.sync="dialog_deploy_detail"
               class="el-dialog-1180w el-dialog-26h issuedialog" :before-close="handleCloseDeployDetail"
               :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
        <div class="table-box-top">
          <div class="table-box" style="margin-bottom: 10px">
            <el-table :data="deployDetailList.slice((deployDetailData.pageNum-1)*deployDetailData.pageSize,
                          deployDetailData.pageNum*deployDetailData.pageSize)" border
                      :class="{'el-table-left-none':deployDetailList.length == 0}">
              <el-table-column prop="appCode" label="应用ID" min-width="100">
                <template slot-scope="scope">
                  {{scope.row.appCode}}
                </template>
              </el-table-column>
              <el-table-column prop="versionName" label="版本" min-width="180">
                <template slot-scope="scope">
                  {{scope.row.versionName}}
                </template>
              </el-table-column>
              <el-table-column prop="zoneName" label="机房" min-width="100">
                <template slot-scope="scope">
                  {{scope.row.zoneName}}
                </template>
              </el-table-column>
              <el-table-column label="首次发布" min-width="150">
                <template slot-scope="scope">
                  <span>{{scope.row.firstDeployTime}}</span>
                  <br>
                  <span>{{scope.row.firstUserId}}</span>
                </template>
              </el-table-column>
              <el-table-column label="最后发布" min-width="150">
                <template slot-scope="scope">
                  <span>{{scope.row.lastDeployTime}}</span>
                  <br>
                  <span>{{scope.row.lastUserId}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="deployInstanceCount" label="实例数/机器数/成功率" min-width="150">
                <template slot-scope="scope">
                  {{scope.row.deployInstanceCount}}/{{scope.row.deployIpCount}}/{{getSuccessRate(scope.row)}}
                </template>
              </el-table-column>
              <el-table-column label="发布详情" min-width="180">
                <template slot-scope="scope">
                  <span v-html="getAbnormalState(scope.row)"></span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="pageModule" style="height: 35px">
            <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleDeploySizeChange"
                           @current-change="handleDeployPageChange"
                           :current-page="deployDetailData.pageNum" :page-sizes="[10]"
                           :page-size="deployDetailData.pageSize"
                           layout="total, sizes, prev, pager, next, jumper" :total="deployDetailData.total">
            </el-pagination>
          </div>
        </div>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "deployStatistics",
    data() {
      return {
        deployStatisticsPageInfo: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
        },
        currentYear: '',
        currentMonth: '',
        currentWeek: '',
        selectedStatisticsType: 'all',
        selectedYear: '',
        selectedMonth: '',
        selectedWeek: '',
        weekList: [],
        yearList: [],
        monthList: [
          {key: 1, value: '1月'},
          {key: 2, value: '2月'},
          {key: 3, value: '3月'},
          {key: 4, value: '4月'},
          {key: 5, value: '5月'},
          {key: 6, value: '6月'},
          {key: 7, value: '7月'},
          {key: 8, value: '8月'},
          {key: 9, value: '9月'},
          {key: 10, value: '10月'},
          {key: 11, value: '11月'},
          {key: 12, value: '12月'},
        ],
        statisticsFW: '1',
        userId: '',
        currentUserId:$utils.getCurrentUserId(),
        isShowCreateButton: false,//新建发布单显示控制
        passIframeUrl: "",
        zoneList: [],
        tabList: [],
        showDeployNote: {},
        showDeployNoteForm: { //发布单详情弹窗
          deployNoteId: '',
          auditFlow: [],
          deployList: [],
        },
        passForm: {},
        passDeployUrl: '',
        deployNoteForm: { //发布弹窗
          data: [],
          isAppView: true,
        },
        isViewDeployNoteForm: true,//true查看发布单  false是审核发布单
        rejectReason: '',
        table_loading: false,
        activeName: "-1",
        look_dialogVisible: false,
        shadeBtn: false,
        modaltobody: false,
        objInfo: {},
        dataMap: {},
        tableListmod: [],
        dialogVisible_fbd: false,
        step: "1",
        bizId: '',
        iviewMap: "0",
        flowData: null,
        disableds: false,
        tablelistparent: [],
        obJect: {},
        obJect_2: {},
        dialogVisible_fb: false,
        deployInframeTitle: '发布',
        iframeData: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        fileList:[],
        uploadFiles:[],
        uploadFileIds:[],
        submit_deploy_upload_loading:false,
        uploadActionUrl: $http.api.deploy_note.uploadDeployDir.url,
        upoladID: {
          deployNoteId: -1,
          bizId:this.getUrlBizId()
        },
        dialog_deploy_detail: false,
        versionNames: '',
        deployDetailData: {
          pageNum:1,
          pageSize:10,
          total:0
        },
        deployDetailList: [],
        deployDetailTitle:'',
        statisticsDetaiData: [],
        appStatisticsVisible: false,
        appStatisticsDetail: [],
        statisticsVo: {
          deployNoteStatisticsBos: [],
          urgentTotalCount: 0,
          overTotalCount: 0,
          rollBackTotalCount: 0,
          deployTotalCount: 0
        }
      };
    },

    mounted() {
      //document.getElementsByClassName('el-tabs__content')[0].style.minHeight = '';
      this.bizId = this.getUrlBizId();
      this.getLoginUserInfo();
      this.getYearList()
      this.getCurrentYear()
      this.getCurrentMonth()
      this.statisticsFWChange()
    },
    /*destroy(){
      document.getElementsByClassName('el-tabs__content')[0].style.minHeight = 300+'px';
    },*/
    methods: {
      goToPaas() {
        window.open('http://paas.oppoer.me/#appmanage/app/statistics/index')
      },
      getCurrentYear() {
        this.currentYear = new Date().getFullYear()
        this.selectedYear = this.currentYear
      },
      getCurrentMonth() {
        this.currentMonth = new Date().getMonth() + 1
        this.selectedMonth = this.currentMonth
      },
      getCurrentWeek() {
        let now = new Date()
        if (this.selectedYear) {
          $http.get($http.api.deploy_note.get_week_list,{year: this.selectedYear}).then((res) => {
            this.weekList = res.data
            this.weekList.forEach(item => {
              let start = new Date(Date.parse(item.startDate))
              let end = new Date(Date.parse(item.endDate))
              if (now >= start && now <= end) {
                this.currentWeek = item.startDate + ':' + item.endDate
              }
            })
            this.selectedWeek = this.currentWeek
          })
        }
      },

      /*原展示内容*/
      showVersionStatisticsDialog(versionStatisticsBos) {
        this.appStatisticsDetail = versionStatisticsBos
        this.appStatisticsVisible = true
      },
      statisticsTypeChange() {
        this.statisticsDetaiData = this.statisticsData[this.selectedStatisticsType]
      },
      getDeployStatistics() {
        if (this.statisticsFW == 1) {
          if (!this.selectedYear) {
            this.$message({ message: '请选择统计年份', type: 'error' })
            return
          }
          if (!this.selectedMonth) {
            this.$message({ message: '请选择统计月份', type: 'error' })
            return
          }
        } else {
          if (!this.selectedYear) {
            this.$message({ message: '请选择统计年份', type: 'error' })
            return
          }
          if (!this.selectedWeek) {
            this.$message({ message: '请选择统计周度', type: 'error' })
            return
          }
        }

        if (this.statisticsFW == 1) {
          $http.get($http.api.deploy_note.get_deploy_statistics,{year: this.selectedYear, statisticsFW: this.statisticsFW, bizId: this.bizId, month: this.selectedMonth}).then((res) => {
            this.statisticsVo = res.data
            //维护假分页信息
            this.deployStatisticsPageInfo.pageNum = 1
            this.deployStatisticsPageInfo.total = this.statisticsVo.deployTotalCount
          }).catch(e => {
            this.$message({ message: '获取统计数据失败！', type: 'error' })
          })
        } else {
          let weekVal = this.selectedWeek
          let vals = weekVal.split(":")
          $http.get($http.api.deploy_note.get_deploy_statistics,{month: 0, year: this.selectedYear, statisticsFW: this.statisticsFW, bizId: this.bizId, start: new Date(vals[0]), end: new Date(vals[1])}).then((res) => {
            this.statisticsVo = res.data
            //维护假分页信息
            this.deployStatisticsPageInfo.pageNum = 1
            this.deployStatisticsPageInfo.total = this.statisticsVo.deployTotalCount
          }).catch(e => {
            this.$message({ message: '获取统计数据失败！', type: 'error' })
          })
        }
      },
      yearChange() {
        if (this.statisticsFW == 2) {
          this.selectedWeek = ''
          this.getWeekList(this.selectedYear)
        }
      },
      statisticsFWChange() {
        if (this.statisticsFW == 2) {
          this.selectedYear = this.currentYear
          this.getCurrentWeek()
        } else {
          this.selectedYear = this.currentYear
          this.selectedMonth = this.currentMonth
        }
      },
      getYearList() {
        $http.get($http.api.deploy_note.get_year_list).then((res) => {
          this.yearList = res.data
        })
      },
      getWeekList(year) {
        if (year) {
          $http.get($http.api.deploy_note.get_week_list,{year: year}).then((res) => {
            this.weekList = res.data
          })
        }
      },
      async getLoginUserInfo() {//获取当前登陆用户信息
        await $http.get($http.api.user.getLoginUserInfo).then((res) => {
          this.userId = res.data.systemUser.userId;
        })
      },

      getSuccessRate(val){
        let successCount = val.deploySuccessConut;
        let failCount = val.deployFailCount;
        let numberRate = successCount/(successCount + failCount);
        let strRate = Number(numberRate * 100).toFixed(2) + "%";
        return strRate;
      },

      getAbnormalState(val){
        let abnormalState = '';
        if(val.rollBackCount > 0){
          abnormalState = abnormalState + "回滚版本：" + val.versionName + "<br>";
        }else{
          abnormalState = abnormalState + "回滚版本：无" + "<br>";
        }
        if(val.urgentCount > 0){
          abnormalState = abnormalState + "紧急发布：" + val.urgentCount + "个实例" + "<br>";
          abnormalState = abnormalState + "紧急原因：" + val.urgentRemarks;
        }else{
          abnormalState = abnormalState + "紧急发布：无";
        }
        return abnormalState;
      },

      //发布日志
      handleCloseDeployDetail(){
        this.dialog_deploy_detail = false;
      },
      showDeployDetails(val){
        this.versionNames = val.appVersionNames
        this.deployDetailData.pageNum = 1;
        this.deployDetailData.pageSize = 10;
        this.deployDetailData.total = 0;
        this.getDeployDetais();
        this.deployDetailTitle = "【" + val.deployNoteDesc + "】发布统计";
        this.dialog_deploy_detail = true;
      },
      //发布日志数据
      getDeployDetais(){
        $http.get($http.api.deploy_note.getDeployDetailList, {versionNames: this.versionNames, pageSize: this.deployDetailData.pageSize, pageNum: this.deployDetailData.pageNum}).then(res => {
          if (res.status == 200) {
            if(res.data){
              this.deployDetailList = res.data;
              this.deployDetailData.total = this.deployDetailList.length;
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },
      handleDeployPageChange(val){
        this.deployDetailData.pageNum = val;
      },

      handleDeploySizeChange(val){
        this.deployDetailData.pageSize = val;
      },

      getDeployDirList(deployNoteId){
        $http.get($http.api.deploy_note.getDeployDirList, {deployNoteId: deployNoteId}).then(res => {
          if (res.status == 200) {
            this.uploadFiles = res.data;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      uploadDeployBtn(){
        this.dialog_visible_upload = true;
      },

      downloadDeployBtn(val){
        $http.get($http.api.deploy_note.downloadDeployDir, {deployDirId: val}).then(res => {
          if (res.status == 200) {
            window.location.href = res.data.downloadUrl;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      deleteDeployBtn(val){
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.deploy_note.deleteDeployDir, {deployDirId: val}).then(res => {
            if (res.status == 200) {
              this.$message({
                message: '删除附件成功',
                type: 'success'
              });
              this.removeUploadFileId(val);
            } else {
              this.$message({
                message: res.msg,
                type: 'warning'
              })
            }

          });
        }).catch(() => {
        });
      },

      removeUploadFileId(fileId){
        this.uploadFileIds.forEach((item, index) => {
          if (item === fileId) {
            this.uploadFileIds.splice(index, 1);
          }
        });

        this.uploadFiles.forEach((item, index) => {
          if (item.id === fileId) {
            this.uploadFiles.splice(index, 1);
          }
        });

      },

      handleUploadSuccess(response, file, fileList){
        let data = response.data;
        let msg = response.msg;
        if(msg === 'OK'){
          this.uploadFiles.push({
            deployNoteId:-1,
            id:data,
            userId:this.currentUserId,
            fileName:file.name
          });
          this.uploadFileIds.push(data);
        }else{
          this.$message({
            message: '上传附件失败：' + msg,
            type: 'error'
          });
        }
      },

      handleUploadError(){},

      submit_deploy_upload(){
        let uploadform = this.$refs.upload.$data.uploadFiles;
        let formData = new FormData();
        formData.append("deployNoteId", -1);
        formData.append("file", uploadform[0].raw);
        $http.post($http.api.deploy_note.uploadDeployDir, formData).then((res) => {
          let data = res.data;
          this.$alert(data !== null ? '上传成功' : '上传失败', '提示', {
            confirmButtonText: '确定',
            callback: action => {
              this.goToPage(this, "deployNoteList", {bizId: this.bizId});
            }
          });
          this.uploadFiles.push({
            deployNoteId:-1,
            id:data,
            fileName:uploadform[0].name
          });
          this.uploadFileIds.push(data);
        }).catch(e => {
        })
      },

      //关闭
      handle_close_upload() {
        this.$refs.upload.$data.uploadFiles.length = 0;
        this.dialog_visible_upload = false;
      },

      handlePreview(file) {

      },
      handleRemove(file, fileList) {

      },
      handleExceed(files, fileList) {
      },

      getStepDesc(item) {
        for (let index in this.tabList) {
          let tab = this.tabList[index];
          if (tab.type == item.deployNoteStatus) {
            return tab.buttonName.replace("待", "");
          }
        }
        return "审批";
      },
      showMore(item) {
        item.expand = true;
      },
      showLess(item) {
        item.expand = false;
      },
      getZoneList() {
        $http.get($http.api.app.getZoneList, {env: 'online'}).then(res => {
          this.zoneList = res.data;
        }).catch((e) => {
          this.$message({
            message: '获取机房失败',
            type: 'error'
          });
        });
      },

      getZoneNameByCode(zoneCode) {
        let zoneName = zoneCode;
        this.zoneList.forEach(zone => {
          if (zone.code == zoneCode) {
            zoneName = zone.name;
          }
        })
        return zoneName;
      },

      spanMethod({row, column, rowIndex, columnIndex}) {
        if (columnIndex === 0) {
          if (row.key1span != 0) {
            return [row.key1span, 1];
          } else {
            return [0, 0];
          }
        } else if (columnIndex === 1) {
          if (row.key2span != 0) {
            return [row.key2span, 1];
          } else {
            return [0, 0];
          }
        }
      },
      canDeploy(deployNote) {//判断到发布时间没有
        try {
          let time = JSON.parse(deployNote.deployNoteResult).deployTime;
          if (time) {
            if (typeof time == 'number') {
              let date = new Date();
              date.setTime(time);
              let deployTime = this.formatDate(date, "yyyyMMdd");
              let nowDate = this.formatDate(new Date(), "yyyyMMdd");
              let deployStatus = parseInt(nowDate) >= parseInt(deployTime);
              return deployStatus;
            } else {
              let deployTime = time.substring(0, 10).replace(new RegExp('-', "g"), "");
              let nowDate = this.formatDate(new Date(), "yyyyMMdd");
              let deployStatus = parseInt(nowDate) >= parseInt(deployTime);
              return deployStatus;
            }
          }
        } catch (e) {
          console.error("解析发布时间出错", e)
        }
        return false;

      },
      isButtonShow(deployNote, buttonType) {
        // "edit","send","review","deploy","finish","delete"

        let stepId = deployNote.deployNoteStatus;
        let ended = deployNote.result === 2;
        let deployed = deployNote.isDeployed == 1;

        var backStates = ["edit", "delete"]//已打回
        var sendStates = ["edit", "send", "delete"]//待送审
        var waitDeployStates = ["deploy", "finish"]//待发布
        var midddleStates = ["review"]//中间审核流程

        if (ended && !deployed) {//已打回
          return backStates.indexOf(buttonType) != -1;
        }
        let showButton = false;
        if (stepId == 0) {//待送审
          showButton = sendStates.indexOf(buttonType) != -1;
        } else if (stepId == 3) {//待发布
          showButton = waitDeployStates.indexOf(buttonType) != -1;
        } else if (stepId == 4) {//已完成
          showButton = false;
        } else {//中间审核流程
          showButton = midddleStates.indexOf(buttonType) != -1;
        }

        //判断当前步骤是否有权限
        if (showButton == false) {
          return false;
        }

        let havePermisson = false;
        let userId = this.userId;
        if (deployNote.auditFlow) {
          deployNote.auditFlow.forEach(flow => {
            if (stepId == flow.stepId) {
              if (flow.memberIds) {
                flow.memberIds.forEach(memberId => {
                  if (userId == memberId) {
                    havePermisson = true;
                  }
                })
              }
            }
          })
        }
        return havePermisson;
      },
      tabChange() {
        this.getDeployNoteList();
      },
      getStatusDesc(status) {
        let statusDesc = '';
        this.tabList.forEach(val => {
          if (val.type == status) {
            statusDesc = val.buttonName;
          }
        })
        return statusDesc;
      },
      getShowUserNameByUserId(userId) { //根据工号获得显示的用户的用户名
        let showUserName = userId;
        if (this.flowData) {
          if (this.flowData.fixedFlowInfo) {
            this.flowData.fixedFlowInfo.forEach(flow => {
              if (flow.approverList) {
                flow.approverList.forEach(person => {
                  if (userId == person.userId) {
                    showUserName = person.userName + "(" + person.userId + ")";
                  }
                })
              }
            });
          }
          if (this.flowData.customFlowInfo) {
            this.flowData.customFlowInfo.forEach(flow => {
              if (flow.approverList) {
                flow.approverList.forEach(person => {
                  if (userId == person.userId) {
                    showUserName = person.userName + "(" + person.userId + ")";
                  }
                })
              }
            });
          }
        }
        return showUserName;
      },
      getFlowData() {//获得业务流程信息，用于判断
        $http.get($http.api.issue.deploynoteflowinfo, {bizId: this.bizId}).then(res => {
          this.flowData = res.data;
        })
      },
      getButtonAndCount() {//获取标签和统计数量
        $http.get($http.api.deploy_note.getButtonAndCount, {bizId: this.bizId}).then(res => {
          res.data.forEach(item => {
            item.type = '' + item.type + '';
            if (!this.dataMap[item.type]) {
              this.$set(this.dataMap, item.type, {total: 0, pageNum: 1, pageSize: 20, list: []});
            }
          })
          this.tabList = res.data;
          this.tabChange();
        }).catch((e) => {
          this.$message({
            message: '获取标签失败，请重试',
            type: 'error'
          });
        });
      },
      viewDeployNote(deployNote) {
        this.isViewDeployNoteForm = true;
        this.getDeployNoteDetail(deployNote);
      },
      reviewDeployNote(deployNote) {
        this.isViewDeployNoteForm = false;
        this.getDeployNoteDetail(deployNote);
      },

      completeDeploy(deployNote) {
        this.$confirm("确定将此发布单更换为完成状态？", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          if (!this.canDeploy(deployNote)) {
            this.$message({
              message: '未到设定的发布时间',
              type: 'warning'
            });
            return;
          }
          $http.get($http.api.deploy_note.completeDeploy, {
            deployNoteId: deployNote.deployNoteId,
            env: 'online',
          }).then(res => {
            this.checkResult(res);
          });
        }).catch(() => {
        });
      },
      getDeployNoteDetail(deployNote) {
        this.upoladID.deployNoteId = deployNote.deployNoteId;
        $http.get($http.api.deploy_note.getDeployNoteDetail, {deployNoteId: deployNote.deployNoteId}).then(res => {
          this.showDeployNote = res.data;
          this.showDeployNoteForm.deployNoteId = this.showDeployNote.deployNoteId;
          this.showDeployNoteForm.deployNoteDesc = this.showDeployNote.deployNoteDesc;
          this.showDeployNoteForm.fastDeployStr = this.showDeployNote.fastDeploy == 0 ? '普通发布' : '快速发布';
          let deployNoteResult = JSON.parse(this.showDeployNote.deployNoteResult);
          this.showDeployNoteForm.bizName = deployNoteResult.bizName;
          this.showDeployNoteForm.title = deployNoteResult.title;
          this.showDeployNoteForm.createUser = deployNoteResult.createUser;
          this.showDeployNoteForm.bizOwner = deployNoteResult.bizOwner;
          this.showDeployNoteForm.deployTime = deployNoteResult.deployTime;
          this.showDeployNoteForm.notice = deployNoteResult.notice;
          this.showDeployNoteForm.auditFlow = deployNoteResult.auditFlow;
          this.showDeployNoteForm.isAppView = this.showDeployNote.deployNoteView == 0;

          //组装列表数据
          this.showDeployNoteForm.deployList = this.assembleTableData(deployNoteResult.deployAppModules, this.showDeployNoteForm.isAppView);
          this.getDeployDirList(deployNote.deployNoteId);
          this.lookOverBtn()
        })
      },

      transferDataToList(deployAppModules) { //把数据转换为列表结构
        let list = [];
        deployAppModules.forEach(module => {
          if (module.deployInfo && module.deployInfo.length != 0) {
            module.deployInfo.forEach(zone => {
              let zoneName = "";
              if (this.zoneList) {
                this.zoneList.forEach(item => {
                  if (item.code == zone.zone) {
                    zoneName = item.name;
                  }
                })
              }

              list.push({
                zone: zone.zone,
                zoneName: zoneName,
                configEnv: zone.configEnv,
                configVersion: zone.configVersion,
                appId: module.appId,
                appCode: module.appCode,
                appName: module.appName,
                updateDesc: module.updateDesc,
                version: module.version,
                versionDesc: module.versionDesc,
                versionId: module.versionId,
                deployOrder: module.deployOrder,
                cmdbPath: module.cmdbPath,
                deployInfo: module.deployInfo,
                repoUrl: module.repoUrl,
                MD5: module.MD5,
                tester: module.tester,
              });
            })
          }
        });
        return list;
      },

      assembleTreeData(deployAppModules, isAppView) {//组装树形数据
        let list = this.transferDataToList(deployAppModules);
        let key1Name = isAppView ? 'appCode' : 'zone';
        let key2Name = isAppView ? 'zone' : 'appCode';
        let map = new Map();//key1,key2,list
        list.forEach(item => {
          let val1 = item[key1Name];
          let val2 = item[key2Name];

          if (!map.has(val1)) {
            let map2 = new Map();
            map2.set(val2, [item])
            map.set(val1, map2);
            return;
          }

          let map2 = map.get(val1);
          if (!map2.has(val2)) {
            map2.set(val2, [item])
          } else {
            map2.get(val2).push(item);
          }
        })

        let data = [];
        map.forEach((map2, label1) => {
          let item1 = {label: label1, children: []};
          data.push(item1);
          map2.forEach((itemList, label2) => {
            let item2 = {label: label2, children: []};
            item1.children.push(item2);
            itemList.forEach(item => {
              item2.children.push({label: item.version, item: item});
            })
          })
        })
        return data;
      },

      assembleTableData(deployAppModules, isAppView) {//组装列表数据
        let key1Name = isAppView ? 'appId' : 'zone';
        let key2Name = isAppView ? 'zone' : 'appId';
        let list = this.transferDataToList(deployAppModules);
        list.sort((a, b) => {
          if (a[key1Name] != b[key1Name]) {
            return a[key1Name] < b[key1Name] ? 1 : -1;
          } else {
            if (a[key2Name] != b[key2Name]) {
              return a[key2Name] < b[key2Name] ? 1 : -1;
            } else {
              return a.deployOrder - b.deployOrder;
            }
          }
        });

        //计算需要合并的列的个数
        let map = new Map();
        list.forEach(item => {
          let key1 = item[key1Name];
          let key2 = item[key1Name] + "_" + item[key2Name];
          let count1 = map.get(key1);
          let count2 = map.get(key2);
          if (count1) {
            map.set(key1, count1 + 1);
          } else {
            map.set(key1, 1);
          }
          if (count2) {
            map.set(key2, count2 + 1);
          } else {
            map.set(key2, 1);
          }
        });

        list.forEach(item => {
          let key1 = item[key1Name];
          let key2 = item[key1Name] + "_" + item[key2Name];
          let count1 = map.get(key1);
          let count2 = map.get(key2);
          if (count1) {
            item.key1span = count1;
            map.delete(key1);
          } else {
            item.key1span = 0;
          }
          if (count2) {
            item.key2span = count2;
            map.delete(key2);
          } else {
            item.key2span = 0;
          }
        });

        return list;

      },
      //级菜单切换控制路由切换
      handleSelect(val) {
        if (val === "1") {
          this.goToPage(this, 'deployNoteList');
        } else if (val === "2") {
          this.goToPage(this, 'deployNoteFlow');
        }
      },
      //级菜单切换控制路由切换
      createNewDeploy() {
        this.goToPage(this, 'deployNoteManage', {bizId: this.bizId})
      },

      // 获取全部发布单列表
      getDeployNoteList() {
        let params = {
          bizId: this.bizId,
          type: this.activeName,
          searchValue: '',
          pageSize: this.dataMap[this.activeName].pageSize,
          pageNum: this.dataMap[this.activeName].pageNum,
        }
        $http.post($http.api.deploy_note.getDeployNoteList, params).then(res => {
          if (res.status == 200) {
            if (res.data && res.data.list) {
              let arr = res.data.list.forEach((item, index) => {
                let parse = JSON.parse(item.deployNoteResult);
                let appSet = new Set();
                let versionSet = new Set();
                parse.deployAppModules.forEach((i, index) => {
                  appSet.add('【' + i.appCode + '】');
                  versionSet.add(i.version);
                });
                let appList = [];
                let versionList = [];
                appSet.forEach(appName => {
                  appList.push(appName);
                });
                versionSet.forEach(versionName => {
                  versionList.push(versionName);
                });
                item.versionNames = versionList.join(",");
                item.appName = appList.join("");
                item.expand = false;
                item.auditFlow = parse.auditFlow;
              })
            }
            this.$set(this.dataMap, this.activeName, res.data)
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      //发布单查看
      lookOverBtn(val) {
        this.look_dialogVisible = true;
      },

      //全部发布单查看
      editDeployNote(deployNote) {
        this.goToPage(this, 'deployNoteManage', {bizId: this.bizId, deployNoteId: deployNote.deployNoteId})
      },
      sendDeployNoteToFlow(deployNote) {//送审
        this.updateFlow(deployNote.deployNoteId, 1)
      },
      passDeployNoteToFlow() {//审核通过
        this.handleClose();
        this.updateFlow(this.showDeployNoteForm.deployNoteId, 1)
      },
      rejectDeployNoteToFlow() {//打回
        this.handleClose_fbd();
        this.look_dialogVisible = false;
        this.updateFlow(this.showDeployNoteForm.deployNoteId, 2, this.rejectReason)
      },
      updateFlow(deployNoteId, result, comment) {//送审
        $http.post($http.api.deploy_note.auditFlowUpdate, {
          deployNoteId: deployNoteId,
          result: result,
          comment: comment
        }).then(res => {
          this.checkResult(res);
        });
      },

      checkResult(res) {
        this.getButtonAndCount();
        if (res.status == 200) {
          this.$message({
            message: "操作成功",
            type: "success"
          });
        } else {
          this.$message({
            message: res.msg,
            type: "error"
          });
        }
      },

      //删除发布单
      deleteDeployNote(deployNote) {
        this.$confirm("确定要删除吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.deploy_note.deleteDeployNote, {deployNoteId: deployNote.deployNoteId}).then(res => {
            this.getButtonAndCount();
            this.$message({
              message: "删除成功",
              type: "success"
            });
          }).catch((e) => {
            this.$message({
              message: "删除失败",
              type: "success"
            });
          });
        }).catch(() => {
        });
      },


      //全部发布单列表分页
      handleSizeChange(val) {
        this.deployStatisticsPageInfo.pageSize = val;
        this.deployStatisticsPageInfo.pageNum = 1;
      },

      handleCurrentChange(val) {
        this.deployStatisticsPageInfo.pageNum = val;
      },


      //查看弹窗关闭
      handleClose() {
        this.look_dialogVisible = false;
      },

      //弹窗驳回按钮
      rejectBtn() {
        this.dialogVisible_fbd = true;
      },

      //驳回弹窗关闭
      handleClose_fbd() {
        this.dialogVisible_fbd = false;
      },

      getResultStr(result) {
        let str = '';
        if (result == 1) {
          str = '同意'
        } else if (result == 2) {
          str = '打回'
        } else if (result) {
          return result;
        }
        return str;
      },

      getPersonStr(username, time, comment) {
        let str = '';
        if (username && time) {
          str = username + ' ' + time;
          if(comment){
            str = str + ' 打回原因:' + comment;
          }
          return str;
        } else {
          return str;
        }
      },

      //发布
      release(deployNote) {
        if (!this.canDeploy(deployNote)) {
          this.$message({
            message: '未到设定的发布时间',
            type: 'warning'
          });
          return;
        }
        window.open("/deployNoteIframe?bizId=" + this.getUrlBizId() + '&' + 'deployNoteId=' + deployNote.deployNoteId, '_blank')
      },


    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  .el-icon-delete {
    color: #f56c6c;
    font-size: 18px;
    line-height: 20px;
  }

  .el-icon-circle-plus-outline {
    color: #409eff;
    font-size: 18px;
  }

  .el-icon-info {
    color: #e6a23c;
    font-size: 18px;
    line-height: 0px;
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .fbdtableshxx {
    padding: 5px 5px 5px 5px;
    height: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    border: none;
    width: 100%;

    .backgroundColor {
      width: 200px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .backgroundColor_b {
      width: 211px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .text-again {
      text-align: left;
      padding-left: 20px !important;
    }

    .backgroundColor_c {
      width: 220px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .backgroundColor:hover {
      background: #f5f7fa;
    }

    .backgroundtitle {
      width: 12.5%;
      height: 40px;
      border: 1px solid #e4e7ed;
      background: #f5f7fa;
    }

    .fontright {
      height: 40px;
      text-align: center;
      line-height: 20px;
    }

    .fontleft {
      text-align: left;
      line-height: 20px;
      padding-left: 20px;
    }
  }

  .tableshxx {
    padding: 5px 5px 5px 5px;
    height: 100%;
    border-collapse: collapse;
    border: 1px solid black;
    width: 100%;

    .backgroundColor {
      width: 480px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .text-again {
      text-align: left !important;
      padding-left: 20px !important;
    }

    .backgroundColor:hover {
      background: #f5f7fa;
    }

    .backgroundtitle {
      width: 120px;
      height: 40px;
      border: 1px solid #e4e7ed;
      background: #f5f7fa;
    }

    .fontright {
      text-align: center;
      line-height: 20px;
      padding-right: 20px;
    }

    .fontleft {
      text-align: left;
      line-height: 20px;

      padding-left: 20px;
    }
  }

  #lookDialog {
    .el-tabs {
      .el-tabs__content {
        height: calc(100% - 40px) !important;

        .el-tab-pane {
          height: 100%;

          .tablegjcxlb {
            padding: 5px 5px 5px 5px;
            height: 100%;
            border-collapse: collapse;
            border: 1px solid black;

            .backgroundColor {
              width: 480px;
              height: 40px;
              border: 1px solid #e4e7ed;
            }

            .text-again {
              text-align: left;
              padding-left: 20px !important;
            }

            .backgroundColor:hover {
              background: #f5f7fa;
            }

            .backgroundtitle {
              width: 120px;
              height: 40px;
              border: 1px solid #e4e7ed;
              background: #f5f7fa;
            }

            .fontright {
              text-align: center;
              line-height: 20px;
              padding-right: 20px;
            }

            .fontleft {
              text-align: left;
              line-height: 20px;

              padding-left: 20px;
            }
          }
        }
      }
    }
  }

  #editDialog {
    .lastheader {
      height: 100%;
      margin-top: 10px;
      margin-bottom: 10px;

      .iviewtitle {
        margin-top: 10px;
        margin-right: 10px;
      }
    }

    .el-tabs {
      margin-top: 10px;

      .el-tabs__content {
        height: calc(100% - 40px) !important;

        .el-tab-pane {
          height: 100%;

          .tablegjcxlb {
            padding: 5px 5px 5px 5px;
            height: 100%;
            border-collapse: collapse;
            border: 1px solid black;

            .backgroundColor {
              width: 480px;
              height: 40px;
              border: 1px solid #e4e7ed;
            }

            .text-again {
              text-align: left;
              padding-left: 20px !important;
            }

            .backgroundColor:hover {
              background: #f5f7fa;
            }

            .backgroundtitle {
              width: 120px;
              height: 40px;
              border: 1px solid #e4e7ed;
              background: #f5f7fa;
            }

            .fontright {
              text-align: center;
              line-height: 20px;
              padding-right: 20px;
            }

            .fontleft {
              text-align: left;
              line-height: 20px;

              padding-left: 20px;
            }
          }
        }
      }
    }

    .tMain {
      padding: 5px 5px 5px 5px;
      height: 100%;
      border-collapse: collapse;
      border: 1px solid black;

      .backgroundColor {
        width: 480px;
        height: 40px;
        border: 1px solid #e4e7ed;
      }

      .backgroundColor:hover {
        background: #f5f7fa;
      }

      .backgroundtitle {
        width: 120px;
        height: 40px;
        border: 1px solid #e4e7ed;
        background: #f5f7fa;
      }

      .fontright {
        text-align: center;
        line-height: 20px;
        padding-right: 20px;
      }

      .fontleft {
        text-align: left;
        line-height: 20px;

        padding-left: 20px;
      }
    }
  }
</style>
