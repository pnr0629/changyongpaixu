<template>
  <div id="deployNoteManage" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-box-top"
               style="height:100%;overflow:auto;overflow-x: hidden;">
            <div>

              <div class="table-outer-box" style="height:100%;" v-if="stepFlag === '1'">
                <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
                  <div class="table-box-top" style="height:100% !important;">
                    <div style="height:100%;">
                      <el-form :model="deployInfo" ref="deployInfo" label-width="110px">
                        <!--<el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">-->
                          <!--<el-col style="margin-bottom: 0px;margin-top: 0px" :span="12">-->
                            <!--<el-alert class="c-red"-->
                                      <!--title="请注意哥伦布发布系统于1月21号到2月10号期间封网，封网期间只有运维人员进行发布操作"-->
                                      <!--type="warning">-->
                            <!--</el-alert>-->
                          <!--</el-col>-->
                        <!--</el-row>-->
                        <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
                          <el-col class="mt10 form_item" :span="12">
                            <el-form-item class='mb10' label="发布标题"
                                          prop="deployNoteDesc"
                                          :rules="[{ required: true, message: '不能为空' ,trigger: 'blur' }]">
                              <el-input v-model="deployInfo.deployNoteDesc"></el-input>
                            </el-form-item>
                          </el-col>
                          <el-col class="mt10 form_item" :span="12">
                          </el-col>

                          <el-col :span="24">
                            <el-col :span="12" style="margin-top: 10px">
                              <el-form-item label="发布人"
                                            prop="deployNoteResult.deployUsersArray"
                                            :rules="[{ required: true, message: '发布人不能为空',trigger: 'blur' }]">
                                <el-select style="width: 100%" filterable multiple
                                           v-model="deployInfo.deployNoteResult.deployUsersArray">
                                  <el-option v-for="item in filterDelopyUserList"
                                             :label="item.userName+'('+item.userId+')'"
                                             :value="item.userId" :key="item.userId"></el-option>
                                </el-select>
                              </el-form-item>
                            </el-col>
                            <el-col style="margin-bottom: 23px;margin-top: 10px" :span="12">
                              <div style="height:40px;line-height: 40px ">
                                <span v-if="deployInfo.deployNoteResult.deployUsersArray.length===1" class="c-red">请注意当前只有一个发布人，请确认是否需要添加发布人</span>
                              </div>
                            </el-col>

                          </el-col>


                          <el-col :span="12">
                            <el-form-item label="发布时间" prop="deployNoteResult.deployTime" id="date_form"
                                          class="date_padding"
                                          :rules="[{ required: true, message: '发布时间不能为空',trigger: 'blur' }]">
                              <el-date-picker value-format="timestamp" v-model="deployInfo.deployNoteResult.deployTime"
                                              :picker-options="dateOptions"
                                              type="date" style="width: 100%"
                                              placeholder="选择日期">
                              </el-date-picker>
                            </el-form-item>
                          </el-col>
                          <el-col style="margin-bottom: 23px;" :span="8">
                            <div style="height:40px;line-height: 40px ">
                              <span class="c-red">{{getDeployTip}}</span>
                            </div>
                          </el-col>
                          <el-col :span="24">
                            <el-form-item label="是否快速发布" prop="fastDeploy"
                                          :rules="[{ required: true, message: '不能为空',trigger: 'blur' }]">
                              <el-radio-group v-model="deployInfo.fastDeploy">
                                <el-radio :label="0">否</el-radio>
                                <el-radio :label="1">是</el-radio>
                              </el-radio-group>
                            </el-form-item>
                          </el-col>

                          <el-col :span="24">
                            <el-form-item label="发布说明" prop="deployNoteResult.notice"
                                          :rules="[{ required: true, message: '不能为空',trigger: 'blur'  }]">
                              <el-input v-model="deployInfo.deployNoteResult.notice" type="textarea"
                                        :rows="12"></el-input>
                            </el-form-item>
                          </el-col>
                        </el-row>
                      </el-form>
                      <div style="height:40px;margin-top:20px;">
                        <el-button type="primary" style="float:left;margin-left:45%;" @click="gotoStep2()">下一步
                        </el-button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="table-outer-box" style="height:100%;" v-if="stepFlag === '2'">
                <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
                  <div style="width:100%">
                    <span class="iviewtitle">首选视图</span>
                    <el-select v-model="selectDeployView" placeholder="请选择" style="width:10%;" class="mb10"
                               @change="deployNoteViewChanged">
                      <el-option
                        v-for="item in deployNoteViewList"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value">
                      </el-option>
                    </el-select>

                    <el-table :data="deployData" border empty-text=" " :span-method="spanMethod" id="deploy-table">
                      <el-table-column :label="isAppView?'应用模块':'机房(单元)'" width="250px">
                        <template slot-scope="table">
                          <div style="display: flex;align-items: center">
                            <el-select v-if="isAppView" v-model="table.row.appId" placeholder="请选择" filterable
                                       @change="appIdChanged(table.row)"
                                       class="deploy-note-table-select">
                              <el-option
                                v-for="item in getSelectAppList(table.row.appId)"
                                :key="item.appId"
                                :label="item.appCode"
                                :value="item.appId">
                              </el-option>
                            </el-select>
                            <el-select v-if="!isAppView" v-model="table.row.zoneCode" placeholder="请选择"
                                       class="deploy-note-table-select"
                                       @change="zoneCodeChanged(table.row)">
                              <el-option
                                v-for="item in zoneList"
                                :key="item.code"
                                :label="item.name"
                                :value="item.code">
                              </el-option>
                            </el-select>
                            <span class="el-icon-delete cp" @click="delete1(table.row)"></span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column :label="!isAppView?'应用模块':'机房(单元)'" width="250px">
                        <template slot-scope="table">
                          <div style="display: flex;align-items: center">
                            <el-select v-if="isAppView"
                                       class="deploy-note-table-select"
                                       v-model="table.row.zoneCode"
                                       placeholder="请选择"
                                       @change="zoneCodeChanged(table.row)">
                              <el-option
                                v-for="item in zoneList"
                                :key="item.code"
                                :label="item.name"
                                :value="item.code">
                              </el-option>
                            </el-select>

                            <el-select v-if="!isAppView" v-model="table.row.appId" placeholder="请选择" filterable
                                       @change="appIdChanged(table.row)"
                                       class="deploy-note-table-select">
                              <el-option
                                v-for="item in appList"
                                :key="item.appId"
                                :label="item.appCode"
                                :value="item.appId">
                              </el-option>
                            </el-select>

                            <span class="el-icon-delete cp"
                                  @click="delete2(table.row)"></span>
                            <span class="el-icon-circle-plus-outline cp"
                                  style="margin-left: 5px"
                                  @click="addModule2(table.row,table.$index)"></span>
                          </div>
                        </template>
                      </el-table-column>
                      <el-table-column label="版本" width="390px">
                        <template slot-scope="table">
                          <el-select v-model="table.row.versionId" placeholder="请选择"
                                     style="width:300px;padding: 8px 0;">
                            <el-option
                              v-for="item in appVersionMap[table.row.appId+'']"
                              :key="item.versionId"
                              :label="item.versionName"
                              :value="item.versionId">
                            </el-option>
                          </el-select>
                          <span class="el-icon-delete cp"
                                @click="delete3(table.row)"></span>
                          <span class="el-icon-circle-plus-outline cp"
                                @click="addModule3(table.row,table.$index)"></span>
                          <el-popover
                            v-model="table.row.popoverShow"
                            placement="bottom"
                            :disabled="shouldShowVersionDesc(table.row)"
                            trigger="click">
                            <div style="margin-bottom: 4px;display: flex">
                              <span
                                style="padding-top: 4px;font-size: 15px;flex: 1;"><b>版本信息</b></span>
                              <i class="el-icon-close"
                                 style="float: right;font-size: 20px;cursor: pointer;padding: 4px;"
                                 @click="table.row.popoverShow=false"></i>
                            </div>
                            <table class="tableshxx white-box" style="border:1px solid #e4e7ed;">
                              <tr v-for="item in versionData.dataList">
                                <td class="fontright backgroundtitle" style="font-size: 14px"><b>{{item.key}}</b></td>
                                <td class="fontright backgroundColor backgroundColor-pop text_agin">{{item.value}}</td>
                              </tr>
                            </table>

                            <div style="padding-bottom: 8px;padding-top: 16px;"
                                 v-show="versionData.appShowType==5"><b>多仓库信息</b></div>
                            <div style="overflow-x: hidden;overflow-y:auto;max-height: 300px;width: 800px;"
                                 v-show="versionData.appShowType==5" id="app">
                              <el-table border :data="versionData.subVoList">
                                <el-table-column prop="subAppId" label="子应用ID" min-width="130px"></el-table-column>
                                <el-table-column prop="gitRepoUrl" min-width="290px" label="源码仓库"></el-table-column>
                                <el-table-column prop="branch" label="分支名称"></el-table-column>
                                <el-table-column prop="commitId" label="commitId" width="100px">
                                  <template slot-scope="scope">
                                    {{scope.row.commitId.substring(0,9)}}
                                  </template>
                                </el-table-column>
                              </el-table>
                            </div>
                            <div class="el-icon-info cp cp-blue" @click="getVersionDesc(table.row)"
                                 slot="reference"></div>
                          </el-popover>
                        </template>
                      </el-table-column>
                      <el-table-column label="环境配置" width="200px">
                        <template slot-scope="table">
                          <el-select v-model="table.row.env" placeholder="请选择"
                                     v-show="envMap[table.row.appId + '_' + table.row.zoneCode]"
                                     @change="envItemChanged(table.row)">
                            <el-option
                              v-for="(value,key) in envMap[table.row.appId+'_'+table.row.zoneCode]"
                              :key="key"
                              :label="key"
                              :value="key">
                            </el-option>
                          </el-select>
                        </template>
                      </el-table-column>
                      <el-table-column label="配置版本" width="150px">
                        <template slot-scope="table">
                          <el-select v-model="table.row.configVersion" placeholder="请选择"
                                     v-show="envMap[table.row.appId + '_' + table.row.zoneCode]">
                            <el-option
                              v-for="item in getEnvVersions(table.row)"
                              :key="item"
                              :label="item"
                              :value="item">
                            </el-option>
                          </el-select>
                        </template>
                      </el-table-column>
                      <el-table-column label="CMDB">
                        <template slot-scope="table">
                          <el-select v-model="table.row.cmdbId"
                                     v-show="cmdbMap[table.row.appId+''] && cmdbMap[table.row.appId+''].length!=0"
                                     placeholder="请选择">
                            <el-option
                              v-for="item in cmdbMap[table.row.appId+'']?cmdbMap[table.row.appId+'']:[]"
                              :label="item.cmdbPath"
                              :key="item.cmdbId"
                              :value="item.cmdbId">
                            </el-option>
                          </el-select>
                          <span v-show="cmdbMap[table.row.appId+''] && cmdbMap[table.row.appId+''].length==0">未关联CMDB分类</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="主机信息" width="120px">
                        <template slot-scope="table">
                          <el-popover
                            v-show="cmdbMap[table.row.appId+''] && cmdbMap[table.row.appId+''].length!=0"
                            placement="bottom"
                            title="主机信息"
                            width="100"
                            trigger="click">
                            <template slot-scope="content">
                              <div style="color: dodgerblue" v-for="ip in showCmdbIpList">{{ip}}</div>
                            </template>
                            <span class="c-blue cp" slot="reference"
                                  @click="getCmdbIpsClick(table.row.appId,table.row.zoneCode,table.row.cmdbId)">
                              查看主机IP
                            </span>
                          </el-popover>
                        </template>
                      </el-table-column>
                    </el-table>
                    <el-button type="primary" style="margin: 0 auto;display: block;margin-top: 16px" @click="addModule">
                      添加模块
                    </el-button>
                  </div>
                  <div style="margin-bottom: 10px">
                    <div class="form-iterm-box">
                      <el-upload class="upload-demo" action="uploadActionUrl" v-bind:action="uploadActionUrl"
                                 :data="upoladID" :on-success="handleUploadSuccess" accept :show-file-list="false" :auto-upload="true">
                        <span size="small" type="primary" class="c-blue" style="line-height:22px;">上传附件</span>
                      </el-upload>
                    </div>
                    <el-row :gutter="10">
                      <el-col v-for="(item,index) in uploadFiles" :key="index" style="background-color: rgba(214,214,214,0.15); margin-right: 5px; width: 200px">
                        <span :title="item.fileName" style="display :inline-block;width: 55%;overflow: hidden;textOverflow: ellipsis;whiteSpace: nowrap">{{ item.fileName }}</span>
                        <span class="c-blue cp" @click="downloadDeployBtn(item.id)" style="float: right">下载</span>
                        <span class="c-blue cp" v-if="currentUserId === item.userId" @click="deleteDeployBtn(item.id)" style="float: right; padding-right: 3px">删除</span>
                      </el-col>
                    </el-row>
                  </div>
                  <span style="font-size: 15px;display: inline-block;margin-bottom: 4px"><b>审核信息</b></span>
                  <table class="tableshxx" style="border:1px solid #e4e7ed;">
                    <tr v-for="flow in auditFlow">
                      <td class="fontright backgroundtitle">{{flow.step}}</td>
                      <td v-if="flow.step!=='公布（读者）'" class="fontright backgroundColor text_agin">
                        {{flow.memberName}}
                      </td>
                      <td v-if="flow.step!=='公布（读者）'" class="fontright backgroundtitle">
                        {{getResultStr(flow.result)}}
                      </td>
                      <td v-if="flow.step!=='公布（读者）'" class="fontright backgroundColor text_agin">
                        {{getPersonStr(flow.auditor,flow.endTime, flow.comment)}}
                      </td>

                      <td v-if="flow.step==='公布（读者）'" colspan="3" class="fontright backgroundColor text_agin">
                        <el-select style="width: 100%" v-model="flow.memberIds" multiple filterable>
                          <el-option v-for="user in bizUserList"
                                     :key="user.userId"
                                     :value="user.userId"
                                     :label="user.userName+'('+user.userId+')'"></el-option>
                        </el-select>
                      </td>
                    </tr>
                  </table>
                  <div style="height:30px;margin-top:20px;margin-bottom:10px;">
                    <div style="display:inline-block;margin-left: calc(50% - 155px);">
                      <el-button type="primary" class="fr mr10" @click="gotoStep1()">上一步</el-button>
                      <el-button type="primary" class="fr mr10" @click="saveBtn(false)">保存</el-button>
                      <el-button type="success" class="fr" @click="saveBtn(true)">送审</el-button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  // import Distpicker from 'v-distpicker'
  export default {
    name: "deployNoteManage",
    computed:{
      getDeployTip() {
        if (this.deployInfo.deployNoteResult.deployTime) {
          let deployTime = this.deployInfo.deployNoteResult.deployTime;
          let date = new Date(deployTime);
          let nowDate = new Date();
          if(date.getDate() == nowDate.getDate()){
            date = new Date(nowDate.getTime());
            this.deployInfo.deployNoteResult.deployTime = date.getTime();
          }
          return "发布周期为" + this.formatDate('yyyy-MM-dd hh时', date) + " 到 " + this.formatDate('yyyy-MM-dd hh时', new Date(date.getTime() + 24 * 60 * 60 * 1000 * 3)) + ",非此期间内不能发布"
        } else {
          return "";
        }
      },
    },
    data() {
      return {
        currentUserId:$utils.getCurrentUserId(),
        deployData: [],
        dateOptions: {
          disabledDate(time) {
            return time.getTime() < (new Date().getTime() - 24 * 60 * 60 * 1000);
          }
        },
        dialog_visible_upload:false,
        submit_deploy_upload_loading:false,
        counter: 0,
        flowData: {},
        cmdbIpMap: {},
        showCmdbIpList: [],
        selectDeployView: 0,
        deployNoteId: null,
        auditFlow: null,
        currentUser: {},
        readersList: [],
        isNew: true,
        bizInfo: {},
        isAppView: true,
        deployUsers: [],
        uploadFileList:[],
        deployInfo: {
          deployNoteDesc: '',
          deployNoteStatus: 0,
          deployNoteType: 0,
          environment: "online",
          deployNoteView: 0,
          fastDeploy: 0,
          deployNoteResult: {
            bizName: '',
            createUser: '',
            relatedDeveloper: '',
            bizOwner: '',
            deployUsers: '',
            deployUsersArray: [],
            deployTime: '',
            notice: '',
            deployAppModules: [],
          }
        },
        updateDelopyNote: {},
        zoneList: [],
        appList: [],
        appVersionMap: {},
        envMap: {},
        cmdbMap: {},
        filterDelopyUserList: [],
        bizUserList: [],
        table_loading: false,
        step: "1",
        bizId: '',
        stepFlag: "1",
        iview1: "",
        iview2: "",
        iview3: "",
        deployNoteViewList: [{label: "应用模块", value: 0}, {label: "机房单元", value: 1}],
        disableds: false,
        deployAppModules: [],
        versionData: {
          dataList: [],
          appShowType: null,
          subVoList: []
        },
        uploadActionUrl: $http.api.deploy_note.uploadDeployDir.url,
        upoladID: {
          deployNoteId: -1,
          bizId:this.getUrlBizId()
        },
        fileList:[],
        uploadFiles:[],
        uploadFileIds:[],
        modaltobody:false
      };
    },
    mounted() {
      this.initPage();
      this.getZoneList();
      this.getBizInfo();
      this.getDeployMembers();
      this.getLoginUserInfo();
    },
    beforeRouteLeave(to, from, next) {
      //跳转页面前，清理SessionStorage
      sessionStorage.removeItem("DEPLOY_NOTE_ONE_CLICK_GENERATE");
      sessionStorage.removeItem("DEPLOY_NOTE_BIZ_ID");
      sessionStorage.removeItem("DEPLOY_NOTE_APP_ID");
      sessionStorage.removeItem("DEPLOY_NOTE_VERSION_ID");
      sessionStorage.removeItem("DEPLOY_NOTE_VERSION_NAME");
      next();
    },
    methods: {
      //-----------------------------------------------------------------------------------------------------------------------

      getDeployDirList(deployNoteId){
        $http.get($http.api.deploy_note.getDeployDirList, {deployNoteId: deployNoteId}).then(res => {
          if (res.status == 200) {
            this.uploadFiles = res.data;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      uploadDeployBtn(){
        this.dialog_visible_upload = true;
      },

      downloadDeployBtn(val){
        $http.get($http.api.deploy_note.downloadDeployDir, {deployDirId: val}).then(res => {
          if (res.status == 200) {
            window.location.href = res.data.downloadUrl;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      deleteDeployBtn(val){
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.deploy_note.deleteDeployDir, {deployDirId: val}).then(res => {
            if (res.status == 200) {
              this.$message({
                message: '删除附件成功',
                type: 'success'
              });
              this.removeUploadFileId(val);
            } else {
              this.$message({
                message: res.msg,
                type: 'warning'
              })
            }

          });
        }).catch(() => {
        });
      },

      removeUploadFileId(fileId){
        this.uploadFileIds.forEach((item, index) => {
          if (item === fileId) {
            this.uploadFileIds.splice(index, 1);
          }
        });

        this.uploadFiles.forEach((item, index) => {
          if (item.id === fileId) {
            this.uploadFiles.splice(index, 1);
          }
        });

      },

      handleUploadSuccess(response, file, fileList){
        let data = response.data;
        let msg = response.msg;
        if(msg === 'OK'){
          this.uploadFiles.push({
            deployNoteId:-1,
            id:data,
            userId:this.currentUserId,
            fileName:file.name
          });
          this.uploadFileIds.push(data);
        }else{
          this.$message({
            message: '上传附件失败：' + msg,
            type: 'error'
          });
        }
      },

      //关闭
      handle_close_upload() {
        this.$refs.upload.$data.uploadFiles.length = 0;
        this.dialog_visible_upload = false;
      },

      handlePreview(file) {

      },
      handleRemove(file, fileList) {

      },
      handleExceed(files, fileList) {
        // this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
      },

      getEnvVersions(row) {
        let envMapElement = this.envMap[row.appId + '_' + row.zoneCode];
        if (!envMapElement || !envMapElement[row.env]) {
          return [];
        }
        return envMapElement[row.env];
      },

      closeVersionDialog() {
        this.dialogVersionVisible = false;
      },
      getSelectAppList(myAppId) {
        if (this.isAppView) {
          let filterList = [];
          let selectAppIds = this.deployData.map(item => {
            return item.appId;
          });
          if (!myAppId || myAppId == '') {
            let filter = this.appList.filter(item => {
              return !selectAppIds.includes(item.appId);
            });
            return filter
          } else {
            let filter = this.appList.filter(item => {
              return !selectAppIds.includes(item.appId) || myAppId == item.appId;
            });
            return filter
          }
        }
        return this.appList;
      },
      envItemChanged(item) {
        item.configVersion = "";
      },
      spanMethod({row, column, rowIndex, columnIndex}) {
        if (columnIndex === 0 || columnIndex == 1) {
          let keyName = "key" + (columnIndex + 1) + "Index";
          let isFirst = false;
          let span = 0;
          for (let index in this.deployData) {
            let deployItem = this.deployData[index];
            if (deployItem[keyName] == row[keyName]) {
              span++;
              if (deployItem === row && span == 1) {
                isFirst = true;
              }
            }
          }
          return isFirst ? [span, 1] : [0, 0];
        }
      },
      delete1(row) {
        this.deployData = this.deployData.filter(item => {
          return item.key1Index != row.key1Index;
        })
      },
      delete2(row) {
        this.deployData = this.deployData.filter(item => {
          return item.key2Index != row.key2Index;
        })
      },
      delete3(row) {
        this.deployData = this.deployData.filter(item => {
          return item.key3Index != row.key3Index;
        })
      },
      zoneCodeChanged(row) {
        this.deployData.forEach(item => {
          if ((this.isAppView && item.key2Index == row.key2Index) || (!this.isAppView && item.key1Index == row.key1Index)) {
            item.zoneCode = row.zoneCode;
            item.env = "";
            item.configVersion = "";
            this.getConfigList(row.appId, row.zoneCode);
          }
        });
      },
      appIdChanged(row) {
        this.deployData.forEach(item => {
          if ((this.isAppView && item.key1Index == row.key1Index) || (!this.isAppView && item.key2Index == row.key2Index)) {
            item.appId = row.appId;
            item.versionId = "";
            item.cmdbId = "";
            item.env = "";
            item.configVersion = "";
            this.getConfigList(item.appId, item.zoneCode);
          }
        });
        this.getVersionList(row.appId);
        this.getCmdb(row.appId);
      },
      addModule() {
        let blankModule = this.getBlankModule();
        blankModule.key1Index = this.nextId();
        blankModule.key2Index = this.nextId();
        blankModule.key3Index = this.nextId();
        this.deployData.push(blankModule);
        return blankModule;
      },

      addModule2(row, index) {
        let blankModule = this.getBlankModule();
        blankModule.key1Index = row.key1Index;
        blankModule.key2Index = this.nextId();
        blankModule.key3Index = this.nextId();
        if (this.isAppView) {
          blankModule.appId = row.appId;
        } else {
          blankModule.zoneCode = row.zoneCode;
        }
        this.deployData.forEach((item, i) => {
          if (item.key2Index == row.key2Index) {
            index = i;
          }
        })
        this.deployData.splice(index + 1, 0, blankModule);
        this.setDefaultValues();
      },
      addModule3(row, index) {
        let blankModule = this.getBlankModule();
        blankModule.key1Index = row.key1Index;
        blankModule.key2Index = row.key2Index;
        blankModule.key3Index = this.nextId();
        blankModule.appId = row.appId;
        blankModule.zoneCode = row.zoneCode;
        this.deployData.splice(index + 1, 0, blankModule);
        this.setDefaultValues();
      },
      nextId() {
        return this.counter++;
      },
      getBlankModule() {
        return {
          appId: "",
          key1Index: 0,
          key2Index: 0,
          key3Index: 0,
          popoverShow: false,
          zoneCode: "",
          versionId: "",
          env: "",
          configVersion: "",
          cmdbId: ""
        }
      },
      getTableAppList(myAppId) {
        if (this.isAppView) {
          let filterList = [];
          let selectAppIds = this.deployData.map(item => {
            return item.appId;
          });
          if (this.isEmpty(myAppId)) {
            let filter = this.appList.filter(item => {
              return !selectAppIds.includes(item.appId);
            });
            return filter
          } else {
            let filter = this.appList.filter(item => {
              return !selectAppIds.includes(item.appId) || myAppId == item.appId;
            });
            return filter
          }
        }
        return this.appList;
      },

      setDefaultValues() {
        //设置版本
        for (let i = 0; i < this.deployData.length; i++) {
          let item = this.deployData[i];
          let appId = item.appId;
          if (this.isNotEmpty(appId)) {

            if (this.isEmpty(item.versionId)) {
              let appLatestVersion = this.getAppLatestVersion(appId);
              if (appLatestVersion) {
                item.versionId = appLatestVersion.versionId;
              }
            }

            if (this.isEmpty(item.cmdbId)) {
              let firstCmdb = this.getFirstCmdb(appId);
              if (firstCmdb) {
                item.cmdbId = firstCmdb.cmdbId;
              }
            }

            if (this.isEmpty(item.zoneCode)) {
              let zone = this.getFirstZoneList();
              if (zone) {
                item.zoneCode = zone.code;
                this.getConfigList(appId, zone.code)
              }
            }
          }
        }
      },

      //------------------------------------------------------------------------------------------------------------------------
      configEnvSelect(item) {
        item.configVersion = '';
      },
      getVersionDesc(item) {
        let versionList = this.appVersionMap[item.appId + ''];
        let versionId = item.versionId;
        if (!versionList || this.isEmpty(versionId)) {
          return;
        }
        let app = this.getAppById(item.appId);
        if (app == null) {
          return;
        }
        this.versionData.appShowType = app.appType;
        this.versionData.subVoList = [];
        this.versionData.dataList = [];
        versionList.forEach(version => {
          if (version.versionId == versionId) {
            this.versionData.dataList.push({key: "应用名称", value: version.appCode});
            this.versionData.dataList.push({key: "版本名称", value: version.versionName});
            this.versionData.dataList.push({key: "版本描述", value: version.versionDesc});
            if (this.versionData.appShowType != 5) {
              this.versionData.dataList.push({key: "commitId", value: version.commitId.substring(0, 9)});
              this.versionData.dataList.push({key: "分支", value: version.sourceBranch});
            }
            this.versionData.dataList.push({key: "创建人", value: version.createUserName});
            this.versionData.dataList.push({key: "测试通过人", value: version.testPassedUser});
            this.versionData.dataList.push({key: "创建时间", value: version.createTime});
            if (version.extendData) {
              this.versionData.subVoList = JSON.parse(version.extendData);
            }
          }
        });
      },

      shouldShowVersionDesc(item) {
        let versionList = this.appVersionMap[item.appId + ''];
        let versionId = item.versionId;
        if (!versionList || this.isEmpty(versionId)) {
          return true;
        }
        for (let version of versionList) {
          if (version.versionId == versionId) {
            return false;
          }
        }
        return true;
      },
      initUpdatePage() {//拿到数据渲染界面
        let deployResult = JSON.parse(this.updateDelopyNote.deployNoteResult);
        this.deployInfo.deployNoteResult.createUser = deployResult.createUser;
        this.deployInfo.deployNoteResult.bizOwner = deployResult.bizOwner;
        this.deployInfo.deployNoteStatus = this.updateDelopyNote.deployNoteStatus;
        this.deployInfo.deployNoteDesc = this.updateDelopyNote.deployNoteDesc;
        this.deployInfo.deployNoteResult.notice = deployResult.notice;
        this.deployInfo.deployNoteResult.bizName = deployResult.bizName;
        this.deployInfo.fastDeploy = this.updateDelopyNote.fastDeploy;

        //解析发布时间
        if (deployResult.deployTime) {
          if (typeof deployResult.deployTime == "string" && deployResult.deployTime.length >= 10) {
            let dateArray = deployResult.deployTime.substring(0, 10).split("-");
            this.deployInfo.deployNoteResult.deployTime = new Date(dateArray[0], --dateArray[1], dateArray[2]);
          } else if (typeof deployResult.deployTime == "number") {
            let date = new Date();
            date.setTime(deployResult.deployTime)
            this.deployInfo.deployNoteResult.deployTime = date;
          }
        }
        this.deployInfo.deployNoteResult.deployUsers = deployResult.deployUsers;
        if (deployResult.deployUsers) {
          this.deployInfo.deployNoteResult.deployUsersArray = deployResult.deployUsers.split(",");
        } else {
          this.deployInfo.deployNoteResult.deployUsersArray = [];
        }

        this.auditFlow = deployResult.auditFlow;

        //------------------组装数据----------------------------------------------
        this.deployData = [];
        this.deployInfo.deployNoteView = this.updateDelopyNote.deployNoteView
        this.isAppView = this.updateDelopyNote.deployNoteView == 0;
        this.selectDeployView = this.updateDelopyNote.deployNoteView;
        this.deployInfo.deployNoteView = this.updateDelopyNote.deployNoteView;

        let tempList = [];
        let appZoneMap = new Map();//用来记录app和zone的一对多关系
        let map = new Map();
        let tempDeployList = [];

        deployResult.deployAppModules.forEach(app => {
          if (app && app.deployInfo && app.deployInfo != 0) {
            app.deployInfo.forEach(zone => {
              let blankModule = this.getBlankModule();
              blankModule.appId = app.appId;
              blankModule.zoneCode = zone.zone;
              blankModule.versionId = app.versionId;
              blankModule.configVersion = zone.configVersion;
              blankModule.env = zone.configEnv;
              blankModule.cmdbId = app.cmdbId;
              tempList.push(blankModule);

              if (!map.has(blankModule.appId)) {
                map.set(blankModule.appId, new Set([blankModule.zoneCode]));
              } else {
                map.get(blankModule.appId).add(blankModule.zoneCode);
              }
            });
          }
        });

        this.assembleList(tempList, this.isAppView);

        //请求版本cmdb
        for (let appId of map.keys()) {
          this.getVersionList(appId);
          this.getCmdb(appId);
        }

        //环境配置中心
        for (let [appId, set] of map.entries()) {
          set.forEach(zoneCode => {
            this.getConfigList(appId, zoneCode);
          })
        }
        this.deployData = tempList;

      },
      initPage() {
        this.bizId = this.getUrlBizId();
        let urlParams = this.getUrlParams();
        if (urlParams.deployNoteId && urlParams.deployNoteId != '') {
          this.isNew = false;
          this.deployNoteId = urlParams.deployNoteId;
          this.getDeployDirList(this.deployNoteId);
        } else {
          this.isNew = true;
        }

        if (this.isNew) {
          this.deployInfo.deployNoteResult.deployUsersArray = [$utils.getCurrentUserId()];
          this.deployInfo.deployNoteResult.deployTime = new Date();
        } else {
          this.getDeployNoteDetail();
        }
      },

      assembleList(tempList, isAppView) { //组装数据

        //排序，保持输入的相对顺序
        var base1List = [];
        var base2List = [];
        var key1Name = isAppView ? "appId" : "zoneCode";
        var key2Name = !isAppView ? "appId" : "zoneCode";
        for (let item of tempList) {
          if (base1List.indexOf(item[key1Name]) == -1) {
            base1List.push(item[key1Name]);
          }
          if (base2List.indexOf(item[key2Name]) == -1) {
            base2List.push(item[key2Name]);
          }
        }
        tempList.sort((a, b) => {
          if (a[key1Name] != b[key1Name]) {
            return base1List.indexOf(a[key1Name]) - base1List.indexOf(b[key1Name])
          } else {
            return base2List.indexOf(b[key2Name]) - base2List.indexOf(b[key2Name])
          }
        });


        let lastObj = null;
        for (let i = 0; i < tempList.length; i++) {
          let curObj = tempList[i];
          if (lastObj == null || (lastObj[key1Name] != curObj[key1Name])) {
            curObj.key1Index = this.nextId();
            curObj.key2Index = this.nextId();
          } else if (lastObj[key2Name] != curObj[key2Name]) {
            curObj.key1Index = lastObj.key1Index;
            curObj.key2Index = this.nextId();
          } else {
            curObj.key1Index = lastObj.key1Index;
            curObj.key2Index = lastObj.key2Index;
          }
          curObj.key3Index = this.nextId();
          lastObj = curObj;
        }
      },

      deployNoteViewChanged() {//手动切换视图触发的事件
        this.$confirm('未保存的数据将丢失，确定切换视图？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          if (this.isNew) {
            this.deployData = [];
          } else {
            let tempList = [];
            tempList = tempList.concat(this.deployData);
            this.assembleList(tempList, !this.isAppView);
            this.deployData = tempList;
          }
          this.deployInfo.deployNoteView = this.selectDeployView;
          this.isAppView = this.deployInfo.deployNoteView == 0;
        }).catch(() => {
          if (this.selectDeployView == 0) {
            this.selectDeployView = 1;
          }else {
            this.selectDeployView = 0;
          }
        });
      },
      getLoginUserInfo() {//获取当前登陆用户信息
        $http.get($http.api.user.getLoginUserInfo).then((res) => {
          this.currentUser = res.data.systemUser;
          this.deployInfo.deployNoteResult.createUser = res.data.systemUser.userName;
          this.deployInfo.deployNoteResult.bizOwner = res.data.systemUser.userName;
          this.getDeployNoteFlowInfo();
        })
      },
      getDeployNoteFlowInfo() {//获取流程信息
        $http.get($http.api.issue.deploynoteflowinfo, {bizId: this.bizId}).then((res) => {
          this.flowData = res.data;
          let deployUserData = [];
          //取出提单人员
          res.data.fixedFlowInfo.forEach(item => {
            if (item.roleId == "BIZ_DEPLOYER") {
              this.filterDelopyUserList = this.filterDelopyUserList.concat(item.approverList);
            }
            //封网期间增加运维人员
            // if (item.roleId == "BIZ_OPERATOR") {
            //
            //   let deployUserData = [];
            //   let selectDeployUserData = [];
            //   item.approverList.forEach(item => {
            //     let curUserId = item.userId;
            //     let isExist = false;
            //     let isSelectExist = false;
            //     this.filterDelopyUserList.forEach(itemUser => {
            //       if (curUserId === itemUser.userId) {
            //         isExist = true;
            //       }
            //     });
            //     this.deployInfo.deployNoteResult.deployUsersArray.forEach(itemUserId => {
            //       if (curUserId === itemUserId) {
            //         isSelectExist = true;
            //       }
            //     });
            //     if (!isExist) {
            //       deployUserData.push(item);
            //     }
            //     if (!isSelectExist) {
            //       selectDeployUserData.push(item.userId);
            //     }
            //   });
            //   this.filterDelopyUserList = this.filterDelopyUserList.concat(deployUserData);
            //   this.deployInfo.deployNoteResult.deployUsersArray = this.deployInfo.deployNoteResult.deployUsersArray.concat(selectDeployUserData);
            // }
          });
        });
      },
      updateFlowDeployer() {//更新发布单发布人
        this.auditFlow.forEach(flow => {
          if (flow.step == '发布') {
            flow.memberName = this.deployInfo.deployNoteResult.deployUsersArray ? this.deployInfo.deployNoteResult.deployUsersArray.map(item => {
              let result = item;
              this.filterDelopyUserList.forEach(user => {
                if (item == user.userId) {
                  result = user.userName + '(' + user.userId + ')';
                }
              });
              return result;
            }).join(" ") : "";
            flow.memberIds = this.deployInfo.deployNoteResult.deployUsersArray;
          }
        })
      },

      createFlow() {
        this.auditFlow = [];
        //记录发布的id，读者的id在发布的id+1
        let deployOrderId = 0;

        this.flowData.fixedFlowInfo.forEach(flow => {

          if (flow.order == 0) {
            this.auditFlow.push({
              step: "拟制",
              stepId: flow.order,
              stageOrder: -1,
              memberName: this.currentUser.userName + '(' + this.currentUser.userId + ')',
              type: 0,
              memberIds: [this.currentUser.userId]
            });
            return;
          }

          if ((flow.order === 3 || flow.order === 2 || flow.order === 1) && this.flowData.customFlowInfo && this.flowData.customFlowInfo.length != 0) {
            let nowStageOrder = flow.order - 1;
            this.flowData.customFlowInfo.forEach(customItem => {
              if(customItem.stageOrder === nowStageOrder){
                this.auditFlow.push({
                  step: customItem.flowName,
                  stepId: customItem.id,
                  stageOrder: customItem.stageOrder,
                  memberName: customItem.approverList ? customItem.approverList.map(item => {
                    return item.showUserName;
                  }).join(" ") : "",
                  type: 1,
                  memberIds: customItem.approverList ? customItem.approverList.map(item => {
                    return item.userId;
                  }) : []
                });
              }
            })
          }

          //快速发布跳过审核流程
          if (this.deployInfo.fastDeploy == 1 && flow.order == 2) {
            return;
          }

          //补齐发布人
          if (flow.order == 3) {
            this.auditFlow.push({
              step: flow.flowName,
              stepId: flow.order,
              stageOrder: -1,
              memberName: this.deployInfo.deployNoteResult.deployUsersArray ? this.deployInfo.deployNoteResult.deployUsersArray.map(item => {
                for (let i = 0; i < this.filterDelopyUserList.length; i++) {
                  let user = this.filterDelopyUserList[i];
                  if (user.userId == item) {
                    return user.userName + '(' + user.userId + ')';
                  }
                }
                return item;
              }).join(" ") : "",
              type: 0,
              memberIds: this.deployInfo.deployNoteResult.deployUsersArray
            });
            return;
          }
          this.auditFlow.push({
            step: flow.flowName,
            stepId: flow.order,
            stageOrder: -1,
            memberName: flow.approverList ? flow.approverList.map(item => {
              return item.showUserName;
            }).join(" ") : "",
            type: 0,
            memberIds: flow.approverList ? flow.approverList.map(item => {
              return item.userId;
            }) : []
          });
        });

        //判断流程的每一步都必须有人
        let allFlowHasPerson = true;
        this.auditFlow.forEach(flow => {
          if (flow.memberIds.length == 0) {
            allFlowHasPerson = false;
            let message = flow.step + '人员为空!无法创建发布单';
            this.$message({
              message: message,
              type: 'error'
            });
            throw new Error(message);
          }
        })
        if (!allFlowHasPerson) {
          return;
        }

        //todo 公布自己组装
        this.auditFlow.push({
          step: '公布（读者）',
          stepId: 99,
          stageOrder: -1,
          memberName: "",
          type: 0,
          memberIds: [],
        });
      },
      async getCmdbIpsClick(appId, zoneCode, cmdbId) {
        if (this.isEmpty(appId) || this.isEmpty(zoneCode) || this.isEmpty(cmdbId)) {
          return "";
        }

        if (!zoneCode || zoneCode == "") {
          return [];
        }
        let app = this.getAppById(appId);
        if (app == null) {
          return null;
        }
        let params = {cmdbAppId: cmdbId, zoneCode: zoneCode, appCode: app.appCode};
        let paramsKey = appId + "_" + zoneCode + "_" + cmdbId;
        await $http.get($http.api.cmdb.cmdbIps, params).then((res) => {
          let ips = [];
          this.cmdbIpMap[paramsKey] = ips;
          let ipList = res.data;
          if (ipList && ipList.length != 0) {
            ipList.forEach(item => {
              ips.push(item.ip);
            });
            this.cmdbIpMap[paramsKey] = ips;
          } else {
            this.cmdbIpMap[paramsKey] = ['未绑定机器'];
          }
        });

        this.showCmdbIpList = this.cmdbIpMap[paramsKey];
      },
      getCmdb(appId) {
        if (!appId || appId === '') {
          return;
        }
        let key = appId + '';
        if (this.cmdbMap[key]) {
          return;
        }
        $http.get($http.api.cmdb.appcmdb, {appId: appId}).then((res) => {
          if (res.data) {
            if (res.data.length != 0) {
              res.data.forEach(cmdb => {
                cmdb.cmdbId = '' + cmdb.cmdbId;
              })
            }
            this.$set(this.cmdbMap, key, res.data)
          } else {
            this.$set(this.cmdbMap, key, [])
          }
        }).catch((e) => {
          this.$message({
            message: '获取cmdb信息失败',
            type: 'error'
          });
        });
      },

      getConfigList(appId, zoneCode) {
        if (!appId || !zoneCode) {
          return;
        }
        let params = {
          env: 'online',
          appId: appId,
          zoneCode: zoneCode
        };
        $http.get($http.api.app.listDisconf, params).then((res) => {
          if (res && res.data && res.data.apps) {
            let newObj = {};
            res.data.apps.forEach((item) => {
              newObj[item.env] = item.versions;
            });
            this.$set(this.envMap, appId + '_' + zoneCode, newObj)
          }
        }).catch((e) => {
          return true;
        });
      },
      envChanged(appIndex, zoneIndex, versionIndex, items) {
        items.configVersion = "";
      },

      getVersionList(appId) {
        if (this.appVersionMap['' + appId]) {
          this.setDefaultValues();
          return;
        }
        let params = {
          bizId: this.bizId,
          appId: appId,
          developMode: -1,
          versionTypes: 2,
          pageNum: 1,
          pageSize: 1000
        };

        $http.get($http.api.appdate.apiappversionlist, params).then((res) => {
          this.$set(this.appVersionMap, '' + appId, res.data.data.list);
          this.setDefaultValues();
        }).catch((e) => {
          this.$message({
            message: '获取应用列表失败',
            type: 'error'
          });
        });
      },
      async getAppList() {
        let params = {
          bizId: this.bizId,
          queryType: 2,
          pageNum: 1,
          pageSize: 1000
        };
        //快速发布查询出快速发布相关应用
        if (this.deployInfo.fastDeploy == 1) {
          params.fastDeploy = 1;
        }

        let result
        try {
          result = await $http.get($http.api.app.list, params)
          this.appList = result.data.list;
        } catch (e) {
          this.$message({
            message: '获取应用列表失败',
            type: 'error'
          })
        }

        return result;
      },
      getDeployNoteDetail() {
        $http.get($http.api.deploy_note.getDeployNoteDetail, {deployNoteId: this.deployNoteId}).then(res => {
          this.updateDelopyNote = res.data;
          this.initUpdatePage();
        }).catch((e) => {
          this.$message({
            message: '获取发布单信息失败，请刷新',
            type: 'error'
          });
        });
      },
      getZoneList() {
        $http.get($http.api.app.getZoneList, {env: 'online'}).then(res => {
          this.zoneList = res.data;
        });
      },
      getBizInfo() {
        if (this.isNew) {
          $http.get($http.api.biz.getBizInfo, {bizId: this.bizId}).then(res => {
            this.bizInfo = res.data;
            this.deployInfo.deployNoteResult.notice = res.data.deployDescTemp;
            this.deployInfo.deployNoteResult.bizName = res.data.bizName;
            this.deployInfo.deployNoteDesc = res.data.bizName + "_" + this.formatDate("yyyyMMddhhmmss", new Date());
          }).catch(() => {
            this.$message({
              message: '获取发布单模板失败',
              type: 'error'
            });
          });
        }

      },

      formatDate(fmt, date) { //时间格式化处理
        var o = {
          "M+": date.getMonth() + 1,                 //月份
          "d+": date.getDate(),                    //日
          "h+": date.getHours(),                   //小时
          "m+": date.getMinutes(),                 //分
          "s+": date.getSeconds(),                 //秒
          "q+": Math.floor((date.getMonth() + 3) / 3), //季度
          "S": date.getMilliseconds()             //毫秒
        };
        if (/(y+)/.test(fmt))
          fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
          if (new RegExp("(" + k + ")").test(fmt))
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
      },
      getDeployMembers() {
        let params = {
          bizId: this.bizId,
          pageNum: 1,
          pageSize: 1000,
        };
        $http.get($http.api.biz.list_biz_members, params).then((res) => {
          this.bizUserList = res.data.list;
        });
      },

      isNotEmpty(obj) {
        if (obj == null || obj == '' || obj == 0) {
          return false;
        } else {
          return true;
        }
      },
      isEmpty(obj) {
        if (obj == null || obj == '' || obj == 0) {
          return true;
        } else {
          return false;
        }
      },
      isRealEmpty(obj) {
        if (obj == null || obj == '') {
          return true;
        } else {
          return false;
        }
      },

      getAppLatestVersion(appId) {
        let appVersionList = this.appVersionMap[appId + ""];
        if (appVersionList != null && appVersionList.length != 0) {
          return appVersionList[0];
        }
        return null;
      },
      getFirstCmdb(appId) {  //获取第一个cmdb
        if (this.isNotEmpty(appId)) {
          let cmdbList = this.cmdbMap['' + appId];
          if (cmdbList && cmdbList.length != 0) {
            return cmdbList[0];
          }
        }
        return null;
      },

      getFirstZoneList() {  //获取第一个cmdb
        if (this.zoneList && this.zoneList.length != 0) {
          return this.zoneList[0];
        }
        return null;
      },

      gotoStep2() {
        this.$refs['deployInfo'].validate(async pass => {
          if (pass) {
            if (this.isNew) {
              this.createFlow();
            } else {
              this.updateFlowDeployer();
            }
            //新建发布单下一步
            this.stepFlag = "2";
          }

          await this.getAppList();
          //一键生成发布单，默认填充应用模块及版本的处理
          if (sessionStorage.getItem("DEPLOY_NOTE_ONE_CLICK_GENERATE")==='true') {
            let deployBizId = sessionStorage.getItem("DEPLOY_NOTE_BIZ_ID");
            let deployAppId = sessionStorage.getItem("DEPLOY_NOTE_APP_ID");
            let deployVersionId = sessionStorage.getItem("DEPLOY_NOTE_VERSION_ID");
            let deployVersionName = sessionStorage.getItem("DEPLOY_NOTE_VERSION_NAME");

            let module = this.deployData.filter(item => {
              return Number(deployAppId) == item.appId;
            });
            if (module.length==0) {
              module = this.addModule();
            } else {
              module = this.deployData[0];
            }
            // console.log(module)
            let appIds = this.appList.map(item => {
              return item.appId;
            });

            if (appIds.includes(Number(deployAppId))) {
              //设置默认选中的应用模块
              module.appId = Number(deployAppId);
              this.appIdChanged(module);
              //设置默认选中的版本
              module.versionId = Number(deployVersionId);
            } else {
              this.showErrorMsg("一键生成发布单时，未查询到当前业务下应用ID为" + deployAppId + "的应用");
            }

          }

        });
      },

      gotoStep1() {//新建发布单上一步
        this.stepFlag = "1";
      },

      showErrorMsg(msg) {
        this.$message({
          message: msg,
          type: 'error'
        });
      },
      //编辑保存
      saveBtn(isAutoPass) {
        if (!this.deployData || this.deployData.length == 0) {
          this.showErrorMsg("请添加发布单");
          return;
        }


        let params = this.deployInfo;
        params.bizId = this.bizId;
        let order = 1;
        let sendDeployParams = [];
        for (let i = 0; i < this.deployData.length; i++) {
          let item = this.deployData[i];

          let appId = item.appId;
          if (this.isEmpty(appId)) {
            this.showErrorMsg("请添加应用");
            return;
          }
          let appModel = this.getAppById(appId);

          let zoneCode = item.zoneCode;
          if (this.isEmpty(zoneCode)) {
            this.showErrorMsg("请选择机房");
            return;
          }

          let versionId = item.versionId;
          if (this.isEmpty(versionId)) {
            this.showErrorMsg("请选择版本");
            return;
          }

          //校验配置环境 和 配置版本
          if (this.envMap[appId + '_' + zoneCode]) {
            let hasConfig = false;
            for (let key in this.envMap[appId + '_' + zoneCode]) {
              hasConfig = true;
              break;
            }
            if (hasConfig) {
              if (this.isRealEmpty(item.env)) {
                this.showErrorMsg("请选择配置环境");
                return;
              }
              if (this.isRealEmpty(item.configVersion)) {
                this.showErrorMsg("请选择配置版本");
                return;
              }
            }
          }

          let versionModel = this.getVersionById(appId, versionId);
          let cmdbInfo = this.getCmdbIdById(appId, item.cmdbId);

          sendDeployParams.push({
            deployOrder: order++,
            appCode: appModel.appCode,
            appName: appModel.appName,
            appId: appModel.appId,
            version: versionModel.versionName,
            versionId: versionModel.versionId,
            versionDesc: versionModel.versionDesc,
            cmdbId: cmdbInfo.cmdbId,
            cmdbPath: cmdbInfo.cmdbPath,
            MD5: versionModel.targetMd5,
            repoUrl: versionModel.repoUrl,
            tester: versionModel.testPassedUser,
            configCenterAppId: appModel.configCenter,
            deployInfo: [{
              zone: zoneCode,
              configEnv: item.env,
              configVersion: item.configVersion,
            }]
          });
          params.deployNoteResult.deployAppModules = sendDeployParams;

        }

        //添加步骤
        //公布（读者）
        if (this.auditFlow.forEach((item) => {
          if (item.step == '公布（读者）') {
            item.memberName = item.memberIds ? item.memberIds.map(item => {
              for (let i = 0; i < this.bizUserList.length; i++) {
                let user = this.bizUserList[i];
                if (user.userId == item) {
                  return user.userName + '(' + user.userId + ')';
                }
              }
              return item;
            }).join(" ") : "";
          }
        })) ;
        params.deployNoteResult.auditFlow = this.auditFlow;
        this.auditFlow.forEach(item => {
          item.endTime = null;
          item.result = 0;
        });


        params.autoPass = isAutoPass;
        if (this.deployInfo.deployNoteResult.deployUsersArray) {
          params.deployNoteResult.deployUsers = this.deployInfo.deployNoteResult.deployUsersArray.join(",");
        }

        if (typeof params.deployNoteResult.deployTime != 'number') {
          params.deployNoteResult.deployTime = params.deployNoteResult.deployTime.getTime();
        }
        if (!this.isNew) {
          params.deployNoteId = this.deployNoteId;
        }
        params.uploadFileIds = this.uploadFileIds;
        // console.log("保存参数", params);
        const loading = this.$loading({
          lock: true,
          text: '处理中',
          spinner: 'el-icon-loading',
        });

        $http.post(this.isNew ? $http.api.deploy_note.createDeployNote : $http.api.deploy_note.updateDeployNote, params).then((res) => {
          loading.close();
          if(res.status==200) {
            this.$alert(isAutoPass ? '送审成功' : '保存成功', '提示', {
              confirmButtonText: '确定',
              callback: action => {
                this.goToPage(this, "deployNoteList", {bizId: this.bizId});
              }
            });
          }
        }).catch(e => {
          loading.close();
        })

      },
      getAppById(appId) {
        for (let i = 0; i < this.appList.length; i++) {
          if (this.appList[i].appId === appId) {
            return this.appList[i];
          }
        }
        if (this.isNotEmpty(appId)) {
          this.showErrorMsg("获取应用信息失败了，请重新刷新页面")
        }
      },
      getVersionById(appId, versionId) {
        let versionList = this.appVersionMap[appId + ''];
        for (let i = 0; i < versionList.length; i++) {
          if (versionList[i].versionId === versionId) {
            return versionList[i];
          }
        }
      },
      getCmdbIdById(appId, cmdbId) {
        let cmdbList = this.cmdbMap[appId + ''];
        if (cmdbList) {
          for (let i = 0; i < cmdbList.length; i++) {
            if (cmdbList[i].cmdbId == cmdbId) {
              return cmdbList[i];
            }
          }
        }
        return {};
      },
      getResultStr(result) {
        let str = '';
        if (result == 1) {
          str = '同意'
        } else if (result == 2) {
          str = '打回'
        } else if (result) {
          return result;
        }
        return str;
      },

      getPersonStr(username, time, comment) {
        let str = '';
        if (username && time) {
          str = username + ' ' + time;
          if (comment) {
            str = str + ' 打回原因:' + comment;
          }
        } else {
          return str;
        }
        return str;
      },
    },
    components: {}
  };
</script>

<style lang="scss" scoped>

  .form_item {
    height: 40px;
  }

  .el-icon-delete {
    color: #f56c6c;
    font-size: 18px;
    line-height: 20px;
  }

  .el-icon-circle-plus-outline {
    color: #409eff;
    font-size: 18px;
  }

  .el-icon-info {
    color: #409eff;
    font-size: 18px;
    line-height: 0px;
  }

  .tableshxx {
    padding: 5px 5px 5px 5px;
    height: 100%;
    border-collapse: collapse;
    border: 1px solid black;
    width: 100%;

    .backgroundColor {
      width: 480px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .backgroundColor-pop {
      width: auto;
      max-width: 500px;
    }

    .text-again {
      text-align: left !important;
      padding-left: 20px !important;
    }

    .backgroundColor:hover {
      background: #f5f7fa;
    }

    .backgroundtitle {
      width: 120px;
      height: 40px;
      border: 1px solid #e4e7ed;
      background: #f5f7fa;
    }

    .fontright {
      text-align: left;
      line-height: 20px;
      padding-right: 20px;
      padding-left: 20px;
    }

    .fontleft {
      text-align: left;
      line-height: 20px;
      padding-left: 20px;
    }
  }

  .deploy-note-table-select {
    flex: 1;
    margin-right: 5px
  }
</style>

<style lang="scss">
  #deploy-table {
    .el-table__empty-block {
      display: none !important;
    }
  }
</style>
