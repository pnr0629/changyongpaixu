<template>
  <div id="deployNoteFlow" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top"
               style="height:100%;padding-left:10px;padding-right:10px;overflow:auto;overflow-x: hidden;">
            <el-tabs v-model="activeName" class="el-tabs-wai">
              <el-tab-pane label="正常流程" name="first">
                <div class="table-box" style="border:none;">
                  <div class="issueBody">
                    <div class="headerBtn">
                      <el-button type="primary" class="mr10 mt5 fr" @click="editBtn()"
                                 v-show="showeye == 'yes' && shouldShowCreateButton">编辑
                      </el-button>
                      <el-button type="primary" class="mr10 mt5 fr" @click="saveBtn()" v-if="showeye == 'no'"
                                 :loading="btnloading">保存
                      </el-button>
                      <el-button class="ml10 mt5 fr" @click="callOffBtn()" v-if="showeye == 'no'">取消</el-button>
                    </div>

                    <div class="issueImg" v-loading.fullscreen.lock="table_loading">
                      <div class="img-td">
                        <div class="img-img">
                          <i class="el-icon-edit-outline"></i>
                          <div class="fontsize">{{personList_a.flowName}}</div>
                        </div>
                        <div class="img-name">
                          <div class="img-name-a" :style="{'width':showeye == 'yes'?'100%':'75%'}">
                            {{personList_a.roleName}}
                          </div>
                          <div class="img-name-b" @click="addBtn_td(-1, 1)" v-if="showeye == 'no'">
                            <i class="el-icon-plus"></i>
                          </div>
                        </div>
                        <div class="name-name" v-for="i in personList_a.approverList" :key="i.userId">
                          <div class="img-name-a" :title="i.showUserName"
                               :style="{'width':showeye == 'yes'?'100%':'75%'}">{{i.showUserName}}
                          </div>
                          <div class="img-name-b" @click="deleteBtn_td(i.showUserName)" v-if="showeye == 'no'">
                            <i class="el-icon-circle-close"></i>
                          </div>
                        </div>
                      </div>
                      <div class="add-img">
                        <i class="el-icon-circle-plus" v-if="showeye == 'no'" @click="addLsitBtn_a(0, -1)"></i>
                      </div>
                      <div class="add-img-td" v-for="(domain,index) in person_custom_one" :key="index">
                        <div class="img-td addlist">
                          <div class="img-img"
                               :style="{'margin-right':showeye == 'no'?'20px':'50px','border-top-right-radius':showeye == 'no'?'20px':'10px'}">
                            <i class="el-icon-error" @click="deleteFlow(0, domain.id)" v-if="showeye == 'no'"></i>
                            <i class="iconfont icon-team"></i>
                            <div class="fontsize">{{domain.flowName}}</div>
                          </div>
                          <div class="img-name">
                            <div class="img-name-a" :title='domain.roleName'
                                 :style="{'width':showeye == 'yes'?'100%':'75%'}">{{domain.roleName}}
                            </div>
                            <div class="img-name-b" @click="addBtn_td(0, domain.roleName)" v-if="showeye == 'no'">
                              <i class="el-icon-plus"></i>
                            </div>
                          </div>
                          <div class="name-name" v-for="item in domain.approverList" :key="item.index">
                            <div class="img-name-a" :title="item.showUserName"
                                 :style="{'width':showeye == 'yes'?'100%':'75%'}">{{item.showUserName}}
                            </div>
                            <div class="img-name-b" v-if="showeye == 'no'"
                                 @click="deleteBtn_for(0, {roleName:domain.roleName,showUserName:item.showUserName})">
                              <i class="el-icon-circle-close" v-if="showeye == 'no'"></i>
                            </div>
                          </div>
                        </div>
                        <div class="add-img">
                          <i class="el-icon-circle-plus" v-if="showeye == 'no'" @click="addLsitBtn_a(0, index)"></i>
                        </div>
                      </div>
                      <!-- ============================================================================     -->
                      <div class="img-td">
                        <div class="img-img">
                          <i class="el-icon-tickets"></i>
                          <div class="fontsize">{{personList_b.flowName}}</div>
                        </div>
                        <div class="img-name">
                          <div class="img-name-a" :style="{'width':showeye == 'yes'?'100%':'75%'}">
                            {{personList_b.roleName}}
                          </div>
                          <div class="img-name-b" @click="addBtn_td(-1, 2)" v-if="showeye == 'no'">
                            <i class="el-icon-plus"></i>
                          </div>
                        </div>
                        <div class="name-name" v-for="i in personList_b.approverList" :key="i.userId">
                          <div class="img-name-a" :title="i.showUserName"
                               :style="{'width':showeye == 'yes'?'100%':'75%'}">{{i.showUserName}}
                          </div>
                          <div class="img-name-b" @click="deleteBtn_sp(i.showUserName)" v-if="showeye == 'no'">
                            <i class="el-icon-circle-close"></i>
                          </div>
                        </div>
                      </div>
                      <div class="add-img">
                        <i class="el-icon-circle-plus" v-if="showeye == 'no'" @click="addLsitBtn_a(1, -1)"></i>
                      </div>
                      <div class="add-img-td" v-for="(domain,index) in person_custom_two" :key="index">
                        <div class="img-td addlist">
                          <div class="img-img"
                               :style="{'margin-right':showeye == 'no'?'20px':'50px','border-top-right-radius':showeye == 'no'?'20px':'10px'}">
                            <i class="el-icon-error" @click="deleteFlow(1, domain.id)" v-if="showeye == 'no'"></i>
                            <i class="iconfont icon-team"></i>
                            <div class="fontsize">{{domain.flowName}}</div>
                          </div>
                          <div class="img-name">
                            <div class="img-name-a" :title='domain.roleName'
                                 :style="{'width':showeye == 'yes'?'100%':'75%'}">{{domain.roleName}}
                            </div>
                            <div class="img-name-b" @click="addBtn_td(1, domain.roleName)" v-if="showeye == 'no'">
                              <i class="el-icon-plus"></i>
                            </div>
                          </div>
                          <div class="name-name" v-for="item in domain.approverList" :key="item.index">
                            <div class="img-name-a" :title="item.showUserName"
                                 :style="{'width':showeye == 'yes'?'100%':'75%'}">{{item.showUserName}}
                            </div>
                            <div class="img-name-b" v-if="showeye == 'no'"
                                 @click="deleteBtn_for(1, {roleName:domain.roleName,showUserName:item.showUserName})">
                              <i class="el-icon-circle-close" v-if="showeye == 'no'"></i>
                            </div>
                          </div>
                        </div>
                        <div class="add-img">
                          <i class="el-icon-circle-plus" v-if="showeye == 'no'" @click="addLsitBtn_a(1, index)"></i>
                        </div>
                      </div>
                      <!-- ==================================================================================== -->
                      <div class="img-td">
                        <div class="img-img">
                          <i class="el-icon-success"></i>
                          <div class="fontsize">{{personList_c.flowName}}</div>
                        </div>
                        <div class="img-name">
                          <div class="img-name-a" :style="{'width':showeye == 'yes'?'100%':'75%'}">
                            {{personList_c.roleName}}
                          </div>
                          <div class="img-name-b" @click="addBtn_td(-1, 3)" v-if="showeye == 'no'">
                            <i class="el-icon-plus"></i>
                          </div>
                        </div>
                        <div class="name-name" v-for="i in personList_c.approverList" :key="i.userId">
                          <div class="img-name-a" :title="i.showUserName"
                               :style="{'width':showeye == 'yes'?'100%':'75%'}">{{i.showUserName}}
                          </div>
                          <div class="img-name-b" @click="deleteBtn_sh(i.showUserName)" v-if="showeye == 'no'">
                            <i class="el-icon-circle-close"></i>
                          </div>
                        </div>
                      </div>
                      <!-- ========================================================================================= -->
                      <div class="add-img">
                        <i class="el-icon-circle-plus" v-if="showeye == 'no'" @click="addLsitBtn_a(2, -1)"></i>
                      </div>
                      <div class="add-img-td" v-for="(domain,index) in person_custom_thr" :key="index">
                        <div class="img-td addlist">
                          <div class="img-img"
                               :style="{'margin-right':showeye == 'no'?'20px':'50px','border-top-right-radius':showeye == 'no'?'20px':'10px'}">
                            <i class="el-icon-error" @click="deleteFlow(2, domain.id)" v-if="showeye == 'no'"></i>
                            <i class="iconfont icon-team"></i>
                            <div class="fontsize">{{domain.flowName}}</div>
                          </div>
                          <div class="img-name">
                            <div class="img-name-a" :title='domain.roleName'
                                 :style="{'width':showeye == 'yes'?'100%':'75%'}">{{domain.roleName}}
                            </div>
                            <div class="img-name-b" @click="addBtn_td(2, domain.roleName)" v-if="showeye == 'no'">
                              <i class="el-icon-plus"></i>
                            </div>
                          </div>
                          <div class="name-name" v-for="item in domain.approverList" :key="item.index">
                            <div class="img-name-a" :title="item.showUserName"
                                 :style="{'width':showeye == 'yes'?'100%':'75%'}">{{item.showUserName}}
                            </div>
                            <div class="img-name-b" v-if="showeye == 'no'"
                                 @click="deleteBtn_for(2, {roleName:domain.roleName,showUserName:item.showUserName})">
                              <i class="el-icon-circle-close" v-if="showeye == 'no'"></i>
                            </div>
                          </div>
                        </div>
                        <div class="add-img">
                          <i class="el-icon-circle-plus" v-if="showeye == 'no'" @click="addLsitBtn_a(2, index)"></i>
                        </div>
                      </div>


                      <!-- =============================================================================================== -->
                      <div class="img-td">
                        <div class="img-img">
                          <i class="el-icon-upload"></i>
                          <div class="fontsize">{{personList_d.flowName}}</div>
                        </div>
                        <div class="img-name-fb">
                          <p>{{personList_d.roleName}}</p>
                        </div>
                      </div>

                      <!-- ======================== -->
                    </div>
                  </div>
                </div>
              </el-tab-pane>
              <el-tab-pane label="新机房部署流程" name="second">
                <div class="table-box">
                  <div class="table-box-top" style="height:100%;">
                    <p style="margin: 2px 0">
                      MO其他文件：<a target="_blank"
                                href="http://mo.adc.com/Home/ProcessCenter/ProcessPortal/ProcessList?procSetID=4">http://mo.adc.com/Home/ProcessCenter/ProcessPortal/ProcessList?procSetID=4</a><br/>
                      审核：团队负责人<br/>
                      批准：叶明亮、业务运维<br/>
                      读者：张政起、张中山、刘彤庆、基础技术团队<br/>
                      <br/>
                      标题：xxx项目 在 xxx机房 窗口期申请<br/>
                      内容：<br/>
                      现申请 [xxxx1/xxxx2] 项目在 [xxxx1/xxxx2]机房 开始部署，时间为：xxxx年xx月xx日 —— xxxx年xx月xx日。已确定：<br/>
                      &nbsp;&nbsp;1.该机房属于新机房，部署时，不会有流量进入<br/>
                      <br/>
                    </p>
                    <el-table :data="bizPeriodList" height="100%" style="width: 35%">
                      <el-table-column prop="deployUnit" label="单元"></el-table-column>
                      <el-table-column label="操作">
                        <template slot-scope="scope">
                          <el-button v-if="shouldShowDeployButton" type="primary" @click="showDeployDialog(scope.row)">
                            发布
                          </el-button>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </div>
              </el-tab-pane>
              <el-tab-pane label="快速发布" name="third">
                <div class="ser-box" style="height:100%;">
                  <div class="table-box-top server-box">
                    <p style="margin: 2px 0">
                      MO其他文件：<a target="_blank"
                                href="http://mo.adc.com/Home/ProcessCenter/ProcessPortal/ProcessList?procSetID=4">http://mo.adc.com/Home/ProcessCenter/ProcessPortal/ProcessList?procSetID=4</a><br/>
                      审核：团队负责人<br/>
                      批准：叶明亮<br/>
                      读者：张政起、张中山、刘彤庆、基础技术团队<br/>
                      <br/>
                      标题：开通哥伦布系统快速发布<br/>
                      内容：<br/>
                      现申请开通 [xxxx1/xxx2] 应用在哥伦布系统启用快速发布。已确定：<br/>
                      &nbsp;&nbsp;1. 该应用属于 支持类 应用，不会对线上业务产生直接影响；<br/>
                      &nbsp;&nbsp;2. 我已知悉快速发布将跳过运维审核步骤。<br/>
                    </p>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>


    <el-dialog :title=titleIssue :visible.sync="dialogVisible" class="el-dialog-640w"
               :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="issueinfoname" class="mt10" ref="issueinfoname" label-width="100px">
          <el-form-item label="姓名/工号" prop="userName" :rules="[{ required: true, message: '不能为空',trigger:'blur'}]">
            <el-select v-model="issueinfoname.selectUserList" filterable placeholder="请选择" multiple filter
                       style="width:100%;">
              <el-option
                v-for="item in vals==3?bizOpsMemberList:options"
                :key="item.userId"
                :label="item.userName+' ('+item.userId+')'"
                :value="item.userId">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="callOff">关闭</el-button>
                <el-button type="primary" @click="submitBtn">保存</el-button>
            </span>
    </el-dialog>


    <el-dialog title="新增流程" :visible.sync="dialogVisible_a" class="el-dialog-400w" :before-close="closeAddFlowDialog"
               :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="issueinfoname_a" class="mt10" ref="issueinfoname_a" label-width="60px" @submit.native.prevent>
          <el-form-item label="名称" prop="flowName" :rules="rules.flowName">
            <el-input placeholder="请输入内容" v-model="issueinfoname_a.flowName" clearable></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="closeAddFlowDialog">关闭</el-button>
                <el-button type="primary" @click="submitBtnAddCustomFlow">保存</el-button>
            </span>
    </el-dialog>


    <el-dialog title='发布窗口' :visible.sync="deployDialogVisible" fullscreen
               :before-close="handleCloseDeploy" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box" style="padding:0px 15px !important;">
        <div style="height: 100%;overflow:auto;overflow-x:hidden;">
          <div style="margin-top: 15px;">
            <el-tabs v-model="deplyActiveAppId" type="border-card" class="el-tabs-wai" @tab-click="showPaaSContent">
              <el-tab-pane :key="item.appCode" :label="item.appCode" :name="item.appId+''" v-for="item in showAppList">
              </el-tab-pane>
              <iframe :src="delopySrc" id="passIframe" width="100%" :style="'height: '+getHeight()"></iframe>
            </el-tabs>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  // import Distpicker from 'v-distpicker'
  import Qs from 'qs'

  export default {
    name: "deployNoteFlow",
    data() {
      let isFlowNameAvailable = (rule, value, callback) => {
        var a = new Array("$", "@", "#", "!", "~", "`", "^", "&", "*", " ");
        for (let i = 0; i < a.length; i++) {
          if (value.indexOf(a[i]) >= 0) {
            callback(new Error("不能包含空格和特殊字符"));
            return;
          }
        }
        callback();
      };
      return {
        bizId: 0,
        bizOpsMemberList: [],
        btnloading: false,
        shadeBtn: false,
        modaltobody: false,
        shouldShowCreateButton: false,
        shouldShowDeployButton: false,
        dialogVisible: false,
        dialogVisible_a: false,
        deployDialogVisible: false,
        titleIssue: '',
        addFlowIndex: -1,
        addStageIndex: -1,
        issueinfoname: {selectUserList: []},
        issueinfoname_a: {flowName: ""},
        list: [],
        delopySrc: '',
        personList_a: {},
        personList_b: {},
        personList_c: {},
        personList_d: {},
        personList_f: [],
        person_custom_one: [],
        person_custom_two: [],
        person_custom_thr: [],
        vals: '',
        showeye: 'yes',
        options: [],
        activeName: 'first',
        deplyActiveAppId: '',
        issueInfo: {},
        personList: {},
        table_loading: false,
        bizPeriodList: [],
        showAppList: [],
        rules: {
          flowName: [{required: true, message: '名称不能为空'}, {validator: isFlowNameAvailable, trigger: 'blur'}],
        },
        deployInfo: []
      };
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this.shouldShowCreateButton = this.authFunction("FUNC_BIZ_FLOW_SAVE", 1)
      this.shouldShowDeployButton = this.authFunction("FUNC_BIZ_FAST_DEPLOY", 1)
      this.getpage();
      this.getpagebiz();
      this.getBizPeriodList();
      this.getBizOpsMembers();

    },

    methods: {
      getBizOpsMembers() {
        $http.get($http.api.biz.listSysOpeMembers, {bizId: this.bizId,}).then((res) => {
          this.bizOpsMemberList = res.data;
        });
      },

      getHeight() {
        return window.innerHeight * 0.75 + 'px';
      },
      showPaaSContent() {
        let formData = new FormData();
        formData.append("appId", this.deplyActiveAppId);
        formData.append("env", 'online');
        formData.append("deployInfo", JSON.stringify([{
          zone: this.deployInfo.deployCode,
          // configEnv: 'online',
          // configVersion: '',
          instances: []
        }]));
        $http.post($http.api.deploy_note.getPaaSLink, formData).then(res => {
          this.delopySrc = encodeURI(res.data)
        }).catch(e => {
          this.delopySrc = "";
        })
      },
      showDeployDialog(deployInfo) {//显示快速发布pass弹窗
        this.showAppList = [];
        this.delopySrc = "";
        this.deployInfo = deployInfo;
        let bizId = deployInfo.bizId;
        $http.get($http.api.app.list, {
          bizId: bizId,
          queryType: 1,
          pageNum: 1,
          pageSize: 1000
        }).then((res) => {
          if (res.status == 200) {
            this.showAppList = res.data.list;
            if (this.showAppList && this.showAppList.length != 0) {
              this.deployDialogVisible = true;
              this.deplyActiveAppId = this.showAppList[0].appId + '';
              this.showPaaSContent();//默认选中第一个
            }
          }

        })
      },
      handleCloseDeploy() {
        this.deployDialogVisible = false;
      },
      getBizPeriodList() {
        $http.get($http.api.deploy_note.getBizPeriodList, {bizId: this.bizId}).then((res) => {
          this.bizPeriodList = res.data;
        });
      },
      //首次进入模块加载的人员数据
      getpage() {
        this.table_loading = true;
        this.getDeployFlow();
        this.table_loading = false;
      },

      //获取业务成员信息
      getpagebiz() {
        $http.get($http.api.issue.bizlistbizmembers, {bizId: this.bizId, pageNum: 1, pageSize: -1}).then((res) => {
          this.options = res.data.list;
        })
      },

      //获取业务成员信息
      getDeployFlow() {
        $http.get($http.api.issue.deploynoteflowinfo, {bizId: this.bizId}).then((res) => {
          this.personList = res.data;
          this.personList_a = this.personList.fixedFlowInfo[0];
          this.personList_b = this.personList.fixedFlowInfo[1];
          this.personList_c = this.personList.fixedFlowInfo[2];
          this.personList_d = this.personList.fixedFlowInfo[3];
          this.personList_f = this.personList.customFlowInfo;
          this.person_custom_one = [];
          this.person_custom_two = [];
          this.person_custom_thr = [];
          this.personList_f.forEach((item, index) => {
            if (item.stageOrder === 0) {
              this.person_custom_one.push(this.personList_f[index])
            }else if(item.stageOrder === 1){
              this.person_custom_two.push(this.personList_f[index])
            }else{
              this.person_custom_thr.push(this.personList_f[index])
            }
          })
        })
      },


      //点击加号打开弹窗
      addBtn_td(stageIndex, val) {
        this.addStageIndex = stageIndex;
        this.issueinfoname.selectUserList = [];
        this.vals = val;
        if (val == '1') {
          this.titleIssue = '添加提单人员';
        } else if (val == '2') {
          this.titleIssue = '添加审批人员';
        } else if (val == '3') {
          this.titleIssue = '添加审核人员';
        } else if (val == '4') {
          this.titleIssue = '添加发布人员'
        } else {
          this.titleIssue = '添加人员';
        }
        this.dialogVisible = true;

      },

      //关闭弹窗
      handleClose() {
        this.dialogVisible = false;
      },

      //弹窗确定
      submitBtn() {
        let selectIdUserList = this.issueinfoname.selectUserList;//id list
        let userList = this.vals == 3 ? this.bizOpsMemberList : this.options;
        if (!selectIdUserList || selectIdUserList.length == 0 || !userList || userList.length === 0) {
          return;
        }
        let person_custom = this.getPersonCustom(this.addStageIndex);
        var addList = [];
        for (let i = 0; i < selectIdUserList.length; i++) {
          let userId = selectIdUserList[i]
          for (let i = 0; i < userList.length; i++) {
            let user = userList[i]
            if (userId == user.userId) {
              addList.push({
                userName: user.userName,
                userId: user.userId,
                showUserName: user.userName + '(' + user.userId + ')',
              })
              break;
            }
          }
        }
        if (this.vals == '1') {
          this.addPersonToList(this.personList_a, addList);
        } else if (this.vals == '2') {
          this.addPersonToList(this.personList_b, addList);
        } else if (this.vals == '3') {
          this.addPersonToList(this.personList_c, addList);
        } else if (this.vals == '4') {
          this.addPersonToList(this.personList_d, addList);
        } else {
          if (person_custom.length > 0 && addList.length != 0) {
            for (let i = 0; i < addList.length; i++) {
              var person = addList[i];
              person_custom.forEach((item, index) => {
                if (item.roleName == this.vals) {
                  if (item.approverList.length == 0) {
                    item.approverList.push(person);
                  } else if (item.approverList.length > 0) {
                    var flag = false;
                    item.approverList.forEach((i, index_s) => {
                      if (i.userId == person.userId) {
                        flag = true;
                      }
                    })
                    if (flag == false) {
                      item.approverList.push(person);
                    }
                  }
                }
              })
            }
            this.setPersonCustom(person_custom, this.addStageIndex);
          }
        }
        this.handleClose();
      },

      addPersonToList(personList, addList) {
        if (addList && addList.length != 0) {
          for (let i = 0; i < addList.length; i++) {
            let person = addList[i];
            if (personList.approverList.length == 0) {
              personList.approverList.push(person);
            } else if (this.personList_a.approverList.length > 0) {
              var flag = false;
              personList.approverList.forEach((item) => {
                if (item.userId == person.userId) {
                  flag = true;
                }
              })
              if (flag == false) {
                personList.approverList.push(person);
              }
            }
          }

        }
      },

      //弹窗取消按钮
      callOff() {
        this.handleClose();
      },


      //提单删除按钮
      deleteBtn_td(val) {
        this.personList_a.approverList.forEach((item, index) => {
          if (item.showUserName == val
          ) {
            this.personList_a.approverList.splice(index, 1);
          }
        })
      },

      //审批删除按钮
      deleteBtn_sp(val) {
        this.personList_b.approverList.forEach((item, index) => {
          if (item.showUserName == val
          ) {
            this.personList_b.approverList.splice(index, 1);
          }
        })
      },

      //审核删除按钮
      deleteBtn_sh(val) {
        this.personList_c.approverList.forEach((item, index) => {
          if (item.showUserName == val
          ) {
            this.personList_c.approverList.splice(index, 1);
          }
        })
      },

      //发布删除按钮
      deleteBtn_fb(val) {
        this.personList_d.forEach((item, index) => {
          if (item.name == val) {
            this.personList_d.splice(index, 1);
          }
        })
      },


      //编辑按钮
      editBtn() {
        this.showeye = 'no';
      },

      //保存按钮
      saveBtn() {
        this.btnloading = true;
        this.personList_f = [];
        this.person_custom_one.forEach((item, index) => {
          item.order = index;
        });
        this.person_custom_two.forEach((item, index) => {
          item.order = index;
        });
        this.person_custom_thr.forEach((item, index) => {
          item.order = index;
        });
        this.personList_f = this.person_custom_one.concat(this.person_custom_two);
        this.personList_f = this.personList_f.concat(this.person_custom_thr);
        var params = {
          bizId: this.bizId,
          fixedFlowInfo: [this.personList_a, this.personList_b, this.personList_c, this.personList_d],
          customFlowInfo: this.personList_f,
        }
        this.showeye = 'yes';
        $http.post($http.api.issue.deploynotesaveflowinfo, params).then((res) => {
          if (res.status == 200) {
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          } else if (res.status == 110) {
            this.$message({
              message: '保存失败',
              type: 'error'
            })
          }

        })
        this.btnloading = false;
      },

      //取消按钮
      callOffBtn() {
        this.showeye = 'yes';
        this.getDeployFlow();
      },
//   =========================================================
      //新增打开弹窗
      addLsitBtn_a(stageIndex, index) {
        this.addFlowIndex = index;
        this.addStageIndex = stageIndex;
        this.issueinfoname_a.flowName = '';
        this.dialogVisible_a = true;
      },


      //新增创建发布流程关闭弹窗
      closeAddFlowDialog() {
        this.dialogVisible_a = false;
        this.issueinfoname_a.name = '';
      },

      getPersonCustom(stageIndex){
        let person_custom = [];
        if(stageIndex == 0){
          person_custom = this.person_custom_one;
        }else if(stageIndex == 1){
          person_custom = this.person_custom_two;
        }else{
          person_custom = this.person_custom_thr;
        }
        return person_custom;
      },

      setPersonCustom(person_custom, stageIndex){
        if(stageIndex === 0){
          this.person_custom_one = person_custom;
        }else if(stageIndex === 1){
          this.person_custom_two = person_custom;
        }else{
          this.person_custom_thr = person_custom;
        }
      },

      //弹窗确定
      submitBtnAddCustomFlow() {
        let person_custom = this.getPersonCustom(this.addStageIndex);
        this.$refs['issueinfoname_a'].validate(pass => {
          if (pass) {
            var json = {
              stageOrder: this.addStageIndex,
              flowName: this.issueinfoname_a.flowName,
              roleName: this.issueinfoname_a.flowName + '人员',
              createUserId: $utils.getCurrentUserId(),
              approverList: []
            };
            var flag = false;
            let all_custom = this.person_custom_one.concat(this.person_custom_two).concat(this.person_custom_thr);
            all_custom.push({flowName:'提单'});
            all_custom.push({flowName:'审批'});
            all_custom.push({flowName:'审核'});
            all_custom.push({flowName:'发布'});
            all_custom.forEach((item, index) => {
              if (item.flowName === this.issueinfoname_a.flowName) {
                this.$message({
                  message: '此流程已经存在,不可重复创建。',
                  type: 'warning'
                });
                flag = true;
              }
            });
            if (flag === false) {
              json['order'] = person_custom.length;
              person_custom.splice(this.addFlowIndex + 1, 0, json)
            }

            //重新设置order
            for (let i = 0; i < person_custom.length; i++) {
              person_custom[i].order = i;
            }
            this.setPersonCustom(person_custom, this.addStageIndex);
            this.closeAddFlowDialog();
          }
        })
      },


      //删除流程
      deleteFlow(stageOrder, val) {
        let person_custom = this.getPersonCustom(stageOrder);
        this.$confirm('此操作将删除此发布流程, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          person_custom.forEach((item, index) => {
            if (item.id == val
            ) {
              person_custom.splice(index, 1);
            }
          })
          this.setPersonCustom(person_custom, stageOrder);
        }).catch(() => {
        });
      },

      //删除人员
      deleteBtn_for(stageOrder, val) {
        let person_custom = this.getPersonCustom(stageOrder);
        person_custom.forEach((i, index_a) => {
          if (val.roleName == i.roleName
          ) {
            i.approverList.forEach((j, index) => {
              if (j.showUserName == val.showUserName
              ) {
                var a = index;
                i.approverList.splice(a, 1);
              }
            })
          }

        })
        this.setPersonCustom(person_custom, stageOrder);
      },

      //头部一级菜单切换控制侧边栏菜单
      handleSelect(val) {
        if (val == '1') {
          this.goToPage(this, 'deployNoteList');
        } else if (val == '2') {
          this.goToPage(this, 'deployNoteFlow');
        }
      },


    }
    ,
    components: {}
  }
  ;
</script>

<style lang="scss" scoped>
  .issueBody {
    // height:100%;
    // border: 1px solid #E8E8E8;
    .headerBtn {
      height: 40px;
      // border: 1px solid #E8E8E8;
      margin-bottom: 10px;
    }

    .issueImg {
      height: 100%;
      margin: 20px;
      // overflow: hidden;
      // overflow: auto;

      .img-td {
        display: inline-block;
        min-height: 380px;
        width: 200px;
        border: 1px solid #E8E8E8;
        margin-bottom: 20px;
        padding-bottom: 10px;
        // vertical-align: -webkit-baseline-middle;
        vertical-align: text-top;

        .img-img {
          display: inline-block;
          margin-left: 50px;
          margin-top: 20px;
          margin-bottom: 20px;
          width: 100px;
          height: 100px;
          background: #67C23A;
          border-radius: 10px;

          .el-icon-edit-outline {
            font-size: 50px;
            color: #fff;
            margin-left: 25px;
            margin-top: 10px;
          }

          .el-icon-tickets {
            font-size: 50px;
            color: #fff;
            margin-left: 25px;
            margin-top: 10px;
          }

          .el-icon-success {
            font-size: 50px;
            color: #fff;
            margin-left: 25px;
            margin-top: 10px;
          }

          .iconfont {
            font-size: 50px;
            color: #fff;
            margin-left: 25px;
            margin-top: 0;
            width: 50px;
            height: 50px;
            display: inline-block;
          }

          .el-icon-upload {
            font-size: 50px;
            color: #fff;
            margin-left: 25px;
            margin-top: 10px;
          }

          .fontsize {
            margin-top: 5px;
            text-align: center;
            font-size: 20px;
            color: #fff;
            padding: 0 10px 0 10px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }
        }

        .img-img:hover {
          box-shadow: 1px 1px 2px #437356;
        }

      }

      .add-img-td {
        display: inline-block;
        width: 256px;
        height: 380px;
        margin-bottom: 20px;
        vertical-align: top;

        .img-td {
          display: inline-block;
          min-height: 380px;
          width: 200px;
          border: 1px solid #E8E8E8;
          vertical-align: middle;

          .el-icon-error {
            float: right;
            font-size: 20px;
            color: #F56C6C;
            cursor: pointer;
          }

          .el-icon-error:hover {
            color: #E6A23C;
            // box-shadow: 1px 1px 2px #437356;
          }

          .img-img {
            display: inline-block;
            margin-left: 50px;
            margin-top: 20px;
            margin-bottom: 20px;
            width: 100px;
            height: 100px;
            background: #67C23A;

            .el-icon-picture {
              font-size: 50px;
              color: #fff;
              margin-left: 25px;
              margin-top: 10px;
            }
          }

        }
      }

      .img-name {
        height: 40px;
        border: 1px solid #E8E8E8;
        margin-left: 10px;
        margin-right: 10px;
        background: #f7f7f7;

        .img-name-a {
          text-align: center;
          padding-top: 9px;
          display: inline-block;
          height: 100%;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;

        }

        .img-name-b {
          border-left: 1px solid #E8E8E8;
          display: inline-block;
          width: 22%;
          height: 100%;
          vertical-align: top;

          .el-icon-plus {
            font-size: 30px;
            margin-left: 4px;
            margin-top: 4px;
            color: #909399;
          }

          .el-icon-plus:hover {
            color: #409EFF;
            cursor: pointer;
          }
        }
      }

      .img-name-fb {
        min-height: 60px;
        border: 1px solid #E8E8E8;
        margin-left: 10px;
        margin-right: 10px;
        padding: 10px 10px 0 10px;
        color: #E6A23C;
        text-indent: 2em;;
      }

      .name-name {
        height: 30px;
        border: 1px solid #E8E8E8;
        margin-left: 10px;
        margin-right: 10px;

        .img-name-a {
          text-align: center;
          padding-top: 4px;
          display: inline-block;
          height: 100%;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }

        .img-name-b {
          border-left: 1px solid #E8E8E8;
          display: inline-block;
          width: 22%;
          height: 100%;
          vertical-align: top;

          .el-icon-circle-close {
            font-size: 20px;
            margin-left: 10px;
            margin-top: 4px;
            color: #F56C6C;
            cursor: pointer;
          }

          .el-icon-circle-close:hover {
            color: #E6A23C;
          }
        }
      }

      .add-img {
        display: inline-block;
        widht: 50px;
        width: 50px;
        height: 380px;
        vertical-align: top;

        .el-icon-circle-plus {
          font-size: 39px;
          color: #E6A23C;
          margin-left: 5px;
          cursor: pointer;
        }

      }

      .addlist {
        vertical-align: text-top;
        margin-bottom: 20px;
      }

    }
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .table-box {
    .server-box {
      .header-a {
        .zjlb {
          margin-left: 10px;
          margin-bottom: 5px;
          margin-right: 10px;
          display: inline-block;
        }
      }

      .el-tabs--top {
        border: 1px solid #e4e7ed;
      }

      .el-progress {
        width: 70%;
        float: left;
        margin-top: 4px;
      }

    }
  }
</style>
