<template>
  <div id="deployNoteList" class="content-outer-box">
    <div class="white-box table-outer-box">
      <div class="mt0">
        <div class="table-box-top"
             style="height:100%;padding-left:10px;padding-right:10px;overflow:auto;overflow-x: hidden;position: relative">
          <el-button style="position: absolute; right:10px; top: 3px; z-index: 9" v-if="isShowCreateButton"
                     @click="createNewDeploy" type="primary">新建发布单
          </el-button>

          <el-tabs v-model="activeName" class="el-tabs-wai" @tab-click="tabChange">
            <el-tab-pane :name="tab.type" v-for="tab in tabList" :key="tab.type">
              <span slot="label">{{(parseInt(tab.type) > 5 ? '待' : '') + tab.buttonName}}
                <el-badge :value="tab.typeNum"
                          :hidden="tab.typeNum<=0 || tab.buttonName == '全部' || tab.buttonName == '已完成' || tab.buttonName == '待送审'"></el-badge>
              </span>

              <div class="table-outer-box" style="height:100%;">
                <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
                  <div class="table-box-top">
                    <el-table
                      :class="{'el-table-left-none':getTabData.length == 0}"
                      :border="true"
                      :data="getTabData">
                      <el-table-column prop="deployNoteDesc" label="标题" min-width="200">
                      </el-table-column>

                      <el-table-column prop="updateTime" label="更新时间" min-width="100" v-if="tab.type!=-1">
                      </el-table-column>

                      <el-table-column prop="createTime" label="创建时间" min-width="100" v-if="tab.type==-1">
                      </el-table-column>
                      <el-table-column prop="createUser" label="申请人" min-width="100">
                        <template slot-scope="scope">
                          {{getShowUserNameByUserId(scope.row.createUser)}}
                        </template>
                      </el-table-column>
                      <el-table-column label="状态" width="100">
                        <template slot-scope="scope">
                          {{getStatusDesc(scope.row.deployNoteStatus)}}
                        </template>
                      </el-table-column>
                      <el-table-column label="应用模块" min-width="300">
                        <template slot-scope="scope">
                          {{(!scope.row.expand &&
                          scope.row.appName.length>55)?(scope.row.appName.substring(0,55)+'...'):scope.row.appName}}
                          <span class="c-blue cp" v-show="!scope.row.expand && scope.row.appName.length>55"
                                @click="showMore(scope.row)">查看全部</span>
                          <span class="c-blue cp" v-show="scope.row.expand" @click="showLess(scope.row)">收起</span>
                        </template>
                      </el-table-column>
                      <el-table-column width="260" label="操作">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="viewDeployNote(scope.row)">查看</span>
                          <span class="c-blue cp" @click="editDeployNote(scope.row)"
                                v-if="isButtonShow(scope.row,'edit')">编辑</span>
                          <span class="c-blue cp" @click="sendDeployNoteToFlow(scope.row)"
                                v-if="isButtonShow(scope.row,'send')">送审</span>
                          <span class="c-blue cp" @click="reviewDeployNote(scope.row)"
                                v-if="isButtonShow(scope.row,'review')">{{getStepDesc(scope.row)}}</span>
                          <span class="cp" :class="canDeploy(scope.row)?'c-blue':'c-gray'"
                                :title="canDeploy(scope.row)?'':'未到设定的发布时间'"
                                v-if="isButtonShow(scope.row,'deploy')"
                                @click="release(scope.row)">发布</span>
                          <span class="cp"
                                :class="canDeploy(scope.row)?'c-blue':'c-gray'"
                                v-if="isButtonShow(scope.row,'finish')"
                                :title="canDeploy(scope.row)?'':'未到设定的发布时间'"
                                @click="completeDeploy(scope.row)">发布完成</span>
                          <span class="c-blue cp" v-if="isButtonShow(scope.row,'delete')"
                                @click="deleteDeployNote(scope.row)">删除</span>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                  <div class="table_b_f_b">
                    <el-pagination
                      class="fr mr10"
                      style="margin-top: 9px;"
                      v-show="dataMap[activeName].total!=0"
                      @size-change="handleSizeChange"
                      @current-change="handleCurrentChange"
                      :current-page="dataMap[activeName].pageNum"
                      :page-sizes="[20, 50, 100]"
                      :page-size="dataMap[activeName].pageSize"
                      layout="total, sizes, prev, pager, next, jumper"
                      :total="dataMap[activeName].total">
                    </el-pagination>
                  </div>
                </div>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>

    <!-- 查看弹窗 -->
    <el-dialog :title="isViewDeployNoteForm?'查看发布单':'审核发布单'" id="lookDialog" class="el-dialog-1180w"
               :before-close="handleClose"
               :visible.sync="look_dialogVisible" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="objInfo" ref="objInfo">
          <el-row :gutter="10" class="mt10">
            <el-col :span="8">
              <el-form-item class='mb15' label="发布标题" label-width="70px">
                <el-input v-model="showDeployNoteForm.deployNoteDesc" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class='mb15' label="项目" label-width="70px">
                <el-input v-model="showDeployNoteForm.bizName" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class='mb15' label="申请人" label-width="70px">
                <el-input v-model="showDeployNoteForm.createUser" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class='mb15' label="发布类型" label-width="70px">
                <el-input v-model="showDeployNoteForm.fastDeployStr" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item class='mb15' label="发布时间" label-width="70px">
                <el-input v-model="showDeployNoteForm.deployTime" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item class='mb15' label="发布说明" label-width="70px">
                <el-input v-model="showDeployNoteForm.notice" type="textarea" :rows="8" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div style="margin-bottom: 10px">
            <div class="form-iterm-box">
              <el-upload class="upload-demo" action="uploadActionUrl" v-bind:action="uploadActionUrl"
                         :data="upoladID" :on-success="handleUploadSuccess" :on-error="handleUploadError" accept :show-file-list="false" :auto-upload="true">
                <span size="small" type="primary" class="c-blue" style="line-height:22px;">上传附件</span>
              </el-upload>
            </div>
            <el-row :gutter="10">
              <el-col v-for="(item,index) in uploadFiles" :key="index" style="background-color: rgba(214,214,214,0.15); margin-right: 5px; width: 200px">
                <span :title="item.fileName" style="display :inline-block;width: 55%;overflow: hidden;textOverflow: ellipsis;whiteSpace: nowrap">{{ item.fileName }}</span>
                <span class="c-blue cp" @click="downloadDeployBtn(item.id)" style="float: right">下载</span>
                <span class="c-blue cp" v-if="currentUserId === item.userId" @click="deleteDeployBtn(item.id)" style="float: right; padding-right: 3px">删除</span>
              </el-col>
            </el-row>
          </div>
        </el-form>
        <el-tabs type="border-card">
          <el-tab-pane label="发布应用信息">
            <div class="table-box-top" style="height:100%;">
              <el-table
                border
                :span-method="spanMethod"
                :data="showDeployNoteForm.deployList"
                height="100%"
                style="width: 100%;height: 100%;overflow:auto;border-bottom:none;">
                <el-table-column
                  :prop="showDeployNoteForm.isAppView?'appCode':'zoneName'"
                  :label="showDeployNoteForm.isAppView?'应用模块':'机房（单元）'">
                </el-table-column>
                <el-table-column
                  :prop="!showDeployNoteForm.isAppView?'appCode':'zoneName'"
                  :label="showDeployNoteForm.isAppView?'机房（单元）':'应用模块'">
                </el-table-column>
                <el-table-column prop="version" label="版本" min-width="160">
                </el-table-column>
                <el-table-column prop="versionDesc" label="版本描述">
                </el-table-column>
                <el-table-column prop="configEnv" label="配置环境">
                </el-table-column>
                <el-table-column prop="configVersion" label="配置版本">
                </el-table-column>
                <el-table-column prop="cmdbPath" label="CMDB">
                </el-table-column>
                <el-table-column prop="tester" label="测试人员">
                </el-table-column>
              </el-table>
            </div>
          </el-tab-pane>
          <el-tab-pane label="审核信息">
            <div class="table-box-top" style="height:100%;">
              <table class="tablegjcxlb white-box" style="border:1px solid #000;">
                <tr v-for="item in showDeployNoteForm.auditFlow">
                  <td class="fontright backgroundtitle">{{item.step}}</td>
                  <td class="fontright backgroundColor text_agin" style="text-align: left;padding-left: 10px">
                    {{item.memberName}}
                  </td>
                  <td class="fontright backgroundtitle">{{getResultStr(item.result)}}</td>
                  <td class="fontright backgroundColor text_agin" style="text-align: left;padding-left: 10px">
                    {{getPersonStr(item.auditor,item.endTime, item.comment)}}
                  </td>
                </tr>
              </table>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button type="primary" class="fr" style="margin-left: 5px;" v-if="!isViewDeployNoteForm"
                     @click="passDeployNoteToFlow">同意</el-button>
          <el-button type="danger" class="fr" style="margin-left: 15px;" v-if="!isViewDeployNoteForm"
                     @click="rejectBtn()">驳回</el-button>

          <el-button class="fr" @click="handleClose()">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 审批 审核 重审驳回弹窗 -->
    <el-dialog title='驳回' id="yyDialog_a" :visible.sync="dialogVisible_fbd"
               class="el-dialog-400w el-dialog-26h issuedialog" :before-close="handleClose_fbd"
               :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box" style="padding:0px 15px !important;">
        <div style="height: 100%;overflow:auto;overflow-x:hidden;">
          <div style="margin-top: 15px;">
            <el-form label-width="70px">
              <el-form-item style="margin-top:20px;" label="驳回理由">
                <el-input placeholder="请输入内容" v-model="rejectReason" type="textarea" :rows="6"></el-input>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button @click="handleClose_fbd">取消</el-button>
          <el-button type="primary" @click="rejectDeployNoteToFlow">确定</el-button>
      </span>
    </el-dialog>

    <!-- 发布日志弹窗 -->
    <!--<el-dialog :title="deployDetailTitle" id="dialog_deploy_detail" :visible.sync="dialog_deploy_detail"
               class="el-dialog-1180w el-dialog-26h issuedialog" :before-close="handleCloseDeployDetail"
               :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
        <div class="table-box-top">
          <div class="table-box" style="margin-bottom: 10px">
            <el-table :data="deployDetailList.slice((deployDetailData.pageNum-1)*deployDetailData.pageSize,
                          deployDetailData.pageNum*deployDetailData.pageSize)" border
                      :class="{'el-table-left-none':deployDetailList.length == 0}">
              <el-table-column prop="appCode" label="应用ID" min-width="100">
                <template slot-scope="scope">
                  {{scope.row.appCode}}
                </template>
              </el-table-column>
              <el-table-column prop="versionName" label="版本" min-width="180">
                <template slot-scope="scope">
                  {{scope.row.versionName}}
                </template>
              </el-table-column>
              <el-table-column prop="zoneName" label="机房" min-width="100">
                <template slot-scope="scope">
                  {{scope.row.zoneName}}
                </template>
              </el-table-column>
              <el-table-column label="首次发布" min-width="150">
                <template slot-scope="scope">
                  <span>{{scope.row.firstDeployTime}}</span>
                  <br>
                  <span>{{scope.row.firstUserId}}</span>
                </template>
              </el-table-column>
              <el-table-column label="最后发布" min-width="150">
                <template slot-scope="scope">
                  <span>{{scope.row.lastDeployTime}}</span>
                  <br>
                  <span>{{scope.row.lastUserId}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="deployInstanceCount" label="实例数/机器数/成功率" min-width="150">
                <template slot-scope="scope">
                  {{scope.row.deployInstanceCount}}/{{scope.row.deployIpCount}}/{{getSuccessRate(scope.row)}}
                </template>
              </el-table-column>
              <el-table-column label="发布详情" min-width="180">
                <template slot-scope="scope">
                  <span v-html="getAbnormalState(scope.row)"></span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="pageModule" style="height: 35px">
            <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleDeploySizeChange"
                           @current-change="handleDeployPageChange"
                           :current-page="deployDetailData.pageNum" :page-sizes="[10]"
                           :page-size="deployDetailData.pageSize"
                           layout="total, sizes, prev, pager, next, jumper" :total="deployDetailData.total">
            </el-pagination>
        </div>
        </div>
    </el-dialog>-->

    <!-- 合并代码弹窗 -->
    <el-dialog title="合并代码" id="mergeCodeDialog" class="el-dialog-1180w" :before-close="handleCloseMergeCodeDialog"
               :visible.sync="mergeCode_dialogVisible" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div class="mt5">
          <span>发布单关联的可合并代码的Release版本分支信息</span>
        </div>
        <div class="table-box-bs mt10" v-loading="merge_code_table_loading" element-loading-text="拼命加载中">
          <feature-branch-wait-deploy-table :bizId="bizId" :wait2DeployListData="wait2DeployListData" :fromDeployNote="true"
                                            @handleListSizeChange="handleListSizeChange" @handleListPageChange="handleListPageChange"
                                            @renderTable="renderTable"
          ></feature-branch-wait-deploy-table>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button type="primary" class="fr" style="margin-left: 5px;"
                     @click="handleFinallyCompleteDeploy">发布完成</el-button>

          <el-button class="fr" @click="handleCloseMergeCodeDialog()">关闭</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  import FeatureBranchWaitDeployTable from "@/components/commonComponents/FeatureBranchWaitDeployTable"
  export default {
    name: "deployNoteList",
    components: {
      FeatureBranchWaitDeployTable,
    },
    data() {
      return {
        userId: '',
        currentUserId:$utils.getCurrentUserId(),
        isShowCreateButton: false,//新建发布单显示控制
        passIframeUrl: "",
        zoneList: [],
        tabList: [],
        showDeployNote: {},
        showDeployNoteForm: { //发布单详情弹窗
          deployNoteId: '',
          auditFlow: [],
          deployList: [],
        },
        passForm: {},
        passDeployUrl: '',
        deployNoteForm: { //发布弹窗
          data: [],
          isAppView: true,
        },
        isViewDeployNoteForm: true,//true查看发布单  false是审核发布单
        rejectReason: '',
        table_loading: false,
        activeName: "-1",
        look_dialogVisible: false,
        shadeBtn: false,
        modaltobody: false,
        objInfo: {},
        dataMap: {},
        tableListmod: [],
        dialogVisible_fbd: false,
        step: "1",
        bizId: '',
        iviewMap: "0",
        flowData: null,
        disableds: false,
        tablelistparent: [],
        obJect: {},
        obJect_2: {},
        dialogVisible_fb: false,
        deployInframeTitle: '发布',
        iframeData: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        fileList:[],
        uploadFiles:[],
        uploadFileIds:[],
        submit_deploy_upload_loading:false,
        uploadActionUrl: $http.api.deploy_note.uploadDeployDir.url,
        upoladID: {
          deployNoteId: -1,
          bizId:this.getUrlBizId()
        },
        dialog_deploy_detail: false,
        versionNames: '',
        deployDetailData: {
          pageNum:1,
          pageSize:10,
          total:0
        },
        deployDetailList: [],
        deployDetailTitle:'',

        bizInfo: {},
        currentCompleteDeployInfo: {},
        mergeCode_dialogVisible: false,
        merge_code_table_loading: false,
        wait2DeployListData: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          list: []
        },


      };
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this.isShowCreateButton = this.authFunction('FUNC_BIZ_DEPLOY_CREATE', 1)
      this.getLoginUserInfo();
      this.getButtonAndCount();
      this.getZoneList();
      this.getFlowData();
      this.getBizInfo();
    },

    computed: {
      getTabData() {
        return this.dataMap[this.activeName] ? this.dataMap[this.activeName].list : [];
      }
    },

    methods: {

      getBizInfo() {
        $http.get($http.api.biz.getBizInfo, {bizId: this.bizId}).then(res => {
          this.bizInfo = res.data;
        }).catch(() => {
          this.$message({
            message: '获取业务信息失败',
            type: 'error'
          });
        });
      },

      async getLoginUserInfo() {//获取当前登陆用户信息
        await $http.get($http.api.user.getLoginUserInfo).then((res) => {
          this.userId = res.data.systemUser.userId;
        })
      },

      getSuccessRate(val){
        let successCount = val.deploySuccessConut;
        let failCount = val.deployFailCount;
        let numberRate = successCount/(successCount + failCount);
        let strRate = Number(numberRate * 100).toFixed(2) + "%";
        return strRate;
      },

      getAbnormalState(val){
        let abnormalState = '';
        if(val.rollBackCount > 0){
          abnormalState = abnormalState + "回滚版本：" + val.versionName + "<br>";
        }else{
          abnormalState = abnormalState + "回滚版本：无" + "<br>";
        }
        if(val.urgentCount > 0){
          abnormalState = abnormalState + "紧急发布：" + val.urgentCount + "个实例" + "<br>";
          abnormalState = abnormalState + "紧急原因：" + val.urgentRemarks;
        }else{
          abnormalState = abnormalState + "紧急发布：无";
        }
        return abnormalState;
      },

      //发布日志
      handleCloseDeployDetail(){
        this.dialog_deploy_detail = false;
      },
      showDeployDetails(val){
        this.versionNames = val.versionNames;
        this.deployDetailData.pageNum = 1;
        this.deployDetailData.pageSize = 10;
        this.deployDetailData.total = 0;
        this.getDeployDetais();
        this.deployDetailTitle = "【" + val.deployNoteDesc + "】发布统计";
        this.dialog_deploy_detail = true;
      },
      //发布日志数据
      getDeployDetais(){
        $http.get($http.api.deploy_note.getDeployDetailList, {versionNames: this.versionNames, pageSize: this.deployDetailData.pageSize, pageNum: this.deployDetailData.pageNum}).then(res => {
          if (res.status == 200) {
            if(res.data){
              this.deployDetailList = res.data;
              this.deployDetailData.total = this.deployDetailList.length;
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },
      handleDeployPageChange(val){
        this.deployDetailData.pageNum = val;
      },

      handleDeploySizeChange(val){
        this.deployDetailData.pageSize = val;
      },

      getDeployDirList(deployNoteId){
        $http.get($http.api.deploy_note.getDeployDirList, {deployNoteId: deployNoteId}).then(res => {
          if (res.status == 200) {
            this.uploadFiles = res.data;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      uploadDeployBtn(){
        this.dialog_visible_upload = true;
      },

      downloadDeployBtn(val){
        $http.get($http.api.deploy_note.downloadDeployDir, {deployDirId: val}).then(res => {
          if (res.status == 200) {
            window.location.href = res.data.downloadUrl;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      deleteDeployBtn(val){
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.deploy_note.deleteDeployDir, {deployDirId: val}).then(res => {
            if (res.status == 200) {
              this.$message({
                message: '删除附件成功',
                type: 'success'
              });
              this.removeUploadFileId(val);
            } else {
              this.$message({
                message: res.msg,
                type: 'warning'
              })
            }

          });
        }).catch(() => {
        });
      },

      removeUploadFileId(fileId){
        this.uploadFileIds.forEach((item, index) => {
          if (item === fileId) {
            this.uploadFileIds.splice(index, 1);
          }
        });

        this.uploadFiles.forEach((item, index) => {
          if (item.id === fileId) {
            this.uploadFiles.splice(index, 1);
          }
        });

      },

      handleUploadSuccess(response, file, fileList){
        let data = response.data;
        let msg = response.msg;
        if(msg === 'OK'){
          this.uploadFiles.push({
            deployNoteId:-1,
            id:data,
            userId:this.currentUserId,
            fileName:file.name
          });
          this.uploadFileIds.push(data);
        }else{
          this.$message({
            message: '上传附件失败：' + msg,
            type: 'error'
          });
        }
      },

      handleUploadError(){},

      submit_deploy_upload(){
        let uploadform = this.$refs.upload.$data.uploadFiles;
        let formData = new FormData();
        formData.append("deployNoteId", -1);
        formData.append("file", uploadform[0].raw);
        $http.post($http.api.deploy_note.uploadDeployDir, formData).then((res) => {
          let data = res.data;
          this.$alert(data !== null ? '上传成功' : '上传失败', '提示', {
            confirmButtonText: '确定',
            callback: action => {
              this.goToPage(this, "deployNoteList", {bizId: this.bizId});
            }
          });
          this.uploadFiles.push({
            deployNoteId:-1,
            id:data,
            fileName:uploadform[0].name
          });
          this.uploadFileIds.push(data);
        }).catch(e => {
        })
      },

      //关闭
      handle_close_upload() {
        this.$refs.upload.$data.uploadFiles.length = 0;
        this.dialog_visible_upload = false;
      },

      handlePreview(file) {

      },
      handleRemove(file, fileList) {

      },
      handleExceed(files, fileList) {
      },

      getStepDesc(item) {
        for (let index in this.tabList) {
          let tab = this.tabList[index];
          if (tab.type == item.deployNoteStatus) {
            return tab.buttonName.replace("待", "");
          }
        }
        return "审批";
      },
      showMore(item) {
        item.expand = true;
      },
      showLess(item) {
        item.expand = false;
      },
      getZoneList() {
        $http.get($http.api.app.getZoneList, {env: 'online'}).then(res => {
          this.zoneList = res.data;
        }).catch((e) => {
          this.$message({
            message: '获取机房失败',
            type: 'error'
          });
        });
      },

      getZoneNameByCode(zoneCode) {
        let zoneName = zoneCode;
        this.zoneList.forEach(zone => {
          if (zone.code == zoneCode) {
            zoneName = zone.name;
          }
        })
        return zoneName;
      },

      spanMethod({row, column, rowIndex, columnIndex}) {
        if (columnIndex === 0) {
          if (row.key1span != 0) {
            return [row.key1span, 1];
          } else {
            return [0, 0];
          }
        } else if (columnIndex === 1) {
          if (row.key2span != 0) {
            return [row.key2span, 1];
          } else {
            return [0, 0];
          }
        }
      },
      canDeploy(deployNote) {//判断到发布时间没有
        try {
          let time = JSON.parse(deployNote.deployNoteResult).deployTime;
          if (time) {
            if (typeof time == 'number') {
              let date = new Date();
              date.setTime(time);
              let deployTime = this.formatDate(date, "yyyyMMdd");
              let nowDate = this.formatDate(new Date(), "yyyyMMdd");
              let deployStatus = parseInt(nowDate) >= parseInt(deployTime);
              return deployStatus;
            } else {
              let deployTime = time.substring(0, 10).replace(new RegExp('-', "g"), "");
              let nowDate = this.formatDate(new Date(), "yyyyMMdd");
              let deployStatus = parseInt(nowDate) >= parseInt(deployTime);
              return deployStatus;
            }
          }
        } catch (e) {
          console.error("解析发布时间出错", e)
        }
        return false;

      },
      isButtonShow(deployNote, buttonType) {
        // "edit","send","review","deploy","finish","delete"

        let stepId = deployNote.deployNoteStatus;
        let ended = deployNote.result === 2;
        let deployed = deployNote.isDeployed == 1;

        var backStates = ["edit", "delete"]//已打回
        var sendStates = ["edit", "send", "delete"]//待送审
        var waitDeployStates = ["deploy", "finish"]//待发布
        var midddleStates = ["review"]//中间审核流程

        if (ended && !deployed) {//已打回
          return backStates.indexOf(buttonType) != -1;
        }
        let showButton = false;
        if (stepId == 0) {//待送审
          showButton = sendStates.indexOf(buttonType) != -1;
        } else if (stepId == 3) {//待发布
          showButton = waitDeployStates.indexOf(buttonType) != -1;
        } else if (stepId == 4) {//已完成
          showButton = false;
        } else {//中间审核流程
          showButton = midddleStates.indexOf(buttonType) != -1;
        }

        //判断当前步骤是否有权限
        if (showButton == false) {
          return false;
        }

        let havePermisson = false;
        let userId = this.userId;
        if (deployNote.auditFlow) {
          deployNote.auditFlow.forEach(flow => {
            if (stepId == flow.stepId) {
              if (flow.memberIds) {
                flow.memberIds.forEach(memberId => {
                  if (userId == memberId) {
                    havePermisson = true;
                  }
                })
              }
            }
          })
        }
        return havePermisson;
      },
      tabChange() {
        this.getDeployNoteList();
      },
      getStatusDesc(status) {
        let statusDesc = '';
        this.tabList.forEach(val => {
          if (val.type == status) {
            statusDesc = val.buttonName;
          }
        })
        return statusDesc;
      },
      getShowUserNameByUserId(userId) { //根据工号获得显示的用户的用户名
        let showUserName = userId;
        if (this.flowData) {
          if (this.flowData.fixedFlowInfo) {
            this.flowData.fixedFlowInfo.forEach(flow => {
              if (flow.approverList) {
                flow.approverList.forEach(person => {
                  if (userId == person.userId) {
                    showUserName = person.userName + "(" + person.userId + ")";
                  }
                })
              }
            });
          }
          if (this.flowData.customFlowInfo) {
            this.flowData.customFlowInfo.forEach(flow => {
              if (flow.approverList) {
                flow.approverList.forEach(person => {
                  if (userId == person.userId) {
                    showUserName = person.userName + "(" + person.userId + ")";
                  }
                })
              }
            });
          }
        }
        return showUserName;
      },
      getFlowData() {//获得业务流程信息，用于判断
        $http.get($http.api.issue.deploynoteflowinfo, {bizId: this.bizId}).then(res => {
          this.flowData = res.data;
        })
      },
      getButtonAndCount() {//获取标签和统计数量
        $http.get($http.api.deploy_note.getButtonAndCount, {bizId: this.bizId}).then(res => {
          res.data.forEach(item => {
            item.type = '' + item.type + '';
            if (!this.dataMap[item.type]) {
              this.$set(this.dataMap, item.type, {total: 0, pageNum: 1, pageSize: 20, list: []});
            }
          })
          this.tabList = res.data;
          this.tabChange();
        }).catch((e) => {
          this.$message({
            message: '获取标签失败，请重试',
            type: 'error'
          });
        });
      },
      viewDeployNote(deployNote) {
        this.isViewDeployNoteForm = true;
        this.getDeployNoteDetail(deployNote);
      },
      reviewDeployNote(deployNote) {
        this.isViewDeployNoteForm = false;
        this.getDeployNoteDetail(deployNote);
      },

      finallyCompleteDeploy() {
        $http.get($http.api.deploy_note.completeDeploy, {
          deployNoteId: this.currentCompleteDeployInfo.deployNoteId,
          env: 'online',
        }).then(res => {
          this.checkResult(res);
        })
      },

      completeDeploy(deployNote) {
        this.$confirm("确定将此发布单更换为完成状态？", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          if (!this.canDeploy(deployNote)) {
            this.$message({
              message: '未到设定的发布时间',
              type: 'warning'
            });
            return;
          }

          this.currentCompleteDeployInfo = deployNote;
          if (this.bizInfo && this.bizInfo.deployFinishedMergeCode) {
            // 设置了合并完成合并代码
            this.mergeCode_dialogVisible = true;
            this.renderTable();
          } else {
            // 未设置发布完成合并代码
            this.finallyCompleteDeploy();
          }
        }).catch(() => {
        });
      },
      getDeployNoteDetail(deployNote) {
        this.upoladID.deployNoteId = deployNote.deployNoteId;
        $http.get($http.api.deploy_note.getDeployNoteDetail, {deployNoteId: deployNote.deployNoteId}).then(res => {
          this.showDeployNote = res.data;
          this.showDeployNoteForm.deployNoteId = this.showDeployNote.deployNoteId;
          this.showDeployNoteForm.deployNoteDesc = this.showDeployNote.deployNoteDesc;
          this.showDeployNoteForm.fastDeployStr = this.showDeployNote.fastDeploy == 0 ? '普通发布' : '快速发布';
          let deployNoteResult = JSON.parse(this.showDeployNote.deployNoteResult);
          this.showDeployNoteForm.bizName = deployNoteResult.bizName;
          this.showDeployNoteForm.title = deployNoteResult.title;
          this.showDeployNoteForm.createUser = deployNoteResult.createUser;
          this.showDeployNoteForm.bizOwner = deployNoteResult.bizOwner;
          this.showDeployNoteForm.deployTime = deployNoteResult.deployTime;
          this.showDeployNoteForm.notice = deployNoteResult.notice;
          this.showDeployNoteForm.auditFlow = deployNoteResult.auditFlow;
          this.showDeployNoteForm.isAppView = this.showDeployNote.deployNoteView == 0;

          //组装列表数据
          this.showDeployNoteForm.deployList = this.assembleTableData(deployNoteResult.deployAppModules, this.showDeployNoteForm.isAppView);
          this.getDeployDirList(deployNote.deployNoteId);
          this.lookOverBtn()
        })
      },

      transferDataToList(deployAppModules) { //把数据转换为列表结构
        let list = [];
        deployAppModules.forEach(module => {
          if (module.deployInfo && module.deployInfo.length != 0) {
            module.deployInfo.forEach(zone => {
              let zoneName = "";
              if (this.zoneList) {
                this.zoneList.forEach(item => {
                  if (item.code == zone.zone) {
                    zoneName = item.name;
                  }
                })
              }

              list.push({
                zone: zone.zone,
                zoneName: zoneName,
                configEnv: zone.configEnv,
                configVersion: zone.configVersion,
                appId: module.appId,
                appCode: module.appCode,
                appName: module.appName,
                updateDesc: module.updateDesc,
                version: module.version,
                versionDesc: module.versionDesc,
                versionId: module.versionId,
                deployOrder: module.deployOrder,
                cmdbPath: module.cmdbPath,
                deployInfo: module.deployInfo,
                repoUrl: module.repoUrl,
                MD5: module.MD5,
                tester: module.tester,
              });
            })
          }
        });
        return list;
      },

      assembleTreeData(deployAppModules, isAppView) {//组装树形数据
        let list = this.transferDataToList(deployAppModules);
        let key1Name = isAppView ? 'appCode' : 'zone';
        let key2Name = isAppView ? 'zone' : 'appCode';
        let map = new Map();//key1,key2,list
        list.forEach(item => {
          let val1 = item[key1Name];
          let val2 = item[key2Name];

          if (!map.has(val1)) {
            let map2 = new Map();
            map2.set(val2, [item])
            map.set(val1, map2);
            return;
          }

          let map2 = map.get(val1);
          if (!map2.has(val2)) {
            map2.set(val2, [item])
          } else {
            map2.get(val2).push(item);
          }
        })

        let data = [];
        map.forEach((map2, label1) => {
          let item1 = {label: label1, children: []};
          data.push(item1);
          map2.forEach((itemList, label2) => {
            let item2 = {label: label2, children: []};
            item1.children.push(item2);
            itemList.forEach(item => {
              item2.children.push({label: item.version, item: item});
            })
          })
        })
        return data;
      },

      assembleTableData(deployAppModules, isAppView) {//组装列表数据
        let key1Name = isAppView ? 'appId' : 'zone';
        let key2Name = isAppView ? 'zone' : 'appId';
        let list = this.transferDataToList(deployAppModules);
        list.sort((a, b) => {
          if (a[key1Name] != b[key1Name]) {
            return a[key1Name] < b[key1Name] ? 1 : -1;
          } else {
            if (a[key2Name] != b[key2Name]) {
              return a[key2Name] < b[key2Name] ? 1 : -1;
            } else {
              return a.deployOrder - b.deployOrder;
            }
          }
        });

        //计算需要合并的列的个数
        let map = new Map();
        list.forEach(item => {
          let key1 = item[key1Name];
          let key2 = item[key1Name] + "_" + item[key2Name];
          let count1 = map.get(key1);
          let count2 = map.get(key2);
          if (count1) {
            map.set(key1, count1 + 1);
          } else {
            map.set(key1, 1);
          }
          if (count2) {
            map.set(key2, count2 + 1);
          } else {
            map.set(key2, 1);
          }
        });

        list.forEach(item => {
          let key1 = item[key1Name];
          let key2 = item[key1Name] + "_" + item[key2Name];
          let count1 = map.get(key1);
          let count2 = map.get(key2);
          if (count1) {
            item.key1span = count1;
            map.delete(key1);
          } else {
            item.key1span = 0;
          }
          if (count2) {
            item.key2span = count2;
            map.delete(key2);
          } else {
            item.key2span = 0;
          }
        });

        return list;

      },
      //级菜单切换控制路由切换
      handleSelect(val) {
        if (val === "1") {
          this.goToPage(this, 'deployNoteList');
        } else if (val === "2") {
          this.goToPage(this, 'deployNoteFlow');
        }
      },
      //级菜单切换控制路由切换
      createNewDeploy() {
        this.goToPage(this, 'deployNoteManage', {bizId: this.bizId})
      },

      // 获取全部发布单列表
      getDeployNoteList() {
        let params = {
          bizId: this.bizId,
          type: this.activeName,
          searchValue: '',
          pageSize: this.dataMap[this.activeName].pageSize,
          pageNum: this.dataMap[this.activeName].pageNum,
        }
        $http.post($http.api.deploy_note.getDeployNoteList, params).then(res => {
          if (res.status == 200) {
            if (res.data && res.data.list) {
              let arr = res.data.list.forEach((item, index) => {
                let parse = JSON.parse(item.deployNoteResult);
                let appSet = new Set();
                let versionSet = new Set();
                parse.deployAppModules.forEach((i, index) => {
                  appSet.add('【' + i.appCode + '】');
                  versionSet.add(i.version);
                });
                let appList = [];
                let versionList = [];
                appSet.forEach(appName => {
                  appList.push(appName);
                });
                versionSet.forEach(versionName => {
                  versionList.push(versionName);
                });
                item.versionNames = versionList.join(",");
                item.appName = appList.join("");
                item.expand = false;
                item.auditFlow = parse.auditFlow;
              })
            }
            this.$set(this.dataMap, this.activeName, res.data)
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      //发布单查看
      lookOverBtn(val) {
        this.look_dialogVisible = true;
      },

      //全部发布单查看
      editDeployNote(deployNote) {
        this.goToPage(this, 'deployNoteManage', {bizId: this.bizId, deployNoteId: deployNote.deployNoteId})
      },
      sendDeployNoteToFlow(deployNote) {//送审
        this.updateFlow(deployNote.deployNoteId, 1)
      },
      passDeployNoteToFlow() {//审核通过
        this.handleClose();
        this.updateFlow(this.showDeployNoteForm.deployNoteId, 1)
      },
      rejectDeployNoteToFlow() {//打回
        this.handleClose_fbd();
        this.look_dialogVisible = false;
        this.updateFlow(this.showDeployNoteForm.deployNoteId, 2, this.rejectReason)
      },
      updateFlow(deployNoteId, result, comment) {//送审
        $http.post($http.api.deploy_note.auditFlowUpdate, {
          deployNoteId: deployNoteId,
          result: result,
          comment: comment
        }).then(res => {
          this.checkResult(res);
        });
      },

      checkResult(res) {
        this.getButtonAndCount();
        if (res.status == 200) {
          this.$message({
            message: "操作成功",
            type: "success"
          });
        } else {
          this.$message({
            message: res.msg,
            type: "error"
          });
        }
      },

      //删除发布单
      deleteDeployNote(deployNote) {
        this.$confirm("确定要删除吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.deploy_note.deleteDeployNote, {deployNoteId: deployNote.deployNoteId}).then(res => {
            this.getButtonAndCount();
            this.$message({
              message: "删除成功",
              type: "success"
            });
          }).catch((e) => {
            this.$message({
              message: "删除失败",
              type: "success"
            });
          });
        }).catch(() => {
        });
      },


      //全部发布单列表分页
      handleSizeChange(val) {
        this.dataMap[this.activeName].pageSize = val;
        this.getDeployNoteList()
      },

      handleCurrentChange(val) {
        this.dataMap[this.activeName].pageNum = val;
        this.getDeployNoteList()
      },


      //查看弹窗关闭
      handleClose() {
        this.look_dialogVisible = false;
      },

      //弹窗驳回按钮
      rejectBtn() {
        this.dialogVisible_fbd = true;
      },

      //驳回弹窗关闭
      handleClose_fbd() {
        this.dialogVisible_fbd = false;
      },

      getResultStr(result) {
        let str = '';
        if (result == 1) {
          str = '同意'
        } else if (result == 2) {
          str = '打回'
        } else if (result) {
          return result;
        }
        return str;
      },

      getPersonStr(username, time, comment) {
        let str = '';
        if (username && time) {
          str = username + ' ' + time;
          if(comment){
            str = str + ' 打回原因:' + comment;
          }
          return str;
        } else {
          return str;
        }
      },

      //发布
      release(deployNote) {
        if (!this.canDeploy(deployNote)) {
          this.$message({
            message: '未到设定的发布时间',
            type: 'warning'
          });
          return;
        }
        window.open("/deployNoteIframe?bizId=" + this.getUrlBizId() + '&' + 'deployNoteId=' + deployNote.deployNoteId, '_blank')
      },

      //合并代码弹窗关闭
      handleCloseMergeCodeDialog() {
        this.mergeCode_dialogVisible = false;
      },

      handleFinallyCompleteDeploy() {
        this.mergeCode_dialogVisible = false;
        this.finallyCompleteDeploy()
      },

      renderTable() {
        this.merge_code_table_loading = true;
        let params = {
          deployNoteId: this.currentCompleteDeployInfo.deployNoteId,
          pageNum: this.wait2DeployListData.pageNum,
          pageSize: this.wait2DeployListData.pageSize,
        };

        $http.get($http.api.feature_branch.wait2DeployListByDeployNote, params).then(response => {
          this.merge_code_table_loading = false;
          this.wait2DeployListData = response.data;
        });
      },

      handleListSizeChange(newPageSize) {
        this.wait2DeployListData.pageSize = newPageSize;
        this.renderTable();
      },

      handleListPageChange(newPageNum) {
        this.wait2DeployListData.pageNum = newPageNum;
        this.renderTable();
      },

    },

  };
</script>

<style lang="scss" scoped>
  .el-icon-delete {
    color: #f56c6c;
    font-size: 18px;
    line-height: 20px;
  }

  .el-icon-circle-plus-outline {
    color: #409eff;
    font-size: 18px;
  }

  .el-icon-info {
    color: #e6a23c;
    font-size: 18px;
    line-height: 0px;
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .fbdtableshxx {
    padding: 5px 5px 5px 5px;
    height: 100%;
    border-collapse: collapse;
    border-spacing: 0;
    border: none;
    width: 100%;

    .backgroundColor {
      width: 200px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .backgroundColor_b {
      width: 211px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .text-again {
      text-align: left;
      padding-left: 20px !important;
    }

    .backgroundColor_c {
      width: 220px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .backgroundColor:hover {
      background: #f5f7fa;
    }

    .backgroundtitle {
      width: 12.5%;
      height: 40px;
      border: 1px solid #e4e7ed;
      background: #f5f7fa;
    }

    .fontright {
      height: 40px;
      text-align: center;
      line-height: 20px;
    }

    .fontleft {
      text-align: left;
      line-height: 20px;
      padding-left: 20px;
    }
  }

  .tableshxx {
    padding: 5px 5px 5px 5px;
    height: 100%;
    border-collapse: collapse;
    border: 1px solid black;
    width: 100%;

    .backgroundColor {
      width: 480px;
      height: 40px;
      border: 1px solid #e4e7ed;
    }

    .text-again {
      text-align: left !important;
      padding-left: 20px !important;
    }

    .backgroundColor:hover {
      background: #f5f7fa;
    }

    .backgroundtitle {
      width: 120px;
      height: 40px;
      border: 1px solid #e4e7ed;
      background: #f5f7fa;
    }

    .fontright {
      text-align: center;
      line-height: 20px;
      padding-right: 20px;
    }

    .fontleft {
      text-align: left;
      line-height: 20px;

      padding-left: 20px;
    }
  }

  #lookDialog {
    .el-tabs {
      .el-tabs__content {
        height: calc(100% - 40px) !important;

        .el-tab-pane {
          height: 100%;

          .tablegjcxlb {
            padding: 5px 5px 5px 5px;
            height: 100%;
            border-collapse: collapse;
            border: 1px solid black;

            .backgroundColor {
              width: 480px;
              height: 40px;
              border: 1px solid #e4e7ed;
            }

            .text-again {
              text-align: left;
              padding-left: 20px !important;
            }

            .backgroundColor:hover {
              background: #f5f7fa;
            }

            .backgroundtitle {
              width: 120px;
              height: 40px;
              border: 1px solid #e4e7ed;
              background: #f5f7fa;
            }

            .fontright {
              text-align: center;
              line-height: 20px;
              padding-right: 20px;
            }

            .fontleft {
              text-align: left;
              line-height: 20px;

              padding-left: 20px;
            }
          }
        }
      }
    }
  }

  #editDialog {
    .lastheader {
      height: 100%;
      margin-top: 10px;
      margin-bottom: 10px;

      .iviewtitle {
        margin-top: 10px;
        margin-right: 10px;
      }
    }

    .el-tabs {
      margin-top: 10px;

      .el-tabs__content {
        height: calc(100% - 40px) !important;

        .el-tab-pane {
          height: 100%;

          .tablegjcxlb {
            padding: 5px 5px 5px 5px;
            height: 100%;
            border-collapse: collapse;
            border: 1px solid black;

            .backgroundColor {
              width: 480px;
              height: 40px;
              border: 1px solid #e4e7ed;
            }

            .text-again {
              text-align: left;
              padding-left: 20px !important;
            }

            .backgroundColor:hover {
              background: #f5f7fa;
            }

            .backgroundtitle {
              width: 120px;
              height: 40px;
              border: 1px solid #e4e7ed;
              background: #f5f7fa;
            }

            .fontright {
              text-align: center;
              line-height: 20px;
              padding-right: 20px;
            }

            .fontleft {
              text-align: left;
              line-height: 20px;

              padding-left: 20px;
            }
          }
        }
      }
    }

    .tMain {
      padding: 5px 5px 5px 5px;
      height: 100%;
      border-collapse: collapse;
      border: 1px solid black;

      .backgroundColor {
        width: 480px;
        height: 40px;
        border: 1px solid #e4e7ed;
      }

      .backgroundColor:hover {
        background: #f5f7fa;
      }

      .backgroundtitle {
        width: 120px;
        height: 40px;
        border: 1px solid #e4e7ed;
        background: #f5f7fa;
      }

      .fontright {
        text-align: center;
        line-height: 20px;
        padding-right: 20px;
      }

      .fontleft {
        text-align: left;
        line-height: 20px;

        padding-left: 20px;
      }
    }
  }
</style>
