<template>
  <div id="bizImageSetting" class="content-outer-box">
    <div class="white-box table-outer-box">
      <div class="mt0">
        <div style="height:35px;">
          <el-button style="position: absolute; right:130px; top: 60px; z-index: 9" v-if="checkUserAuth()" @click="showImageUploadDialog" type="primary">上传镜像
          </el-button>
          <el-button style="position: absolute; right:35px; top: 60px; z-index: 9" @click="showUploadHistryDialog" type="primary">上传历史
          </el-button>
        </div>
        <div class="table-box-top"
             style="height:100%;padding-left:10px;padding-right:10px;overflow:auto;overflow-x: hidden;position: relative">
          <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
            <div class="table-box-top">
              <el-table
                :data="bizImageInfos.slice((bizImageData.pageNum-1)*bizImageData.pageSize,
                          bizImageData.pageNum*bizImageData.pageSize)"
                border
                :class="{'el-table-left-none':bizImageInfos.length == 0}">
                <el-table-column prop="typeName" label="镜像类型" min-width="100">
                </el-table-column>
                <el-table-column prop="imageRepo" label="镜像名称" min-width="100">
                </el-table-column>
                <el-table-column prop="imageTag" label="镜像标签" min-width="100">
                </el-table-column>
                <el-table-column prop="stable" label="稳定版本" min-width="80">
                  <template slot-scope="scope">
                    {{scope.row.stable===1?'是':'否'}}
                  </template>
                </el-table-column>
                <el-table-column prop="containerUp" label="保留构建环境" min-width="80">
                  <template slot-scope="scope">
                    {{scope.row.containerUp===1?'是':'否'}}
                  </template>
                </el-table-column>
                <el-table-column prop="uploadTime" label="上传时间" min-width="100">
                </el-table-column>
                <el-table-column width="350" label="操作">
                  <template slot-scope="scope">
                    <span class="c-blue cp" @click="downloadData(scope.row)">下载</span>
                    <span class="c-blue cp" v-if="scope.row.typePrivate == 1" @click="showUploadLogDialog(scope.row.uploadId)">上传日志</span>
                    <span class="c-blue cp" v-if="scope.row.typePrivate == 1 && checkUserAuth()" @click="showBindImageDialog(scope.row)">绑定业务</span>
                    <span class="c-blue cp" v-if="scope.row.typePrivate == 1 && checkUserAuth()" @click="deleteUploadData(scope.row)">删除</span>
                    <span class="c-blue cp" v-if="scope.row.typePrivate == 1 && scope.row.stable == 0 && checkUserAuth()" @click="checkImageStableMethod(scope.row)">设为稳定版本</span>
                    <span class="c-blue cp" v-if="scope.row.typePrivate == 1 && scope.row.stable == 1 && checkUserAuth()" @click="setImageContainerUp(scope.row)">{{scope.row.containerUp==0?'保留构建环境':'不保留构建环境'}}</span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="pageModule" style="height: 35px">
              <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleImageSizeChange"
                             @current-change="handleImagePageChange"
                             :current-page="bizImageData.pageNum" :page-sizes="[20]"
                             :page-size="bizImageData.pageSize"
                             layout="total, sizes, prev, pager, next, jumper" :total="bizImageData.total">
              </el-pagination>
            </div>
            </div>
          </div>
        </div>
      </div>
    <el-dialog
      title="上传镜像"
      :visible.sync="imageUploadDialogShow"
      class="el-dialog-580w issuedialog"
      element-loading-text="拼命上传中">
      <div class="form-iterm-box" v-loading="submit_upload_loading">
        <el-form :model="uploadImageInfo" ref="imageInfoEditForm" label-width="110px" label-position="right">
          <el-form-item label="镜像类型:" class="mb15" prop="typeId" :rules="{required: true, message: '镜像类型不能为空', trigger: 'blur'}">
            <el-select v-model="uploadImageInfo.typeId" placeholder="请选择" class="width-input-select" style="width: 420px">
              <el-option v-for="item in bizImageTypes" :key="item.typeId" :label="item.typeName"
                         :value="item.typeId"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="镜像名称:" class="mb15" prop="imageRepo" :rules="{required: true, message: '镜像名称不能为空', trigger: 'blur'}">
            <el-input v-model="uploadImageInfo.imageRepo" placeholder="请输入镜像类型名称"></el-input>
          </el-form-item>
          <el-form-item label="镜像标签:" class="mb20" prop="imageTag" :rules="{required: true, message: '镜像标签不能为空', trigger: 'blur'}">
            <el-input v-model="uploadImageInfo.imageTag" placeholder="请输入镜像类型描述"></el-input>
          </el-form-item>
          <el-form-item label="稳定版本:" class="mb20" prop="stable" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
            <el-radio-group v-model="uploadImageInfo.stable" placeholder="请选择" style="width: 110px"
                            class="width-input-select" @change="changeStableCheck">
              <el-radio :label="1" class="mt5 mb10">是</el-radio>
              <el-radio :label="0" class="mt5 mb10">否</el-radio>
            </el-radio-group>
            <i class="el-icon-question" title="同一个镜像名称下只有一个稳定版本，构建时将使用稳定版本" style="font-size: 16px;padding: 5px"></i>
          </el-form-item>
          <el-form-item label="保留构建环境:" v-if="uploadImageInfo.stable == 1" class="mb20" prop="containerUp" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
            <el-radio-group v-model="uploadImageInfo.containerUp" placeholder="请选择" style="width: 110px"
                            class="width-input-select">
              <el-radio :label="1" class="mt5 mb10">是</el-radio>
              <el-radio :label="0" class="mt5 mb10">否</el-radio>
            </el-radio-group>
            <i class="el-icon-question" title="若选择保留构建环境，构建完毕后容器将会保留，下次构建仍会使用此容器" style="font-size: 16px;padding: 5px"></i>
          </el-form-item>
          <el-form-item label="手工上传:" class="mb20" prop="stable" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
            <el-radio-group v-model="uploadImageInfo.manualUpload" placeholder="请选择" style="width: 110px"
                            class="width-input-select">
              <el-radio :label="1" class="mt5 mb10">是</el-radio>
              <el-radio :label="0" class="mt5 mb10">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="镜像包(tar.gz):" class="mb20" v-if="uploadImageInfo.manualUpload==0">
            <el-upload class="upload-demo"
                       ref="upload"
                       action=""
                       :on-exceed="handleExceed"
                       :file-list="fileList"
                       :limit="1"
                       :auto-upload="false">
              <span size="small" type="primary" class="c-blue" style="line-height:22px;">选取文件</span>
              <i class="el-icon-question" title="1.docker save成tar包后必须再压缩成tar.gz包; 2.名字必须是${image name}_${tag}.tar.gz" style="font-size: 16px;padding: 5px"></i>
            </el-upload>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeImageUploadDialog">关闭</el-button>
        <el-button type="primary" @click="saveOrUpdateImage" :loading="submit_upload_loading">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="上传历史"
      :visible.sync="uploadHistryDialogShow"
      class="el-dialog-880w issuedialog">
      <div class="table-box" v-loading="table_loading" element-loading-text="拼命加载中">
        <div class="table-box-top">
          <el-table
            :data="imageUploadHistrys.slice((uploadHistryData.pageNum-1)*uploadHistryData.pageSize,
                          uploadHistryData.pageNum*uploadHistryData.pageSize)"
            border
            :class="{'el-table-left-none':imageUploadHistrys.length == 0}">
            <el-table-column prop="imageRepo" label="镜像名称" min-width="150">
            </el-table-column>
            <el-table-column prop="imageTag" label="镜像标签" min-width="150">
            </el-table-column>
            <el-table-column prop="createTime" label="上传时间" min-width="150">
            </el-table-column>
            <el-table-column prop="status" label="结果" min-width="150">
              <template slot-scope="scope">
                {{getResultByStatus(scope.row)}}
              </template>
            </el-table-column>
            <el-table-column prop="createTime" label="操作" min-width="150">
              <template slot-scope="scope">
                <span class="c-blue cp" @click="showUploadLogDialog(scope.row.id)">上传日志</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="pageModule" style="height: 35px">
          <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleUploadHistryChange"
                         @current-change="handleUploadHistryChange"
                         :current-page="uploadHistryData.pageNum" :page-sizes="[20]"
                         :page-size="uploadHistryData.pageSize"
                         layout="total, sizes, prev, pager, next, jumper" :total="uploadHistryData.total">
          </el-pagination>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeUploadHistryDialog">关闭</el-button>
      </span>
    </el-dialog>

    <!--上传镜像日志弹窗-->
    <el-dialog title="上传日志详情" :visible.sync="imageUploadLogDialogVisible" class="box-card-body-body" :before-close="closeUploadDialog">
      <div id="logDetail" class="box-card-body-body_right" style="background-color: #544c4c; color: floralwhite;font-size:14px;font-weight:400;margin-top: 10px;">
        <p v-html="logDetail" style="word-wrap: break-word;word-break: break-all;"></p>
        <p v-show="lastOffsets > 0"><i class="el-icon-loading"></i></p>
      </div>
    </el-dialog>

    <!--绑定镜像弹窗-->
    <el-dialog
      title="绑定镜像"
      :visible.sync="bindImageDialogVisible"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="image2bizInfo" ref="bindImageForm" label-width="110px" label-position="right">
          <el-form-item label="镜像名称:" class="mb15" prop="imageName" :rules="{required: true, message: '镜像名称不能为空', trigger: 'blur'}">
            <el-input v-model="image2bizInfo.imageName" disabled placeholder="请输入镜像类型名称"></el-input>
          </el-form-item>
          <el-form-item label="业务名称:" class="mb20" prop="bizId" :rules="{required: true, message: '业务名称不能为空', trigger: 'blur'}">
            <el-select v-model="image2bizInfo.bizIdArr" multiple filterable placeholder="请选择" style="width: 420px">
              <el-option v-for="item in bizList" :key=item.bizId :label="item.bizName"
                         :value=item.bizId></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeBindImageDialog">关闭</el-button>
        <el-button type="primary" @click="saveBindImage">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "bizImageSetting",
    data() {
      return {
        logList: [],
        logDetail: '',
        lastOffsets: -1,
        imageUploadLogDialogVisible: false,
        bindImageDialogVisible: false,
        currentBizId: '',
        bizImageTypes:[],
        bizImageInfos:[],
        imageUploadHistrys:[],
        bizImageData: {
          pageNum:1,
          pageSize:20,
          total:0
        },
        uploadHistryData: {
          pageNum:1,
          pageSize:20,
          total:0
        },
        uploadImageInfo: {
          typeId: -1,
          imageRepo: '',
          imageTag: '',
          stable: 0,
          containerUp: 0,
          buildType: 0,
          manualUpload: 0
        },
        table_loading: false,
        submit_upload_loading: false,
        imageUploadDialogShow: false,
        uploadHistryDialogShow:false,
        image2bizInfo: {
          imageId:-1,
          imageName:'',
          bizIdArr:-1
        },
        fileList:[],
        checkImageStable: false,
        checkImageInfo: {
          check: false,
          msg: '',
        },
        currentInterval: '',
        bizList:[]
      };
    },

    mounted() {
      this.currentBizId = this.$route.query.bizId;
      this.getBizImageInfos();
    },

    methods: {
      closeBindImageDialog() {
        this.bindImageDialogVisible = false;
      },

      showBindImageDialog(item) {
        let param = {};
        param.imageId = item.imageId;
        this.image2bizInfo.imageId = item.imageId;
        this.image2bizInfo.imageName = item.imageRepo + ":" + item.imageTag;
        $http.get($http.api.image_manage.get_biz_by_image,param).then(res => {
          if (res.status == 200) {
            this.image2bizInfo.bizIdArr = res.data;
          } else {
            this.$message({message: '获取绑定的业务失败！', type: 'error'});
          }
        });
        this.getMyBizInfos();
        this.bindImageDialogVisible = true;
      },

      getMyBizInfos() {
        $http.get($http.api.biz.getAllBizList).then(res => {
          if (res.status == 200) {
            this.bizList = res.data;
          } else {
            this.$message({message: '获取业务失败！', type: 'error'});
          }
        }).catch(_ => {})
      },

      saveBindImage(){
        let formData = new FormData();
        formData.append('imageId', this.image2bizInfo.imageId);
        formData.append('bizIdArr[]', this.image2bizInfo.bizIdArr);

        $http.post($http.api.image_manage.save_biz_image, formData).then((res) => {
          this.$message({
            type: 'success',
            message: '保存成功!'
          });

          this.closeBindImageDialog();
        })
      },

      closeUploadDialog() {
        this.imageUploadLogDialogVisible = false
        if (this.currentInterval) {
          clearInterval(this.currentInterval)
          this.currentInterval = ''
        }
      },

      showUploadLogDialog(uploadId) {
        this.imageUploadLogDialogVisible = true;
        let flag = 0;
        this.logList.forEach(item => {
          if (item.uploadId === uploadId) {
            this.logDetail = '';
            this.logDetail = item.logDetail;
            this.lastOffsets = item.lastOffsets;
            flag = 1
          }
        });
        if (flag === 0) {
          this.logList.push({uploadId: uploadId, logDetail: '', lastOffsets: 0})
          this.logDetail = '';
          this.lastOffsets = 0;
        }
        this.getImageUploadLog(uploadId)
      },
      getResultByStatus(item){
        if(item.cephStatus === 2 && item.harborStatus === 2){
          return '上传成功';
        }else if(item.cephStatus === 3 || item.harborStatus === 3){
          return '上传失败';
        }else{
          return '上传中';
        }
      },
      checkUserAuth(){
        return this.authFunction('FUNC_BIZ_IDENTITY_ADMIN', 1, this.$route.query.bizId) || this.authFunction('FUNC_SYS_IDENTITY_ADMIN', 0, -1);
      },

      intervalGetLog(uploadId) {
        if (!this.currentInterval || this.currentInterval == '') {
          this.currentInterval = setInterval(() => {
            if (this.lastOffsets == -1 && this.currentInterval) {
              clearInterval(this.currentInterval);
            } else {
              this.getImageUploadLog(uploadId)
            }
          }, 2000);
        }
      },
      //获取上传日志
      getImageUploadLog(uploadId) {
        if (this.lastOffsets != -1) {
          $http.get($http.api.compile.logs, {uploadId: uploadId, offset: this.lastOffsets}).then(res => {
            let str = res.data.logs;
            if (str && str.length > 0) {
              let lineArr = str.split('\n');
              let newStr = '';
              if (lineArr.length > 0) {
                lineArr.forEach((line) => {
                  if (line && line.length > 0) {
                    if (line.indexOf('[WARN]') > -1 || line.indexOf('[WARNING]') > -1) {
                      newStr += '<span class="c-yellow">' + line + '</span><br/>';
                    } else if (line.indexOf('[ERROR]') > -1) {
                      newStr += '<span class="c-error">' + line + '</span><br/>';
                    } else {
                      newStr += line + '<br/>';
                    }
                  }
                })
              }
              this.logDetail += newStr;
            }
            this.lastOffsets = res.data.offset;

            //维护logList
            if (this.logList.length != 0) {
              let newArray = []
              this.logList.forEach(item => {
                if (item.uploadId != uploadId) {
                  newArray.push(item)
                }
                if (item.uploadId == uploadId) {
                  newArray.push({uploadId: uploadId, logDetail: this.logDetail, lastOffsets: this.lastOffsets})
                }
              })
              this.logList = []
              this.logList = newArray
            } else {
              this.logList.push({uploadId: uploadId, logDetail: this.logDetail, lastOffsets: this.lastOffsets})
            }
            //
            if (this.lastOffsets != -1) {
              this.intervalGetLog(uploadId)
            }
          })
        }
      },
      saveOrUpdateImage(){
        this.submit_upload_loading = true;
        this.$refs['imageInfoEditForm'].validate((valid) => {
          if (valid) {
            $http.get($http.api.image_manage.check_image_repeat, {typeId: this.uploadImageInfo.typeId, imageRepo: this.uploadImageInfo.imageRepo, imageTag: this.uploadImageInfo.imageTag}).then(res => {
              if (res.status == 200) {
                this.checkImageInfo = res.data;
                if(this.checkImageInfo.check){
                  this.uploadImage();
                }else{
                  this.submit_upload_loading = false;
                  this.$message({
                    message: this.checkImageInfo.msg,
                    type: 'warning'
                  });
                }
              } else {
                this.submit_upload_loading = false;
                this.$message({
                  message: res.msg,
                  type: 'warning'
                })
              }
            });
          }
        });
      },

      downloadData(val){
        $http.get($http.api.image_manage.download_image, {uploadId: val.uploadId}).then(res => {
          if (res.status == 200) {
            window.location.href = res.data.downloadUrl;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      uploadImage(){
        let formData = new FormData();
        let manualUpload = this.uploadImageInfo.manualUpload;
        formData.append("bizId", this.currentBizId);
        formData.append("imageRepo", this.uploadImageInfo.imageRepo);
        formData.append("imageTag", this.uploadImageInfo.imageTag);
        formData.append("typeId", this.uploadImageInfo.typeId);
        formData.append("stable", this.uploadImageInfo.stable);
        formData.append("containerUp", this.uploadImageInfo.containerUp);
        formData.append("buildType", this.uploadImageInfo.buildType);
        formData.append("manualUpload", this.uploadImageInfo.manualUpload);
        if(this.uploadImageInfo.manualUpload === 0){
          let uploadform = this.$refs.upload.$data.uploadFiles;
          if (!uploadform || uploadform.length === 0) {
            this.submit_upload_loading = false;
            this.$message({
              message: '请选择文件',
              type: 'warning'
            });
            return;
          }
          formData.append("file", uploadform[0].raw);
        }
        $http.post($http.api.image_manage.upload_image, formData).then(res => {
          if (res.status == 200) {
            this.$message({
              message: "镜像上传中",
              type: "success"
            });
            this.submit_upload_loading = false;
            this.closeImageUploadDialog();
            if(manualUpload === 0){
              this.showUploadLogDialog(res.data);
              this.getBizImageInfos();
            }else{
              this.getBizImageInfos();
            }
          } else {
            this.submit_upload_loading = false;
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      changeStableCheck(){
        if(this.uploadImageInfo.stable === 1){
          if(this.uploadImageInfo.imageRepo === ''){
            this.$message({
              message: '镜像名称为空',
              type: 'warning'
            });
            this.uploadImageInfo.stable = 0;
            return;
          }
          if(this.uploadImageInfo.typeId === -1){
            this.$message({
              message: '请选择镜像类型',
              type: 'warning'
            });
            this.uploadImageInfo.stable = 0;
            return;
          }
          $http.get($http.api.image_manage.check_image_stable, {typeId: this.uploadImageInfo.typeId, imageRepo: this.uploadImageInfo.imageRepo, bizId: this.currentBizId}).then(res => {
            if (res.status == 200) {
              this.checkImageStable = res.data;
              if(this.checkImageStable){
                this.$confirm("相同镜像名称下已存在稳定版本，是否替换?", "提示", {
                  distinguishCancelAndClose: true,
                  confirmButtonText: "确定",
                  cancelButtonText: "取消",
                  type: "warning"
                }).then(() => {

                }).catch(() => {
                  this.uploadImageInfo.stable = 0;
                });
              }
            } else {
              this.$message({
                message: res.msg,
                type: 'warning'
              })
            }
          });
        }
      },

      getBizImageInfos(){
        $http.get($http.api.image_manage.biz_images).then(res => {
          if (res.status == 200) {
            if(res.data){
              this.bizImageInfos = res.data;
              this.bizImageData.total = this.bizImageInfos.length;
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      getCompileTypes(){
        $http.get($http.api.image_manage.get_pri_types,{typePrivate: 1}).then(res => {
          if (res.status == 200) {
            if(res.data){
              this.bizImageTypes = res.data;
              if(this.bizImageTypes.length > 0){
                this.uploadImageInfo.typeId = this.bizImageTypes[0].typeId
              }
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      showUploadHistryDialog(){
        this.getUploadHistrys();
        this.uploadHistryDialogShow = true;
      },
      closeUploadHistryDialog(){
        this.uploadHistryDialogShow = false;
      },

      getUploadHistrys(){
        $http.get($http.api.image_manage.image_upload_histry).then(res => {
          if (res.status == 200) {
            if(res.data != null){
              this.imageUploadHistrys = res.data;
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      showImageUploadDialog(){
        this.getCompileTypes();
        this.imageUploadDialogShow = true;
      },
      closeImageUploadDialog(){
        this.uploadImageInfo =  {
          typeId: -1,
          imageRepo: '',
          imageTag: '',
          stable: 0,
          containerUp: 0,
          buildType: 0,
          manualUpload: 0
        };
        this.imageUploadDialogShow = false;
      },
      handleImagePageChange(val){
        this.bizImageData.pageNum = val;
      },

      handleImageSizeChange(val){
        this.bizImageData.pageSize = val;
      },

      closeUploadHistryDialog(){
        this.uploadHistryDialogShow = false;
      },
      handleUploadHistryChange(val){
        this.uploadHistryData.pageSize = val;
      },
      handleUploadHistryChange(val){
        this.uploadHistryData.pageNum = val;
      },


      handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
      },

      checkImageStableMethod(item){
        if(item.stable === 0){
          $http.get($http.api.image_manage.check_image_stable, {typeId: item.typeId, imageRepo: item.imageRepo, bizId: -1}).then(res => {
            if (res.status == 200) {
              if(res.data){
                this.$confirm("相同镜像名称下已存在稳定版本，是否替换?", "提示", {
                  distinguishCancelAndClose: true,
                  confirmButtonText: "确定",
                  cancelButtonText: "取消",
                  type: "warning"
                }).then(() => {
                  this.setImageStable(item);
                }).catch(() => {

                });
              }else{
                this.setImageStable(item);
              }
            } else {
              this.$message({
                message: res.msg,
                type: 'warning'
              })
            }
          });
        }else{
          this.setImageStable(item);
        }
      },
      setImageStable(item){
        let changeStable = item.stable === 1? 0 : 1;
        $http.get($http.api.image_manage.set_image_stable, {typeId: item.typeId, imageRepo: item.imageRepo, imageId: item.imageId, stable: changeStable}).then(res => {
          if (res.status == 200) {
            this.$message({
              message: '设置稳定版本成功',
              type: 'success'
            });
            this.getBizImageInfos();
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },
      setImageContainerUp(item){
        let currentContainerUp = item.containerUp === 1?0:1;
        $http.get($http.api.image_manage.image_container_up, {imageId: item.imageId, containerUp:currentContainerUp}).then(res => {
          if (res.status == 200) {
            this.$message({
              message: '设置容器常态成功',
              type: 'success'
            });
            this.getBizImageInfos();
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },

      deleteUploadData(val){
        this.$confirm('确认删除[' + val.imageRepo + ":" + val.imageTag + ']镜像吗？').then(_ => {
          let param = {};
          param.id = val.imageId;
          param.bizId = this.currentBizId;
          $http.get($http.api.image_manage.del_image, param).then(res => {
            if (res.status == 200) {
              this.$message({message: '删除镜像成功', type: 'success'});
              this.getBizImageInfos();
            } else {
              this.$message({message: '删除镜像失败，' + res.msg, type: 'error'});
            }
          }).catch(_ => {})
        }).catch(_ => {});
      },
    }
  };
</script>

<style lang="scss" scoped>
  .box-card-body-body_right {
    display: inline-block;
    width: 100%;
    height: 900px;
    overflow: auto;
    background: black;
    border-left: 0;
    color: aliceblue;
    word-wrap: break-word;
    word-break: break-word;

  p {
    line-height: 18px;
    margin-left: 10px;
    margin-right: 10px;
  }
  }

  .box-card-body-body {
    // margin-left: 10px;

    .box-card-body-body_right {
      display: inline-block;
      width: 100%;
      height: 700px;
      overflow: auto;
      background: black;
      border-left: 0;
      color: aliceblue;
      word-wrap: break-word;
      word-break: break-word;

      p {
        line-height: 18px;
        margin-left: 10px;
        margin-right: 10px;
      }
    }
  }
</style>
