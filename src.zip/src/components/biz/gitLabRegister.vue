<template>
  <div id="bizList" class="content-outer-box">
    <div class="x-arD content-box">
      <div>
        <el-form :model="registerInfo" ref="gitLabRegister" label-width="140px">
          <el-row>
            <el-col :span="settingWidth">
              <div>
                <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
                  <el-col :span='13'>
                    <el-form-item class='mb15' label="工号" prop="jobNumber"
                                  :rules="[{required: true, message: '不能为空' ,trigger: 'blur'}]">
                      <el-input placeholder="工号，具体以TT个人信息显示为准" v-model="registerInfo.jobNumber" class="width-input-select"/>
                    </el-form-item>
                  </el-col>
                  <el-col :span='13'>
                    <el-form-item class='mb15' label="姓名拼音" prop="nameSpell"
                                  :rules="[{required: true, message: '不能为空' ,trigger: 'blur'}]">
                      <el-input placeholder="姓名拼音，不需要考虑重名情况" v-model="registerInfo.nameSpell" class="width-input-select"/>
                    </el-form-item>
                  </el-col>
                  <el-col :span='13'>
                    <el-form-item class='mb15' label="邮箱" prop="email"
                                  :rules="rules.email">
                      <el-input placeholder="请输入邮箱" v-model="registerInfo.email" class="width-input-select"/>
                    </el-form-item>
                  </el-col>
                  <el-col :span='13'>
                    <el-form-item label-width="140px" label="创建组/项目权限" prop="hasCreatePermission"
                                  :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-radio-group v-model="registerInfo.hasCreatePermission">
                        <el-radio :label="true">是</el-radio>
                        <el-radio :label="false">否</el-radio>
                      </el-radio-group>
                    </el-form-item>
                  </el-col>
                </el-row>
              </div>
            </el-col>
            <el-col :span="12">
              <div style="background-color: #a4deff;width: 400px;margin-top: 20px;border-radius:5px;margin-left: -100px">
                <div class="alert alert-info" style="font-size: 15px;padding: 15px">
                  1. 邮箱用于登录和日常接收GitLab邮件，请务必如实填写，原则上禁止使用外部邮箱!<br/><br/>
                  2. GitLab登录账号为工号，或者邮箱地址，初始密码为12345678，登录后请自行修改<br/>
                </div>
              </div>
            </el-col>
          </el-row>
        </el-form>
        <div class="foot">
          <el-col :span='13'>
            <el-button style="margin-left: 570px" type="primary" class="button-left" @click="registerGitLab()" size="medium">保存</el-button>
          </el-col>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'gitLabRegister',
    data() {
      let validEmail = (rule, value, callback) => {
        let temp = /^[\w.\-]+@(?:[a-z0-9]+(?:-[a-z0-9]+)*\.)+[a-z]{2,3}$/
        if (value && (!(temp).test(value))) {
          callback(new Error('邮箱格式不符合规范'))
        } else {
          callback()
        }
      };
      return {
        settingWidth: 12,
        rules: {
          email: [{required: true, message: '邮箱不能为空',trigger: 'blur'}, {validator: validEmail, trigger: 'blur'}]
        },
        registerInfo: {
          jobNumber: '',
          nameSpell: '',
          email: '',
          hasCreatePermission: false,
        },
      }
    },

    mounted() {
      window.onresize = () => {
        this.reactiveLayOut()
      };
    },

    methods: {
      reactiveLayOut() {
        let offsetWidth = document.body.offsetWidth;
        if (offsetWidth < 1450) {
          return this.settingWidth = 13;
        } else {
          return this.settingWidth = 12;
        }
      },
      registerGitLab() {
        this.$refs['gitLabRegister'].validate(pass => {
          if (pass) {
            let param = this.registerInfo;
            $http.post($http.api.biz.gitlab_user, param).then(res => {
              if (res.status == 200) {
                this.$message({
                  message: '注册成功',
                  type: 'success'
                });
                this.registerInfo = {};
              }
            })
          }
        })
      },
      authWithOutDataId(funcId,funcType) {
        let permissionInfo = $utils.getStorage(GLOBAL_CONST.USER_PERMISSION_INFO);
        let show = false;
        if (permissionInfo) {
          if (permissionInfo.isAdmin && permissionInfo.isAdmin == 1) {
            return true;
          }
          let functionList = permissionInfo.funcInfos;
          if (functionList) {
            functionList.some((func) => {
              if (func.type == funcType && func.id == funcId) {
                show = true;
                return true;
              }
            })
          }
        }
        return show;
      },

    }
  }
</script>

<style>

</style>
