<template>
  <div id="bizMemberSetting" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box" style="height: -webkit-calc(100% - 45px);">
        <div
          style="min-height:200px;width:calc(50% - 8px);display:inline-block;vertical-align: top;margin: 10px 0px 10px 0px;border:1px solid #dfe3ed;">
          <div style="height:50px;">
            <span class="tit fl mt10 ml10" style="font-size: 16px;font-weight:900;">业务成员信息</span>
            <el-input v-model="objInfo.bizMemberQryStr" class="fl ml10 mt10" style="width:200px;"
                      placeholder="请输入人员名称"></el-input>
            <el-button type="primary" class="fl mt10 ml10" @click="getBizMembers">查询</el-button>
            <el-button type="primary" class="fr mt10 mr10" v-if="userRole!==4" @click="showAddMemberDialog">添加</el-button>
          </div>
          <div style="">
            <el-table :border="true" :data="bizMemberData.list" style="width: 100%;height: 100%;">
              <el-table-column label="人员" min-width="120">
                <template slot-scope="scope">
                  {{scope.row.userName+'('+scope.row.userId+')'}}
                </template>
              </el-table-column>
              <el-table-column label="角色" min-width="180">
                <template slot-scope="scope">
                  {{arrayJoiner(scope.row.roleInfos,'、','roleName')}}
                </template>
              </el-table-column>
              <el-table-column label="操作" v-if="userRole!==4" width="120">
                <template slot-scope="scope">
                  <span class="c-blue cp" v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)" @click="showEditBizMemberDialog(scope.row)">编辑</span>
                  <span class="cp" :class="deleteView(scope.row.roleInfos)?'c-blue':'c-gray'" @click="deleteView(scope.row.roleInfos)?delBizMember(scope.row):''">删除</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="table_b_f_b">
            <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleSizeChange"
                           @current-change="handleCurrentChange"
                           :current-page="bizMemberData.pageNum" :page-sizes="[10, 20, 30]"
                           :page-size="bizMemberData.pageSize"
                           layout="total, sizes, prev, pager, next, jumper" :total="bizMemberData.total">
            </el-pagination>
          </div>
        </div>
        <div
          style="min-height:200px;width:calc(50% - 10px);display:inline-block;margin-left:2px;margin-left:10px;;margin-top:10px;border:1px solid #dfe3ed;">
          <div style="height:50px;">
            <span class="tit fl mt10 ml10" style="font-size: 16px;font-weight:900;">业务运维人员</span>
            <el-input v-model="objInfo.bizOpsMemberQryStr" class="fl ml10 mt10" style="width:200px;"
                      placeholder="请输入人员名称"></el-input>
            <el-button type="primary" class="fl mt10 ml10" @click="getBizOpsMembers">查询</el-button>
            <el-button type="primary" class="fr mt10 mr10" v-show="authFunction('FUNC_BIZ_OPE_ADD', 1)"
                       @click="showAddOpsDialog">添加
            </el-button>
          </div>
          <div style="">
            <el-table :border="true" :data="bizOpsMemberData.list" style="width: 100%;height: 100%;">
              <el-table-column prop="userName" label="人员" min-width="120">
                <template slot-scope="scope">
                  {{scope.row.userName+'('+scope.row.userId+')'}}
                </template>
              </el-table-column>
              <el-table-column label="角色" min-width="180">
                <template slot-scope="scope">
                  {{arrayJoiner(scope.row.roleInfos,'、','roleName')}}
                </template>
              </el-table-column>
              <el-table-column label="操作" v-if="userRole===0" width="120">
                <template slot-scope="scope">
                  <span class="c-blue cp" @click="delBizOpeMember(scope.row)">删除</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="table_b_f_b">
            <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleOpsSizeChange"
                           @current-change="handleOpsCurrentChange"
                           :current-page="bizOpsMemberData.pageNum" :page-sizes="[10, 20, 30]"
                           :page-size=bizOpsMemberData.pageSize
                           layout="total, sizes, prev, pager, next, jumper" :total="bizOpsMemberData.total">
            </el-pagination>
          </div>
        </div>
        <div class="table-box p10" v-loading="table_loading" v-if="userRole!==4" element-loading-text="拼命加载中"
             style="border:1px solid #dfe6ec;height:auto;">
          <div class="function-bar" style="height:50px;">
            <span class="fl mr10">请选择设置项:</span>
            <el-radio-group class="fl mt10"
                            text-color='#ffffff'
                            fill='#409EFF'
                            v-model="settingRadio"
                            size="small"
                            @change="handleSelect()">
              <el-radio-button label="1" v-if="batchButtonControl(1)">批量替换应用owner</el-radio-button>
              <el-radio-button label="2" v-if="batchButtonControl(2)">批量添加应用开发人员</el-radio-button>
              <el-radio-button label="3" v-if="batchButtonControl(3)">批量添加应用测试人员</el-radio-button>
            </el-radio-group>

            <el-button type="success" class="fr mt10" v-if="showtable == 'owner'" @click="batrepBtn()">批量替换</el-button>
            <el-button type="success" class="fr mt10 mr0" v-if="showtable == 'exploit' || showtable == 'test' "
                       @click="bataddBtn()">批量新增
            </el-button>
            <el-button type="primary" class="fr mt10 mr10" v-if="showtable == 'test'" @click='changeBtn()'>设置
            </el-button>
            <el-button type="primary" class="fr mt10 mr10" style="margin-left:10px;" @click="getAppList">查询</el-button>
            <el-input v-model="search" placeholder="请输入应用ID，如‘demo12’" class="fr product-box ml10"></el-input>
          </div>
          <div class="table-box-top" style="height: -webkit-calc(100% - 90px);">
            <el-table :border="true" :data="appData.list" style="width: 100%;height: 100%;">
              <el-table-column prop="appCode" label="应用ID" min-width="50"></el-table-column>
              <el-table-column label="应用owner" min-width="200" v-if="showtable === 'owner'">
                <template slot-scope="scope">
                  {{scope.row.appOwner?(scope.row.appOwner.userName+'('+scope.row.appOwner.userId+')'):''}}
                </template>
              </el-table-column>
              <el-table-column label="应用开发" min-width="200" v-if="showtable === 'exploit'">
                <template slot-scope="scope">
                  {{arrayJoiner(scope.row.devs,'、','userName')}}
                </template>
              </el-table-column>
              <el-table-column label="应用测试" min-width="200" v-if="showtable === 'test'">
                <template slot-scope="scope">
                  {{arrayJoiner(scope.row.tests,'、','userName')}}
                </template>
              </el-table-column>
              <el-table-column width="80" label="操作">
                <template slot-scope="scope">
                  <span class="c-blue cp" @click="showReplaceOwnerDialog(scope.row)"
                        v-if="showtable === 'owner'">替换</span>
                  <span class="c-blue cp" @click="onAddButtonClick(scope.row)"
                        v-if="showtable === 'exploit' || showtable == 'test' ">新增</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="table_b_f_b">
            <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleAppSizeChange"
                           @current-change="handleAppCurrentChange"
                           :current-page="appData.pageNum" :page-sizes="[10, 20, 30]" :page-size="appData.pageSize"
                           layout="total, sizes, prev, pager, next, jumper"
                           :total="appData.total">
            </el-pagination>
          </div>
        </div>
      </div>
    </div>

    <!-- 添加业务成员信息弹窗 -->
    <el-dialog :title='objTitle'
               class="el-dialog-580w"
               :before-close="closeAddBizMemberDialog"
               :visible.sync="dialogVisible_obj" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="objInfo" ref="objInfo">
          <el-form-item label="姓名/工号" label-width="90px" prop="bizMemberAddName" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-select v-model="objInfo.bizMemberAddName" multiple
                       :disabled="!objInfo.isAdd"
                       filterable
                       remote
                       placeholder="输入姓名或工号搜索，未登录过哥伦布的人员仅支持工号搜索"
                       :remote-method="searchRemoteMember"
                       :loading="loading"
                       style="width:100%;">
              <el-option v-for="item in userBos" :key="item.userId" :label="item.userName" :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="职责" label-width="90px"  prop="bizMemberAddRoles" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-select v-model="objInfo.bizMemberAddRoles" multiple filterable placeholder="请选择" @change="filterRole" :disabled="addButtonControl" style="width:100%">
              <el-option v-for="item in bizRoles" :key="item.value" :label="item.label"
                         :value="item.value" :disabled="item.disabled"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="addOrEditBizMembers">保存</el-button>
        <el-button class="fr" @click="closeAddBizMemberDialog">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 业务运维人员弹窗 -->
    <el-dialog :title="ops_Title" id="bizOpsMemberDialog" class="el-dialog-580w"
               :before-close="closeOpsDialog"
               :visible.sync="dialogVisible_ops" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="objInfo" ref="objInfo">
          <el-form-item label="姓名/工号" label-width="90px" prop="bizOpsMemberAddName" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-select v-model="objInfo.bizOpsMemberAddName" placeholder="请输入关键词" multiple filterable :filter-method="filterBizMemberMethod"
                       style="width:100%;">
              <el-option v-for="item in memberbos" :key="item.userId" :label="item.userName" :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="职责" label-width="90px"  prop="bizOpsMemberAddRoles" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-select v-model="objInfo.bizOpsMemberAddRoles" disabled style="width:100%">
              <el-option v-for="item in bizOpsRoles" :key="item.value" :label="item.label" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="addBizOpsMembers">保存</el-button>
        <el-button class="fr" @click="closeOpsDialog">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 批量替换/新增弹窗 -->
    <el-dialog :title="yyTitle"  class="el-dialog-740w" :before-close="handleClose"
               :visible.sync="dialogVisible" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div class="tab-box">
          <el-transfer :titles="['未选应用列表', '已选应用列表']" filterable @change="handleChange" :filter-method="filterMethod"
                       filter-placeholder="请输入应用名称" v-model="value2" :data="data2">
          </el-transfer>
        </div>
        <div class="label-name">
          <el-form ref="yyinfoname" label-width="120px">
            <el-form-item style="margin-top:10px;" label="设置应用owner为" v-if="showtable == 'owner'">
              <el-select v-model="appSetting.owner.userId" filterable :filter-method="searchMember" placeholder="请选择" style="width:93%;">
                <el-option v-for="item in appSetting.optionMember" :key="item.userId" :label="item.userName"
                           :value="item.userId">
                  <span style="float: left">{{ item.userName }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px">{{ item.userId }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item style="margin-top:10px;" label="新增应用开发人员" v-if="showtable == 'exploit'">
              <el-select v-model="appSetting.devUser.userIds" filterable :filter-method="searchMember" multiple placeholder="请选择" style="width:93%;">
                <el-option v-for="item in appSetting.optionMember" :key="item.userId" :label="item.userName"
                           :value="item.userId">
                  <span style="float: left">{{ item.userName }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
                </el-option>
              </el-select>
            </el-form-item>
            <el-form-item style="margin-top:10px;" label="新增应用测试人员" v-if="showtable == 'test'">
              <el-select v-model="appSetting.testUser.userIds" filterable :filter-method="searchMember" multiple placeholder="请选择" style="width:93%;">
                <el-option v-for="item in appSetting.optionMember" :key="item.userId" :label="item.userName"
                           :value="item.userId">
                  <span style="float: left">{{ item.userName }}</span>
                  <span style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="batchSave">保存</el-button>
        <el-button class="fr" @click="handleClose()">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 已有应用批量设置 -->
    <el-dialog title="批量设置" id="yyDialog" class="el-dialog-740w" :before-close="handleClose_b"
               :visible.sync="dialogVisible_b" :modal-append-to-body="true" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div class="tab-box">
          <div style="height:30px;">
            <el-switch v-model="switch_value1" inactive-text="新增应用默认设置：" class="fl mt10" style="margin-left:20px;"
                       @change='setBtn(switch_value1)'></el-switch>
          </div>
          <p style="height: 40px;line-height: 50px;margin-left:20px;">是否允许将业务开发人员添加为应用测试</p>
          <el-transfer :titles="['不允许', '允许']" filterable @change="handleChange" :filter-method="filterMethod"
                       filter-placeholder="请输入ID账号" v-model="value2" :data="data2">
          </el-transfer>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="handleSure_b()">保存</el-button>
        <el-button class="fr"  @click="handleClose_b()">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 表格替换/新增弹窗 -->
    <el-dialog :title='yyTitle'  :visible.sync="dialogVisible_a"
               class="el-dialog-400w"
               :before-close="closeSettingDialog" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form ref="yyinfoname_a" label-width="70px">
          <el-form-item  label="应用ID">
            <el-input placeholder="请输入内容" v-model="appSetting.appCode" disabled></el-input>
          </el-form-item>

          <el-form-item label="业务成员" v-if="showtable == 'owner'">
            <el-select v-model="appSetting.owner.userId" filterable :filter-method="searchMember" placeholder="请选择" style="width:100%;">
              <el-option v-for="item in appSetting.optionMember" :key="item.userId" :label="item.userName"
                         :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>

          <el-form-item  label="业务成员" v-if="showtable == 'exploit'">
            <el-select v-model="appSetting.devUser.userIds" filterable :filter-method="searchMember" multiple placeholder="请选择" style="width:100%;">
              <el-option v-for="item in appSetting.optionMember" :key="item.userId" :label="item.userName"
                         :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="业务成员" v-if="showtable == 'test'">
            <el-select v-model="appSetting.testUser.userIds" filterable :filter-method="searchMember" multiple placeholder="请选择" style="width:100%;">
              <el-option v-for="item in appSetting.optionMember" :key="item.userId" :label="item.userName"
                         :value="item.userId">
                <span style="float: left">{{ item.userName }}</span>
                <span style="float: right; color: #8492a6; font-size: 13px; margin-right:25px;">{{ item.userId }}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="settingSave(false)">保存</el-button>
        <el-button class="fr" @click="closeSettingDialog">关闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "bizMemberSetting",
    data() {
      return {
        userId:"",
        userRole: 4,
        loading: false,
        memberbos: [],
        allMemberbos: [],
        userBos: [],
        activeButton: 0,
        data2: [],
        value2: [],
        filterMethod(query, item) {
          return item.label.indexOf(query) > -1;
        },
        bizRoles: [
          {
            value: "BIZ_ADMIN",
            label: "业务管理员"
          },
          {
            value: "BIZ_DEVELOP_LEADER",
            label: "开发负责人"
          }, {
            value: "BIZ_TEST_LEADER",
            label: "测试负责人"
          },
          {
            value: "BIZ_DEVELOPER",
            label: "开发人员"
          },
          {
            value: "BIZ_TESTER",
            label: "测试人员"
          }
        ],
        addButtonControl:false,
        bizOpsRoles: [
          {
            value: "BIZ_OPERATOR",
            label: "业务运维"
          }],
        dialogVisible: false, //通过确定弹窗
        shadeBtn: false, //禁止点击遮罩层关闭弹窗
        search: null,
        yyTitle: "替换应用Owner",
        showtable: "owner",
        settingRadio: "",
        yyinfoname: {
          name: "",
          name1: [],
          name2: []
        },
        dialogVisible_a: false,
        dialogVisible_b: false,
        appSetting: {
          optionMember: [],
          optionMemberBackup: [],
          allBizMember:[],
          devMember:[],
          testMember:[],
          appList:[],
          appTestOrigin:0,
          appId: null,
          owner: {userId: null},
          devUser: {userIds: []},
          testUser: {userIds: []},
        },
        modaltobody: false,
        switch_value1: "",
        switch_value2: "",
        tableData: {},
        table_loading: false,
        appOwnerSettingInfo: {},
        tableList: {},
        //业务成员信息
        bizMemberData: {list: [], pageNum: 1, pageSize: 10, total: 0, pages: 0},
        bizOpsMemberData: {list: [], pageNum: 1, pageSize: 10, total: 0, pages: 0},
        appData: {list: [], pageNum: 1, pageSize: 10, total: 0, pages: 0},
        dialogVisible_obj: false,
        objTitle: '',
        objInfo: {
          bizId: 0,
          isAdd: true,
          bizMemberQryStr: "",
          bizMemberAddName: [],
          bizMemberAddRoles: [],
          bizOpsMemberAddName: "",
          bizOpsMemberAddRoles: "业务运维",
          userIds: [],
          userIdsStr: ""
        },
        dialogVisible_ops: false,
        ops_Title: ''
      };
    },

    mounted() {
      this.getIdentity();
      this.userId=$utils.getCurrentUserId();
      this.objInfo.bizId = this.$route.query.bizId;
      this.getPage();
    },

    methods: {
      filterBizMemberMethod(text){
        if (text == '') {
          this.memberbos = this.allMemberbos.concat([]);
        } else {
          this.memberbos = this.allMemberbos.filter(item => {
            return item.userName.indexOf(text) != -1 || item.userId.indexOf(text) != -1
          });
        }
      },
      searchMember(query){
        if (query) { //val存在
          this.appSetting.optionMember = this.appSetting.optionMemberBackup.filter((item) => {
            if (!!~item.userName.indexOf(query)||!!~item.userId.indexOf(query)) {
              return true
            }
          })
        } else { //val为空时，还原数组
          this.appSetting.optionMember = this.appSetting.optionMemberBackup;
        }
      },

      getIdentity(){
        if (this.authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)) {
          this.userRole=0;
        }else if (this.authFunction('FUNC_BIZ_IDENTITY_DEV',1)&&this.authFunction('FUNC_BIZ_IDENTITY_TEST',1)) {
          this.userRole=3;
        }else if (this.authFunction('FUNC_BIZ_IDENTITY_DEV',1)) {
          this.userRole=1;
        }else if (this.authFunction('FUNC_BIZ_IDENTITY_TEST',1)) {
          this.userRole=2;
        }

        if (this.userRole!==4){
          this.initBatchData();
          this.getAllApp();
        }
      },

      deleteView1(roleInfos){
        if (this.authFunction('FUNC_BIZ_IDENTITY_ADMIN',1)) {
          return true;
        }
        if (this.authFunction('FUNC_BIZ_IDENTITY_DEV',1)&&this.authFunction('FUNC_BIZ_IDENTITY_TEST',1)) {
          for (let i=0;i<roleInfos.length;i++){
            if (roleInfos[i].roleId==="BIZ_DEVELOPER"||roleInfos[i].roleId==="BIZ_TESTER") {
              return true;
            }
          }
        }
        if (this.authFunction('FUNC_BIZ_IDENTITY_DEV',1)) {
          for (let i=0;i<roleInfos.length;i++){
            if (roleInfos[i].roleId==="BIZ_DEVELOPER") {
              return true;
            }
          }
        }
        if (this.authFunction('FUNC_BIZ_IDENTITY_TEST',1)) {
          for (let i=0;i<roleInfos.length;i++){
            if (roleInfos[i].roleId==="BIZ_TESTER") {
              return true;
            }
          }
        }

        return false;
      },

      deleteView(roleInfos){
        if (this.userRole===0){
          return true;
        };
        if (this.userRole===3){
          for (let i=0;i<roleInfos.length;i++){
            if (roleInfos[i].roleId==="BIZ_DEVELOPER"||roleInfos[i].roleId==="BIZ_TESTER") {
              return true;
            }
          }
        };
        if (this.userRole===1){
          for (let i=0;i<roleInfos.length;i++){
            if (roleInfos[i].roleId==="BIZ_DEVELOPER") {
              return true;
            }
          }
        }
        if (this.userRole===2){
          for (let i=0;i<roleInfos.length;i++){
            if (roleInfos[i].roleId==="BIZ_TESTER") {
              return true;
            }
          }
        };
        return false;
      },

      batchButtonControl(buttonType){
        if (this.userRole===0){
          return true;
        }
        if(buttonType===2&&(this.userRole===3||this.userRole===1)){
          return true;
        }
        if (buttonType===3&&(this.userRole===3||this.userRole===2)){
          return true;
        }
      },

      getSettingRadio(){
        //this.initBatchData()
        return this.settingRadio;
      },

      initBatchData(){
        let roleId=this.userRole;
        if (roleId===0){
          this.settingRadio="1"
        } ;
        if(roleId===1||roleId===3){
          this.settingRadio="2"
        };
        if (roleId===2){
          this.settingRadio="3"
        }
        if (roleId===4){
          return;
        }
        this.handleSelect();
      },

      getBatchSettingMember(){
        $http.get($http.api.biz.get_biz_member,{bizId: this.objInfo.bizId}).then((res)=> {
          this.appSetting.allBizMember=res.data.allBizMember;
          this.appSetting.devMember=res.data.devMember;
          this.appSetting.testMember=res.data.testMember;
          if (this.showtable == 'owner') {
            this.appSetting.optionMember=this.appSetting.allBizMember;
          }
          if (this.showtable == 'exploit') {
            this.appSetting.optionMember=this.appSetting.devMember;
          }
          if (this.showtable == 'test') {
            if (this.appSetting.appTestOrigin===1){
              this.appSetting.optionMember=this.appSetting.allBizMember;
            } else{
              this.appSetting.optionMember=this.appSetting.testMember;
            }
          }
          this.appSetting.optionMemberBackup=this.appSetting.optionMember;
        });
      },

      getAllApp(){
        $http.get($http.api.biz.get_app_for_bacth,{bizId: this.objInfo.bizId}).then((res)=> {
          this.appSetting.appList=res.data;
        })
      },

      filterRole(){
        let roles=this.objInfo.bizMemberAddRoles;
        let size=roles.length;
        let role=roles[size-1];
        if (role==="BIZ_DEVELOPER"){
          for (let i=0;i<size;i++){
            if (roles[i]==="BIZ_TESTER") {
              this.objInfo.bizMemberAddRoles.splice(size-1);
              this.$message({
                message: '业务人员不能同时为测试和开发！',
                type: 'warning'
              });
            }
          }
        }
        if (role==="BIZ_TESTER"){
          for (let i=0;i<size;i++){
            if (roles[i]==="BIZ_DEVELOPER") {
              this.objInfo.bizMemberAddRoles.splice(size-1);
              this.$message({
                message: '业务人员不能同时为测试和开发！',
                type: 'warning'
              });
            }
          }
        }
      },

      handleChange(){},
      //获取数据列表
      getPage() {
        this.getBizMembers();
        this.getBizOpsMembers();
      },
      getBizMembers() {
        //获取业务成员信息
        let params = {
          bizId: this.objInfo.bizId,
          pageNum: this.bizMemberData.pageNum,
          pageSize: this.bizMemberData.pageSize,
          userName: this.objInfo.bizMemberQryStr
        };
        $http.get($http.api.biz.list_biz_members, params).then((res) => {
          this.bizMemberData = res.data;
        });
      },

      addOrEditBizMembers() {
        if (this.objInfo.bizMemberAddName.length === 0) {
          this.$message({
            message: '姓名/工号不能为空',
            type: 'warning'
          });
          return;
        }

        if (this.objInfo.bizMemberAddRoles.length === 0) {
          this.$message({
            message: '职责不能为空',
            type: 'warning'
          });
          return;
        }

        //获取业务成员信息
        const vm = this;
        let params = {};
        let params1 = {
          userIdsStr: this.objInfo.bizMemberAddName.join(","),
          roleIdsStr: this.objInfo.bizMemberAddRoles.join(","),
          bizId: this.objInfo.bizId
        };
        let params2 = {
          userId: this.objInfo.bizMemberAddName.toString(),
          roleIdsStr: this.objInfo.bizMemberAddRoles.join(","),
          bizId: this.objInfo.bizId
        };
        if (this.objInfo.isAdd) {
          params = params1;
        } else {
          params = params2;
        }
        if (this.userRole===0){
          $http.post(this.objInfo.isAdd ? $http.api.biz.add_biz_member : $http.api.biz.edit_biz_member, params).then((res) => {
            this.$message({
              message: this.objInfo.isAdd ? '添加成功' : '修改成功',
              type: 'success'
            });
            if (!this.objInfo.isAdd&&this.userId===params.userId){
              this.getIdentity();
            }
            this.closeAddBizMemberDialog();
            this.getBizMembers();
            this.getAppList();
          }, () => {
            this.$message({
              message: '添加失败',
              type: 'error'
            });
          });
        } else {
          $http.post($http.api.biz.add_biz_devtest, params).then((res) => {
            this.$message({
              message: '添加成功',
              type: 'success'
            });
            this.closeAddBizMemberDialog();
            this.getBizMembers();
            this.getAppList();
          }, () => {
            this.$message({
              message: '添加失败',
              type: 'error'
            });
          });
        }

      },

      delBizMember(delUser) {
        let role=this.userRole;
        if (role===0){
          this.$confirm("确定将"+delUser.userName+"从业务中删除?", "提示", {
            distinguishCancelAndClose: true,
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(() => {
            $http.post($http.api.biz.del_biz_member, {
              userId: delUser.userId,
              bizId: this.objInfo.bizId
            }).then((res) => {
              if(res.status===200){
                this.$message({
                  message: '删除成功',
                  type: 'success'
                });
                this.getBizMembers();
                this.getAppList();
              }else{
                this.$message({
                  message: res.msg,
                  type: 'error'
                });
              }
            })
          }).catch(() => {
          });
        }else {
          let roleId = "";
          let roleName = "";
          if (role === 3) {
            let roles = delUser.roleInfos
            for (let i = 0; i < roles.length; i++) {
              if (roles[i].roleId === "BIZ_DEVELOPER") {
                roleName = "业务开发人员";
                roleId = roles[i].roleId;
              }
              if (roles[i].roleId === "BIZ_TESTER") {
                roleName = "业务测试人员";
                roleId = roles[i].roleId;
              }
            }
          }
          if (role === 1) {
            roleName = "业务开发人员";
            roleId = "BIZ_DEVELOPER";
          }
          if (role === 2) {
            roleName = "业务测试人员";
            roleId = "BIZ_TESTER";
          }
          this.$confirm("确定将" + delUser.userName + "的" + roleName + "角色删除?", "提示", {
            distinguishCancelAndClose: true,
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(() => {
            $http.get($http.api.biz.del_biz_devtest, {
              userId: delUser.userId,
              roleId: roleId,
              bizId: this.objInfo.bizId
            }).then((res) => {
              if(res.status===200) {
                this.$message({
                  message: '删除成功',
                  type: 'success'
                });
                this.getBizMembers();
                this.getAppList();
              }
            });
          }).catch(() => {
          });
        }
      },

      getBizOpsMembers() {
        $http.get($http.api.biz.list_biz_ope_members, {
          bizId: this.objInfo.bizId,
          pageNum: this.bizOpsMemberData.pageNum,
          pageSize: this.bizOpsMemberData.pageSize,
          userName: this.objInfo.bizOpsMemberQryStr
        }).then((res) => {
          this.bizOpsMemberData = res.data;
        });
      },
      addBizOpsMembers() {
        if (this.objInfo.bizOpsMemberAddName.length === 0) {
          this.$message({
            message: '姓名/工号不能为空',
            type: 'warning'
          });
          return;
        }

        let params = {
          userIdsStr: this.objInfo.bizOpsMemberAddName.join(","),
          bizId: this.objInfo.bizId
        };
        this.closeOpsDialog();
        $http.post($http.api.biz.add_biz_ops_member, params).then((res) => {
          this.$message({
            message: '添加成功',
            type: 'success'
          });
          this.closeAddBizMemberDialog();
          this.getBizOpsMembers();
        }).catch(() => {
          this.$message({
            message: '添加失败',
            type: 'error'
          });
        });
      },
      arrayJoiner(inputArray, joiner, keyName) { //数组拼接
        let title = "";
        var arr = [];
        if (inputArray){
          inputArray.forEach(item => {
            if (!keyName) {
              arr.push(item);
            } else {
              if (keyName==="userName") {
                arr.push(item[keyName]+'('+item["userId"]+')');
              }else{
                arr.push(item[keyName]);
              }

            }
          })
        }
        return arr.join(joiner)
      },
      getAppList() {
        //获取app列表
        $http.get($http.api.biz.get_biz_batch_setting_info, {
          pageNum: this.appData.pageNum,
          pageSize: this.appData.pageSize,
          bizId: this.objInfo.bizId,
          appCode: this.search,
          appRole: this.settingRadio
        }).then((res) => {
          this.appData = res.data;
        });
      },

      //页面切换
      handleSelect() {
        if (this.settingRadio == "1") {
          this.showtable = "owner";
          this.yyTitle = "替换应用Owner";
        } else if (this.settingRadio == "2") {
          this.showtable = "exploit";
          this.yyTitle = "新增应用开发";
        } else if (this.settingRadio == "3") {
          this.showtable = "test";
          this.yyTitle = "新增应用测试";
        }
        this.getAppList();
      },
      setBatchData() {
        let appList=this.appSetting.appList;
        var data = [];
        for (let i = 0; i < appList.length; i++) {
          let obj = appList[i];
          if (obj.appCode) {
            data.push({key: obj.appId + "", label: obj.appCode})
          }
        }
        this.data2 = data;
      },
      //批量替换
      batrepBtn() {
        this.getBatchSettingMember();
        this.dialogVisible = true;
        this.setBatchData();
      },

      //批量新增
      bataddBtn() {
        this.appSetting.appTestOrigin=0;
        this.getBatchSettingMember();
        this.dialogVisible = true;
        this.setBatchData();
      },

      //设置按钮
      setBtn(val) {
        this.$confirm("是否确定修改此设置?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          let defalutTest=this.switch_value1?1:0;
          $http.post($http.api.biz.change_biz_default_test,{bizId:this.objInfo.bizId,defaultTest:defalutTest},{type: 'form'}).then((res)=> {
            if (res.status===200){
              this.$message({
                type: "success",
                message: "设置成功"
              });
            }
          })
        })
          .catch(() => {
            this.switch_value1 = !val;
          });
      },

      //已有应用批量设置按钮
      changeBtn() {
        this.initShezhi();
        this.dialogVisible_b = true;
      },

      //初始化设置界面
      initShezhi(){

        $http.get($http.api.biz.get_all_test_origin).then((res)=> {
          let appOfTestOrigin=res.data.appNameVos;
          this.switch_value1=res.data.defaulttest===1?true:false;
          let allData=[];
          let allowData=[];
          appOfTestOrigin.forEach((app)=> {
            if (app.appTestOrigin===1){
              allowData.push(app.appId+"");
            }
            allData.push({key: app.appId + "", label: app.appCode})
          })
          this.value2=allowData;
          this.data2=allData;
        });

      },
      //关闭弹窗
      handleClose() {
        this.value2=[];
        this.appSetting.owner.userId=null;
        this.appSetting.devUser.userIds=[];
        this.appSetting.testUser.userIds=[];
        this.dialogVisible = false;
      },

      //保存已选人员
      batchSave() {
        this.settingSave(true);
      },

      //表格替换按钮
      showReplaceOwnerDialog(val) {
        this.appSetting.appTestOrigin=0;
        this.getBatchSettingMember();
        this.dialogVisible_a =val.appOwner?true:false;
        this.appSetting.appId = val.appId;
        this.appSetting.appCode = val.appCode;
        this.appSetting.owner = val.appOwner?val.appOwner:[];
      },

      //表格替换按钮
      showAddDialog(val) {
        this.onAddButtonClick()
        this.dialogVisible_a = true;
      },

      //关闭替换弹窗
      closeSettingDialog() {
        this.appSetting.owner.userId=null;
        this.appSetting.devUser.userIds=[];
        this.appSetting.testUser.userIds=[];
        this.dialogVisible_a = false;
      },

      //保存已选人员
      settingSave(batch) {
        let params = {};
        let url = {};
        if (batch) {
          if (this.value2.length === 0) {
            this.$message({
              message: '应用不能为空',
              type: 'error'
            });
            return;
          }
          params.appIdsStr = this.value2.join(",");
        } else {
          params.appIdsStr = this.appSetting.appId;
        }
        if (this.showtable === 'owner') {
          if (this.appSetting.owner.userId === null) {
            this.$message({
              message: '应用owner不能为空',
              type: 'error'
            });
            return;
          }
          url = $http.api.biz.batch_change_owner;
          params.ownerId = this.appSetting.owner.userId;
        } else if (this.showtable === 'exploit') {
          if (this.appSetting.devUser.userIds.length === 0) {
            this.$message({
              message: '开发者不能为空',
              type: 'error'
            });
            return;
          }
          url = $http.api.biz.batch_add_app_devs;
          params.userIdsStr = this.appSetting.devUser.userIds.join(",");
        } else if (this.showtable === 'test') {
          if (this.appSetting.testUser.userIds.length === 0) {
            this.$message({
              message: '测试人员不能为空',
              type: 'error'
            });
            return;
          }
          url = $http.api.biz.batch_add_app_tests;
          params.userIdsStr = this.appSetting.testUser.userIds.join(",");
        }
        this.closeSettingDialog();
        $http.post(url, params).then((res) => {
          this.$message({
            message: '保存成功',
            type: 'success'
          });
          this.handleClose();
          this.getAppList();
        })
      },

      onAddButtonClick(val) {
        this.appSetting.appTestOrigin=val.appTestOrigin;
        this.getBatchSettingMember();
        this.appSetting.appId = val.appId;
        this.appSetting.owner = val.appOwner?val.appOwner:[];
        this.appSetting.appCode = val.appCode;
        this.dialogVisible_a = true;
      },

      //已有应用批量设置关闭
      handleClose_b() {
        this.value2=[];
        this.dialogVisible_b = false;
      },

      //已有应用批量设置保存
      handleSure_b() {
        this.setAppTestOrigin();
      },

      setAppTestOrigin(){
        let allowSelect=new Set();
        let noAllowSelect=[];
        this.value2.forEach(item=> {
          allowSelect.add(item);
        });
        this.data2.forEach(item=> {
          let notAppId=item.key;
          if (!allowSelect.has(notAppId)){
            noAllowSelect.push(notAppId);
          }
        });
        let params={
          bizId: this.objInfo.bizId,
          allowAppIdsStr: this.value2.join(","),
          notAllowAppIdsStr: noAllowSelect.join(",")
        };
        $http.post($http.api.biz.set_app_test_origin,params,{type:'form'}).then((res)=> {
          if (res.status===200){
            this.$message({
              message: '保存成功',
              type: 'success'
            });
            this.getAppList();
            this.handleClose_b();
          }else {
            this.$message({
              message: '保存失败',
              type: 'success'
            });
          }
        });
      },
      //添加业务成员信息打开弹窗
      showAddMemberDialog() {
        this.objInfo.bizMemberAddRoles = [];
        if (this.userRole===1){
          this.objInfo.bizMemberAddRoles.push("BIZ_DEVELOPER");
          this.addButtonControl=true;
        }
        if (this.userRole===2){
          this.objInfo.bizMemberAddRoles.push("BIZ_TESTER");
          this.addButtonControl=true;
        }
        if(this.userRole===3){
          this.bizRoles[0].disabled=true;
          this.bizRoles[1].disabled=true;
          this.bizRoles[2].disabled=true;
        }
        $http.get($http.api.biz.getAllUser,{keyWord: ''}).then((res) => {
          this.userBos = res.data;
        })
        this.objTitle = '添加业务成员';
        this.objInfo.isAdd = true;
        this.objInfo.bizMemberAddName = [];
        this.dialogVisible_obj = true;
      },

      searchRemoteMember(query){
        if (query !== '') {
          this.loading = true;
          setTimeout(() => {
            this.loading = false;
            $http.get($http.api.biz.getAllUser, {keyWord: query}).then((res) => {
              this.userBos = res.data;
            });
          },200)
        } else {
          this.options4 = [];
        }
      },

      //关闭添加业务成员信息的弹窗
      closeAddBizMemberDialog() {
        this.dialogVisible_obj = false;
      },

      //保存添加业务成员信息的弹窗
      editBizMemberDialog() {
        this.closeAddBizMemberDialog();
      },

      //编辑业务成员信息打开弹窗
      showEditBizMemberDialog(memberInfo) {
        this.objInfo.isAdd = false;
        this.userBos = [];
        this.userBos.push(memberInfo);

        this.objInfo.bizMemberAddName = [];
        this.objInfo.bizMemberAddName.push(memberInfo.userId + "");

        this.objInfo.bizMemberAddRoles = [];
        for (let i = 0; i < memberInfo.roleInfos.length; i++) {
          this.objInfo.bizMemberAddRoles.push(memberInfo.roleInfos[i].roleId + "")
        }
        this.objTitle = '编辑业务人员信息';
        this.dialogVisible_obj = true;
      },

      //删除业务成员信息
      delete_ObjPer_Btn() {
        this.$message({
          message: '功能开发中敬请期待。。。',
          type: 'success'
        })
      },


      //添加业务运维成员信息打开弹窗
      showAddOpsDialog() {
        $http.get($http.api.biz.listSysOpeMembers).then((res) => {
          this.allMemberbos = res.data;
          if (!this.allMemberbos) {
            this.allMemberbos = [];
          }
          this.memberbos = this.allMemberbos.concat([]);
        });
        this.ops_Title = '添加业务运维成员';
        this.dialogVisible_ops = true;
        this.objInfo.bizOpsMemberAddName = []
      },

      //关闭添加业务运维成员信息的弹窗
      closeOpsDialog() {
        this.dialogVisible_ops = false;
      },

      //删除业务运维成员信息
      delBizOpeMember(delUser) {
        let params = {
          userId: delUser.userId,
          bizId: this.objInfo.bizId
        };

        this.$confirm("确定将运维人员"+delUser.userName+"从业务中删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.post($http.api.biz.del_biz_ope_member, params).then((res) => {
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            this.getBizOpsMembers();
          }).catch(() => {
            this.$message({
              message: '删除失败',
              type: 'error'
            });
          });
        }).catch(() => {
        });


      },


      //分页
      handleSizeChange(val) {
        this.bizMemberData.pageSize = val;
        this.getBizMembers();
      },
      //分页
      handleAppSizeChange(val) {
        this.appData.pageSize = val;
        this.getAppList();
      },
      //分页
      handleOpsSizeChange(val) {
        this.bizOpsMemberData.pageSize = val;
        this.getBizOpsMembers();
      },

      handleCurrentChange(val) {
        this.bizMemberData.pageNum = val;
        this.getBizMembers();
      },
      handleOpsCurrentChange(val) {
        this.bizOpsMemberData.pageNum = val;
        this.getBizOpsMembers();
      },
      handleAppCurrentChange(val) {
        this.appData.pageNum = val;
        this.getAppList();
      },


    }
  };
</script>

<style lang="scss" scoped>
  .tab-box {
    min-height: 450px;
    margin-top: 10px;
    margin-right: 10px;
    margin-left: 10px;
    border: 1px solid #e2dbdb;
    .el-button--primary {
      height: 46px;
    }
  }

  .label-name {
    border: none;
    display: inline-block;
    width: 700px;
    margin: 15px 20px 0px 20px;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  .el-form-item__error {
    right: 0;
    top: 14px;
  }
</style>


