<template>
  <div class="x-arD content-box">
    <div class="function-bar">
      <el-breadcrumb separator-class="el-icon-arrow-right" ref="elBreadcrumbDemo">
        <el-breadcrumb-item>
          <el-dropdown size="medium" trigger="click" @command="goToBizPage" placement="bottom-start"
                       @visible-change="bizVisibleChange">
              <span class="el-dropdown-link cursor-pointer">
                {{bizName}}<i class="el-icon-caret-bottom" style="margin-left: 8px"></i>
              </span>
            <el-dropdown-menu slot="dropdown">
              <el-input v-model="filterBizText" size="small" clearable
                        class="search_filter_input"
                        placeholder="输入业务名称过滤"
                        @input="doBizFilter">
              </el-input>
              <div class="search_filter_hint"
                   v-show="!filterBizList || filterBizList.length===0">没有找到相关业务
              </div>
              <div class="select-dropdown-container">
                <el-dropdown-item :command="item.bizId" v-for="(item,key) in filterBizList" :key="key">{{item.bizName}}
                </el-dropdown-item>
              </div>
            </el-dropdown-menu>
          </el-dropdown>
        </el-breadcrumb-item>

        <el-breadcrumb-item v-if="menuApp && menuApp.appCode">
          <el-dropdown size="medium" trigger="click" @command="goToApp" placement="bottom-start" @visible-change="appVisibleChange">
              <span class="el-dropdown-link  cursor-pointer">
                {{menuApp.appCode}}<i class="el-icon-caret-bottom" style="margin-left: 8px"></i>
              </span>
            <el-dropdown-menu slot="dropdown">
              <el-input v-model="filterAppText" size="small"
                        clearable
                        class="search_filter_input"
                        placeholder="输入应用名称过滤"
                        @input="doAppFilter"></el-input>
              <div class="search_filter_hint"
                   v-show="!filterAppList || filterAppList.length===0">没有找到相关应用
              </div>
              <div class="select-dropdown-container">
                <el-dropdown-item :command="item" v-for="(item,key) in filterAppList" :key="key">{{item.appCode}}
                </el-dropdown-item>
              </div>
            </el-dropdown-menu>
          </el-dropdown>
        </el-breadcrumb-item>
        <el-breadcrumb-item v-if="menuName && menuName.length > 0">{{menuName}}</el-breadcrumb-item>
      </el-breadcrumb>
      
      <el-menu
        :class="{'el-menu-demo-float':isElMenuDemoOverflow, 'el-menu-demo':!isElMenuDemoOverflow}"
        ref="elMenuDemo"
        background-color="#fff"
        text-color="#545c64"
        active-text-color="rgb(64, 158, 255)"
        mode="horizontal"
        @select="handleSelect"
        :default-active="defaultActive">
        <el-menu-item :index="menu.name" v-for="(menu,index) in breadcrumbMenuList" :key="index" v-show="menu.show">
          {{menu.text}}
        </el-menu-item>
      </el-menu>
    </div>
    <div class="white-box table-outer-box">
      <router-view></router-view>
    </div>
  </div>
</template>

<script>
  export default {
    name: "biz",
    data() {
      return {
        currentBiz: '',
        userBizList: [],
        filterBizList: [],
        filterBizText: "",

        userAppList: [],
        filterAppList: [],
        filterAppText: "",

        defaultActive: '',
        bizName: '',
        menuName: '',
        menuApp: {},
        left_positi: '',
        breadcrumbMenuList: [
          {text: '特性分支', name: 'featureBranchList', show: false},
          {text: '集成', name: 'featureBranchIntegration', show: false},
          {text: '版本', name: 'appVersions', show: false},
          {text: '流水线', name: 'appPipelineList', show: false},
          {text:'编译任务', name:'AppCompileTaskList', show:false},
          {text: '部署任务', name: 'appDeployTaskList', show: false},
          {text: '日志', name: 'appLog', show: false},
          {text: '发布单', name: 'deployNoteList', show: false},
          {text: '发布流程', name: 'deployNoteFlow', show: false},
          {text: '发布统计', name: 'deployStatistics', show: false},
          {text: '应用设置', name: 'appSettings', show: false},
          {text: '人员设置', name: 'bizMemberSetting', show: false},
          {text: '接口文档', name: 'apiList', show: false},
          {text: '基础设置', name: 'bizInfoSetting', show: false},
          {text: '镜像设置', name: 'bizImageSetting', show: false},
          {text: '实例标签设置', name: 'bizInstanceTagSetting', show: false},
          {text: 'GitLab账号注册', name: 'gitLabRegister', show: false},
        ],
        heightscreen: '',
        isElMenuDemoOverflow: false // 用于配置 el-menu class
      }
    },

    watch: {
      '$route'(to, from) {
        this.renderBreadcrumbMenu()
      }
    },

    async mounted() {
      this.currentBiz = this.$route.query.bizId + "";
      this.userBizList = $utils.getStorage(GLOBAL_CONST.USER_BIZ_LIST);
      this.doBizFilter();
      if (this.userBizList != null && this.userBizList.length !== 0) {
        for (let i = 0; i < this.userBizList.length; i++) {
          let biz = this.userBizList[i];
          if (biz.bizId == this.currentBiz) {
            this.userAppList = biz.appList;
            this.doAppFilter();
            break;
          }
        }
      } else {
        this.userAppList = []
      }
      this.menuApp = {};
      this.renderBreadcrumbMenu();
      this.appCode = this.getUrlAppCode();

      //每次界面刷新，启动同步代码获取
      await $http.get($http.api.biz.getBizInfo).then(res => {
        this.bizName = res.data.bizName;
      }).catch(e => {
      });
    },

    methods: {
      // 设置 el-mu 位置 add by heyunjiang on 2019.5.1
      // update by heyunjiang ，使用 setTimeout 调用，并且加时间延迟，在位置计算上，在它之前有全局左侧菜单位置计算问题
      elMenuPositionSet() {
        if(!this.$refs.elBreadcrumbDemo || !this.$refs.elMenuDemo) {return false;}
        try {
          let right1 = this.$refs.elBreadcrumbDemo.$el.getBoundingClientRect().right; // 左侧 breadcrumb 右侧距离浏览器左边框距离
          let left2 = this.$refs.elMenuDemo.$el.getBoundingClientRect().left; // 中间 el-menu 左侧距离浏览器左边框距离
          // 如果已经在右边，则不变化了
          if(left2 > right1 && left2 - right1 < 51) {
            return false;
          }
          this.isElMenuDemoOverflow = right1 > left2?true:false;
        }catch(_) {_}
      },

      bizVisibleChange(visible) {
        if (!visible) {
          this.filterBizText = "";
          this.doBizFilter();
        }
      },

      doBizFilter() {
        if (!this.filterBizText || this.filterBizText === '') {
          this.filterBizList = this.userBizList.concat([])
        } else {
          this.filterBizList = this.userBizList.filter(item => {
            return item.bizName.indexOf(this.filterBizText) != -1
          })
        }
        setTimeout(this.elMenuPositionSet, 60)
      },

      doAppFilter() {
        if (!this.userAppList) {
          this.filterAppList = [];
          return;
        }
        if (!this.filterAppText || this.filterAppText === '') {
          this.filterAppList = this.userAppList.concat([])
        } else {
          this.filterAppList = this.userAppList.filter(item => {
            return item.appCode.indexOf(this.filterAppText) != -1
          })
        }
        setTimeout(this.elMenuPositionSet, 60)
      },

      appVisibleChange(visible) {
        if (!visible) {
          this.filterAppText = "";
          this.doAppFilter();
        }
      },

      goToBizPage(command) {
        if (window.location.search.match("appId")) {
          window.location.href = "/app/list" + "?bizId=" + command;
        } else {
          let pathname = window.location.pathname;

          //这里处理发布单，防止越权填写发布单，暂时考虑到这里
          if (window.location.pathname.match("/deployNote/manage")) {
            pathname = "/deployNote/list";
          }

          window.location.href = pathname + "?bizId=" + command;
        }
      },

      goToApp(appInfo) {

        let targetHref = window.location.pathname;

        //根据应用开发模式，边界情况需要接入处理defaultActive
        if (appInfo.developMode != undefined) {
          if (appInfo.developMode == 0) {
            if (this.defaultActive == "featureBranchList"
              || this.defaultActive == "featureBranchIntegration"
              || this.defaultActive == "featureBranchDetails") {

              this.defaultActive = "appVersions";
            }
          } else if (appInfo.developMode == 1){
            if(this.defaultActive == "appVersions"
              || this.defaultActive == "featureBranchDetails") {
              this.defaultActive = "featureBranchList";
            }
          }
        }
     
        let targetRouter = $utils.getRouter(this.defaultActive);
        if (targetRouter) {
          targetHref = targetRouter.path;
        }
        targetHref += "?bizId=" + this.currentBiz + "&appId=" + appInfo.appId;

        window.location.href = targetHref;
      },

      // 渲染面包屑 和 顶部菜单
      async renderBreadcrumbMenu() {
        if (this.$route.meta.showSub == false) {
          this.breadcrumbMenuList.forEach((bm) => {
            bm.show = false
          });
          this.menuName = '应用列表';
          this.menuApp = {};
          return;
        }

        let sideBarDefaultActive;
        let topMenu = $utils.getTopMenu(this.$route);
        if (this.$route.meta.parent == topMenu.name) {
          sideBarDefaultActive = this.$route.name
          this.menuApp = {};
        } else {
          sideBarDefaultActive = this.$route.meta.parent
          let appId = this.$route.query.appId;
          if (appId) {
            if (!this.menuApp.appCode) {
              await $http.get($http.api.app.simpleInfo).then(res => {
                this.menuApp = res.data;
                if (this.menuApp.bizId != this.$route.query.bizId) {
                  this.$message({
                    message: '该业务下不存在该应用',
                    type: 'error'
                  });
                  this.$router.push({name: 'bizList'});
                }
                setTimeout(this.elMenuPositionSet, 60)
              }).catch((err) => {
                this.$router.push({name: 'bizList'});
              })
            }
          } else {
            this.menuApp = {};
          }
        }

        let tempSubMenuList = $utils.getSubMenuListByName(sideBarDefaultActive)

        this.breadcrumbMenuList.forEach((bm) => {
          bm.show = false;
          tempSubMenuList.forEach((m) => {
            if (bm.name == m.name) {
              bm.show = true;
            }
            //动态调整应用在"自由分支"，“特性分支”两种开发模式下的菜单子项
            if(sideBarDefaultActive == "appList") {
              if (this.menuApp.developMode != undefined) {
                if (this.menuApp.developMode == 1) {
                  if(bm.name == "appVersions") {
                    bm.show = false;
                  }
                  //切换应用跨开发模式时做好defaultActive调整
                  if (this.defaultActive == "appVersions") {
                    this.defaultActive = "featureBranchList";
                  }
                } else if (this.menuApp.developMode == 0) {
                  if ( bm.name == "featureBranchList" || bm.name == "featureBranchIntegration") {
                    bm.show = false;
                  }
                  if (this.defaultActive == "featureBranchList" 
                    || this.defaultActive == "featureBranchIntegration") {
                    this.defaultActive = "appVersions";
                  }
                }
              } 
            }
          });
        });

        this.$nextTick(function () {
          this.defaultActive = this.$route.name;
          let tempMenu = this.breadcrumbMenuList.find(r => {
            return r.name == this.defaultActive
          });
          if (tempMenu) {
            this.menuName = tempMenu.text
          }
        })
        setTimeout(this.elMenuPositionSet, 60)
      },

      goAppList() {
        this.$router.push({name: 'appList', query: {bizId: this.$route.query.bizId}})
      },
      handleSelect(index) {
        let query = {bizId: this.$route.query.bizId};
        if (this.$route.meta.parent == 'appList') {
          query.appId = this.$route.query.appId
        }
        this.$router.push({name: index, query: query})
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'BizCommon';

  .el-menu--horizontal {
    border-bottom: none !important;
  }

  .el-menu-demo {
    // float: left;
    // margin-left: 50px;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
    width: auto !important;
    height: 40px !important;
    border: none;
    .el-menu-item {
      height: 48px !important;
      border-bottom: 1px !important;
      line-height: 50px;
    }
  }
  // 当左侧 breadcrumb 宽度被中间 el-menu 覆盖住时，需要设置此 class
  .el-menu-demo-float {
    float: left;
    margin-left: 50px;
    .el-menu-item {
      height: 48px !important;
      border-bottom: 1px !important;
      line-height: 50px;
    }
  }

  .el-breadcrumb {
    margin-top: 18px;
    margin-left: 5px;
    float: left;
  }

  .search_filter_input {
    padding-bottom: 4px;
    padding-left: 8px;
    padding-right: 8px;
    box-sizing: border-box;
  }

  .search_filter_hint {
    padding-left: 8px;
    color: gray;
    padding-top: 8px;
  }

  .select-dropdown-container {
    max-height: 400px;
    max-height: 65vh;
    overflow: auto;
  }
</style>
