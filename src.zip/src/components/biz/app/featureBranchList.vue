<template>
  <div id="featureBranchList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
              <div class="btnArea">
                <el-row type="flex">
                  <el-col>
                    <el-button type="success" class="mb10" @click="showCreateDialog()">新建特性分支</el-button>
                    <el-button type="primary" class="mb10" @click="showImportDialog()">导入已有分支</el-button>
                    <el-button type="primary" class="mb10" @click="showApplicationAssociation(bizId, appId)">关联应用</el-button>
                  </el-col>
                  <el-col>
                    <el-row  type="flex" justify="end">
                      <el-button type="primary" class="mb10" @click="renderTable()">刷新</el-button>
                    </el-row>
                  </el-col>
                </el-row>
              </div>

              <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                <div class="table-box-top-bs">
                  <el-table :data="featureBranchListData.list" style="width:100%;height:100%;overflow:auto;">

                    <el-table-column label="变更ID" min-width="50">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="goToFeatureBranchDetail(scope.row)">
                              {{scope.row.changeId}}
                          </span>
                        </template>
                    </el-table-column>

                    <el-table-column label="变更原因" min-width="120">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="goToFeatureBranchDetail(scope.row)">
                            {{scope.row.changeReason}}
                        </span>
                      </template>
                    </el-table-column>

                    <el-table-column label="分支" min-width="150">
                      <template slot-scope="scope">
                        <el-tooltip  v-if="scope.row.gitBranchDeleted" class="item" effect="dark" content="Git分支已被删除" placement="top-start">
                          <span class="c-red">{{scope.row.sourceRepo}}/{{scope.row.originalBranch}}</span>
                        </el-tooltip>
                        <span v-else>{{scope.row.sourceRepo}}/{{scope.row.originalBranch}}</span>
                      </template>
                    </el-table-column>

                    <!-- 不同的状态放置不同的条状路由，能够快速定位到流水线页面 -->
                    <el-table-column prop="statusName" label="状态" min-width="50">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="goToStatusCorrespondingPage(scope.row)">
                          {{scope.row.statusName}}
                        </span>
                      </template>
                    </el-table-column>

                    <el-table-column prop="autoDelete" label="合并主干后自动删除" min-width="70">
                      <template slot-scope="scope">
                        <span>
                            {{scope.row.autoDelete ? "是" : "否"}}
                        </span>
                      </template>

                    </el-table-column>

                    <el-table-column prop="createUser" label="创建者" min-width="80">
                      <template slot-scope="scope">
                        {{getCreateUser(scope.row)}}
                      </template>
                    </el-table-column>

                    <el-table-column prop="createTime" label="创建时间" width="150">
                    </el-table-column>

                    <el-table-column prop="planReleaseTime" label="计划发布时间" width="98">
                      <template slot-scope="scope">
                        <span>
                            {{ !scope.row.planReleaseTime ? "--" : scope.row.planReleaseTime.substring(0, 10)}}
                        </span>
                      </template>
                    </el-table-column>

                    <!-- todo 其他操作待定 -->
                    <el-table-column prop="time" label="操作"width="100">
                      <template slot-scope="scope">
                        <span class="c-blue cp" v-if="scope.row.status==FEATURE_BRANCH_STATUS.DEVELOPING"
                          @click="submitIntegration(scope.row.changeId)">提交集成</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="table_b_f_b">
                  <el-pagination
                    class="fr"
                    style="margin-top: 9px;"
                    @size-change="handleFeatureBranchListSizeChange"
                    @current-change="handleFeatureBranchListPageChange"
                    :current-page="featureBranchListData.pageNum"
                    :page-sizes="[10, 20, 30]"
                    :page-size="featureBranchListData.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="featureBranchListData.total">
                  </el-pagination>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>


    <!--新建特性分支弹框-->
    <el-dialog title='新建特性分支' :visible.sync="showCreateFeatureBranchDialog" class="issuedialog el-dialog-640w" :before-close="closeCreateDialog" :close-on-click-modal="false">
      <div class="form-iterm-box">
        <el-form ref="createFeatureBranchDialogForm" :model="createFeatureBranchInfo">
          <el-form-item label="变更原因" label-width="120px" prop="changeReason" :rules="[{required: true, message: '请填写变更原因', trigger: 'blur'}]">
            <el-input  v-model.trim="createFeatureBranchInfo.changeReason"></el-input>
          </el-form-item>

          <el-form-item label="计划发布时间" label-width="120px" prop="planReleaseTime" :rules="[{required: true, message: '请选择计划发布时间', trigger: 'blur'}]">
            <el-date-picker
                  type="date"
                  v-model="createFeatureBranchInfo.planReleaseTime"
                  value-format="yyyy-MM-dd 00:00:00"
                  class="datepicker"
                  :picker-options="pickerOptions"
                  :editable="false"
                  prefix-icon="not-exist-el-icon-date"
                  placeholder="请选择计划发布时间"
                  >
                </el-date-picker>
          </el-form-item>

          <el-form-item label="分支名称" label-width="120px" prop="nameMode"  :rules="[{required: true, message: '请选择分支名称类型' , trigger: 'blur'}]">
            <el-radio-group v-model="createFeatureBranchInfo.nameMode" @change="handleCreateFeatureBranchNameModeChange">
              <el-radio label="0">规范名称</el-radio>
              <el-radio label="1">自定义名称</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item prop="nameSuffix"
            v-if="createFeatureBranchInfo.nameMode=='0'"
            :rules="[{required: true, message: '请继续补充特性分支名称', trigger: 'blur'}]" class="ml40">
            <el-select  v-model="createFeatureBranchInfo.namePrefix" class="name-prefix">
              <el-option value="feature" label="feature"></el-option>
              <el-option value="hotfix" label="hotfix"></el-option>
            </el-select>

            / <span>{{this.formatDate(new Date(), "yyyyMMdd")}}</span>_变更ID_
            <el-input v-model.trim="createFeatureBranchInfo.nameSuffix" class="name-suffix" ></el-input>
          </el-form-item>

          <el-form-item prop="selfdefineBranchName"
            class="ml40"
            v-if="createFeatureBranchInfo.nameMode=='1'"
            :rules="[{required: true, message: '请填写自定义分支名称' ,trigger: 'blur'}]">
            <el-input v-model.trim="createFeatureBranchInfo.selfdefineBranchName"
              placeholder="请填写自定义分支名称"></el-input>
          </el-form-item>

          <el-form-item label="初始化流水线" label-width="120px" prop="pipelineInitMode"  :rules="[{required: true, message: '请选择初始化流水线' , trigger: 'blur'}]">
            <el-radio-group v-model="createFeatureBranchInfo.pipelineInitMode" @change="handlePipelineInitModeChange">
              <el-tooltip placement="top">
                <div slot="content">只包含构建，部署阶段的简单流水线</div>
                <el-radio label="0">默认流水线</el-radio>
              </el-tooltip>
              <el-radio label="1">复制已存在的流水线</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item
            class="ml40"
            prop="copyPipelineId"
            v-if="createFeatureBranchInfo.pipelineInitMode==1"
            :rules="[{required: true, message: '请选择复制的流水线' ,trigger: 'blur'}]">
            <el-select v-model="createFeatureBranchInfo.copyPipelineId" placeholder="请选择" style="width:100%">
              <el-option v-for="item in copyPipelineList" :key="item.id" :label="item.name"
                         :value="item.id">
                <span style="float: left">{{item.name}}</span>
              </el-option>
            </el-select>
          </el-form-item>


          <el-form-item prop="autoDelete" class="ml40">
            <el-checkbox v-model="createFeatureBranchInfo.autoDelete">合并主干后自动删除分支 &nbsp;<i class="header-icon el-icon-question" title="集成环境生成的Release分支合并主干后，该分支将会自动删除"></i></el-checkbox>
          </el-form-item>

        </el-form>
      </div>

      <span slot="footer" class="dialog-footer">
        <el-button @click="closeCreateDialog">取消</el-button>
        <el-button type="primary" @click="createFeatureBranch()" :disabled="btnCreateConfirmDisabled">确定</el-button>
      </span>
    </el-dialog>

    <!--导入分支-->
    <el-dialog title='导入已有分支' :visible.sync="showImportFeatureBranchDialog" class="issuedialog el-dialog-640w" :before-close="closeImportDialog" :close-on-click-modal="false">

        <div class="form-iterm-box">
          <div>
            <span
              style="margin-block-start: 0.33em; margin-block-end: 0.33em;margin-bottom:10px; font-weight: bold;">
              分支列表&nbsp;&nbsp;&nbsp;
            </span>

            <el-input
              @keyup.native="searchBranch(branchSearchKey)"
              @blur="searchBranch(branchSearchKey)"
              v-model="branchSearchKey"
              style="width:180px;margin-bottom:8px;"
              placeholder="请输入分支名称搜索">
            </el-input>

            <el-table
              ref="branchesTableRef"
              :data="filteredBranchTableList"
              style="width: 100%"
              @select-all="selectAllEvent"
              @select="handleSelectionChange"
              v-loading="branchTableloading"
              element-loading-text="加载中">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
               prop="name"
               label="分支名称"
               min-width="200">
                <template slot-scope="scope">
                  {{ scope.row.name }}
                  <el-popover
                    v-if="scope.row.alreadyImported"
                    placement="top"
                    :title="scope.row.name + ' 已存在的应用列表'"
                    width="550"
                    trigger="hover"
                    :open-delay="200">
                    <el-table :data="scope.row.importedBranchApplicationBos" v-if="scope.row.alreadyImported">
                      <el-table-column property="application.appCode" label="应用ID" width="210"></el-table-column>
                      <el-table-column property="application.appName" label="应用名称" width="210"></el-table-column>
                      <el-table-column property="statusName" label="分支状态"></el-table-column>
                    </el-table>
                    <i slot="reference" class="el-icon-warning" v-if="scope.row.alreadyImported"></i>
                  </el-popover>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="table_b_f_b" v-show="originalBranchTableList.length != 0">
            <el-row type="flex" justify="end">
              <el-pagination
                @current-change="handleBranchCurrentChange"
                :current-page="branchPaginationData.pageNum"
                :page-sizes="[5, 10, 20]"
                :page-size="branchPaginationData.pageSize"
                layout="total, prev, pager, next"
                :total="branchPaginationData.total"
                :pages="branchPaginationData.pages">
              </el-pagination>
            </el-row>
          </div>

          <el-form ref="importFeatureBranchDialogForm" :model="createFeatureBranchInfo">
            <el-form-item v-if="selectedBranches.length <= 1"
              label="变更原因"
              label-width="120px"
              prop="changeReason"
              :rules="[{required: true, message: '请填写变更原因', trigger: 'blur'}]">
              <el-input  v-model.trim="createFeatureBranchInfo.changeReason"></el-input>
            </el-form-item>

            <el-form-item label="计划发布时间" label-width="120px" prop="planReleaseTime" :rules="[{required: true, message: '请选择计划发布时间', trigger: 'blur'}]">
              <el-date-picker
                    v-model="createFeatureBranchInfo.planReleaseTime"
                    type="date"
                    value-format="yyyy-MM-dd 00:00:00"
                    class="datepicker"
                    :picker-options="pickerOptions"
                    :editable="false"
                    prefix-icon="not-exist-el-icon-date"
                    placeholder="请选择计划发布时间"
                    >
                  </el-date-picker>
            </el-form-item>

            <el-form-item label="分支名称" label-width="120px" prop="nameMode"  :rules="[{required: true, message: '请选择分支名称类型' , trigger: 'blur'}]">
              <el-radio-group v-model="importModeNameMode">
                <el-radio label="0" v-show="selectedBranches.length <= 1">规范名称</el-radio>
                <el-radio label="1">原分支名称</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item prop="nameSuffix"
              class="ml40"
              v-if="createFeatureBranchInfo.nameMode=='0' && selectedBranches.length <= 1"
              :rules="[{required: true, message: '请继续补充特性分支名称', trigger: 'blur'}]" >
              <el-select  v-model="createFeatureBranchInfo.namePrefix" class="name-prefix">
                <el-option value="feature" label="feature"></el-option>
                <el-option value="hotfix" label="hotfix"></el-option>
              </el-select>

              / <span>{{this.formatDate(new Date(), "yyyyMMdd")}}</span>_变更ID_
              <el-input v-model.trim="createFeatureBranchInfo.nameSuffix" class="name-suffix"></el-input>
            </el-form-item>

            <el-form-item label="初始化流水线" label-width="120px" prop="pipelineInitMode"  :rules="[{required: true, message: '请选择初始化流水线' , trigger: 'blur'}]">
              <el-radio-group v-model="createFeatureBranchInfo.pipelineInitMode" @change="handlePipelineInitModeChange">
                <el-tooltip placement="top">
                  <div slot="content">只包含构建，部署阶段的简单流水线</div>
                  <el-radio label="0">默认流水线</el-radio>
                </el-tooltip>
                <el-radio label="1">复制已存在的流水线</el-radio>
              </el-radio-group>
            </el-form-item>

            <el-form-item
              class="ml40"
              prop="copyPipelineId"
              v-if="createFeatureBranchInfo.pipelineInitMode==1"
              :rules="[{required: true, message: '请选择复制的流水线' ,trigger: 'blur'}]">
              <el-select v-model="createFeatureBranchInfo.copyPipelineId" placeholder="请选择" style="width:100%">
                <el-option v-for="item in copyPipelineList" :key="item.id" :label="item.name"
                           :value="item.id">
                  <span style="float: left">{{item.name}}</span>
                </el-option>
              </el-select>
            </el-form-item>

            <el-form-item prop="autoDelete" class="ml40">
              <el-checkbox v-model="createFeatureBranchInfo.autoDelete">合并主干后自动删除分支 &nbsp;<i class="header-icon el-icon-question" title="集成环境生成的Release分支合并主干后，该分支将会自动删除"></i></el-checkbox>
            </el-form-item>

          </el-form>
        </div>

        <span slot="footer" class="dialog-footer">
          <el-button @click="closeImportDialog">取消</el-button>
          <el-button type="primary" @click="importFeatureBranch()" :disabled="btnImportConfirmDisabled">确定</el-button>
        </span>
      </el-dialog>

    <!--关联应用-->
    <application-association :dialogVisible_correlation="dialogVisible_correlation" :handleClose_correlation="handleClose_correlation"
                             :modaltobody="false" :shadeBtn="false" ref="applicationAssociationRef"></application-association>


  </div>



</template>

<script>
  import AppVersionPipeline from '@/components/biz/app/appVersionPipeline'
  import ApplicationAssociation from '@/components/commonComponents/ApplicationAssociation'

  export default {
    name: "featureBranchList",
    components: {
      AppVersionPipeline,
      ApplicationAssociation
    },
    data() {

      return {
        pickerOptions:{
          disabledDate(time) {
            return time.getTime() < Date.now() - 8.64e7;
          }
        },

        table_loading: false,

        featureBranchListData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        bizId: '',
        appId: '',
        appSimpleInfo: null,

        showCreateFeatureBranchDialog: false,

        branchTableloading: false,
        showImportFeatureBranchDialog: false,

        //直接从后端拿到的全量分支列表
        originalBranchTableList: [],

        //前端假分页，假搜索后的分支列表信息（视野内当前那一页的数据）
        filteredBranchTableList: [],

        //筛选过滤后的全部分支列表信息（不一定是视野内的）
        filteredBranchTableAllList:[],

        selectedBranches:[],

        branchSearchKey: "",
        //后端接口不是返回PageInfo结果，这个结构只是前端通过假分页维护的
        branchPaginationData: {
          pageNum: 1,
          pageSize: 5,
          total: 0,
          pages: 0
        },
        multipleSelection: [],

        btnCreateConfirmDisabled: false,
        btnImportConfirmDisabled: false,

        createFeatureBranchInfo: {
          changeReason: '',
          planReleaseTime: '',
          featureBranch: '',
          originalBranch: '',
          autoDelete: false,
          createMode: 0,  //创建方式 0 新建，1 导入
          nameMode: '0',     //分支命名模式 0 规范命名， 1 自定义命名
          namePrefix: "feature",
          nameSuffix: "",
          selfdefineBranchName: "",
          pipelineInitMode: "0",  //流水线初始化方式0使用默认流水线，1复制自某条流水线
          copyPipelineId: '',       //pipelineInitMode为1时，选中的pipelineId
        },

        FEATURE_BRANCH_STATUS: GLOBAL_CONST.FEATURE_BRANCH_STATUS,

        copyPipelineList:[],
        copyPipelineListInited: false,

        dialogVisible_correlation: false,
      };
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this.appId = this.getUrlAppId();
      this.renderTable();
      this.getAppSimpleInfo();
    },

    computed: {
      importModeNameMode: {
        get: function() {
          if(this.selectedBranches.length > 1) {
            this.createFeatureBranchInfo.nameMode = '1';
            return this.createFeatureBranchInfo.nameMode;
          }
          return this.createFeatureBranchInfo.nameMode;
        },
        set: function(newValue) {
          this.createFeatureBranchInfo.nameMode = newValue;
        }
      }
    },

    methods: {

      showCreateDialog() {
        this.showCreateFeatureBranchDialog = true;
      },

      closeCreateDialog() {
        this.showCreateFeatureBranchDialog = false;
        this.createFeatureBranchInfo.nameMode = '0';
        this.$refs["createFeatureBranchDialogForm"].resetFields();
      },

      handleCreateFeatureBranchNameModeChange(val) {
        if(val == "0") {
          this.$refs['createFeatureBranchDialogForm'].clearValidate();
        }
      },

      showImportDialog() {
        this.branchTableloading = true;
        $http.get($http.api.feature_branch.canImportBranches,{appId: this.appId}).then((res) => {
          if(res.status == 200) {
            this.originalBranchTableList = res.data;
            this.handleBranchSizeChange(this.branchPaginationData.pageSize);
          }
          this.branchTableloading = false;
        })

        this.showImportFeatureBranchDialog = true;
      },

      selectAllEvent(data) {
        if (data.length == 0) {
          this.selectedBranches = [];
        } else {
          this.selectedBranches = [];
          Array.prototype.push.apply(this.selectedBranches, this.filteredBranchTableAllList);
        }

        this.$nextTick(() => {
          this.filteredBranchTableList.forEach((item, index) => {
            let predicateResult = this.selectedBranches.indexOf(item) != -1;
            let branchTable = this.$refs.branchesTableRef;
            branchTable && branchTable.toggleRowSelection(item, predicateResult);
          })
        });
      },

      //表格勾选
      handleSelectionChange(val) {

        let dataList = this.filteredBranchTableList;
        dataList.forEach(item => {
          let index = this.selectedBranches.indexOf(item);
          if (index != -1) {
            this.selectedBranches.splice(index, 1)
          }
        });

        val.forEach(item => {
          this.selectedBranches.push(item);
        });

        this.$nextTick(() => {
          this.filteredBranchTableList.forEach((item, index) => {
            let branchesTable = this.$refs.branchesTableRef;
            branchesTable && branchesTable.toggleRowSelection(item, this.selectedBranches.indexOf(item) != -1);
          })
        });
      },

      closeImportDialog() {
        this.showImportFeatureBranchDialog = false;

        this.createFeatureBranchInfo.nameMode = '0';
        this.selectedBranches = [];

        this.branchPaginationData.pageNum = 1;

        this.$refs["importFeatureBranchDialogForm"].resetFields();
      },

      searchBranch(keyWord) {
        this.branchPaginationData.pageNum = 1;
        this.fakePage(this.branchPaginationData.pageNum, this.branchPaginationData.pageSize, keyWord);
      },

      fakePage(num, size, keyWord) {
        let allList = this.originalBranchTableList;
        let tempList = [];
        let returnList = [];
        if (allList && allList.length != 0) {
          if (keyWord && keyWord.trim() != '') {
            allList.forEach(item => {
              if (item.name.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                tempList.push(item);
              }
            })
          } else {
            tempList = allList;
          }
          this.filteredBranchTableAllList = tempList;

          let start = size * (num - 1);
          let end = size * num;
          if (start < 0) {
            start = 0;
          }
          if (start > tempList.length) {
            start = tempList.length - 1;
          }
          if (end > tempList.length) {
            end = tempList.length;
          }
          for (let i = start; i < end; i++) {
            returnList.push(tempList[i]);
          }
          this.filteredBranchTableList = returnList;
        }
        this.branchPaginationData.total = tempList.length;
        this.branchPaginationData.pages = Math.ceil(tempList.length / this.branchPaginationData.pageSize);

        //处理过滤后的选中
        this.$nextTick(() => {
          let filteredBranchTableList = this.filteredBranchTableList;
          filteredBranchTableList.forEach((item, index) => {
            let branchesTable = this.$refs.branchesTableRef;
            branchesTable && branchesTable.toggleRowSelection(item, this.selectedBranches.indexOf(item) != -1);
          })
        });
      },

      //并没有切换size的下拉框，这个只是前端假分页第一次加载数据的时候被调用
      handleBranchSizeChange(val) {
        this.branchPaginationData.pageSize = val;
        this.fakePage(this.branchPaginationData.pageNum, val, this.branchSearchKey);
      },

      handleBranchCurrentChange(val) {
        this.branchPaginationData.pageNum = val;
        this.fakePage(val, this.branchPaginationData.pageSize, this.branchSearchKey);
      },

      createFeatureBranch() {
        this.$refs["createFeatureBranchDialogForm"].validate(validate => {
          if (validate) {
            this.btnCreateConfirmDisabled = true;
            let params = this.generateCreateParams(0);
            $http.post($http.api.feature_branch.create, params).then(res => {
              if(res.status == 200) {
                this.$message({
                  message: "创建特性分支成功",
                  type: "success"
                });

                this.renderTable();
                this.closeCreateDialog();
              }
              this.btnCreateConfirmDisabled =  false;
            }).catch((error) => {
              this.btnCreateConfirmDisabled = false;
            });
          }
        });
      },

      importFeatureBranch() {
        this.$refs["importFeatureBranchDialogForm"].validate(validate => {
          if (validate) {
            if(this.selectedBranches.length == 0) {
              this.$message.error("请选择需要导入的分支");
              return;
            }
            this.btnImportConfirmDisabled = true;
            let params = this.generateCreateParams(1);
            $http.post($http.api.feature_branch.create, params).then(res => {
              if(res.status == 200) {
                this.$message({
                  message: "创建特性分支成功",
                  type: "success"
                });

                this.renderTable();
                this.closeImportDialog();
              }
              this.btnImportConfirmDisabled =  false;
            }).catch((error) => {
              this.btnImportConfirmDisabled = false;
            });
          }
        });
      },

      generateCreateParams(createMode) {

        let params = {};
        params.changeReason = this.createFeatureBranchInfo.changeReason;
        params.planReleaseTime = this.createFeatureBranchInfo.planReleaseTime;
        params.autoDelete = this.createFeatureBranchInfo.autoDelete;
        params.createMode = createMode;
        params.nameMode = this.createFeatureBranchInfo.nameMode;

        //导入模式下
        if(createMode == 1) {
          params.nameMode = this.importModeNameMode;
        }

        params.appId = this.appId;
        params.pipelineInitMode = this.createFeatureBranchInfo.pipelineInitMode;
        params.copyPipelineId = this.createFeatureBranchInfo.copyPipelineId;

        params.featureBranchNamePairList = [];

        if(createMode == 0) {

          let featureBranchNamePair = {};
          //新建
          //采用规范命名，则特性分支名称，跟git仓库名称一致
          if (this.createFeatureBranchInfo.nameMode == '0') {
            featureBranchNamePair.featureBranch = this.createFeatureBranchInfo.namePrefix
              + "/" + this.formatDate(new Date(), "yyyyMMdd") + "_{CHANGE_ID}_"
              + this.createFeatureBranchInfo.nameSuffix;
            featureBranchNamePair.originalBranch = this.createFeatureBranchInfo.featureBranch;
          } else {
            featureBranchNamePair.featureBranch = this.createFeatureBranchInfo.selfdefineBranchName;
            featureBranchNamePair.originalBranch = this.createFeatureBranchInfo.selfdefineBranchName;
          }

          params.featureBranchNamePairList.push(featureBranchNamePair);

        } else {
          this.selectedBranches.forEach((item, index, arr) => {
            let featureBranchNamePair = {};
            //导入
            if(this.createFeatureBranchInfo.nameMode == '0') {
              featureBranchNamePair.featureBranch = this.createFeatureBranchInfo.namePrefix
                + "/" + this.formatDate(new Date(), "yyyyMMdd") + "_{CHANGE_ID}_"
                + this.createFeatureBranchInfo.nameSuffix;
              featureBranchNamePair.originalBranch = item.name;
            } else {
              //采用原有的仓库分支
              featureBranchNamePair.featureBranch = item.name;
              featureBranchNamePair.originalBranch = item.name;
            }
            params.featureBranchNamePairList.push(featureBranchNamePair);
          });

          if(this.selectedBranches.length > 1) {
            params.changeReason = "批量导入已有分支";
          }
        }
        return params;
      },

      getCreateUser(row) {
        if (row && (row.createUser || row.createUserName)) {
          return row.createUserName + '(' + row.createUser + ')';
        }
        return "";
      },

      handleFeatureBranchListSizeChange(newPageSize) {
        this.featureBranchListData.pageSize = newPageSize;
        this.renderTable();
      },

      handleFeatureBranchListPageChange(newPageNum) {
        this.featureBranchListData.pageNum = newPageNum;
        this.renderTable();
      },

      renderTable() {
        this.table_loading = true;
        let params = {
          appId: this.appId,
          pageNum: this.featureBranchListData.pageNum,
          pageSize: this.featureBranchListData.pageSize,
        };

        $http.get($http.api.feature_branch.list, params).then(response => {
          this.featureBranchListData = response.data;
          this.table_loading = false;
        });
      },

      getAppSimpleInfo() {
        $http.get($http.api.app.simpleInfo).then(res => {
          if(res.status == 200){
            this.appSimpleInfo = res.data;
          }
        }).catch((err) => {
          console.log(err);
        })
      },


      goToFeatureBranchDetail(row) {
        this.goToPage(this, 'featureBranchDetails',  {bizId : this.bizId, appId : this.appId, featureBranchId : row.changeId});
      },

      goToStatusCorrespondingPage(row) {
        let curStatus = row.status;
        switch(curStatus) {
          case this.FEATURE_BRANCH_STATUS.DEVELOPING:
            this.goToFeatureBranchDetail(row);
            break;
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_DEV_WAITING:
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_DEV_HANDLING:
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_DEV_EXCEPTION:
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_DEV_SUCCESS:
            this.goToPage(this, "featureBranchIntegration", {bizId: this.bizId, appId: this.appId, activeTab: "integrated_dev"});
            break;
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_TEST_WAITING:
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_TEST_HANDLING:
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_TEST_EXCEPTION:
          case this.FEATURE_BRANCH_STATUS.INTEGRATED_TEST_SUCCESS:
            this.goToPage(this, "featureBranchIntegration", {bizId: this.bizId, appId: this.appId, activeTab: "integrated_test"});
            break;
          default:
            //do nothing
            break;
        }
      },

      submitIntegration(changeId) {
        let directToIntegratedTest = false;
        if(this.appSimpleInfo.appIntegratedSettings.integratedDevEnabled != null && this.appSimpleInfo.appIntegratedSettings.integratedDevEnabled == false) {
          directToIntegratedTest = true;
        }

        let formData = new FormData();
        formData.set('id', changeId);
        formData.set('sourceStatus', this.FEATURE_BRANCH_STATUS.DEVELOPING);

        let targetStatus = directToIntegratedTest ? this.FEATURE_BRANCH_STATUS.INTEGRATED_TEST_WAITING
          : this.FEATURE_BRANCH_STATUS.INTEGRATED_DEV_WAITING;
        formData.set('targetStatus', targetStatus);

        $http.post($http.api.feature_branch.status, formData).then(response => {
          if (response.status == 200) {
            this.$message({
              message: "提交集成成功",
              type: "success"
            });
            let activeTab = directToIntegratedTest ? "integrated_test" : "integrated_dev";
            this.goToPage(this, 'featureBranchIntegration', { bizId: this.bizId, appId: this.appId, activeTab: activeTab });
          }
        }).catch((e) => {
          //do nothing
        });
      },


      //删除特性分支，需要二次提示是否同步删除代码仓库对应分支
      deleteFeature(row) {
        this.$confirm(`确定要删除特性分支？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let formData = new FormData();
          formData.set('id', row.id);
        }).catch(() => {
        });
      },

      handlePipelineInitModeChange(radioValue) {
        //模式是复制已经存在某条流水线
        if(radioValue == 1 && !this.copyPipelineListInited) {
          this.initCopyPipelineList();
        }
      },

      initCopyPipelineList() {
        $http.get($http.api.pipeline.copyList, {appId: this.appId}).then(response => {
          if(response.status == 200) {
            this.copyPipelineList = response.data;
            this.copyPipelineListInited = true;
          }
        });
      },

      showApplicationAssociation(bizId, appId) {
        this.dialogVisible_correlation = true;
        if(this.$refs.applicationAssociationRef) {
          this.$refs.applicationAssociationRef.init(bizId, appId)
        }
      },

      handleClose_correlation() {
        this.dialogVisible_correlation = false;
      },

    },

  };
</script>

<style lang="scss" scoped>
  .name-prefix {
    width: 120px;
  }

  .name-suffix {
    width: 290px;
  }

  .datepicker {
    width: 470px;
  }

  .table_b_f_b {
    margin-top: 0px;
  }

</style>
