<template>
  <div class="table-box" style="border:none;">
    <el-form>
      <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
        <el-form :model="uploadConfig" ref="uploadConfig" label-width="150px">
          <p style="font-size: 16px;margin-left: 10px"><b>开发版本</b></p>
          <el-col :span='24'>
            <el-form-item class='mb10'  label="最大保存个数" prop="maxNumDev" :rules="rule">
              <el-input placeholder="请输入最大保存个数[20,100]" v-model.number="uploadConfig.maxNumDev"
                        class="width-input-select"></el-input>
            </el-form-item>
          </el-col>

          <p style="font-size: 16px;margin-left: 10px;margin-top: 50px"><b>测试版本</b></p>
          <el-col :span='24'>
            <el-form-item class='mb10' label="最大保存个数"  prop="maxNumTest" :rules="rule">
              <el-input placeholder="请输入最大保存个数[20,100]" v-model.number="uploadConfig.maxNumTest"
                        class="width-input-select"></el-input>
            </el-form-item>
          </el-col>

          <p style="font-size: 16px;margin-left: 10px;"><b>正式版本</b></p>
          <el-col :span='24'>
            <el-form-item class='mb10' label="最大保存个数"  prop="maxNumOnline" :rules="rule">
              <el-input placeholder="请输入最大保存个数[20,100]" v-model.number="uploadConfig.maxNumOnline"
                        class="width-input-select"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span='24'>
            <el-form-item class='mb10' label="触发上传至正式环境"  prop="upload2onlineMoment">
              <el-radio-group v-model="uploadConfig.upload2onlineMoment" class="width-input-select">
                <el-radio :label="0">初次上传时</el-radio>
                <el-radio :label="1">发布时</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-col>
        </el-form>
        <el-col :span='24' style="width: 660px">
          <el-button type="primary" style="float: right" @click="saveAppMaxUploadConfig()" size="medium">保存</el-button>
        </el-col>
      </el-row>
    </el-form>
  </div>

</template>

<script>
  export default {
    name: "maxPkgUploadManage",
    data() {
      let validateNum = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('最大保存数不能为空'));
        }

        if (!Number.isInteger(value)) {
          callback(new Error('请输入数字值'));
        } else {
          if (value < 20 || value > 100) {
            callback(new Error('最大保存数取值范围为[20,100]'));
          } else {
            callback();
          }
        }
        
      };

      return {
        dataInit: false,
        rule: [
          {required: true, message: '不能为空', trigger: 'blur'},
          {validator: validateNum, trigger: 'blur'}],
        uploadConfig: {}
      };
    },
    mounted() {
    },
    methods: {
      getAppMaxUploadConfig() {
        $http.get($http.api.app.appMaxUploadConfig, {appId: this.getUrlAppId()}).then(res => {
          if (res.status === 200) {
            this.uploadConfig = res.data;
            this.dataInit = true;
          }
        });
      },
      saveAppMaxUploadConfig() {
        this.$refs['uploadConfig'].validate(pass => {
          if(pass) {
            if (!this.dataInit) {
              this.$message({
                message: "获取数据失败，请重新刷新界面",
                type: "success"
              });
              return;
            }
            $http.post($http.api.app.appMaxUploadConfig, this.uploadConfig).then(res => {
              if (res.status === 200) {
                this.$message({
                  message: "保存成功",
                  type: "success"
                });
              }
            });
          }
        });
      },
    }
  }
</script>
