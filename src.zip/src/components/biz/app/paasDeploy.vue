<template>
  <el-dialog title='部署'
             class="el-dialog-1300w"
             :visible.sync="deployDialogVisible"
             :before-close="handleCloseDeploy"
             :modal-append-to-body="false"
             :close-on-click-modal='shadeBtn'>
    <div class="form-iframe-box">
      <div style="height: 100%;overflow:auto;overflow-x:hidden;">
        <iframe :src="deploySrc" width="100%" :style="'height: '+getHeight()" frameborder="no" border="0"></iframe>
      </div>
    </div>
  </el-dialog>
</template>


<script>
  export default {
    name: 'paasDeploy',
    data() {
      return {
        deploySrc: '',
        deployDialogVisible: false,
        shadeBtn: '',
      }
    },
    methods: {
      getHeight() {
        return (window.innerHeight - 160) + 'px';
      },
      handleCloseDeploy() {
        this.deployDialogVisible = false;
      },

      //获取Url
      setDeployUrl(versionId, env) {
        this.deployDialogVisible = true;

        let formData = new FormData();
        formData.append("versionId", versionId);
        formData.append("env", env);
        formData.append("appId", this.getUrlAppId());
        $http.post($http.api.deploy_note.getPaaSLink, formData).then((res) => {
          if (res != undefined) {
            this.deploySrc = encodeURI(res.data);
          }
        });
      },
    }
  }
</script>

<style lang="scss" scoped>
  .el-dialog-iframe .el-dialog {
    min-width: 1400px;
  }

  .form-iframe-box {
    overflow: hidden;
    height: 100%;
    box-sizing: border-box;
  }
</style>
