<template>
  <div id="appCompileHistoryList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
            <div class="navArea mb10" style="display: inline-block">
              <span style="font-size: 16px;font-weight: 600;">历史执行记录</span>
              <span class="c-blue cp" @click="goToCompileTaskList()">&lt;&lt;返回</span>
            </div>

            <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">

              <!-- todo 这里要增加一个返回的导航 -->
              <div class="table-box-top-bs">
                <el-table :data="compileHistoryListData.list" style="width:100%;height:100%;overflow:auto;">
                  <el-table-column prop="taskName" label="任务名称" min-width="120">
                  </el-table-column>

                  <el-table-column prop="compileStepRunningInfoBoList" label="运行状态" min-width="120">
                    <template slot-scope="scope">
                      <span class="cp" v-for="(item,index) in scope.row.compileStepRunningInfoBoList" :key="item.id"
                            @click="showCompileDetail(scope.row)">
                        <i class="iconfont" :class="getClassByRunningStatus(item.stepRunningStatus)"
                           :title="item.name"></i>
                        <i class="iconfont icon-more"
                           v-if="scope.row.compileStepRunningInfoBoList.length-1 != index"></i>
                      </span>
                    </template>
                  </el-table-column>

                  <el-table-column label="操作人" min-width="120">
                    <template slot-scope="scope">
                      {{getTrigger(scope.row)}}
                    </template>
                  </el-table-column>

                  <el-table-column label="触发机制" min-width="120">
                    <template slot-scope="scope">
                      {{getTriggerMode(scope.row)}}
                    </template>
                  </el-table-column>

                  <el-table-column label="分支名称" min-width="120">
                    <template slot-scope="scope">
                      {{getBranchName(scope.row)}}
                      <span class="c-blue cp" @click="examineBtn(scope.row.extendData)" v-if="getBranchName(scope.row) == '' || getBranchName(scope.row) == null">查看</span>
                    </template>
                  </el-table-column>

                  <el-table-column label="开始时间" prop="startTime" min-width="120">
                  </el-table-column>

                  <el-table-column label="结束时间" min-width="120">
                    <template slot-scope="scope">
                      {{getTaskEndTime(scope.row)}}
                    </template>
                  </el-table-column>
                </el-table>
              </div>

              <div class="table_b_f_b">
                <el-pagination class="fr" style="margin-top: 9px;" @size-change="handleCompileHistoryListSizeChange"
                               @current-change="handleCompileHistoryListPageChange"
                               :current-page="compileHistoryListData.pageNum"
                               :page-sizes="[10, 20, 30]" :page-size="compileHistoryListData.pageSize"
                               layout="total, sizes, prev, pager, next, jumper" :total="compileHistoryListData.total">
                </el-pagination>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <app-version-pipeline ref="appVersionPipeline"></app-version-pipeline>
    <!-- 查看分支名称 -->
    <el-dialog title='查看分支' :visible.sync="dialogVisible" class="el-dialog-880w"
               :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-table
          :data="examinelist">
          <el-table-column prop="subAppId" label="子应用ID" min-width="160"></el-table-column>
          <el-table-column prop="gitRepoUrl" label="源码仓库" min-width="220"></el-table-column>
          <el-table-column prop="branch" label="分支名称" min-width="160"></el-table-column>
          <el-table-column prop="commitId" label="CommitId" min-width="120"></el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button @click="handleClose">关闭</el-button>
      </span>
    </el-dialog>
  </div>

</template>

<script>
  import AppVersionPipeline from '@/components/biz/app/appVersionPipeline'

  export default {
    name: "appCompileHistoryList",
    data() {
      return {
        COMPILE_TASK_STATUS: GLOBAL_CONST.COMPILE_TASK_STATUS,
        table_loading: false,
        compileHistoryListData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        bizId: '',
        appId: '',
        taskUuid: '',
        examinelist: [],
        dialogVisible: false,
        shadeBtn: false,
        modaltobody: false,
      };
    },

    mounted() {
      let urlParams = this.getUrlParams();
      this.bizId = urlParams.bizId;
      this.appId = urlParams.appId;
      this.taskUuid = urlParams.uuid;
      this.renderTable();
    },

    methods: {
      showCompileDetail(info) {
        this.goToPage(this, 'AppCompileTaskOverView', {
          bizId: this.bizId,
          appId: this.appId,
          detailId: info.detailId,
        })
        // console.log(info)
      },
      getTaskEndTime(row) {
        if (row && row.status &&
            (row.status == GLOBAL_CONST.COMPILE_TASK_STATUS.COMPILE_RESULT_FAIL || row.status == GLOBAL_CONST.COMPILE_TASK_STATUS.COMPILE_RESULT_SUC)) {
          return row.endTime;
        }
        return "";
      },

      getTrigger(row) {
        if (row && (row.userId || row.userName)) {
          return row.userName + '(' + row.userId + ')';
        }
        return "";
      },

      getTriggerMode(row) {
        if (row) {
          return row.opType === 1 ? '手工' : '流水线';
        }
        return "";
      },

      getBranchName(row) {
        if (row) {
          return row.branch;
        }
        return "";
      },

      //查看按钮
      examineBtn(val) {
        let extraObjs = JSON.parse(val);
        extraObjs.forEach(item => {
          let commitId = item.commitId;
          let shotCommitId = commitId.substr(0, 8);
          item.commitId = shotCommitId;
        })
        this.examinelist = extraObjs;
        this.dialogVisible = true;
      },

      //关闭弹窗
      handleClose() {
        this.dialogVisible = false;
      },

      handleCompileHistoryListSizeChange(newPageSize) {
        this.compileHistoryListData.pageSize = newPageSize;
        this.renderTable();
      },

      handleCompileHistoryListPageChange(newPageNum) {
        this.compileHistoryListData.pageNum = newPageNum;
        this.renderTable();
      },

      renderTable() {
        this.table_loading = true;
        let params = {
          uuid: this.taskUuid,
          pageNum: this.compileHistoryListData.pageNum,
          pageSize: this.compileHistoryListData.pageSize,
        };

        $http.get($http.api.compile.compileHistoryLst, params).then(response => {
          this.compileHistoryListData = response.data;
          this.table_loading = false;
        });
      },

      goToCompileTaskList(row) {
        this.goToPage(this, 'AppCompileTaskList', {bizId: this.bizId, appId: this.appId});
      },

      getClassByRunningStatus(status) {
        switch (status) {
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_NEW:
            return "icon-status-init-l";
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_ING:
            return "icon-status-running-l";
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_SUC:
            return "icon-status-success-l";
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_FAIL:
            return "icon-status-fail-l";
        }
      },

      showVersionPipeline(workflowId) {
        //第三个参数true，表示从流水线执行历史记录页面跳转到流水线执行详情页面
        this.$refs.appVersionPipeline.showVersionPipeline(workflowId, this.appId, true);
      },
    },

    components: {
      AppVersionPipeline
    }
  };
</script>
