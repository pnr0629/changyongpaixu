/**
 * 特性分支 mixin
 * 
 * time: 2019.7.2
 * author: heyunjiang
 */
import config from '@/base/js/config'

export default {
  data() {
    return {
      workflowTaskId: 0, // 当前活跃 task 的 id
      currentSelectedWorkflow: {} // 当前活跃 task info
    }
  },
  computed: {
    showLogBox() {
      return this.currentSelectedWorkflow.task && config.showLogBox.includes(this.currentSelectedWorkflow.task.type);
    }
  },
  methods: {
    updateWorkflowTaskInfo(workflowTaskinfo) {
      this.workflowTaskId = workflowTaskinfo.id;
      this.currentSelectedWorkflow = workflowTaskinfo;
    }
  }
}