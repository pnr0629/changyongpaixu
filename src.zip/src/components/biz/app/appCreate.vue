<template>
  <div id="appCreate" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box p10">
          <div style="height:60px">
            <el-steps :space="200" :active="activeStep" finish-status="finish" style="padding-left: 8%;" align-center>
              <el-step title="应用配置"></el-step>
              <el-step title="开发模式"></el-step>
              <el-step title="基础信息"></el-step>
              <el-step title="编译信息"></el-step>
              <el-step title="运行信息"></el-step>
              <el-step title="人员信息"></el-step>
              <el-step title="完成"></el-step>
            </el-steps>
          </div>
          <div class="table-box-top">
            <div class="step1_box">
              <div v-show="activeStep===0" class="mt10">
                <el-form :model="createInfo" ref="createInfo_step1">
                  <el-form-item class="firstradio" label-width="130px"
                    :style="{'margin-bottom':createInforadio == '1'?'-10px':'10px'}">
                    <el-radio-group v-model="createInforadio">
                      <el-radio id="NEWAPPTYPENEW" label="0" class="mt5 mb10">新建应用</el-radio>
                      <el-radio id="NEWAPPTYPECOPY" label="1" class="mt5 mb10">复制已有的应用配置</el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item style="margin-left: 130px" label-width="130px" label="复制的应用名称:"
                    v-if="createInforadio == '1'" prop="copyAppId"
                    :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-select id="NEWAPPTYPECOPYSELECT" v-model="createInfo.copyAppId" placeholder="请选择" filterable>
                      <el-option v-for="item in queryTypelist" :key="item.appId" :label="item.appCode"
                        :value="item.appId">
                        <span style="float: left">{{ item.appCode }}</span>
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
                <div style="margin-left:170px;margin-top:25px;">
                  <el-button id="NEWAPPNEXT1" type="primary" @click="nextBntton_1">下一步</el-button>
                </div>
              </div>

              <!-- 开发模式 -->
              <div v-show="activeStep===1" class="mt10">
                <el-form :model="createInfo" ref="createInfo_step1">
                  <el-form-item class="firstradio" label-width="130px">
                    <el-radio-group v-model="createInfo.developMode">
                      <el-radio label="0" class="mt5 mb10">自由模式：可以在任意分支上进行构建，部署等操作，
                        <a class="c-blue cp" href="http://columbus.os.adc.com/doc/detail?productId=1&selectedId=526" target="_blank">了解更多 》》</a>
                      </el-radio>
                      <el-radio label="1" class="mt5 mb10">分支模式：在各特性分支上开发，用哥伦布管理它们的集成和发布，
                        <a class="c-blue cp" href="http://columbus.os.adc.com/doc/detail?productId=1&selectedId=527" target="_blank">了解更多 》》</a></el-radio>
                    </el-radio-group>
                  </el-form-item>
                </el-form>
                <div style="margin-left:170px;margin-top:25px;">
                  <el-button id="NEWAPPNEXT1" type="primary" @click="nextBntton_1">下一步</el-button>
                </div>
              </div>

              <!-- ========================================================== -->
              <div v-show="activeStep===2" class="mt10">
                <el-form :model="createInfo" ref="createInfo_step2">
                  <el-form-item label-width="130px" label="应用ID" prop="appCode" :rules="rules1.appCode">
                    <el-input id="NEWAPPAPPID" v-model="createInfo.appCode" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="130px" label="应用名称" prop="appName"
                    :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input id="NEWAPPAPPNAME" v-model.trim="createInfo.appName" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="130px" label="调用链ID" prop="appSnakeId">
                    <el-input v-model="createInfo.appSnakeId" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="130px" label="允许发布分支规则" prop="publishableBranches"
                    :rules="rules1.publishableBranches">
                    <el-input v-model="createInfo.publishableBranches" placeholder="请输入允许发布分支规则,多个用逗号分隔,留空表示允许所有分支发布"
                      class="width-input-select" />
                    <i class="el-icon-question" title="单击此图标以查看/隐藏允许发布分支规则详情" @click="triggerPublishableBranchesDesc()"
                      style="font-size: 16px;padding: 5px;" />
                  </el-form-item>
                  <el-form-item label-width="130px" label="版本名称规则" prop="versionNameTemplateData"
                    :rules="rules1.versionNameTemplateData">
                    <el-input id="NEWAPPRULE" v-model="createInfo.versionNameTemplateData" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                    <i class="el-icon-question" title="单击此图标以查看/隐藏版本名称规则详情" @click="triggerVersionNameTemplateDesc()"
                      style="font-size: 16px;padding: 5px;" />
                  </el-form-item>
                  <div style="width: 550px;margin-left: 70px" v-if="showPublishableBranchesDesc">
                    <span style="font-size: 16px;">允许发布分支规则示例：master,release/*,hotfix/**</span><br />
                    <span style="font-size: 16px;">允许发布分支规则说明：?（匹配单个字符），*（匹配0或多个字符），**（匹配0或多个字符及目录）</span><br />
                    <span style="font-size: 16px;">留空表示允许所有分支发布</span>
                  </div>
                  <div style="width: 550px;margin-left: 70px" v-if="showVersionNameTemplateDesc">
                    <span style="font-size: 16px;">版本名称规则示例：${appId}-${date}-${totalIncr}</span><br />
                    <span style="font-size: 16px;">版本名称规则说明：生成的版本名称会对${xxx}形式的占位符做替换</span>
                    <el-table border :data="tipInfo" style="width: 100%;height:100%;margin-top: 20px">
                      <el-table-column prop="key" label="KEY" min-width="100"></el-table-column>
                      <el-table-column prop="explaim" label="释义" min-width="100"></el-table-column>
                      <el-table-column prop="extraInfo" label="说明" min-width="100"></el-table-column>
                    </el-table>
                  </div>
                </el-form>
                <div style="margin-left: 120px;margin-top:25px;">
                  <el-button type="primary" @click="lastStep">上一步</el-button>
                  <el-button id="NEWAPPNEXT2" type="primary" @click="nextBntton_2">下一步</el-button>
                </div>
              </div>
              <!-- ================================================================ -->
              <div v-show="activeStep===3" class="mt10">

                <el-form :model="createInfo" ref="createInfo_step3" :rules="createInfo">
                  <el-form-item label-width="140px" label="编译方式" prop="appType" :rules="rules1.appType">
                    <el-select v-model="createInfo.appType" placeholder="请选择" class="width-input-select"
                      @change="onCompileMethodChange()">
                      <el-option v-for="item in compileMethodOptions" :key="item.key" :label="item.key"
                        :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>

                  <el-row>
                    <div style="display: inline-block">
                      <el-form-item :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]" class='mb15'
                        label="编译镜像" prop="typeId" label-width="80px" style="margin-left: 60px">
                        <el-select v-model="createInfo.typeId" placeholder="请选择" class="width-input-select"
                          @change="onCompileTypeChange()" style="width: 225px;">
                          <el-option v-for="item in compileTypeList" :key="item.typeId" :label="item.typeName"
                            :value="item.typeId"></el-option>
                        </el-select>
                      </el-form-item>
                    </div>
                    <div style="display: inline-block">
                      <el-form-item :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]" class='mb15' label=""
                        prop="imageId" label-width="0px">
                        <el-select v-model="createInfo.imageId" placeholder="请选择"
                          style="width: 260px;margin-left: 10px">
                          <el-option v-for="item in compileTypeImageList" :key="item.id" :label="item.imageRepo"
                            :value="item.id" />

                        </el-select>
                      </el-form-item>
                    </div>
                  </el-row>

                  <el-form-item v-if="createInfo.appType != APP_TYPE.MULTI_REPO_SHELL" label-width="140px" label="源码仓库"
                    prop="sourceRepo" :rules="rules1.sourceRepo">
                    <el-input id="NEWAPPSOURCEREPO" v-model="createInfo.sourceRepo" placeholder="请输入内容"
                      class="width-input-select">
                    </el-input>
                  </el-form-item>

                  <el-form-item label-width="140px" label="编译语言" prop="appLanguage"
                    v-if="!isAndroidAPKApp(createInfo.appType)">
                    <el-select v-model="createInfo.appLanguage" placeholder="请选择" class="width-input-select">
                      <el-option key="1" label="JAVA" value="JAVA" class="mt5 mb10">JAVA</el-option>
                      <el-option key="2" label="PHP" value="PHP" class="mt5 mb10">PHP</el-option>
                      <el-option key="3" label="C++" value="C++" class="mt5 mb10">C++</el-option>
                      <el-option key="4" label="GO" value="GO" class="mt5 mb10">GO</el-option>
                      <el-option key="5" label="HTML" value="HTML" class="mt5 mb10">HTML</el-option>
                      <el-option key="6" label="JS" value="JS" class="mt5 mb10">JS</el-option>
                    </el-select>
                  </el-form-item>

                  <el-form-item label-width="140px" label="mvn命令" v-if="isMavenJavaApp(createInfo.appType)"
                    prop="mvnCmd" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input id="NEWAPPMVNINPUT" v-model="createInfo.mvnCmd" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="140px" label="pom文件" v-if="isMavenJavaApp(createInfo.appType)"
                    prop="pomFile" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input id="NEWAPPPOMINPUT" v-model="createInfo.pomFile" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>

                  <el-form-item label-width="140px" label="gradle命令"
                    v-if="isGradleJavaApp(createInfo.appType) || isAndroidAPKApp(createInfo.appType)" prop="gradleCmd"
                    :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input placeholder="请输入内容" v-model="createInfo.gradleCmd" class="width-input-select"></el-input>
                  </el-form-item>

                  <el-form-item label-width="140px" label="目标文件路径"
                    v-if="isJavaApp(createInfo.appType) || isAndroidAPKApp(createInfo.appType)" prop="targetDir"
                    :rules="rules1.targetDir">
                    <el-input id="NEWAPPTARGETDIRINPUT" v-model="createInfo.targetDir" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>

                  <el-form-item v-if="createInfo.appType != APP_TYPE.TAR" label-width="140px" label="目标文件压缩格式"
                    prop="targetPattern">
                    <el-select v-model="createInfo.targetPattern" placeholder="请选择" class="width-input-select">
                      <el-option v-if="isNotWebJavaApp(createInfo.appType) || isShellScriptApp(createInfo.appType)"
                        :value="'zip'" label="zip">zip
                      </el-option>
                      <el-option v-if="isNotWebJavaApp(createInfo.appType) || isShellScriptApp(createInfo.appType)"
                        :value="'tar'" label="tar">tar
                      </el-option>
                      <el-option v-if="isShellScriptApp(createInfo.appType)" :value="'rpm'" label="rpm">rpm</el-option>
                      <el-option v-if="isNotWebJavaApp(createInfo.appType)" :value="'jar'" label="jar">jar</el-option>
                      <el-option v-if="isJavaWebApp(createInfo.appType)" :value="'war'" label="war">war</el-option>
                      <el-option v-if="isAndroidAPKApp(createInfo.appType)" :value="'apk'" label="apk">apk</el-option>
                      <el-option v-if="isAndroidAPKApp(createInfo.appType)" :value="'aar'" label="aar">aar</el-option>
                    </el-select>
                  </el-form-item>

                  <el-form-item label-width="140px" label="打包目录" v-if="createInfo.appType == APP_TYPE.TAR" prop="tarDir"
                    :rules="[{ required: true, message: '不能为空' ,trigger:'blur'} ]">
                    <el-input v-model="createInfo.tarDir" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="140px" label="生成文件" v-if="createInfo.appType == APP_TYPE.TAR"
                    prop="targetFileName" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input placeholder="请输入内容" v-model="createInfo.targetFileName" class="width-input-select">
                    </el-input>
                  </el-form-item>
                  <el-form-item label-width="140px" class="mt20" label="自定义脚本"
                    v-if="isShellScriptApp(createInfo.appType)" prop="appShellInfo"
                    :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input v-model="createInfo.appShellInfo" type="textarea" :rows="5" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                    <a class="el-icon-question cp" title="单击此图标以查看自定义脚本构建帮助文档"
                       href="http://doc.oppoer.me/pages/viewpage.action?pageId=40077947" target="view_window"
                        style="font-size: 16px;padding: 5px;" />
                  </el-form-item>
                  <el-form-item label-width="140px" class="mt20" label="自定义初始化脚本"
                    v-if="createInfo.appType == APP_TYPE.MULTI_REPO_SHELL" prop="appCustomInitShellInfo">
                    <el-input v-model="createInfo.appCustomInitShellInfo" type="textarea" :rows="5" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>


                  <div v-for="(item,index) in createInfo.applicationlists"
                    v-if="createInfo.appType == APP_TYPE.MULTI_REPO_SHELL" :key="index">
                    <el-row>
                      <el-col :span="10">
                        <el-form-item label-width="140px" :label="'应用ID/源码仓库'"
                          :prop="'applicationlists['+index+'].subAppId'"
                          :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]">
                          <el-input v-model="item.subAppId" style="width:200px;"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="11">
                        <el-form-item label-width="0px" class="multi-repo-class" label=""
                          :prop="'applicationlists['+index+'].sourceRepo'" :rules="rules1.sourceRepo">
                          <el-input v-model="item.sourceRepo" style="width:290px; margin-left: 60px"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span="3">
                        <el-button @click="removeapplicationlist(item)" style=" margin-top: 7px; margin-left: 20px"
                          :style="createInfo.applicationlists.length > 1?'visibility: visible':'visibility: hidden'">删除
                        </el-button>
                      </el-col>
                    </el-row>
                  </div>
                  <el-form-item v-if="createInfo.appType == APP_TYPE.MULTI_REPO_SHELL">
                    <el-button @click="addApplication" style="margin-left:140px" class="mt20 fl">+新增应用模块
                    </el-button>
                  </el-form-item>

                  <el-form-item label-width="140px" label="是否增量" prop="incr"
                    :rules="[  { required: true, message: '不能为空' ,trigger:'blur'}  ]">
                    <el-radio-group v-model="createInfo.incr">
                      <el-radio :label="1">是</el-radio>
                      <el-radio :label="0">否</el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item label-width="140px" label="使用公共仓库" v-if="isMavenJavaApp(createInfo.appType)"
                    prop="usePublicRepo" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-radio-group v-model="createInfo.usePublicRepo" placeholder="请选择" style="width: 110px"
                      class="width-input-select">
                      <el-radio :label="1" class="mt5 mb10">是</el-radio>
                      <el-radio :label="0" class="mt5 mb10">否</el-radio>
                    </el-radio-group>
                    <i class="el-icon-question"
                      title="使用公共仓库会使用打包机器本地localRepository下缓存的依赖包，不使用则每次构建开辟一个临时localRepository从中央仓库下载所有的依赖包"
                      style="font-size: 16px;padding: 5px"></i>
                  </el-form-item>
                  <el-form-item label-width="140px" label="是否生成镜像" prop="createImage"
                    :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-radio-group v-model="createInfo.createImage" @change="changeTypeHandle()">
                      <el-radio :label="1">是</el-radio>
                      <el-radio :label="0">否</el-radio>
                    </el-radio-group>
                  </el-form-item>

                  <!--生成镜像设置-->

                  <div style="display: inline-block;">
                    <el-form-item label-width="140px" label="基础镜像:" v-if="createInfo.createImage === 1">
                      <el-select v-model="createInfo.baseTypeId" placeholder="请选择" class="width-input-select"
                        style="width: 220px;" @change="underCompileTypeChange()">
                        <el-option v-for="item in underCompileTypeOptions" :key="item.typeId" :label="item.typeName"
                          :value="item.typeId" />
                      </el-select>
                    </el-form-item>
                  </div>
                  <div style="display: inline-block">
                    <el-form-item label-width="0px" label="" v-if="createInfo.createImage === 1">
                      <el-select v-model="createInfo.baseImageId" placeholder="请选择" class="width-input-select"
                        style="width: 268px;margin-left: 6px">
                        <el-option v-for="item in underCompileTypeImageOptions" :key="item.id" :label="item.imageRepo"
                          :value="item.id" />
                      </el-select>
                    </el-form-item>
                  </div>

                  <el-form-item label-width="140px" label="CPU核数:" v-if="createInfo.createImage === 1" prop="cpu"
                    :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input v-model="createInfo.cpu" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="140px" label="内存(单位M):" v-if="createInfo.createImage === 1" prop="memory"
                    :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input v-model="createInfo.memory" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="140px" label="磁盘存储(单位G):" v-if="createInfo.createImage === 1"
                    prop="storage" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                    <el-input v-model="createInfo.storage" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>

                  <div v-if="isJavaWebApp(createInfo.appType)">
                    <div><b>TOMCAT设置</b></div>
                    <el-form-item label-width="140px" label="Tomcat版本" prop="tomcatVersion">
                      <el-select v-model="createInfo.tomcatVersion" placeholder="请选择" class="width-input-select">
                        <el-option :value="'tomcat7'" label="tomcat7">tomcat7</el-option>
                        <el-option :value="'tomcat8'" label="tomcat8">tomcat8</el-option>
                      </el-select>
                    </el-form-item>
                    <el-form-item label-width="140px" label="Tomcat路径" prop="tomcatContext">
                      <el-input v-model="createInfo.tomcatContext" placeholder="请输入内容" class="width-input-select">
                      </el-input>
                    </el-form-item>
                    <el-form-item label-width="140px" label="Tomcat默认端口" prop="tomcatDefaultPort">
                      <el-input v-model="createInfo.tomcatDefaultPort" placeholder="请输入内容" class="width-input-select">
                      </el-input>
                    </el-form-item>

                    <div><b>JVM参数设置</b></div>
                    <el-form-item label-width="140px" label="JAVA_OPTS" prop="tomcatJavaOpts">
                      <el-input v-model="createInfo.tomcatJavaOpts" placeholder="请输入内容" type="textarea" :row="5"
                        class="width-input-select"></el-input>
                    </el-form-item>

                    <div><b>Connector参数设置</b></div>
                    <el-form-item v-for="(value,key) in connectorInfo" label-width="140px" :label="key" :key="key">
                      <el-input v-if="key!=='protocol'" v-model="connectorInfo[key]" placeholder="请输入内容"
                        class="width-input-select"></el-input>
                      <el-select v-if="key==='protocol'" v-model="connectorInfo[key]" placeholder="请输入内容"
                        class="width-input-select">
                        <el-option :value="'org.apache.coyote.http11.Http11NioProtocol'" label="NIO">NIO</el-option>
                        <el-option :value="'org.apache.coyote.http11.Http11Nio2Protocol'" label="NIO2">NIO2</el-option>
                        <el-option :value="'org.apache.coyote.http11.Http11Protocol'" label="BIO">BIO</el-option>
                        <el-option :value="'org.apache.coyote.http11.Http11AprProtocol'" label="APR">APR</el-option>
                      </el-select>
                      <span class="el-icon-delete" v-if="fixedOptions.indexOf(key) == -1"
                        @click="delConnectorInfo(key)"></span>
                    </el-form-item>

                    <el-form :inline="true">
                      <el-form-item label="字段名" style="margin-left: 90px;">
                        <el-input v-model="newConnectorInfo" style="width: 330px" placeholder="请输入Connector字段名">
                        </el-input>
                      </el-form-item>
                      <el-form-item>
                        <el-button @click="addConnectorInfo()" icon="el-icon-plus">新增Connector配置</el-button>
                      </el-form-item>
                    </el-form>
                  </div>


                  <!-- ======================================================= -->
                </el-form>
                <div
                  :style="{'margin-left':'120px','margin-bottom':'15px','margin-top':createInfo.appType == 1?'50px':'25px'}">
                  <!-- <el-button type="primary" @click="lastBntton_4">跳过</el-button> -->
                  <el-button type="primary" @click="lastStep">上一步</el-button>
                  <el-button id="NEWAPPNEXT3" type="primary" @click="nextBntton_3">下一步</el-button>
                </div>
              </div>

              <!-- ========================================================================= -->
              <div v-show="activeStep===4" class="mt10">
                <el-form :model="createInfo" ref="createInfo_step4" :rules="createInfo">
                  <el-form-item class='mb15' label="部署类型" label-width="120px" prop="publishType"
                    :rules="rules1.publish">
                    <el-select id="NEWAPPPUBLISHTYPE" class="width-input-select" v-model="createInfo.publishType"
                      placeholder="请选择" @change="publishTypeChanged()">
                      <el-option :id="'NEWAPPPUBLISHTYPEITEM'+index" v-for="(item, index) in deployTypeOptions"
                        :key="index" :label="item.name" :value="item.value"></el-option>
                    </el-select>
                  </el-form-item>

                  <el-form-item label-width="120px" label="App根目录" prop="baseDir" :rules="rules1.baseDir">
                    <el-input id="NEWAPPBASEDIRINPUT" v-model="createInfo.baseDir" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                    <el-checkbox v-model="createInfo.userDefineDir" :true-label="1" :false-label="0">自定义目录</el-checkbox>
                  </el-form-item>
                  <span style="margin-left: 120px"
                    v-if="createInfo.userDefineDir == 1">{{"使用自定义目录时请注意在该目录下只能部署单个进程，请确认是否存在其他进程"}}</span>


                  <el-form-item :span='24' v-if="createInfo.publishType==1" label="实例目录" prop="instanceDir"
                    label-width="120px">
                    <el-input v-model="createInfo.instanceDir" :disabled="createInfo.userDefineDir == 0"
                      placeholder="请输入实例目录" style="width: 500px">
                      <template slot="prepend">{{createInfo.baseDir}}</template>
                    </el-input>
                    <span style="color: #c0c4cc">{{getRealInstanceDir()}}</span>
                  </el-form-item>

                  <el-form-item label-width="120px" label="实例目录" v-if="createInfo.publishType!=1">
                    <el-input placeholder="请输入内容"
                      :value="createInfo.baseDir+(createInfo.userDefineDir===0?'/'+createInfo.appCode+'/${instanceId}':'')+'/release'"
                      clearable disabled class="width-input-select"></el-input>
                  </el-form-item>

                  <el-form-item label-width="120px" label="运行用户名" prop="userName" :rules="rules1.userName">
                    <el-input id="NEWAPPUSERNAMEINPUT" v-model="createInfo.userName" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                  </el-form-item>

                  <el-form-item label-width="120px" label="默认运行JDK" prop="jdkVersion" v-if="isJavaApp(createInfo.appType)">
                    <el-select v-model="createInfo.jdkVersion" placeholder="请选择" class="width-input-select">
                      <el-option label="jdk_1.7" :value="'jdk_1.7'" class="mt5 mb10">jdk_1.7</el-option>
                      <el-option label="jdk_1.8" :value="'jdk_1.8'" class="mt5 mb10">jdk_1.8</el-option>
                      <el-option label="openjdk_8" :value="'openjdk_8'" class="mt5 mb10">openjdk_8
                      </el-option>
                      <el-option label="openjdk_11" :value="'openjdk_11'" class="mt5 mb10">openjdk_11
                      </el-option>
                    </el-select>
                  </el-form-item>

                  <el-form-item label-width="120px" label="配置下载目录" prop="confDir">
                    <el-input v-model="createInfo.confDir" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="120px" label="发布初始化脚本" prop="initShell">
                    <el-input v-model="createInfo.initShell" placeholder="请输入内容" class="width-input-select"></el-input>
                  </el-form-item>
                  <el-form-item label-width="120px" label="启动脚本" prop="startShell">
                    <el-input v-model="createInfo.startShell" :disabled="isJavaWebApp(createInfo.appType)"
                      placeholder="请输入内容" class="width-input-select"></el-input>
                    <span class="c-blue cp" @click="addParams(1)">添加启动参数</span>
                  </el-form-item>
                  <el-form-item label-width="120px" v-for="(item,index) in createInfo.startShellParamList"
                    :label="'启动参数'+(index+1)" :key="index" :prop="'startShellParamList['+index+']'"
                    :rules="rules1.shell">
                    <el-input v-model=createInfo.startShellParamList[index] placeholder="请输入内容"
                      class="width-input-select"></el-input>
                    <span class="c-red cp" @click="deleteParams(1,index)">删除</span>
                  </el-form-item>
                  <el-form-item label-width="120px" label="停止脚本" prop="stopShell">
                    <el-input v-model="createInfo.stopShell" :disabled="isJavaWebApp(createInfo.appType)"
                      placeholder="请输入内容" class="width-input-select"></el-input>
                    <span class="c-blue cp" @click="addParams(2)">添加停止参数</span>
                  </el-form-item>
                  <el-form-item label-width="120px" v-for="(item,index) in createInfo.stopShellParamList" :key="index"
                    :label="'停止参数'+(index+1)" :prop="'stopShellParamList['+index+']'" :rules="rules1.shell">
                    <el-input v-model="createInfo.stopShellParamList[index]" placeholder="请输入内容"
                      class="width-input-select"></el-input>
                    <span class="c-red cp" @click="deleteParams(2,index)">删除</span>
                  </el-form-item>

                  <el-form-item class='mb15' label="回滚脚本" label-width="120px" prop="rollBackShell"
                    v-if="createInfo.publishType==1">
                    <el-input placeholder="请输入内容" v-model="createInfo.rollBackShell" clearable
                      class="width-input-select"></el-input>
                  </el-form-item>

                  <el-form-item class='mb15' label="健康检查脚本" label-width="120px" prop="healthCheckShell">
                    <el-input placeholder="请输入内容" v-model="createInfo.healthCheckShell" clearable
                      class="width-input-select"></el-input>
                  </el-form-item>


                  <el-form-item label-width="120px" label="日志目录" prop="logDir"
                    :rules="[{ required: true, message: '不能为空' ,trigger: 'blur'}]">
                    <el-input v-model="createInfo.logDir" placeholder="请输入内容" class="width-input-select"></el-input>
                    <el-checkbox v-show="createInfo.logDir.trim().startsWith('/')"
                      v-model="createInfo.instanceLogDistinguish" :true-label="1" :false-label="0">
                      区分日志实例路径
                    </el-checkbox>
                  </el-form-item>
                  <el-form-item label="日志目录路径" label-width="120px">
                    <el-input placeholder="请输入内容"
                      :value="createInfo.logDir+(createInfo.instanceLogDistinguish===1?'/${instanceId}':'')" clearable
                      disabled class="width-input-select"></el-input>
                  </el-form-item>
                </el-form>
                <div style="margin-left: 120px;margin-top:25px;">
                  <el-button type="primary" @click="skip">跳过</el-button>
                  <el-button type="primary" @click="lastStep">上一步</el-button>
                  <el-button id="NEWAPPNEXT4" type="primary" @click="nextBntton_4" :loading="nextBntton_loading">下一步
                  </el-button>
                </div>
              </div>
              <!-- ================================================================================= -->
              <div v-show="activeStep===5" class="mt10">
                <el-form ref="createInfo_step5" :model="memberForm" :rules="memberFormRules">
                  <el-form-item label-width="120px" label="开发人员" prop="appDevMemberIdslist">
                    <el-select id="NEWAPPDEVMEMBERSELECT" v-model="memberForm.appDevMemberIdslist" multiple
                      placeholder="请选择" class="width-input-select">
                      <el-option :id="'NEWAPPDEVMEMBERSELECTITEM'+index" v-for="(item, index) in appDevList"
                        :key="item.userId" :label="item.userName" :value="item.userId">
                        <span style="float: left">{{ item.userName }}</span>
                        <span
                          style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label-width="120px" label="测试人员" prop="appTestMemberIdslist">
                    <el-select id="NEWAPPTESTMEMBERSELECT" v-model="memberForm.appTestMemberIdslist" multiple
                      placeholder="请选择" class="width-input-select">
                      <el-option :id="'NEWAPPTESTMEMBERSELECTITEM'+index" v-for="(item, index) in appTestList"
                        :key="item.userId" :label="item.userName" :value="item.userId">
                        <span style="float: left">{{ item.userName }}</span>
                        <span
                          style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label-width="120px" label="应用Owner" prop="appOwnerId">
                    <el-select id="NEWAPPOWNERSELECT" v-model="memberForm.appOwnerId" placeholder="请选择"
                      class="width-input-select">
                      <el-option :id="'NEWAPPOWNERSELECTITEM'+index" v-for="(item, index) in appOwnerList"
                        :key="item.userId" :label="item.userName" :value="item.userId">
                        <span style="float: left">{{ item.userName }}</span>
                        <span
                          style="float: right; color: #8492a6; font-size: 13px;margin-right:25px;">{{ item.userId }}</span>
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-form>
                <div
                  :style="{'margin-left':'120px','margin-bottom':'15px','margin-top':createInfo.appType == 4?'80px':'25px'}">
                  <el-button type="primary" @click="lastStep">上一步</el-button>
                  <el-button id="NEWAPPCREATEAPP" type="primary" @click="nextBntton_5">创建应用</el-button>
                </div>
              </div>

              <!-- ========================================================================================= -->
              <div v-show="activeStep === 6" class="mt10">
                <div style="display:inline-block;height: 200px; width:400px;float:left;margin-left:calc(50% - 200px)">
                  <span style="font-size: 30px;color:#409EFF;margin-left:160px;margin-bottom:10px;">创建成功！</span>
                  <div style="margin-left: 120px;">
                    <el-button id="NEWAPPGOTOAPPLIST" type="primary" @click="goToAppList">返回应用列表</el-button>
                    <el-button id="NEWAPPGOTOAPPDETAIL" type="primary" @click="goToAppDetail">进入详情页面</el-button>
                  </div>
                </div>
              </div>
            </div>

            <!-- ============================================================================================== -->
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  export default {
    name: "appCreate",
    data() {
      let isAppCodeAvailable = (rule, value, callback) => {
        var a = new Array("$", "@", "#", "!", "~", "`", "^", "&", "*", " ");
        for (let i = 0; i < a.length; i++) {
          if (value.indexOf(a[i]) >= 0) {
            callback(new Error("不能包含空格和特殊字符"));
            return;
          };
        };
        $http.get($http.api.app.checkAppCode, {
          appCode: value
        }).then((res) => {
          if (res.status == 200) {
            callback();
          } else {
            callback(new Error(res.msg));
          }
        }).catch(_ => { })
      };

      let validAppType = (rule, value, callback) => {
        if(this.createInfo.developMode == '1'
          && value == 5) {
          callback(new Error("多仓库应用不支持分支模式开发模式！"));
        } else{
          callback();
        }
      };

      let validTargetDir = (rule, value, callback) => {
        let targetPattern = this.createInfo.targetPattern;
        if (!this.targetPatternVerify(value, targetPattern)) {
          callback(new Error("目标文件路径中文件与目标文件压缩格式不符合！"));
        } else {
          callback();
        }
      };

      let validRepo = (rule, value, callback) => {
        let checkGitSshUrl = /^(git@|ssh:\/\/\w+@)\w+/;

        let checkGitHttpUrl = /^[A-Za-z]+:\/\/+/;

        if (!checkGitSshUrl.test(value) && !checkGitHttpUrl.test(value)) {
          callback(new Error("源码仓库格式错误！请检查git地址格式! 形如git@xxx或者ssh://xxx@xxx或者http://xxx"));
        } else {
          $http.get($http.api.app.sourceRepoValidate, {originalSourceRepo: "", sourceRepo: value.trim(), developMode:this.createInfo.developMode})
          .then((res) => {
            if ( res.status == 200) {
              callback();
            } else {
              callback(new Error(res.msg));
            }
          }).catch(_ => {})
        }
      };
      let validShell = (rule, value, callback) => {
        let invalidateChar = ["`", "$", "|", ";", "&&", ">", "<"];
        if (value) {
          for (let oneChar of invalidateChar) {
            if (value.indexOf(oneChar) !== -1) {
              callback(new Error("参数不能包含特殊字符" + oneChar));
              return;
            }
          }
        }
        callback();
      };
      let validBaseDir = (rule, value, callback) => {
        if (value.substr(0, 1) != "/") {
          callback(new Error("APP根目录必须是绝对路径"));
        } else {
          callback();
        }
      };
      let validUserName = (rule, value, callback) => {
        value = value.trim().toLowerCase();
        if (value === 'root') {
          callback(new Error("运行用户名不能为root"));
        } else {
          callback();
        }
      };
      let validVersionNameTemplateData = (rule, value, callback) => {
        let spaceList = value.split(" ");
        if (spaceList.length > 1) {
          callback(new Error("请去除空格！"))
        }

        let pattern = /\w*(\${[a-zA-Z]+})*\w*/;
        if (!pattern.test(value)) {
          callback(new Error("输入格式错误！"))
        }

        let tempList = value.split("${");
        let afterTrim = tempList.splice(1, tempList.length - 1);
        let realList = [];
        afterTrim.forEach(item => {
          realList.push(item.substring(0, item.indexOf("}")));
        });
        realList.forEach(item => {
          if (GLOBAL_CONST.DEFAULT_VERSION_NAME_TEMPLATE_DATA_LIST.indexOf(item) == -1) {
            callback(new Error("占位符变量填写错误，建议拷贝填入"));
          }
        })
        callback();
      };
      let validPublishableBranches = (rule, value, callback) => {
        if (!value) {
          callback();
        } else {
          let spaceList = value.split(" ");
          if (spaceList.length > 1) {
            callback(new Error("请去除空格！"))
          } else {
            callback();
          }
        }
      }
      return {
        underCompileTypeImageOptions: [],
        underCompileTypeOptions: [],
        baseImageShowVal: '',
        tipInfo: [
          { key: 'date', explaim: '时间戳（精确至日期）', extraInfo: '' },
          { key: 'dateTime', explaim: '时间戳（精确至秒）', extraInfo: '' },
          { key: 'appId', explaim: '应用ID', extraInfo: '' },
          { key: 'branchName', explaim: '分支名称', extraInfo: '多仓库自定义脚本类应用不支持' },
          { key: 'todayIncr', explaim: '应用当天打包总数自增', extraInfo: '' },
          { key: 'totalIncr', explaim: '应用历史打包总数自增', extraInfo: '' },
        ],
        isSkip: 0,
        fixedOptions: ['protocol', 'maxThreads', 'minSpareThreads', 'maxConnections', 'acceptCount', 'connectionTimeOut'],
        appCodeMsg: '',
        appId: '',
        bizId: '',
        rules1: {
          publishableBranches: [{ validator: validPublishableBranches, trigger: 'blur' }],
          versionNameTemplateData: [{ required: true, message: '版本名称规则不能为空', trigger: 'blur' }, { validator: validVersionNameTemplateData, trigger: 'blur' }],
          appCode: [{ required: true, message: '应用ID不能为空' }, { validator: isAppCodeAvailable, trigger: 'blur' }],
          appType: [{ required: true, message: '请选择编译方式' }, { validator: validAppType, trigger: 'change' }],
          sourceRepo: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validRepo, trigger: 'blur' }],
          baseDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validBaseDir, trigger: 'blur' }],
          targetDir: [{ required: true, message: '不能为空' }, { validator: validTargetDir, trigger: 'blur' },],
          publish: [{ required: true, message: '不能为空', trigger: 'blur' }],
          shell: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validShell, trigger: 'blur' }],
          userName: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validUserName, trigger: 'blur' }]
        },
        createInforadio: '0',
        newConnectorInfo: "",
        connectorInfo: {
          protocol: "org.apache.coyote.http11.Http11NioProtocol",
          maxThreads: "200",
          minSpareThreads: "10",
          maxConnections: "10000",
          acceptCount: "100",
          connectionTimeOut: "20000"
        },
        deployTypeOptions: [{ name: "普通发布", value: 0 }, { name: "yum发布", value: 1 }],
        createInfo: {
          developMode: '0',
          instanceDir: '',
          healthCheckShell: '',
          rollBackShell: '',
          publishableBranches: '',
          baseTypeId: 0,
          baseImageId: 0,
          baseImageRepo: '',
          typeId: '',
          imageId: '',
          imageRepo: '',
          imageTag: '',
          publishType: 0,
          versionNameTemplateData: '',
          instanceLogDistinguish: 0,
          userDefineDir: 0,
          baseImage: 'Java 7',
          cpu: '4',
          memory: '4096',
          storage: '50',
          bizId: '',
          copyAppId: '',
          appCode: '',
          appName: '',
          appSnakeId: '',
          appLanguage: 'JAVA',
          sourceRepo: '',
          appType: '1',
          jdkVersion: 'openjdk_11',
          incr: 0,
          createImage: 0,
          usePublicRepo: 1,
          mvnCmd: '',
          targetPattern: 'jar',
          targetDir: '',
          pomFile: '',
          gradleCmd: '',
          targetFileName: '',
          tarDir: '',
          appShellInfo: '',
          appCustomInitShellInfo: '',
          baseDir: '',
          userName: '',
          startShell: '',
          stopShell: '',
          logDir: 'logs',
          initShell: '',
          startShellParams: '',
          stopShellParams: '',
          startShellParamList: [],
          stopShellParamList: [],
          confDir: '',
          tomcatVersion: '',
          tomcatContext: '',
          tomcatDefaultPort: '',
          tomcatJavaOpts: '',
          protocol: '',
          maxThreads: '',
          minSpareThreads: '',
          maxConnections: '',
          acceptCount: '',
          connectionTimeOut: '',
          appDevMemberIds: '',
          appTestMemberIds: '',
          //添加配置参数
          domains: [],
          applicationlists: [{ subAppId: '', sourceRepo: '' }]
        },

        javaAppBuildTool: 1,

        appDevList: [],
        appTestList: [],
        appOwnerList: [],
        memberFormRules: {
          appDevMemberIdslist: [{ type: 'array', required: true, message: '开发人员不能为空', trigger: 'blur' }],
          appTestMemberIdslist: [{ type: 'array', required: true, message: '测试人员不能为空', trigger: 'blur' }],
          appOwnerId: [{ required: true, message: '应用Owner不能为空', trigger: 'blur' }]
        },
        memberForm: {
          appDevMemberIdslist: [],
          appTestMemberIdslist: [],
          appOwnerId: ''
        },
        activeStep: 0,
        nextBntton_loading: false,
        APP_TYPE: GLOBAL_CONST.APP_TYPE,
        COMPILE_IMAGE_TYPE: GLOBAL_CONST.COMPILE_IMAGE_TYPE,
        compileMethodOptions: [
          { key: 'Java编译', value: '1' },
          { key: 'Java Web编译', value: '2' },
          { key: '自动打包', value: '3' },
          { key: '自定义脚本', value: '4' },
          { key: '多仓库自定义脚本', value: '5' },
          { key: "Java Gradle编译", value: '6' },
          { key: "Java Web Gradle编译", value: '7' },
          { key: 'Android APK', value: '8' },
        ],

        javaAppBuildToolOptions: [
          { 'key': 'Maven', 'value': 1 },
          { 'key': 'Gradle', 'value': 2 },
        ],

        businesslist: [
          {
            value: 'docker-test',
            label: 'docker-test'
          },
          {
            value: 'pass管控平台',
            label: 'pass管控平台'
          },
          {
            value: '基础技术k8s',
            label: '基础技术k8s'
          }
        ],
        serverCodeobj: {
          'docker-test': 'docker-test',
          'pass管控平台': 'pass管控平台',
          '基础技术k8s': '基础技术k8s',
        },
        queryTypelist: [],
        showVersionNameTemplateDesc: false,
        showPublishableBranchesDesc: false,
        compileTypeImageList: [],
        compileTypeList: [],
        gradleCompileTypeOptions: [],
        androidCompileTypeOptions: [],
      };
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this._getpage();
      this.initCompileTypes();
      this.initImageTypes()
    },

    methods: {
      getAppOwnerList() {
        $http.get($http.api.biz.get_selected_app_owners, { bizId: this.bizId }).then((res) => {
          let selectiveAppOwners = res.data.allBizMember
          this.appOwnerList = selectiveAppOwners
        }).catch(e => {
          this.$message({ type: "error", message: "获取可选应用Owner信息失败！" });
        })
      },
      //因为前端逻辑，Java，Java_Web的通用判断由原来的Maven代表，具体是Maven还是Gradle则由前端javaAppBuildTool属性共同决定
      isJavaApp(appType) {
        return appType == this.APP_TYPE.JAVA_MAVEN
          || appType == this.APP_TYPE.JAVA_WEB_MAVEN
          || appType == this.APP_TYPE.JAVA_GRADLE
          || appType == this.APP_TYPE.JAVA_WEB_GRADLE;
      },

      isNotWebJavaApp(appType) {
        return appType == this.APP_TYPE.JAVA_MAVEN
          || appType == this.APP_TYPE.JAVA_GRADLE;
      },

      isJavaWebApp(appType) {
        return appType == this.APP_TYPE.JAVA_WEB_MAVEN
          || appType == this.APP_TYPE.JAVA_WEB_GRADLE;
      },

      isMavenJavaApp(appType) {
        return (appType == this.APP_TYPE.JAVA_MAVEN || appType == this.APP_TYPE.JAVA_WEB_MAVEN) && this.javaAppBuildTool == 1;
      },

      isGradleJavaApp(appType) {
        return ((appType == this.APP_TYPE.JAVA_MAVEN || appType == this.APP_TYPE.JAVA_WEB_MAVEN) && this.javaAppBuildTool == 2)
          || appType == this.APP_TYPE.JAVA_GRADLE || appType == this.APP_TYPE.JAVA_WEB_GRADLE;
      },

      isAndroidAPKApp(appType) {
        return appType == this.APP_TYPE.ANDROID_APK;
      },

      //跟isJavaApp并非严格二分，还是要列举出类型
      isNotJavaApp(appType) {
        return appType == this.APP_TYPE.TAR
          || appType == this.APP_TYPE.SHELL
          || appType == this.APP_TYPE.MULTI_REPO_SHELL;
      },

      isShellScriptApp(appType) {
        return appType == this.APP_TYPE.SHELL || appType == this.APP_TYPE.MULTI_REPO_SHELL;
      },

      addParams(type) {
        if (type == 1) {
          this.createInfo.startShellParamList.push("");
        } else {
          this.createInfo.stopShellParamList.push("");
        }
      },
      deleteParams(type, index) {
        if (type == 1) {
          this.createInfo.startShellParamList.splice(index, 1);
        } else {
          this.createInfo.stopShellParamList.splice(index, 1);
        }
      },

      isContainerBuildApp(appType) {
        return !this.isMavenJavaApp(appType);
      },

      underCompileTypeChange() {
        this.$set(this.createInfo, 'baseImageId', '');
        $http.get($http.api.compile.compileTypeImages, { bizId: this.bizId, typeId: this.createInfo.baseTypeId }).then((res) => {
          this.underCompileTypeImageOptions = res.data;
        }).catch(() => {
          this.$message({
            type: "error",
            message: "获取基础镜像失败"
          });
        });
      },

      getRealInstanceDir() {
        if (!this.createInfo.baseDir) {
          this.createInfo.baseDir = "";
        }
        if (!this.createInfo.instanceDir) {
          this.createInfo.instanceDir = "";
        }
        return this.createInfo.baseDir + this.createInfo.instanceDir;
      },
      publishTypeChanged() {
        if (this.createInfo.publishType == 1) {
          this.createInfo.userDefineDir = 1;
        }
      },
      userDefineDirChanged() {
        if (this.createInfo.userDefineDir == 0) {
          this.createInfo.instanceDir = "/" + this.createInfo.appCode + "/${instanceId}/release"
        } else {
          this.createInfo.instanceDir = "/release"
        }
      },
      skip() {
        this.isSkip = 1;
        $http.get($http.api.biz.list_biz_devs, { bizId: this.bizId }).then((res) => {
          this.appDevList = res.data;
        })
        $http.get($http.api.biz.list_biz_tests, { bizId: this.bizId }).then((res) => {
          this.appTestList = res.data;
        })
        this.getAppOwnerList()
        this.nextStep();
      },

      initCompileTypes() {
        $http.get($http.api.compile.compileTypes, { typePurpose: -1 }).then((res) => {
          let allTypes = res.data;
          let compileTypePurposes = [];
          let baseCompileTypePurposes = [];
          this.gradleCompileTypeOptions = [];
          this.androidCompileTypeOptions = [];
          allTypes.forEach(item => {
            if (item.typePurpose === 0) {
              compileTypePurposes.push(item);
            }
            if (item.typePurpose === 2) {
              baseCompileTypePurposes.push(item);
            }
            if (item.typeId == this.COMPILE_IMAGE_TYPE.PRIVATE
              || item.typeId == this.COMPILE_IMAGE_TYPE.GRADLE) {
              this.gradleCompileTypeOptions.unshift(item);
            }

            if (item.typeId == this.COMPILE_IMAGE_TYPE.PRIVATE
              || item.typeId == this.COMPILE_IMAGE_TYPE.ANDROID) {
              this.androidCompileTypeOptions.unshift(item);
            }
          })

          this.underCompileTypeOptions = baseCompileTypePurposes;
          if (this.underCompileTypeOptions.length > 0) {
            this.createInfo.baseTypeId = this.underCompileTypeOptions[0].typeId;
          }
        }).catch(() => {
          this.$message({
            type: "error",
            message: "获取镜像类型失败"
          });
        });
      },

      onCompileTypeChange() {
        this.$set(this.createInfo, 'imageId', '');

        $http.get($http.api.compile.compileTypeImages, { bizId: this.bizId, typeId: this.createInfo.typeId }).then((res) => {
          this.compileTypeImageList = res.data;
        }).catch(() => {
          this.$message({
            type: "error",
            message: "获取镜像失败"
          });
        });
      },

      targetPatternVerify(targetDir, targetPattern) {
        let endFormat = [".zip", ".jar", ".tar", ".tar.gz", ".war"];
        let count = 0;
        for (let i = 0; i < endFormat.length; i++) {
          if (targetDir.endsWith(endFormat[i])) {
            count++;
            break;
          }
        }
        if (count === 0) {
          return true;
        }
        if (targetDir.endsWith(targetPattern)) {
          return true;
        }
        if (targetPattern == "tar" && targetDir.endsWith(targetPattern + ".gz")) {
          return true;
        }
        return false;
      },

      delConnectorInfo(key) {
        this.$delete(this.connectorInfo, key);
      },

      addConnectorInfo() {
        if (this.newConnectorInfo && this.newConnectorInfo !== '') {
          for (let key in this.connectorInfo) {
            if (this.newConnectorInfo === key) {
              this.$message({
                message: '该配置已存在',
                type: 'error'
              });
              return;
            }
          }
          this.connectorInfo[this.newConnectorInfo] = '';
          this.newConnectorInfo = ''
        } else {
          this.$message({
            message: '请输入字段名',
            type: 'error'
          });
        }
      },

      //打开页面获取应用名称
      _getpage() {
        let params = {
          pageNum: 1,
          pageSize: 10000,
          keyword: ''
        };
        $http.get($http.api.biz.getAppList, params).then(res => {
          this.queryTypelist = res.data.list;
        });
      },

      initImageTypes() {
        $http.get($http.api.compile.image_types, { compileType: this.createInfo.appType }).then(res => {
          this.compileTypeList = res.data
        });
      },
      onCompileMethodChange() {
        this.initImageTypes();
        let curPattern = this.createInfo.targetPattern;
        if (this.isNotWebJavaApp(this.createInfo.appType)) {//java
          //1 2 4
          if (['zip', 'tar', 'jar'].indexOf(curPattern) === -1) {
            this.createInfo.targetPattern = 'jar';
          }
        } else if (this.isJavaWebApp(this.createInfo.appType)) { //java web
          this.createInfo.targetPattern = 'war';
        } else if (this.isAndroidAPKApp(this.createInfo.appType)) {
          this.createInfo.targetPattern = 'apk';
        } else if (this.createInfo.appType == this.APP_TYPE.SHELL) {
          if (['zip', 'tar', 'rpm'].indexOf(curPattern) == -1) {
            this.createInfo.targetPattern = 'zip';
          }
        }
        if (this.createInfo.appType == this.APP_TYPE.MULTI_REPO_SHELL) {
          if (!this.createInfo.applicationlists || this.createInfo.applicationlists.length == 0) {
            this.createInfo.applicationlists = [{ subAppId: '', sourceRepo: '' }];
          }
        }
        this.createInfo.typeId = '';
        this.createInfo.imageId = '';

      },

      changeTypeHandle() {
        if (this.createInfo.createImage === 1) {
          this.underCompileTypeChange();
        }
      },



      // 第一步
      nextBntton_1() {
        // this.initCompileTypes();
        this.$refs["createInfo_step1"].validate(valid => {
          if (valid) {
            if (this.createInforadio == '0') {
              this.nextStep();
            } else if (this.createInforadio == '1') {
              $http.get($http.api.creat_yy.apiapplicationgetappinfo, { appId: this.createInfo.copyAppId }).then((res) => {
                if (res.status == 110) {
                  this.$message({
                    message: 'Server Error',
                    type: 'error'
                  })
                } else if (res.status == 200) {
                  for (var key1 in this.createInfo) {
                    for (var key2 in res.data.applicationBasicInfoForm) {
                      if (key1 == key2) {
                        this.createInfo[key1] = res.data.applicationBasicInfoForm[key2];

                      }
                    }
                    for (var key3 in JSON.parse(res.data.applicationCompileDefaultBo.appConfig)) {
                      if (key1 == key3) {
                        this.createInfo[key1] = JSON.parse(res.data.applicationCompileDefaultBo.appConfig)[key3];
                      }

                    }
                  }
                  this.createInfo.serverCode = this.serverCodeobj[res.data.applicationBasicInfoForm.serverCode];
                  this.createInfo.incr = res.data.applicationCompileDefaultBo.incr;

                  let retAppType = res.data.applicationCompileDefaultBo.appType;
                  this.createInfo.appType = retAppType + '';
                  this.initImageTypes();
                  this.createInfo.createImage = res.data.applicationCompileDefaultBo.createImage;
                  this.createInfo.appLanguage = res.data.applicationCompileDefaultBo.appLanguage;
                  this.createInfo.usePublicRepo = res.data.applicationCompileDefaultBo.baseAppConfig.usePublicRepo;
                  this.createInfo.appShellInfo = res.data.applicationCompileDefaultBo.appShellInfo;
                  this.createInfo.appCustomInitShellInfo = res.data.applicationCompileDefaultBo.appCustomInitShellInfo;

                  this.createInfo.typeId = res.data.applicationCompileDefaultBo.typeId;
                  if (this.createInfo.typeId != null) {
                    this.onCompileTypeChange();
                  }
                  this.createInfo.imageId = res.data.applicationCompileDefaultBo.imageId;

                  if (!res.data.applicationDeployConfig.baseDir) {
                    this.createInfo.baseDir = '';
                  } else {
                    this.createInfo.baseDir = res.data.applicationDeployConfig.baseDir;
                  }

                  this.createInfo.userName = res.data.applicationDeployConfig.userName;
                  this.createInfo.logDir = res.data.applicationDeployConfig.logDir;
                  if (!res.data.applicationDeployConfig.logDir) {
                    this.createInfo.logDir = 'logs';
                  }
                  this.createInfo.startShell = res.data.applicationDeployConfig.startShell;
                  this.createInfo.stopShell = res.data.applicationDeployConfig.stopShell;
                  this.createInfo.restartShell = res.data.applicationDeployConfig.restartShell;
                  this.createInfo.initShell = res.data.applicationDeployConfig.initShell;
                  this.createInfo.userDefineDir = res.data.applicationDeployConfig.userDefineDir;

                  this.createInfo.confDir = res.data.applicationDeployConfig.confDir;
                  this.createInfo.rollBackShell = res.data.applicationDeployConfig.rollBackShell;
                  this.createInfo.healthCheckShell = res.data.applicationDeployConfig.healthCheckShell;
                  this.createInfo.instanceDir = res.data.applicationDeployConfig.instanceDir;
                  this.createInfo.publishType = res.data.applicationDeployConfig.publishType;

                  if (res.data.applicationDeployConfig.startShellParams) {
                    this.$set(this.createInfo, "startShellParamList", JSON.parse(res.data.applicationDeployConfig.startShellParams));
                  } else {
                    this.$set(this.createInfo, "startShellParamList", []);
                  }

                  if (res.data.applicationDeployConfig.stopShellParams) {
                    this.$set(this.createInfo, "stopShellParamList", JSON.parse(res.data.applicationDeployConfig.stopShellParams));
                  } else {
                    this.$set(this.createInfo, "stopShellParamList", []);
                  }

                  //处理实例目录
                  if (res.data.userDefineDir == 0) {
                    this.createInfo.instanceDir = '';
                  } else {
                    this.createInfo.instanceDir = this.createInfo.baseDir && this.createInfo.instanceDir ? this.createInfo.instanceDir.substr(this.createInfo.baseDir.length) : "";
                  }

                  if (!res.data.applicationDeployConfig.instanceLogDistinguish) {
                    this.createInfo.instanceLogDistinguish = 0;
                  } else {
                    this.createInfo.instanceLogDistinguish = res.data.applicationDeployConfig.instanceLogDistinguish;
                  }

                  this.createInfo.tomcatJavaOpts = res.data.applicationDeployConfig.otherConfigObject.tomcatJavaOpts;
                  this.createInfo.tomcatVersion = res.data.applicationDeployConfig.otherConfigObject.tomcatVersion;
                  this.createInfo.tomcatContext = res.data.applicationDeployConfig.otherConfigObject.tomcatContext;
                  this.createInfo.tomcatDefaultPort = res.data.applicationDeployConfig.otherConfigObject.tomcatDefaultPort;
                  if (!this.isEmptyObject(res.data.applicationDeployConfig.otherConfigObject.tomcatConnectorConfig)) {
                    try {
                      this.connectorInfo = res.data.applicationDeployConfig.otherConfigObject.tomcatConnectorConfig;
                    } catch (e) {
                    }
                  } else {
                    this.connectorInfo = {
                      protocol: "org.apache.coyote.http11.Http11NioProtocol",
                      maxThreads: "200",
                      minSpareThreads: "10",
                      maxConnections: "10000",
                      acceptCount: "100",
                      connectionTimeOut: "20000"
                    }
                  }

                  if (res.data.applicationCompileDefaultBo.createImage === 1) {
                    this.createInfo.baseTypeId = res.data.applicationDeployConfig.baseTypeId;
                    if (this.createInfo.baseTypeId != null) {
                      this.underCompileTypeChange();
                    }
                    this.createInfo.baseImageId = res.data.applicationDeployConfig.baseImageId;
                    this.createInfo.cpu = res.data.applicationDeployConfig.otherConfigObject.cpu;
                    this.createInfo.memory = res.data.applicationDeployConfig.otherConfigObject.memory;
                    this.createInfo.storage = res.data.applicationDeployConfig.otherConfigObject.storage;
                  }

                  if (res.data.applicationCompileDefaultBo.appType == 5) {
                    if (!res.data.applicationCompileDefaultBo.baseAppConfig.subAppBos) {
                      //没有值，手动添加响应参数
                      //this.$set(this.createInfo.applicationlists, 'applicationlists', [{subAppId:'',sourceRepo:''}]);
                      this.createInfo.applicationlists = [{ subAppId: '', sourceRepo: '' }];
                    } else {
                      this.createInfo.applicationlists = res.data.applicationCompileDefaultBo.baseAppConfig.subAppBos;
                    }
                  }
                  this.appDevMemberIdslist = res.data.applicationMemberInfoBo.appDevMembers;
                  this.appTestMemberIdslist = res.data.applicationMemberInfoBo.appTestMembers;
                  this.nextStep();
                }
              })
            }

          }
        });

      },
      isEmptyObject(obj) {
        if (!obj || obj == '') {
          return true;
        }
        for (let objKey in obj) {
          return false;
        }
        return true;

      },

      //选完开发模式的下一步
      nextButton_1_1() {
        this.nextStep();
      },



      // 第二步
      nextBntton_2() {
        this.$refs["createInfo_step2"].validate(valid => {

          if (valid) {
            if (!this.createInfo) {
              this.createInfo.appType = '1';
            }
            this.nextStep();
          }
        });
      },

      // 第三步
      nextBntton_3() {
        this.$refs["createInfo_step3"].validate(valid => {
          if (valid) {
            if (this.createInfo.appType == 2) {
              this.createInfo.startShell = 'bin/startup.sh';
              this.createInfo.stopShell = 'bin/shutdown.sh';
            }
            this.nextStep();
          }
        });
      },

      //删除子应用ID和仓库
      removeapplicationlist(item) {
        let index = this.createInfo.applicationlists.indexOf(item);
        if (index !== -1) {
          this.createInfo.applicationlists.splice(index, 1)
        }
      },
      //添加添加子应用ID和仓库
      addApplication() {
        this.createInfo.applicationlists.push({
          subAppId: '',
          sourceRepo: '',
        });
      },

      // 第四步
      nextBntton_4() {
        $http.get($http.api.biz.list_biz_devs, { bizId: this.bizId }).then((res) => {
          this.appDevList = res.data;
        })
        $http.get($http.api.biz.list_biz_tests, { bizId: this.bizId }).then((res) => {
          this.appTestList = res.data;
        })
        this.getAppOwnerList()
        this.$refs["createInfo_step4"].validate(valid => {
          if (valid) {
            this.nextStep();
          }
        });

      },


      //删除新增配置参数
      removeDomain(item) {
        var index = this.createInfo.domains.indexOf(item)
        if (index !== -1) {
          this.createInfo.domains.splice(index, 1)
        }
      },
      //添加配置参数
      addDomain() {
        this.createInfo.domains.push({
          value1: '',
          value2: '',
          key: Date.now()
        });
      },


      // 第五步
      nextBntton_5() {
        let param = {};
        this.createInfo.bizId = this.bizId;
        param.bizId = this.createInfo.bizId;
        param.developMode = this.createInfo.developMode;
        this.$refs["createInfo_step5"].validate(valid => {
          if (valid) {
            this.nextBntton_loading = true;
            setTimeout(() => {
              //人员信息
              this.createInfo.appDevMemberIds = this.memberForm.appDevMemberIdslist.join(",");
              param.appDevMemberIds = this.memberForm.appDevMemberIdslist.join(",");
              this.createInfo.appTestMemberIds = this.memberForm.appTestMemberIdslist.join(",");
              param.appTestMemberIds = this.memberForm.appTestMemberIdslist.join(",");
              param.appOwnerId = this.memberForm.appOwnerId

              param.appCode = this.createInfo.appCode;
              param.appName = this.createInfo.appName;
              param.appSnakeId = this.createInfo.appSnakeId;
              param.versionNameTemplateData = this.createInfo.versionNameTemplateData;
              param.publishableBranches = this.createInfo.publishableBranches;

              if (this.createInfo.appType != this.APP_TYPE.MULTI_REPO_SHELL) {
                param.sourceRepo = this.createInfo.sourceRepo;
              }

              param.createImage = this.createInfo.createImage;

              let realAppType = this.createInfo.appType;

              param.appType = realAppType;
              param.appLanguage = this.createInfo.appLanguage;
              param.incr = this.createInfo.incr;

              if (this.isJavaApp(param.appType)) {
                if (this.isMavenJavaApp(param.appType)) {
                  param.usePublicRepo = this.createInfo.usePublicRepo;
                  param.mvnCmd = this.createInfo.mvnCmd;
                  param.pomFile = this.createInfo.pomFile;
                }

                if (this.isGradleJavaApp(param.appType)) {
                  param.gradleCmd = this.createInfo.gradleCmd;
                }

                param.jdkVersion = this.createInfo.jdkVersion;
                param.targetPattern = this.createInfo.targetPattern;
                if (this.createInfo.targetDir) {
                  param.targetDir = this.createInfo.targetDir.trim();
                } else {
                  param.targetDir = this.createInfo.targetDir;
                }
              }

              if (this.isAndroidAPKApp(param.appType)) {
                param.gradleCmd = this.createInfo.gradleCmd;
                param.targetPattern = this.createInfo.targetPattern;
                param.targetDir = this.createInfo.targetDir;
              }

              if (this.isJavaWebApp(param.appType)) {
                param.tomcatVersion = this.createInfo.tomcatVersion;
                param.tomcatContext = this.createInfo.tomcatContext;
                param.tomcatDefaultPort = this.createInfo.tomcatDefaultPort;
                param.tomcatJavaOpts = this.createInfo.tomcatJavaOpts;
                param.tomcatConnectorConfig = JSON.stringify(this.connectorInfo);
              }

              if (param.appType == this.APP_TYPE.TAR) {
                if (this.createInfo.tarDir) {
                  param.tarDir = this.createInfo.tarDir.trim();
                } else {
                  param.tarDir = this.createInfo.tarDir;
                }
                param.targetFileName = this.createInfo.targetFileName;
              }

              if (this.isShellScriptApp(param.appType)) {
                param.targetPattern = this.createInfo.targetPattern;
                param.appShellInfo = this.createInfo.appShellInfo;
              }
              if (param.appType == this.APP_TYPE.MULTI_REPO_SHELL) {
                param.appCustomInitShellInfo = this.createInfo.appCustomInitShellInfo;
                if (this.createInfo.applicationlists && this.createInfo.applicationlists.length != 0) {
                  param.subAppBosStr = JSON.stringify(this.createInfo.applicationlists);
                }
              }

              // if (this.isContainerBuildApp(param.appType)) {
              param.typeId = this.createInfo.typeId;
              this.compileTypeImageList.forEach(item => {
                if (this.createInfo.imageId == item.id) {
                  param.imageRepo = item.imageRepo;
                  param.imageTag = item.imageTag;
                }
              })
              // }

              if (!!!this.createInfo.publishType) {
                param.publishType = 0;
              } else {
                param.publishType = this.createInfo.publishType;
              }

              if (this.isSkip == 0) {
                param.baseDir = this.createInfo.baseDir;
                param.userName = this.createInfo.userName;
                param.logDir = this.createInfo.logDir;
                param.startShell = this.createInfo.startShell;
                param.stopShell = this.createInfo.stopShell;
                param.restartShell = this.createInfo.restartShell;
                param.initShell = this.createInfo.initShell;
                param.userDefineDir = this.createInfo.userDefineDir;
                param.healthCheckShell = this.createInfo.healthCheckShell;

                if (this.createInfo.logDir.trim().startsWith('/')) {
                  param.instanceLogDistinguish = this.createInfo.instanceLogDistinguish;
                } else {
                  param.instanceLogDistinguish = 0;
                }

                if (this.createInfo.userDefineDir == 0 || this.createInfo.publishType != 1) {
                  param.instanceDir = "";
                } else {
                  param.instanceDir = this.createInfo.baseDir + this.createInfo.instanceDir;
                }

                if (this.createInfo.publishType == 1) {
                  param.rollBackShell = this.createInfo.rollBackShell;
                } else {
                  param.rollBackShell = "";
                }
              }
              if (this.createInfo.createImage == 1) {
                param.baseImage = this.createInfo.baseImage;
                param.cpu = this.createInfo.cpu;
                param.memory = this.createInfo.memory;
                param.storage = this.createInfo.storage;
                param.baseTypeId = this.createInfo.baseTypeId;
                param.baseImageId = this.createInfo.baseImageId;
                this.underCompileTypeImageOptions.forEach(item => {
                  if (param.baseImageId === item.id) {
                    param.baseImageRepo = item.imageRepo;
                  }
                })
              }

              param.confDir = this.createInfo.confDir;

              if (this.createInfo.startShellParamList && this.createInfo.startShellParamList.length !== 0) {
                param.startShellParams = JSON.stringify(this.createInfo.startShellParamList);
              } else {
                param.startShellParams = "";
              }

              if (this.createInfo.stopShellParamList && this.createInfo.stopShellParamList.length !== 0) {
                param.stopShellParams = JSON.stringify(this.createInfo.stopShellParamList);
              } else {
                param.stopShellParams = "";
              }

              console.log(param)
              $http.post($http.api.creat_yy.createApplication, param).then((res) => {
                if (res.status === 200) {
                  this.appId = res.data.appId;
                  this.$message({
                    message: '提交成功',
                    type: 'success'
                  });
                  $utils.getUserInfo();
                  this.nextStep();
                  //维护前端缓存
                  let allApps = $utils.getStorage(GLOBAL_CONST.ALL_APPS_LIST)
                  if (allApps.length > 0) {
                    allApps.push({ appId: this.appId, appCode: param.appCode })
                    $utils.saveStorage(GLOBAL_CONST.ALL_APPS_LIST, allApps)
                  }
                  //
                } else if (res.status === 110) {
                  this.$message({
                    message: '提交失败',
                    type: 'error'
                  })
                }
              })
              this.nextBntton_loading = false;
            }, 200);
          }
        });
      },

      //进入详情页面
      goToAppDetail() {
        if(this.createInfo.developMode == '1') {
          this.goToPage(this, 'featureBranchList', { bizId: this.bizId, appId: this.appId });
        } else{
          this.goToPage(this, 'appVersions', { bizId: this.bizId, appId: this.appId });
        }
      },

      //回退上一步
      lastStep() {
        this.activeStep--;
      },
      //下一步
      nextStep() {
        this.activeStep++;
      },

      //返回应用列表
      goToAppList() {
        this.goToPage(this, 'appList', { bizId: this.bizId });
      },

      triggerVersionNameTemplateDesc() {
        if (this.showVersionNameTemplateDesc) {
          this.showVersionNameTemplateDesc = false;
          this.showPublishableBranchesDesc = false;
        } else {
          this.showVersionNameTemplateDesc = true;
          this.showPublishableBranchesDesc = false;
        }
      },

      triggerPublishableBranchesDesc() {
        if (this.showPublishableBranchesDesc) {
          this.showPublishableBranchesDesc = false;
          this.showVersionNameTemplateDesc = false;
        } else {
          this.showPublishableBranchesDesc = true;
          this.showVersionNameTemplateDesc = false;
        }
      },

    },
  };
</script>

<style lang="scss" scoped>
  .table-box-top {
    height: -webkit-calc(100% - 50px);
    border: 1px solid #ebeef5;

    .step1_box {
      min-height: 350px;
      min-width: 400px;
      float: left;
      margin-left: calc(50% - 400px);
      margin-top: 30px;

      // border: 1px solid wheat;
      .firstradio {
        .el-radio-group {
          display: inline-grid;

          .el-radio {
            margin-left: 0 !important;
          }
        }
      }
    }
  }

  .multi-repo-class {
    .el-input {
      margin-left: 39px !important;
    }
  }
</style>
