<template>
  <div class="app-compiling">
    <div class="compiling-header">
      <div class="compile-title">
        {{taskOverViwe.taskName}}
      </div>
      <div class="compile-btn-box">
        <el-button @click="stopTask" type="primary"
          v-if="taskOverViwe.opType ===1 && (taskOverViwe.compileStatus ===1 || taskOverViwe.compileStatus ===0) ">停止执行
        </el-button>
        <el-button @click="startTask" type="primary"
          v-if="taskOverViwe.compileStatus ===2 || taskOverViwe.compileStatus ===3">执行
        </el-button>
        <el-button @click="goBack">返回
        </el-button>
      </div>
    </div>
    <div class="compiling-content">
      <div class="compile-info-item">
        <div class="c-key">代码分支：</div>
        <div class="c-val" :title="taskOverViwe.sourceBranch">{{taskOverViwe.sourceBranch ? taskOverViwe.sourceBranch : '--' }}</div>
      </div>
      <div class="compile-info-item">
        <div class="c-key">开始时间：</div>
        <div class="c-val">{{taskOverViwe.startTime}}</div>
      </div>
      <div class="compile-info-item">
        <div class="c-key">结束时间：</div>
        <div class="c-val">
          {{taskOverViwe.compileStatus === 2 ||taskOverViwe.compileStatus === 3?taskOverViwe.endTime : '--'}}</div>
      </div>
      <div class="compile-info-item">
        <div class="c-key">操作人：</div>
        <div class="c-val">{{taskOverViwe.userName}}({{taskOverViwe.userId}})</div>
      </div>
    </div>
    <div class="compile-execute">
      <div class="compile-execute-header" :class="bulidStatusData.stausColor">
        <i class="el-icon-success" v-show='bulidStatusData.statusIcon === 2'></i>
        <i class="el-icon-error" v-show='bulidStatusData.statusIcon === 3'></i>
        <i class="el-icon-loading" v-show='bulidStatusData.statusIcon === 1 || bulidStatusData.statusIcon === 0'></i>
        <!-- <i class="el-icon-remove" v-show='bulidStatusData.statusIcon === 0'></i> -->
        <i class="el-icon-video-pause" v-show='bulidStatusData.statusIcon === 4'></i> <span
          class="">{{bulidStatusData.statusDes}}</span>
        <i class="el-icon-video-play"></i> <span>{{getTriggerMode(taskOverViwe.opType)}}</span>
        <i class="el-icon-tickets"></i><span>{{taskOverViwe.commitId ?taskOverViwe.commitId : '--' }}</span>
        <el-button class="downlaod-vesion-pack" disabled type="info"
          v-if="taskOverViwe.checkPackage !==1 || taskOverViwe.compileStatus !==2 ">下载版本包
        </el-button>
        <el-button class="downlaod-vesion-pack" v-if="taskOverViwe.checkPackage ===1 && taskOverViwe.compileStatus ===2"
          @click="downloadLog">下载版本包</el-button>
      </div>
      <div class="compile-execute-content">
        <div class="compile-execute-content-l">
          <el-tabs v-model="bulidStatusData.activeName">
            <el-tab-pane label="步骤日志" name="first">
              <el-steps :active="active" finish-status="success" :icon="icon" space="60px" direction="vertical">
                <el-step :title="item.name" :icon='icon[index]' v-for="(item,index) in taskOverViwe.stepRunningInfoBos"
                  :key="index">
                </el-step>
              </el-steps>
            </el-tab-pane>
            <el-tab-pane label="执行参数" name="second">
              <div class="execute-data-header">
                <div class="data-key-header">参数名</div>
                <div class="data-val-header">参数值</div>
              </div>
              <!-- <div class="execute-data"> -->
              <div class="execute-data" v-for='(item,key) in taskOverViwe.setting' :key="key">
                <div class="data-key">{{key}}</div>
                <div class="data-val">{{item}}</div>
              </div>
              <!-- </div> -->
            </el-tab-pane>

          </el-tabs>

        </div>
        <div class="compile-excute-content-r">
          <div class="box-card-body-body_right" :style="{height:clientHeight}" id="logDetail">
            <p v-html="logDetail" style="word-wrap: break-word;word-break: break-all;"></p>
            <p v-show="lastOffsets > 0"><i class="el-icon-loading"></i></p>
          </div>
        </div>
      </div>
    </div>

    <!-- <el-button style="margin-top: 12px;" @click="next">下一步</el-button> -->

    <el-dialog title='编译任务' :visible.sync="dialogVisible_master1" class="el-dialog-400w"
      :before-close="handleClose_master1" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="packInfo" ref="packInfo" label-width="100px">
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">

            <el-col :span='24'>
              <el-form-item class='mb15' label="版本分支" label-width="100px" prop="branch" :rules="[
                   { required: true, message: '版本分支不能为空' }
               ]">
                <el-select v-model="packInfo.branch" placeholder="请选择" @change="updateData" style="width:200px;">
                  <el-option v-for="(item,index) in branchLst" :key="index" :label="item.name" :value="item.name" :title="item.name" style="width:200px;">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <!-- 如果对应的构建任务设置了“构建参数”， 则展示给用户选择-->
            <el-col :span='24'
                    v-if="compileInfo.appType != 5 && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:200px;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose_master1">取消</el-button>
        <el-button type="primary" @click="goToCompiling">确定</el-button>
      </span>
    </el-dialog>
    <el-dialog title='编译任务' :visible.sync="dialogVisible_master2" class="" :modal-append-to-body="modaltobody"
      :close-on-click-modal='shadeBtn'>

      <div class="pb20" v-loading="table_loading" element-loading-text="拼命加载中">
        <el-table ref="branchTale" :border="true" :data="tableListNew.data" @select-all="selectAllEvent"
          @select='handleSelectionChange'>
          <el-table-column type="selection" width="50"></el-table-column>
          <el-table-column prop="subAppId" label="子应用ID" min-width="160"></el-table-column>
          <el-table-column prop="sourceRepo" label="源码仓库" min-width="200"></el-table-column>
          <el-table-column prop="sourceBranch" label="分支名称" min-width="180">
            <template slot-scope="scope">
              <el-select v-model="scope.row.branchBosid" placeholder="请选择" @change="branchBosidChange" filterable>
                <el-option v-for="item in scope.row.branchBos" :key="item.sourceBranch" :label="item.sourceBranch"
                  :value="item.commitIdWithIndex">
                </el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="commitId" min-width="180">
            <template slot-scope="scope">
              <el-input contenteditable="plaintext-only" style="min-height:28px;"
                v-model="scope.row.branchBosidCommitId">
              </el-input>
            </template>
          </el-table-column>
        </el-table>
        <div class="table_b_f_b">
          <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleBranchSizeChange"
            @current-change="handleBranchCurrentChange" :current-page="branchPageData.pageNum"
            :page-sizes="[10, 20, 50]" :page-size="branchPageData.pageSize"
            layout="total, sizes, prev, pager, next, jumper" :total="branchPageData.total"
            :pages="branchPageData.pages"></el-pagination>
        </div>
      </div>
      <el-collapse v-if="buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
        <el-collapse-item>
          <template slot="title">
            请选择构建参数
          </template>
          <div>
            <el-form :model="packInfo" ref="packInfo" label-width="100px" @submit.native.prevent>
              <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
                <!-- 如果对应的构建任务设置了“构建参数”， 则展示给用户选择-->
                <el-col :span='24'
                        v-if="buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
                  <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                                v-for="(item,index) in buildTaskVaiableList">
                    <el-autocomplete
                      class="inline-input"
                      v-model="item.currentOption"
                      placeholder="请输入内容"
                      style="width:200px;"
                      :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                      :disabled="false"
                      @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                    >
                    </el-autocomplete>
                    {{item.desc}}
                    <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                      <span class="el-form-item__error">构建参数不能为空</span>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </el-collapse-item>
      </el-collapse>
      <span slot="footer" class="dialog-footer">
        <el-button @click=" handleClose_master2">取消</el-button>
        <el-button type="primary" @click="goToCompiling('mbanch')">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
  export default {
    name: 'AppCompiling',
    data() {
      return {
        logDetail: "",
        type: '',
        tableListNew: {
          appType: 0,
          data: [],//多仓库表格数据
        },
        totalSet:[],
        lastOffsets: 0,
        offset: 0,
        taskOverViwe: {
          stepRunningInfoBos: {
            id: ''
          }
        },
        stepOverViwe: {},
        dialogVisible_master1: false,
        dialogVisible_master2: false,
        compilingInfo: {
          label: 1,
          to: 2
        },
        branchPageData: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pages: 0
        },
        count: 0,//计数器
        status: 'success',
        // stepList: [{ label: '步骤' }, { label: '步骤2' }],
        active: 0,
        icon: [],
        finsh: false,
        table_loading: false,
        bulidTime: null,
        modaltobody: false,
        compileInfo: {},//获取编译方式
        buildTaskVaiableList: [],
        packInfo: {},
        shadeBtn: false,
        branchLst: [],//分支列表
        bulidStatusData: {
          stausColor: '',
          statusDes: "构建中",
          statusIcon: 0, //0初始化 1进行中 2成功 3失败
          isVersion: false,//判断版本本是否纯在
          activeName: 'first'

        },
        clientHeight:'',//屏幕可见高度
      }
    },
    watch: {
      logDetail() {
        this.$nextTick(() => {
          let logDetailDiv = this.$el.querySelector('#logDetail');
          if (logDetailDiv) {
            logDetailDiv.scrollTop = logDetailDiv.scrollHeight
          }
        })
      }
    },
    mounted() {
      this.bizId = this.getUrlBizId();
      this.appId = this.getUrlAppId();
      this.taskId = this.getUrlParams().taskId;
      this.detailId = this.getUrlParams().detailId;
      this.getAllDetail();
      this.clientHeight = document.body.clientHeight-264+'px';
    },
    destroyed() {
      this.finsh = true;
      this.offset = -1;
    },
    methods: {
      goBack() {
        this.$router.go(-1);//返回上一层
      },
      getBuildTaskVarsJson() {
        let varsSelectedObj = {};
        this.buildTaskVaiableList.forEach(item => {
          varsSelectedObj[item.variable] = item.currentOption;
        });
        return varsSelectedObj;
      },
      queryVariableSearch(queryString, cb , variable) {
        var restaurants = [];
        this.buildTaskVaiableList.forEach(item => {
          if(item.variable == variable){
            restaurants = item.options;
          }
        });
        var results = [];
        restaurants.forEach((item)=>{
          if(queryString == null || queryString == "" || item.toLowerCase().indexOf(queryString) == 0){
            results.push({value:item})
          }
        });
        cb(results);
      },
      handleOptionsSelect(selectData , currentOption){
        currentOption = selectData;
      },
      getpageCode() {
        $http
          .get($http.api.pipeline.appBranchCompleteInfo, {
            appId: this.appId
          })
          .then(res => {
            this.branchLst = res.data.branchLst;
            // console.log(this.branchLst)
          });
      },
      handleBranchSizeChange(val) {
        this.branchPageData.pageSize = val;
        this.fakePage(this.branchPageData.pageNum, val, this.search, this.appType);
      },

      handleBranchCurrentChange(val) {
        this.branchPageData.pageNum = val;
        this.fakePage(val, this.branchPageData.pageSize, this.search, this.appType);
      },
      branchBosidChange(val) {
        let arr = val.split(",");
        let indexStr = arr[2];
        let index = parseInt(indexStr);
        let data1 = this.tableList.data;
        let item = data1[index];
        if (item) {
          item.branchBosidCommitId = arr[0]
        }
      },
      getBranchList() {
        this.table_loading = true;
        let params = { appId: this.appId };
        $http.get($http.api.appdate.appBranchList, params).then((res) => {
          if (res.status == 200) {
            this.appType = res.data.appType;
            if (res.data.appType != 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                if (a.name == 'master' && b.name != 'master') {
                  return -1;
                } else if (a.name != 'master' && b.name == 'master') {
                  return 1;
                } else if (!a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return -1;
                } else if (a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return 1;
                } else if (!a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                } else if (a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                }
              })
              this.tableList = res.data;

              //data替换为分支名称排序后的
              this.tableList.data = data;
              this.appBranchInfo = this.tableList.data.concat([]);
              this.handleBranchSizeChange(this.branchPageData.pageSize);
              this.gitAddress = res.data.sourceRepo;
            } else if (res.data.appType == 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                return a.subAppId.localeCompare(b.subAppId);
              })
              res.data.data.forEach((subApp, index_i) => {
                if (subApp.branchBos.length > 0) {
                  subApp.branchBos.forEach((oneBranch, index) => {
                    if (oneBranch.sourceBranch == 'master') {
                      subApp.branchBosidCommitId = oneBranch.commitId;
                      subApp.branchBosid = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                    }
                    oneBranch.commitIdWithIndex = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                  })
                }
              })
              this.tableList = res.data;
              this.tableList.data = data;
              this.handleBranchSizeChange(this.branchPageData.pageSize);
            }
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
          this.table_loading = false;
        }).catch(_ => {
          this.table_loading = false;
        });
      },
      fakePage(num, size, keyWord, appType) {
        let allList = this.tableList.data;
        let tempList = [];
        let returnList = [];
        if (appType != 5) {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.name.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        } else {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.subAppId.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            this.tempList = tempList;
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        }
        this.$nextTick(() => {
          let tableListNew = this.tableListNew;
          tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale && branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },

      //全选事件
      selectAllEvent(data) {
        if (data.length == 0) {
          this.totalSet = [];
        } else {
          this.totalSet = [];
          this.tempList.forEach(item => {
            this.totalSet.push(item);
          });
        }
        this.$nextTick(() => {
          this.tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            let t = this.totalSet.indexOf(item) != -1;
            branchTale && branchTale.toggleRowSelection(item, t);
          })
        });
      },
      //表格勾选
      handleSelectionChange(val) {
        let dataList = this.tableListNew.data;
        dataList.forEach(item => {
          let index = this.totalSet.indexOf(item);
          if (index != -1) {
            this.totalSet.splice(index, 1)
          }
        });
        val.forEach(item => {
          this.totalSet.push(item);
        });
        this.$nextTick(() => {
          this.tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale && branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },
      targetPatternVerify(targetDir, targetPattern) {
        let endFormat = [".zip", ".jar", ".tar", ".tar.gz", ".war"];
        let count = 0;
        for (let i = 0; i < endFormat.length; i++) {
          if (targetDir.endsWith(endFormat[i])) {
            count++;
            break;
          }
        }
        if (count === 0) {
          return true;
        }
        if (targetDir.endsWith(targetPattern)) {
          return true;
        }
        if (targetPattern == "tar" && targetDir.endsWith(targetPattern + ".gz")) {
          return true;
        }
        return false;
      },
      hasVariableBlank() {
        var hasVariableBlank = false;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length > 0){
          this.buildTaskVaiableList.forEach(item=>{
            if(item.currentOption == null || item.currentOption == ""){
              hasVariableBlank = true;
            }
          });
        }
        return hasVariableBlank;
      },
      goToCompiling(menu) {
        if(this.hasVariableBlank()){
          this.$message({
            showClose: true,
            message: '构建参数不能为空',
            type: 'warning'
          });
          return;
        }
        var branch = '', gitRepoInfoLstJsonStr = '', buildTaskVarsJsonStr = '', commitId = '';
        if (menu === 'mbanch') {
          if(this.totalSet.length == 0){
            this.$message({
              message: '请勾选分支列表',
              type: 'warning'
            })
            return;
          }
          let totalList = JSON.parse(JSON.stringify(this.totalSet))
          totalList.forEach((item, index) => {
            if (item.branchBos) {
              delete item.branchBos;
              item['gitRepoUrl'] = item.sourceRepo;
              item['branch'] = item.branchBosid ? item.branchBosid.split(',')[1] : '';
              item['commitId'] = item.branchBosidCommitId ? item.branchBosidCommitId : '';
              delete item.sourceRepo;
              delete item.branchBosid;
              delete item.branchBosidCommitId
            }
          })
          let list = [];
          totalList.forEach(item => {
            list.push(item);
          })
          gitRepoInfoLstJsonStr = JSON.stringify(list);
          // sessionStorage.setItem('sendMbrachParmas', JSON.stringify(obj))
          if(this.buildTaskVaiableList.length > 0){
            buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
          }
        } else {
          for (let i = 0; i < this.branchLst.length; i++) {
            if (this.branchLst[i].name === this.packInfo.branch) {
              // console.log(this.branchLst[i].commit.id)
              commitId = this.branchLst[i].commit.id
            }
          }
          branch = this.packInfo.branch;
          buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        }

        $http.post($http.api.compile.task_start, { appId: this.appId, commitId, uuid: this.uuid, branch, gitRepoInfoLstJsonStr, buildTaskVarsJsonStr, }, { type: 'form' }).then(res => {
          // debugger
          this.detailId = res.data

          this.active = 0;
          this.count = 0;
          this.finsh = false;
          this.offset = 0;
          this.logDetail = null;
          this.getAllDetail()
          this.dialogVisible_master1 = false;
          this.dialogVisible_master2 = false;
        })


      },
      updateData() {
        this.$forceUpdate()
      },
      handleClose_master1() {
        this.$refs['packInfo'].resetFields();
        this.dialogVisible_master1 = false;
      },
      handleClose_master2() {
        this.dialogVisible_master2 = false;
      },
      handleClose_hand_upload() {
        this.$refs['correlationInfo_hand'].resetFields();
        this.$refs.upload.$data.uploadFiles.length = 0;
        this.dialogVisible_hand_upload = false;
      },
      startTask() {
        this.taskId = this.taskOverViwe.taskId
        this.uuid = this.taskOverViwe.uuid
        this.packInfo.branch = this.taskOverViwe.sourceBranch
        this.getpageCode()
        $http.get($http.api.compile.task_branch, { taskId: this.taskId }).then(res => {
          // this.buildTaskVaiableList = res.data
          this.getBranchList()
          $http.get($http.api.compile.task_variables, { taskId: this.taskId }).then(res => {
            this.buildTaskVaiableList = res.data
          })
          if (res.data.compileType !== 5) {
            this.dialogVisible_master1 = true;
          } else {
            this.dialogVisible_master2 = true;
          }
        })
      },
      downloadLog() {

        $http.get($http.api.compile.task_download, { detailId: this.detailId, }, { type: 'form' }).then(res => {
          window.open(res.data.downloadUrl)
        })
      },
      handleClick() {

      },
      bulidStatus(staus) {
        // debugger
        // console.log(staus)
        this.bulidStatusData.statusIcon = staus;
        // console.log(this.bulidStatusData.statusIcon)
        switch (staus) {
          case 0: this.bulidStatusData.statusDes = '初始化'; this.bulidStatusData.stausColor = 'compile-execute-init'; break;
          case 1: this.bulidStatusData.statusDes = '构建中'; this.bulidStatusData.stausColor = 'compile-execute-init'; break;
          case 2: this.bulidStatusData.stausColor = 'compile-execute-success'; this.bulidStatusData.statusDes = '构建成功'; break;
          case 3: this.bulidStatusData.stausColor = 'compile-execute-error'; this.bulidStatusData.statusDes = '构建失败'; break;
          case 4: this.bulidStatusData.stausColor = 'compile-execute-stop'; this.bulidStatusData.statusDes = '手动停止'; break;
        }

      },
      stopTask() {
        // this.getTaskAllView();
        $http.get($http.api.compile.task_stop, { detailId: this.detailId, }, { type: 'form' }).then(res => {
          if (res.status === 200) {
            this.$message({ type: "warning", message: "手动停止成功" })
          }
        })

      },

      //获取日志
      getlogS() {
        this.timer2 = null;
        if (this.offset === -1) {
          return
        }
        $http.post($http.api.compile.task_logs, { detailId: this.detailId, offset: this.offset }, { type: 'form' }).then(res => {
          this.offset = res.data.offset
          let str = res.data.logs;
          if (str && str.length > 0) {
            let lineArr = str.split('\n');
            let newStr = '';
            if (lineArr.length > 0) {
              lineArr.forEach((line) => {
                if (line && line.length > 0) {
                  if (line.indexOf('[WARN]') > -1 || line.indexOf('[WARNING]') > -1) {
                    newStr += '<span class="c-yellow">' + line + '</span><br/>';
                  } else if (line.indexOf('[ERROR]') > -1) {
                    newStr += '<span class="c-error">' + line + '</span><br/>';
                  } else {
                    newStr += line + '<br/>';
                  }
                }
              })
            }
            this.logDetail += newStr;
          }

          this.timer2 = setTimeout(() => {
            this.getlogS()
          }, 3000)
        })
      },
      formatDuring(mss) {
        var time = parseFloat(mss) / 1000;
        time = parseInt(time / 60.0) + "分钟" + parseInt((parseFloat(time / 60.0) - parseInt(time / 60.0)) * 60) + "秒";
        return time
      },
      //获取全部数据
      getAllDetail() {
        // console.log(111)
        $http.post($http.api.compile.task_overView, { detailId: this.detailId }, { type: 'form' }).then(res => {
          this.taskOverViwe = res.data
          this.taskOverViwe.setting = res.data.setting ? JSON.parse(this.taskOverViwe.setting) : '';
          if (!this.taskOverViwe.isManual) {
            this.bulidStatus(this.taskOverViwe.compileStatus)
          } else {
            this.bulidStatus(4)
          }
          this.icon = [];
          this.active = 0;
          for (let i = 0; i < this.taskOverViwe.stepRunningInfoBos.length; i++) {
            if (this.taskOverViwe.stepRunningInfoBos[i].stepRunningStatus === 0) {
              this.icon.push('el-icon-remove');
            } else if (this.taskOverViwe.stepRunningInfoBos[i].stepRunningStatus === 1) {
              this.icon.push('el-icon-loading');
            } else if (this.taskOverViwe.stepRunningInfoBos[i].stepRunningStatus === 2) {
              this.active++
              this.icon.push("");
            } else if (this.taskOverViwe.stepRunningInfoBos[i].stepRunningStatus === 3) {
              this.icon.push('iconfont icon-status-fail-l');
            }
          }
          // console.log(this.icon)
          if (this.count === this.taskOverViwe.stepRunningInfoBos.length || this.finsh) { return }

          if (this.taskOverViwe.compileStatus !== 0) {
            this.getStepOverViwe();
            this.getlogS()
          } else if (this.taskOverViwe.compileStatus === 0) {
            this.timer = setTimeout(() => {
              this.getAllDetail()
            }, 1000)
          }
        })
      },
      getStepOverViwe() {
        this.timer1 = null;
        if (this.count === this.taskOverViwe.stepRunningInfoBos.length || this.finsh) { return }
        $http.post($http.api.compile.step_overView, { executeId: this.taskOverViwe.stepRunningInfoBos[this.count].id }, { type: 'form' }).then(res => {
          if (res.data.stepRunningStatus == 0) {
            this.timer = setTimeout(() => {
              this.getAllDetail();
            }, 3000)
          } else if (res.data.stepRunningStatus == 1) {
          } else if (res.data.stepRunningStatus == 2) {
            this.count++;
            this.getAllDetail();
          } else if (res.data.stepRunningStatus == 3) {

            this.finsh = true;
            this.getAllDetail()

            return
          }
          this.timer1 = setTimeout(() => {
            this.getStepOverViwe()
          }, 3000)
        })
      },
      getTriggerMode(row) {
        if (row) {
          return row.opType === 1 ? '手工触发' : '流水线触发';
        }
        return "";
      },

    },
  }
</script>
<style lang="scss" scoped>
  .el-icon-error {
    /* color: red; */
  }

  .app-compiling {
    .compiling-header {
      overflow: hidden;

      .compile-title {
        font-size: 15px;
        font-weight: 700;
        color: #333;
        float: left;
      }

      .compile-btn-box {
        float: right;

      }
    }

    .compiling-content {
      padding-top: 10px;

      .compile-info-item {
        display: inline-block;
        /* height: 60px; */
        border-right: 1px solid #E3E5E9;
        width: 160px;
        height: 44px;

        .c-key {
          color: #5E6678;
          line-height: 20px;
        }

        .c-val {
          font-weight: 700;
          line-height: 24px;
          font-size: 14px;
          height: 24px;
          max-height: 24px;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }
    }

    .compile-execute {
      .compile-execute-header {
        line-height: 40px;
        height: 40px;
        color: #FFFFFF;
        padding: 0 20px;
        background-color: #5170FF;
        position: relative;

        .downlaod-vesion-pack {
          position: absolute;
          right: 20px;
          top: 7px;
        }
      }

      .compile-execute-init {
        background-color: #5170FF;
      }

      .compile-execute-error {
        background-color: #F95F5B;
      }

      .compile-execute-success {
        background-color: #3DCCA6;
      }

      .compile-execute-stop {
        background-color: #293040;
      }

      .compile-execute-content {
        .compile-execute-content-l {
          float: left;
          width: 20%;

          .execute-data-header {
            height: 40px;
            line-height: 40px;
            width: 100%;
            border-bottom: 1px solid #cacfd8;

            /* box-sizing: border-box; */
            .data-key-header {
              height: 100%;
              width: 48%;
              border-right: 1px dotted #ccc;
              display: inline-block;
              text-align: center;
            }

            .data-val-header {
              height: 100%;
              width: 48%;
              display: inline-block;
              text-align: center;
            }
          }

          .execute-data {
            height: 40px;
            line-height: 40px;
            width: 100%;

            .data-key {
              height: 100%;
              width: 48%;
              display: inline-block;
              text-align: center;
            }

            .data-val {
              height: 100%;
              width: 48%;
              display: inline-block;
              text-align: center;
            }
          }
        }

        .compile-excute-content-r {
          float: left;
          width: 80%;

          .box-card-body-body_right {
            display: inline-block;
            width: 100%;
            height: 500px;
            overflow: auto;
            background: black;
            border-left: 0;
            color: aliceblue;
            word-wrap: break-word;
            word-break: break-word;

            p {
              line-height: 18px;
              margin-left: 10px;
              margin-right: 10px;
            }
          }

        }
      }
    }
  }
</style>
