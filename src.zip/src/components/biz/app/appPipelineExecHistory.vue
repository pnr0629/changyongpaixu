<template>
  <div id="appPipelineHistoryList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
              <div class="navArea mb10" style="display: inline-block">
                      <span style="font-size: 16px;font-weight: 600;">历史执行记录</span>
                  <span class="c-blue cp" @click="goToPipelineList()">&lt;&lt;返回</span>
              </div>

              <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">

                <!-- todo 这里要增加一个返回的导航 -->
                <div class="table-box-top-bs">
                  <el-table :data="pipelineHistoryListData.list" style="width:100%;height:100%;overflow:auto;">
                    <el-table-column prop="pipelineName" label="流水线名称" min-width="120">
                    </el-table-column>

                    <el-table-column prop="pipelineStageRunningInfoBos" label="运行状态" min-width="120">
                        <template slot-scope="scope">
                          <span class="cp" v-for="(item,index) in scope.row.pipelineStageRunningInfoBos" :key="item.id"
                                @click="showVersionPipeline(scope.row.workflowId)">
                            <i class="iconfont" :class="getClassByRunningStatus(item.stageRunningStatus)" :title="item.name"></i>
                            <i class="iconfont icon-more" v-if="scope.row.pipelineStageRunningInfoBos.length-1 != index"></i>
                          </span>
                        </template>
                    </el-table-column>

                    <el-table-column label="操作人" min-width="120">
                      <template slot-scope="scope">
                        {{getTrigger(scope.row)}}
                      </template>
                    </el-table-column>

                    <el-table-column label="触发机制" min-width="120">
                      <template slot-scope="scope">
                        {{getTriggerMode(scope.row)}}
                      </template>
                    </el-table-column>

                    <el-table-column label="开始时间" prop="startTime" min-width="120">
                    </el-table-column>

                    <el-table-column label="结束时间" min-width="120">
                      <template slot-scope="scope">
                        {{getWorkFlowEndTime(scope.row)}}
                      </template>
                    </el-table-column>
                  </el-table>
                </div>

                <div class="table_b_f_b">
                  <el-pagination
                    class="fr"
                    style="margin-top: 9px;"
                    @size-change="handlePipelineHistoryListSizeChange"
                    @current-change="handlePipelineHistoryListPageChange"
                    :current-page="pipelineHistoryListData.pageNum"
                    :page-sizes="[10, 20, 30]"
                    :page-size="pipelineHistoryListData.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="pipelineHistoryListData.total">
                  </el-pagination>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
    <app-version-pipeline ref="appVersionPipeline"></app-version-pipeline>
  </div>
</template>

<script>
  import AppVersionPipeline from '@/components/biz/app/appVersionPipeline'

  export default {
    name: "appPipelineHistoryList",
    data() {
      return {
        WORKFLOW_TASK_STATUS: GLOBAL_CONST.WORKFLOW_TASK_STATUS,
        table_loading: false,
        pipelineHistoryListData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        bizId: '',
        appId: '',
        pipelineUuid: '',
      };
    },

    mounted() {
      let urlParams = this.getUrlParams();
      this.bizId = urlParams.bizId;
      this.appId = urlParams.appId;
      this.pipelineUuid = urlParams.uuid;
      this.renderTable();
    },

    methods: {
      getWorkFlowEndTime(row) {
        if (row && row.workflowStatus &&
          (row.workflowStatus == this.WORKFLOW_TASK_STATUS.FAILURE || row.workflowStatus == this.WORKFLOW_TASK_STATUS.SUCCESS)) {
          return row.endTime;
        }
        return "";
      },

      getTrigger(row) {
        if (row && (row.triggerUser || row.triggerUserName)) {
          return row.triggerUserName + '(' + row.triggerUser + ')';
        }
        return "";
      },

      getTriggerMode(row){
        if (row && row.triggerType){
          return GLOBAL_CONST.PIPELINE_TRIGGER_TYPE_MAP[row.triggerType];
        }
        return "";
      },


      handlePipelineHistoryListSizeChange(newPageSize) {
        this.pipelineHistoryListData.pageSize = newPageSize;
        this.renderTable();
      },

      handlePipelineHistoryListPageChange(newPageNum) {
        this.pipelineHistoryListData.pageNum = newPageNum;
        this.renderTable();
      },

      renderTable() {
        this.table_loading = true;
        let params = {
          uuid: this.pipelineUuid,
          pageNum: this.pipelineHistoryListData.pageNum,
          pageSize: this.pipelineHistoryListData.pageSize,
        };

        $http.get($http.api.pipeline.historyList, params).then(response => {
          this.pipelineHistoryListData = response.data;
          this.table_loading = false;
        });
      },

      goToPipelineList(row) {
        this.goToPage(this, 'appPipelineList', {bizId : this.bizId, appId : this.appId});
      },

      getClassByRunningStatus(status) {
        switch (status) {
          case GLOBAL_CONST.STAGE_STATUS.NOT_RUNNING:
            return "icon-status-init-l";
          case GLOBAL_CONST.STAGE_STATUS.WAIT:
            return "icon-status-waiting-l";
          case GLOBAL_CONST.STAGE_STATUS.RUNNING:
            return "icon-status-running-l";
          case GLOBAL_CONST.STAGE_STATUS.SUCCESS:
            return "icon-status-success-l";
          case GLOBAL_CONST.STAGE_STATUS.FAILURE:
            return "icon-status-fail-l";
        }
      },

      showVersionPipeline(workflowId) {
        //第三个参数true，表示从流水线执行历史记录页面跳转到流水线执行详情页面
        this.$refs.appVersionPipeline.showVersionPipeline(workflowId, this.appId, true);
      },

    },

    components: {
      AppVersionPipeline
    }
  };
</script>
