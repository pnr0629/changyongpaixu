<template>
  <div id="compileTaskList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar" style="border-bottom:2px solid #d6d9e0">
        <h3 class="headername">构建任务</h3>
      </div>
      <div class="white-box table-outer-box" style="height:auto;">
        <div class="p10" v-loading="table_loading" element-loading-text="拼命加载中">
          <div class="table-box-top">
            <el-table :data="tableList.rows" style="width: 100%;height: 100%;overflow:auto;">
              <el-table-column type="index" label="序号" width="50" align="center">
              </el-table-column>
              <el-table-column align="center" prop="date" label="名称" min-width="180">
              </el-table-column>
              <el-table-column align="center" prop="name" label="创建者" min-width="180">
              </el-table-column>
              <el-table-column align="center" prop="time" label="最后构建时间" min-width="180">
              </el-table-column>
              <el-table-column width="180" align="center" label="操作">
                <template slot-scope="scope">
                  <span class="c-blue cp" @click="editBtn()">编辑</span>
                  <span class="c-blue cp" @click="copyBtn()">复制</span>
                  <span class="c-blue cp" @click="deleteBtn()">删除</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="table_b_f_b">
            <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleSizeChange" @current-change="handleCurrentChange"
              :current-page="tableList.page" :page-sizes="[20, 50, 100]" :page-size="tableList.size" layout="total, sizes, prev, pager, next, jumper"
              :total="tableList.total">
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Distpicker from 'v-distpicker'

  export default {
    name: 'compileTaskList',
    data() {
      return {
        tableData: {
          total: 23,
          rows: [
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            }, ,
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            }, ,
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            }, ,
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            }, ,
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            }, ,
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            }, ,
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
            {
              date: '哥伦布系统',
              name: '吴晓峰',
              time: '2018-10-08-16:15'
            },
          ]
        },
        table_loading: false,
        tableList: {},
      }
    },

    mounted() {
      this.getPage({
        page: 1,
        size: 20,
      });
    },

    methods: {
      //获取数据列表
      getPage() {
        this.tableList = this.tableData;
      },

      //表格编辑
      editBtn() {
        this.$message({
          message: '功能开发中敬请期待...',
          type: 'success'
        });
      },

      //表格数据复制
      copyBtn() {
        this.$message({
          message: '功能开发中敬请期待...',
          type: 'success'
        });
      },
      //删除表格数据
      deleteBtn() {
        this.$message({
          message: '功能开发中敬请期待...',
          type: 'success'
        });
      },

      //分页
      handleSizeChange(val) {
        this.getPage({
          page: val,
          size: this.tableData.size,
        });
      },

      handleCurrentChange(val) {
        this.getPage({
          page: val,
          size: this.tableData.size,
        });
      }

    },
    components: {
      'v-distpicker': Distpicker,
    },

  }
</script>

<style lang="scss" scoped>
  .headername {
    padding-top: 10px;
    padding-left: 10px;
  }
</style>
