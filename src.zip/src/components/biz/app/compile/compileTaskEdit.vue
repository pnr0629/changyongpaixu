<template>
  <div id="comBuiTas" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box">
          <div class="table-box-top-by">
            <h4 style="margin-left:15px;">编译构建任务</h4>
            <hr class="hrheader">
            <div class="Columbus-CI">
              <div class="ColumbusParent">
                <span class="ColumbusHeader" @click="columbusBtn()">Columbus-CI</span>
              </div>
              <hr class="columbushr">
              <div id="bodyColumbus">
                <div v-for="(domain,index) in textinner" :key="index" class="active">
                  <div class="acter">
                    <span class="activespant" v-if="index != 0">↓</span>
                  </div>
                  <div class="actcont" @click="clickBtn(domain.title)">
                    <span class="activespan">{{domain.title}}</span>
                    <span class="activespano el-icon-delete" @click="deleteBtn(domain.id)"></span>
                  </div>
                </div>
                <div id="addHtml" @click="addDomcument();">
                  <i class='el-icon-plus'></i>
                </div>
                <div id="operation">
                  <p>每个任务都有一个目录作为工作空间：</p>
                  <p class="ml20">1.工作空间会挂载到每个镜像，镜像内把内容放到工作空间，才不会丢失；</p>
                  <p class="ml20">2.需要使用路径的时候，都是相对于工作空间的路径；</p>
                </div>
              </div>
            </div>
            <div class="jichushezhi">
              <div class="stepOne" v-if="step == '0'">
                <div class="stepOne_a">
                  <span class="stepOne_b">基础设置</span>
                </div>
                <hr class="stepOne_c">
                <div class="bodystep">
                  <div style="color:cornflowerblue;margin-top:0px;margin-left:20px;margin-right:20px;padding-left:20px;">
                    tips:构建任务默认允许所有分支共享，默认分支是在单独触发流水线时启用
                  </div>
                  <div class="pr10 pl10 form">
                    <el-form :model="itemInfo" ref="itemInfo" label-width="100px">
                      <el-row :gutter="10" class="mt10">
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="任务名称" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-input placeholder="请输入内容" v-model="itemInfo.name" clearable></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="任务描述" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-input placeholder="请输入内容" type="textarea" :rows="4" v-model="itemInfo.name" clearable></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="源码仓库" label-width="100px" prop="name" :rules="[
                                                            { required: true, message: '不能为空' }
                                                        ]">
                            <el-select v-model="itemInfo.huanjing" placeholder="请选择" style="width:100%">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="默认分支" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-select v-model="itemInfo.huanjing" placeholder="请选择" style="width:100%">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-form>
                  </div>
                  <div class="floor">
                    <el-button @click="">取消</el-button>
                    <el-button type="primary" @click="">保存</el-button>
                    <el-button type="success" @click="">另存为模板</el-button>
                  </div>
                </div>
              </div>
              <!-- ============================================================================================= -->
              <div class="stepOne" v-if="step == '1'">
                <div class="stepOne_a">
                  <span class="stepOne_b">在Docker中执行shell命令</span>
                </div>
                <hr class="stepOne_c">
                <div class="bodystep">
                  <div class="pr10 pl10 form">
                    <el-form :model="itemInfo" ref="itemInfo" label-width="100px">
                      <el-row :gutter="10" class="mt10">
                        <el-col :span='8'>
                          <el-form-item class='mb15' label="环境选择" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-select v-model="itemInfo.huanjing" placeholder="请选择" style="width:100%">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="镜像类型" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-select v-model="itemInfo.huanjing" placeholder="请选择" style="width:50%">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                            <el-select v-model="itemInfo.huanjingtwo" placeholder="请选择" style="width:49%">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                        <el-col :span='24'>
                          <div class="npmtaobao"></div>
                        </el-col>
                      </el-row>
                    </el-form>
                  </div>
                  <div class="floor">
                    <el-button @click="">取消</el-button>
                    <el-button type="primary" @click="">保存</el-button>
                    <el-button type="success" @click="">另存为模板</el-button>
                  </div>
                </div>
              </div>
              <!-- ===================================================================================== -->
              <div class="stepOne" v-if="step == '2'">
                <div class="stepOne_a">
                  <span class="stepOne_b">使用Apache Maven构建Java项目</span>
                </div>
                <hr class="stepOne_c">
                <div class="bodystep">
                  <div class="pr10 pl10 form">
                    <el-form :model="itemInfo" ref="itemInfo" label-width="100px">
                      <el-row :gutter="10" class="mt10">
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="环境选择" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-select v-model="itemInfo.huanjing" placeholder="请选择" style="width:100%;">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="镜像类型" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-select v-model="itemInfo.huanjing" placeholder="请选择" style="width:50%;">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                            <el-select v-model="itemInfo.huanjingtwo" placeholder="请选择" style="width:49%;">
                              <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                              </el-option>
                            </el-select>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="mvn命令" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-input placeholder="请输入内容" v-model="itemInfo.name" clearable></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="目标文件路径" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-input placeholder="请输入内容" v-model="itemInfo.name" clearable></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='16'>
                          <el-form-item class='mb15' label="pom文件" label-width="100px" prop="name" :rules="[
                                                        { required: true, message: '不能为空' }
                                                    ]">
                            <el-input placeholder="请输入内容" v-model="itemInfo.name" clearable></el-input>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-form>
                  </div>
                  <div class="floor">
                    <el-button @click="">取消</el-button>
                    <el-button type="primary" @click="">保存</el-button>
                    <el-button type="success" @click="">另存为模板</el-button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>


    <el-dialog title="选择操作" :visible.sync="dialogVisible" class="el-dialog-880w agentperson"
      :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
            <el-input placeholder="请输入内容" v-model="search" class="input-with-select " style="width:400px">
              <el-button slot="append" icon="el-icon-search"></el-button>
            </el-input>
          <div class='headerdialog'>
            <div class="dialogcontent" v-for="item in toolList.rows" @click='submitObj(item)' :key="item.id">
              <span class="imgdialog">
                <i class="el-icon-message" v-if="item.id == '1'"></i>
                <i class="el-icon-location" v-if="item.id == '2'"></i>
                <i class="el-icon-loading" v-if="item.id == '3'"></i>
                <i class="el-icon-star-off" v-if="item.id == '4'"></i>
                <i class="el-icon-star-off" v-if="item.id == '5'"></i>
              </span>
              <span class='el-icon-check' v-if="item.pitchOn == true"></span>
              <div class="bigfont">{{item.title}}</div>
              <div class="smallfont">{{item.content}}</div>
            </div>
          </div>
          <div class="pagination">
            <el-pagination style="display:inline-block;float:right;" @size-change="handleSizeChange" @current-change="handleCurrentChange"
              :current-page="toolList.page" :page-size="5" layout="total, prev, pager, next" :total="toolList.total">
            </el-pagination>
          </div>
        </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="callOff">取消</el-button>
        <el-button type="primary" @click="submit">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  // import Distpicker from 'v-distpicker'
  export default {
    name: "comBuiTas",
    data() {
      return {
        dialogVisible: false,
        modaltobody: false,
        shadeBtn: false,
        search: "",
        toolList: {},
        textinner: [],
        objStep: {},
        listtool: {
          total: 30,
          rows: [
            {
              title: "Android构建",
              content: "安卓构建真的可以吗？",
              id: "1",
              pitchOn: false
            },
            {
              title: "Ant构建",
              content: "安卓构建真的可以吗？",
              id: "2",
              pitchOn: false
            },
            {
              title: "配置Maven仓库",
              content: "安卓构建真的可以吗？",
              id: "3",
              pitchOn: false
            },
            {
              title: "制作镜像不推送",
              content: "安卓构建真的可以吗？",
              id: "4",
              pitchOn: false
            },
            {
              title: "Cmake构建",
              content:
                "安卓构建真的可以吗安卓构建真的可以吗安卓构建真的可以吗安卓构建真的可以吗安卓构建真的可以吗安卓构建真的可以吗安卓构建真的可以吗？",
              id: "5",
              pitchOn: false,
            }
          ]
        },

        itemInfo: {},
        options: [
          {
            value: "1",
            label: "哥伦布"
          },
          {
            value: "2",
            label: "新大陆呢"
          }
        ],
        step: '0',
      };
    },

    mounted() {
      this.getPage({
        page: 1,
        size: 5
      });
    },

    methods: {
      //头部一级菜单切换控制侧边栏菜单
      handleSelect(val) {
        if (val === '3') {
          this.goToPage(this, 'deployNoteList');
        }
      },

      getPage() {
        this.toolList = this.listtool;
      },

      //基础设置页面切换
      columbusBtn() {
        this.step = '0';
      },

      //新增弹窗
      addDomcument() {
        this.dialogVisible = true;
      },

      //选择一项
      submitObj(val) {
        this.objStep = val;
        this.toolList.rows.forEach((r, index) => {
          if (r.id == val.id) {
            r.pitchOn = !r.pitchOn;
            if (r.pitchOn == false) {
              this.objStep = {};
            }
          } else {
            r.pitchOn = false;
          }
        });
      },

      //关闭弹窗
      handleClose() {
        this.objStep = {};
        this.toolList.rows.forEach((r, index) => {
          if (r.pitchOn == true) {
            r.pitchOn = false;
          }
        });
        this.dialogVisible = false;
      },

      //取消关闭弹窗
      callOff() {
        this.handleClose();
      },

      //点击确定关闭弹窗
      submit() {
        if (Object.keys(this.objStep).length == 0) {
          this.$message({
            message: "请选择一项！",
            type: "warning"
          });
        } else {
          if (this.textinner.length < 11) {
            if (this.textinner.length == 0) {
              this.textinner.push(this.objStep);
            } else if (this.textinner.length > 0) {
              var flag = false;
              this.textinner.forEach((i, index_i) => {
                if (i.id == this.objStep.id) {
                  flag = true;
                  this.$message({
                    message: "此项已经添加，不可重复添加...",
                    type: "warning"
                  });
                }
              });
              if (flag == false) {
                this.textinner.push(this.objStep);
              }
            }
          } else {
            this.$message({
              message: "已经达到上限，不可再增加...",
              type: "warning"
            });
          }
          this.handleClose();
        }
      },

      //删除新增的栏目
      deleteBtn(val) {
        this.$confirm("确定要删除吗？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          this.textinner.forEach((item, index) => {
            if (item.id == val) {
              this.textinner.splice(index, 1);
            }
          });
          if (this.textinner.length == 0) {
            this.step = '0';
          }
        }).catch(() => {
        });
      },

      //弹窗数据的分页
      handleSizeChange() {
        this.getPage({
          page: val,
          size: this.toolList.size
        });
      },
      handleCurrentChange() {
        this.getPage({
          page: val,
          size: this.toolList.size
        });
      },


      //点击新增流程图中的任意一个进行切换
      clickBtn(val) {
        if (val == 'Android构建') {
          this.step = '1';
        } else if (val == 'Ant构建') {
          this.step = '2';
        }
      }
    },
    components: {
      // 'v-distpicker':Distpicker,
    }
  };
</script>

<style lang="scss" scoped>
  .table-box {
    .table-box-top-by {
      height: calc(100% - 1px);
      height: -webkit-calc(100% - 0px);

      .hrheader {
        margin-bottom: 5px;
        border: 1px solid #606266;
      }

      .Columbus-CI {
        border: 1px solid #e2dbdb;
        width: calc(30% - 2px);
        height: calc(100% - 30px);
        display: inline-block;
        float: left;
        margin-right: 2px;

        .ColumbusParent {
          height: 50px;

          .ColumbusHeader {
            cursor: pointer;
            position: relative;
            font-size: 18px;
            left: 35%;
            top: 10px;
          }

          .ColumbusHeader:hover {
            color: #60a0ff;
          }
        }

        .columbushr {
          border: 1px solid #606266;
          margin-left: 20px;
          margin-right: 20px;
        }

        #bodyColumbus {
          width: 100%;
          height: calc(100% - 70px);
          // background:red;
          margin-top: 20px;
          display: inline-block;
          overflow: auto;
          overflow-x: hidden;

          #addHtml {
            height: 50px;
            width: calc(100% - 80px);
            margin-left: 40px;
            margin-right: 40px;
            margin-top: 40px;
            margin-bottom: 40px;
            border: 1px solid #606266;
            cursor: pointer;

            .el-icon-plus {
              font-size: 40px;
              float: left;
              margin-left: calc(50% - 20px);
              margin-top: 5px;
            }
          }

          #operation {
            height: 100px;
            width: calc(100% - 80px);
            margin-left: 40px;
            margin-right: 40px;
            margin-top: 40px;
            margin-bottom: 10px;
          }

          .active {
            margin-left: 40px;
            margin-right: 40px;
            height: 90px;
            width: calc(100% - 80px);

            .actcont {
              border: 1px solid rgb(19, 17, 17);
              height: 50px;
              cursor: pointer;

              .activespan {
                width: 160px;
                height: 25px;
                margin-left: 20px;
                margin-top: 8px;
                float: left;
                font-size: 20px;
              }

              .activespano {
                width: 30px;
                height: 30px;
                margin-right: 10px;
                margin-top: 10px;
                float: right;
                font-size: 30px;
                color: #f56c6c;
              }
            }

            .acter {
              height: 40px;

              .activespant {
                color: #a3a5a9;
                width: 20px;
                height: 40px;
                font-size: 40px;
                margin-left: 45%;
                margin-top: -11px;
                float: left;
              }
            }
          }
        }
      }

      .jichushezhi {
        border: 1px solid #e2dbdb;
        width: calc(70% - 4px);
        height: calc(100% - 30px);
        display: inline-block;
        float: right;
        margin-left: 2px;

        .stepOne {
          height: 100%;

          .stepOne_a {
            height: 50px;

            .stepOne_b {
              position: relative;
              font-size: 18px;
              left: 35%;
              top: 10px;
            }
          }

          .stepOne_c {
            border: 1px solid #606266;
            margin-left: 20px;
            margin-right: 20px;
          }

          .bodystep {
            width: 100%;
            height: calc(100% - 70px);
            margin-top: 8px;
            display: inline-block;
            overflow: auto;
            overflow-x: hidden;

            .form {
              .npmtaobao {
                background: #e0e0e0;
                width: 100%;
                min-height: 600px;
              }
            }

            .floor {
              height: 40px;
              float: right;
              margin-right: 38%;
              margin-top: 20px;
            }
          }
        }
      }
    }
  }

  .agentperson {
    .el-form-item {
      margin-bottom: 10px !important;
    }

    .el-dialog__footer {
      padding: 10px 15px 10px !important;
    }

    .el-dialog__header {
      height: 40px;
    }

    .headerdialog {
      width: 100%;
      height: calc(100% - 85px);
      margin-right: 20px;

      .dialogcontent {
        cursor: pointer;
        display: inline-block;
        float: left;
        width: 100%;
        height: 50px;
        background: #e4e7ed;
        border-radius: 5px;
        margin-top: 15px;

        .imgdialog {
          margin-left: 5px;
          margin-top: 5px;
          float: left;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          background: white;

          .el-icon-message {
            font-size: 20px;
            color: yellowgreen;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
          }

          .el-icon-star-off {
            font-size: 20px;
            color: peru;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
          }

          .el-icon-loading {
            font-size: 20px;
            color: palevioletred;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
          }

          .el-icon-location {
            font-size: 20px;
            color: burlywood;
            float: left;
            margin-left: 10px;
            margin-top: 10px;
          }
        }

        .el-icon-check {
          font-size: 50px;
          color: #67c23a;
          float: right;
          margin-right: 10px;
        }

        .bigfont {
          font-size: 16px;
          font-weight: 500;
          margin-left: 10px;
          margin-top: 2px;
          float: left;
          color: #303133;
        }

        .smallfont {
          width: 500px;
          padding-left: 10px;
          margin-top: 26px;
          color: #909399;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
      }

      .pagination {
        margin-top: 20px;

        .el-pagination {
          background: red;
          display: inline-block;
          margin-right: 10px;
          float: right;
        }
      }
    }
  }
</style>
