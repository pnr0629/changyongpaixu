<template>
  <div id="featureBranchIntegration" class="content-outer-box">
    <el-tabs v-model="activeName" @tab-click="activeTabChange">
      <el-tab-pane
        v-if="enableIntegratedDevTab===true"
        label="开发集成"
        name="integrated_dev" >
        <feature-branch-integration-details
          v-if="activeName==='integrated_dev'"
          integratedType="integrated_dev"
          @activeNameChange="activeNameChange">
        </feature-branch-integration-details>
      </el-tab-pane>

      <el-tab-pane label="测试集成" name="integrated_test">
        <feature-branch-integration-details
          v-if="activeName==='integrated_test'"
          integratedType="integrated_test"
          :defaultRenderWorkflowId="defaultRenderWorkflowId"
          @activeNameChange="activeNameChange">
        </feature-branch-integration-details>
      </el-tab-pane>
      <el-tab-pane label="待发布" name="wait_to_deploy">
        <feature-branch-wait2-deploy v-if="activeName==='wait_to_deploy'" @activeNameChange="activeNameChange"></feature-branch-wait2-deploy>
      </el-tab-pane>
    </el-tabs>
  </div>

</template>

<script>
  import featureBranchWait2Deploy from './featureBranchWait2Deploy'
  import featureBranchIntegrationDetails from './featureBranchIntegrationDetails'

  export default {
    name: "featureBranchIntegration",
    components: {
      featureBranchWait2Deploy,
      featureBranchIntegrationDetails,
    },
    data() {
      return {
        appSimpleInfo: {
          appIntegratedSettings:{}
        },
        bizId: +this.getUrlParams().bizId,
        appId: +this.getUrlParams().appId,
        enableIntegratedDevTab: true,
        activeName: '',
        defaultRenderWorkflowId: 0,
      };
    },

    mounted() {

    },

    created() {
      this.initAllTabs();
    },

    methods: {
      async initAllTabs() {
        await $http.get($http.api.app.simpleInfo).then(res => {
          if(res.status == 200){
            this.appSimpleInfo = res.data;
            if(this.appSimpleInfo.appIntegratedSettings.integratedDevEnabled != null
              && this.appSimpleInfo.appIntegratedSettings.integratedDevEnabled == false) {
              this.enableIntegratedDevTab = false;
            }
            //获取初始化激活的tab
            this.activeName = this.getDefaultActiveTabName();
          }
        }).catch((err) => {
          this.$message({
            message: err,
            type: 'error'
          });
        })
      },

      getDefaultActiveTabName() {
        let urlParams = this.getUrlParams();
        let defaultActiveTabName = urlParams['activeTab'];
        if(!defaultActiveTabName
          || !['integrated_dev', 'integrated_test', 'wait_to_deploy'].includes(defaultActiveTabName)) {
          return this.enableIntegratedDevTab ? "integrated_dev" : "integrated_test";
        }
        return defaultActiveTabName;
      },

      // 更新当前活跃 tab
      activeNameChange(name = 'integrated_dev', workflowId = 0) {
        this.defaultRenderWorkflowId = workflowId;
        if(!name || !['integrated_dev', 'integrated_test', 'wait_to_deploy'].includes(name)) {
          name = this.enableIntegratedDevTab ? "integrated_dev" : "integrated_test";
        }
        this.activeName = name;
        this.goToPage(this, 'featureBranchIntegration', { bizId: this.bizId, appId: this.appId, activeTab: this.activeName });
      },

      activeTabChange(data) {
        this.goToPage(this, 'featureBranchIntegration', { bizId: this.bizId, appId: this.appId, activeTab: data.name });
      }
    }
  };
</script>

<style lang="scss" scoped>
  #featureBranchIntegration {
    padding: 0 10px;
  }
</style>
