<template>
  <div>
    <div class="header-box">
      <span class="item-box" v-for="item in flows" :key="item.name">
        <i :class="item.icon + ' item-box-icon'"></i>
        <div class="item-box-title">{{item.name}}</div>
        <div class="box-card-arrow">{{item.direct}}</div>
      </span>
    </div>
    <div class="notice-text">
      点击左侧菜单“发布”，新建发布单，提交需要发布的应用<br/>
      没有显示“新建发布单”的按钮？<span class="c-blue cp" @click="goToDeployFlow()">查看发布流程</span>
    </div>
    <div class="table-box-bs mt10" v-loading="table_loading" element-loading-text="拼命加载中">
      <feature-branch-wait-deploy-table :bizId="bizId" :wait2DeployListData="wait2DeployListData" :fromDeployNote="false"
                                        @handleListSizeChange="handleListSizeChange" @handleListPageChange="handleListPageChange"
                                        @renderTable="renderTable"
      ></feature-branch-wait-deploy-table>
    </div>
  </div>
</template>
<script>
  import FeatureBranchWaitDeployTable from "@/components/commonComponents/FeatureBranchWaitDeployTable"
  export default {
    name: "featureBranchWait2Deploy",
    components: {
      FeatureBranchWaitDeployTable,
    },
    mixins: [],
    props: {},
    data() {
      return {
        table_loading: false,
        wait2DeployListData: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          list: []
        },
        bizId: +this.getUrlParams().bizId,
        appId: +this.getUrlParams().appId,
        flows: [
          { name: '提发布单', icon: 'el-icon-edit-outline',direct:'→'},
          { name: '发布', icon: 'el-icon-upload',direct:'→' },
          { name: '合并代码', icon: 'iconfont icon-mr',direct:'' }
        ],

      }
    },
    computed: {},
    watch: {},
    mounted() {
      this.renderTable();
    },
    methods: {

      goToDeployFlow() {
        this.goToPage(this, 'deployNoteFlow', { bizId: this.bizId});
      },

      renderTable() {
        this.table_loading = true;
        let params = {
          appId: this.appId,
          pageNum: this.wait2DeployListData.pageNum,
          pageSize: this.wait2DeployListData.pageSize,
        };

        $http.get($http.api.feature_branch.wait2DeployList, params).then(response => {
          this.wait2DeployListData = response.data;
          this.table_loading = false;
        });
      },

      handleListSizeChange(newPageSize) {
        this.wait2DeployListData.pageSize = newPageSize;
        this.renderTable();
      },

      handleListPageChange(newPageNum) {
        this.wait2DeployListData.pageNum = newPageNum;
        this.renderTable();
      },

    }
  }
</script>
<style lang="scss" scoped>
  .header-box {
    margin-bottom: 10px;

    .box-card-arrow {
      width: 80px;
      height: 100px;
      text-align: right;
      font-size: 26px;
      padding-bottom: 2px;
      position: relative;
      top: -59px;
      left: 60px;
    }

  }

  .item-box {
    display: inline-block;
    margin-right: 50px;
    margin-top: 20px;
    /*margin-bottom: 20px;*/
    width: 100px;
    height: 100px;
    background: #67C23A;
    border-radius: 10px;
    .item-box-icon {
      font-size: 50px;
      color: #fff;
      margin-left: 25px;
      margin-top: 10px;
      width: 50px;
      height: 50px;
      display: inline-block;
    }
    &:last-of-type{
      position: relative;
      top: -26px;
    }
    .iconfont {
      margin-top: 0;
    }

    .item-box-title {
      margin-top: 5px;
      text-align: center;
      font-size: 20px;
      color: #fff;
      padding: 0 10px 0 10px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    }
  }

  .notice-text {
    font-size: 13px;
    color: #888;
    line-height: 20px;
  }

</style>

