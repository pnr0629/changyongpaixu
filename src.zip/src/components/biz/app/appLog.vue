<template>
  <div id="appLog" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="table-box-top" style="height:100%;overflow:auto;overflow-x: hidden;">
        <el-tabs v-model="activeName" class="el-tabs-wai">
          <el-tab-pane label="发布日志" name="first">
            <div class="ser-box" style="height:100%">
              <div class="table-box-top server-box" style="height:100%;">
                <el-tabs v-model="activeName1" type="border-card" @tab-click="envTabClick()" style="height:100%;">
                  <el-tab-pane v-for="env in envList" :label="env.envName" :name="env.envValue" :key="env.envValue">
                    <div class="table-box">
                      <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                        <div class="table-box-top-bs">
                          <el-table :data="bulidingList_deploy_log.rows" style="width: 100%;height:100%;">
                            <el-table-column prop="build0" label="版本名称" min-width="220">
                            </el-table-column>
                            <el-table-column prop="build1" label="发布IP" min-width="80">
                            </el-table-column>
                            <el-table-column prop="build2" label="实例ID" min-width="80">
                            </el-table-column>
                            <el-table-column prop="build3" label="配置环境" min-width="120">
                            </el-table-column>
                            <el-table-column prop="build4" label="配置版本" min-width="60">
                            </el-table-column>
                            <el-table-column prop="build5" label="发布时间" min-width="180">
                            </el-table-column>
                            <el-table-column prop="build6" label="操作人员" min-width="180">
                            </el-table-column>
                            <el-table-column prop="build7" label="发布结果" width="200">
                            </el-table-column>
                          </el-table>
                        </div>
                        <div class="table_b_f_b">
                          <el-pagination
                            v-show="bulidingList_deploy_log.rows.length != 0"
                            class="fr mr10"
                            style="margin-top: 5px;"
                            @size-change="appDeployLoghandleSizeChange"
                            @current-change="appDeployLoghandleCurrentChange"
                            :current-page="bulidingList_deploy_log.pageNum"
                            :page-sizes="[15, 20, 30]" :page-size="bulidingList_deploy_log.pageSize"
                            layout="total, sizes, prev, pager, next, jumper"
                            :total="bulidingList_deploy_log.total">
                          </el-pagination>
                        </div>
                      </div>
                    </div>
                  </el-tab-pane>
                </el-tabs>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="操作日志" name="fourth">
            <div class="table-box">
              <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                <div class="table-box-top-bs">
                  <el-table :border="true"
                            :class="{'el-table-left-none':appLogList.rows.length == 0}"
                            :data="appLogList.rows" style="width:100%;height:100%;">
                    <el-table-column prop="build0" label="操作时间" min-width="50">
                    </el-table-column>
                    <el-table-column prop="build1" label="操作人员" min-width="100">
                    </el-table-column>
                    <el-table-column prop="build2" label="操作记录" min-width="260">
                    </el-table-column>
                  </el-table>
                </div>
                <div class="table_b_f_b">
                  <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="appLogHandleSizeChange"
                                 @current-change="appLogHandleCurrentChange" :current-page="appLogList.page"
                                 :page-sizes="[20, 50, 100]"
                                 :page-size="appLogList.size" layout="total, sizes, prev, pager, next, jumper"
                                 :total="appLogList.total">
                  </el-pagination>
                </div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </div>
  </div>
</template>

<script>
  // import Distpicker from 'v-distpicker'
  export default {
    name: "appLog",
    data() {
      return {
        showBtn: '0',
        envList: [{"envName": "开发环境", "envValue": "dev"}, {"envName": "测试环境", "envValue": "test"}, {
          "envName": "线上环境",
          "envValue": "online"
        }],
        table_loading: false,
        bulidingList_deploy_log: {
          rows: [],
          pageNum: 1,
          pageSize: 20,
          total: 0,
          env: 'dev'
        },
        appLogList: {
          total: 0,
          size: 20,
          page: 1,
          rows: []
        },
        bulidingList: {},
        options: [],
        activeName: 'first',
        deployInfo: {},
        activeName1: 'dev',
        cliList: [],
        cli_num_list: [],
        cliList_map: {},
        appId: ''
      };
    },

    mounted() {
      this.appId = this.getUrlAppId();
      this.getpage();
      this.getAppLog();
      this.getAppDeployLog();
    },

    methods: {

      appDeployLoghandleSizeChange(val) {
        this.bulidingList_deploy_log.pageSize = val;
        this.getAppDeployLog();
      },

      appDeployLoghandleCurrentChange(val) {
        this.bulidingList_deploy_log.pageNum = val;
        this.getAppDeployLog();
      },

      envTabClick() {
        this.bulidingList_deploy_log.env = this.activeName1;
        this.getAppDeployLog();
      },
      //表格合并单元格的方法
      objectSpanMethod({row, column, rowIndex, columnIndex}) {
        if (columnIndex === 1 || columnIndex === 2) {
          if (this.cli_num_list.indexOf(rowIndex) != -1) {
            return {
              rowspan: this.cliList_map[row.clId],
              colspan: 1
            };
          } else {
            return {
              rowspan: 0,
              colspan: 0
            };
          }
        }
      },


      appLogHandleSizeChange(val) {
        this.appLogList.size = val;
        this.getAppLog();
      },

      appLogHandleCurrentChange(val) {
        this.appLogList.page = val;
        this.getAppLog();
      },

      //级菜单切换控制路由切换
      handleSelect(val) {
        if (val === "1") {
          this.goToPage(this, 'appVersions', {appId: this.appId});
        } else if (val === "2") {
          this.goToPage(this, 'appPipeline', {appId: this.appId});
        } else if (val === "3") {
          this.goToPage(this, 'appDeployTaskList', {appId: this.appId});
        } else if (val === "4") {
          this.goToPage(this, 'appLog', {appId: this.appId});
        } else if (val === "5") {
          this.goToPage(this, 'appSettings', {appId: this.appId});
        }
      },


      //获取数据的方法
      getpage() {
      },

      //获取应用操作日志
      getAppLog() {
        $http.get($http.api.system_log.getAppLog, {
          appId: this.appId,
          pageNum: this.appLogList.page,
          pageSize: this.appLogList.size
        }).then((res) => {
          this.appLogList.total = res.data.total;
          this.appLogList.page = res.data.pageNum;
          this.appLogList.size = res.data.pageSize;
          this.appLogList.rows = [];
          res.data.list.forEach(item => {
            let temItem = {};
            temItem.build0 = item.opTime;
            temItem.build1 = item.userName + '(' + item.userId + ')';
            temItem.build2 = item.opDesc;
            this.appLogList.rows.push(temItem);
          })
        })
      },

      //获取应用发布日志
      getAppDeployLog() {
        $http.get($http.api.system_log.getAppDeployLog, {
          appId: this.appId,
          pageNum: this.bulidingList_deploy_log.pageNum,
          pageSize: this.bulidingList_deploy_log.pageSize,
          env: this.bulidingList_deploy_log.env
        }).then((res) => {
          this.bulidingList_deploy_log.pageNum = res.data.pageNum;
          this.bulidingList_deploy_log.pageSize = res.data.pageSize;
          this.bulidingList_deploy_log.total = res.data.total;
          this.bulidingList_deploy_log.rows = [];
          if (res.data.list) {
            res.data.list.forEach(item => {
              let temItem = {};
              temItem.build0 = item.versionName;
              temItem.build1 = item.ip;
              temItem.build2 = item.instanceId;
              temItem.build3 = item.confEnv;
              temItem.build4 = item.confVersion;
              temItem.build5 = item.opTime;
              temItem.build6 = item.userName + '(' + item.userId + ')';
              temItem.build7 = item.result === 1 ? "发布成功" : item.opDesc;
              this.bulidingList_deploy_log.rows.push(temItem);
            })
          }

        })
      }


    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .table-box-bs {
    box-sizing: border-box;
    background: #fff;
    height: calc(100% - 30px);

    .table-box-top-bs {
      width: 100%;
      height: calc(100% - 5px)
    }
  }


  .table-box {
    .server-box {
      .header-a {
        .zjlb {
          margin-left: 10px;
          margin-bottom: 5px;
          margin-right: 10px;
          display: inline-block;
        }

        .tjzj {
          width: 55px;
          height: 20px;
          margin-left: 10px;
          margin-bottom: 5px;
          display: inline-block;
          cursor: pointer;
        }

        .tjzj:hover {
          color: #409EFF;
          //  border: 1px solid #409EFF;
          //  box-shadow: 0 0 10px #409EFF;
        }
      }

      .el-tabs--top {
        border: 1px solid #e4e7ed;
      }

      .el-progress {
        width: 70%;
        float: left;
        margin-top: 4px;
      }

      .progressNum {
        width: 25%;
        float: right;
        text-align: left;
      }

    }
  }

  .pzheader {
    height: calc(7% - 4px);
    border-bottom: 1px solid #e4e7ed;
  }

  .pzhg {
    height: calc(20% - 10px);
    min-height: 143px;
    border: 1px solid #e4e7ed;
    margin-bottom: 10px;

    .el-form-item {
      margin-bottom: 0px !important;
    }

  }

  .pzhjxq {
    height: 73%;

    .pzhjxq-s {
      width: calc(33.2% - 0.8px);
      min-width: 516.1px;
      height: 100%;
      border: 1px solid #E8E8E8;
      display: inline-block;
      overflow: hidden;
      overflow: auto;

      .kf-cs-zs {
        height: 30px;
        background: #e4e7ed;
      }

      .pz-hj-bb {
        height: 50px;
        border-bottom: 1px solid #e4e7ed;
      }

      .content {
        height: calc(100% - 80px);
        background: #F8F8F8;
      }
    }
  }
</style>
