<template>
  <div v-loading="integrated_page_loading" element-loading-text="拼命加载中">
    <div class="header">
      <div class="header-btns">
        <el-button
          type="primary"
          @click="beginPipeLine()"
          :disabled="!pipelineInfo.pipelineId"
        >{{ifExecuteBtnVisiable(pipelineInfo.pipelineStageRunningInfoBos) ? "运行" : "重新运行"}}</el-button>
        <el-button
          plain
          type="primary"
          @click="editPipeline(pipelineInfo)"
          :disabled="!pipelineInfo.pipelineId"
        >编辑流水线</el-button>
        <el-button
          plain
          type="info"
          @click="showVerDescTypeSettingDialog()"
        >版本描述设置</el-button>
      </div>
    </div>

    <work-flow-stage ref="WorkFlowStage" @taskTransfer="this.updateWorkflowTaskInfo" @ALLTASKEND="afterTasksFinish" @initLog="()=>{this.$refs.logBox.init()}">
      <p class="integrated-info-title">集成分支信息</p>
      <!--当前集成生成release分支信息-->
      <div id="integratedReleaseBranch" class="integrated-release-branch-box">
        <!-- <h4>当前集成Release分支</h4> -->
        <div>
          <span>当前集成Release分支：</span>
          <span
            v-if="this.currentIntegratedRelease.releaseBranch"
          >{{this.currentIntegratedRelease.releaseBranch}}</span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span>Commit：</span>
          <span
            v-if="this.currentIntegratedRelease.latestCommitId"
          >{{this.currentIntegratedRelease.latestCommitId}}</span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <span
            v-if="!this.currentIntegratedRelease.integratedSuccess && this.currentIntegratedRelease.statusName!=''"
          >{{this.currentIntegratedRelease.statusName}}</span>
          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <el-button
            type="warning"
            @click="submitTest"
            v-if="currentIntegratedRelease.integratedSuccess && integratedType === 'integrated_dev'"
          >提交测试待集成</el-button>
          <el-button
            type="warning"
            @click="beginTestIntegrated"
            v-if="currentIntegratedRelease.integratedSuccess && integratedType === 'integrated_dev'"
          >提交测试当前集成</el-button>
          <template v-if="authFunction('FUNC_APP_RELEASE_BRANCH_PASS_TEST', 2, appId)">
            <el-button
              type="warning"
              @click="passTest"
              v-if="currentIntegratedRelease.integratedSuccess && integratedType === 'integrated_test'"
            >测试通过</el-button>
          </template>
          <template v-else-if="currentIntegratedRelease.integratedSuccess && integratedType === 'integrated_test'">
            <span class="c-red">只有具备应用测试人员身份才能“测试通过”Release版本</span>
          </template>
        </div>
      </div>
    </work-flow-stage>


    <!--当前集成分支-->
    <div
      id="currentIntegratedBranches"
      class="common-table-box"
      v-show="isBranchTask"
    >
      <div class="common-table-title">当前集成分支</div>
      <el-button
        type="primary"
        class="mb10"
        :disabled="currentIntegratedBranchList.list.length == 0"
        @click="beginExitIntegrated">
        退出集成
      </el-button>
      <div v-loading="current_integrated_branches_list_table_loading" element-loading-text="拼命加载中">
        <div>
          <el-table
            :data="currentIntegratedBranchList.list"
            @selection-change="handleIntegratingSelectionChange">
            <el-table-column type="selection" min-width="55"> </el-table-column>
            <el-table-column prop="featureBranch" label="分支名称" min-width="150">
              <template slot-scope="scope">
                <el-tooltip  v-if="scope.row.gitBranchDeleted" class="item" effect="dark" content="Git分支已被删除" placement="top-start">
                  <span class="c-red">{{scope.row.featureBranch}}</span>
                </el-tooltip>
                <a v-else :href="scope.row.gitBranchCommitsUrl" target="_blank" class="c-blue cp">
                  {{scope.row.featureBranch}}
                </a>
              </template>
            </el-table-column>
            <el-table-column label="当前commitId" min-width="100">
              <template slot-scope="scope">
                <span>{{scope.row.latestCommitId?scope.row.latestCommitId.substring(0,8):'-'}}</span>
                <el-button
                  v-if="scope.row.hasNewCommit"
                  type="danger"
                  size="mini"
                  style="padding: 3px 5px !important"
                  :disabled="showLatestCommitDiffBtnDisable"
                  @click="showLatestCommitDiff(scope.row)"
                >新提交</el-button>
              </template>
            </el-table-column>
            <el-table-column prop="changeReason" label="当前描述" min-width="250">
              <template slot-scope="scope">
                <span class="c-blue cp" @click="goToFeatureBranchDetailsPage(scope.row.changeId)">
                  {{scope.row.changeReason}}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="计划发布时间" width="160">
              <template slot-scope="scope">
                <span>{{scope.row.planReleaseTime?scope.row.planReleaseTime.substring(0, 10):'--'}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="createUserName" label="创建者" width="150">
              <template slot-scope="scope">
                <span>{{getFeatureBranchCreateUser(scope.row)}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="statusName" label="状态" min-width="100"></el-table-column>
            <el-table-column label="" width="180">
              <template slot-scope="scope">
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div>
          <el-pagination
            v-show="currentIntegratedBranchList.total>10"
            class="fr mr10"
            style="margin-top: 9px;"
            @size-change="handleCurrentIntegratedBranchListSizeChange"
            @current-change="handleCurrentIntegratedBranchListPageChange"
            :current-page="currentIntegratedBranchList.pageNum"
            :page-sizes="[10, 20, 30]"
            :page-size="currentIntegratedBranchList.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="currentIntegratedBranchList.total"
          ></el-pagination>
        </div>
      </div>
    </div>



    <el-dialog title="提示" :before-close="handleDiffDialogClose" :visible.sync="dialogDiffVisible">
      <div slot="title">
        <strong>特性分支：</strong>
        {{dialogDiffTile.featureBranch}} &nbsp;&nbsp;&nbsp;
        <strong>CommitId：</strong>
        {{dialogDiffTile.latestCommitId}}
      </div>

      <el-tabs v-model="editableActiveTab" type="card">
        <el-tab-pane
          :key="item.name"
          v-for="(item, index) in commitDifftableTabs"
          :label="item.title"
          :name="item.name"
        >
          <el-table :data="item.content" style="width: 100%">
            <el-table-column prop="displayFile" label="文件"></el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </el-dialog>

    <el-dialog
      title="版本描述设置"
      :visible.sync="verDescTypeSettingDialogVisible"
      width="30%"
      :before-close="handleVerDescTypeSettingDialogClose"
      :close-on-click-modal="false"
    >
      <el-form>
        <el-row type="flex" justify="center">
          <el-radio-group v-model="curIntegratedEnvVerDescType">
            <el-tooltip placement="bottom">
              <div slot="content">每次集成前用户都需要输入应用版本描述</div>
              <el-radio label="0" border style="margin-left:-40px">用户自定义输入</el-radio>
            </el-tooltip>

            <el-tooltip placement="bottom">
              <div slot="content">系统默认生成的应用版本描述为<br/>
                  哥伦布集成开发/集成测试自动生成版本<br/>
                  master -- commitId -- commitMsg <br/>
                  feature1 -- commitId -- commitMsg <br/>
                  feature2 -- commitId -- commitMsg <br/>
                  ... <br/>
                  featureN -- commitId -- commitMsg <br/>

              </div>
              <el-radio label="1" border style="margin-left:40px">系统默认生成</el-radio>
            </el-tooltip>
          </el-radio-group>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleVerDescTypeSettingDialogClose">取 消</el-button>
        <el-button type="primary" @click="saveVerDescTypeSetting" :disabled="verDescTypeSettingBtnDisabled">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog
      title="版本描述"
      :visible.sync="userDefinedVersionDescDialogVisible"
      width="30%"
      :before-close="handleVerDescDialogClose"
      :close-on-click-modal="false"
    >
      <el-form >
        <el-row type="flex" justify="center">
            <el-input
              type="textarea"
              v-model.trim="userDefinedVersionDesc"
              resize="vertical !important"
              placeholder="不超过500字，不填写则使用系统默认生成的版本描述">
            </el-input>
        </el-row>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="handleVerDescDialogClose">取 消</el-button>
        <el-button type="primary"
          @click="dispatchExecuteRequestWithUserDefinedVerDesc"
          :disabled="verDescConfirmBtnDisabled">
          确 定
        </el-button>
      </div>
    </el-dialog>

    <!--待集成分支-->
    <div
      id="waitIntegratedBranches"
      class="common-table-box"
      v-show="isBranchTask"
    >
      <div class="common-table-title">待集成分支</div>
      <el-button
        type="primary"
        class="mb10"
        :disabled="waitIntegratedBranchList.list.length == 0"
        @click="beginIntegrated">
        提交集成
      </el-button>

      <div v-loading="wait_integrated_branches_list_table_loading" element-loading-text="拼命加载中">
        <div>
          <el-table
            :data="waitIntegratedBranchList.list"
            @selection-change="handleWaiIntegrateSelectionChange">
            <el-table-column type="selection" min-width="55"> </el-table-column>
            <el-table-column prop="featureBranch" label="分支名称" min-width="150">
              <template slot-scope="scope">
                <el-tooltip  v-if="scope.row.gitBranchDeleted" class="item" effect="dark" content="Git分支已被删除" placement="top-start">
                  <span class="c-red">{{scope.row.featureBranch}}</span>
                </el-tooltip>
                <a v-else :href="scope.row.gitBranchCommitsUrl" target="_blank" class="c-blue cp">
                  {{scope.row.featureBranch}}
                </a>
              </template>
            </el-table-column>
            <el-table-column label="当前commitId" min-width="100">
              <template
                slot-scope="scope"
              >{{scope.row.latestCommitId?scope.row.latestCommitId.substring(0,8):'-'}}</template>
            </el-table-column>
            <el-table-column prop="changeReason" label="当前描述" min-width="250">
              <template slot-scope="scope">
                <span class="c-blue cp" @click="goToFeatureBranchDetailsPage(scope.row.changeId)">
                  {{scope.row.changeReason}}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="计划发布时间" width="160">
              <template slot-scope="scope">
                <span>{{scope.row.planReleaseTime?scope.row.planReleaseTime.substring(0, 10):'--'}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="createUserName" label="创建者" width="150">
              <template slot-scope="scope">
                <span>{{getFeatureBranchCreateUser(scope.row)}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="statusName" label="状态" min-width="100"></el-table-column>
            <el-table-column label="操作" width="180">
              <template slot-scope="scope">
                <span class="c-blue cp" @click="turnBack2Developing(scope.row)">退回开发中</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div>
          <el-pagination
            v-show="waitIntegratedBranchList.total>10"
            class="fr mr10"
            style="margin-top: 9px;"
            @size-change="handleWaitIntegratedBranchListSizeChange"
            @current-change="handleWaitIntegratedBranchListPageChange"
            :current-page="waitIntegratedBranchList.pageNum"
            :page-sizes="[10, 20, 30]"
            :page-size="waitIntegratedBranchList.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="waitIntegratedBranchList.total"
          ></el-pagination>
        </div>
      </div>
    </div>
    <div class="common-table-box" v-show="showLogBox">
      <div class="common-table-title">日志详情</div>
      <log-box
        :workflowTaskId="workflowTaskId"
        :currentSelectedWorkflow="currentSelectedWorkflow"
        ref="logBox"
      ></log-box>
    </div>
    <div class="common-table-box">
      <el-row type="flex" justify="space-between">
        <el-col>
          <div class="common-table-title">版本列表</div>
        </el-col>

        <el-col>
            <el-row type="flex" justify="end">
              <el-button type="primary" class="mb10" @click="getVersionList()">刷新</el-button>
              <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2, appId)"
                         @click="passEnvClick('dev')" class="mb10">开发环境
              </el-button>
              <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2, appId)"
                         @click="passEnvClick('test')" class="mb10">测试环境
              </el-button>
            </el-row>
          </el-col>
      </el-row>
      <!--版本列表-->
      <div id="appVersions">
        <div v-loading="version_list_table_loading" element-loading-text="拼命加载中">
          <div>
            <el-table :border="true" :data="appVersionList.list">
              <el-table-column prop="versionName" label="版本名称" min-width="150">
                <template slot-scope="scope">
                    <span class="cp c-blue" @click="showVersionPipelineVersion(scope.row.pipelineWorkflowId)">{{scope.row.versionName}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="sourceBranch" label="分支名称" min-width="180">
                <template slot-scope="scope">
                  <el-popover
                     placement="right"
                     :title="scope.row.sourceBranch + ' 分支组合'"
                     width="550"
                     trigger="hover"
                     :open-delay="200">
                     <el-table :data="JSON.parse(scope.row.extendData)">
                        <el-table-column property="branch" label="分支名称" width="400"></el-table-column>
                        <el-table-column property="integratedCommitId" label="CommitId">
                          <template slot-scope="scope2">
                            {{scope2.row.integratedCommitId ? scope2.row.integratedCommitId.substring(0,8) : ""}}
                          </template>>
                        </el-table-column>
                      </el-table>
                    <span slot="reference" class="c-blue cursor-default">{{scope.row.sourceBranch}}</span>
                  </el-popover>
                </template>
              </el-table-column>
              <el-table-column label="commitId" min-width="80">
                <template
                  slot-scope="scope"
                >{{scope.row.commitId?scope.row.commitId.substring(0,8):'-'}}</template>
              </el-table-column>

              <el-table-column label="版本类型"
                               prop="versionType"
                               width="100"
                               v-if="integratedEnv==='test'"
              >
                <template slot-scope="scope">
                  <span>{{versionType_china[scope.row.versionType]}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="createUserName" label="创建者" width="120"></el-table-column>
              <el-table-column label="创建时间" width="180">
                <template slot-scope="scope">
                  <span>{{scope.row.createTime?scope.row.createTime:'-------'}}</span>
                </template>
              </el-table-column>
              <el-table-column label="打包状态" width="120">
                <template slot-scope="scope">
                  <span
                    :class="{'c-red':scope.row.pkgStatus == 3}"
                  >{{PKG_STATUS[scope.row.pkgStatus]}}</span>
                </template>
              </el-table-column>
              <el-table-column label="上传详情" width="120">
                <template slot-scope="scope">
                  <span class="c-blue cp" @click="checkUpload(scope.row.versionId, 0)">查看</span>
                  <span
                    class="c-blue cp"
                    v-if="scope.row.pkgStatus == 4"
                    @click="downloadVersion(scope.row)"
                  >下载</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div>
            <el-pagination
              v-show="appVersionList.list.length!=0"
              class="fr mr10"
              style="margin-top: 9px;"
              @size-change="handleVersionListSizeChange"
              @current-change="handleVersionListPageChange"
              :current-page="appVersionList.pageNum"
              :page-sizes="[10, 20, 30]"
              :page-size="appVersionList.pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="appVersionList.total"
            ></el-pagination>
          </div>
        </div>
      </div>
    </div>
    <!-- 仓库包上传详情 -->
    <package-upload-info :dialogVisible="uploadDialogVisible" :dialogClose="handleCloseUpload" ref="PackageUploadInfo"></package-upload-info>
    <app-version-pipeline ref="appVersionPipelineVersion" @refreshVersion="getVersionList()"></app-version-pipeline>


    <el-dialog title='构建参数' :visible.sync="variablesDialogShow" class="el-dialog-400w"
    >
      <div class="form-iterm-box">
        <el-form  label-width="100px" @submit.native.prevent>
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
            <el-col :span='24'
                    v-if="variablesDialogShow && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:200px;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>

          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseVariablesDialog">取消</el-button>
        <el-button type="primary" @click="dispatchIntegrationRequestWithParams">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>
<script>
import AppVersionPipeline from '@/components/biz/app/appVersionPipeline'
import LogBox from '@/components/commonComponents/LogBox'
import WorkFlowStage from '@/components/commonComponents/WorkFlowStage'
import PackageUploadInfo from '@/components/commonComponents/PackageUploadInfo'
import featureBranchMixin from './featureBranchMixin.js'

export default {
  name: "featureBranchIntegrationDetails",
  components: {
    AppVersionPipeline,
    LogBox,
    WorkFlowStage,
    PackageUploadInfo
  },
  props: {
    integratedType: {
      type: [String],
      required: true,
      desc: '集成类型，integrated_dev、integrated_test'
    },
    defaultRenderWorkflowId: {
      type: [Number],
      required: false,
      default: 0,
      desc: '默认自动渲染的workflowId'
    }
  },
  mixins: [featureBranchMixin],
  data() {
    return {
      PKG_STATUS: GLOBAL_CONST.PKG_STATUS,
      STAGE_STATUS: GLOBAL_CONST.STAGE_STATUS,

      activeNames: ['integratedPipeline'],
      tabActive: 'logDetail', // 底部 tab 活跃
      bizId: +this.getUrlParams().bizId,
      appId: +this.getUrlParams().appId,
      appSimpleInfo: {
        appIntegratedSettings:{}
      },
      integratedDevVerdescType: null,
      integratedTestVerdescType: null,

      developMode: 1,
      integratedEnv: "",

      integrated_page_loading: false,
      pipeline_list_table_loading: false,
      version_list_table_loading: false,
      current_integrated_branches_list_table_loading: false,
      wait_integrated_branches_list_table_loading: false,

      verDescTypeSettingDialogVisible: false,
      verDescTypeSettingBtnDisabled: false,


      //流水线列表使用数据
      pipelineInfo: {},
      pipelineListData: {
        pageNum: 1,
        pageSize: 10,
        total: 0,
        list: []
      },

      //当前集成生成的Release信息使用数据
      currentIntegratedRelease: {
        releaseBranch: "",
        latestCommitId: "",
        hasNewCommit: false,
        statusName: "",
        integratedSuccess: false
      },
      dialogDiffVisible: false,
      dialogDiffTile: {
        featureBranch: "",
        latestCommitId: "",
      },

      editableActiveTab: '',
      commitDifftableTabs: [],

      //当前集成分支区域使用数据
      currentIntegratedBranchList: {
        pageNum: 1,
        pageSize: 10,
        total: 0,
        list: []
      },

      //待集成分支区域使用数据
      waitIntegratedBranchList: {
        pageNum: 1,
        pageSize: 10,
        total: 0,
        list: []
      },

      //版本列表使用数据
      appVersionList: {
        pageNum: 1,
        pageSize: 10,
        total: 0,
        list: []
      },
      versionType_china: {
        '0': '开发版本',
        '1': '测试版本',
        '2': '正式版本'
      },

      uploadDialogVisible: false,
      testUpload_list: [],
      imageUploadHarbor: false,
      imageUploadDetail: [],
      currentVersionId: -1, // 当前版本 id，用于获取当前集成分支信息时，-1表示获取最新版本的
      integratingMultipleSelection: [],
      waitIntegrateMultipleSelection: [],
      showLatestCommitDiffBtnDisable: false,

      userDefinedVersionDescDialogVisible: false,
      userDefinedVersionDesc:"",
      triggerType:"",  //触发集成流水线,
      callFunc:"",
      verDescConfirmBtnDisabled: false,

      //构建参数相关变量
      buildTaskVaiableList:[],
      //控制构造参数选择框显示
      variablesDialogShow: false,
    }
  },
  computed: {
    // 是否是分支管理器 task，数据从 mixin 中获取
    isBranchTask() {
      return this.currentSelectedWorkflow.type && this.currentSelectedWorkflow.type === 'BRANCH_MANAGE';
    },

    curIntegratedEnvVerDescType: {
      get() {
        if(this.integratedEnv == "dev") {
          return this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType + "";
        } else if(this.integratedEnv == "test") {
          return this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType + "";
        }
        return "1";
      },

      set(value) {
        if(this.integratedEnv == "dev") {
          this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType = value;
        } else if(this.integratedEnv == "test") {
          this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType = value;
        }
      }
    }
  },

  watch: {
    // 当每次任务切换的时候，去更新对应的分支信息
    workflowTaskId() {
      this.getCurrentIntegratedRelease();
      // 如果是分支管理器，则更新当前集成分支、待集成分支 table
      if (this.currentSelectedWorkflow.type && this.currentSelectedWorkflow.type === 'BRANCH_MANAGE') {
        this.getWaitIntegratedBranchList();
        this.getCurrentIntegratedBranchList();
      }
    }
  },

  mounted() {
    this.initIntegratedEnv();
    this.renderPipeline();
    this.getVersionList();
    this.getWaitIntegratedBranchList();
    this.getCurrentIntegratedBranchList();
    this.getCurrentIntegratedRelease();
    this.getAppSimpleInfo();
    this.autoRenderDefaultWorkFlow();

  },
  methods: {

    //页面根据参数可自动渲染流水线执行效果
    autoRenderDefaultWorkFlow() {
      // console.log(this.defaultRenderWorkflowId);
      if (this.defaultRenderWorkflowId && this.defaultRenderWorkflowId > 0) {
        this.$nextTick(() => {
          this.renderPipeline(this.defaultRenderWorkflowId);
        })
      }
    },

    // 当任务结束时，需要更新页面一些状态
    afterTasksFinish() {
      this.getVersionList();
      this.getWaitIntegratedBranchList();
      this.getCurrentIntegratedBranchList();
      this.getCurrentIntegratedRelease();
    },

    refreshPage() {
      this.renderPipeline();
      this.getVersionList();
      this.getWaitIntegratedBranchList();
      this.getCurrentIntegratedBranchList();
      this.getCurrentIntegratedRelease();
    },

    getAppSimpleInfo() {
      $http.get($http.api.app.simpleInfo).then(res => {
        if(res.status == 200){
          this.appSimpleInfo = res.data;
          this.integratedDevVerdescType = this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType;
          this.integratedTestVerdescType = this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType;
        }
      }).catch((err) => {
        console.log(err);
      })
    },

    initIntegratedEnv() {
      if ("integrated_dev" == this.integratedType) {
        this.integratedEnv = "dev";
      } else if ("integrated_test" == this.integratedType) {
        this.integratedEnv = "test";
      } else {
        this.integratedEnv = "unknown";
      }
    },

    goToPipelineDetail(row) {
      this.goToPage(this, 'appPipeline',
        { bizId: this.bizId, appId: this.appId, operation: 'view', pipelineId: row.pipelineId });
    },

    showVersionPipelineVersion(latestWorkflowId) {
      this.$refs.appVersionPipelineVersion.showVersionPipeline(latestWorkflowId, this.appId);
    },

    showVersionPipelinePipeline(latestWorkflowId, pipelineId) {
      // 打开 dialog
      // this.$refs.appVersionPipelinePipeline.showVersionPipeline(latestWorkflowId, this.appId);
      // 本页运行
      this.$refs.WorkFlowStage.init(latestWorkflowId, pipelineId);
      this.currentVersionId = -1;
    },

    getCreateUser(row) {
      if (row && (row.createUserId || row.createUserName)) {
        return row.createUserName + '(' + row.createUserId + ')';
      }
      return "";
    },

    renderPipeline(executeWorkflowId) {
      this.pipeline_list_table_loading = true;
      let params = {
        appId: this.appId,
        integratedEnv: this.integratedEnv,
      };

      $http.get($http.api.feature_branch.integratedPipelineQuery, params).then(response => {
        this.pipelineListData = response.data;
        this.pipelineInfo = response.data.list.length > 0 ? response.data.list[0] : {}

        if (executeWorkflowId) {
          this.$nextTick(() => {
            this.showVersionPipelinePipeline(executeWorkflowId)
          })
        } else {
          if (this.pipelineInfo.pipelineId) {
            this.$nextTick(() => {
              this.showVersionPipelinePipeline(0, this.pipelineInfo.pipelineId)
            })
          }
        }
        this.pipeline_list_table_loading = false;
      });
    },

    ifExecuteBtnVisiable(pipelineStageRunningInfoBos) {
      let result = false;
      if (!pipelineStageRunningInfoBos || pipelineStageRunningInfoBos.length == 0) {
        result = true;
      } else {
        let lastPipelineStageRunningInfo = pipelineStageRunningInfoBos[pipelineStageRunningInfoBos.length - 1];
        if (lastPipelineStageRunningInfo.stageRunningStatus == 'SUCCESS') {
          result = true;
        }
      }

      return result;
    },

    getBuildTaskVarsJson() {
      let varsSelectedObj = {};
      this.buildTaskVaiableList.forEach(item => {
        varsSelectedObj[item.variable] = item.currentOption;
      });
      return varsSelectedObj;
    },
    queryVariableSearch(queryString, cb , variable) {
      var restaurants = [];
      this.buildTaskVaiableList.forEach(item => {
        if(item.variable == variable){
          restaurants = item.options;
        }
      });
      var results = [];
      restaurants.forEach((item)=>{
        if(queryString == null || queryString == "" || item.toLowerCase().indexOf(queryString) == 0){
          results.push({value:item})
        }
      });
      cb(results);
    },
    handleOptionsSelect(selectData , currentOption){
      currentOption = selectData;
    },

    handleCloseVariablesDialog(){
      this.variablesDialogShow = false;
    },

    hasVariableBlank() {
      var hasVariableBlank = false;
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length > 0){
        this.buildTaskVaiableList.forEach(item=>{
          if(item.currentOption == null || item.currentOption == ""){
            hasVariableBlank = true;
          }
        });
      }
      return hasVariableBlank;
    },

    beginPipeLine() {
      $http.get($http.api.pipeline.buildTaskVars, { pipelineId: this.pipelineInfo.pipelineId }).then(res => {
        this.buildTaskVaiableList = res.data;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
          this.variablesDialogShow = true;
          this.callFunc = "executePipeline";
        }else{
          this.variablesDialogShow = false;
          this.executePipeline();
        }
      })
    },

    executePipeline() {
      this.triggerType = "execute";

      if (this.currentIntegratedBranchList.list.length == 0) {
        this.$message.error("当前集成分支列表为空，请刷新页面或将待集成分支提交集成后再操作")
        return;
      }

      if(this.integratedEnv == "dev") {
        if(this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType == 0) {
          //show version desc dialog
          this.showVerDescDialog();
          this.handleCloseVariablesDialog();
          return;
        }
      } else if(this.integratedEnv == "test") {
        if(this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType == 0) {
          //show version desc dialog
          this.showVerDescDialog();
          this.handleCloseVariablesDialog();
          return;
        }
      }
      this.issueExecutePipelineReqeust();
      this.handleCloseVariablesDialog();
    },

    issueExecutePipelineReqeust(versionDesc) {
      let formData = new FormData();
      formData.set("pipelineId", this.pipelineInfo.pipelineId);
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
        let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
      }
      if(versionDesc) {
        formData.set("versionDesc", versionDesc);
      }
      $http.post($http.api.feature_branch.triggerIntegrated, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "集成指令已下发"
          });

          let executeWorkflowId = response.data;
          this.renderPipeline(executeWorkflowId);
        }
      });
      this.handleCloseVariablesDialog();
    },

    editPipeline(row) {
      this.goToPage(this, 'appPipeline',
        { bizId: this.bizId, appId: this.appId, operation: 'edit', pipelineId: row.pipelineId });
    },

    showVerDescTypeSettingDialog() {
      this.verDescTypeSettingDialogVisible = true;
    },

    handleVerDescTypeSettingDialogClose() {
      this.verDescTypeSettingDialogVisible = false;
      if(this.integratedEnv == "dev") {
        if(this.integratedDevVerdescType != this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType) {
          this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType = this.integratedDevVerdescType
        }
      } else if(this.integratedEnv == "test") {
        if(this.integratedTestVerdescType != this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType) {
          this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType = this.integratedTestVerdescType
        }
      }
    },

    saveVerDescTypeSetting() {
      this.verDescTypeSettingBtnDisabled = true;
      let versionDescType = null;
      if(this.integratedEnv == "dev") {
        versionDescType = this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType;
      } else if(this.integratedEnv == "test") {
        versionDescType = this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType;
      }

      let formData = new FormData();
      formData.set("appId", this.appId);
      formData.set("integratedEnv", this.integratedEnv);
      formData.set("versionDescType", versionDescType);
      $http.post($http.api.feature_branch.switchVerionDescType, formData).then(response => {
        if(response.status == 200) {
          this.$message({
            message: "修改应用描述设置成功",
            type: "success",
          });
          this.getAppSimpleInfo();
          this.verDescTypeSettingDialogVisible = false;
        }
        this.verDescTypeSettingBtnDisabled = false;
      }).catch((_) => {
        this.verDescTypeSettingBtnDisabled = false;
      });

    },

    //查看当前集成区域特性分支最新提交的内容
    showLatestCommitDiff(row) {
      this.showLatestCommitDiffBtnDisable = true;
      this.commitDifftableTabs = [];
      $http.get($http.api.feature_branch.commitDiff, { id: row.changeId, commitId: row.latestCommitId })
        .then(response => {
          this.showLatestCommitDiffBtnDisable = false;
          if (response.status == 200) {
            let firstTabAssigned = false;
            for (var key in response.data) {
              if (!firstTabAssigned) {
                this.editableActiveTab = key;
                firstTabAssigned = true;
              }
              let tabData = { title: key, name: key, content: response.data[key] };
              this.commitDifftableTabs.push(tabData);
            }
          }

          this.dialogDiffTile.featureBranch = row.featureBranch;
          this.dialogDiffTile.latestCommitId = row.latestCommitId ? row.latestCommitId.substring(0, 8) : "-";
          this.dialogDiffVisible = true;
        }).catch((e) => {
          console.log(e);
          this.showLatestCommitDiffBtnDisable = false;
        });
    },

    handleDiffDialogClose() {
      this.commitDifftableTabs = [];
      this.dialogDiffTile.featureBranch = "";
      this.dialogDiffTile.latestCommitId = "";
      this.dialogDiffVisible = false;
    },

    //提测分支，特性分支从开发集成流转到测试集成（提交测试待集成）
    submitTest() {
      let formData = new FormData();
      formData.set("appId", this.appId);
      $http.post($http.api.feature_branch.submitTest, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "提交测试待集成成功"
          });
          // this.refreshPage();
          // 提测成功后应当跳转到测试集成的tab页
          this.$emit('activeNameChange', 'integrated_test')
          // this.goToPage(this, "featureBranchIntegration", {bizId: this.bizId, appId: this.appId, activeTab: "integrated_test"});
        }
      });
    },

    //提测分支，特性分支从开发集成流转到测试集成（提交测试当前集成）
    submitTestIntegrated() {
      this.triggerType = "submitTestIntegrated";
      if(this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType == 0) {
        //show version desc dialog
        this.showVerDescDialog();
        return;
      }
      this.issueSubmitTestIntegratedRequest();
      this.handleCloseVariablesDialog();
    },

    issueSubmitTestIntegratedRequest(versionDesc) {
      this.integrated_page_loading = true;
      let formData = new FormData();
      formData.set("appId", this.appId);
      if(versionDesc) {
        formData.set("versionDesc", versionDesc);
      }
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
        let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
      }

      $http.post($http.api.feature_branch.submitTestIntegrated, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "提交测试当前集成成功"
          });
          // this.refreshPage();
          // 提测成功后应当跳转到测试集成的tab页
          this.$emit('activeNameChange', 'integrated_test', response.data)
          // this.goToPage(this, "featureBranchIntegration", {bizId: this.bizId, appId: this.appId, activeTab: "integrated_test"});
        }
        this.integrated_page_loading = false;
      });
    },

    //测试通过分支，流转到待发布阶段
    passTest() {
      let formData = new FormData();
      formData.set("appId", this.appId);
      $http.post($http.api.feature_branch.passTest, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "测试通过成功"
          });
          // this.refreshPage();
          // 测试通过成功后应当跳转到待发布的tab页
          this.$emit('activeNameChange', 'wait_to_deploy')
          // this.goToPage(this, "featureBranchIntegration", {bizId: this.bizId, appId: this.appId, activeTab: "wait_to_deploy"});
        }
      });
    },

    //获取当前集成生成的Release分支信息
    getCurrentIntegratedRelease() {
      let params = {
        appId: this.appId,
        integratedEnv: this.integratedEnv,
      };
      this.currentVersionId > 0 && (params.versionId = this.currentVersionId)
      $http.get($http.api.feature_branch.currentIntegratedRelease, params).then(res => {
        if (res != undefined && res.data) {
          this.currentIntegratedRelease = res.data;
        }
      });
    },


    getFeatureBranchCreateUser(row) {
      if (row && (row.createUser || row.createUserName)) {
        return row.createUserName + '(' + row.createUser + ')';
      }
      return "";
    },

    //获取当前集成分支列表
    getCurrentIntegratedBranchList() {
      this.current_integrated_branches_list_table_loading = true;
      let params = {
        appId: this.appId,
        integratedEnv: this.integratedEnv,
        pageNum: this.currentIntegratedBranchList.pageNum,
        pageSize: this.currentIntegratedBranchList.pageSize,
      };
      $http.get($http.api.feature_branch.currentIntegratedList, params).then(res => {
        if (res != undefined) {
          this.currentIntegratedBranchList = res.data;
          this.current_integrated_branches_list_table_loading = false;
        }
      });
    },

    handleCurrentIntegratedBranchListSizeChange(val) {
      this.currentIntegratedBranchList.pageSize = val;
      this.getCurrentIntegratedBranchList();
    },

    handleCurrentIntegratedBranchListPageChange(val) {
      this.currentIntegratedBranchList.pageNum = val;
      this.getCurrentIntegratedBranchList();
    },

    handleIntegratingSelectionChange(val) {
      this.integratingMultipleSelection = val;
    },

    //退出集成
    async exitIntegrated() {
      if(this.integratingMultipleSelection.length == 0) {
        this.$message.error("请选择当前集成分支后再执行操作")
        return;
      }

      let curPipelineRunningStatus =  this.$refs.WorkFlowStage.getPipelineOverallRunningStatus();

      if(curPipelineRunningStatus != this.STAGE_STATUS.SUCCESS) {
        let confirmResult;

        try{
          confirmResult = await this.$confirm("流水线上一次的执行流程仍未执行完，确认退出集成？",'提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          });
        } catch(e) {
          //do nothing
        };

        if(!confirmResult) {
          return;
        }
      }

      let exitIdArr = [];
      this.integratingMultipleSelection.forEach((item, index, arr) => {
        exitIdArr.push(item.changeId);
      });
      let allIdArr = [];
      this.currentIntegratedBranchList.list.forEach((item, index, arr) => {
        allIdArr.push(item.changeId);
      });
      let allFeatureBranchExit = exitIdArr.length == allIdArr.length;

      this.triggerType = "exitIntegrated";

      if(this.integratedEnv == "dev") {
        if(this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType == 0 && allFeatureBranchExit == false) {
          //show version desc dialog
          this.showVerDescDialog();
          return;
        }
      } else if(this.integratedEnv == "test") {
        if(this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType == 0 && allFeatureBranchExit == false) {
          //show version desc dialog
          this.showVerDescDialog();
          return;
        }
      }

      this.issueExitIntegratedRequest();
    },

    issueExitIntegratedRequest(versionDesc) {
      let targetStatus = "";
      if ("integrated_dev" == this.integratedType) {
        targetStatus = "INTEGRATED_DEV_WAITING";

      } else if ("integrated_test" == this.integratedType) {
        targetStatus = "INTEGRATED_TEST_WAITING";
      } else {
        targetStatus = "unknown";
      }

      let idArr = [];
      this.integratingMultipleSelection.forEach((item, index, arr) => {
        idArr.push(item.changeId);
      });

      let formData = new FormData();
      formData.set("id", idArr.join(","));
      formData.set("targetStatus", targetStatus);
      formData.set("triggerIntegrate", true);
      if(versionDesc) {
        formData.set("versionDesc", versionDesc);
      }
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
        let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
      }
      $http.post($http.api.feature_branch.status, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "退出集成成功"
          });
          this.refreshPage();
          //流水线触发自动执行后前端页面也需要动态展示
          let executeWorkflowId = response.data;
          if (executeWorkflowId && executeWorkflowId > 0) {
            this.renderPipeline(executeWorkflowId);
          }
        }
      });
      this.handleCloseVariablesDialog();
    },

    goToFeatureBranchDetailsPage(featureBranchId) {
      this.goToPage(this, 'featureBranchDetails',  {bizId : this.bizId, appId : this.appId, featureBranchId : featureBranchId});
    },

    //获取待集成分支列表
    getWaitIntegratedBranchList() {
      this.wait_integrated_branches_list_table_loading = true;
      let params = {
        appId: this.appId,
        integratedEnv: this.integratedEnv,
        pageNum: this.waitIntegratedBranchList.pageNum,
        pageSize: this.waitIntegratedBranchList.pageSize,
      };
      $http.get($http.api.feature_branch.waitIntegratedList, params).then(res => {
        if (res != undefined) {
          this.waitIntegratedBranchList = res.data;
          this.wait_integrated_branches_list_table_loading = false;
        }
      });
    },

    handleWaitIntegratedBranchListSizeChange(val) {
      this.waitIntegratedBranchList.pageSize = val;
      this.getWaitIntegratedBranchList();
    },

    handleWaitIntegratedBranchListPageChange(val) {
      this.waitIntegratedBranchList.pageNum = val;
      this.getWaitIntegratedBranchList();
    },


    handleWaiIntegrateSelectionChange(val) {
      this.waitIntegrateMultipleSelection = val;
    },

    beginIntegrated() {
      $http.get($http.api.pipeline.buildTaskVars, { pipelineId: this.pipelineInfo.pipelineId }).then(res => {
        this.buildTaskVaiableList = res.data;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
          this.variablesDialogShow = true;
          this.callFunc = "submitIntegrated";
        }else{
          this.variablesDialogShow = false;
          this.submitIntegrated();
        }
      })
    },

    beginTestIntegrated(){
      $http.get($http.api.pipeline.buildTaskVars, { pipelineId: this.pipelineInfo.pipelineId }).then(res => {
        this.buildTaskVaiableList = res.data;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
          this.variablesDialogShow = true;
          this.callFunc = "submitTestIntegrated";
        }else{
          this.variablesDialogShow = false;
          this.submitTestIntegrated();
        }
      })
    },

    beginExitIntegrated() {
      $http.get($http.api.pipeline.buildTaskVars, { pipelineId: this.pipelineInfo.pipelineId }).then(res => {
        this.buildTaskVaiableList = res.data;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
          let exitIdArr = [];
          this.integratingMultipleSelection.forEach((item, index, arr) => {
            exitIdArr.push(item.changeId);
          });
          let allIdArr = [];
          this.currentIntegratedBranchList.list.forEach((item, index, arr) => {
            allIdArr.push(item.changeId);
          });
          let allFeatureBranchExit = exitIdArr.length == allIdArr.length;
          if(allFeatureBranchExit){
            this.variablesDialogShow = false;
            this.exitIntegrated();
            return;
          }
          this.variablesDialogShow = true;
          this.callFunc = "exitIntegrated";
        }else{
          this.variablesDialogShow = false;
          this.exitIntegrated();
        }
      })
    },

    dispatchIntegrationRequestWithParams() {
      if(this.hasVariableBlank()){
        this.$message({
          showClose: true,
          message: '构建参数不能为空',
          type: 'warning'
        });
        return;
      }
      if(this.callFunc == "submitIntegrated"){
        this.submitIntegrated();
      }

      if(this.callFunc == "executePipeline"){
        this.executePipeline();
      }

      if(this.callFunc == "exitIntegrated"){
        this.exitIntegrated();
      }

      if(this.callFunc == "submitTestIntegrated"){
        this.submitTestIntegrated();
      }

      this.handleCloseVariablesDialog();
    },
    //提交集成, 批量操作
    async submitIntegrated() {
      if(this.waitIntegrateMultipleSelection.length == 0) {
        this.$message.error("请选择待集成分支后再执行操作");
        return;
      }

      let curPipelineRunningStatus =  this.$refs.WorkFlowStage.getPipelineOverallRunningStatus();

      if(curPipelineRunningStatus != this.STAGE_STATUS.SUCCESS) {
        let confirmResult;

        try{
          confirmResult = await this.$confirm("流水线上一次的执行流程仍未执行完，确认重新运行？",'提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          });
        } catch(e) {
          //do nothing
        };

        if(!confirmResult) {
          return;
        }
      }

      this.triggerType = "submitIntegrated";

      if(this.integratedEnv == "dev") {
        if(this.appSimpleInfo.appIntegratedSettings.integratedDevVerdescType == 0) {
          //show version desc dialog
          this.showVerDescDialog();
          return;
        }
      } else if(this.integratedEnv == "test") {
        if(this.appSimpleInfo.appIntegratedSettings.integratedTestVerdescType == 0) {
          //show version desc dialog
          this.showVerDescDialog();
          return;
        }
      }

      this.issueSubmitIntegratedRequest();
    },

    issueSubmitIntegratedRequest(versionDesc) {
      let sourceStatus = "";
      let targetStatus = "";
      if ("integrated_dev" == this.integratedType) {
        sourceStatus = "INTEGRATED_DEV_WAITING";
        targetStatus = "INTEGRATED_DEV_HANDLING";
      } else if ("integrated_test" == this.integratedType) {
        sourceStatus = "INTEGRATED_TEST_WAITING"
        targetStatus = "INTEGRATED_TEST_HANDLING";
      } else {
        sourceStatus = "unknown";
        targetStatus = "unknown";
      }

      let idArr = [];
      this.waitIntegrateMultipleSelection.forEach((item, index, arr) => {
        idArr.push(item.changeId);
      });

      let formData = new FormData();
      formData.set("id", idArr.join(","));
      formData.set("sourceStatus", sourceStatus);
      formData.set("targetStatus", targetStatus);
      formData.set("triggerIntegrate", true);
      if(versionDesc) {
        formData.set("versionDesc", versionDesc);
      }
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
        let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
      }
      $http.post($http.api.feature_branch.status, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "提交集成成功"
          });
          this.refreshPage();
          //流水线触发自动执行后前端页面也需要动态展示
          let executeWorkflowId = response.data;
          if (executeWorkflowId && executeWorkflowId > 0) {
            this.renderPipeline(executeWorkflowId);
          }
        }
      });
      this.handleCloseVariablesDialog();
    },

    //退回开发中
    turnBack2Developing(row) {
      let formData = new FormData();
      formData.set("id", row.changeId);
      formData.set("sourceStatus", row.status);
      formData.set("targetStatus", "DEVELOPING");
      $http.post($http.api.feature_branch.status, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "退回开发中成功"
          });
          this.refreshPage();
        }
      });
    },


    //获取版本列表
    getVersionList() {
      this.version_list_table_loading = true;
      let params = {
        appId: this.appId,
        pageNum: this.appVersionList.pageNum,
        pageSize: this.appVersionList.pageSize,
        developMode: this.developMode,
        featureBranchType: this.integratedType,
      };
      $http.get($http.api.appdate.apiappversionlist, params).then(res => {
        if (res != undefined) {
          this.appVersionList = res.data.data;
          this.version_list_table_loading = false;
        }
      });
    },

    passEnvClick(env) {
      $http.get($http.api.deploy_note.getPaasServerUrl, {env: env}).then((res) => {
        let url = res.data + "/appmanage/instanceRedirect?appId=" + this.appSimpleInfo.appCode;
        window.open(url, "_blank");
      });
    },

    handleVersionListSizeChange(val) {
      this.appVersionList.pageSize = val;
      this.getVersionList();
    },

    handleVersionListPageChange(val) {
      this.appVersionList.pageNum = val;
      this.getVersionList();
    },

    //点击版本名称下载
    downloadVersion(val) {
      if (val.pkgStatus == 4) {
        $http.get($http.api.appdate.api_app_version_download, { versionId: val.versionId }).then(res => {
          if (res.status == 200) {
            window.location.href = res.data.downloadUrl;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }

        });
      }
    },

    checkUpload(versionId, type) {
      this.uploadDialogVisible = true;
      if(this.$refs.PackageUploadInfo) {
        this.$refs.PackageUploadInfo.init(versionId, type)
      }
    },
    handleCloseUpload() {
      this.uploadDialogVisible = false;
    },

    handleVerDescDialogClose() {
      this.triggerType == "";
      this.userDefinedVersionDesc = "";
      this.userDefinedVersionDescDialogVisible = false;
    },

    showVerDescDialog() {
      this.userDefinedVersionDescDialogVisible = true;
    },


    dispatchExecuteRequestWithUserDefinedVerDesc() {
      if(this.userDefinedVersionDesc) {
        let curSize = this.userDefinedVersionDesc.length;
        if(curSize > 500) {
          this.$message.error("版本描述不得超过500字，当前字数为" + curSize);
          return false;
        }
      }

      //运行，重新运行的时候触发
      if(this.triggerType == "execute") {
        this.issueExecutePipelineReqeust(this.userDefinedVersionDesc);
      }
      //提交集成
      else if(this.triggerType == "submitIntegrated") {
        this.issueSubmitIntegratedRequest(this.userDefinedVersionDesc);
      }
      //退出集成
      else if(this.triggerType == "exitIntegrated") {
        this.issueExitIntegratedRequest(this.userDefinedVersionDesc);
      }

      else if(this.triggerType == "submitTestIntegrated") {
        this.issueSubmitTestIntegratedRequest(this.userDefinedVersionDesc);
      }
      this.handleVerDescDialogClose();
    },
  }
}
</script>

<style lang="scss" scoped>
.header-btns {
  margin: 0 0 15px;
  vertical-align: middle;
  .introduce-title {
    margin-left: 10px;
    font-size: 12px;
  }
}
.integrated-info-title {
  font-size: 14px;
  font-weight: 700;
  padding: 10px;
  margin: 0;
  // height: 50px;
  // line-height: 50px;
}
.integrated-release-branch-box {
  padding: 10px;
  background-color: #ecf1f0;
  border: 1px solid #e2e7e6;
}
.common-table-box {
  @extend .integrated-release-branch-box;
  margin: 10px 0 0;
  background-color: #f9f9f9;
  border: none;
  .common-table-title {
    font-size: 14px;
    font-weight: 700;
    margin-bottom: 5px;
    // text-align: center;
  }
}
</style>

