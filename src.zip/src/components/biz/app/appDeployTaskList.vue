<template>
  <div id="appDeployTaskList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
            <div class="table-box" v-if="showBtn == '0'">
              <div class="createBtn">
                <el-button type="success" class="mb10" @click="createDeployTask()">创建部署任务</el-button>
              </div>
              <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                <div class="table-box-top-bs">
                  <el-table :data="bulidingList_a" style="width:100%;height:100%;overflow:auto;">
                    <el-table-column type="index" label="序号" min-width="50">
                    </el-table-column>
                    <el-table-column prop="deployPlanName" label="部署名称" min-width="180">
                    </el-table-column>
                    <el-table-column prop="deployType" label="部署类型" min-width="120">
                    </el-table-column>
                    <el-table-column label="部署环境" min-width="120">
                      <template slot-scope="scope">
                        {{getDeployEnvStr(scope.row)}}
                      </template>
                    </el-table-column>
                    <el-table-column prop="zoneCode" label="部署机房" min-width="120">
                    </el-table-column>
                    <el-table-column prop="configEnv" label="配置环境" min-width="120">
                    </el-table-column>
                    <el-table-column prop="configVersion" label="配置版本" min-width="120">
                    </el-table-column>
                    <el-table-column label="创建人" min-width="150">
                      <template slot-scope="scope">
                        {{getCreateUser(scope.row)}}
                      </template>
                    </el-table-column>
                    <el-table-column prop="createTime" label="创建时间" min-width="180">
                    </el-table-column>
                    <el-table-column prop="time" label="操作" width="120">
                      <template slot-scope="scope">
                        <span class="c-blue cp" @click="editDeployTask(scope.row)">编辑</span>
                        <span class="c-blue cp" @click="deleteDeployTask(scope.row)">删除</span>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
              </div>
            </div>

            <div class="table-box deployinfoclass" v-if="showBtn == '1'">
              <div>
                <span style="font-size: 18px;font-weight: 600;" class="ml40" v-if="btnshow == 'edit'">编辑部署任务</span>
                <span style="font-size: 18px;font-weight: 600;" class="ml40" v-if="btnshow == 'keep'">创建部署任务</span>
                <span class="ml10 c-blue cp" @click="handleClose_bs()">&lt;&lt;返回</span>
              </div>
              <el-form :model="deployInfo" ref="deployInfoForm" label-width="120px" style="height:50%;">
                <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="部署名称" label-width="120px" prop="deployPlanName" :rules="[
                                            { required: true, message: '部署名称不能为空', trigger: 'blur' }
                                        ]">
                      <el-input placeholder="请输入部署名称" v-model="deployInfo.deployPlanName"
                                style='width:500px;'></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="描述" label-width="120px" prop="deployPlanDesc">
                      <el-input placeholder="请输入部署描述" type="textarea" v-model="deployInfo.deployPlanDesc"
                                style='width:500px;'></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="部署类型" label-width="120px" prop="deployType" :rules="[
                                            { required: true, message: '部署类型不能为空', trigger: 'blur' }
                                        ]">
                      <template>
                        <el-radio-group v-model="deployInfo.deployType">
                          <el-radio v-for="item in deployTypelist" :key="item.value" :label="item.value"
                                    :disabled="item.disabled">
                            {{item.label}}
                          </el-radio>
                        </el-radio-group>
                      </template>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="部署环境" label-width="120px" prop="deployEnv" :rules="[
                                            { required: true, message: '部署环境不能为空', trigger: 'blur' }
                                        ]">
                      <template>
                        <el-radio-group v-model="deployInfo.deployEnv"
                                        @change="changeDeployEnv(deployInfo.deployEnv, true, false)">
                          <el-radio v-for="item in deployEnvlist" :key="item.value" :label="item.value">
                            {{item.label}}
                          </el-radio>
                        </el-radio-group>
                      </template>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="机房单元" label-width="120px" prop="zoneCode" :rules="[
                                            { required: true, message: '机房单元与部署任务相关联，不能为空', trigger: 'blur' }
                                        ]">
                      <el-select v-model="deployInfo.zoneCode" placeholder="请选择" style='width:500px;'
                                 @change="changeZoneCode(deployInfo.zoneCode, true)">
                        <el-option v-for="item in zoneCodelist" :key="item.code" :label="item.name" :value="item.code">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="showConfig">
                    <el-form-item class='mb15' label="配置环境" label-width="120px" prop="configEnv">
                      <el-select v-model="deployInfo.configEnv" placeholder="请选择" style='width:500px;'
                                 @change="changeConfigEnv(deployInfo.configEnv, true)">
                        <el-option v-for="item in configEnvlist" :key="item.value" :label="item.label"
                                   :value="item.value">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="showConfig">
                    <el-form-item class='mb15' label="配置版本" label-width="120px" prop="configVersion">
                      <el-select v-model="deployInfo.configVersion" placeholder="请选择" style='width:500px;'>
                        <el-option v-for="item in configVersionlist" :key="item.value" :label="item.label"
                                   :value="item.value">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="部署批次" label-width="120px" prop="batchNum" :rules="[
                                            { required: true, message: '不能为空', trigger: 'blur' },
                                            { type: 'number', message: '必须为数字值'}
                                        ]">
                      <el-input type="n" placeholder="发布的批次数" v-model.number="deployInfo.batchNum"
                                style='width:500px;'></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="每批间隔(秒)" label-width="120px" prop="intervalTime" :rules="[
                                            { required: true, message: '不能为空', trigger: 'blur' },
                                            { type: 'number', message: '必须为数字值'}
                                        ]">
                      <el-input placeholder="每批次发布完的暂停时间" v-model.number="deployInfo.intervalTime"
                                style='width:500px;'></el-input>
                    </el-form-item>
                  </el-col>
                  <!--部署任务超时时间功能已废弃，现在默认传值180-->
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="超时时间(秒)" label-width="120px" prop="timeOut" :rules="[
                                            { required: true, message: '不能为空', trigger: 'blur' },
                                            { type: 'number', message: '必须为数字值'}
                                        ]">
                      <el-input placeholder="发布单台机器的超时时间" v-model.number="deployInfo.timeOut"
                                style='width:500px;'></el-input>
                    </el-form-item>
                  </el-col>

                </el-row>
              </el-form>
              <div style="height:80%;" class="ml20 mr20 mt5" v-loading="table_loading" element-loading-text="拼命加载中">
                <div style="height:40px;margin-bottom:10px;">
                  <span class="fl mt15 ml40">部署实例</span>
                  <span class="fl mt15 ml10 c-blue cp" @click="addBtn_zj()">
                    <i class="el-icon-plus"></i>
                    添加主机
                  </span>
                </div>
                <el-table :data="tableListDeoloy_a" style="width:1120px;overflow:auto;border:1px solid #dcdfe6">
                  <el-table-column type="index" label="序号" min-width="40">
                  </el-table-column>
                  <el-table-column prop="hostName" label="主机名称" min-width="120">
                  </el-table-column>
                  <el-table-column prop="ip" label="主机IP" min-width="120">
                  </el-table-column>
                  <el-table-column label="实例列表" min-width="700">
                    <template slot-scope="scope">
                      <el-table :ref="getRef(scope)" @select="checkboxSelectHandle"
                                @select-all="checkboxSelectHandle"
                                :data="scope.row.instanceList"
                                style="width:100%;height:100%;border:1px solid #dcdfe6">
                        <el-table-column align="center" type="selection" min-width="40"></el-table-column>
                        <el-table-column prop="instanceId" label="实例ID" min-width="120">
                        </el-table-column>
                        <el-table-column prop="tag" label="实例标签" min-width="120">
                        </el-table-column>
                        <el-table-column prop="createUser" label="创建人" min-width="150">
                          <template slot-scope="scope">
                            {{getCreateUser(scope.row)}}
                          </template>
                        </el-table-column>
                        <el-table-column prop="createTime" label="创建时间" min-width="150">
                        </el-table-column>
                        <el-table-column prop="information" label="操作" min-width="80">
                          <template slot-scope="scope">
                            <span class="c-blue cp" @click="delelteBtn_sl(scope.row)">删除</span>
                          </template>
                        </el-table-column>
                      </el-table>
                    </template>
                  </el-table-column>
                  <el-table-column prop="time" label="操作" min-width="120">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="addBtn_sl(scope.row)">添加实例</span>
                      <span class="c-blue cp" @click="delelteBtn_zj(scope.row)">删除</span>
                    </template>
                  </el-table-column>
                </el-table>
                <div class="foot" style="height:10%;text-align: center;">
                  <el-button type="primary" class="mt20 mb20" @click="updateBtn()" style="margin-right:20px;"
                             v-if="btnshow == 'edit'">保存
                  </el-button>
                  <el-button type="primary" class="mt20 mb20" @click="keepBtn()" style="margin-right:20px;"
                             v-if="btnshow == 'keep'">保存
                  </el-button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 添加主机 -->
    <el-dialog title='添加主机' id="yyDialog_zj" :visible.sync="dialogVisible_zj" class="el-dialog-400w issuedialog"
               :before-close="handleClose_zj" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="infoname_zj" ref="infoname_zj" class="mt20" label-width="70px" @submit.native.prevent>
          <el-form-item label="主机IP" prop="ip" :rules="[
                                            { required: true, message: '主机IP不能为空', trigger: 'blur' }
                                        ]">
            <el-input placeholder="请输入IP地址" v-model="infoname_zj.ip"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose_zj">关闭</el-button>
        <el-button type="primary" @click="handleSure_zj">保存</el-button>
      </span>
    </el-dialog>

    <!-- 添加实例 -->
    <el-dialog title='添加实例' id="yyDialog_sl" :visible.sync="dialogVisible_sl" class="el-dialog-640w issuedialog"
               :before-close="handleClose_sl" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="infoname_sl" ref="infoname_sl" label-width="120px">
          <el-form-item class='mb15' label="实例端口" prop="ports" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' },
                                            { type: 'number', message: '必须为数字值'}
                        ]">
            <el-input placeholder="请输入端口号" v-model.number="infoname_sl.ports"></el-input>
          </el-form-item>
          <el-form-item class='mb15' label="分类标签" prop="tag" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input placeholder="用于分类标识实例，同一批次的实例建议设置相同的分类标签" v-model="infoname_sl.tag"></el-input>
          </el-form-item>
          <el-form-item class='mb15' label="超时时间(秒)" prop="timeOut" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' },
                                            { type: 'number', message: '必须为数字值'}
                        ]">
            <el-input placeholder="请输入实例超时时间" v-model.number="infoname_sl.timeOut"></el-input>
          </el-form-item>
          <el-form-item class='mb15' label="容器网络模式" prop="containerNetType" v-if="deployInfo.deployType == 'Docker部署'"
                        :rules="[
                                            { required: true, message: '不能为空', trigger: 'blur' }
                                        ]">
            <el-select v-model="infoname_sl.containerNetType" placeholder="请选择">
              <el-option v-for="item in containerNetTypeList" :key="item.value" :label="item.label"
                         :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose_sl">关闭</el-button>
        <el-button type="primary" @click="handleSure_sl">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  // import Distpicker from 'v-distpicker'
  export default {
    name: "appDeployTaskList",
    data() {
      return {
        showBtn: "0",
        table_loading: false,
        deployEnvlist: [
          {
            value: "dev",
            label: "深圳开发私有云"
          },
          {
            value: "test",
            label: "北京测试私有云"
          }
        ],
        deployTypelist: [
          {
            value: "物理机部署",
            label: "物理机部署",
            disabled: false
          },
          {
            value: "Docker部署",
            label: "Docker部署",
            disabled: true
          },
          {
            value: "Kubernetes部署",
            label: "Kubernetes部署",
            disabled: true
          }
        ],
        zoneCodelist: [], //机房单元

        containerNetTypeList: [
          {
            value: "HOST",
            label: "HOST"
          },
          {
            value: "MACVLAN",
            label: "MACVLAN"
          },
          {
            value: "OVS",
            label: "OVS"
          }
        ],

        configEnvlist: [],  //配置环境
        configEnvTemplist: [],  //配置环境缓存列表
        configVersionlist: [], //配置版本
        infoname_zj: {ip: ''},
        dialogVisible_zj: false,
        modaltobody: false,
        shadeBtn: false,
        dialogVisible_sl: false,
        infoname_sl: {
          ports: "",
          tag: "",
          timeOut: "",
          containerNetType: ""
        },
        appLogList: [],
        currentZj: "",
        options: [],
        activeName: "first",
        deployInfo: {
          deployPlanName: '',
          deployPlanDesc: '',
          deployEnv: '',
          zoneCode: '',
          configEnv: '',
          deployType: '',
          configVersion: '',
          intervalTime: '',
          timeOut: '',
          batchNum: ''
        },
        bulidingList_a: [],
        appId: '',
        appCode: '',
        currentUser: {},
        idlist: [],
        btnshow: '',
        deploylanId: '',
        tableListDeoloy_a: [],
        showConfig: false,
        configCenterAppName: ''
      };
    },

    mounted() {
      this.appId = this.getUrlAppId();
      this.initParamAndPage();
    },

    methods: {

      getDeployEnvStr(row) {
        let deployEnvStr = "";
        this.deployEnvlist.forEach((item, index) => {
          if (row.deployEnv == item.value) {
            deployEnvStr = item.label;
          }
        })
        return deployEnvStr;
      },

      getCreateUser(row) {
        if (row && (row.userId || row.userName)) {
          return row.userName + '(' + row.userId + ')';
        }
        return "";
      },

      getRef(row) {
        return 'multipleTable' + row.$index;
      },

      getConfigCenterApplication() {
        $http.get($http.api.config_center.config_center_application, {appId: this.appId}).then((res) => {
          if (res.status != 200) {
          } else {
            if (res.data.isUsed === 1) {
              this.configCenterInfo = res.data.data;
              this.configCenterAppName = this.configCenterInfo.configCenterAppName;
              // 应用关联的配置中心不为空时才显示对应的输入框
              this.showConfig = true;
            }
          }
        });
      },

      initParamAndPage() {
        let params = {appId: this.appId};
        $http.get($http.api.app.get_app_basic_info, params).then(res => {
          if (res.status != 200) {
            this.$message({
              message: "获取appCode失败",
              type: "warning"
            });
          } else {
            this.appCode = res.data.appCode;
            this.getLoginUserInfo();
            this.getConfigCenterApplication();
            this.getdeploy();
          }
        });
      },

      getLoginUserInfo() {//获取当前登陆用户信息
        $http.get($http.api.user.getLoginUserInfo).then((res) => {
          if (res.status != 200) {
            this.$message({
              message: "获取当前登录用户信息失败",
              type: "warning"
            });
          } else {
            this.currentUser = res.data.systemUser;
          }
        })
      },

      //部署计划查询
      getdeploy() {
        this.bulidingList_a = [];
        var paramsDev = {appCode: this.appCode, env: "dev"}
        $http.get($http.api.deploy.apideployplanlist, paramsDev).then(res => {
          if (res.status == 200) {
            this.bulidingList_a = this.bulidingList_a.concat(res.data);
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }

        });
        var paramsTest = {appCode: this.appCode, env: "test"}
        $http.get($http.api.deploy.apideployplanlist, paramsTest).then(res => {
          if (res.status == 200) {
            this.bulidingList_a = this.bulidingList_a.concat(res.data);
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }

        });
      },

      //删除
      deleteDeployTask(val) {
        this.$confirm('确定要删除部署任务' + val.deployPlanName + '吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.get($http.api.deploy.apideployplandel, {
            deployPlanId: val.deployPlanId,
            env: val.deployEnv
          }).then(res => {
            if (res.status != 200) {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            } else {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.getdeploy();
            }
          });
        }).catch(() => {
        });
      },

      //编辑列表
      editDeployTask(val) {
        let params = {
          deployPlanId: val.deployPlanId,
          env: val.deployEnv
        }
        $http.get($http.api.deploy.apideployplansearch, params).then(res => {
          if (res.status == 200) {
            this.showBtn = "1";
            this.btnshow = 'edit';
            this.deployInfo = {
              deployPlanName: res.data.deployPlanName,
              deployPlanDesc: res.data.deployPlanDesc,
              deployEnv: res.data.deployEnv,
              zoneCode: res.data.zoneCode,
              configEnv: res.data.configEnv,
              deployType: res.data.deployType,
              configVersion: res.data.configVersion,
              intervalTime: res.data.intervalTime,
              timeOut: res.data.timeOut,
              batchNum: res.data.batchNum
            };
            let list = res.data;
            this.deploylanId = list.deployPlanId;
            //勾选的实例
            this.idlist = [];
            if (list.hostList) {
              list.hostList.forEach((i, index_i) => {
                i.instanceList.forEach((k, index_k) => {
                  this.idlist.push(k.instanceId);
                })
              });
            }

            this.changeDeployEnv(this.deployInfo.deployEnv, false, true);
            this.changeZoneCode(this.deployInfo.zoneCode, false);

          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      //创建部署任务
      createDeployTask() {
        this.deployInfo = {
          deployPlanName: '',
          deployPlanDesc: '',
          deployEnv: '',
          zoneCode: '',
          configEnv: '',
          deployType: '',
          configVersion: '',
          intervalTime: '',
          timeOut: 180,
          batchNum: ''
        };
        this.idlist = [];
        this.showBtn = "1";
        this.btnshow = 'keep';
      },

      //获取主机列表数据
      getHostPage() {
        this.table_loading = true;
        let params = {appCode: this.appCode, zoneCode: this.deployInfo.zoneCode, env: this.deployInfo.deployEnv};
        $http.get($http.api.deploy.apihostlist, params).then(res => {
          if (res.status != 200) {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          } else {
            this.tableListDeoloy_a = res.data;
            //已选中的实例列表在Vue渲染全部列表后进行二次勾选的渲染
            this.$nextTick(() => {
              this.tableListDeoloy_a.forEach((zj, index_zj) => {
                if (zj.instanceList) {
                  zj.instanceList.forEach((ins, index_ins) => {
                    this.idlist.forEach((k) => {
                      if (k == ins.instanceId) {
                        this.$refs['multipleTable' + index_zj].toggleRowSelection(ins);
                      }
                    })
                  })
                }
              })
            });
          }
        });
        this.table_loading = false;
      },


      //获取机房单元
      changeDeployEnv(val, cleanData, isEditDeployPlan) {
        let params = {env: val};
        $http.get($http.api.deploy.apiapplicationzonelist, params).then(res => {
          if (res.status != 200) {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          } else {
            this.zoneCodelist = res.data;
            if (cleanData) {
              //关联组件数据联动清空
              this.deployInfo.zoneCode = '';
              this.tableListDeoloy_a = [];
            }
          }
        });

        if (this.showConfig) {
          let params2 = {appId: this.appId, env: val};
          $http.get($http.api.config_center.app_config, params2).then(res => {
            if (res.status != 200) {
            } else {
              var list = [];
              for (var key in res.data) {
                var versions = [];
                for (var version in res.data[key].versionConfigMap) {
                  versions.push(version);
                }
                list.push({env: key, versions: versions});
              }

              this.configEnvTemplist = JSON.parse(JSON.stringify(list));
              list.forEach((item, index) => {
                item.value = item.env;
                item.label = item.env;
                delete item.env;
                delete item.versions;
              });
              this.configEnvlist = list;
              if (cleanData) {
                //关联组件数据联动清空
                this.deployInfo.configEnv = '';
                this.configVersionlist = [];
                this.deployInfo.configVersion = '';
              };
              if (isEditDeployPlan) {
                // 点击编辑时确保配置版本列表能在获取到列表数据后进行渲染
                this.changeConfigEnv(this.deployInfo.configEnv, false);
              }
            }
          });
        }
      },

      //选择机房单元获取配置环境信息
      changeZoneCode(val, cleanData) {
        //更新关联的主机列表
        this.getHostPage();
      },


      //选择配置环境获取配置版本
      changeConfigEnv(val, cleanData) {
        var temp = [];
        this.configEnvTemplist.forEach((item, index) => {
          if (item.env == val) {
            if (item.versions) {
              item.versions.forEach((version) => {
                temp.push({value: version, label: version});
              })
            }
          }
        })
        this.configVersionlist = temp;
        //关联组件数据联动清空
        if (cleanData) {
          this.deployInfo.configVersion = '';
        }

      },

      //添加主机
      addBtn_zj() {
        this.dialogVisible_zj = true;
      },

      //关闭添加主机的弹窗
      handleClose_zj() {
        this.infoname_zj = {ip: ''};
        this.dialogVisible_zj = false;
      },

      //添加主机弹窗确定按钮
      handleSure_zj() {
        this.$refs["infoname_zj"].validate(valid => {
          if (valid) {
            if (this.deployInfo.zoneCode && this.deployInfo.deployEnv) {
              let params = {
                appCode: this.appCode,
                zoneCode: this.deployInfo.zoneCode,
                env: this.deployInfo.deployEnv,
                ip: this.infoname_zj.ip,
                type: "0"
              };
              $http.post($http.api.deploy.apihostadd, params).then(res => {
                if (res.status != 200) {
                  this.$message({
                    message: res.msg,
                    type: "warning"
                  });
                } else {
                  this.$message({
                    message: "添加成功",
                    type: "success"
                  });
                  this.handleClose_zj();
                  this.getHostPage();
                }
              });
            } else {
              this.$message({
                message: "添加主机前请先选择部署环境和机房单元",
                type: "warning"
              });
            }
          }
        });
      },

      //删除实例列表中的其中选中的一条
      delelteBtn_sl(val) {
        this.$confirm('确定要删除实例' + val.instanceId + '吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.deploy.apiappinstancedel, {
            instanceId: val.instanceId,
            env: this.deployInfo.deployEnv,
            appCode: this.appCode
          }).then(res => {
            if (res.status != 200) {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            } else {
              this.$message({
                message: "删除成功",
                type: "success"
              });
            }
            this.getHostPage();
          });
        }).catch(() => {
        });
      },

      //删除主机信息
      delelteBtn_zj(val) {
        this.$confirm('确定要删除主机' + val.ip + '吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let params = {
            appCode: this.appCode,
            zoneCode: this.deployInfo.zoneCode,
            env: this.deployInfo.deployEnv,
            hostId: val.hostId
          };
          $http.post($http.api.deploy.apihostdel, params).then(res => {
            if (res.status != 200) {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            } else {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.getHostPage();
            }
          });
        }).catch(() => {
        });
      },

      //添加一条主机实例信息打开弹窗
      addBtn_sl(val) {
        if (this.deployInfo.deployType == null || this.deployInfo.deployType.length == 0) {
          this.$alert('请先选择部署类型，然后再添加实例', '错误操作', {
            confirmButtonText: '确定',
            callback: action => {
            }
          });
        } else {
          this.currentZj = val;
          this.dialogVisible_sl = true;
        }
      },

      //添加实例确定按钮
      handleSure_sl() {
        this.$refs["infoname_sl"].validate(valid => {
          if (valid) {
            let params = {
              appCode: this.appCode,
              zoneCode: this.deployInfo.zoneCode,
              env: this.deployInfo.deployEnv,
              deployType: this.deployInfo.deployType,
              confEnv: this.deployInfo.confEnv,
              confVersion: this.deployInfo.confVersion,
              hostId: this.currentZj.hostId,
              ip: this.currentZj.ip,
              hostName: this.currentZj.hostName,
              ports: this.infoname_sl.ports,
              tag: this.infoname_sl.tag,
              timeOut: this.infoname_sl.timeOut,
              containerNetType: this.infoname_sl.containerNetType,
              userId: this.currentUser.userId,
              userName: this.currentUser.userName
            };
            $http.post($http.api.deploy.apiinstanceadd, params).then(res => {
              if (res.status == 200) {
                this.$message({
                  message: "添加成功",
                  type: "success"
                });
                this.getHostPage();
                this.handleClose_sl();
              } else {
                this.$message({
                  message: res.msg,
                  type: "warning"
                });
              }
            });
          }
        });
      },

      //关闭添加实例的弹窗
      handleClose_sl() {
        this.$refs["infoname_sl"].resetFields();
        this.dialogVisible_sl = false;
      },

      //处理用户勾选实例操作
      checkboxSelectHandle(val) {
        this.idlist = [];
        this.tableListDeoloy_a.forEach((zj, index_zj) => {
          this.$refs['multipleTable' + index_zj].selection.forEach((select, index_select) => {
            var id = select.instanceId;
            this.idlist.push(id);
          })
        });
      },

      //创建部署任务保存
      keepBtn() {
        this.$refs['deployInfoForm'].validate((valid) => {
          if (valid) {
            //在添加或者更新之前确保勾选的实例列表，数据与界面元素一定是对应起来的
            this.checkboxSelectHandle();
            if (this.idlist && this.idlist.length > 0) {
              if(this.deployInfo.configEnv && !this.deployInfo.configVersion) {
                this.$message({
                  message: "请完善配置环境和配置版本信息",
                  type: "warning"
                });
                return;
              }

              let params = {
                appCode: this.appCode,
                zoneCode: this.deployInfo.zoneCode,
                env: this.deployInfo.deployEnv,
                deployPlanName: this.deployInfo.deployPlanName,
                deployPlanDesc: this.deployInfo.deployPlanDesc,
                deployEnv: this.deployInfo.deployEnv,
                configEnv: this.deployInfo.configEnv,
                zoneCode: this.deployInfo.zoneCode,
                deployType: this.deployInfo.deployType,
                configVersion: this.deployInfo.configVersion,
                intervalTime: this.deployInfo.intervalTime,
                timeOut: this.deployInfo.timeOut,
                // timeOut: '180',
                batchNum: this.deployInfo.batchNum,
                instanceIdList: new Set(this.idlist),
                userId: this.currentUser.userId,
                userName: this.currentUser.userName
              };
              $http.post($http.api.deploy.apideployplancreate, params).then(res => {
                if (res.status == 200) {
                  this.$message({
                    message: "保存成功",
                    type: "success"
                  });
                  this.getdeploy();
                  this.showBtn = "0";
                  this.idlist = [];
                } else {
                  this.$message({
                    message: res.msg,
                    type: "warning"
                  });
                }
              });
            } else {
              this.$message({
                message: "部署任务关联的实例列表不能为空，请添加并勾选关联实例",
                type: "error"
              });
            }
          }
        });
      },


      //更新按钮
      updateBtn() {
        this.$refs['deployInfoForm'].validate((valid) => {
          if (valid) {
            //在添加或者更新之前确保勾选的实例列表，数据与界面元素一定是对应起来的
            this.checkboxSelectHandle();
            if (this.idlist && this.idlist.length > 0) {
              if(this.deployInfo.configEnv && !this.deployInfo.configVersion) {
                this.$message({
                  message: "请完善配置环境和配置版本信息",
                  type: "warning"
                });
                return;
              }

              let params = {
                deployPlanName: this.deployInfo.deployPlanName,
                deployPlanId: this.deploylanId,
                deployPlanDesc: this.deployInfo.deployPlanDesc,
                deployEnv: this.deployInfo.deployEnv,
                zoneCode: this.deployInfo.zoneCode,
                deployType: this.deployInfo.deployType,
                configEnv: this.deployInfo.configEnv,
                configVersion: this.deployInfo.configVersion,
                appCode: this.appCode,
                intervalTime: this.deployInfo.intervalTime,
                timeOut: this.deployInfo.timeOut,
                // timeOut: '180',
                batchNum: this.deployInfo.batchNum,
                env: this.deployInfo.deployEnv,
                instanceIdList: new Set(this.idlist),
              };
              $http.post($http.api.deploy.apideployplanupdate, params).then(res => {
                if (res.status == 200) {
                  this.$message({
                    message: "更新成功",
                    type: "success"
                  });
                  this.getdeploy();
                  this.showBtn = "0";
                  this.idlist = [];
                } else {
                  this.$message({
                    message: res.msg,
                    type: "warning"
                  });
                }

              });
            } else {
              this.$message({
                message: "部署任务关联的实例列表不能为空，请添加并勾选关联实例",
                type: "error"
              });
            }
          }
        });
      },

      //返回部署任务列表页面
      handleClose_bs() {
        this.getdeploy();
        this.showBtn = "0";
        this.idlist = [];
        this.tableListDeoloy_a = [];
      },

    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  // .el-popper {
  //   margin-top: 0px !important;
  // }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .table-box-bs {
    box-sizing: border-box;
    background: #fff;
    height: calc(100% - 30px);

    .table-box-top-bs {
      width: 100%;
      height: calc(100% - 5px);
    }
  }

  .table-box {
    .server-box {
      .header-a {
        .zjlb {
          margin-left: 10px;
          margin-bottom: 5px;
          margin-right: 10px;
          display: inline-block;
        }

        .tjzj {
          width: 55px;
          height: 20px;
          margin-left: 10px;
          margin-bottom: 5px;
          display: inline-block;
          cursor: pointer;
        }

        .tjzj:hover {
          color: #409eff;
          //  border: 1px solid #409EFF;
          //  box-shadow: 0 0 10px #409EFF;
        }
      }

      .el-tabs--top {
        border: 1px solid #e4e7ed;
      }

      .el-progress {
        width: 70%;
        float: left;
        margin-top: 4px;
      }

      .progressNum {
        width: 25%;
        float: right;
        text-align: left;
      }
    }
  }

  .pzheader {
    height: calc(7% - 4px);
    border-bottom: 1px solid #e4e7ed;
  }

  .pzhg {
    height: calc(20% - 10px);
    min-height: 143px;
    border: 1px solid #e4e7ed;
    margin-bottom: 10px;

    .el-form-item {
      margin-bottom: 0px !important;
    }
  }

  .pzhjxq {
    height: 73%;

    .pzhjxq-s {
      width: calc(33.2% - 0.8px);
      min-width: 516.1px;
      height: 100%;
      border: 1px solid #e8e8e8;
      display: inline-block;
      overflow: hidden;
      overflow: auto;

      .kf-cs-zs {
        height: 30px;
        background: #e4e7ed;
      }

      .pz-hj-bb {
        height: 50px;
        border-bottom: 1px solid #e4e7ed;
      }

      .content {
        height: calc(100% - 80px);
        background: #f8f8f8;
      }
    }
  }

  .deployinfoclass {
    .el-form-item__error {
      margin-top: -30px;
      padding-left: 510px;
    }
  }

  .bstableshgl {
    .cell {
      padding-left: 0px !important;
      padding-right: 0px !important;
    }
  }
</style>
