<template>
  <div id="appPipeline" class="content-outer-box">
    <div class="x-arD content-box" style="margin-right: -15px;">
      <div class="streamLineheader"
        style="'height':pipelineInfo.triggerMode == 'TIMING_TRIGGER'?'550px':'250px';'height':pipelineInfo.triggerMode == 'MANU_TRIGGER'?'485px':'250px';">
        <div class="streamline">
          <div class="go-back">
            <span class="c-blue cp go-back-text" @click="goBack()">&lt;&lt;返回</span>
          </div>
          <el-form :model="pipelineInfo" ref="pipelineInfoForm" label-width="100px">
            <el-row :gutter="10" class="mt10" type="flex" justify="space-between">
              <el-col :lg="9" :md="14" :sm="24" :xs="24">
                <el-form-item label="流水线名称" prop="name" :rules="[
                                        { required: true, message: '请输入流水线名称' }
                                    ]">
                  <el-input v-model.trim="pipelineInfo.name" maxlength="99" :disabled="ifPipelineNameForbidden()">
                  </el-input>
                </el-form-item>
              </el-col>
              <el-col :lg="4" :md="6" :sm="24" :xs="24" v-if="operation != 'create' && pipelineInfo.developMode == 0 ">
                <p align="right" class="mt0 mr15">
                  <span :class="(pipelineInfo.defaultPipeline != true ? 'c-blue cp' : 'c-disabled cursor-default')"
                    style="font-size:14px; line-height: 40px;" @click="switchDefaultPipeline()">
                    设置为默认流水线
                  </span>
                  <el-tooltip effect="light" content="设置为默认流水线后，[生成版本]时将会自动选中默认流水线" placement="bottom-end">
                    <i class="el-icon-question ml5"></i>
                  </el-tooltip>
                </p>
              </el-col>
            </el-row>

            <el-row :gutter="10" v-if="appcodeinfo.appType != 5">
              <el-col :lg="9" :md="14" :sm="24" :xs="24">
                <el-form-item label="代码仓库" prop="sourceRepo">
                  <el-input v-model="pipelineInfo.sourceRepo" disabled></el-input>
                </el-form-item>
              </el-col>
            </el-row>

            <el-row :gutter="10" v-if="ifDisplayRelatedBranch()">
              <el-col :lg="9" :md="14" :sm="24" :xs="24">
                <el-form-item label="关联分支" prop="defaultBranch" :rules="[
                                        { required: true, message: '请选择关联分支' }
                                    ]">
                  <el-select v-model="pipelineInfo.defaultBranch" filterable placeholder="请选择关联分支"
                    style="width: 100%; color:#1b1b1d;" :disabled="ifRelatedBranchForbidden()">
                    <el-option v-for="item in allBranchList" :key="item.name" :label="item.name" :value="item.name">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>

            <el-row :gutter="10">

              <el-col :lg="9" :md="14" :sm="24" :xs="24">
                <el-form-item label="触发机制" prop="triggerMode" :rules="[
                                        { required: true, message: '请选择触发机制' }
                                    ]">
                  <el-radio-group v-model="pipelineInfo.triggerMode" @change="triggerModeChange"
                    :disabled="disabledform">
                    <el-radio :label="'MANU_TRIGGER'">手工</el-radio>
                    <el-radio :label="'TIMING_TRIGGER'" v-if="appcodeinfo.appType != 5">定时</el-radio>
                    <el-radio
                      :label="'AUTO_TRIGGER'"
                      v-if="!(pipelineInfo.featureBranchType == FEATURE_BRANCH_TYPE.INTEGRATED_DEV
                        || pipelineInfo.featureBranchType == FEATURE_BRANCH_TYPE.INTEGRATED_TEST)">
                    自动</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <!--<el-col :lg="24" :md="24" :sm="24" :xs="24" v-if="appcodeinfo.appType == 5">-->
                <!--<p class="c-red ml30"> 多仓库应用包含构建任务的流水线暂时只支持[生成版本]时触发</p>-->
              <!--</el-col>-->
            </el-row>

            <el-row :gutter="10">
              <el-col :lg="12" :md="14" :sm="24" :xs="24" v-if="pipelineInfo.triggerMode == 'TIMING_TRIGGER'">
                <el-form-item label="时间区间" required>
                  <el-col :lg="8" :md="10" :sm="22" :xs="22">
                    <el-form-item prop="scheduleStartTime" :rules="[
                                        { required: true, message: '请选择开始时间' }
                                    ]">
                      <el-time-select class="el-time-select" :disabled="disabledform" placeholder="起始时间"
                        v-model="pipelineInfo.scheduleStartTime" :picker-options="{
                                            start: '00:00',
                                            step: '00:10',
                                            end: '23:59'
                                            }"></el-time-select>
                    </el-form-item>
                  </el-col>
                  <el-col :lg="1"> -- </el-col>
                  <el-col :lg="8" :md="10" :sm="22" :xs="22">
                    <el-form-item prop="scheduleEndTime" :rules="[
                                        { required: true, message: '请选择结束时间' }
                                    ]">
                      <el-time-select class="el-time-select" :disabled="disabledform" placeholder="结束时间"
                        v-model="pipelineInfo.scheduleEndTime" :picker-options="{
                                            start: '00:00',
                                            step: '00:10',
                                            end: '23:59',
                                            }"></el-time-select>
                    </el-form-item>
                  </el-col>
                </el-form-item>
              </el-col>
            </el-row>

            <el-row :gutter="10">
              <el-col :lg="9" :md="14" :sm="24" :xs="24" v-if="pipelineInfo.triggerMode == 'TIMING_TRIGGER'">
                <el-form-item id="time_form" label="时间间隔" prop="interval" :rules="[
                                        { required: true, message: '请选择时间间隔' }
                                    ]">
                  <el-select v-model="pipelineInfo.interval" placeholder="请选择时间间隔" style="width:100%; color:#1b1b1d;"
                    :disabled="disabledform">
                    <el-option v-for="item in timeVallist" :key="item.value" :label="item.label" :value="item.value">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>

            <el-row :gutter="10">
              <el-col :lg="12" :md="14" :sm="24" :xs="24">
                <el-form-item prop="executeWeekdays" :rules="[
                                        { required: true, message: '请选择执行周几执行' }
                                    ]" v-if="pipelineInfo.triggerMode == 'TIMING_TRIGGER'">
                  <el-checkbox-group v-model="pipelineInfo.executeWeekdays" :disabled="disabledform">
                    <el-checkbox label="1">星期一</el-checkbox>
                    <el-checkbox label="2" style="margin-left:20px;">星期二</el-checkbox>
                    <el-checkbox label="3">星期三</el-checkbox>
                    <el-checkbox label="4">星期四</el-checkbox>
                    <el-checkbox label="5">星期五</el-checkbox>
                    <el-checkbox label="6">星期六</el-checkbox>
                    <el-checkbox label="7">星期日</el-checkbox>
                  </el-checkbox-group>
                </el-form-item>
              </el-col>
            </el-row>

            <el-row :gutter="10">
              <!--非多仓库应用自动触发流水线设置-->
              <el-col :lg="12" :md="14" :sm="24" :xs="24" v-if="pipelineInfo.triggerMode == 'AUTO_TRIGGER' && appcodeinfo.appType != 5">
                <el-form-item class="appcode_calss" v-for="(domain,index) in pipelineInfo.githookSettingLst"
                  style="margin-bottom:0;" :label="index > 0 ? '' :'代码分支'" :key="domain.key" required
                  :rules="[{ required: true, message: '不能为空' }]">
                  <el-form-item>
                    <el-select v-model="domain.sourceBranch" placeholder="请选择" style="width:280px;color:#1b1b1d;"
                      :disabled="disabledform">
                      <el-option v-for="item in autoTriggerBindableBranches" :key="item.name" :label="item.name" :value="item.name">
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item>
                    <el-select v-model="domain.event" placeholder="请选择" style="width:175px;color:#1b1b1d;"
                      :disabled="disabledform">
                      <el-option v-for="item in gitTriggerType" :key="item.value" :label="item.label"
                        :value="item.value"></el-option>
                    </el-select>
                  </el-form-item>

                  <el-button @click.prevent="removeDomain(domain)" :disabled="disabledform"
                    v-if="disabledform == false">删除
                  </el-button>

                </el-form-item>
                <el-button @click="addDomain" style="margin-bottom: 20px;margin-right: 225px;" class="fr"
                  :disabled="disabledform" v-if="disabledform == false">+添加监听分支
                </el-button>
              </el-col>
              <!--多仓库应用自动触发流水线设置-->
              <el-col :lg="20" :md="20" :sm="24" :xs="24" v-if="pipelineInfo.triggerMode == 'AUTO_TRIGGER' && appcodeinfo.appType == 5">
                <el-form-item class="appcode_calss" v-for="(domain,index) in pipelineInfo.githookSettingLst"
                              style="margin-bottom:0;" :label="index > 0 ? '' :'仓库/分支'" :key="domain.key" required
                              :rules="[{ required: true, message: '不能为空' }]">
                  <el-form-item>
                    <el-select v-model="domain.sourceRepo" placeholder="请选择" style="width:410px;color:#1b1b1d;"
                               :disabled="disabledform" @change="autoTriggerMultiRepoChange(domain)">
                      <el-option v-for="item in autoTriggerMultiRepoSourceRepoList" :key="item.name" :label="item.name" :value="item.name">
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item>
                    <el-select v-model="domain.sourceBranch" placeholder="请选择" style="width:230px;color:#1b1b1d;"
                               :disabled="disabledform">
                      <el-option v-for="item in autoTriggerMultiRepoSourceBranchList(domain)" :key="item.name" :label="item.name" :value="item.name">
                      </el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item>
                    <el-select v-model="domain.event" placeholder="请选择" style="width:165px;color:#1b1b1d;"
                               :disabled="disabledform">
                      <el-option v-for="item in gitTriggerType" :key="item.value" :label="item.label"
                                 :value="item.value"></el-option>
                    </el-select>
                  </el-form-item>

                  <el-button @click.prevent="removeDomain(domain)" :disabled="disabledform"
                             v-if="disabledform == false">删除
                  </el-button>

                </el-form-item>
                <el-button @click="addDomain" style="margin-bottom: 20px;margin-left: 865px;" class="fl"
                           :disabled="disabledform" v-if="disabledform == false">+添加监听分支
                </el-button>
              </el-col>
            </el-row>
            <el-row :gutter="10">
              <el-col :span="24">
                <el-form-item>
                  <el-button @click="cancelPipelineEdit" v-if="btneye == '1'">取消</el-button>
                  <el-button type="primary" v-if="btneye == '1'" @click="savePipelineInfo" :disabled="btnSaveDisabled">
                    保存</el-button>
                  <el-button type="primary" id="editBtn" v-if="btneye == '2' && pipelineInfo.status == 0"
                    @click="switchToEdit">编辑
                  </el-button>
                </el-form-item>
              </el-col>
            </el-row>

          </el-form>
        </div>
      </div>
      <div class="white-box streambody">
        <div class="shadeshow"></div>
        <div class="step_modulepar" v-for="(domain,index) in stageLst" :key="index">
          <div class="step_module">
            <div class="modulehead">
              <span class="moduletitle" :title="domain.name">{{domain.name}}</span>
              <div class="moduletitle" style="font-size:15px;padding-top:0px;">{{domain.pipelineTaskLst.length}}个任务
              </div>
              <i class="el-icon-edit" @click="editStage({name:domain.name,index:index})" v-if="disabledform == false">
              </i>
              <i class="el-icon-delete" @click="deleteStage(domain.name)" v-if="disabledform == false"></i>
            </div>
            <div class="moduleBody">
              <span style="font-size: 20px;
                    height: 30px;
                    display: inline-block;
                    margin-top: 10px;
                    margin-left: -190px;">任务列表</span>
              <div style="border:1px dashed rgb(41, 36, 36);margin-bottom: 18px;" class="ml10 mr10"></div>
              <draggable v-model="domain.pipelineTaskLst" @update="datadragEnd" :options_drag="{animation:100}">
                <!-- <transition-group> -->
                <div class="moduleBody_a" v-for="(item,index) in domain.pipelineTaskLst" :key="index">
                  <span class="moduleBody_a_son" title="可拖动排序">{{item.name}}</span>
                  <i class="el-icon-delete" @click="deleteTask({stageName:domain.name, taskName:item.name})"
                    v-if="disabledform == false"></i>
                  <i class="el-icon-edit"
                    @click="editTask({stageName:domain.name, taskName:item.name, taskType:item.type, taskSetting:item.setting,index:index})"
                    v-if="disabledform == false"></i>
                  <div class="moduleBody_a_son2" title="可拖动排序">{{getTaskName(item)}}</div>
                </div>
                <!-- </transition-group> -->
              </draggable>
              <el-button type="primary" style="margin-left:calc(50% - 45px);margin-top:10px;margin-bottom:10px;"
                @click="addcontentadd(domain.name)" v-if="disabledform == false">+添加任务
              </el-button>
            </div>
          </div>
          <div class="add">
            <span class="el-icon-circle-plus-outline" @click="addcontent(index)" v-if="disabledform == false"></span>
            <span class="el-icon-d-arrow-right" v-if="stageLst.length != index + 1"></span>
          </div>
        </div>
      </div>
    </div>
    <el-dialog :title="titleLine" :visible.sync="dialogVisible" class="el-dialog-350w streamlinedialog"
      :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal="shadeBtn">
      <div class="form-iterm-box">
        <el-form :model="pipelineStageTempInfo" ref="pipelineStageTempInfoForm" label-width="60px"
          @submit.native.prevent>
          <el-form-item label="名称" prop="name" :rules="[
                                { required: true, message: '不能为空' }
                            ]">
            <el-input placeholder="请输入内容" maxlength="60" v-model="pipelineStageTempInfo.name"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="callStageEdit">关闭</el-button>
        <el-button type="primary" @click="submitBtn">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog :title="titleTask" :visible.sync="adddialogVisible" class="el-dialog-640w" :before-close="addhandleClose"
      :modal-append-to-body="modaltobody" :close-on-click-modal="shadeBtn">
      <div class="form-iterm-box">
        <el-form :model="pipelineTaskTempInfo" ref="pipelineTaskTempInfoForm" label-width="80px">
          <el-row :gutter="10" class="mt10">
            <el-col :span="24">
              <el-form-item label="类型" prop="type" :rules="[
                                    { required: true, message: '请选择任务类型',trigger:'blur' }
                                ]">
                <el-select v-model="pipelineTaskTempInfo.type" placeholder="请选择" style="width:100%;"
                  @change="changeTaskType(pipelineTaskTempInfo.type)">
                  <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label="名称" prop="name" :rules="[
                                    { required: true, message: '请输入任务名称',trigger:'blur' }
                                ]">
                <el-input placeholder="请输入内容" maxlength="60" v-model="pipelineTaskTempInfo.name"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'BUILD'">
              <el-col :span="12" style="padding-top:5px;">
                <span style="font-size:14px; line-height: 40px; font-weight: bold">
                  请选择需要调用的任务
                </span>
              </el-col>
              <el-col :span="12" style="padding-top:5px;">
                <p align="right" class="mt0 mr15">
                  <span style="font-size:14px; line-height: 40px;">
                    找不到合适的任务?
                  </span>
                  <span class="c-blue cp" style="font-size:14px; line-height: 40px;" @click="goCreateCompileTask()">
                    点击创建
                  </span>
                </p>
              </el-col>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'BUILD'">
              <span style="font-size:14px; line-height: 40px;">
                您已选择：
              </span>
              <el-button-group v-if="pipelineTaskTempInfo.type == 'BUILD' && showTaskName">
                <el-button>{{pipelineTaskTempInfo.compileTaskName}}</el-button>
                <el-button icon="el-icon-close" @click="taskClose"></el-button>
              </el-button-group>
              <span class="c-blue cp" style="font-size:14px; line-height: 40px; float: right;"
                @click="getCompileTaskLst()">
                刷新
              </span>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'DEPLOY'">
              <el-form-item label="部署环境" prop="environment" :rules="[
                                    { required: true, message: '请选择部署环境',trigger:'blur' }
                                ]">
                <el-select v-model="pipelineTaskTempInfo.environment" placeholder="请选择" style="width:100%;"
                  @change="changeenvBtn(pipelineTaskTempInfo.environment)">
                  <el-option v-for="item in environmentlist" :key="item.value" :label="item.label" :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'CODE_SCANNING'">
              <el-form-item class="mb15" label="扫描类型" prop="taskType" :rules="[
                                    { required: true, message: '请选择代码扫描类型',trigger:'blur' }
                                ]">
                <el-select v-model="pipelineTaskTempInfo.taskType" placeholder="请选择" style="width:100%;"
                  @change="changeCodeScanningType()">
                  <el-option v-for="item in codeScanningTaskTypeList" :key="item.value" :label="item.label"
                    :value="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-show="false"
              v-if="pipelineTaskTempInfo.type == 'CODE_SCANNING' && pipelineTaskTempInfo.taskType=='SONARQUBE'"
              v-for="(item, index) in pipelineTaskTempInfo.sonarMetricsList" :key="index">
              <el-form-item class="mb15" :label="index==0 ? '质量阀' : ''">
                <el-col :span="10">
                  <label>{{item.descriptionZh}}</label>
                </el-col>
                <el-col :span="5">
                  <label>{{getSonarMetricsOperatorDesc(item)}}</label>
                </el-col>
                <el-col :span="5">
                  <!--TODO 代码扫描第一版默认质量阀不可编辑，后期此处调整为可编辑即可-->
                  <el-input v-if="item.valType=='PERCENT' || item.valType=='INT'" v-model="item.valueError"
                    readonly="readonly"></el-input>
                  <label
                    v-if="item.valType=='RATING'">{{item.valueError==1 ? 'A' : item.valueError==2 ? 'B' : item.valueError==3 ? 'C' : item.valueError==4 ? 'D' : 'E'}}</label>
                </el-col>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-show="false"
              v-if="pipelineTaskTempInfo.type == 'CODE_SCANNING' && pipelineTaskTempInfo.taskType=='SONARQUBE'">
              <el-form-item class="mb15" :label="''">
                <el-button @click="addSonarQualityGateMetrics" class="ml80">+添加Sonar质量阀指标</el-button>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'MVN_DEPLOY'" style="width: 636px;">
              <el-form-item label="允许分支" prop="deployMvnBranches" class="mb15">
                <el-input v-model="pipelineTaskTempInfo.deployMvnBranches"
                          placeholder="请输入允许上传的分支,多个用逗号分隔,留空表示允许所有分支发布" style="width: 505px;"/>
                <i class="el-icon-question" title="1.允许发布分支规则示例：master,release/*,hotfix/**
2.允许发布分支规则说明：?（匹配单个字符），*（匹配0或多个字符），**（匹配0或多个字符及目录）
3.留空表示允许所有分支推送" style="font-size: 12px;" />
              </el-form-item>
            </el-col>
            <el-col :span="24"
              v-if="pipelineTaskTempInfo.type == 'SUBMIT_TEST'|| pipelineTaskTempInfo.type == 'ARTIFICIAL_CHECKPOINT'
                    || pipelineTaskTempInfo.type == 'PASS_TEST'">
              <el-form-item label="处理人">
                <el-col :span="12">
                  <el-form-item prop="proPerson" :rules="[
                                          { required: true, message: '不能为空',trigger:'blur' }
                                      ]">
                    <el-select v-model="pipelineTaskTempInfo.proPerson" placeholder="请选择" style="width:100%;"
                      :disabled="disabled_persion">
                      <el-option v-for="item in personlist" :key="item.value" :label="item.label" :value="item.value">
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="12" v-if="pipelineTaskTempInfo.proPerson == 0">
                  <el-form-item prop="person" :rules="[
                                      { required: true, message: '不能为空' ,trigger:'blur' }
                                  ]">
                    <el-select multiple v-model="pipelineTaskTempInfo.person" placeholder="请选择" style="width:100%;"
                      :disabled="disabled_persion">
                      <el-option v-for="item in objpersonList" :key="item.roleId" :label="item.roleName"
                        :value="item.roleId"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="12" v-if="pipelineTaskTempInfo.proPerson == 1">
                  <el-form-item prop="people" :rules="[
                                      { required: true, message: '不能为空',trigger:'blur' }
                                  ]">
                    <el-select multiple v-model="pipelineTaskTempInfo.people" placeholder="请选择" style="width:100%;">
                      <el-option v-for="item in personperlist" :key="item.userId" :label="item.userName"
                        :value="item.userId">
                        <span style="float: left">{{ item.userName }}</span>
                        <span style="float: right; color: #8492a6; font-size: 13px">{{ item.userId }}</span>
                      </el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-form-item>
            </el-col>

            <el-col :span="24" v-if="pipelineTaskTempInfo.type != '' && pipelineTaskTempInfo.type != 'BUILD'
              && pipelineTaskTempInfo.type != 'BRANCH_MANAGE'
              && pipelineTaskTempInfo.type != 'CODE_SCANNING'
              && pipelineTaskTempInfo.type != 'AUTO_TEST'
              && pipelineTaskTempInfo.type != 'PASS_TEST'
              && pipelineTaskTempInfo.type != 'ARTIFICIAL_CHECKPOINT'
              && pipelineTaskTempInfo.type != 'UNIT_TEST'">
              <el-form-item label="触发方式" prop="autoExec" :rules="[
                                        { required: true, message: '请选择触发方式',trigger:'blur' }
                                    ]">
                <el-radio-group v-model="pipelineTaskTempInfo.autoExec">
                  <el-radio :label="false">手动</el-radio>
                  <el-radio :label="true">自动</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="(pipelineTaskTempInfo.type == 'DEPLOY' && pipelineTaskTempInfo.autoExec== true) ||
              pipelineTaskTempInfo.type == 'UNIT_TEST' || pipelineTaskTempInfo.type == 'CODE_SCANNING' ||
              pipelineTaskTempInfo.type == 'AUTO_TEST'">
              <el-form-item label="流转方式" prop="transferType" :rules="[
                                    { required: true, message: '请选择流转方式',trigger:'blur' }
                                ]">
                <el-select v-model="pipelineTaskTempInfo.transferType" placeholder="请选择" style="width:100%;">
                  <el-option v-for="item in transferTypeList" :key="item.value" :label="item.label" :value="item.value">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'DEPLOY' && pipelineTaskTempInfo.autoExec== true"
              style="padding-top:5px;">
              <el-form-item label="部署任务" prop="deployPlanName" :rules="[
                                        { required: true, message: '请选择部署任务',trigger:'blur' }
                                    ]">
                <el-select v-model="pipelineTaskTempInfo.deployPlanName" placeholder="请选择" style="width:100%">
                  <el-option v-for="item in deploymentTaskList" :key="item.deployPlanId" :label="item.deployPlanName"
                    :value="item.deployPlanId"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'CUSTOMIZED_SCRIPT'" style="padding-top:5px;">
              <el-form-item label="脚本内容" prop="shellScriptContent" :rules="[
                                        { required: true, message: '不能为空',trigger:'blur' }
                                    ]">
                <el-input type="textarea" :rows="6" v-model="pipelineTaskTempInfo.shellScriptContent"></el-input>
              </el-form-item>
              <el-form-item>
                <span><a class="c-blue cp" href="http://doc.oppoer.me/pages/viewpage.action?pageId=60753727"
                    target="view_window">自定义脚本帮助文档</a></span>
              </el-form-item>
            </el-col>
            <el-col :span="24" v-if="pipelineTaskTempInfo.type == 'UNIT_TEST'" style="padding-top:5px;">
              <el-form-item label="命令" prop="mvnCommand" :rules="[
                                        { required: true, message: '不能为空',trigger:'blur' }
                                    ]">
                <el-input placeholder="请输入单元测试MAVEN命令" v-model="pipelineTaskTempInfo.mvnCommand" disabled></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="10" v-if="pipelineTaskTempInfo.type == 'BUILD'">
            <el-col :span="10" v-for="(item, index) in compileTaskList" :key="item.uuid" :offset="2"
              style="margin: 5px 5px 0 25px;">
              <el-card :body-style="{ padding: '0px', 'width': '200px'}" shadow="hover"
                :class="(pipelineTaskTempInfo.compileTaskUUID == item.uuid ? 'card_border cp' : 'cp')"
                @click.native="selectCompileTask(item.uuid)">
                <div style="padding: 5px;">
                  <span style="font-size:12px; line-height: 25px; font-weight: bold; overflow:hidden;"
                    :title="item.taskName">{{item.taskName}}</span>
                  <p class="mt0 mr15" style="margin-bottom: 6px;">
                    <span style="font-size:12px; line-height: 10px; font-weight: lighter">
                      创建者:
                    </span>
                    <span style="font-size:12px; line-height: 10px;">
                      {{item.userName}}
                    </span>
                  </p>
                  <p class="mt0 mr15" style="margin-bottom: 6px;">
                    <span style="font-size:12px; line-height: 10px; font-weight: lighter">
                      最近构建:
                    </span>
                    <span style="font-size:12px; line-height: 10px;">
                      {{item.lastDetailId === -1 ? '--' : item.lastCompileTime}}
                    </span>
                  </p>
                </div>
              </el-card>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addhandleClose()">关闭</el-button>
        <el-button type="primary" @click="saveTaskSetting" :loading="btnloading">保存</el-button>
      </span>
    </el-dialog>
    <el-dialog title="添加Sonar质量阀指标" :visible.sync="dialogAddSonarMetricsVisible" class="el-dialog-350w streamlinedialog"
      :before-close="handleCloseAddSonarMetricsDialog" :modal-append-to-body="modaltobody"
      :close-on-click-modal="shadeBtn">
      <div class="form-iterm-box">
        <el-form :model="sonarMetricsAddTempInfo" ref="addSonarMetricsForm" label-width="60px">
          <el-form-item label="名称" prop="name" :rules="[
                                { required: true, message: '不能为空', trigger:'blur' }
                            ]">
            <el-select v-model="sonarMetricsAddTempInfo.name" placeholder="请选择" style="width:100%"
              @change="addSonarMetricsChange()">
              <el-option v-for="item in sonarMetricsAllList" :key="item.name" :label="item.descriptionZh"
                :value="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="操作" v-if="sonarMetricsAddTempInfo.operator">
            <label>{{getSonarMetricsOperatorDesc(sonarMetricsAddTempInfo)}}</label>
          </el-form-item>
          <el-form-item label="错误" prop="valueError" :rules="[
                                { required: true, message: '不能为空' }
                            ]" v-if="sonarMetricsAddTempInfo.valueError">
            <el-input placeholder="请输入错误值"
              v-if="sonarMetricsAddTempInfo.valType=='PERCENT' || sonarMetricsAddTempInfo.valType=='INT'"
              v-model="sonarMetricsAddTempInfo.valueError"></el-input>
            <el-select v-model="sonarMetricsAddTempInfo.valueError" placeholder="请选择" style="width:100%"
              v-if="sonarMetricsAddTempInfo.valType=='RATING'">
              <el-option v-for="item in sonarMetricsRatingValTypeList" :key="item.value" :label="item.label"
                :value="item.value"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseAddSonarMetricsDialog">关闭</el-button>
        <el-button type="primary" @click="submitAddSonarMetrics">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>


<script>
  import draggable from "vuedraggable"; //拖拽插件
  export default {
    name: "appPipeline",

    data() {

      return {
        WORKFLOW_TRIGGER_TYPE: GLOBAL_CONST.WORKFLOW_TRIGGER_TYPE,
        WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
        TRANSFER_TYPE: GLOBAL_CONST.TRANSFER_TYPE,
        FEATURE_BRANCH_TYPE: GLOBAL_CONST.FEATURE_BRANCH_TYPE,
        showTaskName: false,
        dialogVisible: false,
        modaltobody: false,
        shadeBtn: false,
        btnloading: false,
        btnSaveDisabled: false,

        //流水线阶段配置，只有一个属性
        pipelineStageTempInfo: {
          name: ""
        },

        //流水线基本信息
        pipelineInfo: {
          name: "",
          createOrder: 0,
          uuid: "",
          defaultPipeline: false,
          status: 0,
          type: 0,
          triggerMode: GLOBAL_CONST.WORKFLOW_TRIGGER_TYPE.MANUAL_TRIGGER,
          defaultBranch: "",
          pkgable: "",
          sourceRepo: "",
          scheduleStartTime: "",
          scheduleEndTime: "",
          interval: "",
          executeWeekdays: [],
          githookSettingLst: [],
          developMode: 0,
          featureBranchType: "",
        },
        currentAddTaskStageName: "",

        //临时编辑/新增任务单表数据
        pipelineTaskTempInfo: {
          name: "",
          type: "",
          taskType: "",
          transferType: "",
          autoExec: null,
          environment: "",
          deployPlanName: "",
          deploymentTask: "",
          proPerson: null,
          person: [],
          people: [],
          shellScriptContent: "",
          mvnCommand: "mvn test",
          sonarMetricsList: [],
          buildVarsList: [],
          compileTaskName: "",
          compileTaskUUID: "",
          deployMvnBranches: "",
        },

        itemInfo: {},
        stageLst: [{ name: "阶段名称", order: "0", pipelineTaskLst: [] }],
        titleLine: "流水线阶段配置",
        titleTask: "添加任务",

        // ===========
        adddialogVisible: false,
        currentEditTask: "",

        options: [
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.BUILD,
            label: "构建"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.DEPLOY,
            label: "部署"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT,
            label: "自定义脚本"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT,
            label: "人工卡点"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.SUBMIT_TEST,
            label: "提测"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.PASS_TEST,
            label: "测试通过"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.CODE_SCANNING,
            label: "代码扫描"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.UNIT_TEST,
            label: "单元测试"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.AUTO_TEST,
            label: "自动化测试"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.BRANCH_MANAGE,
            label: "分支管理器"
          },
          {
            value: GLOBAL_CONST.WORKFLOW_TASK_TYPE.MVN_DEPLOY,
            label: "上传Maven仓库"
          },
        ],

        typeOptions: {
          BUILD: "构建",
          DEPLOY: "部署",
          CODE_SCANNING: "代码扫描",
          AUTO_TEST: "自动化测试",
          CUSTOMIZED_SCRIPT: "自定义脚本",
          ARTIFICIAL_CHECKPOINT: "人工卡点",
          SUBMIT_TEST: "提测",
          PASS_TEST: "测试通过",
          UNIT_TEST: "单元测试",
          BRANCH_MANAGE: "分支管理器",
          MVN_DEPLOY: "上传Maven仓库",
        },
        disabled_persion: false,
        personlist: [
          {
            value: 0,
            label: "角色"
          },
          {
            value: 1,
            label: "人员"
          }
        ],
        objpersonList: [],
        environmentlist: [
          {
            value: "dev",
            label: "开发环境"
          },
          {
            value: "test",
            label: "测试环境"
          }
        ],

        nowType: "",
        newType: "",

        timeVallist: [
          {
            value: 10,
            label: "10分钟"
          },
          {
            value: 30,
            label: "30分钟"
          },
          {
            value: 60,
            label: "60分钟"
          },
          {
            value: 120,
            label: "120分钟"
          },
          {
            value: 240,
            label: "240分钟"
          },
          {
            value: 360,
            label: "360分钟"
          }
        ],
        personperlist: [],

        //代码分支，既包含普通branch,也包含tag
        allBranchList: [],
        //纯普通branch分支，不包含tag
        pureBranchList: [],

        //多仓库应用分支列表
        multiRepoApplicationBranchList: [],

        btneye: "2",
        tmpPipelineId: "", //流水线临时ID
        disabledform: true,
        indexvip: null,
        deploymentTaskList: [],
        compileTaskList: [],
        transferTypeList: [
          {
            value: "FINISHED_SUCCESS_TRANSFER",
            label: "完成且成功流转"
          },
          {
            value: "FINISHED_TRANSFER",
            label: "完成流转"
          },
          {
            value: "UNFINISHED_TRANSFER",
            label: "未完成流转"
          }
        ],

        options_drag: "",
        appcodeinfo: {},
        bizId: null,
        appId: null,
        pipelineId: null,

        gitTriggerType: [
          {
            value: "push",
            label: "PUSH"
          },
          {
            value: "merge_merged",
            label: "MERGE"
          }
        ],

        operation: '',
        templateType: '',
        templatePipelineId: '',

        codeScanningTaskTypeList: [
          {
            value: "FIND_BUGS",
            label: "FindBugs"
          },
          {
            value: "SONARQUBE",
            label: "SonarQube"
          },
          {
            value: "SONARQUBE_OPPO_RULE",
            label: "代码规范扫描"
          },
          {
            value: "SAFETY_SCAN",
            label: "SecurityScan"
          }
        ],

        dialogAddSonarMetricsVisible: false,
        sonarMetricsAllList: [],
        sonarMetricsAddTempInfo: {
          name: "",
          descriptionZh: "",
          operator: "",
          valType: "",
          valueError: ""
        },
        sonarMetricsRatingValTypeList: [
          {
            value: "1",
            label: "A"
          },
          {
            value: "2",
            label: "B"
          },
          {
            value: "3",
            label: "C"
          },
          {
            value: "4",
            label: "D"
          }
        ],
      };
    },

    mounted() {
      this.initPage();
    },

    computed: {
      autoTriggerBindableBranches() {
        if(this.pipelineInfo.featureBranchType == this.FEATURE_BRANCH_TYPE.DEV) {
          return new Array({name:this.pipelineInfo.defaultBranch});
        }
        return this.pureBranchList;
      },
      autoTriggerMultiRepoSourceRepoList() {
        let repoList = new Array();
        if (this.multiRepoApplicationBranchList) {
          this.multiRepoApplicationBranchList.forEach((item, index) => {
            repoList.push({name:item.sourceRepo});
          });
        }
        return repoList;
      },
    },

    beforeRouteLeave(to, from, next) {
      //跳转页面前，如果流水线编辑未保存，则提示是否强制跳转
      if (this.btneye == "1") {
        this.$confirm("当前页面未保存，确定不保存直接离开？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          next();
        }).catch(() => {
        });
      } else {
        next();
      }
    },

    methods: {
      goBack() {
        this.$router.go(-1);//返回上一层
      },
      //触发机制为自动方式
      triggerModeChange() {
        if (this.pipelineInfo.triggerMode == 'AUTO_TRIGGER' && this.pipelineInfo.githookSettingLst.length === 0) {
          this.addDomain()
        }
      },
      selectCompileTask(uuid) {
        this.pipelineTaskTempInfo.compileTaskUUID = uuid;
        this.compileTaskList.forEach((item, index) => {
          if (item.uuid == uuid) {
            this.pipelineTaskTempInfo.compileTaskName = item.taskName;
          }
        });
        this.showTaskName = true;
      },

      taskClose() {
        this.showTaskName = false;
        this.pipelineTaskTempInfo.compileTaskName = "";
        this.pipelineTaskTempInfo.compileTaskUUID = "";
      },

      //特性分支对应的开发流水线关联分支不能改变，就是创建时的特性分支
      ifPipelineNameForbidden() {
        return this.disabledform
          || (this.pipelineInfo.featureBranchType != undefined
              && this.pipelineInfo.featureBranchType != "");
      },

      //多仓库应用以及集成测试分支不显示关联分支
      ifDisplayRelatedBranch() {
        return this.appcodeinfo.appType != 5
          && this.pipelineInfo.featureBranchType != this.FEATURE_BRANCH_TYPE.INTEGRATED_DEV
          && this.pipelineInfo.featureBranchType != this.FEATURE_BRANCH_TYPE.INTEGRATED_TEST
      },

      //特性分支对应的开发流水线关联分支不能改变，就是创建时的特性分支
      ifRelatedBranchForbidden() {
        return this.disabledform || this.pipelineInfo.featureBranchType == this.FEATURE_BRANCH_TYPE.DEV;
      },

      getSonarMetricsOperatorDesc(item) {
        if (item.valType == "PERCENT" || item.valType == "INT") {
          if (item.operator == "GT") {
            return "大于"
          } else if (item.operator == "LT") {
            return "小于"
          } else {
            return "未知的操作类型" + item.operator;
          }
        } else if (item.valType == "RATING") {
          if (item.operator == "GT") {
            return "劣于"
          } else if (item.operator == "LT") {
            return "优于"
          } else {
            return "未知的操作类型" + item.operator;
          }
        } else {
          return "未知的值类型" + item.valType;
        }
      },

      goCreateCompileTask() {
        this.goToNewWindowPage(this, 'AppCompileTaskDetail', { bizId: this.bizId, appId: this.appId });
      },

      addSonarMetricsChange() {
        this.sonarMetricsAllList.some((item) => {
          if (this.sonarMetricsAddTempInfo.name == item.name) {
            this.sonarMetricsAddTempInfo.descriptionZh = item.descriptionZh;
            this.sonarMetricsAddTempInfo.operator = item.defaultOperator;
            this.sonarMetricsAddTempInfo.valType = item.valType;
            this.sonarMetricsAddTempInfo.valueError = item.defaultValueError;
            return true;
          }
          return false;
        });
      },

      handleCloseAddSonarMetricsDialog() {
        setTimeout(() => {
          this.$refs["addSonarMetricsForm"].resetFields();
          this.dialogAddSonarMetricsVisible = false;
          this.sonarMetricsAddTempInfo.name = "";
          this.sonarMetricsAddTempInfo.descriptionZh = "";
          this.sonarMetricsAddTempInfo.operator = "";
          this.sonarMetricsAddTempInfo.valType = "";
          this.sonarMetricsAddTempInfo.valueError = "";
        }, 100);
      },

      //添加Sonar质量阀指标
      addSonarQualityGateMetrics() {
        this.dialogAddSonarMetricsVisible = true;
      },

      submitAddSonarMetrics() {
        this.$refs["addSonarMetricsForm"].validate(valid => {
          if (valid) {
            var existsFlag = false;

            if (!this.pipelineTaskTempInfo.sonarMetricsList) {
              this.pipelineTaskTempInfo.sonarMetricsList = [];
            }

            this.pipelineTaskTempInfo.sonarMetricsList.some((element, index) => {
              if (element.name == this.sonarMetricsAddTempInfo.name) {
                this.$message({
                  message: "此质量阀指标已存在！",
                  type: "warning"
                });
                existsFlag = true;
                return true;
              } else {
                return false;
              }
            });

            if (!existsFlag) {
              this.pipelineTaskTempInfo.sonarMetricsList.push({
                name: this.sonarMetricsAddTempInfo.name,
                descriptionZh: this.sonarMetricsAddTempInfo.descriptionZh,
                valType: this.sonarMetricsAddTempInfo.valType,
                operator: this.sonarMetricsAddTempInfo.operator,
                valueError: this.sonarMetricsAddTempInfo.valueError
              });
            }
            ;

            this.handleCloseAddSonarMetricsDialog();
          }
        });
      },

      changeCodeScanningType() {
        if ("SONARQUBE" == this.pipelineTaskTempInfo.taskType || "SONARQUBE_OPPO_RULE" == this.pipelineTaskTempInfo.taskType) {
          let params = {
            pageNum: 1,
            pageSize: 500,
          };
          $http.get($http.api.pipeline.sonarMetricsList, params).then(res => {
            if (res.status == 200) {
              this.sonarMetricsAllList = res.data.list;
            } else {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            }
          });

          //TODO 代码扫描第一版默认质量阀不可编辑，此处直接设置使用默认质量阀的值，后期开放质量阀编辑功能时需要删除掉这一段代码，并将页面上的输入框/选择框等设置为可编辑状态即可
          this.pipelineTaskTempInfo.sonarMetricsList = [];
        }
      },

      //初始化编辑页面
      initPage() {
        let urlParams = this.getUrlParams();

        this.bizId = urlParams.bizId;
        this.appId = urlParams.appId;
        this.operation = urlParams.operation;
        this.getCompileTaskLst();
        if (this.operation && this.operation == 'view') {
          //查看流水线详情入口
          this.pipelineId = urlParams.pipelineId;
          this.renderPipelineViewPage();
        } else if (this.operation && this.operation == 'edit') {
          //编辑流水线
          this.pipelineId = urlParams.pipelineId;
          this.renderPipelineViewPage();
          document.getElementById("editBtn").click();
        } else if (this.operation && this.operation == 'create') {
          //创建流水线
          this.templateType = urlParams.templateType;
          this.templatePipelineId = urlParams.templatePipelineId;
          this.renderPipelineCreatePage();
          document.getElementById("editBtn").click();
        } else {
          this.goToPage(this, "appPipelineList", { bizId: this.bizId, appId: this.appId });
        }
      },

      renderPipelineViewPage() {
        this.getApplication();
        var div_box = document.getElementsByClassName("content-box");
        div_box.height = document.body.offsetHeight - 90 + "px";

        this.getPage();

        this.getpersonperlist();
        this.getroleperlist();
        document.getElementsByClassName("shadeshow")[0].style.display = "black";
      },

      renderPipelineCreatePage() {
        this.getApplication();
        var div_box = document.getElementsByClassName("content-box");
        div_box.height = document.body.offsetHeight - 90 + "px";

        this.getPipelineCreatePage();

        this.getpersonperlist();
        this.getroleperlist();
        document.getElementsByClassName("shadeshow")[0].style.display = "black";
      },

      //获取创建流水线模板数据
      getPipelineCreatePage() {
        this.tmpPipelineId = "";
        $http
          .get($http.api.pipeline.template, { appId: this.appId, templateType: this.templateType, templatePipelineId: this.templatePipelineId })
          .then(res => {
            this.handlePipelineDetailsData(res);
          });
      },

      getTaskName(item) {
        let name = "";
        if (item.autoExec) {
          name = this.typeOptions[item.type] + " [自动]";
        } else {
          name = this.typeOptions[item.type] + " [手动]";
        }
        return name;
      },

      handlePipelineDetailsData(res) {
        if (res != undefined) {
          var datas = res.data;
          for (var key_a in datas) {
            for (var key_b in this.pipelineInfo) {
              if (key_a == key_b) {
                this.pipelineInfo[key_b] = datas[key_a];
              }
            }
          }
          if (datas) {
            if (datas.triggerMode != this.WORKFLOW_TRIGGER_TYPE.AUTO_TRIGGER) {
              this.pipelineInfo.githookSettingLst = [];
            }

            this.pipelineInfo.triggerMode = datas.triggerMode;
            this.stageLst = datas.stageLst;
            this.tmpPipelineId = datas.id;
            for (var key1 in datas.timingSetting) {
              for (var key2 in this.pipelineInfo) {
                if (key1 == key2) {
                  this.pipelineInfo[key2] = datas.timingSetting[key1];
                }
              }
            }

            if (!datas.timingSetting || !datas.timingSetting.executeWeekdays) {
              this.pipelineInfo.executeWeekdays = [];
            } else {
              this.pipelineInfo.executeWeekdays = datas.timingSetting.executeWeekdays.split(",");
            }
          }
        }
      },

      //应用基本信息配置查询
      getApplication() {
        $http.get($http.api.appdate.api_application_basic_info, { appId: this.appId })
          .then(res => {
            if (res.status == 200) {
              this.appcodeinfo = res.data;
              if (this.appcodeinfo) {
                this.getpageCode();
              }
            } else {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            }
          });
      },

      //查询人员信息
      getpersonperlist() {
        $http
          .get($http.api.pipeline.appMember, { appId: this.appId })
          .then(res => {
            if (res.status == 200) {
              this.personperlist = [];
              let allPersonMap = new Map();
              if (res.data.appDevMembers) {
                res.data.appDevMembers.forEach(item => {
                  allPersonMap.set(item.userId, item);
                });
              }
              if (res.data.appTestMembers) {
                res.data.appTestMembers.forEach(item => {
                  allPersonMap.set(item.userId, item);
                });
              }
              if (res.data.appOwner) {
                allPersonMap.set(res.data.appOwner.userId, res.data.appOwner);
              }
              allPersonMap.forEach(item => {
                this.personperlist.push(item);
              });
            }

          });
      },

      //查询角色人员信息
      getroleperlist() {
        $http.get($http.api.pipeline.systemRole, {}).then(res => {
          if (res != undefined) {
            let arr = res.data;
            arr.forEach((item, index) => {
              if (item.roleType == 0) {
                arr.splice(index, 1);
              }
            });
            this.objpersonList = arr;
          }
        });
      },

      //保存流水线后拉去流水线数据
      getPage() {
        this.tmpPipelineId = "";
        $http
          .get($http.api.pipeline.configDetailsV2, { pipelineId: this.pipelineId })
          .then(res => {
            this.handlePipelineDetailsData(res);
          });
      },

      //获取代码分支信息
      getpageCode() {
        if (this.appcodeinfo.appType != 5) {
          //非多仓库应用获取分支信息
          $http.get($http.api.pipeline.appBranchCompleteInfo, {
            appId: this.appId
          }).then(res => {
            this.pipelineInfo.sourceRepo = res.data.sourceRepo;
            var branchLst = res.data.branchLst;
            this.allBranchList = branchLst.concat(res.data.tagLst);
            this.pureBranchList = res.data.branchLst;
          });
        } else {
          //多仓库应用获取分支信息
          $http.get($http.api.appdate.appBranchList, {
            appId: this.appId
          }).then((res) => {
            let data = res.data.data;
            data.sort((a, b) => {
              return a.subAppId.localeCompare(b.subAppId);
            });
            this.multiRepoApplicationBranchList = data;
          });
        }
      },

      autoTriggerMultiRepoChange(param) {
        param.sourceBranch="";

      },

      autoTriggerMultiRepoSourceBranchList(param) {
        if (!param.sourceRepo) {
          return new Array();
        }
        let branchList = new Array();
        if (this.multiRepoApplicationBranchList) {
          this.multiRepoApplicationBranchList.forEach((item, index) => {
            if (param.sourceRepo == item.sourceRepo) {
              if (item.branchBos && item.branchBos.length > 0) {
                item.branchBos.forEach((branch, index2) => {
                  branchList.push({name:branch.sourceBranch});
                });
              }
            }
          });
        }
        return branchList;
      },

      cancelPipelineEdit() {
        if (this.operation == 'create') {
          //创建阶段还未保存就点击取消，此时直接返回流水线列表页面
          this.goToPage(this, "appPipelineList", { bizId: this.bizId, appId: this.appId });
          return;
        }

        this.disabledform = true;
        document.getElementsByClassName("shadeshow")[0].style.display = "block";
        this.$refs["pipelineInfoForm"].resetFields();
        this.btneye = "2";
        this.getPage();
        if (this.appcodeinfo) {
          this.getpageCode();
        }
      },

      //流水线阶段配置打开弹窗
      addcontent(val) {
        this.indexvip = val;
        this.titleLine = "流水线阶段配置";
        this.newType = "add";
        this.dialogVisible = true;
      },

      editStage(params) {
        this.dialogVisible = true;
        this.pipelineStageTempInfo.name = params.name;
        this.newIndex = params.index;
        this.titleLine = "流水线阶段配置编辑";
        this.newType = "edit";
      },

      deleteStage(stageName) {
        if (this.stageLst.length == 1) {
          this.$message({
            message: "不可操作！",
            type: "warning"
          });
        } else {
          this.$confirm("确定要删除吗？", "删除提示", {
            confirmButtonText: "确定"
          })
            .then(() => {
              this.stageLst.forEach((item, index) => {
                if (item.name == stageName) {
                  var ind = index;
                  this.stageLst.splice(ind, 1);
                }
              });
            })
            .catch(() => {
            });
        }
      },
      // 流水线阶段配置关闭弹窗
      handleClose() {
        setTimeout(() => {
          this.$refs["pipelineStageTempInfoForm"].resetFields();
          this.dialogVisible = false;
        }, 100);
      },

      //流水线阶段配置取消弹窗
      callStageEdit() {
        this.handleClose();
      },

      //流水线阶段配置新增提交弹窗内容
      submitBtn() {
        this.$refs["pipelineStageTempInfoForm"].validate(valid => {
          if (valid) {
            var json = { name: this.pipelineStageTempInfo.name };
            if (this.newType == "add") {
              var flag = false;
              this.stageLst.forEach((element, index) => {
                if (element.name == json.name) {
                  this.$message({
                    message: "此阶段已存在！",
                    type: "warning"
                  });
                  flag = true;
                }
              });
              if (flag == false) {
                this.stageLst.forEach((item, index) => {
                  json["order"] = index + 1;
                });
                if (!json.pipelineTaskLst) {
                  json["pipelineTaskLst"] = [];
                }
                this.stageLst.splice(this.indexvip + 1, 0, json);
              }
            } else if (this.newType == "edit") {
              this.stageLst[this.newIndex].name = "";
              this.stageLst[this.newIndex].name = json.name;
            }

            this.handleClose();
          }
        });
      },

      // ===========================================
      //编译任务信息获取
      getCompileTaskLst() {
        let params = { appId: this.appId };
        $http.get($http.api.compile.compiling_list, params).then(res => {
          if (res.status === 200) {
            this.compileTaskList = res.data.list;
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      // ===========================================
      //部署任务信息获取
      getpagedeploy(val) {
        var params = { appCode: this.appcodeinfo.appCode, env: val };
        $http.get($http.api.deploy.apideployplanlist, params).then(res => {
          if (res.status == 200) {
            this.deploymentTaskList = res.data;
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },
      // =====================================
      // 任务类型选择
      changeTaskType(curTaskType) {
        if (curTaskType == this.WORKFLOW_TASK_TYPE.SUBMIT_TEST) {
          this.pipelineTaskTempInfo.person = [];
          this.pipelineTaskTempInfo.proPerson = 0;
          this.pipelineTaskTempInfo.person[0] = 'APP_OWNER';
          this.pipelineTaskTempInfo.person[1] = 'APP_DEVELOPER';
          this.disabled_persion = true;
        } else if (curTaskType == this.WORKFLOW_TASK_TYPE.PASS_TEST) {
          this.pipelineTaskTempInfo.person = [];
          this.pipelineTaskTempInfo.proPerson = 0;
          this.pipelineTaskTempInfo.person[0] = 'APP_TESTER';
          this.disabled_persion = true;
        } else if (curTaskType == this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT) {
          this.pipelineTaskTempInfo.person = [];
          this.disabled_persion = false;
        }
      },

      //接口自动化和UI自动化公用方法（检查应用是否绑定测试任务）
      check_binded(arr) {
        this.$confirm('应用' + '【' + this.appcodeinfo.appCode + '】' + arr.val1, '提示', {
          confirmButtonText: '去绑定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          window.open(arr.val2, "_blank");
        }).catch(() => {

        });


      },

      //选择部署环境获取部署任务
      changeenvBtn(val) {
        this.pipelineTaskTempInfo.deployPlanName = '';
        this.getpagedeploy(val);
      },

      //添加任务打开弹窗
      addcontentadd(val) {
        this.titleTask = "添加任务";
        this.nowType = "add";
        this.currentAddTaskStageName = val;
        this.adddialogVisible = true;
        this.pipelineTaskTempInfo;
        this.getpersonperlist();
      },


      //添加任务关闭弹窗
      addhandleClose() {
        this.$set(this.pipelineTaskTempInfo, "type", "");
        this.$set(this.pipelineTaskTempInfo, "name", "");
        this.$set(this.pipelineTaskTempInfo, "environment", "");
        this.$set(this.pipelineTaskTempInfo, "proPerson", "");
        this.$set(this.pipelineTaskTempInfo, "transferType", "");
        this.$set(this.pipelineTaskTempInfo, "taskType", "");
        this.$set(this.pipelineTaskTempInfo, "autoExec", null);
        this.$set(this.pipelineTaskTempInfo, "deploymentTask", "");
        this.$set(this.pipelineTaskTempInfo, "deployPlanName", "");
        this.$set(this.pipelineTaskTempInfo, "shellScriptContent", "");
        this.$set(this.pipelineTaskTempInfo, "person", []);
        this.$set(this.pipelineTaskTempInfo, "people", []);
        this.$set(this.pipelineTaskTempInfo, "sonarMetricsList", []);
        this.disabled_persion = false;
        this.adddialogVisible = false;
        this.$refs["pipelineTaskTempInfoForm"].clearValidate();
      },

      //任务提交弹窗内容
      saveTaskSetting() {
        this.$refs["pipelineTaskTempInfoForm"].validate(valid => {
          if (valid) {
            var taskSettingJsonStr = "";
            var json = {};
            if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.BUILD) {
              this.pipelineTaskTempInfo.autoExec = true;
              json["transferType"] = this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER;
              if (this.pipelineTaskTempInfo.compileTaskUUID == "") {
                this.$message({
                  message: "编译任务不能为空！",
                  type: "warning"
                });
                return;
              }
              taskSettingJsonStr = JSON.stringify({
                compileTaskUUID: this.pipelineTaskTempInfo.compileTaskUUID
              });
            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
              if (this.pipelineTaskTempInfo.autoExec == true) {
                taskSettingJsonStr = JSON.stringify({
                  deployPlanId: this.pipelineTaskTempInfo.deployPlanName,
                  environment: this.pipelineTaskTempInfo.environment
                });
                json["transferType"] = this.pipelineTaskTempInfo.transferType;
              } else if (this.pipelineTaskTempInfo.autoExec == false) {
                json["transferType"] = this.TRANSFER_TYPE.FINISHED_TRANSFER;
                taskSettingJsonStr = JSON.stringify({
                  environment: this.pipelineTaskTempInfo.environment
                });
              }

            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.CODE_SCANNING) {
              if (this.pipelineTaskTempInfo.taskType == "SONARQUBE" || this.pipelineTaskTempInfo.taskType == "SONARQUBE_OPPO_RULE") {
                taskSettingJsonStr = JSON.stringify({
                  taskType: this.pipelineTaskTempInfo.taskType,
                  sonarMetricsList: this.pipelineTaskTempInfo.sonarMetricsList
                });
              } else {
                taskSettingJsonStr = JSON.stringify({ taskType: this.pipelineTaskTempInfo.taskType });
              }
              this.pipelineTaskTempInfo.autoExec = true;
              json["transferType"] = this.pipelineTaskTempInfo.transferType;
            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.AUTO_TEST) {
              taskSettingJsonStr = "";
              this.pipelineTaskTempInfo.autoExec = true;
              json["transferType"] = this.pipelineTaskTempInfo.transferType;
            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT) {
              taskSettingJsonStr = JSON.stringify({
                shellScriptContent: this.pipelineTaskTempInfo.shellScriptContent
              });
              json["transferType"] = this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER;
            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT) {
              if (this.pipelineTaskTempInfo.proPerson == 0) {
                taskSettingJsonStr = JSON.stringify({
                  type: this.pipelineTaskTempInfo.proPerson,
                  role: this.pipelineTaskTempInfo.person.toString()
                });
              } else if (this.pipelineTaskTempInfo.proPerson == 1) {
                taskSettingJsonStr = JSON.stringify({
                  type: this.pipelineTaskTempInfo.proPerson,
                  people: this.pipelineTaskTempInfo.people.toString()
                });
              }
              this.pipelineTaskTempInfo.autoExec = false;
              json["transferType"] = this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER;
            } else if (
              this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.SUBMIT_TEST ||
              this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.PASS_TEST
            ) {
              if (this.pipelineTaskTempInfo.proPerson == 0) {
                taskSettingJsonStr = JSON.stringify({
                  type: this.pipelineTaskTempInfo.proPerson,
                  role: this.pipelineTaskTempInfo.person.toString()
                });
              } else if (this.pipelineTaskTempInfo.proPerson == 1) {
                taskSettingJsonStr = JSON.stringify({
                  type: this.pipelineTaskTempInfo.proPerson,
                  people: this.pipelineTaskTempInfo.people.toString()
                });
              }

              if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.PASS_TEST) {
                this.pipelineTaskTempInfo.autoExec = false;
              }
              json["transferType"] = this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER;
            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.UNIT_TEST) {
              taskSettingJsonStr = JSON.stringify({
                mvnCommand: this.pipelineTaskTempInfo.mvnCommand
              });
              json["transferType"] = this.pipelineTaskTempInfo.transferType;
              this.pipelineTaskTempInfo.autoExec = true;
            } else if (this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE) {
              this.pipelineTaskTempInfo.autoExec = true;
              json["transferType"] = this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER;
            } else if(this.pipelineTaskTempInfo.type == this.WORKFLOW_TASK_TYPE.MVN_DEPLOY) {
              if(this.pipelineTaskTempInfo.deployMvnBranches){
                taskSettingJsonStr = JSON.stringify({
                  deployMvnBranches: this.pipelineTaskTempInfo.deployMvnBranches
                });
              }
            }

            json["autoExec"] = this.pipelineTaskTempInfo.autoExec;
            json["name"] = this.pipelineTaskTempInfo.name;
            json["type"] = this.pipelineTaskTempInfo.type;
            json["setting"] = taskSettingJsonStr;

            if (this.nowType == "add") {
              if (this.stageLst.length != 0) {
                this.stageLst.forEach((item, index) => {
                  if (item.name == this.currentAddTaskStageName) {
                    if (item.pipelineTaskLst.length > 0) {
                      var flag = false;
                      item.pipelineTaskLst.forEach((r, index) => {
                        if (r.name == json.name) {
                          this.$message({
                            message: "此条目录已经存在！",
                            type: "warning"
                          });
                          flag = true;
                        }
                      });
                      if (flag == false) {
                        json["order"] = item.pipelineTaskLst.length;
                        item.pipelineTaskLst.push(json);
                      }
                    } else if (item.pipelineTaskLst.length == 0) {
                      json["order"] = 0;
                      item.pipelineTaskLst.push(json);
                    }
                  }
                });
              }
            } else if (this.nowType == "edit") {
              this.stageLst.forEach((item, index) => {
                if (item.name == this.currentEditTask.stageName) {
                  item.pipelineTaskLst[this.nowIndex] = {};
                  item.pipelineTaskLst[this.nowIndex] = json;
                }
              });
            }

            this.addhandleClose();
          }
        });
      },


      //任务编辑阶段中的内容
      editTask(params) {
        this.adddialogVisible = true;
        if (params.taskType == this.WORKFLOW_TASK_TYPE.SUBMIT_TEST || params.taskType == this.WORKFLOW_TASK_TYPE.PASS_TEST) {
          this.disabled_persion = true;
        } else {
          this.disabled_persion = false;
        }
        if (params.taskType == this.WORKFLOW_TASK_TYPE.DEPLOY) {
          let parsedDeployTaskSetting = JSON.parse(params.taskSetting);
          this.getpagedeploy(parsedDeployTaskSetting.environment);
        }
        this.currentEditTask = params;
        this.titleTask = "编辑任务";
        this.nowType = "edit";
        this.nowIndex = params.index;
        this.pipelineTaskTempInfo.environment = "";
        this.pipelineTaskTempInfo.transferType = "";
        this.getpersonperlist();

        this.$nextTick(function () {
          this.stageLst.forEach((i, index) => {
            if (i.name == params.stageName) {
              i.pipelineTaskLst.forEach((j, index) => {
                if (j.name == params.taskName) {
                  this.pipelineTaskTempInfo.name = j.name;
                  this.pipelineTaskTempInfo.type = j.type;
                  this.pipelineTaskTempInfo.autoExec = j.autoExec;
                  this.pipelineTaskTempInfo.transferType = j.transferType;
                  if (j.type == this.WORKFLOW_TASK_TYPE.BUILD) {
                    if (!j.setting || null === j.setting || "" === j.setting) {
                      this.pipelineTaskTempInfo.compileTaskUUID = "";
                    } else {
                      this.pipelineTaskTempInfo.compileTaskUUID = JSON.parse(
                        j.setting
                      ).compileTaskUUID;
                      if (this.pipelineTaskTempInfo.compileTaskUUID != "") {
                        this.selectCompileTask(this.pipelineTaskTempInfo.compileTaskUUID)
                      }
                    }
                  }
                  if (j.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
                    if (j.autoExec == true) {
                      this.pipelineTaskTempInfo.deployPlanName = JSON.parse(
                        j.setting
                      ).deployPlanId;
                      this.pipelineTaskTempInfo.environment = JSON.parse(
                        j.setting
                      ).environment;
                      this.pipelineTaskTempInfo.transferType = j.transferType;
                      // ===================================
                    } else if (j.autoExec == false) {
                      this.pipelineTaskTempInfo.environment = JSON.parse(
                        j.setting
                      ).environment;
                      // this.pipelineTaskTempInfo.deployPlanId = '';
                      // this.pipelineTaskTempInfo.transferType = j.transferType;
                    }
                  }
                  if (j.type == this.WORKFLOW_TASK_TYPE.CODE_SCANNING) {
                    this.pipelineTaskTempInfo.taskType = JSON.parse(
                      j.setting
                    ).taskType;
                    if (this.pipelineTaskTempInfo.taskType == "SONARQUBE" || this.pipelineTaskTempInfo.taskType == "SONARQUBE_OPPO_RULE") {
                      this.pipelineTaskTempInfo.sonarMetricsList = JSON.parse(
                        j.setting
                      ).sonarMetricsList;
                      this.changeCodeScanningType();
                    }
                  }
                  if (j.type == this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT) {
                    this.pipelineTaskTempInfo.shellScriptContent = JSON.parse(
                      j.setting
                    ).shellScriptContent;
                  }

                  if (
                    j.type == this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT ||
                    j.type == this.WORKFLOW_TASK_TYPE.SUBMIT_TEST ||
                    j.type == this.WORKFLOW_TASK_TYPE.PASS_TEST
                  ) {
                    this.pipelineTaskTempInfo.proPerson = JSON.parse(j.setting).type;
                    if (this.pipelineTaskTempInfo.proPerson == 0) {
                      this.pipelineTaskTempInfo.person = JSON.parse(
                        j.setting
                      ).role.split(",");
                    } else {
                      this.pipelineTaskTempInfo.people = JSON.parse(
                        j.setting
                      ).people.split(",");
                    }
                  }

                  if (j.type == this.WORKFLOW_TASK_TYPE.UNIT_TEST) {
                    this.pipelineTaskTempInfo.mvnCommand = JSON.parse(
                      j.setting
                    ).mvnCommand;
                  }
                }
              });
            }
          });
        });
      },

      //删除阶段中的任务
      deleteTask(params) {
        this.$confirm("确定删除吗？", "删除提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        })
          .then(() => {
            this.stageLst.forEach((i, index_1) => {
              if (i.name == params.stageName) {
                if (i.pipelineTaskLst.length > 0) {
                  i.pipelineTaskLst.forEach((j, index_2) => {
                    if (j.name == params.taskName) {
                      var index = index_2;
                      this.$set(
                        this.stageLst,
                        i.pipelineTaskLst,
                        i.pipelineTaskLst.splice(index, 1)
                      );
                    }
                  });
                }
              }
            });
          })
          .catch(() => {

          });
      },

      //数据保存提交
      savePipelineInfo() {
        this.$refs["pipelineInfoForm"].validate(valid => {
          if (valid) {
            if (this.btnSaveDisabled) {
              return;
            }
            if (this.pipelineInfo.triggerMode == this.WORKFLOW_TRIGGER_TYPE.TIMING_TRIGGER) {
              let timesmall_head1 = parseInt(
                this.pipelineInfo.scheduleStartTime.split(":")[0]
              );
              let timesmall_head2 = parseInt(
                this.pipelineInfo.scheduleStartTime.split(":")[1]
              );
              let timesmall_footer1 = parseInt(
                this.pipelineInfo.scheduleEndTime.split(":")[0]
              );
              let timesmall_footer2 = parseInt(
                this.pipelineInfo.scheduleEndTime.split(":")[1]
              );
              if (timesmall_head1 > timesmall_footer1) {
                this.$message({
                  message: "时间范围，起始时间不能大于结束时间",
                  type: "warning"
                });
                this.btnSaveDisabled = false;
                return;
              } else if (timesmall_head1 == timesmall_footer1
                && timesmall_head2 > timesmall_footer2) {
                this.$message({
                  message: "时间范围，起始时间不能大于结束时间",
                  type: "warning"
                });
                this.btnSaveDisabled = false;
                return;
              }
            }

            let canContinue = true;
            let isPlanIdValue = true;
            let emptyStageName = '';
            let emptyPlanStageName = '';
            this.stageLst.every((i, index_i) => {
              if (i.order) {
                delete i.order;
              }
              i["order"] = index_i;
              //如果当前stage下没有任务，则不允许保存
              if (i.pipelineTaskLst.length <= 0) {
                emptyStageName = i.name;
                canContinue = false;
                return false;
              }
              i.pipelineTaskLst.forEach((j, index_j) => {
                if (j.order) {
                  delete j.order;
                }

                j["order"] = index_j;
                if (j.type === 'DEPLOY' && j.autoExec === true) {
                  let nowDeployPlanName = JSON.parse(
                    j.setting
                  ).deployPlanId;
                  if (!nowDeployPlanName) {
                    isPlanIdValue = false;
                    emptyPlanStageName = j.name;
                    return false;
                  }
                }
              });
              return true;
            });
            if (!canContinue) {
              this.$message({
                message: "阶段[" + emptyStageName + "]中不包含任何任务",
                type: 'error'
              });
              this.btnSaveDisabled = false;
              return;
            }
            if (!isPlanIdValue) {
              this.$message({
                message: "阶段[" + emptyPlanStageName + "]中需要配置部署任务",
                type: 'error'
              });
              this.btnSaveDisabled = false;
              return;
            }

            let params = {
              id: this.tmpPipelineId,
              name: this.pipelineInfo.name,
              stageLst: this.stageLst,
              bizId: this.bizId,
              appId: this.appId,
              defaultPipeline: this.pipelineInfo.defaultPipeline,
              defaultBranch: this.pipelineInfo.defaultBranch,
              createOrder: this.pipelineInfo.createOrder,
              uuid: this.pipelineInfo.uuid,
              type: this.pipelineInfo.type ? this.pipelineInfo.type : 0,
              developMode: this.appcodeinfo.developMode,
              featureBranchType: this.pipelineInfo.featureBranchType
            };

            if (this.pipelineInfo.triggerMode == this.WORKFLOW_TRIGGER_TYPE.MANUAL_TRIGGER) {
              params.triggerMode = this.WORKFLOW_TRIGGER_TYPE.MANUAL_TRIGGER;
            } else if (this.pipelineInfo.triggerMode == this.WORKFLOW_TRIGGER_TYPE.TIMING_TRIGGER) {
              if (this.pipelineInfo.scheduleStartTime.length == 5) {
                this.pipelineInfo.scheduleStartTime =
                  this.pipelineInfo.scheduleStartTime + ":00";
              }
              if (this.pipelineInfo.scheduleEndTime.length == 5) {
                this.pipelineInfo.scheduleEndTime =
                  this.pipelineInfo.scheduleEndTime + ":00";
              }
              params.triggerMode = this.WORKFLOW_TRIGGER_TYPE.TIMING_TRIGGER;
              params.timingSetting = {};
              params.timingSetting.scheduleStartTime = this.pipelineInfo.scheduleStartTime ? this.pipelineInfo.scheduleStartTime : "";
              params.timingSetting.scheduleEndTime = this.pipelineInfo.scheduleEndTime ? this.pipelineInfo.scheduleEndTime : "";
              params.timingSetting.interval = this.pipelineInfo.interval;
              params.timingSetting.executeWeekdays = this.pipelineInfo.executeWeekdays.join(",");
            } else if (this.pipelineInfo.triggerMode == this.WORKFLOW_TRIGGER_TYPE.AUTO_TRIGGER) {
              params.triggerMode = this.WORKFLOW_TRIGGER_TYPE.AUTO_TRIGGER;
              let checkGithook = false;
              if (this.pipelineInfo.githookSettingLst
                && this.pipelineInfo.githookSettingLst.length != 0
                && this.pipelineInfo.githookSettingLst.length != null) {
                this.pipelineInfo.githookSettingLst.forEach(item => {
                  if (item.sourceRepo == "" || item.sourceBranch == "" || item.event == "") {
                    checkGithook = true;
                    this.btnSaveDisabled = false;
                    this.$message({
                      message: "请完整选择代码仓库、分支及触发事件！",
                      type: "warning"
                    });
                  }
                });
                if (checkGithook) {
                  return;
                }
              } else if (this.pipelineInfo.githookSettingLst
                && (this.pipelineInfo.githookSettingLst.length == 0
                  || this.pipelineInfo.githookSettingLst.length == null)) {
                this.btnSaveDisabled = false;
                this.$message({
                  message: "请添加监听的代码仓库和分支！",
                  type: "warning"
                });
                return;
              }

              this.pipelineInfo.githookSettingLst.forEach((item, index) => {
                delete item.key;
              });
              params.githookSettingLst = this.pipelineInfo.githookSettingLst;
            }
            this.btnSaveDisabled = true;
            $http.post($http.api.pipeline.save, params).then(res => {
              if (res.status == 200) {
                this.$message({
                  message: "保存流水线信息成功",
                  type: "success"
                });
                this.disabledform = true;
                this.btneye = "2";
                document.getElementsByClassName("shadeshow")[0].style.display = "block";
                this.refreshPage(res.data);
              }
              this.btnSaveDisabled = false;
            }).catch((error) => {
              this.btnSaveDisabled = false;
            });
          }
        });
      },

      //流水线创建，保存成功的时候重新刷新页面使用
      refreshPage(pipelineId) {
        this.$router.replace({ name: 'appPipeline', query: { bizId: this.bizId, appId: this.appId, operation: 'view', pipelineId: pipelineId } }, ()=>{
          //主动触发重新加载页面元素和数据
          this.initPage();
        });
      },

      //切换到流水线编辑模式
      switchToEdit() {
        this.disabledform = false;
        this.btneye = "1";
        document.getElementsByClassName("shadeshow")[0].style.display = "none";
      },


      switchDefaultPipeline() {
        if (this.pipelineInfo.defaultPipeline) {
          return false;
        }

        if (!this.pipelineInfo.pkgable) {
          this.$confirm("当前流水线未设置构建任务（或暂时未保存），设置后[生成版本]时将不会自动选中为默认流水线，是否继续设置为默认流水线", "提示", {
            distinguishCancelAndClose: true,
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: "warning"
          }).then(() => {
            this.switchDefaultPipelineRequest();
          }).catch(() => {

          });
        } else {
          this.switchDefaultPipelineRequest();
        }
      },

      switchDefaultPipelineRequest() {
        let formData = new FormData();
        formData.set("appId", this.appId);
        formData.set('pipelineId', this.pipelineId);
        $http.post($http.api.pipeline.switchDefaultPipeline, formData).then(response => {
          if (response.status == 200) {
            this.pipelineInfo.defaultPipeline = true;
            this.$message({
              message: "当前流水线已设置为默认流水线",
              type: "success"
            });
          }
        });
      },

      //删除监听代码库
      removeDomain(item) {
        let index = this.pipelineInfo.githookSettingLst.indexOf(item);
        if (index !== -1) {
          this.pipelineInfo.githookSettingLst.splice(index, 1);
        }
      },

      //添加监听代码库
      addDomain() {
        if (this.pipelineInfo.githookSettingLst == null) {
          this.pipelineInfo.githookSettingLst = [];
        }
        let tempParam = {};
        if (this.appcodeinfo) {
          if (this.appcodeinfo.appType != 5) {
            //非多仓库应用默认设置触发自动集成仓库为当前应用的git仓库
            tempParam = {
              sourceRepo: this.pipelineInfo.sourceRepo,
              sourceBranch: "",
              event: "",
              key: Date.now()
            };
          } else {
            //多仓库应用，默认不设置自动集成的git仓库，由用户自主选择
            tempParam = {
              sourceRepo: "",
              sourceBranch: "",
              event: "",
              key: Date.now()
            };
          }
        }

        this.pipelineInfo.githookSettingLst.push(tempParam);
      },

      //拖动方法
      datadragEnd(evt) {
        evt.preventDefault();
      }
    },
    components: {
      draggable
    }
  };
</script>

<style lang="scss" scoped>
  .go-back {
    height: 25px;

    .go-back-text {
      position: relative;
      top: 13px;
      left: 14px;
    }
  }

  .streamLineheader {
    min-height: 250px;
    border: 1px solid #dde5ef;
    font-size: 13px;
    box-sizing: border-box;
    background: #fff;
    padding: 0px 5px 5px 5px;
    margin: 0px;
    box-shadow: none;
    margin-bottom: 5px;
  }

  .streambody {
    border: 1px solid #dde5ef;
    position: relative;

    .shadeshow {
      display: none;
      position: absolute;
      display: inline-block;
      top: 0;
      left: 5px;
      width: calc(100% - 7px);
      height: 100%;
      background-color: #e6e1e1;
      z-index: 1001;
      -moz-opacity: 0.1;
      opacity: 0.1;
      filter: alpha(opacity=30);
    }

    .step_modulepar {
      width: calc(25% - 20px);
      display: inline-block;
      margin-top: 20px;
      margin-bottom: 20px;
      margin-left: 15px;
      min-width: 370px;
      vertical-align: top;

      .step_module {
        min-height: 420px;
        height: -webkit-calc(100%);
        width: 88%;
        display: inline-block;
        border: 1px solid black;
        vertical-align: top;

        .modulehead {
          height: 60px;
          background: #606266;
          position: relative;

          .moduletitle {
            float: left;
            padding-left: 10px;
            padding-top: 1px;
            line-height: 30px;
            font-size: 25px;
            color: beige;
            width: 200px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
          }

          .el-icon-edit {
            cursor: pointer;
            font-size: 25px;
            color: beige;
            padding: 5px;
            position: absolute;
            left: 78%;
          }

          .el-icon-delete {
            cursor: pointer;
            font-size: 25px;
            color: beige;
            padding: 5px;
            position: absolute;
            left: 90%;
          }
        }

        .moduleBody {
          .moduleBody_a {
            height: 60px;
            font-size: 20px;
            position: relative;

            .moduleBody_a_son {
              cursor: move;
              display: inline-block;
              margin-left: 15px;
              font-size: 16px;
              font-weight: 500;
              width: 280px;
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
            }

            .moduleBody_a_son2 {
              cursor: move;
              margin-left: 15px;
              margin-right: 10px;
              margin-top: -5px;
              font-size: 13px;
              color: #b8b8b8;
              border-bottom: 1px solid black;
            }

            .el-icon-delete {
              float: right;
              font-size: 20px;
              // margin-top: 10px;
              // margin-right: 10px;
              position: absolute;
              top: 5px;
              left: 92%;
              color: red;
              cursor: pointer;
            }

            .el-icon-edit {
              float: right;
              font-size: 20px;
              // margin-top: 10px;
              // margin-right: 10px;
              position: absolute;
              top: 5px;
              left: 85%;
              cursor: pointer;
            }

            .el-input__inner {
              color: #676c77;
              background-color: #ffffff !important;
            }

            .el-input-group__append {
              background: #ffffff;
            }
          }

          .moduleBody_c {
            height: 30px;
            width: 100px;
            border: 1px solid rgb(175, 166, 166);
            font-size: 20px;
            margin-top: 20px;
            margin-right: 20px;
            margin-bottom: 20px;
            float: right;
            cursor: pointer;
            border-radius: 5px;
          }

          .moduleBody_c:hover {
            color: #409eff;
            border-color: #409eff;
          }
        }
      }

      .add {
        width: 10%;
        display: inline-block;
        height: 400px;
        float: right;
        padding-left: 5px;

        .el-icon-circle-plus-outline {
          cursor: pointer;
          margin-top: 10px;
          font-size: 40px;
          color: #606266;
          padding-left: 3px;
        }

        .el-icon-d-arrow-right {
          font-size: 40px;
          font-weight: 900;
          margin-top: 140px;
          display: inline-block;
          color: #606266;
          padding-left: 2px;
        }
      }
    }
  }

  .appcode_calss {
    .el-form-item {
      display: inline-block;
    }
  }

  .card_border {
    border: 1px #4056ff solid;
  }
</style>

<style lang='scss' scoped>
  .is-checked {
    .el-radio__inner {
      border-color: #409eff !important;
      background: #409eff !important;
    }
  }

  .is-checked {
    .el-checkbox__inner {
      border-color: #409eff !important;
      background: #409eff !important;
    }
  }
</style>
