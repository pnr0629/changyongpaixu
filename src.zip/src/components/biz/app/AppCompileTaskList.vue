<template>
  <div class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box-top" style="padding-top:10px;">
          <div class="btnArea">
            <el-row type="flex" justify="space-between">
              <el-button type="success" class="mb10" @click="showDialogCompile()"
                v-if="this.appType !== this.APP_TYPE.MULTI_REPO_SHELL && authFunction('FUNC_APP_COMPILE_TASK_SAVE', 2, appId)">
                创建编译任务</el-button>
              <el-button type="primary" class="mb10" @click="getCompilingList()">刷新</el-button>
            </el-row>
          </div>
          <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
            <div class="table-box-top-bs">
              <el-table :data="compilingList.list" style="width:100%;height:100%;overflow:auto;">
                <el-table-column label="编译任务名称" show-overflow-tooltip min-width="120">
                  <template slot-scope="scope">
                    <span class="cp c-blue" @click="showCompileTask(scope.row)">
                      {{scope.row.taskName}}
                    </span>
                    <span
                      style="padding: 2px; border-radius: 2px; display: inline-block; background: #000; vertical-align: center;"
                      v-if="scope.row.defaultTask == 1">
                      <span
                        style="display: block; color: #FFFFFF; height: 14px; line-height: 14px; text-align: center">default</span>
                    </span>
                  </template>
                </el-table-column>
                <el-table-column prop="defaultBranch" show-overflow-tooltip label="默认关联分支" min-width="100">
                  <template slot-scope="scope">
                    {{scope.row.sourceBranch ? scope.row.sourceBranch :'master'}}
                  </template>
                </el-table-column>
                <el-table-column prop="updateTime" label="最近更新时间" show-overflow-tooltip min-width="80">
                </el-table-column>
                <el-table-column prop="compileStepRunningInfoBoList" label="运行状态" min-width="120">
                  <template slot-scope="scope">
                    <span class="cp" v-for="(item,index) in scope.row.compileStepRunningInfoBoList" :key="item.id"
                      @click="showCompileDetail(scope.row)">
                      <i class="iconfont" :class="getClassByRunningStatus(item.stepRunningStatus)"
                        :title="item.name"></i>
                      <i class="iconfont icon-more" v-if="scope.row.compileStepRunningInfoBoList.length-1 != index"></i>
                    </span>
                  </template>
                </el-table-column>
                <el-table-column prop="time" label="操作" min-width="120">
                  <template slot-scope="scope">
                    <template>
                      <span class="c-blue cp" @click="executePipeline(scope.row)">执行<span
                          class="cursor-text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span>
                    </template>
                    <span class="c-blue cp" @click="goToComplineExecHistory(scope.row)">历史执行记录</span>
                    &nbsp;&nbsp;&nbsp;
                    <span class="c-blue cp" @click="editCompileTask(scope.row)"
                      v-if="authFunction('FUNC_APP_COMPILE_TASK_SAVE', 2, appId)">编辑</span>
                    &nbsp;&nbsp;&nbsp;
                    <span class="c-blue cp" @click="deleteCompline(scope.row)"
                      v-if="scope.row.defaultTask !==1 && authFunction('FUNC_APP_COMPILE_TASK_DELETE', 2, appId)">删除</span>
                    &nbsp;&nbsp;&nbsp;
                    <span class="c-blue cp" @click="setDefaultTask(scope.row)"
                      v-if="scope.row.defaultTask !==1 && authFunction('FUNC_APP_COMPILE_TASK_DEFAULT', 2, appId)">设置默认</span>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="table_b_f_b">
              <el-pagination class="fr" style="margin-top: 9px;" @size-change="handlePipelineListSizeChange"
                @current-change="handlePipelineListPageChange" :current-page="compilingList.pageNum"
                :page-sizes="[10, 20, 30]" :page-size="compilingList.pageSize"
                layout="total, sizes, prev, pager, next, jumper" :total="compilingList.total">
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
    </div>

    <el-dialog title='创建编译任务' :visible.sync="dialogVisibleCompile" class="issuedialog el-dialog-400w"
      :before-close="handleCloseCompile" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form ref="createTaskDialogForm" :model="createTaskTemplateInfo">
          <el-form-item class="mt0 mb10" prop="type"
            :rules="[{required: true, message: '请选择创建编译任务模式' ,trigger: 'blur'}]">
            <el-radio-group style="display: inline-grid;" v-model="createTaskTemplateInfo.type"
              @change="handlePipelineTemplateChange">
              <el-radio class="mt5 mb10 ml0" :key="0" :label="0">创建空白编译任务</el-radio>
              <el-radio class="mt5 mb10 ml0" :key="1" :label="1">复制已有编译任务</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item class="mt10 mb10 ml10" label="复制的编译任务" prop="taskId" v-if="createTaskTemplateInfo.type==1"
            :rules="[{required: true, message: '请选择复制的编译任务' ,trigger: 'blur'}]">
            <el-select v-model="createTaskTemplateInfo.taskId" placeholder="请选择">
              <el-option v-for="item in compilingList.list" :key="item.taskId" :label="item.taskName"
                :value="item.taskId">
                <span style="float: left">{{item.taskName}}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseCompile">取消</el-button>
        <el-button type="primary" @click="newCompileTask">确定</el-button>
      </span>
    </el-dialog>

    <el-dialog title='编译任务' :visible.sync="dialogVisible_master1" class="el-dialog-400w"
      :before-close="handleClose_master1" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="packInfo" ref="packInfo" label-width="100px">
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">

            <el-col :span='24'>
              <el-form-item class='mb15' label="版本分支" label-width="100px" prop="branch" :rules="[
                   { required: true, message: '版本分支不能为空' }
               ]">
                <!-- <el-input placeholder="请输入内容" v-model="packInfo.branch"></el-input> -->
                <el-select v-model="packInfo.branch" placeholder="请选择" @change="updateData" style="width:200px;">
                  <el-option v-for="(item,index) in branchLst" :key="index" :label="item.name" :value="item.name" :title="item.name" style="width:200px;">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>

            <el-col :span='24'
              v-if="compileInfo.appType != 5 && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete class="inline-input" v-model="item.currentOption" placeholder="请输入内容"
                  style="width:200px;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false" @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)">
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>

          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleClose_master1">取消</el-button>
        <el-button type="primary" @click="goToCompiling">确定</el-button>
      </span>
    </el-dialog>
    <el-dialog title='编译任务' :visible.sync="dialogVisible_master2" class="" :modal-append-to-body="modaltobody"
      :close-on-click-modal='shadeBtn'>

      <div class="pb20" v-loading="table_loading" element-loading-text="拼命加载中">
        <el-table ref="branchTale" :border="true" :data="tableListNew.data" @select-all="selectAllEvent"
          @select='handleSelectionChange'>
          <el-table-column type="selection" width="50"></el-table-column>
          <el-table-column prop="subAppId" label="子应用ID" min-width="160"></el-table-column>
          <el-table-column prop="sourceRepo" label="源码仓库" min-width="200"></el-table-column>
          <el-table-column prop="sourceBranch" label="分支名称" min-width="180">
            <template slot-scope="scope">
              <el-select v-model="scope.row.branchBosid" placeholder="请选择" @change="branchBosidChange" filterable>
                <el-option v-for="item in scope.row.branchBos" :key="item.sourceBranch" :label="item.sourceBranch"
                  :value="item.commitIdWithIndex">
                </el-option>
              </el-select>
            </template>
          </el-table-column>
          <el-table-column label="commitId" min-width="180">
            <template slot-scope="scope">
              <el-input contenteditable="plaintext-only" style="min-height:28px;"
                v-model="scope.row.branchBosidCommitId">
              </el-input>
            </template>
          </el-table-column>
        </el-table>
        <div class="table_b_f_b">
          <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleBranchSizeChange"
            @current-change="handleBranchCurrentChange" :current-page="branchPageData.pageNum"
            :page-sizes="[10, 20, 50]" :page-size="branchPageData.pageSize"
            layout="total, sizes, prev, pager, next, jumper" :total="branchPageData.total"
            :pages="branchPageData.pages"></el-pagination>
        </div>
      </div>
      <el-collapse v-if="buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
        <el-collapse-item>
          <template slot="title">
            请选择构建参数
          </template>
          <div>
            <el-form :model="packInfo" ref="packInfo" label-width="100px" @submit.native.prevent>
              <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
                <!-- 如果对应的构建任务设置了“构建参数”， 则展示给用户选择-->
                <el-col :span='24' v-if="buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
                  <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                    v-for="(item,index) in buildTaskVaiableList">
                    <el-autocomplete class="inline-input" v-model="item.currentOption" placeholder="请输入内容"
                      style="width:200px;"
                      :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                      :disabled="false" @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)">
                    </el-autocomplete>
                    {{item.desc}}
                    <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                      <span class="el-form-item__error">构建参数不能为空</span>
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </el-collapse-item>
      </el-collapse>
      <span slot="footer" class="dialog-footer">
        <el-button @click=" handleClose_master2">取消</el-button>
        <el-button type="primary" @click="goToCompiling('mbanch')">确定</el-button>
      </span>
    </el-dialog>
  </div>

</template>

<script>
  let compileDetail = {
    sourceRepo: '',
    appId: null,
    taskId: null,
    uuid: null,
    taskName: "",
    sourceBranch: "",
    defaultTask: 1,
    setting: '',
    compileStepLst: [],
  };
  let bulidStasusInfo = {
    imageRepo: '',//镜像名称
    stepId: null, //步骤id
    stepName: '', //步骤名称
    taskId: null, //任务ID
    typeId: null, //镜像类型ID
    shellInfo: '',//自定义脚本
    taskOrder: '',//步骤顺序
    stepConfig: {

    }
  };
  let cefhStatusInfo = {
    taskOrder: '',//步骤顺序
    imageRepo: '',//镜像名称
    stepId: null, //步骤id
    stepName: '上传版本包到仓库', //步骤名称
    taskId: null, //任务ID
    typeId: null, //镜像类型ID
    shellInfo: '',//自定义脚本
    stepConfig: null
  }
  let harborStatusInfo = {
    taskOrder: '',//步骤顺序
    imageRepo: '',//镜像名称
    stepId: null, //步骤id
    stepName: '', //步骤名称
    taskId: null, //任务ID
    typeId: null, //镜像类型ID
    shellInfo: '',//自定义脚本
    stepConfig: {
      cpu: '4', //cpu核数
      memory: '4096',//内存
      storage: '50',//磁盘存储
    }
  }
  let bulidtaskStaus = {
    isAddTask: '',//判断添加是否纯在
    isActive: '',//判断已存在的任务是否选中
    isStatus: "add",//判断是编辑还是添加状态
    typePurpose: '',//判断构建用途,
    isInit: 'show',//判断是创建还是展示,
    addSort: 'null',//判断之前还是之后添加
    location: 0,//记录之前活着之后添加的位置
  }

  import draggable from 'vuedraggable';
  export default {
    name: "AppTaskBulid",
    data() {
      let validTargetDir = (rule, value, callback) => {
        let targetPattern = this.bulidStasusInfo.stepConfig.targetPattern;
        if (!this.targetPatternVerify(value, targetPattern)) {
          callback(new Error("目标文件路径中文件与目标文件压缩格式不符合！"));
        } else {
          callback();
        }
      };
      let validShell = (rule, value, callback) => {
        let invalidateChar = ["`", "$", "|", ";", "&&", ">", "<"];
        if (value) {
          for (let oneChar of invalidateChar) {
            if (value.indexOf(oneChar) !== -1) {
              callback(new Error("参数不能包含特殊字符" + oneChar));
              return;
            }
          }
        }
        callback();
      };
      let validRepo = (rule, value, callback) => {
        let checkGitSshUrl = /^(git@|ssh:\/\/\w+@)\w+/;

        let checkGitHttpUrl = /^[A-Za-z]+:\/\/+/;

        if (!checkGitSshUrl.test(value) && !checkGitHttpUrl.test(value)) {
          callback(new Error("源码仓库格式错误！请检查git地址格式! 形如git@xxx或者ssh://xxx@xxx或者http://xxx"));
        } else {
          callback();
        }
      };

      let validBaseDir = (rule, value, callback) => {
        if (value.substr(0, 1) != "/") {
          callback(new Error("APP根目录必须是绝对路径"));
        } else {
          callback();
        }
      };
      let validUserName = (rule, value, callback) => {
        value = value.trim().toLowerCase();
        if (value === 'root') {
          callback(new Error("运行用户名不能为root"));
        } else {
          callback();
        }
      };
      let validVersionNameTemplateData = (rule, value, callback) => {
        let spaceList = value.split(" ");
        if (spaceList.length > 1) {
          callback(new Error("请去除空格！"))
        }

        let pattern = /\w*(\${[a-zA-Z]+})*\w*/;
        if (!pattern.test(value)) {
          callback(new Error("输入格式错误！"))
        }

        let tempList = value.split("${");
        let afterTrim = tempList.splice(1, tempList.length - 1);
        let realList = [];
        afterTrim.forEach(item => {
          realList.push(item.substring(0, item.indexOf("}")));
        });
        realList.forEach(item => {
          if (GLOBAL_CONST.DEFAULT_VERSION_NAME_TEMPLATE_DATA_LIST.indexOf(item) == -1) {
            callback(new Error("占位符变量填写错误，建议拷贝填入"));
          }
        })
        callback();
      };
      let validPublishableBranches = (rule, value, callback) => {
        if (!value) {
          callback();
        } else {
          let spaceList = value.split(" ");
          if (spaceList.length > 1) {
            callback(new Error("请去除空格！"))
          } else {
            callback();
          }
        }
      }
      let validateVariableName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入参数名称'));
        } else {
          let variableNameRegExp = /^[A-Z_]+[A-Z_0-9]*$/;
          // console.log(variableNameRegExp.test(value));
          if (!variableNameRegExp.test(value)) {
            callback(new Error('只接受大写英文字母，下划线，阿拉伯数字（即正常编码常量命名规范）'));
          } else {
            callback();
          }
        }
      };

      let validateDefaultOption = (rule, value, callback) => {
        //要想办法判断value.defaultOption是否是可选项value.options里面的一个值
        let options = value.options;
        if (!options || !options.trim()) {
          callback();
        }

        let defaultOption = value.defaultOption;
        if (!defaultOption || !defaultOption.trim()) {
          callback();
        }

        options = options.trim();
        defaultOption = defaultOption.trim();

        let optionArr = options.split('\n');
        if (optionArr.indexOf(defaultOption) == -1) {
          callback(new Error("如果填写默认值，则必须为\"可选项\"中的某项"))
        }

        callback();

      };

      return {
        createTaskTemplateInfo: {
          type: '',
          taskId: '',
        },
        buildTaskVaiableList: [],
        tableListNew: {
          appType: 0,
          data: [],//多仓库表格数据
        },
        taskId: '',
        totalSet: [],
        dialogVisible_master1: false,
        dialogVisible_master2: false,
        dialogVisibleCompile: false,
        modaltobody: false,
        shadeBtn: false,
        branchPageData: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pages: 0
        },
        packInfo: {},
        pipelineTaskTempInfo: {
          name: "",
          type: "",
          taskType: "",
          transferType: "",
          autoExec: null,
          environment: "",
          deployPlanName: "",
          deploymentTask: "",
          proPerson: null,
          person: [],
          people: [],
          shellScriptContent: "",
          mvnCommand: "mvn test",
          sonarMetricsList: [],
          buildVarsList: [],
        },
        buildVarsRules: {
          variable: [{ required: true, message: '不能为空', trigger: 'blur' },
          { validator: validateVariableName, trigger: 'blur' }],
          options: [{ required: true, message: '不能为空', trigger: 'blur' }],
          defaultOption: [{ validator: validateDefaultOption, trigger: 'blur' }],
        },
        // /分界线/
        bulidtaskStaus: {
          isAddTask: '',//判断添加是否纯在
          isActive: '',//判断已存在的任务是否选中
          isStatus: "add",//判断是编辑还是添加状态
          typePurpose: '',//判断构建用途,
          isInit: 'show',//判断是创建还是展示,
          addSort: 'null',//判断之前还是之后添加
          location: 0,//记录之前活着之后添加的位置
        }
        ,
        rules1: {
          publishableBranches: [{ validator: validPublishableBranches, trigger: 'blur' }],
          versionNameTemplateData: [{ required: true, message: '版本名称规则不能为空', trigger: 'blur' }, { validator: validVersionNameTemplateData, trigger: 'blur' }],
          sourceRepo: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validRepo, trigger: 'blur' }],
          baseDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validBaseDir, trigger: 'blur' }],
          targetDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validTargetDir, trigger: 'blur' }],
          userName: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validUserName, trigger: 'blur' }],
          shell: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validShell, trigger: 'blur' }],
          publish: [{ required: true, message: '不能为空', trigger: 'blur' }]
        },
        compileInfo: {},//获取编译方式
        javaAppBuildTool: 1, //
        APP_TYPE: GLOBAL_CONST.APP_TYPE, //引入全局变量编译方式类型
        COMPILE_IMAGE_TYPE: GLOBAL_CONST.COMPILE_IMAGE_TYPE,
        sourceRepo: '',
        bulidStasusInfo: {

          imageRepo: '',//镜像名称
          stepId: null, //步骤id
          stepName: '', //步骤名称
          taskId: null, //任务ID
          typeId: null, //镜像类型ID
          shellInfo: '',//自定义脚本
          taskOrder: '',//步骤顺序
          stepConfig: {

          }

        },
        cefhStatusInfo: {
          sourceRepo: '',
          taskOrder: '',//步骤顺序
          imageRepo: '',//镜像名称
          stepId: null, //步骤id
          stepName: '上传版本包到仓库', //步骤名称
          taskId: null, //任务ID
          typeId: null, //镜像类型ID
          shellInfo: '',//自定义脚本
          stepConfig: null
        },
        harborStatusInfo: {
          taskOrder: '',//步骤顺序
          imageRepo: '',//镜像名称
          stepId: null, //步骤id
          stepName: '', //步骤名称
          taskId: null, //任务ID
          typeId: null, //镜像类型ID
          shellInfo: '',//自定义脚本
          stepConfig: {
            cpu: '4', //cpu核数
            memory: '4096',//内存
            storage: '50',//磁盘存储
          }
        },
        createdBulidTask: [],

        imageRepolist: [],//镜像信息
        // : [],
        compilingList: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          list: []
        },
        table_loading: false,
        appearExecuteBtn: false,
        appearReExecuteBtn: false,
        pipelineListData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        bizId: '',
        appId: '',
        compileDetail: {
          appId: null,
          taskId: null,
          uuid: null,
          taskName: "",
          sourceBranch: "",
          defaultTask: 1,
          setting: '',
          compileStepLst: [],

        },
        branchLst: [],//分支列表
        COMPILE_TASK_STATUS: GLOBAL_CONST.COMPILE_TASK_STATUS,
        appType: '',
      }
    },

    mounted() {

      this.bizId = this.getUrlBizId();
      this.appId = this.getUrlAppId();

      this.getCompilingList();
      this.getBranchiInfo();
      this.getCurrentAppCode()
    },
    methods: {
      getCurrentAppCode() {
        $http.get($http.api.app.simpleInfo).then(res => {
          if (res.status == 200) {
            this.appType = res.data.appType;
          }
        }).catch((err) => {

        })
      },
      updateData() {
        this.$forceUpdate()
      },
      setDefaultTask(row) {
        if (row.defaultTask === 1) {
          this.$message({ type: 'warning', message: "当前任务已是默认编译任务" })
          return
        }
        let taskId = row.taskId;
        this.$confirm('是否设置为默认任务?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.compile.task_default, { taskId }, { type: 'form' }).then(res => {
            this.$message({
              type: 'success',
              message: '设置成功'
            });
            this.getCompilingList()
          })
        })
          .catch(() => {
            this.$message({
              type: 'info',
              message: '取消设置'
            });
          });
      },

      showCompileDetail(info) {
        if (!info.lastDetailId || info.lastDetailId === -1) {
          this.$message({ type: "warning", message: "当前任务还未有执行记录" })
          return
        }
        this.goToPage(this, 'AppCompileTaskOverView', { bizId: this.bizId, appId: this.appId, detailId: info.lastDetailId, })
      },
      branchBosidChange(val) {
        let arr = val.split(",");
        let indexStr = arr[2];
        let index = parseInt(indexStr);
        let data1 = this.tableList.data;
        let item = data1[index];
        if (item) {
          item.branchBosidCommitId = arr[0]
        }
      },
      getBuildTaskVarsJson() {
        let varsSelectedObj = {};
        this.buildTaskVaiableList.forEach(item => {
          varsSelectedObj[item.variable] = item.currentOption;
        });
        return varsSelectedObj;
      },
      queryVariableSearch(queryString, cb, variable) {
        var restaurants = [];
        this.buildTaskVaiableList.forEach(item => {
          if (item.variable == variable) {
            restaurants = item.options;
          }
        });
        var results = [];
        restaurants.forEach((item) => {
          if (queryString == null || queryString == "" || item.toLowerCase().indexOf(queryString) == 0) {
            results.push({ value: item })
          }
        });
        cb(results);
      },
      handleOptionsSelect(selectData, currentOption) {
        currentOption = selectData;
      },
      hasVariableBlank() {
        var hasVariableBlank = false;
        if (this.buildTaskVaiableList != null && this.buildTaskVaiableList.length > 0) {
          this.buildTaskVaiableList.forEach(item => {
            if (item.currentOption == null || item.currentOption == "") {
              hasVariableBlank = true;
            }
          });
        }
        return hasVariableBlank;
      },
      goToCompiling(menu) {
        if (this.hasVariableBlank()) {
          this.$message({
            showClose: true,
            message: '构建参数不能为空',
            type: 'warning'
          });
          return;
        }
        var branch = '', gitRepoInfoLstJsonStr = '', buildTaskVarsJsonStr = '', commitId = '';
        if (menu === 'mbanch') {
          if (this.totalSet.length == 0) {
            this.$message({
              message: '请勾选分支列表',
              type: 'warning'
            })
            return;
          }
          let totalList = JSON.parse(JSON.stringify(this.totalSet))
          totalList.forEach((item, index) => {
            if (item.branchBos) {
              delete item.branchBos;
              item['gitRepoUrl'] = item.sourceRepo;
              item['branch'] = item.branchBosid ? item.branchBosid.split(',')[1] : '';
              item['commitId'] = item.branchBosidCommitId ? item.branchBosidCommitId : '';
              delete item.sourceRepo;
              delete item.branchBosid;
              delete item.branchBosidCommitId
            }
          })
          let list = [];
          totalList.forEach(item => {
            list.push(item);
          })
          gitRepoInfoLstJsonStr = JSON.stringify(list);
          if (this.buildTaskVaiableList.length > 0) {
            buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
          }
          // sessionStorage.setItem('sendMbrachParmas', JSON.stringify(obj))
        } else {
          for (let i = 0; i < this.branchLst.length; i++) {
            if (this.branchLst[i].name === this.packInfo.branch) {
              // console.log(this.branchLst[i].commit.id)
              commitId = this.branchLst[i].commit.id
            }
          }
          branch = this.packInfo.branch;
          buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        }

        $http.post($http.api.compile.task_start, { appId: this.appId, commitId, uuid: this.uuid, branch, gitRepoInfoLstJsonStr, buildTaskVarsJsonStr, }, { type: 'form' }).then(res => {
          let detailId = res.data
          this.goToPage(this, 'AppCompileTaskOverView', { bizId: this.bizId, appId: this.appId, taskId: this.taskId, detailId })
        })


      },
      getBranchList() {
        this.table_loading = true;
        let params = { appId: this.appId };
        $http.get($http.api.appdate.appBranchList, params).then((res) => {
          if (res.status == 200) {
            this.appType = res.data.appType;
            if (res.data.appType != 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                if (a.name == 'master' && b.name != 'master') {
                  return -1;
                } else if (a.name != 'master' && b.name == 'master') {
                  return 1;
                } else if (!a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return -1;
                } else if (a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return 1;
                } else if (!a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                } else if (a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                }
              })
              this.tableList = res.data;

              //data替换为分支名称排序后的
              this.tableList.data = data;
              this.appBranchInfo = this.tableList.data.concat([]);
              this.handleBranchSizeChange(this.branchPageData.pageSize);
              this.gitAddress = res.data.sourceRepo;
            } else if (res.data.appType == 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                return a.subAppId.localeCompare(b.subAppId);
              })
              res.data.data.forEach((subApp, index_i) => {
                if (subApp.branchBos.length > 0) {
                  subApp.branchBos.forEach((oneBranch, index) => {
                    if (oneBranch.sourceBranch == 'master') {
                      subApp.branchBosidCommitId = oneBranch.commitId;
                      subApp.branchBosid = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                    }
                    oneBranch.commitIdWithIndex = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                  })
                }
              })
              this.tableList = res.data;
              this.tableList.data = data;
              this.handleBranchSizeChange(this.branchPageData.pageSize);
            }
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
          this.table_loading = false;
        }).catch(_ => {
          this.table_loading = false;
        });
      },

      handleBranchSizeChange(val) {
        this.branchPageData.pageSize = val;
        this.fakePage(this.branchPageData.pageNum, val, this.search, this.appType);
      },

      handleBranchCurrentChange(val) {
        this.branchPageData.pageNum = val;
        this.fakePage(val, this.branchPageData.pageSize, this.search, this.appType);
      },

      fakePage(num, size, keyWord, appType) {
        let allList = this.tableList.data;
        let tempList = [];
        let returnList = [];
        if (appType != 5) {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.name.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        } else {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.subAppId.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            this.tempList = tempList;
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        }
        this.$nextTick(() => {
          let tableListNew = this.tableListNew;
          tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale && branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },

      //全选事件
      selectAllEvent(data) {
        if (data.length == 0) {
          this.totalSet = [];
        } else {
          this.totalSet = [];
          this.tempList.forEach(item => {
            this.totalSet.push(item);
          });
        }
        this.$nextTick(() => {
          this.tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            let t = this.totalSet.indexOf(item) != -1;
            branchTale && branchTale.toggleRowSelection(item, t);
          })
        });
      },
      //表格勾选
      handleSelectionChange(val) {
        let dataList = this.tableListNew.data;
        dataList.forEach(item => {
          let index = this.totalSet.indexOf(item);
          if (index != -1) {
            this.totalSet.splice(index, 1)
          }
        });
        val.forEach(item => {
          this.totalSet.push(item);
        });
        this.$nextTick(() => {
          this.tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale && branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },
      targetPatternVerify(targetDir, targetPattern) {
        let endFormat = [".zip", ".jar", ".tar", ".tar.gz", ".war"];
        let count = 0;
        for (let i = 0; i < endFormat.length; i++) {
          if (targetDir.endsWith(endFormat[i])) {
            count++;
            break;
          }
        }
        if (count === 0) {
          return true;
        }
        if (targetDir.endsWith(targetPattern)) {
          return true;
        }
        if (targetPattern == "tar" && targetDir.endsWith(targetPattern + ".gz")) {
          return true;
        }
        return false;
      },
      showDialogCompile() {
        this.dialogVisibleCompile = true;
      },
      handleCloseCompile() {
        this.dialogVisibleCompile = false;
        this.createTaskTemplateInfo.type = '';
        this.createTaskTemplateInfo.taskId = '';
      },
      //非多仓库关闭
      handleClose_master1() {
        this.$refs['packInfo'].resetFields();
        this.dialogVisible_master1 = false;
      },
      handleClose_master2() {
        this.dialogVisible_master2 = false;
      },
      handleClose_hand_upload() {
        this.$refs['correlationInfo_hand'].resetFields();
        this.$refs.upload.$data.uploadFiles.length = 0;
        this.dialogVisible_hand_upload = false;
      },

      //获取镜像名称列表
      getImageRepoList(item) {
        let params = {
          bizId: this.bizId,
          typeId: item.typeId
        }
        $http.get($http.api.compile.compileTypeImages, params).then(res => {
          this.imageRepolist = res.data;
          this.sourceRepo = res.data.sourceRepo;
        })
      },
      //获取分支信息
      getBranchiInfo() {
        $http
          .get($http.api.pipeline.appBranchCompleteInfo, {
            appId: this.appId
          })
          .then(res => {
            this.branchLst = res.data.branchLst;
          });
      },
      //获取编译任务列表
      getCompilingList() {
        let params = {
          appId: this.appId,
          pageNum: this.compilingList.pageNum,
          pageSize: this.compilingList.pageSize,
        };

        $http.get($http.api.compile.compiling_list, params).then(res => {
          this.compilingList = res.data;
          this.taskId = res.data.list[0].taskId
        })
      },



      isJavaApp(appType) {
        // console.log(appType)
        return appType == this.APP_TYPE.JAVA_MAVEN
          || appType == this.APP_TYPE.JAVA_WEB_MAVEN
          || appType == this.APP_TYPE.JAVA_GRADLE
          || appType == this.APP_TYPE.JAVA_WEB_GRADLE
          || appType == this.APP_TYPE.ANDROID_APK;
      },

      isNotWebJavaApp(appType) {
        // console.log(appType)
        return appType !== this.APP_TYPE.TAR

      },

      isJavaWebApp(appType) {
        // console.log(appType)
        return appType == this.APP_TYPE.JAVA_WEB_MAVEN
          || appType == this.APP_TYPE.JAVA_WEB_GRADLE;
      },
      isMavenJavaApp(appType) {
        // console.log(appType)
        return (appType == this.APP_TYPE.JAVA_MAVEN || appType == this.APP_TYPE.JAVA_WEB_MAVEN)
      },

      isGradleJavaApp(appType) {
        // console.log(appType)
        return appType == this.APP_TYPE.JAVA_GRADLE || appType == this.APP_TYPE.JAVA_WEB_GRADLE || appType == this.APP_TYPE.ANDROID_APK;
      },

      isNotJavaApp(appType) {
        // console.log(appType)
        return !this.isJavaApp(appType);
      },

      isShellScriptApp(appType) {
        // console.log(appType)
        return appType == this.APP_TYPE.SHELL || appType == this.APP_TYPE.MULTI_REPO_SHELL;
      },

      //获取所有的镜像列表



      handlePipelineListSizeChange(newPageSize) {
        this.compilingList.pageSize = newPageSize;
        this.getCompilingList()
      },

      handlePipelineListPageChange(newPageNum) {
        this.compilingList.pageNum = newPageNum;
        this.getCompilingList()

      },
      newCompileTask() {
        if (this.createTaskTemplateInfo.type === 0) {
          this.goToPage(this, 'AppCompileTaskDetail', { bizId: this.bizId, appId: this.appId, operation: 'create' });
        } else {
          this.goToPage(this, 'AppCompileTaskDetail', { bizId: this.bizId, appId: this.appId, taskId: this.createTaskTemplateInfo.taskId, operation: 'create' });
        }
      },
      goToComplineExecHistory(row) {
        this.goToPage(this, 'appCompileHistory', { bizId: this.bizId, appId: this.appId, uuid: row.uuid })
      },
      executePipeline(row) {
        // debugger
        this.taskId = row.taskId
        this.uuid = row.uuid
        this.packInfo.branch = row.sourceBranch

        $http.get($http.api.compile.task_branch, { taskId: this.taskId }).then(res => {
          // this.buildTaskVaiableList = res.data
          this.getBranchList()
          $http.get($http.api.compile.task_variables, { taskId: this.taskId }).then(res => {
            this.buildTaskVaiableList = res.data
          })
          if (res.data.compileType !== 5) {
            this.dialogVisible_master1 = true;

          } else {
            this.dialogVisible_master2 = true;

          }
        })
      },
      //编辑列表,在查看的基础上多了一步自动触发跳进去后的页面的“编辑”按钮
      editCompileTask(row) {
        this.goToPage(this, 'AppCompileTaskDetail', { bizId: this.bizId, appId: this.appId, taskId: row.taskId, operation: 'edit' });
      },

      showCompileTask(row) {
        this.goToPage(this, 'AppCompileTaskDetail', { bizId: this.bizId, appId: this.appId, taskId: row.taskId, operation: 'view' });
      },

      //删除
      deleteCompline(row) {
        this.$confirm(`确定要删除编译任务[${row.taskName}]？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let taskId = row.taskId;
          // formData.set('pipelineId', row.pipelineId);
          $http.post($http.api.compile.task_delete, { taskId }, { type: 'form' }).then(response => {
            if (response.status == 200) {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.getCompilingList();
            }
          });
        }).catch(() => {
        });
      },
      ifExecuteBtnVisiable(pipelineStageRunningInfoBos) {
        let result = false;
        if (!pipelineStageRunningInfoBos || pipelineStageRunningInfoBos.length == 0) {
          result = true;
        } else {
          let lastPipelineStageRunningInfo = pipelineStageRunningInfoBos[pipelineStageRunningInfoBos.length - 1];
          if (lastPipelineStageRunningInfo.stageRunningStatus == 'SUCCESS') {
            result = true;
          }
        }
        if (result) {
          this.appearExecuteBtn = true;
        }
        return result;
      },

      ifReExecuteBtnVisiable(pipelineStageRunningInfoBos) {
        let result = !this.ifExecuteBtnVisiable(pipelineStageRunningInfoBos);
        if (result) {
          this.appearReExecuteBtn = true;
        }
        return result;
      },
      getClassByRunningStatus(status) {
        switch (status) {
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_NEW:
            return "icon-status-init-l";
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_ING:
            return "icon-status-running-l";
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_SUC:
            return "icon-status-success-l";
          case this.COMPILE_TASK_STATUS.COMPILE_RESULT_FAIL:
            return "icon-status-fail-l";
        }
      },

    },
    components: {
      draggable
    }
  };
</script>
<style lang="scss" scoped>
  .icon-positon {
    position: absolute;
    top: 4px;
    right: 20px;
    color: #000;
    font-weight: 700px;
    font-size: 16px;
  }

  .icon-circle {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 1px solid #ccc;
  }

  .blue-icon {
    color: #5170FF;
  }

  .new-bulid-task {
    /* width: 1200px; */
    margin: 0 auto;
    background-color: #FFF;
    padding: 10px 20px 0;
    /* min-height: calc(100vh - 150px); */
    box-shadow: 0 10px 20px -10px #112037;
    height: auto;
    overflow: hidden;
    /* height: calc(100% - 50px); */
  }

  .new-image-list {
    /* width: 1200px; */
    margin: 0 auto;
    background-color: #FFF;
    padding: 20px;
    /* min-height: calc(100vh - 50px); */
    box-shadow: 0 10px 20px -10px #112037;
    /* height: calc(100% - 50px); */
    height: auto;
    overflow: hidden;

    .bulid-task {
      overflow: hidden;

      .bulid-task-box-left {
        float: left;
        padding-bottom: 20px;

        .bulid-task-item {
          border: 1px solid transparent;
          background-color: #F8F8F8;
          width: 480px;
          height: 80px;
          cursor: pointer;
          margin-top: 20px;
          padding-left: 10px;
          position: relative;

          .bulid-task-name {
            font-weight: 700;
            color: #333;
            font-size: 14px;
            position: relative;

          }

          .bulid-tasl-des {
            font-size: 12px;
            color: #5E6678;
            position: relative;
          }

          .add-top-icon {
            /* display: none; */
            position: absolute;
            width: 20px;
            height: 20px;
            background: #4C5C85;
            border-radius: 50%;
            left: 59px;
            color: #FFFFFF;
            /* color: var(--font-white, #FFFFFF); */
            text-align: center;
            line-height: 20px;
            font-size: 18px;
            cursor: pointer;
            top: -12px;
          }


          .add-down-icon {
            position: absolute;
            width: 20px;
            height: 20px;
            background: #4C5C85;
            border-radius: 50%;
            left: 59px;
            color: #FFFFFF;
            /* color: var(--font-white, #FFFFFF); */
            text-align: center;
            line-height: 20px;
            font-size: 18px;
            cursor: pointer;
            top: 70px;
          }
        }

        .active {
          background: #FFFFFF;
          box-shadow: 0 0 2px 0 #5170FF;
          border: 1px solid #5170FF;
        }

        .bulid-task-null {
          display: inline-block;
          width: 480px;
          height: 80px;
          border: 1px dotted #CACFD8;
          cursor: pointer;
          text-align: center;
          line-height: 80px;
        }
      }

      .bulid-task-box-right {
        float: left;
        width: 541px;
        padding-left: 40px;

        .add-step-title {
          font-size: 16px;
          font-weight: 700;
          color: #333;
        }

        .all-task {
          color: #5170ff;
          display: inline-block;
          border-bottom: 2px solid #5170ff;
          font-weight: 700;
          margin-top: 20px;
        }

        .el-icon-close {
          margin-left: 360px;
        }

        .item-box {
          margin-top: 20px;

          .bulid-task-item {
            width: 541px;
            height: 80px;
            border: 1px solid transparent;
            border-bottom: 1px solid #CACFD8;
            position: relative;

            .bulid-task-name {
              font-weight: 700;
              color: #333;
              font-size: 14px;
              /* padding-top: 13px; */
            }

            .bulid-tasl-des {
              font-size: 12px;
              color: #5E6678;
            }

            &:hover {
              box-shadow: 0 0 2px 0 #5170FF;
              border: 1px solid #5170FF;
              position: relative;
            }
          }

          .add-bulid-task {
            position: absolute;
            top: 26px;
            right: 20px;
          }
        }
      }

    }
  }
</style>
