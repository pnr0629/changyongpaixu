<template>
  <div id="appVersionPipeline">
    <el-dialog
      :title="'流水线：' + pipelineName"
      class="el-dialog-1300w"
      :fullscreen='fullscreen'
      :before-close="handleClose_bb"
      :visible.sync="dialogVisible"
      :modal-append-to-body="true"
      :close-on-click-modal='false'>
      <div class="oem-line-box">
        <div style="height: 100%;overflow:auto;overflow-x: hidden;" id="oem_scroll_box">
          <div class="oem-line-header" v-if="containsAppVersion == true">
            <span>版本：{{appVersionInfo.versionName}}</span>
            <span>分支：{{appVersionInfo.sourceBranch}}</span>
            <span>commitId：{{appVersionInfo.commitId}}</span>
          </div>

          <div class="oem-body_a">
            <div class="oem-body_b" v-for="(item,index) in stageRunningVoList" :key='item.id'>
              <div class="box-card" @click="stageClick(item.id)" :class="{'active':item.id == currentSelectedStage.id}">
                <div class="box-card-title">{{item.name}}</div>
                <el-progress type="circle" :percentage="item.percentage" class="card-progress" :width="100"
                             color="#67C23A" status="text"><span v-html="item.desc"></span></el-progress>
                <div class="circle-time" v-if="item.executeTime>0">{{item.executeTime}}秒</div>
                <span :class="{'triangle':item.id == currentSelectedStage.id}"></span>
                <span :class="{'triangle2':item.id == currentSelectedStage.id}"></span>
              </div>
              <div class="box-card-arrow" v-if='index != stageRunningVoList.length-1'>→</div>
            </div>
          </div>

          <div class="box-card-body">
            <div class="box-card-body-head">
              <div class="circle-line" v-for="(item,index) in currentSelectedWorkflowList" :key='item.id'>
                <div class="circle-head" @click="workflowClick(item.id)"
                     :class="{'circle-active':item.id == currentSelectedWorkflow.id}" v-html="item.task.showName">
                </div>
                <span :class="{'triangleBtn':item.id == currentSelectedWorkflow.id}"></span>
                <span :class="{'triangleBtn2':item.id == currentSelectedWorkflow.id}"></span>
                <div class="line-head"
                     v-if="currentSelectedWorkflowList.length-1  != index"
                     :style="{'margin-left':item.id == currentSelectedWorkflow.id?'-40px':'-4px'}"></div>
              </div>
            </div>

            <div class="publicclass">
              <!-- 最后操作信息 -->
              <el-table :data="lastWorkflowOperation">
                <el-table-column label="任务类型" min-width="100">
                  <template slot-scope="scope">
                    <el-tooltip class="item" effect="dark" placement="top" :content="deployInfo"
                                v-if="deployInfo.length > 0">
                      <span>{{scope.row.workflowTaskTypeName}}</span>
                    </el-tooltip>
                    <span v-else>{{scope.row.workflowTaskTypeName}}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="executeType" label="触发类型" min-width="60"></el-table-column>
                <el-table-column label="流转方式" min-width="100">
                  <template slot-scope="scope">
                    <el-tooltip class="item" effect="dark" placement="top">
                      <div slot="content">未完成流转：执不执行都会流转到下一任务<br/>
                        完成流转：执行完成了（成功或失败都会）流转下一任务<br/>
                        完成且成功流转：执行成功了才会流转下一任务
                      </div>
                      <span v-html="scope.row.transferType"></span>
                    </el-tooltip>
                  </template>
                </el-table-column>
                <el-table-column prop="triggerUser" label="最后操作人" min-width="180"></el-table-column>
                <el-table-column prop="startTime" label="操作时间" min-width="180"></el-table-column>
                <el-table-column label="状态" min-width="180">
                  <template slot-scope="scope">
                    <span v-html="scope.row.showStatus"></span>
                    <el-tooltip class="item" effect="dark" placement="top"
                                v-if="scope.row.errorMsg && scope.row.errorMsg.length > 0">
                      <div slot="content">{{scope.row.errorMsg}}</div>
                      <i class="el-icon-warning"></i>
                    </el-tooltip>
                    <el-tooltip class="item" effect="dark" placement="top"
                                v-if="scope.row.workflowTaskType == WORKFLOW_TASK_TYPE.AUTO_TEST && underStatus && underStatus.length > 0
                                && (scope.row.workflowTaskStatus == WORKFLOW_TASK_STATUS.SUCCESS || scope.row.workflowTaskStatus == WORKFLOW_TASK_STATUS.FAILURE)">
                      <div slot="content">{{underStatus}}</div>
                      <i class="el-icon-warning"></i>
                    </el-tooltip>
                  </template>
                </el-table-column>
                <el-table-column label="操作" min-width="140">
                  <template slot-scope="scope">
                    <template v-if="ifDeployTestOrCanGo(scope.row)">
                      <!-- 手动部署时，部署测试或部署开发 -->
                      <span class="c-blue cp" v-show="canExecute(scope.row)"@click="executeWorkflow(scope.row)">{{scope.row.executeName}}</span>

                      <span :class="(scope.row.manualStop != 1) ? 'c-blue cp' : 'c-disabled cursor-default'" v-show="canExcuteTaskStop(scope.row)" @click="stopTaskExecute(scope.row)">{{scope.row.stopName}}</span>

                      <!-- 自动部署时，显示手动部署按钮 -->
                      <span class="c-blue cp" @click="manualDeploy" v-show="canManualDeploy(scope.row)">手动部署</span>
                      &nbsp;&nbsp;

                      <span class="c-blue cp" @click="doExecuteWorkflow" v-show="canExecuteNextWorkflow(scope.row)">
                        流转下一阶段
                      </span>
                      <!-- 下载单元测试报告 -->
                      <span class="c-blue cp" @click="openUrlInNewWindow(getUnitTestReportsDownloadUrl(scope.row.result))" v-show="canDownloadUnitTestReports(scope.row)">
                        下载报告
                      </span>
                      <!-- 重新执行自动化测试 -->
                      <span class="c-blue cp" @click="doExecuteWorkflow" v-show="canExecuteAutoTestReRun(scope.row)">
                        重新执行
                      </span>
                    </template>
                    <template v-else>
                      <span class="c-red">只有应用测试人员才能部署测试环境</span>
                    </template>

                    <!--展示url-->
                    <span class="c-blue cp" @click="openUrlInNewWindow(underUrlInfo)" v-if="scope.row.workflowTaskTypeName == '自动化测试'
                      && underStatus != null && underStatus != '无自动化'">测试详情</span>
                  </template>
                </el-table-column>
              </el-table>
              <!-- ==================================== -->
              <div style="min-height:40px;"
                   v-if="ifCurrentWorkflowTypeIn([WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT, WORKFLOW_TASK_TYPE.SUBMIT_TEST, WORKFLOW_TASK_TYPE.PASS_TEST])">
                <div class="title-detaile">可操作人信息</div>
                <el-tag type="info">{{operatorInfo}}</el-tag>
              </div>
              <div style="min-height:40px;"
                   v-if="ifCurrentWorkflowTypeIn([WORKFLOW_TASK_TYPE.PASS_TEST]) && ifSafetyTestResult(satefyTestResult)">
                <div class="title-detaile">隐私合规测试:</div>
                <span class="c-blue cp" @click="openSafetyUrlInNewWindow(satefyTestResult, 0)">{{getSafetyTestUrl(satefyTestResult, 0)}}</span>
              </div>
              <div style="min-height:40px;"
                   v-if="ifCurrentWorkflowTypeIn([WORKFLOW_TASK_TYPE.PASS_TEST]) && ifSafetyTestResult(satefyTestResult)">
                <div class="title-detaile">安全测试:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                <span class="c-blue cp" @click="openSafetyUrlInNewWindow(satefyTestResult, 1)">{{getSafetyTestUrl(satefyTestResult, 1)}}</span>
              </div>
              <!-- ====================================================== -->
              <div style="height:100%;" v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.DEPLOY)">
                <div class="title-detaile">
                  部署历史
                </div>
                <el-table key="deployHistoryTable" :data="deploy_history_list.result">
                  <el-table-column prop="appVersion" label="版本名称" min-width="200"></el-table-column>
                  <el-table-column prop="ip" label="发布机器" min-width="120"></el-table-column>
                  <el-table-column prop="instanceId" label="实例id" min-width="120"></el-table-column>
                  <el-table-column prop="confEnv" label="配置环境" min-width="120"></el-table-column>
                  <el-table-column prop="confVersion" label="配置版本" min-width="120"></el-table-column>
                  <el-table-column prop="operator" label="操作人" min-width="120"></el-table-column>
                  <el-table-column label="操作时间" min-width="140">
                    <template slot-scope="scope">
                      <span>{{scope.row.deployTime?scope.row.deployTime.substring(0,16):''}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="部署结果" min-width="100">
                    <template slot-scope="scope">
                      <span :class="scope.row.result?'':'c-red'">{{scope.row.result?'SUCCESS':'FAIL'}}</span>
                      <el-tooltip class="item" placement="top">
                        <div slot="content" v-if="!scope.row.result" v-html="getFailMsg(scope.row)"></div>
                        <i class="el-icon-warning" v-if="!scope.row.result"></i>
                      </el-tooltip>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" min-width="130px">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="getPaaSLogLink(scope.row,true)">部署日志</span>
                      <span class="c-blue cp" style="margin-left: 4px" @click="getPaaSLogLink(scope.row,false)">实例日志</span>
                    </template>
                  </el-table-column>
                </el-table>
                <div class="table_b_f_b">
                  <el-pagination
                    class="fr mr10"
                    style="margin-top: 9px;"
                    :current-page="deploy_history_list.pageNum"
                    :page-sizes="[5, 10, 15]"
                    :page-size="deploy_history_list.pageSize"
                    @current-change="handleDeployHistoryPageChange"
                    @size-change="handleDeployHistorySizeChange"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="deploy_history_list.total">
                  </el-pagination>
                </div>
              </div>

              <!--<div style="height:100%;" v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.AUTO_TEST)">-->
              <div style="height:100%;" v-show="false">
                  <span class="title-detaile">
                    自动化测试执行详情
                  </span>
                <el-table key="intfTestResultTable" :data="deploy_project_list.list">
                  <el-table-column prop="taskName" label="名称" min-width="120"></el-table-column>
                  <el-table-column prop="taskType" label="任务类型" min-width="120"></el-table-column>
                  <!--<el-table-column align="left" label="运行情况" min-width="120">
                    <template slot-scope="scope">
                        <span>
                          <div>{{scope.row.passed + '/' + scope.row.failed + '/' + scope.row.error}}</div>
                          <div>{{'通过率：' + (((scope.row.passed/scope.row.all)*100).toFixed(2) + '/' + '%')}}</div>
                        </span>
                    </template>
                  </el-table-column>-->
                  <el-table-column prop="taskStatus" label="状态" min-width="120">
                    <template slot-scope="scope">
                      <span>{{parseStatus(scope.row.taskStatus)}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" min-width="120">
                    <template slot-scope="scope">
                        <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.detailUrl)"
                              v-if="scope.row.taskStatus != null">运行详情</span>
                    </template>
                  </el-table-column>
                </el-table>
                <div class="table_b_f_b">
                  <el-pagination
                    class="fr mr10"
                    style="margin-top: 9px;"
                    @size-change="handAutoTestinnerSizeChange"
                    @current-change="handAutoTestinnerPageChange"
                    :current-page="deploy_project_list.pageNum"
                    :page-sizes="[5, 10, 15]"
                    :page-size="deploy_project_list.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="deploy_project_list.total">
                  </el-pagination>
                </div>
              </div>
              <!-- =========================== -->

              <!-- ======================================== -->
              <div style="height:100%;" v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.CODE_SCANNING) && ifCurrentWorkflowTypeCodeScanningFindBugs()">
                  <span class="title-detaile">
                    代码扫描(FindBugs)执行详情
                  </span>
                <el-table key="codeScanResultTable" :data="find_bugs_result_list.list">
                  <el-table-column prop="name" label="名称" min-width="120"></el-table-column>
                  <el-table-column label="负责人" min-width="120">
                    <template slot-scope="scope">
                      <span>{{scope.row.createUserName + '(' + scope.row.createUser + ')'}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column prop="startTime" label="开始时间" min-width="120"></el-table-column>
                  <el-table-column prop="during" label="运行时间" min-width="120"></el-table-column>
                  <el-table-column align="left" prop="confVersion" label="扫描结果" min-width="160">
                    <template slot-scope="scope">
                        <span v-if="scope.row.scanResult != null">
                          <div>{{'总共：' +( scope.row.scanResult.totalWarnings!=null? scope.row.scanResult.totalWarnings:'')}}</div>
                          <div>{{'高危：' + (scope.row.scanResult.highPriorityWarnings!=null?scope.row.scanResult.highPriorityWarnings:'')}}</div>
                          <div>{{'中危：' + (scope.row.scanResult.mediumPriorityWarnings!=null?scope.row.scanResult.mediumPriorityWarnings:'')}}</div>
                          <div>{{'低危：' + (scope.row.scanResult.lowPriorityWarnings!=null?scope.row.scanResult.lowPriorityWarnings:'')}}</div>
                        </span>
                    </template>
                  </el-table-column>
                  <el-table-column prop="status" label="状态" min-width="60">
                    <template slot-scope="scope">
                      <span>{{scope.row.status!= null?innerface_status_findings[scope.row.status.toLowerCase()]:'未开始'}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" min-width="140">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.jenkinsLog)" v-if="scope.row.status != null">运行日志</span>
                      <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.reportDetailUrl)"
                            v-if="scope.row.status == null||scope.row.status != WORKFLOW_TASK_STATUS.RUNNING">运行详情</span>
                      <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.reportUrl)"
                            v-if="scope.row.status == null||scope.row.status != WORKFLOW_TASK_STATUS.RUNNING">报告</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <!-- ======================================== -->
              <div style="height:100%;" v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.CODE_SCANNING) && ifCurrentWorkflowTypeCodeScanningSonarQube()">
                  <span class="title-detaile">
                    {{getScanTypeTitle()}}
                  </span>
                <el-table key="codeScanResultTable" :data="sonarqube_result_list.list">
                  <el-table-column prop="projectKey" label="项目Key" min-width="120"></el-table-column>
                  <el-table-column prop="projectName" label="项目名称" min-width="120"></el-table-column>
                  <el-table-column prop="taskCurrentStage" label="任务所处阶段" min-width="120"></el-table-column>
                  <el-table-column prop="status" label="任务状态" min-width="120"></el-table-column>
                  <el-table-column prop="qualityGateStatus" label="扫描结果" min-width="120"></el-table-column>
                  <el-table-column prop="totalTime" label="总耗时" min-width="120"></el-table-column>
                  <el-table-column label="操作" min-width="120">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.projectUrl)"
                            v-if="scope.row.projectUrl">报告</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <!-- ======================================== -->

              <div style="height:100%;"
                   v-if="ifCurrentWorkflowTypeIn(WORKFLOW_TASK_TYPE.CODE_SCANNING) && ifCurrentWorkflowTypeCodeScanSafetyScan()">
                <span class="title-detaile">
                    安全扫描(SecurityScan)执行详情
                </span>
                <el-table :data="safety_scan_result_list.list" key="codeScanResultTable" :default-sort = "{prop: 'scanResult.ts', order: 'descending'}">
                  <el-table-column label="任务名称">
                    <template slot-scope="scope">
                      <div v-if="scope.row.scanResult">{{scope.row.scanResult.taskName != null ? scope.row.scanResult.taskName : ""}}</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="任务完成时间" sortable prop = "scanResult.ts">
                    <template slot-scope="scope">
                      <div v-if="scope.row.scanResult">{{dateFormat(scope.row.scanResult.ts)}}</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="安全扫描任务ID">
                    <template slot-scope="scope">
                      <div v-if="scope.row.scanResult">{{scope.row.scanResult.taskId != null ? scope.row.scanResult.taskId : ""}}</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="文件数量">
                    <template slot-scope="scope">
                      <div v-if="scope.row.scanResult">{{scope.row.scanResult.fileNum != null ? scope.row.scanResult.fileNum : ""}}</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="扫描行数">
                    <template slot-scope="scope">
                      <div v-if="scope.row.scanResult">{{scope.row.scanResult.rowNum != null ? scope.row.scanResult.rowNum : ""}}</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="扫描语言">
                    <template slot-scope="scope">
                      <div v-if="scope.row.scanResult">{{languageFormat(scope.row.scanResult.language)}}</div>
                    </template>
                  </el-table-column>
                  <el-table-column label="扫描结果">
                    <template slot-scope="scope" v-if="scope.row.scanResult">
                      <div>
                        <span style="color:#F56C6C">高危缺陷数：{{scope.row.scanResult.bugNumSerious != null
                        ? scope.row.scanResult.bugNumSerious : ""}}
                      </span>
                      </div>
                      <div>
                        <span style="color:#E6A23C">中级缺陷数：{{scope.row.scanResult.bugNumMedium != null
                        ? scope.row.scanResult.bugNumMedium : ""}}
                      </span>
                      </div>
                      <div>
                        <span style="color:#67C23A">低级缺陷数：{{scope.row.scanResult.bugNumLow != null
                        ? scope.row.scanResult.bugNumLow : ""}}
                      </span>
                      </div>
                      <div>
                        <span class="c-blue cp" @click="openUrlInNewWindow(scope.row.scanResult.downloadPath)">报告</span>
                      </div>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <!-- ======================================== -->

              <div class="box-card-body-body"
                   v-if="ifCurrentWorkflowTypeIn([WORKFLOW_TASK_TYPE.BUILD, WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT, WORKFLOW_TASK_TYPE.UNIT_TEST, WORKFLOW_TASK_TYPE.BRANCH_MANAGE, WORKFLOW_TASK_TYPE.MVN_DEPLOY])
                   || ifCurrentWorkflowTypeCodeScanningSonarQube()">
                <div style="color: #544c4c;
                    font-size:14px;
                    font-weight:400;
                    margin-top: 10px;">日志详情
                </div>
                <div class="box-card-body-body_right" id="logDetail">
                  <p v-html="logDetail" style="word-wrap: break-word;word-break: break-all;"></p>
                  <p v-show="lastOffsets > 0"><i class="el-icon-loading"></i></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>

    <el-dialog title='部署日志'
               class="el-dialog-1200w"
               :visible.sync="deployLogDialogVisible"
               :before-close="handleCloseDeployLog"
               :modal-append-to-body="false">
      <div >
        <div style="height: 100%;overflow:auto;overflow-x:hidden;">
          <iframe :src="deployLogSrc" width="100%" :height="logHeight" style="background: white" frameborder="no" border="0" id="logIFrame"></iframe>
        </div>
      </div>
    </el-dialog>

    <paas-deploy ref="paasDeploy"></paas-deploy>
  </div>
</template>


<script>
  import paasDeploy from '@/components/biz/app/paasDeploy'

  export default {
    name: 'appVersionPipeline',
    data() {
      return {
        underUrlInfo: '',
        underStatus: '',
        WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
        WORKFLOW_TRIGGER_TYPE: GLOBAL_CONST.WORKFLOW_TRIGGER_TYPE,
        STAGE_STATUS: GLOBAL_CONST.STAGE_STATUS,
        WORKFLOW_TASK_STATUS: GLOBAL_CONST.WORKFLOW_TASK_STATUS,
        TRANSFER_TYPE: GLOBAL_CONST.TRANSFER_TYPE,
        EXECUTE_TYPE: GLOBAL_CONST.EXECUTE_TYPE,
        CODE_SCANNING_TYPE: GLOBAL_CONST.CODE_SCANNING_TYPE,

        dialogVisible: false,
        pipelineName: "",
        deployLogDialogVisible: false,
        appVersionInfo: {},
        containsAppVersion: false,
        lastWorkflowOperation: [],
        satefyTestResult: '',

        inited: false,
        appId: 0,

        deployLogSrc: '',
        logHeight: '',

        stageList: [],
        stageRunningDetailLst: [],
        stageRunningVoList: [], //上面属性的vo

        currentSelectedStage: {}, //当前选中的stage
        currentSelectedWorkflow: {},  //当前选中的workflow

        logDetail: '',
        // widthvip: '',
        deploy_history_list: {
          pageNum: 1,
          pageSize: 5,
          total: 0,
          result: []
        },
        deploy_project_list: { //接口自动化执行详情
          pageNum: 1,
          pageSize: 5,
          total: 0,
          list: []
        },
        find_bugs_result_list: {
          pageNum: 1,
          pageSize: 5,
          total: 0,
          list: []
        },
        sonarqube_result_list: {
          pageNum: 1,
          pageSize: 5,
          total: 0,
          list: []
        },
        safety_scan_result_list: {
          pageNum: 1,
          pageSize: 5,
          total: 0,
          list: []
        },
        operatorInfo: '',    //人工卡点等类型的操作信息
        deployInfo: '', //部署设置信息

        innerface_status_findings: {
          'failure': '失败',
          'success': '成功',
          'running': '执行中'
        },

        lastOffsets: 0,
        lastWorkflowTaskId: 0,

        fullscreen: false,
        currentWorkflowInterval: {},
        currentPipelineInterval: {},
        workflowAutoTransfer: true,
        jumpFromPipelineExecHistory: false,
        appVersionUrl: false
      }
    },

    beforeDestroy: function() {
      //未关闭窗口离开相关渲染页面时，关闭定时器
      if(this.dialogVisible){
        clearInterval(this.currentPipelineInterval)
        clearInterval(this.currentWorkflowInterval)
      }
    },

    methods: {
      parseStatus(oriStatus) {
        if (oriStatus == "运行完成" || oriStatus == "人工通过" || oriStatus == "无自动化") {
          return "通过";
        }
        if (oriStatus == "未运行" || oriStatus == "运行中" || oriStatus == "未定义") {
          return "运行中";

        }
        if (oriStatus == "运行失败" || oriStatus == "人工确认") {
          return "不通过";
        }
      },
      getPaaSLogLink(deploy,isDeployLog) {
        let params = {
          appId: this.getUrlAppId(),
          instanceId: deploy.instanceId,
          env: deploy.env
        };
        if (isDeployLog) {
          params.deployId = deploy.id;
          this.logHeight = "615px";
        }else{
          this.logHeight = "650px";
        }
        $http.post($http.api.appdate.getPaaSLogLink, params, {type: 'form'}).then(res => {
          this.deployLogSrc = res.data;
          this.deployLogDialogVisible = true;
        })
      },

      languageFormat(language){
        var language = "Java";
        switch(language){
          case 0:
            language = "Java";
            break;
          case 1:
            language= "C/C++";
            break;
          case 2:
            language = "C#";
            break;
          case 3:
            language = "Python";
            break;
          case 4:
            language = "PHP";
            break;
          case 5:
            language = "Objective-C";
            break;
          case 6:
            language = "Cobol";
            break;
          case 9:
            language = "NodeJS";
            break;
          case 15:
            language = "Swift";
            break;
          default:
            break;
        }
        return language;
      },

      dateFormat(timeStamp){
        var date = new Date(timeStamp * 1000);
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var day = date.getDate();
        var hour = this.timeFormat(date.getHours());
        var minutes = this.timeFormat(date.getMinutes());
        var seconds = this.timeFormat(date.getSeconds())
        return year + "-" + month + "-" + day + " " + hour + ":" + minutes + ":" + seconds;
      },

      timeFormat(time){
        if(time < 10){
          return "0" + time;
        }
        return time;
      },

      handleCloseDeployLog() {
        this.deployLogDialogVisible = false;
        //只要是清除页面里面的定时器
        this.deployLogSrc=null;
      },

      getFailMsg(item) {
        return item.msg ? item.msg.replace(/\r\n/g, "<br/>").replace(/\n/g, "<br/>") : "";
      },

      getDeployLogHeight() {
        return window.innerHeight * 0.75 + 'px';
      },

      //全屏查看
      full_screen_view() {
        this.fullscreen = !this.fullscreen;
      },


      //进入版本详情弹窗页面,appId用于鉴权
      showVersionPipeline(workflowId, appId, jumpFromPipelineExecHistory = false, appVersionUrl = false) {
        //原来是设置versionId场景入口，手工部署需要传递版本后，versionId在那里要换个办法拿到
        this.workflowId = workflowId;
        this.appId = appId;
        //是否是从流水线执行历史记录页面跳转到流水线执行详情页面，不传参数表示默认false
        this.jumpFromPipelineExecHistory = jumpFromPipelineExecHistory;
        this.appVersionUrl = appVersionUrl;
        this.init();
        this.getVersionPipelineOverview(workflowId);
      },

      init() {
        this.lastOffsets = 0;
        this.lastWorkflowTaskId = 0;
        this.inited = false;
        this.dialogVisible = true;
        this.logDetail = '';
        this.stageList = [];
        this.stageRunningDetailLst = [];
        this.stageRunningVoList = [];
        this.currentSelectedStage = {}; //当前选中的stage
        this.currentSelectedWorkflow = {};
        this.workflowAutoTransfer = true;

        this.pipelineName = "";
        this.appVersionInfo = {};
        this.containsAppVersion = false;
      },

      ifCurrentWorkflowTypeIn(arr) {
        if (this.currentSelectedWorkflow.task) {
          return arr.indexOf(this.currentSelectedWorkflow.task.type) > -1
        }
        return false;
      },

      ifSafetyTestResult(val){
        if(val){
          return true;
        }
        return false;
      },

      ifCurrentWorkflowTypeCodeScanningSonarQube() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting && (setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE || setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE_OPPO_RULE)) {
              return true;
            }
          }
        }
        return false;
      },

      getScanTypeTitle() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting) {
              if (setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE) {
                return "代码扫描(SonarQube)执行详情";
              } else if (setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE_OPPO_RULE) {
                return "代码规范扫描(SonarQube)执行详情";
              }
            }
          }
        }
        return "未知扫描类型";
      },

      ifCurrentWorkflowTypeCodeScanningFindBugs() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting && setting.taskType == this.CODE_SCANNING_TYPE.FIND_BUGS) {
              return true;
            }
          }
        }
        return false;
      },

      ifCurrentWorkflowTypeCodeScanSafetyScan() {
        if (this.currentSelectedWorkflow.task && (this.WORKFLOW_TASK_TYPE.CODE_SCANNING == this.currentSelectedWorkflow.task.type)) {
          if (this.currentSelectedWorkflow.task.setting) {
            let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
            if (setting && setting.taskType == this.CODE_SCANNING_TYPE.SAFETY_SCAN) {
              return true;
            }
          }
        }
        return false;
      },

      ifSafetyScanEnd() {
        var isEnd = true;
        if(this.ifCurrentWorkflowTypeCodeScanSafetyScan()) {
          if(this.safety_scan_result_list.list != null && this.safety_scan_result_list.list.length > 0){
            this.safety_scan_result_list.list.forEach(item=>{
              if(item.scanResult == null || item.scanResult == ""){
                isEnd = false;
              }
            });
          } else{
            isEnd = false;
          }
        }
        return isEnd;
      },

      refreshWorkflow() {
        if (this.dialogVisible) {
          this.renderWorkflowDetail()
        }
      },

      getPipelineDetail(workflowId) {
        $http.get($http.api.pipeline.stagesExecOverview, {workflowId: workflowId}).then(res => {
          this.stageRunningDetailLst = res.data;
          this.reGenerateStageRunningVo(res.data)
        })
      },

      //查询版本流水线概要信息
      getVersionPipelineOverview(workflowId) {
        $http.get($http.api.pipeline.workflowExecOverview, {workflowId: workflowId}).then(res => {
          if (res.status == 200) {
            this.pipelineName = res.data.pipelineDTO.name;
            this.stageRunningDetailLst = res.data.stageRunningDetailsLst;
            this.stageList = res.data.pipelineDTO.stageLst;
            this.reGenerateStageRunningVo(res.data.stageRunningDetailsLst)

            if (!this.inited) {
              this.inited = true;
              if (res.data.appVersionInfo != "") {
                this.appVersionInfo = JSON.parse(res.data.appVersionInfo);
                this.containsAppVersion = true;
              }

              //找出当前应该应该选中的stage和workflow
              this.stageRunningVoList.some((stageRunningVo, index) => {
                if (stageRunningVo.stageRunningStatus != this.STAGE_STATUS.SUCCESS || index == this.stageRunningVoList.length - 1) {
                  this.currentSelectedStage = stageRunningVo;

                  stageRunningVo.workflowTaskLst.some((workflow, wIndex) => {
                    //完成流转未执行或者完成成功流转不成功
                    if (this.ifWorkflowCurrent(workflow) || wIndex == stageRunningVo.workflowTaskLst.length - 1) {
                      this.currentSelectedWorkflow = workflow;
                      return true;
                    }
                  });

                  return true;
                }
              })
            }

          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      ifWorkflowCurrent(workflow) {
        //完成流转成功或失败  完成且成功流传不成功
        return (workflow.transferType == this.TRANSFER_TYPE.FINISHED_TRANSFER
          && workflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.SUCCESS
          && workflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.FAILURE)
          || (workflow.transferType == this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER
            && workflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.SUCCESS);
      },

      renderWorkflowDetail() {
        //假如不存在的话，不要刷新
        if (!this.currentSelectedWorkflow || !this.currentSelectedWorkflow.task) {
          return;
        }
        let itemType = this.currentSelectedWorkflow.task.type;
        let workflowId = this.currentSelectedWorkflow.workflowId;
        let workflowTaskId = this.currentSelectedWorkflow.id;

        //处理回显问题
        if (itemType === this.WORKFLOW_TASK_TYPE.AUTO_TEST
          || itemType === this.WORKFLOW_TASK_TYPE.INTF_AUTO_TEST
          || itemType === this.WORKFLOW_TASK_TYPE.UI_AUTO_TEST
          || itemType === this.WORKFLOW_TASK_TYPE.VOICE_ASSISTANT_AI_AUTO_TEST) {
          this.getAutoTestResult({
            pageNum: 1,
            pageSize: 5,
            workflowTaskId: workflowTaskId
          });
        }

        setTimeout(() => {
          //更新workflow的操作记录
          this.getWorkflowHistory(workflowTaskId);
        },200);

        this.deployInfo = '';
        if (itemType === this.WORKFLOW_TASK_TYPE.DEPLOY) {
          let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
          if (setting) {
            this.deployInfo = '部署环境：' + (setting.environment == 'dev' ? '开发' : '测试');
            if (this.containsAppVersion) {
              this.getDeployHistory({
                appVersion: this.appVersionInfo.versionName,
                pageNum: 1,
                pageSize: 10,
                env: setting.environment
              }); //部署历史
            }
          }
        } else if (itemType === this.WORKFLOW_TASK_TYPE.BUILD) {
          this.getWorkflowLog(workflowId, workflowTaskId);

        } else if (itemType === this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT) {
          this.getWorkflowLog(workflowId, workflowTaskId);

        } else if (itemType === this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT || itemType === this.WORKFLOW_TASK_TYPE.SUBMIT_TEST
          || itemType === this.WORKFLOW_TASK_TYPE.PASS_TEST) {
          let setting = JSON.parse(this.currentSelectedWorkflow.task.setting)

          let gatekeeperType = "角色";
          let gatekeeperTitle = "类型名称";
          let gatekeeper = "";
          if(setting.type == 0){
            gatekeeper = setting.role;
          }else{
            gatekeeperType = "人员";
            gatekeeperTitle = "工号";
            gatekeeper = setting.people;
          }
          this.operatorInfo = `类型：【${gatekeeperType}】 ${gatekeeperTitle}：${gatekeeper}`;

        } else if (itemType === this.WORKFLOW_TASK_TYPE.AUTO_TEST || itemType === this.WORKFLOW_TASK_TYPE.INTF_AUTO_TEST
          || itemType === this.WORKFLOW_TASK_TYPE.UI_AUTO_TEST || itemType === this.WORKFLOW_TASK_TYPE.VOICE_ASSISTANT_AI_AUTO_TEST) {
          this.getAutoTestResult({
            pageNum: 1,
            pageSize: 5,
            workflowTaskId: workflowTaskId
          });

        } else if (itemType === this.WORKFLOW_TASK_TYPE.CODE_SCANNING) {
          let setting = JSON.parse(this.currentSelectedWorkflow.task.setting);
          if (setting) {
            if (setting.taskType == this.CODE_SCANNING_TYPE.FIND_BUGS) {
              this.getCodeScanningFindBugsResult({
                pageNum: 1,
                pageSize: 5,
                workflowTaskId: workflowTaskId
              });
            } else if (setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE || setting.taskType == this.CODE_SCANNING_TYPE.SONARQUBE_OPPO_RULE) {
              this.getCodeScanningSonarQubeResult({
                pageNum: 1,
                pageSize: 5,
                workflowTaskId: workflowTaskId
              });
              this.getWorkflowLog(workflowId, workflowTaskId);
            } else if (setting.taskType == this.CODE_SCANNING_TYPE.SAFETY_SCAN) {
              this.getCodeScanSafetyScanResult({
                pageNum: 1,
                pageSize: 5,
                workflowTaskId: workflowTaskId
              })}
            else {
              console.error("暂不支持的代码扫描类型" + setting.taskType);
            }
          }
        } else if (itemType === this.WORKFLOW_TASK_TYPE.UNIT_TEST) {
          this.getWorkflowLog(workflowId, workflowTaskId);
        } else if (itemType === this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE) {
          this.getWorkflowLog(workflowId, workflowTaskId);
        } else if (itemType === this.WORKFLOW_TASK_TYPE.MVN_DEPLOY) {
          this.getWorkflowLog(workflowId, workflowTaskId);
        }

        this.lastWorkflowTaskId = workflowTaskId;
      },

      //stage点击事件
      stageClick(stageId) {
        let changeSuccess = false;  //如果stage未开始，不能点击
        this.stageRunningVoList.some((stage) => {
          if (stage.id == stageId) {
            if (stage.stageRunningStatus == this.STAGE_STATUS.NOT_RUNNING) {
              return true;
            }

            changeSuccess = true;
            if (this.currentSelectedStage && this.currentSelectedStage.id != stage.id) {
              this.workflowAutoTransfer = false;
            }
            this.currentSelectedStage = stage;

            return true;
          }
        })

        if (!changeSuccess) {
          this.$message({
            message: '该阶段任务尚未开始！',
            type: 'info'
          })
          return;
        }

        this.currentSelectedWorkflow = this.currentSelectedWorkflowList.find((workflow, index) => {
          return this.ifWorkflowCurrent(workflow) || index == this.currentSelectedWorkflowList.length - 1;
        })

      },

      //获取工作流操作信息（当前只有最后一次）
      getWorkflowHistory(val) {
        $http.get($http.api.appdate.apipipelineexectaskdetails, {workflowTaskId: val}).then(res => {
          let detail = res.data;
          this.satefyTestResult = '';
          this.lastWorkflowOperation = [
            {
              workflowTaskType: this.currentSelectedWorkflow.task.type,
              workflowTaskTypeName: this.getWorkflowTaskTypeName(this.currentSelectedWorkflow.task.type),
              startTime: detail.startTime,
              transferType: this.getTransferTypeDesc(detail.transferType),
              executeType: (this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.autoExec) ? '自动触发' : '手动触发',
              triggerUser: detail.triggerUser ? (detail.triggerUserName + '(' + detail.triggerUser + ')') : '-',
              workflowTaskStatus: detail.workflowTaskStatus,
              showStatus: this.getWorkflowTaskStatus(detail.workflowTaskStatus,this.currentSelectedWorkflow.task.type),
              errorMsg: detail.errorMsg,
              result: detail.result,
              executeName: this.getExecuteName(detail),
              stopName: this.getStopName(detail),
              manualStop: detail.manualStop,
            }
          ];
          if(detail.type === this.WORKFLOW_TASK_TYPE.PASS_TEST){
            this.satefyTestResult = detail.result;
          }
        });
      },

      getExecuteName(taskDetail) {
        if (taskDetail.type == this.WORKFLOW_TASK_TYPE.BUILD) {
          return taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新构建" : "构建";
        } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
          let envName = '';
          if (this.currentSelectedWorkflow) {
            let deploySetting = this.currentSelectedWorkflow.task.setting;
            let env = JSON.parse(deploySetting).environment;
            envName = (env == 'dev' ? '开发' : env == 'test' ? '测试' : '');
          }
          return (taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新部署" : "部署") + envName;
        } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.SUBMIT_TEST) {
          return "提测";
        } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.PASS_TEST) {
          return "测试通过";
        } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.UNIT_TEST) {
          return taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新执行" : "执行";
        } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.AUTO_TEST) {
          return "";
        } else if (taskDetail.type == this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE) {
          return taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE ? "重新集成" : "集成";
        }
        return "执行";
      },

      getStopName(taskDetail) {
        if(taskDetail.manualStop == 1 && taskDetail.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING){
          return "停止中..."
        }

        return "停止";
      },

      getTransferTypeDesc(transferType) {
        switch (transferType) {
          case this.TRANSFER_TYPE.FINISHED_TRANSFER:
            return '完成流转';
          case this.TRANSFER_TYPE.UNFINISHED_TRANSFER:
            return '未完成流转';
          case this.TRANSFER_TYPE.FINISHED_SUCCESS_TRANSFER:
            return '完成且成功流转';
        }
      },

      getWorkflowTaskStatus(status,type) {
        switch (status) {
          case this.WORKFLOW_TASK_STATUS.RUNNING:
            return '<i class="el-icon-loading"></i>';
          case this.WORKFLOW_TASK_STATUS.SUCCESS:
            return '成功';
          case this.WORKFLOW_TASK_STATUS.FAILURE:
            return '失败';
          case this.WORKFLOW_TASK_STATUS.NEW:
            return '未开始';
          case this.WORKFLOW_TASK_STATUS.WAIT:
            return '等待执行';
          case this.WORKFLOW_TASK_STATUS.MANUAL_STOP:
            return '手工暂停';
        }
      },

      getWorkflowTaskTypeName(type) {
        switch (type) {
          case this.WORKFLOW_TASK_TYPE.BUILD:
            return '构建';
          case this.WORKFLOW_TASK_TYPE.DEPLOY:
            return '部署';
          case this.WORKFLOW_TASK_TYPE.CODE_SCANNING:
            return '代码扫描';
          case this.WORKFLOW_TASK_TYPE.INTF_AUTO_TEST:
            return '接口自动化测试';
          case this.WORKFLOW_TASK_TYPE.UI_AUTO_TEST:
            return 'UI自动化测试';
          case this.WORKFLOW_TASK_TYPE.VOICE_ASSISTANT_AI_AUTO_TEST:
            return '语音助手AI自动化测试';
          case this.WORKFLOW_TASK_TYPE.ARTIFICIAL_CHECKPOINT:
            return '人工卡点';
          case this.WORKFLOW_TASK_TYPE.SUBMIT_TEST:
            return '提测';
          case this.WORKFLOW_TASK_TYPE.PASS_TEST:
            return '测试通过';
          case this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT:
            return '自定义脚本';
          case this.WORKFLOW_TASK_TYPE.UNIT_TEST:
            return '单元测试';
          case this.WORKFLOW_TASK_TYPE.AUTO_TEST:
            return '自动化测试';
          case this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE:
            return '分支管理器';
          case this.WORKFLOW_TASK_TYPE.MVN_DEPLOY:
            return '上传mvn仓库';
        }
      },

      //获取部署历史信息
      getDeployHistory(val) {
        let params = val;
        $http.get($http.api.appdate.apiinstancedeploy_history, params).then(res => {
          if (res.status == 200) {

            //拼接环境
            if (res.data && res.data.result){
              for (let i = 0; i < res.data.result.length; i++) {
                let item = res.data.result[i];
                item.env = params.env;
              }
            }

            this.deploy_history_list = res.data;
          }
        });
      },

      //部署历史分页
      handleDeployHistorySizeChange(newPageSize) {
        this.deploy_history_list.pageSize = newPageSize;

        if (this.containsAppVersion) {
          let deploySetting = this.currentSelectedWorkflow.task.setting;
          if (deploySetting) {
            let env = JSON.parse(deploySetting).environment;
            this.getDeployHistory({
              pageNum: this.deploy_history_list.pageNum,
              pageSize: this.deploy_history_list.pageSize,
              appVersion: this.appVersionInfo.versionName,
              env: env
            });
          } else {
            this.$message({
              message: '获取部署设置环境参数失败, deploySetting:' + deploySetting,
              type: "error"
            });
          }
        }
      },

      handleDeployHistoryPageChange(newPageNum) {
        this.deploy_history_list.pageNum = newPageNum;
        if (this.containsAppVersion) {
          let deploySetting = this.currentSelectedWorkflow.task.setting;
          if (deploySetting) {
            let env = JSON.parse(deploySetting).environment;
            this.getDeployHistory({
              pageNum: this.deploy_history_list.pageNum,
              pageSize: this.deploy_history_list.pageSize,
              appVersion: this.appVersionInfo.versionName,
              env: env
            });
          } else {
            this.$message({
              message: '获取部署设置环境参数失败, deploySetting:' + deploySetting,
              type: "error"
            });
          }
        }
      },

      //查询流水线执行日志
      getWorkflowLog(workflowId, workflowTaskId) {
        let offsets = 0;
        if (workflowTaskId == this.lastWorkflowTaskId) {
          offsets = this.lastOffsets;
        } else {
          this.lastWorkflowTaskId = workflowTaskId;
          offsets = this.lastOffsets = 0;
          this.logDetail = '';
        }

        if (offsets == -1) {
          return;
        }

        let params = {
          // workflowId:workflowId,
          workflowTaskId: workflowTaskId,
          offset: offsets,
        }

        $http.get($http.api.appdate.apipipelinelogs, params).then(res => {
          let str = res.data.logs;
          if (str && str.length > 0) {

            let lineArr = str.split('\n');
            let newStr = '';
            if (lineArr.length > 0) {
              lineArr.forEach((line) => {
                if (line && line.length > 0) {
                  if (line.indexOf('[WARN]') > -1 || line.indexOf('[WARNING]') > -1) {
                    newStr += '<span class="c-yellow">' + line + '</span><br/>';
                  } else if (line.indexOf('[ERROR]') > -1) {
                    newStr += '<span class="c-error">' + line + '</span><br/>';
                  } else {
                    newStr += line + '<br/>';
                  }
                }

              })
            }
            this.logDetail += newStr;
          }
          this.lastOffsets = res.data.offset;

        });
      },

      //流水线任务按钮点击事件
      workflowClick(workflowId) {
        //如果没变化，手动触发刷新
        if (this.currentSelectedWorkflow.id == workflowId) {
          this.refreshWorkflow();
        }

        this.currentSelectedWorkflow = this.currentSelectedWorkflowList.find((workflow) => {
          return workflow.id == workflowId;
        })

        if (this.pipelineWorkflow && this.pipelineWorkflow.id != this.currentSelectedWorkflow.id) {
          this.workflowAutoTransfer = false;
        } else {
          this.workflowAutoTransfer = true;
        }

      },

      canManualDeploy(val) {
        //部署类型、自动任务、成功或失败
        return (!this.jumpFromPipelineExecHistory) &&
          (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.DEPLOY
            && this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.autoExec
            && (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS || val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE))
      },

      canExecuteNextWorkflow(val) {
        return (!this.jumpFromPipelineExecHistory) &&
          (val.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.SUCCESS && val.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.NEW &&
            val.workflowTaskType == this.WORKFLOW_TASK_TYPE.DEPLOY && this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.autoExec == false)
      },

      canExecuteAutoTestReRun(val) {
        return (!this.jumpFromPipelineExecHistory) &&
          (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE &&
            val.workflowTaskType == this.WORKFLOW_TASK_TYPE.AUTO_TEST)
      },

      canDownloadUnitTestReports(val) {
        return (!this.jumpFromPipelineExecHistory) &&
          (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.UNIT_TEST && (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS || val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE))
      },

      getUnitTestReportsDownloadUrl(val) {
        if (val) {
          let unitTestReportUrl = JSON.parse(val).unitTestReportUrl;
          return unitTestReportUrl;
        }
        return "";
      },

      ifDeployTestOrCanGo(val) {
        if (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.DEPLOY) {
          if (this.currentSelectedWorkflow && this.currentSelectedWorkflow.type && this.currentSelectedWorkflow.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
            if (this.currentSelectedWorkflow.task && this.currentSelectedWorkflow.task.setting) {
              let deploySetting = this.currentSelectedWorkflow.task.setting;
              let env = JSON.parse(deploySetting).environment;
              //部署测试，开始校验
              if (env == 'test') {
                return this.authFunction('FUNC_APP_DEPLOY_TEST', 2, this.appId);
              }
            }
            return true;
          }
        }
        return true;
      },

      canExecute(val) {
        return (!this.jumpFromPipelineExecHistory) &&
          (val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE
            || val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.WAIT
            || (this.currentSelectedWorkflow.task
              && this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.DEPLOY
              && !this.currentSelectedWorkflow.task.autoExec
              && val.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.NEW));
      },

      //只有运行中的构建任务才显示停止按钮
      canExcuteTaskStop(val){
        return (!this.jumpFromPipelineExecHistory &&
          val.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING
          && (val.workflowTaskType == this.WORKFLOW_TASK_TYPE.BUILD
            || val.workflowTaskType == this.WORKFLOW_TASK_TYPE.UNIT_TEST
            || val.workflowTaskType == this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT
            || val.workflowTaskType == this.WORKFLOW_TASK_TYPE.AUTO_TEST));

      },

      //点击执行按钮重新拉取数据
      async executeWorkflow(val) {
        if (this.currentSelectedWorkflow.task
          && this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.DEPLOY
          && !this.currentSelectedWorkflow.task.autoExec) {
          this.manualDeploy();
          return;
        }

        if (this.currentSelectedWorkflow.task
          && (this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.BUILD
            || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.UNIT_TEST
            || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.CUSTOMIZED_SCRIPT
            || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.BRANCH_MANAGE
            || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.CODE_SCANNING
            || this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.MVN_DEPLOY)) {
          this.lastOffsets = 0;
          this.logDetail = '';
        }

        //测试通过命令发送前增加一个confirm操作
        if (this.currentSelectedWorkflow.task
          && this.currentSelectedWorkflow.task.type == this.WORKFLOW_TASK_TYPE.PASS_TEST){
          let confirmResult;
          try {
            let behindData = [];
            let res = {};
            try {
              let params = { workflowId: this.currentSelectedWorkflow.workflowId, workflowTaskId: this.currentSelectedWorkflow.id };
              res = await $http.get($http.api.appdate.appVersionBehindCount, params);
            } catch (e) {
              res.status = 0;
            }
            if (res.status == 200) {
              behindData = res.data;
            }


            let msg = "";
            if (behindData && behindData.length > 0) {
              msg = msg + "当前版本";
              behindData.forEach((item, index) => {
                if (item.hasBehind == "true") {
                  let temp = "已落后" + item.sourceBranch + "分支" + item.behindCount + "次Commit提交，"
                  msg = msg + temp;
                }
              });
            }
            msg = msg + "确认对当前版本进行“测试通过”操作？";
            confirmResult = await this.$confirm(msg, "提示", {
              distinguishCancelAndClose: true,
              confirmButtonText: "确定",
              cancelButtonText: "取消",
              type: "warning"
            });
          } catch(e) {
            //do nothing
          }
          if(!confirmResult){
            return false;
          }
        }
        this.doExecuteWorkflow();
      },

      stopTaskExecute(val) {
        if(val.manualStop == 1){
          return false;
        }

        //后端其实已经保证不会继续跑下去了
        this.workflowAutoTransfer = false;
        let formData = new FormData();
        formData.set('workflowId', this.currentSelectedWorkflow.workflowId);
        formData.set('workflowTaskId', this.currentSelectedWorkflow.id);
        if(val.workflowTaskType == this.WORKFLOW_TASK_TYPE.AUTO_TEST){
          formData.set('updateStatus', 'true');
        }

        $http.post($http.api.pipeline.stopWorkflowTask, formData).then(res => {
          this.$message({
            message: '停止指令已发送，请等待任务停止执行',
            type: 'info'
          });
        });
      },

      doExecuteWorkflow() {
        if (this.pipelineWorkflow && this.currentSelectedWorkflow && this.pipelineWorkflow.id == this.currentSelectedWorkflow.id) {
          this.workflowAutoTransfer = true;
        }
        let formData = new FormData();
        formData.set('workflowId', this.currentSelectedWorkflow.workflowId);
        formData.set('workflowTaskId', this.currentSelectedWorkflow.id);
        $http.post($http.api.appdate.apipipelineexecute, formData).then(res => {
          this.renderWorkflowDetail();
          this.getPipelineDetail(this.workflowId);
          this.$message({
            message: '执行指令已发送',
            type: 'info'
          })
        });
      },

      //自动化任务执行结果
      getAutoTestResult(val) {
        let params = val;
        $http.get($http.api.appdate.auto_test_result, params)
          .then(res => {
            if (res.status == 200) {
              this.deploy_project_list = res.data;
              //逻辑变为不能重跑 所以只会有一个结果
              this.deploy_project_list.list.forEach(item => {
                this.underUrlInfo = item.detailUrl;
                this.underStatus = item.taskStatus;
              })
            }
          });
      },

      //自动化任务执行结果分页
      handAutoTestinnerSizeChange(val) {
        this.getAutoTestResult({
          pageNum: val,
          pageSize: this.deploy_project_list.pageSize,
          workflowTaskId: this.workflowTaskId
        })
      },
      handAutoTestinnerPageChange(val) {
        this.getAutoTestResult({
          pageNum: val,
          pageSize: this.deploy_project_list.pageSize,
          workflowTaskId: this.workflowTaskId
        })
      },

      //代码扫描执行结果FindBugs
      getCodeScanningFindBugsResult(val) {
        let params = val;
        $http.get($http.api.appdate.apipipelinetestfindbugstaskresult, params)
          .then(res => {
            if (res.status == 200) {
              this.find_bugs_result_list = res.data;
            }
          });
      },

      //代码扫描执行结果SonarQube
      getCodeScanningSonarQubeResult(val) {
        let params = val;
        $http.get($http.api.appdate.apipipelinesonartaskresult, params)
          .then(res => {
            if (res.status == 200) {
              this.sonarqube_result_list = res.data;
            }
          });
      },
      getCodeScanSafetyScanResult(val) {
        let params = val;
        $http.get($http.api.appdate.apipipelinetestsafetyscantaskresult, params)
            .then(res => {
              if (res.status == 200) {
                this.safety_scan_result_list = res.data;
              }
            });
      },
      //新窗口打开页面
      openUrlInNewWindow(val) {
        if (val) {
          window.open(val);
        }
      },

      //新窗口打开页面
      openSafetyUrlInNewWindow(val, type) {
        let resultJson = JSON.parse(val);
        if(type === 0){
          this.openUrlInNewWindow(resultJson.privacyUrl);
        }
        if(type === 1){
          this.openUrlInNewWindow(resultJson.secTestUrl);
        }
      },

      getSafetyTestUrl(val, type){
        let resultJson = JSON.parse(val);
        if(type === 0){
          return resultJson.privacyUrl;
        }
        if(type === 1){
          return resultJson.secTestUrl;
        }
        return "";
      },

      handleClose_bb() {
        this.dialogVisible = false;
        this.fullscreen = false;   //清空全屏效果

        this.$emit('refreshVersion');
        if(this.appVersionUrl){
          this.$router.replace({name: 'appVersions', query : { bizId: this.getUrlBizId(), appId: this.getUrlAppId()}});
        }
      },

      //手动部署
      manualDeploy() {
        if (!this.containsAppVersion) {
          this.$message({
            message: '当前流水线无可用应用版本，无法执行部署操作',
            type: "error"
          });
          return;
        }

        let deploySetting = this.currentSelectedWorkflow.task.setting;
        if (deploySetting) {
          let env = JSON.parse(deploySetting).environment;
          this.$refs.paasDeploy.setDeployUrl(this.appVersionInfo.versionId, env)
        } else {
          this.$message({
            message: '获取部署设置环境参数失败, deploySetting:' + deploySetting,
            type: "error"
          });
        }
      },

      ifWorkflowFinish(workflow) {
        return workflow.transferType == this.TRANSFER_TYPE.UNFINISHED_TRANSFER
          || (workflow.transferType == this.TRANSFER_TYPE.FINISHED_TRANSFER
            && workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE)
          || workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS;
      },

      ifStageCurrent(stage) {
        return stage.stageRunningStatus == this.STAGE_STATUS.RUNNING
          || stage.stageRunningStatus == this.STAGE_STATUS.WAIT
          || stage.stageRunningStatus == this.STAGE_STATUS.FAILURE;
      },

      reGenerateStageRunningVo(newVal, maxCount) {
        let pipelineRunningWorkflow;
        let pipelineRunningStage;
        let findRunning = false;
        newVal.forEach((stageRunning) => {
          let stageRunningWorkflow;
          let finish = 0;

          //stage如果在running的状态的情况
          if (this.ifStageCurrent(stageRunning) && !pipelineRunningStage) {
            pipelineRunningStage = stageRunning;
          }

          stageRunning.workflowTaskLst.forEach((workflow) => {
            //填充stageVo
            workflow.task = this.pipelineTaskMap[workflow.pipelineTaskId]

            if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING) {
              findRunning = true;
            }

            if (this.ifWorkflowFinish(workflow)) {
              finish++;
            }

            if (this.ifWorkflowCurrent(workflow)) {
              if (!pipelineRunningWorkflow) {
                pipelineRunningWorkflow = workflow;
              }

              if (!stageRunningWorkflow) {
                stageRunningWorkflow = workflow;
              }
            }

            //处理名称
            if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.SUCCESS) {
              workflow.task.showName = '<i class="iconfont icon-status-success-sm"></i>&nbsp;' + workflow.task.name;
            } else if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE) {
              workflow.task.showName = '<i class="iconfont icon-status-fail-sm"></i>&nbsp;' + workflow.task.name;
            } else if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING) {
              workflow.task.showName = '<i class="el-icon-loading"></i>&nbsp;' + workflow.task.name;
            } else if (workflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.WAIT) {
              workflow.task.showName = '<i class="iconfont icon-status-waiting-sm"></i>&nbsp;' + workflow.task.name;
            } else {
              workflow.task.showName = '<i class="iconfont icon-status-init-sm" style="font-size:12px;"></i>&nbsp;' + workflow.task.name;
            }
          });

          //如果没有找到，最后一个
          if (!stageRunningWorkflow) {
            stageRunningWorkflow = stageRunning.workflowTaskLst[stageRunning.workflowTaskLst.length - 1];
          }

          if (stageRunning.stageRunningStatus == this.STAGE_STATUS.NOT_RUNNING) {
            stageRunning.percentage = 0;
            stageRunning.desc = '未开始';
          } else {
            stageRunning.percentage = Math.round((finish * 100) / stageRunning.workflowTaskLst.length);
            stageRunning.percentage = stageRunning.percentage == 0 ? 1 : stageRunning.percentage;

            let clazz = '';
            let taskName = stageRunningWorkflow.task.name;
            let statusDesc = this.getWorkflowTaskStatus(stageRunningWorkflow.workflowTaskStatus);
            if (stageRunningWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.FAILURE) {
              clazz = 'c-red';
            }

            stageRunning.desc = `<span class="task-name ${clazz}" title="${taskName}">${taskName}</span><br/><span class="${clazz}">${statusDesc}</span>`;
          }

        });

        clearInterval(this.currentPipelineInterval)
        if (findRunning || (pipelineRunningWorkflow &&
          (pipelineRunningWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING
            || pipelineRunningWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.NEW))) {
          this.currentPipelineInterval = setInterval(() => {
            this.getPipelineDetail(this.workflowId)
          }, 1500)
        }

        let fresh = true;
        // 如果可以自动流转，自动流转
        if (this.workflowAutoTransfer) {
          if (pipelineRunningWorkflow && pipelineRunningWorkflow.id != this.currentSelectedWorkflow.id) {
            this.currentSelectedWorkflow = pipelineRunningWorkflow;
            fresh = false;
          }

          if (pipelineRunningStage && pipelineRunningStage.id != this.currentSelectedStage.id) {
            this.currentSelectedStage = pipelineRunningStage;
          }

        }

        if (fresh) {
          //刷新最新的任务状态
          newVal.some((stage) => {
            if (this.currentSelectedStage && stage.id == this.currentSelectedStage.id) {
              stage.workflowTaskLst.some((workflow) => {
                if (workflow.pipelineTaskId == this.currentSelectedWorkflow.task.id) {
                  if (this.currentSelectedWorkflow.workflowTaskStatus != workflow.workflowTaskStatus) {
                    this.currentSelectedWorkflow = workflow;
                  }

                  return true;
                }
              });
              return true;
            }
          })

        }

        this.stageRunningVoList = newVal;
      }
    },

    watch: {
      dialogVisible: function (newVal, oldVal) {
        if (newVal == false) {
          clearInterval(this.currentPipelineInterval)
          clearInterval(this.currentWorkflowInterval)
        }
      },

      currentSelectedWorkflow: function (newWorkflow, oldWorkflow) {
        this.refreshWorkflow();
        clearInterval(this.currentWorkflowInterval)
        if (newWorkflow.workflowTaskStatus == this.WORKFLOW_TASK_STATUS.RUNNING && this.dialogVisible) {
          this.currentWorkflowInterval = setInterval(() => {
            if (this.currentSelectedWorkflow.workflowTaskStatus != this.WORKFLOW_TASK_STATUS.RUNNING && this.ifSafetyScanEnd()) {
              clearInterval(this.currentWorkflowInterval);
              return;
            }
            this.refreshWorkflow();
          }, 1500);
        }

      },

      logDetail() {
        this.$nextTick(() => {
          let logDetailDiv = this.$el.querySelector('#logDetail');
          if (logDetailDiv) {
            logDetailDiv.scrollTop = logDetailDiv.scrollHeight
          }
        })
      }
    },

    computed: {
      currentSelectedWorkflowList: {
        get() {
          return this.currentSelectedStage.workflowTaskLst;
        }
      },
      pipelineTaskMap: {
        get() {
          let tempWorkflowMap = {}
          this.stageList.forEach((stage) => {
            stage.pipelineTaskLst.forEach((pipelineTask) => {
              tempWorkflowMap[pipelineTask.id] = pipelineTask
            })
          })
          return tempWorkflowMap;
        }
      },

      pipelineStage: {
        get() {
          return this.stageRunningDetailLst.find((stage) => {
            return this.ifStageCurrent(stage);
          });
        }
      },

      //真实的最新任务节点
      pipelineWorkflow: {
        get() {
          let temp
          this.stageRunningDetailLst.some((stageRunning) => {
            temp = stageRunning.workflowTaskLst.find((workflow) => {
              return this.ifWorkflowCurrent(workflow);
            })
            if (temp && temp.id) {
              return true;
            }
          })

          return temp;
        }
      },
      workflowTaskId: {
        get() {
          return this.currentSelectedWorkflow.id;
        }
      }
    },

    components: {
      paasDeploy
    }
  }
</script>

<style lang="scss" scoped>
  .oem-line-box {
    overflow: hidden;
    height: 100%;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    background: transparent;

    .oem-line-header {
      border-bottom: 2px solid rgb(214, 217, 224);
      margin-top: 10px;

      span {
        margin-right: 20px;
        margin-left: 10px;
      }
    }

    .oem-body_a {
      max-height: 215px;
      margin-top: 10px;
      overflow: auto;
      overflow-y: hidden;
      white-space: nowrap;
      // margin-right: 10px;
      // margin-bottom: 10px;
      background: hsla(216, 63%, 97%, 0.7);

      .oem-body_b {
        width: calc(25% - 5px);
        height: 180px;
        margin-top: 10px;
        margin-bottom: 10px;
        display: inline-block;
        color: #606266;
        margin-left: 10px;
        cursor: pointer;

        .box-card {
          width: 78%;
          height: 150px;
          padding: 10px;
          display: inline-block;
          border: 2px solid #d6d9e0;

          .box-card-title {
            border-bottom: 2px solid #d6d9e0;
            padding-bottom: 8px;
          }

          .card-progress {
            margin-top: 20px;
          }

          .circle-time {
            display: inline-block;
            width: 80px;
            height: 40px;
            float: right;
            margin-top: 58px;
            font-size: 18px;
            font-weight: 600;
            color: #606266;
          }
        }

        .active {
          border: 2px solid #409EFF;
          box-shadow: 0 0 10px #409EFF;
        }

        .box-card-arrow {
          width: 12%;
          height: 180px;
          display: inline-block;
          vertical-align: top;
          text-align: right;
          line-height: 210px;
          font-size: 26px;
          padding-bottom: 2px;
        }
      }

      .triangle {
        width: 0px;
        height: 0px;
        border: 10px solid #409EFF;
        border-top-color: #409EFF;
        border-bottom-color: transparent;
        border-left-color: transparent;
        border-right-color: transparent;
        position: relative;
        top: 38px;
        left: -10px;
      }

      .triangle2 {
        width: 0px;
        height: 0px;
        border: 8px solid #F2F6FC;
        border-top-color: #F2F6FC;
        border-bottom-color: rgba(200, 200, 200, 0);
        border-right-color: rgba(200, 200, 200, 0);
        border-left-color: rgba(200, 200, 200, 0);
        position: relative;
        top: 34px;
        left: -28px;
      }
    }

    .smallDiv {
      margin-right: 13px;

      .solid-arrow {
        height: 1px;
        background: black;
        display: inline-block;
        width: calc(48% - 2px);
        margin-bottom: 5px;
      }

      .el-icon-arrow-up {
        font-size: 30px;
      }
    }

    .box-card-body {
      border: 1px solid #d6d9e0;
      padding: 0px 5px 5px;

      .box-card-body-head {
        min-height: 50px;
        padding-top: 10px;
        padding-left: 10px;
        overflow-y: hidden;
        white-space: nowrap;

        .circle-line {
          display: inline-block;

          .circle-head {
            height: 30px;
            min-width: 60px;
            padding-left: 5px;
            padding-right: 5px;
            border: 2px solid #d6d9e0;
            display: inline-block;
            text-align: center;
            line-height: 25px;
            margin-bottom: 10px;
            border-radius: 5px;
            cursor: pointer;
          }

          .circle-active {
            cursor: pointer;
            border: 2px solid #409EFF;
            box-shadow: 0 0 10px #409EFF;
          }

          .circle-head:hover {
            border: 2px solid #409EFF;
          }

          .line-head {
            height: 2px;
            width: 100px;
            background: #d6d9e0;
            display: inline-block;
            vertical-align: text-top;
            margin-top: 10px;
            // margin-left: -4px;
          }
        }

        .triangleBtn {
          width: 0px;
          height: 0px;
          border: 10px solid #409EFF;
          border-top-color: #409EFF;
          border-bottom-color: transparent;
          border-left-color: transparent;
          border-right-color: transparent;
          position: relative;
          top: 38px;
          right: 50px;
        }

        .triangleBtn2 {
          width: 0px;
          height: 0px;
          border: 8px solid #F2F6FC;
          border-top-color: #FFF;
          border-bottom-color: rgba(200, 200, 200, 0);
          border-right-color: rgba(200, 200, 200, 0);
          border-left-color: rgba(200, 200, 200, 0);
          position: relative;
          top: 34px;
          right: 68px;
        }

      }

      .publicclass {
        /*padding-top: 10px;*/
        // padding-left: 10px;
        /*margin-top: 10px;*/

        .title-detaile {
          color: #544c4c;
          font-size: 14px;
          font-weight: 400;
          margin-top: 10px;
          display: inline-block;
        }

      }

      .box-card-body-body {
        // margin-left: 10px;

        .box-card-body-body_right {
          display: inline-block;
          width: 100%;
          height: 500px;
          overflow: auto;
          background: black;
          border-left: 0;
          color: aliceblue;
          word-wrap: break-word;
          word-break: break-word;

          p {
            line-height: 18px;
            margin-left: 10px;
            margin-right: 10px;
          }
        }
      }
    }
  }
</style>
