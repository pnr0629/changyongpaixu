<template>
  <div id="appPipelineList" class="content-outer-box">

    <!--创建编译任务-->
    <div>
      <div class="new-bulid-task">
        <el-form ref="form" :model="compileDetail" label-width="170px">
          <el-form-item label="编译任务名称">
            <el-input v-model="compileDetail.taskName" style="width:500px;" :disabled="disabledForm"></el-input>
          </el-form-item>

          <el-form-item label="默认分支">
            <el-select v-model="compileDetail.sourceBranch" placeholder="请选择" style="width:500px;" :disabled="disabledForm">
              <el-option v-for="(item,index) in branchLst" :key="index" :label="item.name" :value="item.name">

              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="默认编译任务">
            <el-radio-group v-model="compileDetail.defaultTask" :disabled="disabledForm">
              <el-radio :label='1'>是</el-radio>
              <el-radio :label='0'>否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item class='mb15' label="编译语言" prop="appLanguage">
            <el-select v-model="compileDetail.appLanguage" placeholder="请选择" class="width-input-select" :disabled="disabledForm">
              <el-option key="1" label="JAVA" value="JAVA" class="mt5 mb10">JAVA</el-option>
              <el-option key="2" label="PHP" value="PHP" class="mt5 mb10">PHP</el-option>
              <el-option key="3" label="C++" value="C++" class="mt5 mb10">C++</el-option>
              <el-option key="4" label="GO" value="GO" class="mt5 mb10">GO</el-option>
              <el-option key="5" label="HTML" value="HTML" class="mt5 mb10">HTML</el-option>
              <el-option key="6" label="JS" value="JS" class="mt5 mb10">JS</el-option>
              <el-option key="7" label="JS" value="python" class="mt5 mb10">python</el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <el-form :model="compileTaskBuildVar" ref="compileTaskBuildVarForm" label-width="80px">
          <el-col :span="24">
            <el-collapse>
              <el-collapse-item>
                <template slot="title">
                  构建参数设置 &nbsp;<i class="header-icon el-icon-question"
                    title="构建参数将会用于替换构建命令中${VAR}形式的占位符，如果是自定义脚本应用，则会作为脚本内置常量传递进自定义脚本。注意：流水线存在多个构建任务设置参数的情况，运行构建任务时只取第一个构建任务的配置！"></i>
                </template>

                <div style="max-height: 200px;">
                  <div class="mt10" style="padding: 10px; border: 1px solid #ccc; border-radius:2px"
                    v-for="(item, index) in compileTaskBuildVar.buildVarsList" :key="index">
                    <div class="btnArea">
                      <el-row type="flex" justify="end">
                        <el-button type="danger" @click="deleteBuildEnvItem(item)" :disabled="disabledForm">删除</el-button>
                      </el-row>
                    </div>
                    <el-form-item :label="'参数名'" :prop="`buildVarsList[${index}].variable`"
                      :rules="buildVarsRules.variable">
                      <el-input v-model="item.variable" placeholder="只接受全大写英文字母，下划线，阿拉伯数字（即正常编码常量命名规范）" :disabled="disabledForm"></el-input>
                    </el-form-item>

                    <el-form-item :label="'可选值'" :prop="`buildVarsList[${index}].options`"
                      :rules="buildVarsRules.options">
                      <el-input type="textarea" v-model="item.options" placeholder="多值则换行填写" :disabled="disabledForm"></el-input>
                    </el-form-item>
                    <el-form-item :label="'描述'" :prop="`buildVarsList[${index}].desc`">
                      <el-input type="textarea" placeholder='可选' v-model="item.desc" :disabled="disabledForm"></el-input>
                    </el-form-item>

                    <el-form-item :label="'默认值'" :prop="`buildVarsList[${index}]`"
                      :rules="buildVarsRules.defaultOption">
                      <el-input v-model="item.defaultOption" placeholder='必须为"可选值"中的某一项，不填写运行构建任务时默认使用第一项' :disabled="disabledForm"></el-input>
                    </el-form-item>
                  </div>

                  <el-button @click="addBuildVar()" class="fl mt10 mb10" :disabled="disabledForm">
                    +添加参数
                  </el-button>
                </div>

              </el-collapse-item>
            </el-collapse>
          </el-col>
        </el-form>

      </div>
      <div class="new-image-list">
        <div class="bulid-task">
          <div class="bulid-task-box-left">
            <draggable @end="endHandle" v-model="createdBulidTask" :options="{group:'people'}">
              <div class="bulid-task-item" v-if="createdBulidTask.length > 0" v-for="(item,index) in createdBulidTask"
                :key="index" :class="[ bulidtaskStaus.isActive === index ? 'active' : '' ]"
                @click="isActive(index,item)" @mouseenter="enter(index)" @mouseleave="leave()">
                <div :class="item.icon" class="icon-box" style="display: inline-block;"></div>
                <div class="des-name-box">
                  <p class="bulid-task-name">{{item.typeName}} <i v-show=" bulidtaskStaus.isActive === index" class="el-icon-success
                    icon-positon blue-icon"></i>
                    <i v-show="bulidtaskStaus.isAddTask === index " class="
                    icon-positon icon-circle"></i>
                  </p>
                  <p class="bulid-tasl-des">{{item.typeDesc}}<i
                      v-show="bulidtaskStaus.isAddTask === index || bulidtaskStaus.isActive === index"
                      @click.stop="deleteImage(item,index)" class="el-icon-delete icon-positon"></i></p>
                </div>
                <div class=" add-top-icon" v-show="bulidtaskStaus.isActive === index" @click.stop="beforeAdd(index)">
                  <span>+</span></div>
                <div class=" add-down-icon" v-if="bulidtaskStaus.isActive === index" @click.stop="afterAdd(index)">
                  <span>+</span></div>
              </div>
            </draggable>
            <div v-if="createdBulidTask.length === 0" @click.stop="nullAdd()" class="bulid-task-null">
              请在右侧选择任务步骤并添加
            </div>
          </div>
          <div class="bulid-task-box-right">
            <template v-if="bulidtaskStaus.isStatus === 'add'">
              <div class="add-step-title">添加步骤</div>
              <div>
                <div class="all-task">所有任务</div> <i class="el-icon-close" @click="addImage"
                  v-if="createdBulidTask.length >= 1"></i>
              </div>
              <div class="item-box">
                <div class="bulid-task-item" @mouseenter="enter(index)" @mouseleave="leave()"
                  v-for="(item,index) in imageList" :key="item.typeId">
                  <div :class="item.icon" class="icon-box" style="display: inline-block;"></div>
                  <div style="display: inline-block;margin-left: 80px;">
                    <p class="bulid-task-name">{{item.typeName}} </p>
                    <p class="bulid-tasl-des">{{item.typeDesc}}</p>
                  </div>
                  <el-button type="primary" class="add-bulid-task" v-show="bulidtaskStaus.isAddTask === index"
                    @click="addBulidTask(item)" :disabled="disabledForm">添加</el-button>
                </div>
              </div>
            </template>
            <template v-if="bulidtaskStaus.isStatus === 'editor'">
              <el-form :model="bulidStasusInfo" ref="compileForm" label-width="140px">
                <template v-if="bulidtaskStaus.typePurpose === 0">
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="步骤名称" prop="stepName"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepName" class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="镜像名称" prop="imageRepo"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-select v-model="bulidStasusInfo.imageRepo" placeholder="请选择" :disabled="disabledForm">
                        <el-option v-for="(item,index) in  imageRepolist" :key="index" :label="item.imageRepo"
                          :value="item.imageRepo">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="isMavenJavaApp(compileInfo.appType)">
                    <el-form-item class='mb15' label="mvn命令" prop="stepConfig.mvnCmd"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepConfig.mvnCmd"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="isMavenJavaApp(compileInfo.appType)">
                    <el-form-item class='mb15' label="pom文件" prop="stepConfig.pomFile"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepConfig.pomFile"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="isGradleJavaApp(compileInfo.appType)">
                    <el-form-item class='mb15' label="gradle命令" prop="stepConfig.gradleCmd"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepConfig.gradleCmd"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="isJavaApp(compileInfo.appType)">
                    <el-form-item class='mb15' label="目标文件路径" prop="stepConfig.targetDir" :rules="rules1.targetDir">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepConfig.targetDir"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="目标文件压缩格式" prop="stepConfig.targetPattern">
                      <el-select v-model="bulidStasusInfo.stepConfig.targetPattern" placeholder="请选择"
                        class="width-input-select" :disabled="disabledForm">
                        <el-option v-if="isNotWebJavaApp(compileInfo.appType)" :value="'zip'" label="zip">
                          zip
                        </el-option>
                        <el-option :value="'tar'" label="tar">
                          tar
                        </el-option>
                        <el-option v-if="isNotWebJavaApp(compileInfo.appType)" :value="'rpm'" label="rpm">rpm
                        </el-option>
                        <el-option v-if="isNotWebJavaApp(compileInfo.appType)" :value="'jar'" label="jar">jar
                        </el-option>
                        <el-option v-if="isNotWebJavaApp(compileInfo.appType)" :value="'war'" label="war">war
                        </el-option>
                        <el-option v-if="isAndroidAPKApp(compileInfo.appType)" :value="'apk'" label="apk">apk
                        </el-option>
                        <el-option v-if="isAndroidAPKApp(compileInfo.appType)" :value="'aar'" label="aar">aar
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>


                  <el-col :span='24' v-if="compileInfo.appType === APP_TYPE.TAR">
                    <el-form-item class='mb15' label="打包目录" prop="stepConfig.tarDir"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepConfig.tarDir"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>

                  <el-col :span='24' v-if="isMavenJavaApp(compileInfo.appType)">
                    <el-form-item class='mb15' label="使用公共仓库" prop="stepConfig.usePublicRepo"
                      :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-radio-group v-model="bulidStasusInfo.stepConfig.usePublicRepo" placeholder="请选择"
                        style="width: 110px" clearable class="width-input-select" :disabled="disabledForm">
                        <el-radio :label="1" class="mt5 mb10">是</el-radio>
                        <el-radio :label="0" class="mt5 mb10">否</el-radio>
                      </el-radio-group>
                      <i class="el-icon-question"
                        title="使用公共仓库会使用打包机器本地localRepository下缓存的依赖包，不使用则每次构建开辟一个临时localRepository从中央仓库下载所有的依赖包"
                        style="font-size: 16px;padding: 5px"></i>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24' v-if="compileInfo.appType === APP_TYPE.TAR">
                    <el-form-item class='mb15' label="生成文件" prop="stepConfig.targetFileName"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="bulidStasusInfo.stepConfig.targetFileName"
                        class="width-input-select" :disabled="disabledForm"></el-input>
                    </el-form-item>
                  </el-col>

                  <el-col :span='24' v-if="isShellScriptApp(compileInfo.appType)">
                    <el-form-item class='mb15' label="自定义脚本" prop="shellInfo"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input type="textarea" :rows="5" placeholder="请输入自定义的脚本" v-model="bulidStasusInfo.shellInfo"
                        clearable class="width-input-select" :disabled="disabledForm"></el-input>
                      <a class="el-icon-question cp" title="单击此图标以查看自定义脚本构建帮助文档"
                         href="http://doc.oppoer.me/pages/viewpage.action?pageId=40077947" target="view_window"
                         style="font-size: 16px;padding: 5px;" />
                    </el-form-item>

                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' :rows="5" label="自定义初始化脚本"
                      v-if="compileInfo.appType === APP_TYPE.MULTI_REPO_SHELL" prop="initShellInfo">
                      <el-input type="textarea" :rows="5" placeholder="请输入自定义初始化脚本" :disabled="disabledForm"
                        v-model="bulidStasusInfo.initShellInfo" clearable class="width-input-select">
                      </el-input>
                    </el-form-item>
                  </el-col>


                  <el-col :span='24' v-for="(item,index) in bulidStasusInfo.stepConfig.subAppBos"
                    v-if="compileInfo.appType === APP_TYPE.MULTI_REPO_SHELL" :key="index">
                    <el-col :span='9'>
                      <el-form-item label-width="140px" :label="'应用ID/源码仓库'"
                        :prop="'stepConfig.subAppBos['+index+'].subAppId'"
                        :rules="[{required: true, message: '不能为空' ,trigger:'blur'}]">
                        <el-input v-model="item.subAppId" style="width:200px;" :disabled="disabledForm"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span='9'>
                      <el-form-item label-width="0px" label="" :prop="'stepConfig.subAppBos['+index+'].sourceRepo'"
                        :rules="rules1.sourceRepo">
                        <el-input v-model="item.sourceRepo" style="width:290px; margin-left: 30px" :disabled="disabledForm"></el-input>
                      </el-form-item>
                    </el-col>
                    <el-col :span='6'>
                      <el-button @click="delSubAppBo(index)" style="margin-left: 20px; margin-top: 7px" :disabled="disabledForm"
                        v-if="bulidStasusInfo.stepConfig.subAppBos.length > 1">删除
                      </el-button>
                    </el-col>
                  </el-col>
                  <el-button v-show="compileInfo.appType === APP_TYPE.MULTI_REPO_SHELL" @click="addSubAppBos()"
                    style="margin-left:140px;" class="mt20 fl" :disabled="disabledForm">+新增应用模块
                  </el-button>
                </template>
              </el-form>
              <template v-if="bulidtaskStaus.typePurpose === 1">

              </template>
              <template v-if="bulidtaskStaus.typePurpose === 2">
                <el-form :model="harborStatusInfo" label-width="140px">
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="步骤名称"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                      <el-input placeholder="请输入内容" v-model="harborStatusInfo.stepName" class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item class='mb15' label="镜像名称"
                      :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">

                      <el-select v-model="harborStatusInfo.imageRepo" placeholder="请选择" :disabled="disabledForm">
                        <el-option v-for="(item,index) in  imageRepolist" :key="index" :label="item.imageRepo"
                          :value="item.imageRepo">

                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item label="CPU核数:">
                      <el-input v-model="harborStatusInfo.stepConfig.cpu" placeholder="请输入内容"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item label="内存(单位M):">
                      <el-input v-model="harborStatusInfo.stepConfig.memory" placeholder="请输入内容"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span='24'>
                    <el-form-item label="磁盘存储(单位G):">
                      <el-input v-model="harborStatusInfo.stepConfig.storage" placeholder="请输入内容"
                        class="width-input-select" :disabled="disabledForm">
                      </el-input>
                    </el-form-item>
                  </el-col>
                </el-form>
              </template>
            </template>

          </div>

        </div>
        <div slot="footer" class="dialog-footer" style="text-align: center;padding-top: 20px;">
          <el-button v-if="disabledForm === false" @click="goToCompileList">取消</el-button>
          <el-button type="primary" v-if="disabledForm === false" @click="sendComplieInfo()">保存</el-button>
          <el-button type="primary" id="editBtn" v-if="disabledForm === true" @click="switchToEdit" >编辑
          </el-button>
        </div>
      </div>
      <!-- 执行参数 -->
    </div>
  </div>
</template>

<script>
  let compileDetail = {
    sourceRepo: '',
    appId: null,
    taskId: null,
    uuid: null,
    taskName: "",
    sourceBranch: "",
    defaultTask: 0,
    setting: '',
    compileStepLst: [],
    appLanguage: 'JAVA',
  };
  let bulidStasusInfo = {
    imageRepo: '',//镜像名称
    stepId: null, //步骤id
    stepName: '构建', //步骤名称
    taskId: null, //任务ID
    typeId: null, //镜像类型ID
    shellInfo: '',//自定义脚本
    taskOrder: '',//步骤顺序
    stepConfig: {
      usePublicRepo: 0,
      subAppBos: [{ subAppId: '', sourceRepo: '' }]
    }
  };
  let cefhStatusInfo = {
    taskOrder: '',//步骤顺序
    imageRepo: '',//镜像名称
    stepId: null, //步骤id
    stepName: '上传版本包到仓库', //步骤名称
    taskId: null, //任务ID
    typeId: null, //镜像类型ID
    shellInfo: '',//自定义脚本
    stepConfig: null
  };
  let harborStatusInfo = {
    taskOrder: '',//步骤顺序
    imageRepo: '',//镜像名称
    stepId: null, //步骤id
    stepName: '', //步骤名称
    taskId: null, //任务ID
    typeId: null, //镜像类型ID
    shellInfo: '',//自定义脚本
    stepConfig: {
      cpu: '4', //cpu核数
      memory: '4096',//内存
      storage: '50',//磁盘存储
    }
  }
  let bulidtaskStaus = {
    isAddTask: '',//判断添加是否纯在
    isActive: '',//判断已存在的任务是否选中
    isStatus: "add",//判断是编辑还是添加状态
    typePurpose: '',//判断构建用途,
    isInit: 'show',//判断是创建还是展示,
    addSort: 'null',//判断之前还是之后添加
    location: 0,//记录之前活着之后添加的位置
  }
  import memberSettings from '@/components/tool/Staffing/Staffing'
  import draggable from 'vuedraggable';
  export default {
    name: "AppTaskBulid",
    data() {
      let validTargetDir = (rule, value, callback) => {
        let targetPattern = this.bulidStasusInfo.stepConfig.targetPattern;
        if (!this.targetPatternVerify(value, targetPattern)) {
          callback(new Error("目标文件路径中文件与目标文件压缩格式不符合！"));
        } else {
          callback();
        }
      };
      let validShell = (rule, value, callback) => {
        let invalidateChar = ["`", "$", "|", ";", "&&", ">", "<"];
        if (value) {
          for (let oneChar of invalidateChar) {
            if (value.indexOf(oneChar) !== -1) {
              callback(new Error("参数不能包含特殊字符" + oneChar));
              return;
            }
          }
        }
        callback();
      };
      let validRepo = (rule, value, callback) => {
        let checkGitSshUrl = /^(git@|ssh:\/\/\w+@)\w+/;

        let checkGitHttpUrl = /^[A-Za-z]+:\/\/+/;

        if (!checkGitSshUrl.test(value) && !checkGitHttpUrl.test(value)) {
          callback(new Error("源码仓库格式错误！请检查git地址格式! 形如git@xxx或者ssh://xxx@xxx或者http://xxx"));
        } else {
          callback();
        }
      };

      let validBaseDir = (rule, value, callback) => {
        if (value.substr(0, 1) != "/") {
          callback(new Error("APP根目录必须是绝对路径"));
        } else {
          callback();
        }
      };
      let validUserName = (rule, value, callback) => {
        value = value.trim().toLowerCase();
        if (value === 'root') {
          callback(new Error("运行用户名不能为root"));
        } else {
          callback();
        }
      };
      let validVersionNameTemplateData = (rule, value, callback) => {
        let spaceList = value.split(" ");
        if (spaceList.length > 1) {
          callback(new Error("请去除空格！"))
        }

        let pattern = /\w*(\${[a-zA-Z]+})*\w*/;
        if (!pattern.test(value)) {
          callback(new Error("输入格式错误！"))
        }

        let tempList = value.split("${");
        let afterTrim = tempList.splice(1, tempList.length - 1);
        let realList = [];
        afterTrim.forEach(item => {
          realList.push(item.substring(0, item.indexOf("}")));
        });
        realList.forEach(item => {
          if (GLOBAL_CONST.DEFAULT_VERSION_NAME_TEMPLATE_DATA_LIST.indexOf(item) == -1) {
            callback(new Error("占位符变量填写错误，建议拷贝填入"));
          }
        })
        callback();
      };
      let validPublishableBranches = (rule, value, callback) => {
        if (!value) {
          callback();
        } else {
          let spaceList = value.split(" ");
          if (spaceList.length > 1) {
            callback(new Error("请去除空格！"))
          } else {
            callback();
          }
        }
      }
      let validateVariableName = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入参数名称'));
        } else {
          let variableNameRegExp = /^[A-Z_]+[A-Z_0-9]*$/;
          // console.log(variableNameRegExp.test(value));
          if (!variableNameRegExp.test(value)) {
            callback(new Error('只接受大写英文字母，下划线，阿拉伯数字（即正常编码常量命名规范）'));
          } else {
            callback();
          }
        }
      };

      let validateDefaultOption = (rule, value, callback) => {
        //要想办法判断value.defaultOption是否是可选项value.options里面的一个值
        let options = value.options;
        if (!options || !options.trim()) {
          callback();
        }

        let defaultOption = value.defaultOption;
        if (!defaultOption || !defaultOption.trim()) {
          callback();
        }

        options = options.trim();
        defaultOption = defaultOption.trim();

        let optionArr = options.split('\n');
        if (optionArr.indexOf(defaultOption) == -1) {
          callback(new Error("如果填写默认值，则必须为\"可选项\"中的某项"))
        }

        callback();

      };

      return {
        buildTaskVaiableList: [],
        tableListNew: {
          appType: 0,
          data: [],//多仓库表格数据
        },
        taskId: '',
        totalSet: [],
        dialogVisible_master1: false,
        dialogVisible_master2: false,
        modaltobody: false,
        shadeBtn: false,
        branchPageData: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pages: 0
        },
        packInfo: {},
        compileTaskBuildVar: {
          buildVarsList: [],
        },
        buildVarsRules: {
          variable: [{ required: true, message: '不能为空', trigger: 'blur' },
          { validator: validateVariableName, trigger: 'blur' }],
          options: [{ required: true, message: '不能为空', trigger: 'blur' }],
          defaultOption: [{ validator: validateDefaultOption, trigger: 'blur' }],
        },
        // /分界线/
        bulidtaskStaus: {
          isAddTask: '',//判断添加是否纯在
          isActive: '',//判断已存在的任务是否选中
          isStatus: "add",//判断是编辑还是添加状态
          typePurpose: '',//判断构建用途,
          isInit: 'show',//判断是创建还是展示,
          addSort: 'null',//判断之前还是之后添加
          location: 0,//记录之前活着之后添加的位置
        },
        rules1: {
          publishableBranches: [{ validator: validPublishableBranches, trigger: 'blur' }],
          versionNameTemplateData: [{ required: true, message: '版本名称规则不能为空', trigger: 'blur' }, { validator: validVersionNameTemplateData, trigger: 'blur' }],
          sourceRepo: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validRepo, trigger: 'blur' }],
          baseDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validBaseDir, trigger: 'blur' }],
          targetDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validTargetDir, trigger: 'blur' }],
          userName: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validUserName, trigger: 'blur' }],
          shell: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validShell, trigger: 'blur' }],
          publish: [{ required: true, message: '不能为空', trigger: 'blur' }]
        },
        compileInfo: {},//获取编译方式
        javaAppBuildTool: 1, //
        APP_TYPE: GLOBAL_CONST.APP_TYPE, //引入全局变量编译方式类型
        COMPILE_IMAGE_TYPE: GLOBAL_CONST.COMPILE_IMAGE_TYPE,
        sourceRepo: '',
        bulidStasusInfo: {
          imageRepo: '',//镜像名称
          stepId: null, //步骤id
          stepName: '', //步骤名称
          taskId: null, //任务ID
          typeId: null, //镜像类型ID
          shellInfo: '',//自定义脚本
          taskOrder: '',//步骤顺序
          stepConfig: {
            usePublicRepo: 0,
            subAppBos: [{ subAppId: '', sourceRepo: '' }]
          }
        },
        cefhStatusInfo: {
          sourceRepo: '',
          taskOrder: '',//步骤顺序
          imageRepo: '',//镜像名称
          stepId: null, //步骤id
          stepName: '上传版本包到仓库', //步骤名称
          taskId: null, //任务ID
          typeId: null, //镜像类型ID
          shellInfo: '',//自定义脚本
          stepConfig: null
        },
        harborStatusInfo: {
          taskOrder: '',//步骤顺序
          imageRepo: '',//镜像名称
          stepId: null, //步骤id
          stepName: '', //步骤名称
          taskId: null, //任务ID
          typeId: null, //镜像类型ID
          shellInfo: '',//自定义脚本
          stepConfig: {
            cpu: '4', //cpu核数
            memory: '4096',//内存
            storage: '50',//磁盘存储
          }
        },
        createdBulidTask: [],

        imageList: [],//镜像列表
        imageRepolist: [],//镜像信息
        compilingList: [],
        table_loading: false,
        appearExecuteBtn: false,
        appearReExecuteBtn: false,
        pipelineListData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        bizId: '',
        appId: '',
        compileDetail: {
          appId: null,
          taskId: null,
          uuid: null,
          taskName: "",
          sourceBranch: "",
          defaultTask: 0,
          appLanguage: 'JAVA',
          setting: '',
          compileStepLst: [],

        },
        branchLst: [],//分支列表
        COMPILE_TASK_STATUS: GLOBAL_CONST.COMPILE_TASK_STATUS,
        disabledForm: true,
        btnEye: "2",
        operation: '',
      }
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this.appId = this.getUrlAppId();
      this.getBranchInfo();
      this.taskId = this.getUrlParams().taskId;
      this.operation = this.getUrlParams().operation;
      this.initCompileTask(this.taskId);
    },

    beforeRouteLeave(to, from, next) {
      //跳转页面前，如果编译任务编辑未保存，则提示是否强制跳转
      if (this.btnEye == "1") {
        this.$confirm("当前页面未保存，确定不保存直接离开？", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          next();
        }).catch(() => {
        });
      } else {
        next();
      }
    },

    methods: {

      //切换到编译任务编辑模式
      switchToEdit() {
        this.disabledForm = false;
        this.btnEye = "1";
      },

      addSubAppBos() {
        if (!this.bulidStasusInfo.stepConfig.subAppBos) {
          this.bulidStasusInfo.stepConfig.subAppBos = [];
        }
        this.bulidStasusInfo.stepConfig.subAppBos.push({});
        this.bulidStasusInfo.stepConfig.subAppBos.sort()
      },

      delSubAppBo(index) {
        if (this.bulidStasusInfo.stepConfig.subAppBos) {
          this.bulidStasusInfo.stepConfig.subAppBos.splice(index, 1);
        }
      },
      async endHandle(...res) {
        this.bulidtaskStaus.isActive = await res[0].newDraggableIndex;
      },
      //前加
      beforeAdd(index) {
        // alert(index)
        this.bulidtaskStaus.addSort = 'before';
        this.bulidtaskStaus.location = index;
        this.bulidtaskStaus.isStatus = 'add';

      },
      //后加
      afterAdd(index) {
        this.bulidtaskStaus.addSort = 'after'
        this.bulidtaskStaus.location = index + 1;
        this.bulidtaskStaus.isStatus = 'add';
      },
      nullAdd() {
        this.bulidtaskStaus.addSort = 'null'
        this.bulidtaskStaus.location = 0;
        this.bulidtaskStaus.isStatus = 'add';

      },

      getBuildTaskVarsJson() {
        let varsSelectedObj = {};
        this.buildTaskVaiableList.forEach(item => {
          varsSelectedObj[item.variable] = item.defaultOption;
        });
        return varsSelectedObj;
      },
      getBranchList() {
        this.table_loading = true;
        let params = { appId: this.appId };
        $http.get($http.api.appdate.appBranchList, params).then((res) => {
          if (res.status == 200) {
            this.appType = res.data.appType;
            if (res.data.appType != 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                if (a.name == 'master' && b.name != 'master') {
                  return -1;
                } else if (a.name != 'master' && b.name == 'master') {
                  return 1;
                } else if (!a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return -1;
                } else if (a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return 1;
                } else if (!a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                } else if (a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                }
              })
              this.tableList = res.data;

              //data替换为分支名称排序后的
              this.tableList.data = data;
              this.appBranchInfo = this.tableList.data.concat([]);
              this.handleBranchSizeChange(this.branchPageData.pageSize);
              this.gitAddress = res.data.sourceRepo;
            } else if (res.data.appType == 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                return a.subAppId.localeCompare(b.subAppId);
              })
              res.data.data.forEach((subApp, index_i) => {
                if (subApp.branchBos.length > 0) {
                  subApp.branchBos.forEach((oneBranch, index) => {
                    if (oneBranch.sourceBranch == 'master') {
                      subApp.branchBosidCommitId = oneBranch.commitId;
                      subApp.branchBosid = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                    }
                    oneBranch.commitIdWithIndex = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                  })
                }
              })
              this.tableList = res.data;
              this.tableList.data = data;
              this.handleBranchSizeChange(this.branchPageData.pageSize);
            }
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
          this.table_loading = false;
        }).catch(_ => {
          this.table_loading = false;
        });
      },

      handleBranchSizeChange(val) {
        this.branchPageData.pageSize = val;
        this.fakePage(this.branchPageData.pageNum, val, this.search, this.appType);
      },

      handleBranchCurrentChange(val) {
        this.branchPageData.pageNum = val;
        this.fakePage(val, this.branchPageData.pageSize, this.search, this.appType);
      },

      fakePage(num, size, keyWord, appType) {
        let allList = this.tableList.data;
        let tempList = [];
        let returnList = [];
        if (appType != 5) {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.name.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        } else {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.subAppId.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            this.tempList = tempList;
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        }
        this.$nextTick(() => {
          let tableListNew = this.tableListNew;
          tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale && branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },

      targetPatternVerify(targetDir, targetPattern) {
        let endFormat = [".zip", ".jar", ".tar", ".tar.gz", ".war"];
        let count = 0;
        for (let i = 0; i < endFormat.length; i++) {
          if (targetDir.endsWith(endFormat[i])) {
            count++;
            break;
          }
        }
        if (count === 0) {
          return true;
        }
        if (targetDir.endsWith(targetPattern)) {
          return true;
        }
        if (targetPattern == "tar" && targetDir.endsWith(targetPattern + ".gz")) {
          return true;
        }
        return false;
      },

      //发送编译信息给后台
      sendComplieInfoFc() {
        this.compileDetail.appId = this.appId;
        $http.post($http.api.compile.task_save, this.compileDetail).then(res => {
          if (res.status === 200) {
            this.btnEye = '2';
            this.taskId = res.data;
            this.refreshPage(this.taskId);
          } else {
            this.compileTaskBuildVar.buildVarsList = JSON.parse(this.compileDetail.setting).vars;
            this.bulidStasusInfo.stepConfig = JSON.parse(this.bulidStasusInfo.stepConfig);
            this.harborStatusInfo.stringify = JSON.parse(this.harborStatusInfo.stringify);
          }
        })
      },

      //编译任务创建，保存成功的时候重新刷新页面使用
      refreshPage(taskId) {
        this.operation = 'view';
        this.$router.replace({name: 'AppCompileTaskDetail', query : { bizId: this.bizId, appId: this.appId, taskId: taskId, operation: 'view'}});
        //主动触发重新加载页面元素和数据
        this.$nextTick(this.initCompileTask(taskId));
      },

      //获取镜像名称列表
      getImageRepoList(item) {
        let params = {
          bizId: this.bizId,
          typeId: item.typeId
        }
        $http.get($http.api.compile.compileTypeImages, params).then(res => {
          this.imageRepolist = res.data;
          this.sourceRepo = res.data.sourceRepo;
        })
      },
      //发送编译任务信息
      sendComplieInfo() {
        var validateFlag = false;
        this.$refs['compileTaskBuildVarForm'].validate(validate => {
          validateFlag = validate;

        });
        if (!validateFlag) {

          return;
        }
        this.$refs['compileForm'].validate(validate => {
          validateFlag = validate;

        });
        if (!validateFlag) {

          return;
        }

        if (this.createdBulidTask.length === 0) {
          this.$message({ type: "warning", message: '请选择镜像' })
          return
        }
        if (!this.compileDetail.taskName) {
          this.$message({ type: "warning", message: '请填写编译任务名称' })
          return
        }
        if (this.compileInfo.appType !== 5) {
          if (!this.compileDetail.sourceBranch) {
            this.$message({ type: "warning", message: '请填写默认分支' })
            return
          }
        }
        if (this.compileTaskBuildVar.buildVarsList) {
          for (let i = 0; i < this.compileTaskBuildVar.buildVarsList.length; i++) {
            if (this.compileTaskBuildVar.buildVarsList[i].variable) {
              if (!this.compileTaskBuildVar.buildVarsList[i].options) {
                this.$message({ type: "warning", message: '请填写可选值' })
                return
              }
            }
            if (this.compileTaskBuildVar.buildVarsList[i].options) {
              if (!this.compileTaskBuildVar.buildVarsList[i].variable) {
                this.$message({ type: "warning", message: '请填写参数名' })
                return
              }
            }
          }
        }
        this.compileDetail.setting = this.compileTaskBuildVar.buildVarsList && this.compileTaskBuildVar.buildVarsList.length > 0 ? JSON.stringify({ vars: this.compileTaskBuildVar.buildVarsList }) : null;
        for (let i = 0; i < this.createdBulidTask.length; i++) {
          if (this.createdBulidTask[i].typePurpose === 0) {
            if (!this.bulidStasusInfo.stepName) {
              this.$message({ type: "warning", message: '请填写步骤名称' })
              return
            }
            if (!this.bulidStasusInfo.imageRepo) {
              this.$message({ type: "warning", message: '请填写镜像名称' })
              return
            }
            if (!this.bulidStasusInfo.stepConfig.targetPattern) {
              this.$message({ type: "warning", message: '请填写目标文件压缩格式' })
              return
            }
            if (this.compileInfo.appType === 1 || this.compileInfo.appType === 2) {
              if (!this.bulidStasusInfo.stepConfig.mvnCmd) {
                this.$message({ type: "warning", message: '请填写mvn命令' })
                return
              }
              if (!this.bulidStasusInfo.stepConfig.pomFile) {
                this.$message({ type: "warning", message: '请填写pom文件' })
                return
              }
            }
            if (this.isJavaApp(this.compileInfo.appType)) {
              if (!this.bulidStasusInfo.stepConfig.targetDir) {
                this.$message({ type: "warning", message: '请填写目标文件路径' })
                return
              }
            }
            if (this.compileInfo.appType === this.APP_TYPE.TAR) {
              if (!this.bulidStasusInfo.stepConfig.tarDir) {
                this.$message({ type: "warning", message: '请填写打包目录' })
                return
              }
              if (!this.bulidStasusInfo.stepConfig.targetFileName) {
                this.$message({ type: "warning", message: '请填生成文件' })
                return
              }
            }
            if (this.isShellScriptApp(this.compileInfo.appType)) {
              if (!this.bulidStasusInfo.shellInfo) {
                this.$message({ type: "warning", message: '请填写自定义脚本' })
                return
              }
            }
            if (this.isGradleJavaApp(this.compileInfo.appType)) {
              if (!this.bulidStasusInfo.stepConfig.gradleCmd) {
                this.$message({ type: "warning", message: '请填写gradle命令' })
                return
              }
            }
            this.bulidStasusInfo.stepConfig = JSON.stringify(this.bulidStasusInfo.stepConfig)
            this.compileDetail.compileStepLst = []
            this.compileDetail.compileStepLst.push(this.bulidStasusInfo)
          } else if (this.createdBulidTask[i].typePurpose === 1) {
            this.compileDetail.compileStepLst.push(this.cefhStatusInfo)
          } else if (this.createdBulidTask[i].typePurpose === 2) {
            if (!this.harborStatusInfo.stepName) {
              this.$message({ type: "warning", message: '请填写步骤名称' })
              return
            }
            if (!this.harborStatusInfo.imageRepo) {
              this.$message({ type: "warning", message: '请填写镜像名称' })
              return
            }
            this.harborStatusInfo.stepConfig = JSON.stringify(this.harborStatusInfo.stepConfig)
            this.compileDetail.compileStepLst.push(this.harborStatusInfo)
          }
        }
        for (let i = 0; i < this.compileDetail.compileStepLst.length; i++) {
          this.compileDetail.compileStepLst[i].taskOrder = i + 1;
        }
        // return
        this.sendComplieInfoFc()
      },
      //获取分支信息
      getBranchInfo() {
        $http
          .get($http.api.pipeline.appBranchCompleteInfo, {
            appId: this.appId
          })
          .then(res => {
            this.branchLst = res.data.branchLst;
          });
      },
      //获取编译任务列表
      getCompilingList() {
        $http.get($http.api.compile.compiling_list, { appId: this.appId }).then(res => {
          this.compilingList = res.data;
          this.taskId = res.data.list[0].taskId
        })
      },

      //获取编译任务详情
      getCompilingDetail(taskId) {
        $http.get($http.api.compile.compiling_detail, { taskId }).then(res => {
          this.$nextTick(() => {
            this.createdBulidTask.length = 0;
            this.compileDetail = res.data;
            this.bulidtaskStaus.isActive = 0;
            this.compileTaskBuildVar.buildVarsList = this.compileDetail.setting ? JSON.parse(this.compileDetail.setting).vars : this.compileDetail.setting;
            for (let i = 0; i < this.compileDetail.compileStepLst.length; i++) {
              for (let j = 0; j < this.imageList.length; j++) {
                if (this.compileDetail.compileStepLst[i].typeId === this.imageList[j].typeId) {

                  this.createdBulidTask.push(this.imageList[j])
                  if (this.imageList[j].typePurpose === 0) {
                    this.bulidStasusInfo = this.compileDetail.compileStepLst[i];
                    this.bulidStasusInfo.stepConfig = JSON.parse(this.bulidStasusInfo.stepConfig)
                  } else if (this.imageList[j].typePurpose === 1) {
                    this.cefhStatusInfo = this.compileDetail.compileStepLst[i];
                  } else if (this.imageList[j].typePurpose === 2) {
                    this.harborStatusInfo = this.compileDetail.compileStepLst[i];

                    this.harborStatusInfo.stepConfig = JSON.parse(this.harborStatusInfo.stepConfig)
                  }
                }
              }
            }
            this.bulidtaskStaus.typePurpose = this.createdBulidTask[0].typePurpose;
            this.compileInfo.appType = this.createdBulidTask[0].compileType;
            if(this.operation === 'create'){
              this.compileDetail.defaultTask = 0;
              this.compileDetail.taskId = '';
              this.compileDetail.taskName = this.compileDetail.taskName + '_copy';
            }
            this.bulidtaskStaus.isStatus = 'editor';
            this.getImageRepoList(this.createdBulidTask[0])
          })
        })

      },
      //取消 返回编译任务列表
      goToCompileList() {
        this.btnEye = '2';
        this.disabledForm = true;
        if(this.operation === 'create'){
          this.goToPage(this, 'AppCompileTaskList', { bizId: this.bizId, appId: this.appId, })
        }else{
          this.refreshPage(this.taskId);
        }
      },
      addBuildVar() {
        if (this.compileTaskBuildVar.buildVarsList == null) {
          this.compileTaskBuildVar.buildVarsList = [];
        }
        this.compileTaskBuildVar.buildVarsList.push({
          variable: "",
          options: "",
          desc: "",
          defaultOption: "",
        })
      },
      deleteBuildEnvItem(item) {
        let index = this.compileTaskBuildVar.buildVarsList.indexOf(item);
        if (index !== -1) {
          this.$confirm(`确认删除参数${item.variable}设置？`, '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            this.compileTaskBuildVar.buildVarsList.splice(index, 1);
          }).catch(() => {

          });
        }

      },
      //添加镜像
      addImage(item, index) {
        this.bulidtaskStaus.isStatus = 'editor';
      },
      //删除镜像
      deleteImage(item, index) {
        if (item.compileType === 5 && this.compileDetail.defaultTask === 1) {
          this.$message({ type: "warning", message: "默认多仓库任务不能删除" });
          return
        }
        if (this.createdBulidTask.length > 1) {
          if (index > 0) {
            this.bulidtaskStaus.isActive = index - 1;
            this.bulidtaskStaus.typePurpose = this.createdBulidTask[index - 1].typePurpose;
            this.compileInfo.appType = this.createdBulidTask[index - 1].compileType;
            this.getImageRepoList(this.createdBulidTask[index - 1]);
          } else {
            this.bulidtaskStaus.isActive = index;
            this.bulidtaskStaus.typePurpose = this.createdBulidTask[index + 1].typePurpose;
            this.compileInfo.appType = this.createdBulidTask[index + 1].compileType;
            this.getImageRepoList(this.createdBulidTask[index + 1])
          }
        }
        this.createdBulidTask.splice(index, 1);
        if (this.createdBulidTask.length === 0) {
          this.bulidtaskStaus.isStatus = 'add'
        }

        if (item.typePurpose === 0) {
          this.bulidStasusInfo = bulidStasusInfo;
          this.$set(this.bulidStasusInfo, 'imageRepo', '')
        } else if (item.typePurpose === 1) {
          this.cefhStatusInfo = cefhStatusInfo;
        } else if (item.typePurpose === 2) {
          this.harborStatusInfo = harborStatusInfo;
          this.$set(this.harborStatusInfo, 'imageRepo', '')
        }
      },

      isJavaApp(appType) {
        return appType == this.APP_TYPE.JAVA_MAVEN
          || appType == this.APP_TYPE.JAVA_WEB_MAVEN
          || appType == this.APP_TYPE.JAVA_GRADLE
          || appType == this.APP_TYPE.JAVA_WEB_GRADLE
          || appType == this.APP_TYPE.ANDROID_APK;
      },

      isNotWebJavaApp(appType) {
        return appType !== this.APP_TYPE.TAR

      },
      isAndroidAPKApp(appType) {
        return appType == this.APP_TYPE.ANDROID_APK;
      },

      isJavaWebApp(appType) {
        return appType == this.APP_TYPE.JAVA_WEB_MAVEN
          || appType == this.APP_TYPE.JAVA_WEB_GRADLE;
      },
      isMavenJavaApp(appType) {
        return (appType == this.APP_TYPE.JAVA_MAVEN || appType == this.APP_TYPE.JAVA_WEB_MAVEN)
      },

      isGradleJavaApp(appType) {
        return appType == this.APP_TYPE.JAVA_GRADLE || appType == this.APP_TYPE.JAVA_WEB_GRADLE || appType == this.APP_TYPE.ANDROID_APK;
      },

      isNotJavaApp(appType) {
        return !this.isJavaApp(appType);
      },

      isShellScriptApp(appType) {
        return appType == this.APP_TYPE.SHELL || appType == this.APP_TYPE.MULTI_REPO_SHELL;
      },

      //获取所有的镜像列表
      getImageList(taskId) {
        $http.get($http.api.compile.compileTypes).then(res => {
          this.imageList = res.data;
          if (taskId) {
            this.getCompilingDetail(taskId)
          }
          for (let i = 0; i < this.imageList.length; i++) {
            switch (this.imageList[i].typeId) {
              case 0:
                this.imageList[i].icon = 'iconfont icon-siyoujingxiang';
                break;
              case 1:
                this.imageList[i].icon = 'iconfont icon-maven-logo-black-on-';
                break;
              case 2:
                this.imageList[i].icon = 'iconfont icon-npm';
                break;
              case 3:
                this.imageList[i].icon = 'iconfont icon-cmake';
                break;
              case 4:
                this.imageList[i].icon = 'iconfont icon-centos';
                break;
              case 13:
                this.imageList[i].icon = 'iconfont icon-dabao1';
                break;
              case 14:
                this.imageList[i].icon = 'iconfont icon-dabao';
                break;
              case 15:
                this.imageList[i].icon = 'iconfont icon-gradle';
                break;
              case 16:
                this.imageList[i].icon = 'iconfont icon-cpp';
                break;
              case 17:
                this.imageList[i].icon = 'iconfont icon-Android';
                break;
              default:
                this.imageList[i].icon = 'iconfont icon-moren2';
                break;
            }
          }
        })
      },
      //选择已有任务选中
      isActive(index, item) {
        this.bulidtaskStaus.isActive = index;
        // console.log(this.bulidtaskStaus.isActive)
        this.bulidtaskStaus.typePurpose = item.typePurpose
        this.bulidtaskStaus.isStatus = 'editor';
        this.compileInfo.appType = item.compileType;
        this.getImageRepoList(item)
      },
      //添加构建任务
      addBulidTask(item) {
        if (this.createdBulidTask.length > 0) {
          for (let i = 0; i < this.createdBulidTask.length; i++) {
            if (this.createdBulidTask[i].typePurpose === item.typePurpose) {
              this.$message({ type: "warning", message: "同一种用途的镜像只能添加一种" })
              return
            }
          }
        }
        if (item.typePurpose === 0) {
          this.bulidStasusInfo.typeId = item.typeId;
        } else if (item.typePurpose === 1) {
          this.cefhStatusInfo.typeId = item.typeId;
        } else if (item.typePurpose === 2) {
          this.harborStatusInfo.typeId = item.typeId;
        }
        this.bulidtaskStaus.isStatus = 'editor';
        this.bulidtaskStaus.typePurpose = item.typePurpose;
        if (this.bulidtaskStaus.addSort === 'before') {
          this.createdBulidTask.splice(this.bulidtaskStaus.location, 0, item)
        } else if (this.bulidtaskStaus.addSort === 'after') {
          this.createdBulidTask.splice(this.bulidtaskStaus.location, 0, item)
        } else if (this.bulidtaskStaus.addSort === 'null') {
          this.createdBulidTask.push(item)
        }
        this.bulidtaskStaus.isActive = this.bulidtaskStaus.location
        this.compileInfo.appType = item.compileType;
        this.getImageRepoList(item);
      },
      //移入事件
      enter(index) {
        this.bulidtaskStaus.isAddTask = index;
      },
      //移出事件
      leave() {
        this.bulidtaskStaus.isAddTask = '';
      },
      getCreateUser(row) {
        if (row && (row.createUserId || row.createUserName)) {
          return row.createUserName + '(' + row.createUserId + ')';
        }
        return "";
      },

      getTriggerMode(row) {
        if (row && row.triggerMode) {
          return GLOBAL_CONST.PIPELINE_TRIGGER_TYPE_MAP[row.triggerMode];
        }
        return "";
      },
      //编辑列表,在查看的基础上多了一步自动触发跳进去后的页面的“编辑”按钮
      initCompileTask(taskId) {
        this.getImageList(taskId);
        if(this.operation && (this.operation === 'edit' || this.operation === 'create')){
          this.switchToEdit();
        }
        if(this.operation && this.operation === 'view'){
          this.btnEye = "2";
          this.disabledForm = true;
        }
      },
    },

    components: {
      memberSettings,
      draggable
    }
  };
</script>
<style lang="scss" scoped>
  /* 局部重写镜像图标 */
  .icon-maven-logo-black-on- {
    font-size: 20px !important;
    color: black;
    top: 25px !important;
    left: -2px !important;
  }

  .icon-npm {
    color: red;
  }

  .icon-dabao,
  .icon-dabao1,
  .icon-moren2 {
    color: black;
  }

  .icon-Android {
    color: green;
  }

  .icon-cmake,
  .icon-centos {
    color: #5170FF;
  }

  .icon-gradle,
  .icon-cpp {
    color: #1296db;
  }

  .icon-positon {
    position: absolute;
    top: 4px;
    right: 20px;
    color: #000;
    font-weight: 700px;
    font-size: 16px;
  }

  .icon-circle {
    width: 14px;
    height: 14px;
    border-radius: 50%;
    border: 1px solid #ccc;
  }

  .blue-icon {
    color: #5170FF;
  }

  .new-bulid-task {
    /* width: 1200px; */
    margin: 0 auto;
    background-color: #FFF;
    padding: 10px 20px 0;
    /* min-height: calc(100vh - 150px); */
    box-shadow: 0 10px 20px -10px #112037;
    height: auto;
    overflow: hidden;
    /* height: calc(100% - 50px); */
  }

  .new-image-list {
    /* width: 1200px; */
    margin: 0 auto;
    background-color: #FFF;
    padding: 20px;
    /* min-height: calc(100vh - 50px); */
    box-shadow: 0 10px 20px -10px #112037;
    /* height: calc(100% - 50px); */
    height: auto;
    overflow: hidden;

    .bulid-task {
      overflow: hidden;

      .bulid-task-box-left {
        float: left;
        padding-bottom: 20px;

        .bulid-task-item {
          border: 1px solid transparent;
          background-color: #F8F8F8;
          width: 480px;
          height: 80px;
          cursor: pointer;
          margin-top: 20px;
          padding-left: 10px;
          position: relative;

          .icon-box {
            width: 60px;
            height: 100%;
            position: absolute;
            top: 5px;
            left: 5px;
            font-size: 46px;
          }

          .des-name-box {
            display: inline-block;
            margin-left: 80px;
            width: calc(100% - 80px);

            .bulid-task-name {
              /* width: calc(100% - 80px); */
              font-weight: 700;
              color: #333;
              font-size: 14px;
              position: relative;

            }

            .bulid-tasl-des {

              font-size: 12px;
              color: #5E6678;
              position: relative;
            }
          }

          .add-top-icon {
            /* display: none; */
            position: absolute;
            width: 20px;
            height: 20px;
            background: #4C5C85;
            border-radius: 50%;
            left: 59px;
            color: #FFFFFF;
            /* color: var(--font-white, #FFFFFF); */
            text-align: center;
            line-height: 20px;
            font-size: 18px;
            cursor: pointer;
            top: -12px;
          }


          .add-down-icon {
            position: absolute;
            width: 20px;
            height: 20px;
            background: #4C5C85;
            border-radius: 50%;
            left: 59px;
            color: #FFFFFF;
            /* color: var(--font-white, #FFFFFF); */
            text-align: center;
            line-height: 20px;
            font-size: 18px;
            cursor: pointer;
            top: 70px;
          }
        }

        .active {
          background: #FFFFFF;
          box-shadow: 0 0 2px 0 #5170FF;
          border: 1px solid #5170FF;
        }

        .bulid-task-null {
          display: inline-block;
          width: 480px;
          height: 80px;
          border: 1px dotted #CACFD8;
          cursor: pointer;
          text-align: center;
          line-height: 80px;
        }
      }

      .bulid-task-box-right {
        float: left;
        width: 858px;
        padding-left: 40px;

        .add-step-title {
          font-size: 16px;
          font-weight: 700;
          color: #333;
        }

        .all-task {
          color: #5170ff;
          display: inline-block;
          border-bottom: 2px solid #5170ff;
          font-weight: 700;
          margin-top: 20px;
        }

        .el-icon-close {
          margin-left: 440px;
          cursor: pointer;
        }

        .item-box {
          margin-top: 20px;

          .bulid-task-item {
            width: 541px;
            height: 80px;
            border: 1px solid transparent;
            border-bottom: 1px solid #CACFD8;
            position: relative;

            .icon-box {
              width: 60px;
              height: 100%;
              position: absolute;
              top: 5px;
              left: 5px;
              font-size: 46px;
            }

            .bulid-task-name {
              font-weight: 700;
              color: #333;
              font-size: 14px;
              /* padding-top: 13px; */
            }

            .bulid-tasl-des {
              font-size: 12px;
              color: #5E6678;
            }

            &:hover {
              box-shadow: 0 0 2px 0 #5170FF;
              border: 1px solid #5170FF;
              position: relative;
            }
          }

          .add-bulid-task {
            position: absolute;
            top: 26px;
            right: 20px;
          }
        }
      }

    }
  }
</style>
