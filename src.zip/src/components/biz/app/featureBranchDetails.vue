<template>
  <div id="featureBranchDetails" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
            <div>
              <el-row>
                <div class="basic-info-area">
                  <div class="basic-info-item">
                    <span class="basic-info-label">特性分支:</span>
                    <el-tooltip  v-if="featureBranchDetails.gitBranchDeleted" class="item" effect="dark" content="Git分支已被删除" placement="top-start">
                      <span class="c-red">{{featureBranchDetails.featureBranch}}</span>
                    </el-tooltip>
                    <a v-else class="c-blue cp" :href="featureBranchDetails.gitBranchCommitsUrl" target="_blank">
                      {{featureBranchDetails.featureBranch}}
                    </a>
                  </div>

                  <div class="basic-info-item">
                    <span class="basic-info-label">最新CommitId：</span>
                      <el-tooltip class="item" effect="dark" placement="bottom">
                        <div slot="content">{{featureBranchDetails.latestCommitMsg}} </div>
                        <span class="c-blue cursor-default">
                          {{featureBranchDetails.latestCommitId ? featureBranchDetails.latestCommitId.substring(0,8) : "-"}}
                        </span>
                      </el-tooltip>
                  </div>

                  <div class="basic-info-item">
                    <span class="basic-info-label">变更原因:</span>
                    <div style="display: inline-block; min-width:150px">
                      <global-input
                        :initValue="featureBranchDetails.changeReason"
                        :title="featureBranchDetails.changeReason"
                        :onChange="(value)=>{handleChangeReasonChange(value)}">
                        <span
                          class="table-input-edit-text cp"
                          style="padding-bottom:2px; color: #606266;"
                          slot>{{featureBranchDetails.changeReason}}</span>
                      </global-input>
                    </div>
                  </div>

                  <div class="basic-info-item">
                    <span class="basic-info-label">计划发布时间：</span>
                    <el-date-picker
                      type="date"
                      v-model="planReleaseTime"
                      value-format="yyyy-MM-dd 00:00:00"
                      :picker-options="pickerOptions"
                      class="datepicker"
                      prefix-icon="not-exist-el-icon-date"
                      :editable="false"
                      :clearable="false"
                      placeholder="请选择计划发布时间"
                      @change="handleReleaseTimeChange"
                      >
                    </el-date-picker>
                  </div>

                  <div class="basic-info-item">
                    <el-checkbox v-model="featureBranchDetails.autoDelete" @change="handleAutoDeleteChange">
                      <span style="color:#ff8b00">合并主干后自动删除分支 &nbsp;
                        <i class="header-icon el-icon-question"
                          style="color: #606266"
                          title="集成环境生成的Release分支合并主干后，该分支将会自动删除">
                        </i>
                      </span>
                    </el-checkbox>
                  </div>

                </div>
              </el-row>

            </div>
            <div class="btnArea">
              <el-row type="flex">
                <el-button
                  type="primary"
                  class="mb10"
                  v-if="featureBranchDetails.status == FEATURE_BRANCH_STATUS.DEVELOPING"
                  @click="beginIntegration()"
                >提交集成</el-button>
                <el-tooltip
                  :disabled="featureBranchDetails.status == FEATURE_BRANCH_STATUS.DEVELOPING"
                  placement="bottom-start"
                >
                  <div slot="content">
                    变更处于集成中，请先
                    <br>退出集成再关闭变更
                  </div>
                  <el-button
                    type="default"
                    :class="(featureBranchDetails.status == FEATURE_BRANCH_STATUS.DEVELOPING ? 'mb10' : 'mb10 fake-disabled-btn')"
                    @click="showDeleteDialog"
                  >关闭变更</el-button>
                </el-tooltip>
              </el-row>
            </div>
            <el-tabs v-model="tabActive">
              <el-tab-pane label="运行详情" name="excuteDetail">
                <div class="btnArea">
                  <el-row type="flex">
                    <el-button type="success" class="mb10" @click="beginExecute()">运行</el-button>
                    <el-button plain type="primary" class="mb10" @click="goPipelineEditPage">编辑流水线</el-button>
                  </el-row>
                </div>

                <div class="pipelineStageArea">
                  <work-flow-stage ref="WorkFlowStage" @taskTransfer="this.updateWorkflowTaskInfo" @ALLTASKEND="renderVersionTable" @initLog="()=>{this.$refs.logBox.init()}"></work-flow-stage>
                </div>

                <div class="common-table-box" v-show="showLogBox">
                  <div class="common-table-title">日志详情</div>
                  <log-box
                    :workflowTaskId="workflowTaskId"
                    :currentSelectedWorkflow="currentSelectedWorkflow"
                    ref="logBox"
                  ></log-box>
                </div>
              </el-tab-pane>
              <el-tab-pane label="版本列表" name="versionList">
                <div class="table-box">
                  <div class="table-box-top">
                    <div class="btnArea">
                      <el-row type="flex" justify="end">
                        <el-button type="primary" class="mb10" @click="renderVersionTable()">刷新</el-button>
                        <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2, appId)"
                                   @click="passEnvClick('dev')" class="mb10">开发环境
                        </el-button>
                        <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2, appId)"
                                   @click="passEnvClick('test')" class="mb10">测试环境
                        </el-button>
                      </el-row>
                    </div>
                    <el-table :border="true" :data="versionTableData.list">
                      <el-table-column prop="versionName" label="版本名称" min-width="120"></el-table-column>

                      <el-table-column label="CommitId" min-width="40">
                        <template
                          slot-scope="scope"
                        >{{scope.row.commitId ? scope.row.commitId.substring(0,8) : '-'}}</template>
                      </el-table-column>

                      <el-table-column prop="versionDesc" label="提交日志" min-width="200"></el-table-column>

                      <el-table-column prop="createUserName" label="创建者" min-width="40"></el-table-column>
                      <el-table-column label="创建时间" min-width="60">
                        <template slot-scope="scope">
                          <span>{{ scope.row.createTime ? scope.row.createTime : '-------' }}</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="打包状态" min-width="40">
                        <template slot-scope="scope">
                          <span
                            :class="{'c-red':scope.row.pkgStatus == 3}"
                          >{{PKG_STATUS[scope.row.pkgStatus]}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="上传详情" min-width="40">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="checkUpload(scope.row.versionId, 0)">查看</span>
                          <span
                            class="c-blue cp"
                            v-if="scope.row.pkgStatus == 4"
                            @click="downloadVersion(scope.row)"
                          >下载</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="操作" min-width="60">
                        <template slot-scope="scope">
                          <span class="c-blue cp"
                            v-if="scope.row.pkgStatus == 4"
                            @click="handleManualDeployClick(scope.row)">
                            手工部署
                          </span>
                          &nbsp;&nbsp;&nbsp;
                          <span class="c-blue cp"
                            v-if="scope.row.pkgStatus == 4"
                            @click="handleAutoDeployClick(scope.row)">
                            自动部署
                          </span>
                        </template>
                      </el-table-column>
                    </el-table>

                    <div class="table_b_f_b">
                      <el-pagination
                        v-show="versionTableData.list.length!=0"
                        class="fr mr10"
                        style="margin-top: 9px;"
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page="versionTableData.pageNum"
                        :page-sizes="[10, 20, 30]"
                        :page-size="versionTableData.pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="versionTableData.total">
                      </el-pagination>
                    </div>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>

    <el-dialog
      title="提示"
      :visible.sync="deleteChangeDialogVisible"
      width="30%"
      :before-close="closeDeleteDialog"
      :close-on-click-modal="false"
      center
    >
      <el-row>
        <h4>确认删除当前变更？</h4>
        <el-form ref="deleteFormRef" :model="deleteForm">
          <el-form-item prop="alsoDeleteGit">
            <el-checkbox v-model="deleteForm.alsoDeleteGit">
              <h4>同步删除Git仓库分支</h4>
            </el-checkbox>
          </el-form-item>
        </el-form>
      </el-row>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDeleteDialog">取 消</el-button>
        <el-button type="primary" @click="deleteChange">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="提示"
      :visible.sync="deployEnvChooseDialogVisible"
      width="30%"
      :before-close="closeDeployEnvChooseDialog"
      :close-on-click-modal="false"
      center>
      <el-row>
        <el-row type="flex" justify="center">
          <h4>当前流水线存在两个可部署的环境，请选择需要手工部署的环境！</h4>
        </el-row>
        <el-row type="flex" justify="center">
          <el-form ref="deployEnvChooseFormRef" :model="deployEnvChooseForm">
            <el-form-item prop="manualDeployEnv">
              <el-radio-group v-model="deployEnvChooseForm.manualDeployEnv">
                <el-radio label="dev">开发环境</el-radio>
                <el-radio label="test">测试环境</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-form>
        </el-row>
      </el-row>

      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDeployEnvChooseDialog">取 消</el-button>
        <el-button type="primary" @click="handleDeployEnvChooseConfirm">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="提示"
      :visible.sync="deployPlanChooseDialogVisible"
      width="45%"
      :before-close="closeDeployPlanChooseDialog"
      :close-on-click-modal="false"
      center>
      <el-row>
        <el-row type="flex" >
          <h4>请选择流水线关联的自动化部署任务</h4>
        </el-row>
        <el-row type="flex" justify="center">
            <el-table
                ref="deployPlanTable"
                :data="deployPlanTableData"
                style="width: 100%"
                v-loading="deployPlanTableLoading"
                @selection-change="handleDeployPlanSelectionChange">
                <el-table-column
                  type="selection"
                  min-width="55">
                </el-table-column>
                <el-table-column
                  prop="deployPlanName"
                  label="部署名称"
                  min-width="150">
                </el-table-column>
                <el-table-column
                  prop="deployType"
                  label="部署类型"
                  min-width="100">
                </el-table-column>
                <el-table-column
                  prop="deployEnv"
                  label="部署环境"

                  min-width="120">
                </el-table-column>
                <el-table-column
                  prop="zoneCode"
                  label="部署机房"
                  min-width="120">
                </el-table-column>
                <el-table-column
                  prop="configEnv"
                  label="配置环境"
                  min-width="100">
                </el-table-column>
                <el-table-column
                  prop="configVersion"
                  label="配置版本"
                  min-width="100">
                </el-table-column>
              </el-table>
        </el-row>
      </el-row>

      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDeployPlanChooseDialog">取 消</el-button>
        <el-button type="primary" @click="handleDeployPlanChooseConfirm">确 定</el-button>
      </span>
    </el-dialog>

    <!-- 仓库包上传详情 -->
    <package-upload-info :dialogVisible="uploadDialogVisible" :dialogClose="handleCloseUpload" ref="PackageUploadInfo"></package-upload-info>
    <paas-deploy ref="paasDeploy"></paas-deploy>

    <el-dialog title='构建参数' :visible.sync="variablesDialogShow" class="el-dialog-400w"
    >
      <div class="form-iterm-box">
        <el-form  label-width="100px" @submit.native.prevent>
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
            <el-col :span='24'
                    v-if="variablesDialogShow && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:200px;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>

          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseVariablesDialog">取消</el-button>
        <el-button type="primary" @click="execute">确定</el-button>
      </span>
    </el-dialog>


    <el-dialog title='构建参数' :visible.sync="integrationVariableDialogShow" class="el-dialog-400w"
    >
      <div class="form-iterm-box">
        <el-form  label-width="100px">
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
            <el-col :span='24'
                    v-if="integrationVariableDialogShow && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:200px;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>

          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseIntegrationVariablesDialog">取消</el-button>
        <el-button type="primary" @click="submitIntegration">确定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>

import LogBox from '@/components/commonComponents/LogBox'
import WorkFlowStage from '@/components/commonComponents/WorkFlowStage'
import PackageUploadInfo from '@/components/commonComponents/PackageUploadInfo'
import paasDeploy from '@/components/biz/app/paasDeploy'
import featureBranchMixin from './featureBranchMixin.js'
import GlobalInput from "@/components/tool/FieldEdit/GlobalInput.vue"

export default {
  name: "featureBranchDetails",
  components: {
    LogBox,
    WorkFlowStage,
    PackageUploadInfo,
    paasDeploy,
    GlobalInput
  },
  mixins: [featureBranchMixin],
  data() {
    return {
      pickerOptions:{
        disabledDate(time) {
          return time.getTime() < Date.now() - 8.64e7;
        }
      },

      FEATURE_BRANCH_STATUS: GLOBAL_CONST.FEATURE_BRANCH_STATUS,
      PKG_STATUS: GLOBAL_CONST.PKG_STATUS,
      WORKFLOW_TASK_TYPE: GLOBAL_CONST.WORKFLOW_TASK_TYPE,
      tabDefaultActiveName: 'first',
      bizId: '',
      appId: '',
      appSimpleInfo: null,
      featureBranchId: '',
      featureBranchDetails: {
        changeReason:"",
      },
      planReleaseTime: '',
      //btn visible control
      deleteChangeDialogVisible: false,
      deployEnvChooseDialogVisible: false,
      deployPlanChooseDialogVisible: false,
      deployPlanTableData:[],
      deployPlanTableLoading: false,

      deleteForm: { alsoDeleteGit: false },

      //手工部署下发参数
      deployEnvChooseForm: {
        appVersionId: -1,
        manualDeployEnv: "dev",
      },

      deployPlanMultipleSelection: [],
      //自动部署下发参数
      autoDeployVersionId: -1,

      versionTableData: {
        pageNum: 1,
        pageSize: 10,
        total: 0,
        list: []
      },
      tabActive: 'excuteDetail',
      uploadDialogVisible: false,
      buildTaskVaiableList:[],
      //控制构造参数选择框显示，流水线运行
      variablesDialogShow: false,
      //控制构造参数选择框显示，集成提交集成时显示，两个参数框分开方便后续独立扩展
      integrationVariableDialogShow: false
    }
  },
  computed: {},

  mounted() {
    this.bizId = this.getUrlBizId();
    this.appId = this.getUrlAppId();
    this.featureBranchId = this.getUrlFeatureBranchId();
    this.renderPage();
    this.renderVersionTable();
    this.getAppSimpleInfo();
  },

  methods: {

    getUrlFeatureBranchId() {
      let urlParams = this.getUrlParams();
      return urlParams['featureBranchId'];
    },

    getAppSimpleInfo() {
      $http.get($http.api.app.simpleInfo).then(res => {
        if(res.status == 200){
          this.appSimpleInfo = res.data;
        }
      }).catch((err) => {
        console.log(err);
      })
    },

    handleChangeReasonChange(value) {
      let oldChangeReason = this.featureBranchDetails.changeReason;
      this.featureBranchDetails.changeReason = value;
      let updateParam = {id:this.featureBranchId, changeReason: value};

      $http.post($http.api.feature_branch.update, updateParam).then(response => {
        if(response.status == 200) {
          this.$message({
            type: "success",
            message: "更新成功"
          });

        } else {
          this.featureBranchDetails.changeReason = oldChangeReason;
        }
      }).catch((e)=>{
        console.log(e);
        this.featureBranchDetails.changeReason = oldChangeReason;
      });
    },

    handleReleaseTimeChange(value) {
      let updateParam = {id: this.featureBranchId, planReleaseTime: value};
      $http.post($http.api.feature_branch.update, updateParam).then(response => {
        if(response.status == 200) {
          this.$message({
            type: "success",
            message: "更新成功"
          });
        } else {
          this.planReleaseTime = this.featureBranchDetails.planReleaseTime;
        }
      });
    },

    async handleAutoDeleteChange(value) {
      let confirmResult;
      try {
        confirmResult = await this.$confirm(
          '确定调整合并主干后删除分支' + this.featureBranchDetails.featureBranch + '？', '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          });
      } catch(e) {
        //do nothing
      }

      if(!confirmResult){
        this.featureBranchDetails.autoDelete = !value;
        return;
      }

      let updateParam = {id: this.featureBranchId, autoDelete: value};
      $http.post($http.api.feature_branch.update, updateParam).then(response => {
        if(response.status == 200) {
          this.$message({
            type: "success",
            message: "更新成功"
          });
        } else {
          this.featureBranchDetails.autoDelete = !value;
        }
      });
    },

    renderPage() {
      this.getFeatureBranchDetails();
    },

    passEnvClick(env) {
      $http.get($http.api.deploy_note.getPaasServerUrl, {env: env}).then((res) => {
        let url = res.data + "/appmanage/instanceRedirect?appId=" + this.appSimpleInfo.appCode;
        window.open(url, "_blank");
      });
    },

    getFeatureBranchDetails() {
      $http.get($http.api.feature_branch.details, { id: this.featureBranchId }).then(response => {
        this.featureBranchDetails = response.data;
        this.planReleaseTime = this.featureBranchDetails.planReleaseTime;
        if (this.featureBranchDetails.pipelineId) {
          this.$refs.WorkFlowStage.init(0, this.featureBranchDetails.pipelineId)
        }
      });
    },

    getBuildTaskVarsJson() {
      let varsSelectedObj = {};
      this.buildTaskVaiableList.forEach(item => {
        varsSelectedObj[item.variable] = item.currentOption;
      });
      return varsSelectedObj;
    },
    queryVariableSearch(queryString, cb , variable) {
      var restaurants = [];
      this.buildTaskVaiableList.forEach(item => {
        if(item.variable == variable){
          restaurants = item.options;
        }
      });
      var results = [];
      restaurants.forEach((item)=>{
        if(queryString == null || queryString == "" || item.toLowerCase().indexOf(queryString) == 0){
          results.push({value:item})
        }
      });
      cb(results);
    },
    handleOptionsSelect(selectData , currentOption){
      currentOption = selectData;
    },

    handleCloseVariablesDialog(){
      this.variablesDialogShow = false;
    },

    handleCloseIntegrationVariablesDialog(){
      this.integrationVariableDialogShow = false;
    },

    beginExecute() {
      $http.get($http.api.pipeline.buildTaskVars, { pipelineId: this.featureBranchDetails.pipelineId }).then(res => {
        this.buildTaskVaiableList = res.data;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
          this.variablesDialogShow = true;
        }else{
          this.variablesDialogShow = false;
          this.execute();
        }
      })
    },

    hasVariableBlank() {
      var hasVariableBlank = false;
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length > 0){
        this.buildTaskVaiableList.forEach(item=>{
          if(item.currentOption == null || item.currentOption == ""){
            hasVariableBlank = true;
          }
        });
      }
      return hasVariableBlank;
    },

    execute() {
      if(this.hasVariableBlank()){
        this.$message({
          showClose: true,
          message: '构建参数不能为空',
          type: 'warning'
        });
        return;
      }
      let formData = new FormData();
      formData.set("pipelineId", this.featureBranchDetails.pipelineId);
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
        let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
      }
      $http.post($http.api.pipeline.executeWhole, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "执行指令已下发"
          });
          this.$refs.WorkFlowStage.init(response.data)
        }
      });
      this.handleCloseVariablesDialog();
    },

    showDeleteDialog() {
      if(this.featureBranchDetails.status != this.FEATURE_BRANCH_STATUS.DEVELOPING) {
        return false;
      }
      this.deleteChangeDialogVisible = true;
    },

    closeDeleteDialog() {
      this.deleteChangeDialogVisible = false;
      this.$refs["deleteFormRef"].resetFields();
    },

    deleteChange() {
      let formData = new FormData();
      formData.set("id", this.featureBranchDetails.changeId);
      formData.set("alsoDeleteGit", this.deleteForm.alsoDeleteGit);
      $http.post($http.api.feature_branch.delete, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "删除变更成功",
            type: "success"
          });
          this.deleteChangeDialogVisible = false;
          this.goToPage(this, "featureBranchList", { bizId: this.bizId, appId: this.appId })
        }
      }).catch((e) => {
        //do nothing
      });
    },

    showDeployEnvChooseDialog() {
      this.deployEnvChooseDialogVisible = true;
    },

    closeDeployEnvChooseDialog() {
      this.deployEnvChooseDialogVisible = false;
      this.$refs["deployEnvChooseFormRef"].resetFields();
    },

    handleDeployEnvChooseConfirm() {
      this.manualDeploy(this.deployEnvChooseForm.appVersionId, this.deployEnvChooseForm.manualDeployEnv);
      this.deployEnvChooseDialogVisible = false;
    },

    showDeployPlanChooseDialog() {
      this.deployPlanChooseDialogVisible = true;
    },

    closeDeployPlanChooseDialog() {
      this.deployPlanChooseDialogVisible = false;
    },

    handleDeployPlanChooseConfirm() {
      if(this.deployPlanMultipleSelection.length == 0) {
        this.$message.error("请选择部署计划！");
        return;
      }

      this.autoDeploy(this.deployPlanMultipleSelection);
      this.deployPlanChooseDialogVisible = false;
    },

    beginIntegration() {
      $http.get($http.api.pipeline.buildTaskVars, { pipelineId: this.featureBranchDetails.pipelineId }).then(res => {
        this.buildTaskVaiableList = res.data;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
          this.integrationVariableDialogShow = true;
        }else{
          this.integrationVariableDialogShow = false;
          this.submitIntegration();
        }
      })
    },


    submitIntegration() {
      let directToIntegratedTest = false;
      if(this.appSimpleInfo.appIntegratedSettings.integratedDevEnabled != null && this.appSimpleInfo.appIntegratedSettings.integratedDevEnabled == false) {
        directToIntegratedTest = true;
      }
      if(this.hasVariableBlank()){
        this.$message({
          showClose: true,
          message: '构建参数不能为空',
          type: 'warning'
        });
        return;
      }
      let formData = new FormData();
      formData.set('id', this.featureBranchDetails.changeId);
      formData.set('sourceStatus', this.FEATURE_BRANCH_STATUS.DEVELOPING);
      if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
        let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
        formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
      }

      let targetStatus = directToIntegratedTest ? this.FEATURE_BRANCH_STATUS.INTEGRATED_TEST_WAITING
        : this.FEATURE_BRANCH_STATUS.INTEGRATED_DEV_WAITING;
      formData.set('targetStatus', targetStatus);

      $http.post($http.api.feature_branch.status, formData).then(response => {
        if (response.status == 200) {
          this.$message({
            message: "提交集成成功",
            type: "success"
          });
          let activeTab = directToIntegratedTest ? "integrated_test" : "integrated_dev";
          this.goToPage(this, 'featureBranchIntegration', { bizId: this.bizId, appId: this.appId, activeTab: activeTab });
        }
      }).catch((e) => {
        //do nothing
      });
      this.handleCloseIntegrationVariablesDialog();
    },

    goPipelineEditPage() {
      this.goToPage(this, 'appPipeline', { bizId: this.bizId, appId: this.appId, operation: 'edit', pipelineId: this.featureBranchDetails.pipelineId });
    },

    renderVersionTable() {
      this.getVersionList(this.versionTableData.pageNum, this.versionTableData.pageSize);
    },

    //分页
    handleSizeChange(curPageSize) {
      this.getVersionList(this.versionTableData.pageNum, curPageSize)
    },

    handleCurrentChange(curPageNum) {
      this.getVersionList(curPageNum, this.versionTableData.pageSize);
    },

    getVersionList(pageNum, pageSize) {
      let params = {
        id: this.featureBranchId,
        pageNum: pageNum,
        pageSize: pageSize,
      }

      $http.get($http.api.feature_branch.versionList, params).then(response => {
        this.versionTableData = response.data;
      });
    },

    checkUpload(versionId, type) {
      this.uploadDialogVisible = true;
      if(this.$refs.PackageUploadInfo) {
        this.$refs.PackageUploadInfo.init(versionId, type)
      }
    },

    handleCloseUpload() {
      this.uploadDialogVisible = false;
    },

    //点击版本名称下载
    downloadVersion(val) {
      if (val.pkgStatus == 4) {
        $http.get($http.api.appdate.api_app_version_download, { versionId: val.versionId }).then(res => {
          if (res.status == 200) {
            window.location.href = res.data.downloadUrl;
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }

        });
      }
    },

    //手动部署
    handleManualDeployClick(appVersion) {
      let stageList = this.$refs.WorkFlowStage.getPipelineStageList();
      let env = "dev"
      let needChooseEnv = false;
      loop1:
        for(let i = 0; i < stageList.length; i++) {
          let curStage = stageList[i];
          loop2:
            for(let j = 0; j < curStage.pipelineTaskLst.length; j++) {
              let curTask = curStage.pipelineTaskLst[j];
              if(curTask.type == this.WORKFLOW_TASK_TYPE.DEPLOY) {
                env = JSON.parse(curTask.setting).environment;
              }
              if(env != "dev") {
                needChooseEnv = true;
                break loop1;
              }
            }
        }

      if(needChooseEnv) {
        this.deployEnvChooseForm.appVersionId = appVersion.versionId;
        this.showDeployEnvChooseDialog();
      } else{
        this.manualDeploy(appVersion.versionId, env);
      }
    },

    manualDeploy(versionId, env) {
      this.$refs.paasDeploy.setDeployUrl(versionId, env);
    },

    handleAutoDeployClick(appVersion) {

      this.deployPlanTableData = [];
      this.deployPlanMultipleSelection = [];
      this.autoDeployVersionId = appVersion.versionId;

      //查找是否有多个部署任务，如果存在多个部署任务，要展示出来，让用户选择
      let stageList = this.$refs.WorkFlowStage.getPipelineStageList();
      let deployPlanIdSet = new Set();
      let deployPlanEnvSet = new Set();

      for(let i = 0; i < stageList.length; i++) {
        let curStage = stageList[i];
        for(let j = 0; j < curStage.pipelineTaskLst.length; j++) {
          let curTask = curStage.pipelineTaskLst[j];
          if(curTask.type == this.WORKFLOW_TASK_TYPE.DEPLOY
            && curTask.autoExec == true) {
            let curTaskParsedSetting = JSON.parse(curTask.setting);
            deployPlanIdSet.add(curTaskParsedSetting.deployPlanId);
            deployPlanEnvSet.add(curTaskParsedSetting.environment);
          }
        }
      }

      if(deployPlanIdSet.size == 0) {
        this.$message.error('当前流水线不存在可以自动部署的部署任务，请设置后再进行此操作！');
        return false;
      }

      this.deployPlanTableLoading = true;
      //渲染confirm表格
      deployPlanEnvSet.forEach((env) => {
        let params = {
          "appCode": this.appSimpleInfo.appCode,
          "env": env
        }

        //渲染deployPlan列表,注意比较开发，测试环境，开发环境在前
        $http.get($http.api.deploy.apideployplanlist, params).then(response => {
          if(response.status == 200) {
            let deployPlanList = response.data;

            if(this.deployPlanTableData.length == 0) {
              deployPlanList.forEach((item) => {
                this.deployPlanTableData.push(item);
              });
            }

            let firstExistedDeployPlan = deployPlanList[0];
            if (firstExistedDeployPlan.deployEnv == "dev") {
              deployPlanList.forEach((item) => {
                this.deployPlanTableData.push(item);
              });

            } else if (firstExistedDeployPlan.deployEnv == "test") {
              deployPlanList.forEach((item) => {
                this.deployPlanTableData.unshift(item);
              });
            }
          }
          //只要一个环境就好了，不强求两个环境共同刷新，情况很少
          this.deployPlanTableLoading  = false;
        });
      });
      this.deployPlanChooseDialogVisible = true;
    },

    handleDeployPlanSelectionChange(val) {
      this.deployPlanMultipleSelection = val;
    },

    autoDeploy(deployPlanSelection) {
      let paramLst = [];
      deployPlanSelection.forEach((item, index, arr) => {
        paramLst.push({
          deployPlanId: item.deployPlanId,
          env: item.deployEnv,
          versionId: this.autoDeployVersionId
        });
      });

      $http.post($http.api.deploy.execute, paramLst).then(response => {
        if(response.status == 200) {
          this.$message({
            message: '自动部署执行指令已发送，请等待部署完成',
            type: 'success'
          })
        }
      }).catch(ex => {
        console.log(ex);
      });
    },
  },
};
</script>

<style lang="scss" scoped>
  .basic-info-area {
    margin-bottom: 5px;
  }

  .basic-info-item {
    margin-right: 20px;
    display: inline;
  }

  .basic-info-label {
    font-weight: bold;
  }

  .fake-disabled-btn {
    color: #c0c4cc;
    background-color: #fff;
    border-color: #ebeef5;
    cursor: not-allowed;
  }

  .integrated-release-branch-box {
    padding: 10px;
    background-color: #ecf1f0;
    border: 1px solid #e2e7e6;
  }
  .common-table-box {
    @extend .integrated-release-branch-box;
    margin: 10px 0 0;
    background-color: #f9f9f9;
    border: none;
    .common-table-title {
      font-size: 14px;
      font-weight: 700;
      margin-bottom: 5px;
      // text-align: center;
    }
  }

</style>

