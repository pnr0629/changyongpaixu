<template>
  <div id="appList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar" style="height:40px;border-bottom:none;">
        <el-input v-model="search" style="width:280px;margin-top:-7px;float:left" placeholder="请输入关键字"
                  @input="getAppListByKeyWord()"></el-input>
        <el-button type="primary" class="ml10 mt5 fl" @click="getAppList()">查询</el-button>
        <el-button type="success" id="NEWAPP" class="ml10 mt5 fr" @click="creatApp()">+创建应用</el-button>
        <el-button type="primary" class="ml10 mt5 fr" @click="addTapsBtn()">标签管理</el-button>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-box-top" style="height:100%;">
            <el-tabs v-model="activeId" class="el-tabs-wai" @tab-click="getAppList()" type="border-card">
              <el-tab-pane v-for="tab in tabList" :key="tab.id+''" :label="tab.tagName" :name="tab.id+''">
                <div class="table-box">
                  <div class="table-box-top">
                    <el-table border :class="{'el-table-left-none':appDataList[''+tab.id+''].list.length == 0}"
                              :data="appDataList[''+tab.id+''].list">
                      <el-table-column align="left" prop="appCode" label="应用ID" min-width="100">
                        <template slot-scope="scope">
                          <i v-if="!scope.row.collected && authFunction('FUNC_APP_VER_LIST', 2, scope.row.appId)" class="el-icon-star-off c-blue cp" @click="changeAppCollection(scope.row.appId)" title="点击星标收藏应用"/>
                          <i v-if="scope.row.collected && authFunction('FUNC_APP_VER_LIST', 2, scope.row.appId)" class="el-icon-star-on c-blue cp" @click="changeAppCollection(scope.row.appId)" title="点击星标取消收藏应用"/>
                          <span :class="authFunction('FUNC_APP_VER_LIST', 2, scope.row.appId)?'c-blue cp':''"
                                title="点击星标收藏应用"
                                @click="authFunction('FUNC_APP_VER_LIST', 2, scope.row.appId)?goToAppDetail(scope.row):''">{{scope.row.appCode}}
                          </span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="appName" label="应用Owner" min-width="120">
                        <template slot-scope="scope">
                          {{getAppOwner(scope.row)}}
                        </template>
                      </el-table-column>
                      <el-table-column label="各环境部署管理" min-width="120">
                        <template slot-scope="scope">
                          <span class="c-blue cp" v-show="authFunction('FUNC_APP_VER_LIST', 2,scope.row.appId)"
                                @click="handleEnvClick('dev',scope.row.appCode)">开发环境</span>
                          <span class="c-blue cp" v-show="authFunction('FUNC_APP_VER_LIST', 2,scope.row.appId)"
                                @click="handleEnvClick('test',scope.row.appCode)">测试环境</span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="fastDeploy" label="是否快速发布" min-width="80">
                        <template slot-scope="scope">
                          {{getFastDeploy(scope.row)}}
                        </template>
                      </el-table-column>
                      <el-table-column min-width="120" label="操作">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="showPersonManageDialog(scope.row)" style=""
                                v-show="authFunction('FUNC_APP_DEL_APP', 2, scope.row.appId)">人员管理</span>
                          <span class="c-blue cp" @click="showSetAppTagDialog(scope.row)" style="padding: 4px"
                                v-show="authFunction('FUNC_APP_VER_LIST', 2, scope.row.appId)">应用标签</span>
                          <span class="c-blue cp" @click="showTransfer(scope.row)" style="padding: 4px"
                                v-show="authFunction('FUNC_APP_DEL_APP', 2, scope.row.appId)">应用迁移</span>
                          <span class="c-blue cp" @click="openDelAppAlert(scope.row)" style="padding: 4px"
                                v-show="authFunction('FUNC_APP_DEL_APP', 2, scope.row.appId)">删除</span>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                  <div class="table_b_f_b">
                    <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleAppSizeChange"
                                   @current-change="handleAppPageChange" :current-page="appDataList[tab.id+''].pageNum"
                                   :page-sizes="[20, 50, 100]"
                                   :page-size="appDataList[tab.id+''].pageSize"
                                   layout="total, sizes, prev, pager, next, jumper"
                                   :total="appDataList[tab.id+''].total">
                    </el-pagination>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>
          </div>
        </div>
      </div>
    </div>

    <!-- 人员设置 -->
    <xsStaffing ref='xsStaffing' @recheckFlush="StaffingBtn" :staffingTitle="staffingTitle" :devList="devList"
                :initSelectDevList="selectDevList" :testList="testList" :initSelectTestList="selectTestList"
                :confirmClick="memberConfirmClick"></xsStaffing>

    <!-- 应用迁移 -->
    <el-dialog :title='appTransfer.ransferName'  :visible.sync="dialogVisible_tansfer"
               class="el-dialog-400w"
               :before-close="closeTransfer" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form ref="yyinfoname_a" label-width="70px">
          <el-form-item  label="所属业务">
            <el-input placeholder="请输入内容" v-model="appTransfer.sourceBizName" disabled></el-input>
          </el-form-item>

          <el-form-item label="目标业务">
            <el-select v-model="appTransfer.targetBizId" filterable placeholder="请选择" style="width:100%;">
              <el-option v-for="item in appTransfer.bizList" :key="item.bizId" :label="item.bizName"
                         :value="item.bizId">
                <span style="float: left">{{item.bizName}}</span>
              </el-option>
            </el-select>
          </el-form-item>

        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" class="fr ml10" @click="saveTransfer">保存</el-button>
        <el-button class="fr" @click="closeTransfer">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 标签管理 -->
    <el-dialog title='标签管理' :visible.sync="dialogVisible" class="issuedialog el-dialog-740w"
               :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div class="addclassTap">
          <span class="tapTitile">标签信息</span>
          <el-button type="primary" class="addtap" @click="showCreateTagDialog()">+添加标签</el-button>
        </div>
        <el-table :data="totalTagList" style="width: 100%;height: 100%;overflow:auto;">
          <el-table-column prop="tagName" label="名称" min-width="120">
          </el-table-column>
          <el-table-column prop="createTime" label="创建时间" min-width="80">
          </el-table-column>
          <el-table-column prop="updateTime" label="更新时间" min-width="80">
          </el-table-column>
          <el-table-column width="120" align="left" label="操作">
            <template slot-scope="scope">
              <span class="c-blue cp" v-show="showTagHandle(scope.row)" @click="showEditTagDialog(scope.row)">编辑</span>
              <span class="c-blue cp" v-show="showTagHandle(scope.row)" @click="showDelTagDialog(scope.row)">删除</span>
            </template>/app/settings
          </el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
            <el-button @click="submitBtn">关闭</el-button>
          </span>
    </el-dialog>


    <el-dialog title='设置应用标签' :visible.sync="dialogAppTagVisible" class="el-dialog-350w issuedialog"
               :before-close="handleSetAppTagDialogClose" :modal-append-to-body="modaltobody"
               :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form>
          <el-form-item :gutter="10" class="mt20" label="标签" label-width="60px"
                        :rules="[{ required: true, message: '不能为空'}]">
            <el-select v-model="selectAppTagList" multiple placeholder="请选择" clearable style="width:100%;">
              <el-option v-for="item in totalTagList" v-show="showTagHandle(item)" :key="item.id" :label="item.tagName" :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleSetAppTagDialogClose">关闭</el-button>
        <el-button type="primary" @click="bindAppTag()">保存</el-button>
      </span>
    </el-dialog>
    <!-- 添加标签 -->
    <el-dialog :title='tapTitle' :visible.sync="dialogVisible_a" class="el-dialog-350w issuedialog"
               :before-close="closeTagEditDialog" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="TagNameInfo" ref="TagNameInfo" @submit.native.prevent>
          <el-form-item label="标签" class="mt15" label-width="55px" prop="inputTagName"
                        :rules="[{required: true, message: '不能为空' ,trigger: 'blur'}]">
            <el-input v-model.trim="TagNameInfo.inputTagName" style="width: 100%;"
                      placeholder="请输入标签名称，字数控制20字以内"></el-input>
          </el-form-item>
          <el-form-item v-show="authFunction('FUNC_BIZ_IDENTITY_ADMIN', 1)" class="mt15" label-width="55px" label="类型" prop="inputTagType">
            <el-radio-group v-model="TagNameInfo.inputTagType">
              <el-radio :label="0">私有</el-radio>
              <el-radio :label="1">公共</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeTagEditDialog()">关闭</el-button>
        <el-button type="primary" @click="saveOrUpdateTag()">保存</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  export default {
    name: "appList",
    data() {
      return {
        appTransfer:{
          targetBizId: null,
          sourceBizId: null,
          sourceBizName: null,
          appId: null,
          bizList: [],
          ransferName:null
        },
        currentUserId: 0,
        myAppIdList: [],
        devList: [],
        activeAppId: null,
        selectDevList: [],
        testList: [],
        selectTestList: [],
        basicTabList: [{
          id: -2,
          tagName: '我的应用',
          queryType: 1,
        }, {
          id: -1,
          tagName: '全部应用',
          queryType: 2,
        }],
        tabList: [],
        totalTagList: [],
        modaltobody: false,
        shadeBtn: false,
        appDataList: {
          "-1": {
            pageNum: 1,
            pageSize: 20,
            total: 0,
            list: []
          },
          "-2": {
            pageNum: 1,
            pageSize: 20,
            total: 0,
            list: []
          }
        },
        titleIssue: "",
        titleIssue_a: "",
        activeId: "-2",
        bizId: 0,
        selectAppTagList: [],
        appData: {},
        staffingTitle: "应用人员管理",
        dialogVisible: false,
        dialogAppTagVisible: false,
        dialogVisible_a: false,
        dialogVisible_tansfer: false,
        TagNameInfo: {
          inputTagName: '',
          inputTagType: 0
        },
        inputTagId: null,
        bindApp: {},
        height_a: '',
        tapTitle: '',
        search: '',
        isSearching: false,
      };
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this.getCurrentUserId();
      this.getTagList();
      this.getMyAppIds();
    },

    methods: {

      showTagHandle(appTag){
        let isShow = false;
        let currentUserId = $utils.getCurrentUserId();
        if(appTag.type === 1){
          if(this.authFunction('FUNC_BIZ_IDENTITY_ADMIN', 1) && currentUserId === appTag.createUser){
            isShow = true
          }
        }else{
          isShow = true;
        }
        return isShow;
      },

      changeAppCollection(val) {
        $http.get($http.api.app.change_app_collection, {appId: val}).then(res => {
          let status = res.data.status
          if (status) {
            this.$message({message: res.data.msg, type: "success"})
          } else {
            this.$message({message: res.data.msg, type: "error"})
          }
          this.getAppList();
        }).catch(e => {
          this.$message({message: "接口请求失败！", type: "error"})
        })
      },

      showTransfer(app){
        this.appTransfer.appId=app.appId;
        this.appTransfer.ransferName='迁移应用【'+app.appCode+'】';
        this.appTransfer.sourceBizId=this.$route.query.bizId;
        $http.get($http.api.biz.getAllBizList).then((res) =>{
          this.appTransfer.bizList=res.data;
          for(let i=0;i<this.appTransfer.bizList.length;i++){
            if (this.appTransfer.sourceBizId+''===this.appTransfer.bizList[i].bizId+'') {
              this.appTransfer.sourceBizName=this.appTransfer.bizList[i].bizName;
              this.appTransfer.bizList.splice(i,1);
              return;
            }
          }
        });
        this.dialogVisible_tansfer=true;
      },

      saveTransfer(){
        if (this.appTransfer.targetBizId===null){
          this.$message({
            message: '目标业务不能为空',
            type: 'error'
          });
          return;
        }
        let params= {
          appId: this.appTransfer.appId,
          sourceBizId: this.appTransfer.sourceBizId,
          targetBizId: this.appTransfer.targetBizId
        };
        $http.get($http.api.app.app_transfer,params).then((res) =>{
          this.$message({
            message: '迁移成功',
            type: 'success'
          })
          this.getAppList();
          this.appTransfer.targetBizId=null;
          this.dialogVisible_tansfer=false;
        }).catch((e,res) =>{
          return;
        });
      },

      closeTransfer(){
        this.dialogVisible_tansfer=false;
      },

      isCurrentUserAppOwner(app) {
        return this.currentUserId === this.getAppOwnerId(app);
      },

      getCurrentUserId() {
        let currentUserId = $utils.getCurrentUserId();
        this.currentUserId = currentUserId;
      },

      handleEnvClick(env, appCode) {
        $http.get($http.api.deploy_note.getPaasServerUrl, {env: env}).then((res) => {
          let url = res.data + "/appmanage/instanceRedirect?appId=" + appCode;
          window.open(url, "_blank");
        });
      },

      memberConfirmClick(type, dataList) {
        if (type === 1) {
          $http.post($http.api.app.saveApplicationDevMembers, {
            appId: this.activeAppId,
            userIdsStr: dataList.join(",")
          }).then((res) => {
            this.$message({
              type: 'success',
              message: '保存开发人员成功'
            });
          }).catch(() => {
            this.$message({
              type: "error",
              message: "保存开发人员失败"
            });
          });
        } else {
          $http.post($http.api.app.saveApplicationTestMembers, {
            appId: this.activeAppId,
            userIdsStr: dataList.join(",")
          }).then((res) => {
            this.$message({
              type: 'success',
              message: '保存测试人员成功'
            });
          }).catch(() => {
            this.$message({
              type: "error",
              message: "保存测试人员失败"
            });
          });
        }
      },
      handleAppPageChange(val) {
        this.appDataList[this.activeId].pageNum = val;
        this.getAppList();
      },
      handleAppSizeChange(val) {
        this.appDataList[this.activeId].pageSize = val;
        this.getAppList();
      },
      openDelAppAlert(app) {
        this.$confirm('此操作删除该应用[' + app.appCode + '], 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.get($http.api.app.delApplication, {appId: app.appId}).then((res) => {
            this.$message({
              message: '删除成功!',
              type: 'success'
            });
            this.getAppList();
          })
        }).catch(() => {
        });
      },
      showSetAppTagDialog(app) {//显示设置应用标签的弹窗
        this.bindApp = app;
        this.selectAppTagList = [];
        app.applicationTags.forEach(val => {
          this.selectAppTagList.push(val.tagId);
        });
        this.dialogAppTagVisible = true;
      },
      getMyAppIds() {
        let params = {
          bizId: this.bizId,
          queryType: 1,
          pageNum: 1,
          pageSize: 100000000,
        };
        $http.get($http.api.app.list, params).then((res) => {
          this.myAppIdList = [];
          res.data.list.forEach(item => {
            this.myAppIdList.push(item.appId);
          });
        });
      },
      getAppListByKeyWord() {
        if (this.isSearching) {
          return;
        }
        this.isSearching = true;
        setTimeout(() => {
          this.$nextTick(() => {
            this.getAppList();
          });
        }, 800);
      },
      getAppList() {
        this.isSearching = true;
        let tab;
        for (let index in this.tabList) {
          if (this.tabList[index].id == this.activeId) {
            tab = this.tabList[index];
            break;
          }
        }
        let params = {
          bizId: this.bizId,
          queryType: tab.queryType,
          tagId: this.activeId,
          keyword: this.search,
          pageNum: this.appDataList[this.activeId].pageNum,
          pageSize: this.appDataList[this.activeId].pageSize,
        };
        $http.get($http.api.app.list, params).then((res) => {
          this.appDataList[tab.id + ''] = res.data;
          this.isSearching = false;
        });
      },
      getAppOwner(app) {
        if (!!app && !!app.applicationMembers && app.applicationMembers.length != 0) {
          var arr = [];
          app.applicationMembers.forEach(item => {
            arr.push(item.userName + "(" + item.userId + ")");
          });
          return arr.join(",")
        }
        return "";
      },
      getAppOwnerId(app) {
        if (!!app && !!app.applicationMembers && app.applicationMembers.length != 0) {
          var arr = [];
          app.applicationMembers.forEach(item => {
            arr.push(item.userId);
          });
          return arr.join(",")
        }
        return "";
      },
      getTagList() {
        $http.get($http.api.app.getTagList, {
          bizId: this.bizId
        }).then((res) => {
          this.tabList = [];
          this.basicTabList.forEach(val => {
            this.tabList.push(val);
          });
          this.totalTagList = res.data;
          res.data.forEach(val => {
            val.queryType = 3;
            this.tabList.push(val);
            this.$set(this.appDataList, val.id + '', {
              pageNum: 1,
              pageSize: 20,
              total: 0,
              list: []
            });
          });
          this.getAppList();
        })
      },
      //人员管理按钮
      showPersonManageDialog(app) {
        let appId = app.appId;
        this.activeAppId = appId;
        this.staffingTitle = '应用【' + app.appCode + '】人员管理';
        this.devList = [];
        this.selectDevList = [];
        this.testList = [];
        this.selectTestList = [];
        $http.get($http.api.app.get_application_member_config_info, {appId: appId}).then((res) => {
          res.data.appDevMembers.forEach(val => {
            let oneDev = {key: val.userId, label: val.userName};
            this.devList.push(oneDev);
            this.selectDevList.push(val.userId);
          });
          res.data.unSelectedDevs.forEach(val => {
            this.devList.push({key: val.userId, label: val.userName});
          });

          res.data.appTestMembers.forEach(val => {
            let oneTest = {key: val.userId, label: val.userName};
            this.testList.push(oneTest)
            this.selectTestList.push(val.userId);
          });
          res.data.unSelectedTests.forEach(val => {
            this.testList.push({key: val.userId, label: val.userName});
          });

          this.$refs.xsStaffing.showcCldProdRight_s();
        });

      },

      //人员设置子类调用父类的方法
      StaffingBtn() {
      },


      //标签管理
      addTapsBtn() {
        this.dialogVisible = true;
      },
      //关闭标签弹窗
      handleClose() {
        this.dialogVisible = false;
      },

      //关闭应用设置标签弹窗
      handleSetAppTagDialogClose() {
        this.dialogAppTagVisible = false;
      },

      //关闭应用设置标签弹窗
      bindAppTag() {
        $http.post($http.api.app.bindTag, {
          appId: this.bindApp.appId,
          tagIds: this.selectAppTagList.join(",")
        }).then((res) => {
          this.$message({
            type: 'success',
            message: '应用绑定标签成功'
          });
          this.getTagList();
        }).catch(() => {
          this.$message({
            type: 'error',
            message: '应用绑定标签失败'
          });
        });
        this.handleSetAppTagDialogClose();
      },

      //点击确定按钮关闭标签管理弹窗
      submitBtn() {
        this.handleClose();
      },
      //添加标签(小弹窗)
      showCreateTagDialog() {
        this.inputTagId = null;
        this.TagNameInfo.inputTagName = '';
        this.TagNameInfo.inputTagType = 0;
        this.height_a = 'addTop';
        this.tapTitle = '创建标签';
        this.dialogVisible_a = true;
      },

      //点击取消按钮关闭标签管理弹窗
      closeTagEditDialog() {
        this.dialogVisible_a = false;
      },
      //点击确定按钮关闭标签管理弹窗
      saveOrUpdateTag() {
        if (!this.TagNameInfo.inputTagName || this.TagNameInfo.inputTagName.length === 0) {
          this.$message({
            message: "请输入标签名",
            type: "warning"
          });
          return;
        }
        if (this.TagNameInfo.inputTagName.length > 20) {
          this.$message({
            message: "输入的标签名过长",
            type: "warning"
          });
          return;
        }

        if (this.inputTagId) {
          $http.post($http.api.app.updateTag, {
            id: this.inputTagId,
            tagName: this.TagNameInfo.inputTagName,
            type: this.TagNameInfo.inputTagType
          }).then((res) => {
            this.$message({
              type: 'success',
              message: '修改标签成功'
            });
            this.closeTagEditDialog();
            this.getTagList();
          }).catch(() => {
            this.$message({
              type: 'error',
              message: '修改标签失败'
            });
          });
        } else {
          $http.post($http.api.app.addTag, {bizId: this.bizId, tagName: this.TagNameInfo.inputTagName, type: this.TagNameInfo.inputTagType}).then((res) => {
            this.$message({
              type: 'success',
              message: '添加标签成功'
            });
            this.closeTagEditDialog();
            this.getTagList();
          }).catch(() => {
            this.$message({
              type: 'error',
              message: '添加标签失败'
            });
          });
        }
      },

      //小弹窗编辑标签
      showEditTagDialog(tag) {
        this.height_a = 'editBtn';
        this.tapTitle = '编辑标签';
        this.dialogVisible_a = true;
        this.TagNameInfo.inputTagName = tag.tagName;
        this.TagNameInfo.inputTagType = tag.type;
        this.inputTagId = tag.id;
      },
      //删除信息
      showDelTagDialog(tag) {
        this.$confirm('此操作删除该标签[' + tag.tagName + '], 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.app.delTag, {id: tag.id}).then((res) => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
            this.getTagList();
          });
        }).catch(() => {
        });
      },


      //创建应用
      creatApp() {
        this.goToPage(this, 'appCreate', {bizId: this.bizId})
      },

      //点击应用ID跳转到版本列表
      goToAppDetail(val) {
        let appDetailsDefaultDestination = "appVersions";
        if(val.developMode && val.developMode == 1) {
          appDetailsDefaultDestination = "featureBranchList";
        }

        this.goToPage(this, appDetailsDefaultDestination, {appId: val.appId, bizId: this.$route.query.bizId});
      },


      handleSizeChange(val) {

      },

      handleCurrentChange(val) {

      },

      getFastDeploy(app) {
        if (app && app.fastDeploy && app.fastDeploy == 1) {
          return "是";
        }
        return "否";
      },

    }
    ,
    components: {}
  }
  ;
</script>

<style lang="scss" scoped>
  .issuedialog {
    .addclassTap {
      height: 30px;

      .tapTitile {
        font-size: 16px;
        font-weight: 400;
      }

      .addtap {
        float: right;
      }
    }

  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .paintermouse {
    cursor: pointer;
  }

  .paintermouse:hover {
    color: #409eff;
  }
</style>
