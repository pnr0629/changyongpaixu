<template>
  <div id="appPipelineList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="white-box table-outer-box">
        <div class="table-box" style="height:auto;">
          <div class="table-box-top" style="padding-top:10px;">
              <div class="btnArea">
                <el-row type="flex" justify="space-between">
                    <el-button type="success" class="mb10" @click="createPipeline()">创建流水线</el-button>
                    <el-button type="primary" class="mb10" @click="renderTable()">刷新</el-button>
                </el-row>
              </div>

              <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                <div class="table-box-top-bs">
                  <el-table :data="pipelineListData.list" style="width:100%;height:100%;overflow:auto;">

                    <el-table-column label="流水线名称" min-width="120">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="goToPipelineDetail(scope.row)">
                              {{scope.row.pipelineName}}
                          </span>
                          <span style="padding: 2px; border-radius: 2px; display: inline-block; background: #000; vertical-align: center;" v-if="scope.row.defaultPipeline == true">
                                <span style="display: block; color: #FFFFFF; height: 14px; line-height: 14px; text-align: center">default</span>
                           </span>

                        </template>
                    </el-table-column>

                    <el-table-column prop="defaultBranch" label="默认关联分支" min-width="100">
                    </el-table-column>

                    <el-table-column prop="updateTime" label="最近更新时间" min-width="80">
                    </el-table-column>

                    <el-table-column prop="pipelineStageRunningInfoBos" label="运行状态" min-width="120">
                        <template slot-scope="scope">
                          <span class="cp" v-for="(item,index) in scope.row.pipelineStageRunningInfoBos" :key="item.id"
                                @click="showVersionPipeline(scope.row.latestWorkflowId)">
                            <i class="iconfont" :class="getClassByRunningStatus(item.stageRunningStatus)" :title="item.name"></i>
                            <i class="iconfont icon-more" v-if="scope.row.pipelineStageRunningInfoBos.length-1 != index"></i>
                          </span>
                        </template>
                    </el-table-column>

                    <el-table-column label="创建人" min-width="70">
                      <template slot-scope="scope">
                        {{getCreateUser(scope.row)}}
                      </template>
                    </el-table-column>

                    <el-table-column label="触发机制" min-width="50">
                      <template slot-scope="scope">
                        {{getTriggerMode(scope.row)}}
                      </template>
                    </el-table-column>

                    <el-table-column prop="time" label="操作" min-width="120">
                      <template slot-scope="scope">
                        <template v-if="ifExecuteBtnAreaVisiable(scope.row)">
                          <span class="c-blue cp" @click="beginPipeLine(scope.row)" v-if="!isFeatureBranchIntegratedPipeline(scope.row) && ifExecuteBtnVisiable(scope.row.pipelineStageRunningInfoBos)">执行<span class="cursor-text" v-if="appearExecuteBtn && appearReExecuteBtn">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></span>
                          <span class="c-blue cp" @click="beginPipeLine(scope.row)" v-if="!isFeatureBranchIntegratedPipeline(scope.row) && ifReExecuteBtnVisiable(scope.row.pipelineStageRunningInfoBos)">重新执行</span>
                          <span class="c-blue cp" @click="goToPipelineExecHistory(scope.row)">历史执行记录</span>
                        &nbsp;&nbsp;&nbsp;
                          <span class="c-blue cp" @click="editPipeline(scope.row)">编辑</span>
                        &nbsp;&nbsp;&nbsp;
                          <span class="c-blue cp" v-if="canPipelineBeDeleted(scope.row)" @click="deletePipeline(scope.row)">删除</span>
                        </template>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="table_b_f_b">
                  <el-pagination
                    class="fr"
                    style="margin-top: 9px;"
                    @size-change="handlePipelineListSizeChange"
                    @current-change="handlePipelineListPageChange"
                    :current-page="pipelineListData.pageNum"
                    :page-sizes="[10, 20, 30]"
                    :page-size="pipelineListData.pageSize"
                    layout="total, sizes, prev, pager, next, jumper"
                    :total="pipelineListData.total">
                  </el-pagination>
                </div>
              </div>
            </div>
        </div>
      </div>
    </div>
    <!--选择流水线模板-->
    <el-dialog title='选择流水线模板' :visible.sync="showCreatePipelineDialog" class="issuedialog el-dialog-400w"
               :before-close="closeCreatePipelineDialog">
      <div class="form-iterm-box">
        <el-form ref="createPipelineDialogForm" :model="createPipelineTemplateInfo">
          <el-form-item class="mt0 mb10" prop="type" :rules="[{required: true, message: '请选择流水线模板' ,trigger: 'blur'}]">
            <el-radio-group style="display: inline-grid;" v-model="createPipelineTemplateInfo.type" @change="handlePipelineTemplateChange">
              <el-radio class="mt5 mb10 ml0" v-for="item in createPipelineTemplateTypeList" :key="item.value" :label="item.value">{{item.label}}</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item class="mt10 mb10 ml10" label="复制自流水线" prop="pipelineId" v-if="createPipelineTemplateInfo.type==3" :rules="[{required: true, message: '请选择复制的流水线' ,trigger: 'blur'}]">
            <el-select v-model="createPipelineTemplateInfo.pipelineId" placeholder="请选择">
              <el-option v-for="item in copyPipelineList" :key="item.id" :label="item.name"
                         :value="item.id">
                <span style="float: left">{{item.name}}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeCreatePipelineDialog">取消</el-button>
        <el-button type="primary" @click="createPipelineFromTemplate()">确定</el-button>
      </span>
    </el-dialog>
    <!--流水线运行详情-->
    <app-version-pipeline ref="appVersionPipeline" @refreshVersion="renderTable"></app-version-pipeline>

    <el-dialog title='构建参数' :visible.sync="variablesDialogShow" class="el-dialog-400w"
               :modal-append-to-body="false"     :close-on-click-modal="false"        >
      <div class="form-iterm-box">
        <el-form  label-width="100px" @submit.native.prevent>
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
            <el-col :span='24'
                    v-if="variablesDialogShow && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:200px;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>

          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCloseVariablesDialog">取消</el-button>
        <el-button type="primary" @click="beginPipeLineWithVariables(executePipelineRow)">确定</el-button>
      </span>
    </el-dialog>
  </div>

</template>

<script>
  import AppVersionPipeline from '@/components/biz/app/appVersionPipeline'

  export default {
    name: "appPipelineList",
    data() {
      return {
        table_loading: false,
        appearExecuteBtn: false,
        appearReExecuteBtn: false,
        pipelineListData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },

        bizId: '',
        appId: '',
        showCreatePipelineDialog: false,
        createPipelineTemplateInfo: {
          type: '',
          pipelineId: ''
        },
        createPipelineTemplateTypeList: [
          {
            value: 2,
            label: "默认研发流程流水线"
          },
          {
            value: 1,
            label: "空白流水线"
          },
          {
            value: 3,
            label: "复制已存在的流水线"
          },
          {
            value: 4,
            label: "默认自动化测试流水线"
          }
        ],
        copyPipelineList:[],
        copyPipelineListInited: false,
        buildTaskVaiableList:[],
        //控制构造参数选择框显示
        variablesDialogShow: false,
        //构建参数输入为空提示
        variablesEmptyWarningShow: false,
        //执行流水线的数据
        executePipelineRow: "",
      };
    },

    mounted() {
      this.bizId = this.getUrlBizId();
      this.appId = this.getUrlAppId();
      this.renderTable();
    },

    methods: {
      createPipelineFromTemplate() {
        this.$refs["createPipelineDialogForm"].validate(validate => {
          if (validate) {
            this.goToPage(this, 'appPipeline', {
              bizId: this.bizId, appId: this.appId,
              operation: 'create', templateType: this.createPipelineTemplateInfo.type,
              templatePipelineId: this.createPipelineTemplateInfo.pipelineId
            });
          }
        });
      },

      closeCreatePipelineDialog() {
        this.showCreatePipelineDialog = false;
        this.createPipelineTemplateInfo.type = '';
        this.createPipelineTemplateInfo.pipelineId = '';
        this.$refs["createPipelineDialogForm"].resetFields();
      },

      getCreateUser(row) {
        if (row && (row.createUserId || row.createUserName)) {
          return row.createUserName + '(' + row.createUserId + ')';
        }
        return "";
      },

      getTriggerMode(row){
        if (row && row.triggerMode){
          return GLOBAL_CONST.PIPELINE_TRIGGER_TYPE_MAP[row.triggerMode];
        }
        return "";
      },

      handlePipelineListSizeChange(newPageSize) {
        this.pipelineListData.pageSize = newPageSize;
        this.renderTable();
      },

      handlePipelineListPageChange(newPageNum) {
        this.pipelineListData.pageNum = newPageNum;
        this.renderTable();
      },

      renderTable(executeWorkflowId) {
        this.table_loading = true;
        let params = {
          appId: this.appId,
          pageNum: this.pipelineListData.pageNum,
          pageSize: this.pipelineListData.pageSize,
        };

        $http.get($http.api.pipeline.list, params).then(response => {
          this.pipelineListData = response.data;

          if (executeWorkflowId) {
            this.$nextTick(() => {
              this.showVersionPipeline(executeWorkflowId)
            })
          }
          this.table_loading = false;
          this.appearExecuteBtn = false;
          this.appearReExecuteBtn = false;
        });
      },

      createPipeline() {
        this.showCreatePipelineDialog = true;
        //默认选中‘默认研发流程流水线’
        this.createPipelineTemplateInfo.type = 2;
      },

      goToPipelineDetail(row) {
        this.goToPage(this, 'appPipeline',  {bizId : this.bizId, appId : this.appId, operation:'view', pipelineId : row.pipelineId});
      },

      goToPipelineExecHistory(row) {
        this.goToPage(this, 'appPipelineExecHistory', {bizId : this.bizId, appId : this.appId, uuid : row.pipelineUuid})
      },
      getBuildTaskVarsJson() {
        let varsSelectedObj = {};
        this.buildTaskVaiableList.forEach(item => {
          varsSelectedObj[item.variable] = item.currentOption;
        });
        return varsSelectedObj;
      },
      queryVariableSearch(queryString, cb , variable) {
        var restaurants = [];
        this.buildTaskVaiableList.forEach(item => {
          if(item.variable == variable){
            restaurants = item.options;
          }
        });
        var results = [];
        restaurants.forEach((item)=>{
          if(queryString == null || queryString == "" || item.toLowerCase().indexOf(queryString) == 0){
            results.push({value:item})
          }
        });
        cb(results);
      },
      handleOptionsSelect(selectData , currentOption){
        currentOption = selectData;
      },

      handleCloseVariablesDialog(){
        this.variablesDialogShow = false;
      },

      beginPipeLine(row) {
        this.executePipelineRow = row;
        $http.get($http.api.pipeline.buildTaskVars, { pipelineId: row.pipelineId }).then(res => {
          this.buildTaskVaiableList = res.data;
          if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0){
            this.variablesDialogShow = true;
          }else{
            this.variablesDialogShow = false;
            this.beginPipeLineWithVariables(row);
          }
        })
      },

      beginPipeLineWithVariables(row){
        var hasVariableBlank = false;
        this.buildTaskVaiableList.forEach(item=>{
          if(item.currentOption == null || item.currentOption == ""){
            hasVariableBlank = true;
          }
        });
        if(hasVariableBlank){
          this.$message({
            showClose: true,
            message: '构建参数不能为空',
            type: 'warning'
          });
          return;
        }
        if(this.ifExecuteBtnVisiable(row.pipelineStageRunningInfoBos)){
          this.executePipeline(row)
        }else{
          this.reExecutePipeline(row)
        }
        this.handleCloseVariablesDialog();
      },

      executePipeline(row) {
        let formData = new FormData();
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
          let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
          formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
        }
        formData.set("pipelineId", row.pipelineId);
        $http.post($http.api.pipeline.executeWhole, formData).then(response => {
          if (response.status == 200) {
            this.$message({
              message: "执行指令已下发"
            });

            let executeWorkflowId = response.data;
            this.renderTable(executeWorkflowId);
          }
        });

      },

      reExecutePipeline(row) {
        this.$confirm(`流水线[${row.pipelineName}]上一次的执行流程仍未执行完，确定重新执行流水线？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let formData = new FormData();
          formData.set("pipelineId", row.pipelineId);
          if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length != 0) {
            let buildTaskVarsJsonStr = this.getBuildTaskVarsJson() ? JSON.stringify(this.getBuildTaskVarsJson()) : '';
            formData.set("buildTaskVarsJsonStr" , buildTaskVarsJsonStr);
          }
          $http.post($http.api.pipeline.executeWhole, formData).then(response => {
            if (response.status == 200) {
              this.$message({
                message: "重新执行指令已下发"
              });

              let executeWorkflowId = response.data;
              this.renderTable(executeWorkflowId);
            }
          });
        }).catch(() => {

        });
      },

      //编辑列表,在查看的基础上多了一步自动触发跳进去后的页面的“编辑”按钮
      editPipeline(row) {
        this.goToPage(this, 'appPipeline',  {bizId : this.bizId, appId : this.appId, operation : 'edit', pipelineId : row.pipelineId});
      },

      //自由分支专用的流水线，以及特性分支下手工创建的流水线才可以删除
      canPipelineBeDeleted(row) {
        return !row.featureBranchType;
      },

      //删除
      deletePipeline(row) {
        this.$confirm(`确定要删除流水线[${row.pipelineName}]？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          let formData = new FormData();
          formData.set('pipelineId', row.pipelineId);
          $http.post($http.api.pipeline.delete, formData).then(response => {
            if (response.status == 200) {
              this.$message({
                message: "删除成功",
                type: "success"
              });
              this.renderTable();
            }
          });
        }).catch(() => {
        });
      },

      ifExecuteBtnAreaVisiable(row) {
        if(row.appType == 5 && row.pkgable == true) {
          return false;
        }
        return true;
      },

      ifExecuteBtnVisiable(pipelineStageRunningInfoBos) {
        let result = false;
        if(!pipelineStageRunningInfoBos || pipelineStageRunningInfoBos.length == 0){
          result = true;
        }else{
          let lastPipelineStageRunningInfo = pipelineStageRunningInfoBos[pipelineStageRunningInfoBos.length - 1];
          if(lastPipelineStageRunningInfo.stageRunningStatus == 'SUCCESS'){
            result = true;
          }
        }
        if(result){
          this.appearExecuteBtn = true;
        }

        return result;
      },

      isFeatureBranchIntegratedPipeline(row) {
        if (row && row.developMode == 1 &&
          (row.featureBranchType == 'integrated_test' || row.featureBranchType == 'integrated_dev')) {
          return true;
        }
        return false;
      },

      ifReExecuteBtnVisiable(pipelineStageRunningInfoBos) {
        let result = !this.ifExecuteBtnVisiable(pipelineStageRunningInfoBos);
        if(result){
          this.appearReExecuteBtn = true;
        }
        return result;
      },

      getClassByRunningStatus(status) {
        switch (status) {
          case GLOBAL_CONST.STAGE_STATUS.NOT_RUNNING:
            return "icon-status-init-l";
          case GLOBAL_CONST.STAGE_STATUS.WAIT:
            return "icon-status-waiting-l";
          case GLOBAL_CONST.STAGE_STATUS.RUNNING:
            return "icon-status-running-l";
          case GLOBAL_CONST.STAGE_STATUS.SUCCESS:
            return "icon-status-success-l";
          case GLOBAL_CONST.STAGE_STATUS.FAILURE:
            return "icon-status-fail-l";
        }
      },

      handlePipelineTemplateChange(radioValue) {
        //模式是复制已经存在某条流水线
        if(radioValue == 3 && !this.copyPipelineListInited) {
          this.initCopyPipelineList();
        }
      },

      initCopyPipelineList() {
        $http.get($http.api.pipeline.copyList, {appId: this.appId}).then(response => {
          if(response.status == 200) {
            this.copyPipelineList = response.data;
            this.copyPipelineListInited = true;
          }
        });
      },

      showVersionPipeline(latestWorkflowId) {
        this.$refs.appVersionPipeline.showVersionPipeline(latestWorkflowId, this.appId);
      },

    },

    components: {
      AppVersionPipeline
    }
  };
</script>
