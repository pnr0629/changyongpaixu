<template>
  <div id="appVersions" class="content-outer-box">
    <div class="x-arD content-box" style="background:#ffffff;">
      <div class="white-box table-outer-box">
        <div v-show="appType != 5" class="pb20" v-loading="table_loading" element-loading-text="拼命加载中">
          <h4 style="margin-block-start: 0.33em;
              margin-block-end: 0.33em;margin-bottom:10px;">分支列表&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <span style="font-weight: normal">git地址：{{gitAddress}}</span>
          </h4>
          <el-input @keyup.native="searchBranch(search)" @blur="searchBranch(search)" v-model="search"
                    style="width:280px;margin-bottom:8px;float:left" placeholder="请输入分支名称搜索"></el-input>
          <el-button type="primary" @click="showApplicationAssociation(bizId, appId)" class="fr mr10">关联应用</el-button>
          <el-table
            border
            :class="{'el-table-left-none':tableList.data.length == 0}"
            :border="true"
            ref="multipleTable"
            :data="tableListNew.data">
            <el-table-column prop="name" label="分支名称" min-width="180"></el-table-column>
            <el-table-column prop="commitId" label="CommitId" min-width="180"></el-table-column>
            <el-table-column prop="commitMessage" label="提交日志" min-width="240"></el-table-column>
            <el-table-column label="最后提交人" min-width="110">
              <template slot-scope="scope">
                <span>{{(scope.row.committerColumbusUser&&scope.row.committerColumbusUserId) ? `${scope.row.committerColumbusUser}(${scope.row.committerColumbusUserId})` : scope.row.committerEmail}}</span>
              </template>
            </el-table-column>
            <el-table-column label="最后提交时间" min-width="110">
              <template slot-scope="scope">
                <span>{{scope.row.commitTime ? scope.row.commitTime.substring(0,16) : '---'}}</span>
              </template>
            </el-table-column>
            <el-table-column width="80" label="操作">
              <template slot-scope="scope">
                <span class="c-blue cp" @click="generateAppVersion(scope.row)">生成版本</span>
              </template>
            </el-table-column>
          </el-table>
          <div class="table_b_f_b">
            <el-pagination
              class="fr mr10"
              style="margin-top: 9px;"
              @size-change="handleBranchSizeChange"
              @current-change="handleBranchCurrentChange"
              :current-page="branchPageData.pageNum"
              :page-sizes="[10, 20, 50]"
              :page-size="branchPageData.pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="branchPageData.total"
              :pages="branchPageData.pages"
            ></el-pagination>
          </div>
        </div>


        <!-- ============================================ -->


        <div v-show="appType == 5" class="pb20" v-loading="table_loading" element-loading-text="拼命加载中">
          <el-button type="primary" class="fr mb10" @click="generateMultipleBranchVersion()">生成版本</el-button>
          <el-input @keyup.native="searchBranch(search)" @blur="searchBranch(search)" v-model="search"
                    style="width:280px;margin-top:5px;float:left" placeholder="请输入子应用ID搜索"></el-input>
          <el-table
            ref="branchTale"
            :border="true"
            :data="tableListNew.data"
            @select-all="selectAllEvent"
            @select='handleSelectionChange'>
            <el-table-column type="selection" width="50"></el-table-column>
            <el-table-column prop="subAppId" label="子应用ID" min-width="120"></el-table-column>
            <el-table-column prop="sourceRepo" label="源码仓库" min-width="200"></el-table-column>
            <el-table-column prop="sourceBranch" label="分支名称" min-width="110">
              <template slot-scope="scope">
                <el-select v-model="scope.row.branchBosid" placeholder="请选择" @change="branchBosidChange" filterable>
                  <el-option
                    v-for="item in scope.row.branchBos"
                    :key="item.sourceBranch"
                    :label="item.sourceBranch"
                    :value="item.commitIdWithIndex">
                  </el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column label="CommitId" min-width="160">
              <template slot-scope="scope">
                <el-input contenteditable="plaintext-only" style="min-height:28px;"
                          v-model="scope.row.branchBosidCommitId"></el-input>
              </template>
            </el-table-column>
            <el-table-column label="提交日志" min-width="200">
              <template slot-scope="scope">
                <span style="min-height:28px; white-space:nowrap; text-overflow:ellipsis; overflow:hidden;"
                  onMouseEnter="this.style.whiteSpace='normal'"
                  onmouseleave="this.style.whiteSpace='nowrap'">
                  {{scope.row.branchBoCommitMsg}}

                </span>
              </template>
            </el-table-column>
          </el-table>
          <div class="table_b_f_b">
            <el-pagination
              class="fr mr10"
              style="margin-top: 9px;"
              @size-change="handleBranchSizeChange"
              @current-change="handleBranchCurrentChange"
              :current-page="branchPageData.pageNum"
              :page-sizes="[10, 20, 50]"
              :page-size="branchPageData.pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="branchPageData.total"
              :pages="branchPageData.pages"
            ></el-pagination>
          </div>
        </div>


        <!--版本列表-->
        <div class="table-box-solid" element-loading-text="拼命加载中">
          <div style="width:100%;" v-if="tableListCommitType == 5">
            <div style="height:30px;margin-bottom:5px;">
              <h4 style="margin-block-start: 0.33em;
                        margin-block-end: 0.33em;
                        display: inline-block;">版本列表
                <el-input @input="doFilterKeyword" v-model="filterKeyword"
                          style="width:160px;margin-left:20px;" placeholder="输入关键字过滤"></el-input>
              </h4>
              <el-select v-model="selectPipelineUuid" placeholder="请选择流水线过滤" @change="doFilterKeyword">
                <el-option label="全部" value=""></el-option>
                <el-option
                  v-for="item in versionPipelineLst"
                  :key="item.pipelineUuid"
                  :label="item.pipelineName"
                  :value="item.pipelineUuid">
                </el-option>
              </el-select>
              <el-button type="primary" @click="manualUploadBtn()" class="fr ml10" v-if="manualUpload == 1">手工上传
              </el-button>
              <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2,appId)"
                         @click="passEnvClick('test')" class="fr mr10">测试环境
              </el-button>
              <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2,appId)"
                         @click="passEnvClick('dev')" class="fr mr10">开发环境
              </el-button>
              <el-button type="primary" @click="getAppVersionByEnv" class="fr">刷新</el-button>
            </div>

            <el-tabs v-model="tabListId" class="el-tabs-wai" @tab-click="getAppVersionByEnv" type="border-card">

              <el-tab-pane v-for="tab in tabList" :key="tab.id+''" :label="tab.tagName" :name="tab.id+''">
                <div class="table-box">
                  <div class="table-box-top">
                    <el-table
                      :class="{'el-table-left-none':tableListCommit.list.length == 0}"
                      :border="true"
                      :data="tableListCommit.list">
                      <el-table-column label="版本名称" min-width="200">
                        <template slot-scope="scope">
                          <span v-if="(scope.row.pipelineStageRunningInfoBos.length == 0 || scope.row.pipelineStageRunningInfoBos == null)">
                            {{scope.row.versionName}}
                          </span>
                          <span v-if="(scope.row.pipelineStageRunningInfoBos.length != 0 && scope.row.pipelineStageRunningInfoBos != null)"
                            :class="{'c-blue':scope.row.pipelineStageRunningInfoBos.length != 0,'cp':scope.row.pipelineStageRunningInfoBos.length != 0}"
                            @click="showVersionPipeline(scope.row.pipelineWorkflowId)">{{scope.row.versionName}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="pkgStatus" label="版本状态" min-width="150">
                        <template slot-scope="scope">
                          <span class="cp" v-for="(item,index) in scope.row.pipelineStageRunningInfoBos" :key="item.id"
                                @click="showVersionPipeline(scope.row.pipelineWorkflowId)">
                            <i class="iconfont" :class="getClassByRunningStatus(item.stageRunningStatus)"></i>
                            <i class="el-icon-more" v-if="scope.row.pipelineStageRunningInfoBos.length-1 != index"></i>
                          </span>
                          <span class="c-blue cp"
                                v-if="(scope.row.pipelineStageRunningInfoBos.length == 0 || scope.row.pipelineStageRunningInfoBos == null)&& scope.row.versionType != 2 && scope.row.pkgStatus==4"
                                @click="passTestBtn(scope.row)">{{scope.row.versionType === 0 ? '提测' : '测试通过'}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="versionDesc" label="版本描述" min-width="300"></el-table-column>
                      <el-table-column prop="sourceBranch" label="分支名称" width="100">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="examineBtn(scope.row.extendData)">查看</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="版本类型" width="80">
                        <template slot-scope="scope">
                          <span>{{versionType_china[scope.row.versionType]}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="createUserName" label="创建者" width="100"></el-table-column>
                      <el-table-column label="创建时间" width="160">
                        <template slot-scope="scope">
                          <span>{{scope.row.createTime?scope.row.createTime:'-------'}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="打包状态" width="80">
                        <template slot-scope="scope">
                          <span
                            :class="{'c-red':scope.row.pkgStatus == 3}">{{PKG_STATUS[scope.row.pkgStatus]}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="上传详情" width="80">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="checkUpload(scope.row.versionId, 0)">查看</span>
                          <span class="c-blue cp" v-if="scope.row.pkgStatus == 4" @click="btnUrl(scope.row)">下载</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="操作" width="50">
                        <template slot-scope="scope">
                          <span class="c-blue cp" v-show="authFunction('FUNC_APP_DEL_APP', 2, appId)" @click="deleteAppVersion(scope.row.versionId)">删除</span>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>

          </div>

          <div style="width:100%;" v-if="tableListCommitType != 5">
            <div style="height:30px;margin-bottom:5px;">
              <h4 style="margin-block-start: 0.33em;
                        margin-block-end: 0.33em;
                        display: inline-block;">版本列表
                <el-input @input="doFilterKeyword" v-model="filterKeyword"
                          style="width:160px;margin-left:20px;" placeholder="输入关键字过滤"></el-input>
              </h4>
              <el-select v-model="selectPipelineUuid" placeholder="请选择流水线过滤" @change="doFilterKeyword">
                <el-option label="全部" value=""></el-option>
                <el-option
                  v-for="item in versionPipelineLst"
                  :key="item.pipelineUuid"
                  :label="item.pipelineName"
                  :value="item.pipelineUuid">
                </el-option>
              </el-select>
              <el-button type="primary" @click="manualUploadBtn()" class="fr ml10" v-if="manualUpload == 1">手工上传
              </el-button>
              <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2,appId)"
                         @click="passEnvClick('test',tableList.appCode)" class="fr mr10">测试环境
              </el-button>
              <el-button type="primary" v-show="authFunction('FUNC_APP_VER_LIST', 2,appId)"
                         @click="passEnvClick('dev',tableList.appCode)" class="fr mr10">开发环境
              </el-button>
              <el-button type="primary" @click="getAppVersionByEnv" class="fr">刷新</el-button>

            </div>

            <el-tabs v-model="tabListId" class="el-tabs-wai" @tab-click="getAppVersionByEnv" type="border-card">

              <el-tab-pane v-for="tab in tabList" :key="tab.id+''" :label="tab.tagName" :name="tab.id+''">
                <div class="table-box">
                  <div class="table-box-top">
                    <el-table
                      :class="{'el-table-left-none':tableListCommit.list.length == 0}"
                      :border="true"
                      :data="tableListCommit.list">
                      <el-table-column label="版本名称" min-width="200">
                        <template slot-scope="scope">
                          <span v-if="(scope.row.pipelineStageRunningInfoBos.length == 0 || scope.row.pipelineStageRunningInfoBos == null)">
                            {{scope.row.versionName}}
                          </span>
                  <span v-if="(scope.row.pipelineStageRunningInfoBos.length != 0 && scope.row.pipelineStageRunningInfoBos != null)"
                    :class="{'c-blue':scope.row.pipelineStageRunningInfoBos.length != 0,'cp':scope.row.pipelineStageRunningInfoBos.length != 0}"
                    @click="showVersionPipeline(scope.row.pipelineWorkflowId)">{{scope.row.versionName}}</span>
                        </template>
                      </el-table-column>

                      <el-table-column prop="pkgStatus" label="版本状态" min-width="150">
                        <template slot-scope="scope">
                  <span class="cp" v-for="(item,index ) in scope.row.pipelineStageRunningInfoBos" :key="item.id"
                        @click="showVersionPipeline(scope.row.pipelineWorkflowId)">
                    <i class="iconfont" :class="getClassByRunningStatus(item.stageRunningStatus)"
                       :title="item.name"></i>
                    <i class="iconfont icon-more" v-if="scope.row.pipelineStageRunningInfoBos.length-1 != index"></i>
                  </span>
                          <span class="c-blue cp"
                                v-if="(scope.row.pipelineStageRunningInfoBos.length == 0 || scope.row.pipelineStageRunningInfoBos == null)&& scope.row.versionType != 2 && scope.row.pkgStatus==4"
                                @click="passTestBtn(scope.row)">{{scope.row.versionType === 0 ? '提测' : '测试通过'}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="versionDesc" label="版本描述" min-width="300"></el-table-column>
                      <el-table-column prop="sourceBranch" label="分支名称" min-width="100"></el-table-column>
                      <el-table-column label="commitId">
                        <template slot-scope="scope">{{scope.row.commitId?scope.row.commitId.substring(0,8):'-'}}
                        </template>
                      </el-table-column>
                      <el-table-column label="版本类型"
                                       prop="versionType"
                                       width="80">
                        <template slot-scope="scope">
                          <span>{{versionType_china[scope.row.versionType]}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column prop="createUserName" label="创建者" width="100"></el-table-column>
                      <el-table-column label="创建时间" width="160">
                        <template slot-scope="scope">
                          <span>{{scope.row.createTime?scope.row.createTime:'-------'}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="打包状态" width="80">
                        <template slot-scope="scope">
                          <span
                            :class="{'c-red':scope.row.pkgStatus == 3}">{{PKG_STATUS[scope.row.pkgStatus]}}</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="上传详情" width="80">
                        <template slot-scope="scope">
                          <span class="c-blue cp" @click="checkUpload(scope.row.versionId, 0)">查看</span>
                          <span class="c-blue cp" v-if="scope.row.pkgStatus == 4" @click="btnUrl(scope.row)">下载</span>
                        </template>
                      </el-table-column>
                      <el-table-column label="操作" width="50">
                        <template slot-scope="scope">
                          <span class="c-blue cp" v-show="authFunction('FUNC_APP_DEL_APP', 2, appId)" @click="deleteAppVersion(scope.row.versionId)">删除</span>
                        </template>
                      </el-table-column>
                    </el-table>

                  </div>
                </div>
              </el-tab-pane>
            </el-tabs>

          </div>
          <div class="table_b_f_b">
            <el-pagination
              v-show="tableListCommit.list.length!=0"
              class="fr mr10"
              style="margin-top: 9px;"
              @size-change="handleSizeChange"
              @current-change="handleCurrentChange"
              :current-page="tableListCommit.pageNum"
              :page-sizes="[10, 20, 30]"
              :page-size="tableListCommit.pageSize"
              layout="total, sizes, prev, pager, next, jumper"
              :total="tableListCommit.total"
            ></el-pagination>
          </div>
        </div>
      </div>
    </div>

    <!-- 查看分支名称 -->
    <el-dialog title='查看分支' :visible.sync="dialogVisible" class="el-dialog-880w"
               :before-close="handleClose" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-table
          :data="examinelist">
          <el-table-column prop="subAppId" label="子应用ID" min-width="160"></el-table-column>
          <el-table-column prop="gitRepoUrl" label="源码仓库" min-width="220"></el-table-column>
          <el-table-column prop="branch" label="分支名称" min-width="160"></el-table-column>
          <el-table-column prop="commitId" label="CommitId" min-width="120"></el-table-column>
        </el-table>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button @click="handleClose">关闭</el-button>
      </span>
    </el-dialog>

    <!-- 非多仓库生成版本弹窗 -->
    <el-dialog title='生成版本' :visible.sync="dialogVisible_master1" class="el-dialog-640w"
               :before-close="handleClose_master1" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="packInfo" ref="packInfo" label-width="100px">
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
            <el-col :span='24'>
              <el-form-item class='mb15' label="版本名称" label-width="100px" prop="verName" :rules="[
                            { required: true, message: '版本不能为空' }
                        ]">
                <el-input placeholder="请输入内容" v-model="packInfo.verName" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24'>
              <el-form-item class='mb15' label="版本分支" label-width="100px" prop="branch" :rules="[
                            { required: true, message: '版本分支不能为空' }
                        ]">
                <el-input placeholder="请输入内容" v-model="packInfo.branch" disabled></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24'>
              <el-form-item class="mb20" label="Commitld" label-width="100px" prop="commitId"
                            :rules="[
                            { required: true, message: 'Commitld不能为空' }
                        ]">
                <el-input placeholder="请输入内容" v-model="packInfo.commitId" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24'>
              <el-form-item class='mb15' label="版本描述" label-width="100px" prop="verDesc" :rules="[
                            { required: true, message: '版本描述不能为空' }
                        ]">
                <el-input placeholder="请输入内容" v-model="packInfo.verDesc" type="textarea" :rows="10"
                          clearable></el-input>
              </el-form-item>
            </el-col>

            <el-col :span='24'>
              <el-form-item class='mb15' label="版本流水线" prop='pipelineId' label-width="100px" :rules="[
                            { required: true, message: '请选择流水线生成版本' }
                        ]">
                <el-select v-model="pkgPipelineId" clearable placeholder="请选择版本流水线"
                           @change="handlePackInfoSelectChange()" style="width:100%">
                  <el-option-group
                    v-for="group in avaliablePkgPipelineListOptions"
                    :key="group.label"
                    :label="group.label">

                    <el-option
                      v-for="item in group.options"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                      :disabled="!item.pkgable">
                      <span style="float: left">{{ item.label }}</span>
                      <span style="float: right; color: #8492a6; font-size: 13px">{{ (item.defaultPipeline && '默认') || '' }}</span>
                    </el-option>
                  </el-option-group>
                </el-select>
              </el-form-item>
            </el-col>

            <!-- 如果对应的构建任务设置了“构建参数”， 则展示给用户选择-->
            <el-col :span='24'
                    v-if="appType != 5 && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:100%;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="handleClose_master1">取消</el-button>
                <el-button type="primary" @click="packBtn_master1" :loading='packBtn_master1_loading'>确定</el-button>
            </span>
    </el-dialog>

    <!-- 多仓库生成版本弹窗 -->
    <el-dialog title='生成版本' :visible.sync="dialogVisible_master2" class="el-dialog-640w"
               :before-close="handleClose_master2" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <el-form :model="packInfo2" ref="packInfo2" label-width="100px">
          <el-row :gutter="10" class="mt15" style="margin-left:0;margin-right:0;">
            <el-col :span='24'>
              <el-form-item class="mt15" label="版本名称" label-width="100px" prop="verName"
                            :rules="[
                                { required: true, message: '版本名称不能为空' }
                            ]">
                <el-input placeholder="请输入内容" v-model="packInfo2.verName" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24'>
              <el-form-item class='mb15' label="版本描述" label-width="100px" prop="verDesc" :rules="[
                                { required: true, message: '版本描述不能为空' }
                            ]">
                <el-input placeholder="请输入内容" v-model="packInfo2.verDesc" type="textarea" :rows="8"
                          clearable></el-input>
              </el-form-item>
            </el-col>

            <el-col :span='24'>
              <el-form-item class='mb15' label="版本流水线" prop="pipelineId" label-width="100px" :rules="[
                            { required: true, message: '请选择流水线生成版本' }
                        ]">
                <el-select v-model="pkgPipelineId" clearable placeholder="请选择版本流水线"
                           @change="handlePackInfo2SelectChange()" style="width:100%">
                  <el-option-group
                    v-for="group in avaliablePkgPipelineListOptions"
                    :key="group.label"
                    :label="group.label">

                    <el-option
                      v-for="item in group.options"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                      :disabled="!item.pkgable">
                      <span style="float: left">{{ item.label }}</span>
                      <span style="float: right; color: #8492a6; font-size: 13px">{{ (item.defaultPipeline && '默认') || '' }}</span>
                    </el-option>
                  </el-option-group>
                </el-select>
              </el-form-item>
            </el-col>

            <!-- 如果对应的构建任务设置了“构建参数”， 则展示给用户选择-->
            <el-col :span='24'
                    v-if="appType == 5 && buildTaskVaiableList != null && buildTaskVaiableList.length > 0">
              <el-form-item class='mb15' :label="item.variable" label-width="100px" :key="item.variable"
                            v-for="(item,index) in buildTaskVaiableList">
                <el-autocomplete
                  class="inline-input"
                  v-model="item.currentOption"
                  placeholder="请输入内容"
                  style="width:100%;"
                  :fetch-suggestions="(queryString , cb)=>queryVariableSearch(queryString , cb , item.variable)"
                  :disabled="false"
                  @select="(selectData)=>handleOptionsSelect(selectData , item.currentOption)"
                >
                </el-autocomplete>
                {{item.desc}}
                <div v-if="item.currentOption == null || item.currentOption == ''" style="margin-top: 0px">
                  <span class="el-form-item__error">构建参数不能为空</span>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="handleClose_master2">取消</el-button>
                <el-button type="primary" @click="packBtn_master2" :loading='packBtn_master2_loading'>确定</el-button>
            </span>
    </el-dialog>

    <application-association :dialogVisible_correlation="dialogVisible_correlation" :handleClose_correlation="handleClose_correlation"
                             :modaltobody="modaltobody" :shadeBtn="shadeBtn" ref="applicationAssociationRef"></application-association>

    <!-- 仓库包上传详情 -->
    <el-dialog title='包上传详情' :visible.sync="dialogVisible_upload" class="el-dialog-1180w"
               :before-close="handleClose_upload" :modal-append-to-body="modaltobody" :close-on-click-modal='shadeBtn'>
      <div class="form-iterm-box">
        <div style="background:rgb(230, 233, 239);;padding-top:5px;">
          <div>
            <span class="fl mt5 ml5">包存储信息</span>
            <el-button type="primary" class="fr mr5 mb5" @click="renovationBtn(1)">刷新</el-button>
          </div>
          <el-table
            :data="testUpload_list">
            <el-table-column prop="versionName" label="应用版本名称" min-width="150"></el-table-column>
            <el-table-column prop="idcName" label="机房名称" min-width="100"></el-table-column>
            <el-table-column prop="uploadEnv" label="上传环境" min-width="80"></el-table-column>
            <el-table-column label="上传状态" min-width="120">
              <template slot-scope="scope">
                <span>{{uploadStatusInfo[scope.row.uploadStatus]}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="uploadMsg" label="上传信息" min-width="120"></el-table-column>
            <el-table-column prop="startTime" label="开始时间" min-width="140"></el-table-column>
            <el-table-column label="结束时间" min-width="140">
              <template slot-scope="scope">
                <span>{{(scope.row.uploadStatus == 2 || scope.row.uploadStatus == 3) ? scope.row.endTime : ""}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="gitRepoUrl" label="操作" min-width="80">
              <template slot-scope="scope" v-if="scope.row.uploadStatus == '3'">
                <span class="c-blue cp" @click="reupload(scope.row, 1)">重新上传</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div class="form-iterm-box" v-if="imageUploadHarbor">
        <div style="background:rgb(230, 233, 239);;padding-top:5px;">
          <div>
            <span class="fl mt5 ml5">镜像存储信息</span>
            <el-button type="primary" class="fr mr5 mb5" @click="renovationBtn(2)">刷新</el-button>
          </div>
          <el-table
            :data="imageUploadDetail">
            <el-table-column prop="versionName" label="应用版本名称" min-width="150"></el-table-column>
            <el-table-column prop="uploadEnv" label="上传环境" min-width="80">正式仓库</el-table-column>
            <el-table-column label="上传状态" min-width="120">
              <template slot-scope="scope">
                <span>{{uploadStatusInfo[scope.row.imageUploadStatus]}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="imageUploadMsg" label="上传信息" min-width="120"></el-table-column>
            <el-table-column prop="gitRepoUrl" label="操作" min-width="80">
              <template slot-scope="scope" v-if="scope.row.imageUploadStatus == '3'">
                <span class="c-blue cp" @click="reupload(scope.row, 2)">重新上传</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
                <el-button @click="handleClose_upload">关闭</el-button>
            </span>
    </el-dialog>

    <!-- 手工上传 -->
    <el-dialog title='上传版本' :visible.sync="dialogVisible_hand_upload" class="el-dialog-640w"
               :before-close="handleClose_hand_upload" :modal-append-to-body="modaltobody"
               :close-on-click-modal='shadeBtn' :show-close="false">
      <div class="form-iterm-box" v-loading="file_manual_uploading" element-loading-text="拼命上传文件中">
        <el-form :model="correlationInfo_hand" ref="correlationInfo_hand">
          <el-row :gutter="10">
            <el-col :span='24'>
              <el-form-item label="版本名称" label-width="100px" prop="verName"
                            :rules="[
                            { required: true, message: '版本名称不能为空' }
                        ]">
                <el-input placeholder="请输入内容" v-model="correlationInfo_hand.verName" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24'>
              <el-form-item label="版本描述" label-width="100px" prop="verDesc" :rules="[
                            { required: true, message: '版本描述不能为空' }
                        ]">
                <el-input placeholder="请输入内容" type="textarea" :rows="5" v-model="correlationInfo_hand.verDesc"
                          clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span='24'>
              <el-form-item label="docker镜像" label-width="100px" prop="imageTar" :rules="[
                            { required: true, message: 'docker镜像不能为空' }
                        ]">
                <el-radio-group v-model="correlationInfo_hand.imageTar">
                  <el-tooltip placement="bottom-start">
                    <div slot="content">Docker镜像文件名必须满足规范 ${image name}_${tag}.tar.gz</div>
                    <el-radio :label="true">是</el-radio>
                  </el-tooltip>
                  <el-radio :label="false">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
            <el-col :span="24">
              <el-form-item label-width="100px" label="版本文件">
                <el-upload
                  class="upload-demo"
                  ref="upload"
                  action=""
                  :on-preview="handlePreview"
                  :on-remove="handleRemove"
                  :on-exceed="handleExceed"
                  :file-list="correlationInfo_hand.fileList"
                  :limit="1"
                  :auto-upload="false">
                  <el-button slot="trigger" size="small" type="primary">选取文件</el-button>
                </el-upload>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
          <el-button @click="handleClose_hand_upload" :loading="file_manual_uploading">关闭</el-button>
          <el-button type="primary" @click="submit_hand_upload" :loading="file_manual_uploading">保存</el-button>
      </span>
    </el-dialog>

    <app-version-pipeline ref="appVersionPipeline" @refreshVersion="getAppVersionByEnv()"></app-version-pipeline>
  </div>
</template>

<script>
  import AppVersionPipeline from '@/components/biz/app/appVersionPipeline'
  import ApplicationAssociation from '@/components/commonComponents/ApplicationAssociation'

  export default {
    name: "appVersions",
    data() {
      return {
        PKG_STATUS: GLOBAL_CONST.PKG_STATUS,
        imageUploadHarbor: false,
        imageUploadDetail: [],
        bizId: 0,
        appId: 0,
        appCode: "",
        search: '',
        tempList: [],
        branchPageData: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pages: 0
        },
        appType: 0,
        active: 0,
        tableListNew: {
          appType: 0,
          data: [],
        },
        tableList: {
          appType: 0,
          data: [],
        },
        totalSet: [],
        tableListCommit: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          list: []
        },
        tableListCommitType: '',
        table_loading: false,
        branchBosid: '',
        examinelist: [],
        shadeBtn: false,
        modaltobody: false,
        dialogVisible: false,
        dialogVisible_master1: false,
        dialogVisible_master2: false,
        packBtn_master1_loading: false,
        packBtn_master2_loading: false,
        packInfo: {},
        packInfo2: {
          verDesc: '',
          verName: ''
        },
        versionIdInfo: null,
        gitAddress: '',
        versionHandle: '',

        dialogVisible_correlation: false,

        appBranchInfo: [],
        dialogVisible_upload: false,
        testUpload_list: [],
        uploadStatusInfo: {
          '0': '新建',
          '1': '上传中',
          '2': '上传成功',
          '3': '上传失败'
        },
        dialogVisible_hand_upload: false,
        file_manual_uploading: false,
        correlationInfo_hand: {
          verName: '',
          verDesc: '',
          imageTar: false,
          fileList: [],
        },
        verNamevip1: '',   //临时存贮版本名称
        verNamevip2: '',   //临时存贮版本名称

        pkgPipelineId: '',
        avaliablePkgPipelineListOptions: [
          {
            label: "版本流水线",
            options: [],
          }
        ],
        versionPipelineLst: [],
        selectPipelineUuid: '',
        buildTaskVaiableList: [],
        filterKeyword: '',
        manualUpload: '',   //判断手动上传是否展示
        verName_vip: '',   //手工上传
        versionType_china: {
          '0': '开发版本',
          '1': '测试版本',
          '2': '正式版本'
        },
        versionTypes: [],
        hiddenSelectShow: false,
        hiddenSelectShowText: false,
        tabList: [{
          id: -1,
          tagName: '全部版本',
        }, {
          id: 0,
          tagName: '开发版本',
        }, {
          id: 1,
          tagName: '测试版本',
        }, {
          id: 2,
          tagName: '正式版本',
        }],
        tabListId: -1 + '',
        originalWorkflowId: ''
      };
    },

    mounted() {
      this.appId = this.getUrlAppId();
      this.bizId = this.getUrlBizId();
      this.originalWorkflowId = this.getUrlWorkflowId();
      this.getBranchList();
      this.getAppVersionByEnv();
      this.getCurrentAppCode();
      this.initVerSelectPipelineLst();
      if(this.originalWorkflowId){
        this.showVersionPipeline(this.originalWorkflowId);
      }
    },

    methods: {
      deleteAppVersion(val){
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.appdate.deleteVersion, {appId: this.appId, versionId: val}).then(res => {
            if(res.status === 200){
              this.$message({
                message: '删除成功',
                type: 'success'
              });
              this.refreshVersionList();
            }else {
              this.$message({
                message: '删除失败',
                type: 'error'
              });
            }
          }).catch((err) => {
            this.$message({
              message: '删除失败',
              type: 'error'
            });
          })
        }).catch(() => {
        });
      },
      getCurrentAppCode(){
        $http.get($http.api.app.simpleInfo).then(res => {
          if(res.status == 200){
            this.appCode = res.data.appCode;
          }
        }).catch((err) => {

        })
      },
      doFilterKeyword(){
        this.getAppVersionByEnv();
      },
      passEnvClick(env) {
        $http.get($http.api.deploy_note.getPaasServerUrl, {env: env}).then((res) => {
          let url = res.data + "/appmanage/instanceRedirect?appId=" + this.appCode;
          window.open(url, "_blank");
        });
      },

      getAppVersionByEnv() {
        this.versionTypes = [];
        if (this.tabListId === (-1 + '')) {
          this.refreshVersionList();
        } else {
          this.versionTypes.push(this.tabListId + '');
          this.versionTypeBtn();
        }
      },

      branchBosidChange(val) {
        let arr = val.split(",");
        let commitId = arr[0];
        let sourceBranch = arr[1];
        let indexStr = arr[2];
        let index = parseInt(indexStr);
        let data1 = this.tableList.data;
        let item = data1[index];
        if (item) {
          item.branchBosidCommitId = arr[0]

          //cascade update commit msg
          item.branchBoCommitMsg = "";
          item.branchBos.some((value, index) => {
            if(value.sourceBranch == sourceBranch) {
              item.branchBoCommitMsg = value.commitMsg;
              return true;
            }
          })
        }
      },

      fakePage(num, size, keyWord, appType) {
        let allList = this.tableList.data;
        let tempList = [];
        let returnList = [];
        if (appType != 5) {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.name.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        } else {
          if (allList && allList.length != 0) {
            if (keyWord && keyWord.trim() != '') {
              allList.forEach(item => {
                if (item.subAppId.toLowerCase().indexOf(keyWord.toLowerCase()) != -1) {
                  tempList.push(item);
                }
              })
            } else {
              tempList = allList;
            }
            this.tempList = tempList;
            let start = size * (num - 1);
            let end = size * num;
            if (start < 0) {
              start = 0;
            }
            if (start > tempList.length) {
              start = tempList.length - 1;
            }
            if (end > tempList.length) {
              end = tempList.length;
            }
            for (let i = start; i < end; i++) {
              returnList.push(tempList[i]);
            }
            this.tableListNew.data = returnList;
          }
          this.branchPageData.total = tempList.length;
          this.branchPageData.pages = Math.ceil(tempList.length / this.branchPageData.pageSize);
        }
        this.$nextTick(() => {
          let tableListNew = this.tableListNew;
          tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale&&branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },

      handleBranchSizeChange(val) {
        this.branchPageData.pageSize = val;
        this.fakePage(this.branchPageData.pageNum, val, this.search, this.appType);
      },

      handleBranchCurrentChange(val) {
        this.branchPageData.pageNum = val;
        this.fakePage(val, this.branchPageData.pageSize, this.search, this.appType);
      },

      searchBranch(keyWord) {
        this.fakePage(this.branchPageData.pageNum, this.branchPageData.pageSize, keyWord, this.appType);
      },

      //获取分支列表
      getBranchList() {
        this.table_loading = true;
        let params = {appId: this.appId};
        $http.get($http.api.appdate.appBranchList, params).then((res) => {
          if (res.status == 200) {
            this.appType = res.data.appType;
            if (res.data.appType != 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                if (a.name == 'master' && b.name != 'master') {
                  return -1;
                } else if (a.name != 'master' && b.name == 'master') {
                  return 1;
                } else if (!a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return -1;
                } else if (a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return 1;
                } else if (!a.name.startsWith('tags/') && !b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                } else if (a.name.startsWith('tags/') && b.name.startsWith('tags/')) {
                  return a.name.localeCompare(b.name);
                }
              })
              this.tableList = res.data;

              //data替换为分支名称排序后的
              this.tableList.data = data;
              this.appBranchInfo = this.tableList.data.concat([]);
              this.handleBranchSizeChange(this.branchPageData.pageSize);
              this.gitAddress = res.data.sourceRepo;
            } else if (res.data.appType == 5) {
              let data = res.data.data;
              data.sort((a, b) => {
                return a.subAppId.localeCompare(b.subAppId);
              })
              res.data.data.forEach((subApp, index_i) => {
                if (subApp.branchBos.length > 0) {
                  subApp.branchBos.forEach((oneBranch, index) => {
                    if (oneBranch.sourceBranch == 'master') {
                      subApp.branchBosidCommitId = oneBranch.commitId;
                      subApp.branchBosid = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                      subApp.branchBoCommitMsg = oneBranch.commitMsg;
                    }
                    oneBranch.commitIdWithIndex = oneBranch.commitId + "," + oneBranch.sourceBranch + ',' + index_i;
                  })
                }
              })
              this.tableList = res.data;
              this.tableList.data = data;
              this.handleBranchSizeChange(this.branchPageData.pageSize);
            }
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
          this.table_loading = false;
        }).catch(_ => {
          this.table_loading = false;
        });
      },

      showApplicationAssociation(bizId, appId) {
        this.dialogVisible_correlation = true;
        if(this.$refs.applicationAssociationRef) {
          this.$refs.applicationAssociationRef.init(bizId, appId)
        }
      },

      handleClose_correlation() {
        this.dialogVisible_correlation = false;
      },

      //手工上传
      manualUploadBtn() {
        let date = new Date();
        this.verName_vip = this.appCode + '_' + this.formatDate(date, 'yyyyMMddhhmmss');
        this.correlationInfo_hand.verName = this.appCode + '_' + this.formatDate(date, 'yyyyMMddhhmmss');
        this.dialogVisible_hand_upload = true;
      },

      //关闭
      handleClose_hand_upload() {
        this.$refs['correlationInfo_hand'].resetFields();
        this.$refs.upload.$data.uploadFiles.length = 0;
        this.dialogVisible_hand_upload = false;
      },

      handlePreview(file) {

      },
      handleRemove(file, fileList) {

      },
      handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
      },

      //手工上传确定按钮
      submit_hand_upload() {
        this.$refs['correlationInfo_hand'].validate((valid) => {
          if (valid) {
            if (this.verName_vip != this.correlationInfo_hand.verName) {
              // 查询生成版本设置的版本名称是否重复
              $http.get($http.api.appdate.api_app_version_name_conflict_check, {
                appId: this.appId,
                versionName: this.correlationInfo_hand.verName
              }).then(res => {
                if (res.status == 200) {
                  if (res.data == true) {
                    this.$message({
                      message: '版本名称重复',
                      type: 'warning'
                    })
                    return;
                  } else {
                    this.hand_UPload();
                  }
                }
              });
            } else {
              this.hand_UPload();
            }

          }
        });


      },

      //手工上传的方法
      hand_UPload() {
        let uploadform = this.$refs.upload.$data.uploadFiles;
        if (!uploadform || uploadform.length == 0) {
          this.$message({
            message: '请选择文件',
            type: 'warning'
          });
          return;
        }
        this.file_manual_uploading = true;
        let formData = new FormData();
        formData.append("appId", this.appId);
        formData.append("bizId", this.bizId);
        formData.append("verName", this.correlationInfo_hand.verName);
        formData.append("verDesc", this.correlationInfo_hand.verDesc);
        formData.append("imageTar", this.correlationInfo_hand.imageTar);
        formData.append("file", uploadform[0].raw);
        $http.post($http.api.appdate.api_app_version_manual_upload, formData).then(res => {
          if (res.status == 200) {
            this.$message({
              message: '上传成功',
              type: "success"
            });
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
          this.file_manual_uploading = false;
          this.handleClose_hand_upload();
          this.refreshVersionList();
        });
      },

      //仓库版本查看上传详情
      checkUpload(val, type) {
        this.versionId = val;
        this.dialogVisible_upload = true;
        $http.get($http.api.appdate.api_app_version_upload_detail_list, {versionId: val}).then(res => {
          if (res.status == 200) {
            if(type === 0 || type === 1){ //type 为0 则全部更新 1 更新包存储信息 2 更新镜像上传信息
              this.testUpload_list = res.data;
            }
            if(type === 0 || type === 2){
              this.imageUploadDetail = [];
              res.data.forEach(item => {
                if(item.imageUploadStatus !== -1) {
                  this.imageUploadHarbor = true;
                  this.imageUploadDetail.unshift(item);
                }
              })
            }
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      //仓库版本查看详情重新上传
      reupload(val, type) {
        $http.post($http.api.appdate.api_app_version_upload_detail_re_upload, {
          versionId: val.versionId,
          id: val.id,
          type: type
        }).then(res => {
          if (res.status == 200) {
            this.checkUpload(val.versionId, type);
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },

      //刷新包存储信息
      renovationBtn(type) {
        this.checkUpload(this.versionId, type);
      },


      //非多仓库版本查看上传详情关闭弹窗
      handleClose_upload() {
        this.dialogVisible_upload = false;
      },


      //获取版本列表
      getVersionList(val, pkgWorkflowId) {
        let params = val;
        $http.get($http.api.appdate.apiappversionlist, params).then(res => {
          if (res != undefined) {
            this.tableListCommit = res.data.data;
            this.tableListCommitType = res.data.appType;
            this.manualUpload = res.data.manualUpload;

            if (pkgWorkflowId) {
              this.$nextTick(() => {
                this.showVersionPipeline(pkgWorkflowId)
              })
            }
          }
        });
      },

      getVersionHandle(versionType) {
        return versionType === 0 ? '提测' : '测试通过'
      },

      //分页
      handleSizeChange(val) {
        this.getVersionList({
          appId: this.appId,
          pageNum: this.tableListCommit.pageNum,
          pageSize: val,
          versionTypes: this.versionTypes.toString(),
          keyword: this.filterKeyword,
          uuid: this.selectPipelineUuid
        });
      },

      handleCurrentChange(val) {
        this.getVersionList({
          appId: this.appId,
          pageNum: val,
          pageSize: this.tableListCommit.pageSize,
          versionTypes: this.versionTypes.toString(),
          keyword: this.filterKeyword,
          uuid: this.selectPipelineUuid
        });
      },

      //查看按钮
      examineBtn(val) {
        let extraObjs = JSON.parse(val);
        extraObjs.forEach(item => {
          let commitId = item.commitId;
          let shotCommitId = commitId.substr(0, 8);
          item.commitId = shotCommitId;
        })
        this.examinelist = extraObjs;
        this.dialogVisible = true;
      },

      //用版本类型对数据进行筛选
      versionTypeBtn() {
        this.getVersionList({
          pageNum: this.tableListCommit.pageNum,
          pageSize: this.tableListCommit.pageSize,
          appId: this.appId,
          versionTypes: this.versionTypes.toString(),
          keyword: this.filterKeyword,
          uuid: this.selectPipelineUuid
        });

      },

      //刷新版本列表
      refreshVersionList() {
        this.getVersionList({
          pageNum: this.tableListCommit.pageNum,
          pageSize: this.tableListCommit.pageSize,
          appId: this.appId,
          keyword: this.filterKeyword,
          uuid: this.selectPipelineUuid
        });
      },

      //点击版本名称下载
      btnUrl(val) {
        if (val.pkgStatus == 4) {
          $http.get($http.api.appdate.api_app_version_download, {versionId: val.versionId}).then(res => {
            if (res.status == 200) {
              window.location.href = res.data.downloadUrl;
            } else {
              this.$message({
                message: res.msg,
                type: 'warning'
              })
            }

          });
        }
      },

      //版本状态测试通过按钮
      passTestBtn(val) {
        let formData = new FormData();
        formData.append("versionId", val.versionId);
        formData.append("versionType", val.versionType);
        $http.post($http.api.appdate.api_app_version_passtest, formData).then(res => {
          if (res.status == 200) {
            this.$message({
              message: val.versionType===0 ? '版本提测成功' : '版本测试通过',
              type: 'success'
            })
            this.getAppVersionByEnv();
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }

        });
      },

      //关闭弹窗
      handleClose() {
        this.dialogVisible = false;
      },


      //非多仓库生成版本
      generateAppVersion(val) {
        this.dialogVisible_master1 = true;
        let date = new Date();
        this.packInfo.branch = val.name;

        $http.get($http.api.appdate.getAppVersionName, {appId: this.appId, branch: this.packInfo.branch}).then(res => {
          if (res.status == 200) {
            let verName = res.data;
            this.$set(this.packInfo, 'verName', verName);
          }
        });

        // 获取分支最新的commit信息
        $http.get($http.api.appdate.appBranchLatestCommit, {
          appId: this.appId,
          branch: val.name
        }).then(res => {
          if (res.status == 200) {
            if (res.data != null) {
              this.$set(this.packInfo, "verDesc", res.data.message);
              this.$set(this.packInfo, "commitId", res.data.id);
            } else {
              this.$set(this.packInfo, "verDesc", val.commitMessage);
              this.$set(this.packInfo, "commitId", val.commitId);
            }
          }
        });

        this.getBranchList();

        this.initPkgPipelineList(false);
      },

      handlePackInfoSelectChange() {
        this.$set(this.packInfo, "pipelineId", this.pkgPipelineId);
        this.queryPipelineBuildTaskVars(this.pkgPipelineId);
      },

      handlePackInfo2SelectChange() {
        this.$set(this.packInfo2, "pipelineId", this.pkgPipelineId);
        this.queryPipelineBuildTaskVars(this.pkgPipelineId);
      },

      queryPipelineBuildTaskVars(pipelineId) {
        this.buildTaskVaiableList = [];
        $http.get($http.api.pipeline.buildTaskVars, {pipelineId: pipelineId}).then(response=>{
          if(response.status == 200) {
            if(response.data != null) {
              this.buildTaskVaiableList = response.data;
            }
          }
        });
      },

      initVerSelectPipelineLst(){
        $http.get($http.api.pipeline.pkgList, {appId: this.appId}).then(response => {
          if (response.status == 200) {
            if (response.data != null) {
              this.versionPipelineLst = response.data;
            }
          }
        });
      },

      //填充打包用的流水线列表
      initPkgPipelineList(isMultiple) {
        var firstGroupSize = this.avaliablePkgPipelineListOptions[0].options.length;
        this.avaliablePkgPipelineListOptions[0].options.splice(0, firstGroupSize);

        if (this.avaliablePkgPipelineListOptions[1] && Array.isArray(this.avaliablePkgPipelineListOptions[1].options)) {
          var secondGroupSize = this.avaliablePkgPipelineListOptions[1].options.length;
          this.avaliablePkgPipelineListOptions[1].options.splice(0, secondGroupSize);
        }

        $http.get($http.api.pipeline.pkgList, {appId: this.appId}).then(response => {
          if (response.status == 200) {
            if (response.data != null) {
              let pkgPipelineLst = response.data;
              let that = this;
              pkgPipelineLst.forEach((cur, index, arr) => {
                if (cur.pkgable) {
                  that.avaliablePkgPipelineListOptions[0].options.push({
                    value: cur.pipelineId,
                    label: cur.pipelineName,
                    pkgable: cur.pkgable,
                    defaultPipeline: cur.defaultPipeline
                  });
                } else {
                  if (!that.avaliablePkgPipelineListOptions[1]) {
                    that.avaliablePkgPipelineListOptions[1] = {label: "不可用流水线（无构建任务）", options: []};
                  }
                  that.avaliablePkgPipelineListOptions[1].options.push({
                    value: cur.pipelineId,
                    label: cur.pipelineName,
                    pkgable: cur.pkgable,
                    defaultPipeline: cur.defaultPipeline
                  });
                }
                if (cur.defaultPipeline && cur.pkgable) {
                  that.pkgPipelineId = cur.pipelineId;
                  this.queryPipelineBuildTaskVars(this.pkgPipelineId);
                }

              });

              if (!this.pkgPipelineId) {
                let firstPkgablePipelineInfo = this.avaliablePkgPipelineListOptions[0].options[0];
                if (firstPkgablePipelineInfo && firstPkgablePipelineInfo.pkgable) {
                  this.pkgPipelineId = firstPkgablePipelineInfo.value;
                  this.queryPipelineBuildTaskVars(this.pkgPipelineId);
                }
              }

              //维护这个主要是用户表单验证
              if (isMultiple) {
                this.$set(this.packInfo2, "pipelineId", this.pkgPipelineId);
              } else {
                this.$set(this.packInfo, "pipelineId", this.pkgPipelineId);
              }
            }
          }
        });
      },

      hasVariableBlank() {
        var hasVariableBlank = false;
        if(this.buildTaskVaiableList != null && this.buildTaskVaiableList.length > 0){
          this.buildTaskVaiableList.forEach(item=>{
            if(item.currentOption == null || item.currentOption == ""){
              hasVariableBlank = true;
            }
          });
        }
        return hasVariableBlank;
      },

      //非多仓库打包(确定按钮)
      packBtn_master1() {
        if(this.hasVariableBlank()){
          this.$message({
            showClose: true,
            message: '构建参数不能为空',
            type: 'warning'
          });
          return;
        }
        this.$refs['packInfo'].validate((valid) => {
          if (valid) {
            this.packBtn_master1_loading = true;
            if (this.verNamevip1 != this.packInfo.verName) {
              // 查询生成版本设置的版本名称是否重复
              $http.get($http.api.appdate.api_app_version_name_conflict_check, {
                appId: this.appId,
                versionName: this.packInfo.verName
              }).then(res => {
                if (res.status == 200) {
                  if (res.data == true) {
                    this.$message({
                      message: '版本名称重复',
                      type: 'warning'
                    })
                    return;
                  } else {
                    this.getpack1();
                  }
                }
              });
            } else {
              this.getpack1();
            }
            this.packBtn_master1_loading = false;
          }
        });
      },

      //非多仓库打包的方法
      getpack1() {
        let formData = new FormData();
        formData.append('verName', this.packInfo.verName);
        formData.append('appId', this.appId);
        formData.append('branch', this.packInfo.branch);
        formData.append('commitId', this.packInfo.commitId);
        formData.append('verDesc', this.packInfo.verDesc);
        formData.append('pipelineId', this.pkgPipelineId);
        formData.append("buildTaskVarsJsonStr", this.getBuildTaskVarsJson());
        $http.post($http.api.appdate.appVersionCreate_v2, formData).then(res => {
          if( res.status == 200 ){
            this.$message({
              message: '打包处理中......',
              type: "success"
            });
            let pkgWorkflowId = res.data;
            this.getVersionList({
              pageNum: 1,
              pageSize: this.tableListCommit.pageSize,
              appId: this.appId,
              keyword: this.filterKeyword,
              uuid: this.selectPipelineUuid
            }, pkgWorkflowId);
          }
        });
        this.packBtn_master1_loading = false;
        this.handleClose_master1();
      },

      getBuildTaskVarsJson() {
        let varsSelectedObj = {};
        this.buildTaskVaiableList.forEach(item => {
          varsSelectedObj[item.variable] = item.currentOption;
        });
        return JSON.stringify(varsSelectedObj);
      },

      //非多仓库关闭
      handleClose_master1() {
        this.$refs['packInfo'].resetFields();
        this.dialogVisible_master1 = false;
      },

      queryVariableSearch(queryString, cb , variable) {
        var restaurants = [];
        this.buildTaskVaiableList.forEach(item => {
          if(item.variable == variable){
            restaurants = item.options;
          }
        });
        var results = [];
        restaurants.forEach((item)=>{
          if(queryString == null || queryString == "" || item.toLowerCase().indexOf(queryString) == 0){
            results.push({value:item})
          }
        });
        cb(results);
      },
      handleOptionsSelect(selectData , currentOption){
        currentOption = selectData;
      },

      //多仓库生成版本
      generateMultipleBranchVersion() {
        $http.get($http.api.appdate.getAppVersionName, {appId: this.appId, branch: ""}).then(res => {
          if (res.status == 200) {
            let verName = res.data;
            this.$set(this.packInfo2, 'verName', verName);
            this.verNamevip2 = verName;
          }
        });

        this.initPkgPipelineList(true);

        this.dialogVisible_master2 = true;
        this.getBranchList();
      },

      //全选事件
      selectAllEvent(data) {
        if (data.length == 0) {
          this.totalSet = [];
        } else {
          this.totalSet = [];
          this.tempList.forEach(item => {
            this.totalSet.push(item);
          });
        }
        this.$nextTick(() => {
          this.tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            let t = this.totalSet.indexOf(item) != -1;
            branchTale&&branchTale.toggleRowSelection(item, t);
          })
        });
      },

      //表格勾选
      handleSelectionChange(val) {
        let dataList = this.tableListNew.data;
        dataList.forEach(item => {
          let index = this.totalSet.indexOf(item);
          if (index != -1) {
            this.totalSet.splice(index, 1)
          }
        });
        val.forEach(item => {
          this.totalSet.push(item);
        });
        this.$nextTick(() => {
          this.tableListNew.data.forEach((item, index) => {
            let branchTale = this.$refs.branchTale;
            branchTale&&branchTale.toggleRowSelection(item, this.totalSet.indexOf(item) != -1);
          })
        });
      },

      //多仓库打包
      packBtn_master2() {
        if(this.hasVariableBlank()){
          this.$message({
            showClose: true,
            message: '构建参数不能为空',
            type: 'warning'
          });
          return;
        }
        let totalSet = this.totalSet;
        this.$refs['packInfo2'].validate((valid) => {
          if (valid) {
            if (this.verNamevip2 != this.packInfo2.verName) {
              // 查询生成版本设置的版本名称是否重复
              $http.get($http.api.appdate.api_app_version_name_conflict_check, {
                appId: this.appId,
                versionName: this.packInfo2.verName
              }).then(res => {
                if (res.status == 200) {
                  if (res.data == true) {
                    this.$message({
                      message: '版本名称重复',
                      type: 'warning'
                    })
                    return;
                  } else {
                    this.getpack2();
                  }
                }
              });
            } else {
              this.getpack2();
            }
          }
        });
      },

      //多仓库打包方法
      getpack2() {
        if (this.totalSet.length == 0) {
          this.$message({
            message: '请勾选分支列表',
            type: 'warning'
          })
          return;
        } else {
          let totalList = JSON.parse(JSON.stringify(this.totalSet))
          totalList.forEach((item, index) => {
            if (item.branchBos) {
              delete item.branchBos;
              item['gitRepoUrl'] = item.sourceRepo;
              item['branch'] = item.branchBosid ? item.branchBosid.split(',')[1] : '';
              item['commitId'] = item.branchBosidCommitId ? item.branchBosidCommitId : '';
              delete item.sourceRepo;
              delete item.branchBosid;
              delete item.branchBosidCommitId
            }
          })

          let formData = new FormData();
          let gitRepoInfoLst = []
          formData.append('appId', this.appId);
          formData.append('verName', this.packInfo2.verName);
          formData.append('verDesc', this.packInfo2.verDesc);
          formData.append('pipelineId', this.pkgPipelineId);
          let list = [];
          totalList.forEach(item => {
            list.push(item);
          })
          formData.append('gitRepoInfoLstJsonStr', JSON.stringify(list));
          formData.append('buildTaskVarsJsonStr', this.getBuildTaskVarsJson());
          $http.post($http.api.appdate.appVersionCreate_v2, formData).then(res => {
            if (res.status == 200) {
              this.$message({
                message: '打包处理中......',
                type: "success"
              });

              let pkgWorkflowId = res.data;
              this.getVersionList({
                pageNum: 1,
                pageSize: this.tableListCommit.pageSize,
                appId: this.appId,
                keyword: this.filterKeyword,
                uuid: this.selectPipelineUuid
              }, pkgWorkflowId);

            } else {
              this.$message({
                message: res.msg,
                type: "warning"
              });
            }
          });
          this.handleClose_master2();
          this.totalSet = [];
        }
      },


      //多仓库关闭
      handleClose_master2() {
        this.packInfo2.verDesc = '';
        this.$refs['packInfo2'].resetFields();
        this.totalSet = [];
        this.dialogVisible_master2 = false;
      },

      showVersionPipeline(workflowId) {
        this.$router.replace({ path: this.$route.path, query: { ...this.$route.query, workflowId: workflowId } })
        this.$nextTick(this.$refs.appVersionPipeline.showVersionPipeline(workflowId, this.appId, false, true));
      },

      getClassByRunningStatus(status) {
        switch (status) {
          case GLOBAL_CONST.STAGE_STATUS.NOT_RUNNING:
            return "icon-status-init-l";
          case GLOBAL_CONST.STAGE_STATUS.WAIT:
            return "icon-status-waiting-l";
          case GLOBAL_CONST.STAGE_STATUS.RUNNING:
            return "icon-status-running-l";
          case GLOBAL_CONST.STAGE_STATUS.SUCCESS:
            return "icon-status-success-l";
          case GLOBAL_CONST.STAGE_STATUS.FAILURE:
            return "icon-status-fail-l";
        }
      }
    },

    components: {
      AppVersionPipeline,
      ApplicationAssociation
    }
  };
</script>

<style lang="scss" scoped>
  .table-box-solid {
    .hrheader {
      margin-bottom: 10px;
      border: 1px solid #d6d9e0;
    }

    .table_b_f_b {
      margin-top: 0px;
    }

    .el-icon-success {
      background: white;
      color: #00ff15;
      font-size: 20px;
    }

    .el-icon-minus {
      font-size: 16px;
      color: #1a1b1d;
    }

    .el-icon-error {
      font-size: 16px;
      color: red;
    }

    .el-icon-more {
      color: #60a0ff;
      font-size: 16px;
    }

    .el-icon-loading {
      color: #ac6c13;
      font-size: 16px;
    }

    .el-icon-caret-right {
      color: #5f5454;
      font-size: 16px;
    }

    .el-checkbox + .el-checkbox {
      margin-left: 15px !important;
    }
  }
</style>

<style lang="scss">
  #upload_file {
    el-input {
      .el-input__inner {
        height: 52px !important;
        padding: 2px 10px !important;
      }
    }

  }
</style>

