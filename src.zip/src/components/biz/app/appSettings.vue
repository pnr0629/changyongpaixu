<template>

  <div id="appSettings" class="content-outer-box">
    <div class="white-box table-outer-box">
      <div class="table-box">
        <div class="table-box-top"
          style="height:100%;padding-left:10px;padding-right:10px;overflow:auto;overflow-x: hidden;">
          <el-tabs v-model="activeName" class="el-tabs-wai" @tab-click="handleClick">
            <el-tab-pane label="人员设置" name="first">
              <div style="width:100%;margin-right:20%;margin-bottom:13px;height:30px;">
                <span class="fl" style="line-height: 26px;">应用owner:</span>
                <el-input v-model="appOwner.userName" style="margin-left:15px;display: inline-block;width:350px"
                  class="fl" disabled></el-input>
                <el-button type="primary" @click="showAppOwnerDialog"
                  v-show="authFunction('FUNC_APP_CHANGE_OWNER', 2, appId)" class="fl ml10">更换owner
                </el-button>
                <el-button type="primary" v-show="authFunction('FUNC_APP_CHANGE_OWNER', 2, appId)"
                  @click="showMemberSettingDialog" class="fl ml10">人员编辑
                </el-button>
              </div>
              <div style="margin-right:40%;">
                <el-table :data="devsAndTests" style="width:100%;height:100%;min-width:800px;">
                  <el-table-column align="center" prop="userName" label="人员" min-width="200">
                    <template slot-scope="scope">
                      <span>{{scope.row.userName+'('+scope.row.userId+')'}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" prop="" label="开发" min-width="200">
                    <template slot-scope="scope">
                      <span v-if="selectDevList.indexOf(scope.row.userId) != -1">{{'√'}}</span>
                    </template>
                  </el-table-column>
                  <el-table-column align="center" prop="" label="测试" min-width="200">
                    <template slot-scope="scope">
                      <span v-if="selectTestList.indexOf(scope.row.userId) != -1">{{'√'}}</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>

              <member-settings ref="memberSettings"></member-settings>
            </el-tab-pane>
            <!-- 人员设置 -->
            <memberSettings ref='memberSettings' @recheckFlush="StaffingBtn" :devList="devList"
              :initSelectDevList="selectDevList" :testList="testList" :initSelectTestList="selectTestList"
              :confirmClick="memberConfirmClick"></memberSettings>
            <el-tab-pane label="部署设置" name="two">
              <div class="table-box" style="border:none;">
                <el-form :model="appDeployInfo" ref="appDeployInfo" label-width="150px">
                  <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">
                    <el-col :span='12'>
                      <el-col :span='24'>
                        <el-form-item class='mb15' label="部署类型" label-width="120px" prop="publishType"
                          :rules="rules1.publish">
                          <el-select class="width-input-select" v-model="appDeployInfo.publishType" placeholder="请选择"
                            @change="publishTypeChanged()">
                            <el-option :key="item.name" v-for="item in deployTypeOptions" :label="item.name"
                              :value="item.value"></el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24'>
                        <el-form-item class='mb15'  label="App根目录" label-width="120px" prop="baseDir"
                          :rules="rules1.baseDir">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.baseDir" clearable
                            class="width-input-select"></el-input>

                          <el-checkbox v-model="appDeployInfo.userDefineDir" :true-label="1" :false-label="0"
                                       @change="userDefineDirChanged()" :disabled="appDeployInfo.publishType==1">自定义目录
                          </el-checkbox>
                          <div  v-if="appDeployInfo.userDefineDir == 1" style="line-height:normal;">{{"使用自定义目录时请注意在该目录下只能部署单个进程，请确认是否存在其他进程"}}</div>
                        </el-form-item>

                      </el-col>

                      <el-col :span='24' v-if="appDeployInfo.publishType!=1">
                        <el-form-item class='mb15' label="实例目录" label-width="120px">
                          <el-input placeholder="请输入内容"
                            :value="appDeployInfo.baseDir+(appDeployInfo.userDefineDir == 0 ? '/' + appDeployInfo.appCode + '/${instanceId}':'')+'/release'"
                            clearable disabled class="width-input-select"></el-input>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24' v-if="appDeployInfo.publishType==1">
                        <el-form-item label="实例目录" prop="instanceDir" label-width="120px">
                          <el-input v-model="appDeployInfo.instanceDir" :disabled="appDeployInfo.userDefineDir == 0"
                            placeholder="请输入实例目录相对于app跟目录" style="width: 500px">
                            <template slot="prepend">{{appDeployInfo.baseDir}}</template>
                          </el-input>
                          <span style="color: #c0c4cc">{{getRealInstanceDir()}}</span>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24'>
                        <el-form-item class='mb15' label="运行用户" label-width="120px" prop="userName"
                          :rules="rules1.userName">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.userName" clearable
                            class="width-input-select"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span='24'>
                        <el-form-item class='mb15' label="日志目录" label-width="120px" prop="logDir"
                          :rules="[{ required: true, message: '不能为空' ,trigger: 'blur'}]">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.logDir" clearable
                            class="width-input-select"></el-input>
                          <el-checkbox v-show="appDeployInfo.logDir.trim().startsWith('/')"
                            v-model="appDeployInfo.instanceLogDistinguish" :true-label="1" :false-label="0">
                            区分日志实例路径
                          </el-checkbox>
                        </el-form-item>
                      </el-col>
                      <el-col :span='24'>
                        <el-form-item class='mb15' label="日志目录路径" label-width="120px">
                          <el-input placeholder="请输入内容"
                            :value="appDeployInfo.logDir+(appDeployInfo.instanceLogDistinguish===1?'/${instanceId}':'')"
                            clearable disabled class="width-input-select"></el-input>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24'>
                        <el-form-item class='mb15' label="默认运行JDK" label-width="120px" prop="jdkVersion">
                          <el-select v-model="appDeployInfo.jdkVersion" placeholder="请选择" class="width-input-select">
                            <el-option label="jdk_1.7" :value="'jdk_1.7'" class="mt5 mb10">jdk_1.7</el-option>
                            <el-option label="jdk_1.8" :value="'jdk_1.8'" class="mt5 mb10">jdk_1.8</el-option>
                            <el-option label="openjdk_8" :value="'openjdk_8'" class="mt5 mb10">openjdk_8
                            </el-option>
                            <el-option label="openjdk_11" :value="'openjdk_11'" class="mt5 mb10">openjdk_11
                            </el-option>
                          </el-select>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24'>
                        <el-form-item class='mb15' label="配置下载目录" label-width="120px" prop="confDir">
                          <el-input placeholder="填写代表应用启动前将把配置文件下载到指定目录,请确认" v-model="appDeployInfo.confDir" clearable
                            class="width-input-select"></el-input>
                          <span v-show="appDeployInfo.confDir && appDeployInfo.confDir.startsWith('/')"
                            class="c-red">{{"请确认部署用户对"+appDeployInfo.confDir+"目录是否具有权限"}}</span>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24'>
                        <el-form-item class='mb15' label="发布初始化脚本" label-width="120px" prop="initShell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.initShell" clearable
                            class="width-input-select"></el-input>
                        </el-form-item>
                      </el-col>
                      <el-col :span='24'>
                        <el-form-item class='mb15' label="启动脚本" label-width="120px" prop="startShell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.startShell" clearable
                            class="width-input-select"></el-input>
                          <span class="c-blue cp" @click="addParams(1)">添加启动参数</span>
                        </el-form-item>
                      </el-col>
                      <el-col :span='24' v-for="(item,index) in appDeployInfo.startShellParamList" :key="index">
                        <el-form-item class='mb15' :label="'启动参数'+(index+1)" label-width="120px"
                          :prop="'startShellParamList['+index+']'" :rules="rules1.shell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.startShellParamList[index]" clearable
                            class="width-input-select"></el-input>
                          <span class="c-red cp" @click="deleteParams(1,index)">删除</span>
                        </el-form-item>
                      </el-col>
                      <el-col :span='24'>
                        <el-form-item class='mb15' label="停止脚本" label-width="120px" prop="stopShell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.stopShell" clearable
                            class="width-input-select"></el-input>
                          <span class="c-blue cp" @click="addParams(2)">添加停止参数</span>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24' v-for="(item,index) in appDeployInfo.stopShellParamList" :key="index">
                        <el-form-item class='mb15' :label="'停止参数'+(index+1)" label-width="120px"
                          :prop="'stopShellParamList['+index+']'" :rules="rules1.shell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.stopShellParamList[index]" clearable
                            class="width-input-select"></el-input>
                          <span class="c-red cp" @click="deleteParams(2,index)">删除</span>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24' v-if="appDeployInfo.publishType==1">
                        <el-form-item class='mb15' label="回滚脚本" label-width="120px" prop="rollBackShell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.rollBackShell" clearable
                            class="width-input-select"></el-input>
                        </el-form-item>
                      </el-col>

                      <el-col :span='24'>
                        <el-form-item class='mb15' label="健康检查脚本" label-width="120px" prop="healthCheckShell">
                          <el-input placeholder="请输入内容" v-model="appDeployInfo.healthCheckShell" clearable
                            class="width-input-select"></el-input>
                        </el-form-item>
                      </el-col>
                    </el-col>
                    <el-col :span="12">

                      <h3>高级设置</h3>

                      <el-col :span='24'>
                        <el-form-item class='mb15' label="是否增量发布" prop="incr"
                          :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                          <el-radio-group v-model="appDeployInfo.incr" placeholder="请选择" clearable
                            class="width-input-select">
                            <el-radio :label="1" class="mt5 mb10">是</el-radio>
                            <el-radio :label="0" class="mt5 mb10">否</el-radio>
                          </el-radio-group>

                        </el-form-item>
                      </el-col>
                      <el-col :span='24'>
                        <el-form-item class='mb15' label="Tomcat配置" prop="incr"
                          :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
                          <el-radio-group v-model="appDeployInfo.useTomcat" placeholder="请选择" clearable
                            class="width-input-select">
                            <el-radio :label="1" class="mt5 mb10">是</el-radio>
                            <el-radio :label="0" class="mt5 mb10">否</el-radio>
                          </el-radio-group>

                        </el-form-item>
                      </el-col>
                      <div v-if="appDeployInfo.useTomcat" class="mt10" style="margin-left:0;margin-right:0;">
                        <el-col :span='24'>
                          <div><b>TOMCAT设置</b></div>
                          <el-form-item class='mb15' label="Tomcat版本">
                            <el-select v-model="appDeployInfo.otherConfigObject.tomcatVersion" placeholder="请选择"
                              class="width-input-select">
                              <el-option :value="'tomcat7'" label="tomcat7">tomcat7</el-option>
                              <el-option :value="'tomcat8'" label="tomcat8">tomcat8</el-option>
                            </el-select>
                          </el-form-item>
                          <el-form-item class='mb15' label="Tomcat路径">
                            <el-input v-model="appDeployInfo.otherConfigObject.tomcatContext" placeholder="请输入内容"
                              class="width-input-select"></el-input>
                          </el-form-item>
                          <el-form-item class='mb15' label="Tomcat默认端口">
                            <el-input v-model="appDeployInfo.otherConfigObject.tomcatDefaultPort" placeholder="请输入内容"
                              class="width-input-select"></el-input>
                          </el-form-item>

                          <div><b>JVM参数设置</b></div>
                          <el-form-item class='mb15' label="JAVA_OPTS">
                            <el-input v-model="appDeployInfo.otherConfigObject.tomcatJavaOpts" type="textarea" :row="5"
                              placeholder="请输入内容" class="width-input-select"></el-input>
                          </el-form-item>

                          <div><b>Connector参数设置</b></div>
                          <el-form-item v-model="connectorInfo" v-for="(value,key) in connectorInfo" class='mb15'
                            prop="sadfasdf" :label="key" :key="key">
                            <el-input v-if="key!=='protocol'" v-model="connectorInfo[key]" placeholder="请输入内容"
                              class="width-input-select"></el-input>
                            <el-select v-if="key==='protocol'" v-model="connectorInfo[key]" placeholder="请输入内容"
                              class="width-input-select">
                              <el-option :value="'org.apache.coyote.http11.Http11NioProtocol'" label="NIO">NIO
                              </el-option>
                              <el-option :value="'org.apache.coyote.http11.Http11Nio2Protocol'" label="NIO2">NIO2
                              </el-option>
                              <el-option :value="'org.apache.coyote.http11.Http11Protocol'" label="BIO">BIO</el-option>
                              <el-option :value="'org.apache.coyote.http11.Http11AprProtocol'" label="APR">APR
                              </el-option>
                            </el-select>
                            <span class="el-icon-delete" v-if="fixedOptions.indexOf(key) == -1"
                              @click="delConnectorInfo(key)"></span>
                          </el-form-item>

                          <el-form :inline="true">
                            <el-form-item label="字段名" style="margin-left: 96px;">
                              <el-input v-model="newConnectorInfo" style="width: 330px" placeholder="请输入Connector字段名">
                              </el-input>
                            </el-form-item>
                            <el-form-item>
                              <el-button @click="addConnectorInfo()" icon="el-icon-plus">新增Connector配置</el-button>
                            </el-form-item>
                          </el-form>
                        </el-col>
                      </div>
                    </el-col>
                  </el-row>
                </el-form>
              </div>
              <div class="foot">
                <el-col :span='24'>
                  <el-button style="margin-left: 570px" type="primary" @click="saveAppDeployInfo()" class="button-left">
                    保存
                  </el-button>
                </el-col>
              </div>
            </el-tab-pane>
            <el-tab-pane label="配置中心设置" name="second">
              <div class="table-box">
                <div class="ml20 mr20 mb10 pzheader">
                  <el-form label-width="120px">
                    <el-row :gutter="10" style="margin-left:0;margin-right:0;">
                      <el-col :span='16'>
                        <el-form-item class='mb20' label="配置" label-width="80px">
                          <el-input style="display: inline-block" disabled v-model="selectConfigCenterAppName"
                            class="width-input-select" placeholder="绑定配置中心需要在正式环境和开发测试环境创建相同的配置中心ID" />
                          <el-switch v-model="useConfigCenter" inactive-text="使用配置中心" class="ml10"
                            style="margin-left:20px;" @change='handleConfigCenterChange' />
                          <el-button v-if="useConfigCenter == true" type="primary" class="ml10"
                            @click="showConfigCenterEnv">前往配置中心</el-button>
                        </el-form-item>
                      </el-col>
                      <el-col :span='4'>
                      </el-col>
                    </el-row>
                  </el-form>
                </div>
                <div class="ml20 mr20 pzhjxq">
                  <div class="pzhjxq-s ml10" style="vertical-align: top" v-for="(item,index) in env">
                    <div class="kf-cs-zs">
                      <span class="ml10 mt5 fl">{{envTitle[index]}}
                        <a style="color: #40a4ff" target="_blank" :href="configCenterUrl[item+'_config_center']">
                          {{'&nbsp;&nbsp;&nbsp;'+configCenterUrl[item+'_config_center']}}</a></span>
                    </div>
                    <div class="pz-hj-bb">
                      <div class="pz-hj-bb-block">
                        <span class="mt15 ml15 fl">配置中心环境</span>
                        <el-select v-model="configCenterSelectData[item+'EnvName']" placeholder="请选择"
                          class="fl mt10 ml10" style="width: 50%;">
                          <el-option v-for="(val,key) in getConfigEnvOps(item)" :key="key" :label="key" :value="key">
                          </el-option>
                        </el-select>
                      </div>

                      <div class="pz-hj-bb-block">
                        <span class="mt15 ml10 fl">配置中心版本</span>
                        <el-select v-model="configCenterSelectData[item+'EnvVersion']" placeholder="请选择"
                          class="fl mt10 ml10" style="width: 50%;">
                          <el-option v-for="(val,key) in getConfigCenterOps(item)" :key="key" :label="key" :value="key">
                          </el-option>
                        </el-select>
                      </div>
                    </div>

                    <div class="content"
                      v-if="configCenterSelectData[item+'EnvName']&&configCenterSelectData[item+'EnvVersion']&&configCenterData[item+'_config_center'].responseMap[configCenterSelectData[item+'EnvName']]">
                      <el-collapse class="ml10 mr10" :value="getConfigExpandCollapse(getParam1(item))">
                        <el-collapse-item :title="key" :key="key" :name="key" v-for="(val,key) in getParam2(item)">
                          <div v-for="v in val">{{'&nbsp&nbsp&nbsp&nbsp'+v}}</div>
                        </el-collapse-item>
                      </el-collapse>
                    </div>

                  </div>
                </div>
              </div>
            </el-tab-pane>

            <el-tab-pane label="基本信息设置" name="fourth">
              <div class="table-box" style="border:none;">
                <el-form :model="appBasicInfo" ref="appBasicInfo" label-width="140px">
                  <el-row :gutter="10" class="mt10" style="margin-left:0;margin-right:0;">

                    <el-col :span="basicSettingWidth">
                      <el-row>
                        <el-col :span='24'>
                          <el-form-item class='mb15' label="应用ID" prop="appCode"
                            :rules="[ { required: true, message: '不能为空' ,trigger: 'blur'}]">
                            <el-input placeholder="请输入内容" v-model="appBasicInfo.appCode" disabled clearable
                              class="width-input-select"></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='24'>
                          <el-form-item class='mb15' label="应用名称" prop="appName"
                            :rules="[{required: true, message: '不能为空' ,trigger: 'blur'}]">
                            <el-input placeholder="请输入内容" v-model.trim="appBasicInfo.appName" clearable
                              class="width-input-select"></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='24'>
                          <el-form-item class='mb15' label="调用链ID" prop="appSnakeId">
                            <el-input placeholder="请输入内容" v-model.trim="appBasicInfo.appSnakeId" clearable
                              class="width-input-select"></el-input>
                          </el-form-item>
                        </el-col>
                        <el-col :span='24'>
                          <el-form-item v-if="appBasicInfo.appType != 5" class='mb15' label="源码仓库" prop="sourceRepo"
                            :rules="rules1.sourceRepo">
                            <el-input placeholder="请输入内容" v-model.trim="appBasicInfo.sourceRepo" clearable
                              class="width-input-select"></el-input>
                          </el-form-item>
                        </el-col>

                        <el-col :span='24' v-if="appBasicInfo.appType != 5 && authFunction('FUNC_APP_DEVELOPMODE_SWTICH', 2, appId)">
                          <el-form-item class='mb15' label="开发模式" prop="developMode">
                          <el-radio-group
                            v-model="appBasicInfo.developMode"
                            @change="handleDevelopModeChange">
                            <el-radio :label="0">自由模式</el-radio>
                            <el-radio :label="1">分支模式</el-radio>
                          </el-radio-group>
                          <div style="display: inline" class="ml15" v-if="appBasicInfo.developMode == 1">
                            <el-checkbox
                            v-model="appBasicInfo.appIntegratedSettings.integratedDevEnabled"
                            @change="handleIntegratedDevChange">开发集成环境
                            </el-checkbox>
                            <el-checkbox
                            v-model="appBasicInfo.appIntegratedSettings.integratedTestEnabled"
                            disabled>测试集成环境
                            </el-checkbox>
                          </div>
                          </el-form-item>
                        </el-col>

                        <el-col :span='24'>
                          <el-form-item label="允许发布分支规则" prop="publishableBranches" :rules="rules1.publishableBranches">
                            <el-input v-model="appBasicInfo.publishableBranches"
                              placeholder="请输入允许发布分支规则,多个用逗号分隔,留空表示允许所有分支发布" class="width-input-select" />
                            <i class="el-icon-question" title="单击此图标以查看/隐藏允许发布分支规则详情"
                              @click="triggerPublishableBranchesDesc()" style="font-size: 16px;padding: 5px;" />
                          </el-form-item>
                        </el-col>
                        <el-col :span='24'>
                          <el-form-item label="版本名称规则" prop="versionNameTemplateData"
                            :rules="rules1.versionNameTemplateData">
                            <el-input v-model="appBasicInfo.versionNameTemplateData" placeholder="请输入内容"
                              class="width-input-select" />
                            <i class="el-icon-question" title="单击此图标以查看/隐藏版本名称规则详情"
                              @click="triggerVersionNameTemplateDesc()" style="font-size: 16px;padding: 5px;" />
                          </el-form-item>
                        </el-col>
                        <el-col style="width: 800px;">
                          <el-form-item label="历史打包总数">
                            <el-input v-model="appBasicInfo.versionCount" disabled class="width-input-select" />
                            <el-button type="primary" @click="flushVersionCount">清空历史打包总数</el-button>
                          </el-form-item>
                        </el-col>
                        <el-col :span='24'>
                          <el-form-item class='mb15' label="CMDB信息">
                            <el-popover placement="top-start" trigger="click" :key="item.cmdbId"
                              v-for="item in appBasicInfo.cmdbSyncInfoBos">
                              <template slot-scope="content">
                                <div v-if="appBasicInfo.cmdbPathIps && appBasicInfo.cmdbPathIps.length != 0"
                                  v-for="item in appBasicInfo.cmdbPathIps">{{item}}</div>
                              </template>
                              <el-button @click="listCmdbIps(item.cmdbId, appBasicInfo.appCode)" slot="reference"
                                style="margin-right: 10px">{{item.cmdbPath}}
                              </el-button>
                            </el-popover>
                            <span style="color: red"
                              v-if="!appBasicInfo.cmdbSyncInfoBos || appBasicInfo.cmdbSyncInfoBos.length == 0">
                              {{'应用未关联CMDB,无法执行线上环境的发布任务,请联系业务运维'+((this.getBizOpsInfo().length != 0)?'【'+this.getBizOpsInfo()+'】':'')+'关联CMDB'}}</span>
                          </el-form-item>
                        </el-col>
                      </el-row>
                    </el-col>
                    <el-col :span="12" v-if="showPublishableBranchesDesc">
                      <el-row>
                        <el-col :span="24">
                          <div style="width: 550px;margin-left: 70px">
                            <span style="font-size: 16px;">允许发布分支规则示例：master,release/*,hotfix/**</span><br />
                            <span style="font-size: 16px;">允许发布分支规则说明：?（匹配单个字符），*（匹配0或多个字符），**（匹配0或多个字符及目录）</span><br />
                            <span style="font-size: 16px;">留空表示允许所有分支发布</span><br />
                          </div>
                        </el-col>
                      </el-row>
                    </el-col>
                    <el-col :span="12" v-if="showVersionNameTemplateDesc">
                      <el-row>
                        <el-col :span="24">
                          <div style="width: 550px;margin-left: 70px">
                            <span style="font-size: 16px;">版本名称规则示例：${appId}-${date}-${totalIncr}</span><br />
                            <span style="font-size: 16px;">版本名称规则说明：生成的版本名称会对${xxx}形式的占位符做替换</span>
                            <el-table border :data="tipInfo" style="width: 100%;height:100%;margin-top: 20px">
                              <el-table-column prop="key" label="KEY" min-width="100"></el-table-column>
                              <el-table-column prop="explaim" label="释义" min-width="100"></el-table-column>
                              <el-table-column prop="extraInfo" label="说明" min-width="100"></el-table-column>
                            </el-table>
                          </div>
                        </el-col>
                      </el-row>
                    </el-col>
                  </el-row>
                </el-form>
                <div class="foot">
                  <el-col :span='24'>
                    <el-button style="margin-left: 570px" type="primary" class="button-left" @click="saveAppBasicInfo()"
                      size="medium">保存
                    </el-button>
                  </el-col>
                </div>
              </div>
            </el-tab-pane>

            <el-tab-pane label="包上传管理" name="five">
              <max-pkg-upload-manage ref="maxPkgUploadManage"></max-pkg-upload-manage>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>
    <!--变更应用owner弹窗-->
    <el-dialog title='变更应用OWNER' :visible.sync="appOwnerDialogVisible" class="el-dialog-350w">
      <el-select v-model="selectedOwnerId" placeholder="请选择" clearable style="width:100%;">
        <el-option v-for="item in allAppMembers" :key="item.userId" :label="item.userName" :value="item.userId">
        </el-option>
      </el-select>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="changeAppOwner" class="fr">保存</el-button>
        <el-button @click="closeAppOwnerDialog" class="fr mr10">关闭</el-button>
      </span>
    </el-dialog>

    <!--前往配置中心-->
    <el-dialog title="前往配置中心" :visible.sync="showIt" class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <div>
          <a target="_blank" style="display: inline-block;color: #359dff;"
            href="http://conf.basictest.wanyol.com/#config/home">前往开发/测试环境的配置中心</a><br /><br />
          <a target="_blank" style="display: inline-block;color: #359dff;"
            href="http://admin.conf.oppoer.me/#config/home">前往正式环境的配置中心</a>
        </div>
      </div>
    </el-dialog>

  </div>
</template>

<script>
  import maxPkgUploadManage from '@/components/biz/app/settings/maxPkgUploadManage'
  import memberSettings from '@/components/tool/Staffing/Staffing'

  export default {
    name: "appSettings",
    data() {
      let validTargetDir = (rule, value, callback) => {
        let targetPattern = this.compileInfo.baseAppConfig.targetPattern;
        if (!this.targetPatternVerify(value, targetPattern)) {
          callback(new Error("目标文件路径中文件与目标文件压缩格式不符合！"));
        } else {
          callback();
        }
      };
      let validShell = (rule, value, callback) => {
        let invalidateChar = ["`", "$", "|", ";", "&&", ">", "<"];
        if (value) {
          for (let oneChar of invalidateChar) {
            if (value.indexOf(oneChar) !== -1) {
              callback(new Error("参数不能包含特殊字符" + oneChar));
              return;
            }
          }
        }
        callback();
      };
      let validRepo = (rule, value, callback) => {
        let checkGitSshUrl = /^(git@|ssh:\/\/\w+@)\w+/;

        let checkGitHttpUrl = /^[A-Za-z]+:\/\/+/;

        if (!checkGitSshUrl.test(value) && !checkGitHttpUrl.test(value)) {
          callback(new Error("源码仓库格式错误！请检查git地址格式! 形如git@xxx或者ssh://xxx@xxx或者http://xxx"));
        } else {
          $http.get($http.api.app.sourceRepoValidate, {appId: this.getUrlAppId(),originalSourceRepo: this.originalSourceRepo, sourceRepo: value.trim(), developMode:this.appBasicInfo.developMode})
          .then((res) => {
            if ( res.status == 200) {
              this.repoValidateMode = res.data.resultMode;
              callback();
            } else {
              callback(new Error(res.msg));
            }
          }).catch(_ => {})
        }
      };
      let validBaseDir = (rule, value, callback) => {
        if (value.substr(0, 1) != "/") {
          callback(new Error("APP根目录必须是绝对路径"));
        } else {
          callback();
        }
      };
      let validUserName = (rule, value, callback) => {
        value = value.trim().toLowerCase();
        if (value === 'root') {
          callback(new Error("运行用户名不能为root"));
        } else {
          callback();
        }
      };
      let validVersionNameTemplateData = (rule, value, callback) => {
        let spaceList = value.split(" ");
        if (spaceList.length > 1) {
          callback(new Error("请去除空格！"))
        }

        let pattern = /\w*(\${[a-zA-Z]+})*\w*/;
        if (!pattern.test(value)) {
          callback(new Error("输入格式错误！"))
        }

        let tempList = value.split("${");
        let afterTrim = tempList.splice(1, tempList.length - 1);
        let realList = [];
        afterTrim.forEach(item => {
          realList.push(item.substring(0, item.indexOf("}")));
        });
        realList.forEach(item => {
          if (GLOBAL_CONST.DEFAULT_VERSION_NAME_TEMPLATE_DATA_LIST.indexOf(item) == -1) {
            callback(new Error("占位符变量填写错误，建议拷贝填入"));
          }
        })
        callback();
      };
      let validPublishableBranches = (rule, value, callback) => {
        if (!value) {
          callback();
        } else {
          let spaceList = value.split(" ");
          if (spaceList.length > 1) {
            callback(new Error("请去除空格！"))
          } else {
            callback();
          }
        }
      }
      return {
        repoValidateMode: 0,
        originalSourceRepo: "",
        showIt: false,
        compileNetBack: 0,
        deployNetBack: 0,
        deployTypeOptions: [{ name: "普通发布", value: 0 }, { name: "yum发布", value: 1 }],
        tipInfo: [
          { key: 'date', explaim: '时间戳（精确至日期）', extraInfo: '' },
          { key: 'dateTime', explaim: '时间戳（精确至秒）', extraInfo: '' },
          { key: 'appId', explaim: '应用ID', extraInfo: '' },
          { key: 'branchName', explaim: '分支名称', extraInfo: '多仓库自定义脚本类应用不支持' },
          { key: 'todayIncr', explaim: '应用当天打包总数自增', extraInfo: '' },
          { key: 'totalIncr', explaim: '应用历史打包总数自增', extraInfo: '' },
        ],
        basicSettingWidth: 12,
        rules1: {
          publishableBranches: [{ validator: validPublishableBranches, trigger: 'blur' }],
          versionNameTemplateData: [{
            required: true,
            message: '版本名称规则不能为空',
            trigger: 'blur'
          }, { validator: validVersionNameTemplateData, trigger: 'blur' }],
          sourceRepo: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validRepo, trigger: 'blur' }],
          baseDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validBaseDir, trigger: 'blur' }],
          targetDir: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validTargetDir, trigger: 'blur' }],
          userName: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validUserName, trigger: 'blur' }],
          shell: [{ required: true, message: '不能为空', trigger: 'blur' }, { validator: validShell, trigger: 'blur' }],
          publish: [{ required: true, message: '不能为空', trigger: 'blur' }]
        },
        settingWidth: 12,
        selectedOwnerId: '',
        appOwnerDialogVisible: false,
        devsAndTests: [],
        allAppMembers: [],
        appOwner: {
          userId: '',
          userName: ''
        },
        devList: [],
        selectDevList: [],
        testList: [],
        selectTestList: [],
        fixedOptions: ['protocol', 'maxThreads', 'minSpareThreads', 'maxConnections', 'acceptCount', 'connectionTimeOut'],
        connectorInfo: {
          protocol: "",
          maxThreads: "",
          minSpareThreads: "",
          maxConnections: "",
          acceptCount: "",
          connectionTimeOut: ""
        },
        appBasicInfo: {
          publishableBranches: '',
          versionNameTemplateData: '',
          appCode: '',
          sourceRepo: '',
          developMode: '',
          serverCode: 'd',
          cmdbSyncInfoBos: [{ cmdbId: 0, cmdbPath: '' }],
          cmdbPathIps: '',
          bizOpes: [],
          versionCount: 0,
          appIntegratedSettings:{},
          repoValidateMode: 0,
        },
        appDeployInfo: {
          jdkVersion: 'jdk_1.8',
          otherConfigObject: {
            cpu: '4',
            memory: '4096',
            storage: '50',
          },
          logDir: 'logs',
          confDir: '',
          instanceLogDistinguish: 0,
          baseDir: '',
          publishType: 0,
          startShellParams: '',
          stopShellParams: '',
          startShellParamList: [],
          stopShellParamList: [],
          instanceDir: "",
          appCode: '',
          incr: 0,
          useTomcat: 0,
        },
        configCenterInfo: {},
        configCenterData: {
          online_config_center: { responseMap: {} },
          dev_config_center: { responseMap: {} },
          test_config_center: { responseMap: {} },
        },
        configCenterSelectData: {
          devEnvVersion: null, devEnvName: null,
          testEnvVersion: null, testEnvName: null,
          onlineEnvVersion: null, onlineEnvName: null
        },
        configCenterUrl: {
          dev_config_center: null,
          test_config_center: null,
          online_config_center: null,
        },
        env: ['dev', 'test', 'online'],
        envTitle: ['开发环境', '测试环境', '正式环境'],
        selectConfigCenterAppName: "",
        configCenterList: {},
        applicationMemberInfo: {},
        newConnectorInfo: "",
        showConnectorInput: false,
        showBtn: '0',
        table_loading: false,
        appId: null,
        options: [],
        compileLanguageOptions: ['JAVA', 'PHP', 'C++', 'GO', 'HTML', 'JS', 'RPM'],
        usePublicRepoOptions: [{ "key": "是", value: 1 }, { "key": "否", value: 0 }],

        APP_TYPE: GLOBAL_CONST.APP_TYPE,

        javaAppBuildTool: 1,

        activeName: 'first',
        activeNameCount: [],
        optionsInfo: {},
        creatInfo: {},
        compileInfo: {
          appType: 1,
          incr: 0,
          baseAppConfig: {
            usePublicRepo: 0,
            subAppBos: [{ subAppId: '', sourceRepo: '' }]
          }
        },
        showVersionNameTemplateDesc: false,
        showPublishableBranchesDesc: false,
        bizId: 0,
        appCode: 0,
        useConfigCenter: 0,
        appCodeComeBackFlag: 0,
        COMPILE_TASK_STATUS: GLOBAL_CONST.COMPILE_TASK_STATUS,
        fullScreenLoading: '',
      };
    },

    computed: {},

    mounted() {
      window.onresize = () => {
        this.changeCompileSize();
        this.appBasicLayOutReactive();
      };
      this.changeCompileSize();
      this.appBasicLayOutReactive();
      this.getCurrentAppId();

      this.activeName = this.getDefaultActiveTabName();
      this.handleClick(this.activeName);
      this.bizId = this.getUrlBizId();
    },

    methods: {
      getDefaultActiveTabName() {
        let urlParams = this.getUrlParams();
        let defaultActiveTabName = urlParams['activeTab'];
        if(!defaultActiveTabName) {
          return "first";
        }
        return defaultActiveTabName;
      },
      addParams(type) {
        if (type == 1) {
          this.appDeployInfo.startShellParamList.push("");
        } else {
          this.appDeployInfo.stopShellParamList.push("");
        }
      },
      deleteParams(type, index) {
        if (type == 1) {
          this.appDeployInfo.startShellParamList.splice(index, 1);
        } else {
          this.appDeployInfo.stopShellParamList.splice(index, 1);
        }
      },
      flushVersionCount() {
        this.$confirm('确认清空历史打包总数吗？清空后将从1开始重新计数').then(_ => {
          $http.get($http.api.app.flush_version_count, { appId: this.appId }).then((res) => {
            this.$message({ type: "success", message: "刷新版本计数成功！" });
            this.getAppBasicInfo();
          }).catch(e => {
            this.$message({ type: "error", message: "刷新版本计数失败！" });
          })
        }).catch(_ => {
        })
      },
      showDevOrTestLink() {
        if ((!this.configCenterData.dev_config_center.responseMap || this.isEmptyObject(this.configCenterData.dev_config_center.responseMap))
          && (!this.configCenterData.test_config_center.responseMap || this.isEmptyObject(this.configCenterData.test_config_center.responseMap))) {
          return true;
        } else {
          return false;
        }
      },
      showOnlineLink() {
        if (!this.configCenterData.online_config_center.responseMap || this.isEmptyObject(this.configCenterData.online_config_center.responseMap)) {
          return true;
        } else {
          return false;
        }
      },
      usesConfigCenter() {
        $http.get($http.api.config_center.save_association, {
          appId: this.appId,
          configCenterAppName: this.selectConfigCenterAppName
        }).then((res) => {
          this.$message({ type: "success", message: "绑定成功！" });
          this.getUseConfigCenterStatus();
          this.getConfigCenterInfo();
        })

      },
      unUseConfigCenter() {
        $http.get($http.api.config_center.save_association, {
          appId: this.appId,
          configCenterAppName: null
        }).then((res) => {
          this.$message({ type: "success", message: "解绑成功！" });
          this.getUseConfigCenterStatus();
          this.getNullConfigCenterInfo();
        })
      },
      showConfigCenterEnv() {
        this.showIt = true;
      },
      handleConfigCenterChange(useStatus) {
        if (useStatus == true) {
          this.usesConfigCenter();
        } else {
          this.unUseConfigCenter();
        }

      },

      getRealInstanceDir() {
        if (!this.appDeployInfo.baseDir) {
          this.appDeployInfo.baseDir = "";
        }
        if (!this.appDeployInfo.instanceDir) {
          this.appDeployInfo.instanceDir = "";
        }
        return this.appDeployInfo.baseDir + this.appDeployInfo.instanceDir;
      },

      publishTypeChanged() {
        if (this.appDeployInfo.publishType == 1) {
          this.appDeployInfo.userDefineDir = 1;
        }
      },
      userDefineDirChanged() {
        if (this.appDeployInfo.userDefineDir == 0) {
          this.appDeployInfo.instanceDir = "/" + this.appDeployInfo.appCode + "/${instanceId}/release"
        } else {
          this.appDeployInfo.instanceDir = "/release"
        }
      },

      appBasicLayOutReactive() {
        let offsetWidth = document.body.offsetWidth;
        if (offsetWidth < 1500) {
          return this.basicSettingWidth = 16;
        } else {
          return this.basicSettingWidth = 12;
        }
      },

      getParam1(item) {
        if (this.configCenterData
          && this.configCenterData[item + '_config_center']
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']]
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']]
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']].normalConfig
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']].normalConfig.configFileMap) {
          return this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']].normalConfig.configFileMap;
        }
      },

      getParam2(item) {
        //configCenterData.online_config_center.responseMap[configCenterSelectData[item+'EnvName']].versionConfigMap[configCenterSelectData[item+'EnvVersion']].normalConfig.configFileMap
        if (this.configCenterData
          && this.configCenterData[item + '_config_center']
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']]
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']]
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']].normalConfig
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']].normalConfig.configFileMap) {
          return this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap[this.configCenterSelectData[item + 'EnvVersion']].normalConfig.configFileMap;
        } else {
          return {};
        }
      },

      getConfigEnvOps(item) {
        if (this.configCenterData && this.configCenterData[item + '_config_center'] && this.configCenterData[item + '_config_center'].responseMap) {
          return this.configCenterData[item + '_config_center'].responseMap
        }
      },


      getConfigCenterOps(item) {
        if (!this.showConfigVer(item)) {
          return {};
        }
        if (this.configCenterData && this.configCenterData[item + '_config_center']
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']]
          && this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap) {
          return this.configCenterData[item + '_config_center'].responseMap[this.configCenterSelectData[item + 'EnvName']].versionConfigMap;
        } else {
          return {};
        }
      },


      showConfigVer(item) {
        if (this.configCenterSelectData[item + 'EnvName']) {
          let temp = this.configCenterData[item + '_config_center'];
          if (temp) {
            if (temp.responseMap[this.configCenterSelectData[item + 'EnvName']]) {
              return true;
            }
          }
        }
        return false;
      },

      getBizOpsInfo() {
        let opesList = this.appBasicInfo.bizOpes;
        let string = '';
        if (opesList && opesList.length != 0) {
          for (let i = 0; i < opesList.length; i++) {
            string += opesList[i].userName;
            if (i < opesList.length - 1) {
              string += ", ";
            }
          }
        }
        return string;
      },

      changeCompileSize() {
        let offsetWidth = document.body.offsetWidth;
        if (offsetWidth < 1500) {
          return this.settingWidth = 16;
        } else {
          return this.settingWidth = 12;
        }
      },
      listCmdbIps(cmdbId, appCode) {
        $http.get($http.api.cmdb.cmdbIps, { cmdbAppId: cmdbId, zoneCode: '', appCode: appCode }).then((res) => {
          let ipList = res.data;
          let returnList = [];
          if (ipList && ipList.length != 0) {
            for (let i = 0; i < ipList.length; i++) {
              returnList.push(ipList[i].ip);
            }
            this.$set(this.appBasicInfo, "cmdbPathIps", returnList);
          } else {
            this.$set(this.appBasicInfo, "cmdbPathIps", ["未绑定机器!"]);
          }
        })
      },

      targetPatternVerify(targetDir, targetPattern) {
        let endFormat = [".zip", ".jar", ".tar", ".tar.gz", ".war"];
        let count = 0;
        for (let i = 0; i < endFormat.length; i++) {
          if (targetDir.endsWith(endFormat[i])) {
            count++;
            break;
          }
        }
        if (count === 0) {
          return true;
        }
        if (targetDir.endsWith(targetPattern)) {
          return true;
        }
        if (targetPattern == "tar" && targetDir.endsWith(targetPattern + ".gz")) {
          return true;
        }
        return false;
      },

      changeAppOwner() {
        let param = {};
        param.appIdsStr = this.appId;
        param.ownerId = this.selectedOwnerId;
        $http.post($http.api.app.changeAppOwner, param).then((res) => {
          this.$message({
            message: '替换成功!',
            type: 'success'
          });
          this.initMemberInfo();
          this.closeAppOwnerDialog();
        });
      },

      showMemberSettingDialog() {
        this.$refs.memberSettings.showcCldProdRight_s();
      },

      showAppOwnerDialog() {
        this.appOwnerDialogVisible = true;
      },

      closeAppOwnerDialog() {
        this.appOwnerDialogVisible = false;
      },

      StaffingBtn() {
      },

      memberConfirmClick(type, dataList) {
        if (type === 1) {
          $http.post($http.api.app.saveApplicationDevMembers, {
            appId: this.appId,
            userIdsStr: dataList.join(",")
          }).then((res) => {
            this.$message({
              type: 'success',
              message: '保存开发人员成功'
            });
            this.initMemberInfo();
          }).catch(() => {
            this.$message({
              type: "error",
              message: "保存开发人员失败"
            });
          });
        } else {
          $http.post($http.api.app.saveApplicationTestMembers, {
            appId: this.appId,
            userIdsStr: dataList.join(",")
          }).then((res) => {
            this.$message({
              type: 'success',
              message: '保存测试人员成功'
            });
            this.initMemberInfo();
          }).catch(() => {
            this.$message({
              type: "error",
              message: "保存测试人员失败"
            });
          });
        }
      },

      initMemberInfo() {
        let appId = this.appId;
        this.devList = [];
        this.selectDevList = [];
        this.testList = [];
        this.selectTestList = [];
        this.devsAndTests = [];
        this.allAppMembers = [];
        $http.get($http.api.app.get_application_member_config_info, { appId: appId }).then((res) => {
          res.data.appDevMembers.forEach(val => {
            let oneDev = { key: val.userId, label: val.userName };
            this.devList.push(oneDev);
            this.selectDevList.push(val.userId);
            this.devsAndTests.push(val);
          });
          res.data.unSelectedDevs.forEach(val => {
            this.devList.push({ key: val.userId, label: val.userName });
          });

          res.data.appTestMembers.forEach(val => {
            let oneTest = { key: val.userId, label: val.userName };
            this.testList.push(oneTest)
            this.selectTestList.push(val.userId);
            let count = 0;
            for (let i = 0; i < this.devsAndTests.length; i++) {
              if (this.devsAndTests[i].userId === val.userId) {
                count++;
                break;
              }
            }
            if (count === 0) {
              this.devsAndTests.push(val);
            }
          });
          res.data.unSelectedTests.forEach(val => {
            this.testList.push({ key: val.userId, label: val.userName });
          });
          if(res.data.appOwner){
            this.appOwner = res.data.appOwner;
            this.selectedOwnerId = res.data.appOwner.userId;
          }

          this.devsAndTests.forEach(val => {
            this.allAppMembers.push(val);
          })

          let count = 0;
          for (let i = 0; i < this.allAppMembers.length; i++) {
            if (this.selectedOwnerId === this.allAppMembers[i].userId) {
              count++;
              break;
            }
          }
          if (count === 0 && this.selectedOwnerId !== '') {
            this.allAppMembers.push(res.data.appOwner);
          }
        });
      },

      isEmptyObject(obj) {
        if (!obj || obj == '') {
          return true;
        }
        for (let objKey in obj) {
          return false;
        }
        return true;

      },

      getUseConfigCenterStatus() {
        $http.get($http.api.app.get_use_config_center_status, { appId: this.appId }).then((res) => {
          setTimeout(() => {
            if (res.data != undefined) {
              if (res.data == 1) {
                this.useConfigCenter = true;
              } else {
                this.useConfigCenter = false;
              }
            } else {
              this.useConfigCenter = false;
            }
          }, 100)
        })
      },

      handleClick(tab, event) {
        if (this.activeName == 'first') {
          this.initMemberInfo();
        }
        if (this.activeName == 'two') {
          this.getAppDeployInfo();
        }
        if (this.activeName == 'second') {
          this.getUseConfigCenterStatus();
          this.getConfigCenterApplication();
          this.getConfigCenterUrl();

        }
        if (this.activeName == 'third') {
          // this.getAppCompileInfo();
          this.getAppDeployInfo();
        }
        if (this.activeName == 'fourth') {
          this.getAppBasicInfo();
        }
        if (this.activeName === 'five') {
          this.$refs['maxPkgUploadManage'].getAppMaxUploadConfig();
        }
      },

      getCurrentAppId() {
        this.appId = this.getUrlAppId();
      },

      delConnectorInfo(key) {
        this.$delete(this.connectorInfo, key);
      },

      addConnectorInfo() {
        if (this.newConnectorInfo && this.newConnectorInfo !== '') {
          for (let key in this.connectorInfo) {
            if (this.newConnectorInfo === key) {
              this.$message({
                message: '该配置已存在',
                type: 'error'
              });
              return;
            }
          }
          this.connectorInfo[this.newConnectorInfo] = '';
          this.newConnectorInfo = ''
        } else {
          this.$message({
            message: '请输入字段名',
            type: 'error'
          });
        }
      },

      getAppBasicInfo() {
        $http.get($http.api.app.get_app_basic_info, { appId: this.appId }).then((res) => {
          this.appBasicInfo = res.data;
          if(res.data){
            this.originalSourceRepo = res.data.sourceRepo
          }
        });
      },

      async saveAppBasicInfo() {
        if(this.compileInfo.appType !== 5 && this.appBasicInfo.sourceRepo !== this.originalSourceRepo) {
          let confirmResult = await this.confirmBeforeOperate('代码仓库修改后，编译任务默认分支统一修改为master');
          if(!confirmResult) {
            return;
          }
        }

        // if(this.appBasicInfo.developMode == '1' && this.appBasicInfo.sourceRepo !== this.originalSourceRepo) {
        //   let confirmResult = await this.confirmBeforeOperate('分支模式下更改源码仓库，旧仓库已创建的特性分支将无法继续进行集成操作，只能删除后重建，请确认');
        //   if(!confirmResult) {
        //     return;
        //   }
        // }

        this.$refs['appBasicInfo'].validate(pass => {
          if (pass) {
            this.appBasicInfo.appId = this.appId;
            if (this.compileInfo.appType == 5) {
              this.appBasicInfo.sourceRepo = '';
            }
            this.appBasicInfo.repoValidateMode = this.repoValidateMode;
            $http.post($http.api.app.save_app_basic_info, this.appBasicInfo).then((res) => {
              if (res.status == 200) {
                this.$message({
                  message: '保存成功',
                  type: 'success'
                });
                this.getAppBasicInfo();
              }
            });
          }
        });
      },

      // 操作前的确认
      async confirmBeforeOperate(text) {
        let result = true;
        try {
          result = await this.$confirm(text, {
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            type: 'warning'
          })
        } catch (_) {
          result = false;
        }
        return result;
      },

      getAppDeployInfo() {
        $http.get($http.api.app.get_app_deploy_info, { appId: this.appId }).then((res) => {
          this.appDeployInfo = res.data;
          if (!res.data.baseDir) {
            this.appDeployInfo.baseDir = '';
          }
          if (!res.data.instanceLogDistinguish) {
            this.appDeployInfo.instanceLogDistinguish = 0;
          }
          if (!res.data.logDir) {
            this.appDeployInfo.logDir = 'log';
          }
          if (res.data.startShellParams) {
            this.$set(this.appDeployInfo, "startShellParamList", JSON.parse(res.data.startShellParams));
          } else {
            this.$set(this.appDeployInfo, "startShellParamList", []);
          }
          if (res.data.stopShellParams) {
            this.$set(this.appDeployInfo, "stopShellParamList", JSON.parse(res.data.stopShellParams));
          } else {
            this.$set(this.appDeployInfo, "stopShellParamList", []);
          }

          //处理实例目录
          if (res.data.userDefineDir == 0) {
            this.appDeployInfo.instanceDir = '';
          } else {
            this.appDeployInfo.instanceDir = this.appDeployInfo.baseDir && this.appDeployInfo.instanceDir ? this.appDeployInfo.instanceDir.substr(this.appDeployInfo.baseDir.length) : "";
          }

          //解析connector配置
          try {
            if (!this.isEmptyObject(this.appDeployInfo.otherConfigObject.tomcatConnectorConfig)) {
              this.connectorInfo = this.appDeployInfo.otherConfigObject.tomcatConnectorConfig;
            } else {
              this.connectorInfo = {
                protocol: "org.apache.coyote.http11.Http11NioProtocol",
                maxThreads: "200",
                minSpareThreads: "10",
                maxConnections: "10000",
                acceptCount: "100",
                connectionTimeOut: "20000"
              }
            }
          } catch (e) {
          }
          //网络请求回来标识
          this.deployNetBack = 1;
        });
      },

      saveAppDeployInfo() {
        this.$refs['appDeployInfo'].validate(pass => {
          if (pass) {
            let param = {};
            param.appId = this.appId;
            param.baseDir = this.appDeployInfo.baseDir;
            param.userName = this.appDeployInfo.userName;
            param.logDir = this.appDeployInfo.logDir;
            param.startShell = this.appDeployInfo.startShell;
            param.stopShell = this.appDeployInfo.stopShell;
            param.restartShell = this.appDeployInfo.restartShell;
            param.initShell = this.appDeployInfo.initShell;
            param.healthCheckShell = this.appDeployInfo.healthCheckShell;
            param.userDefineDir = this.appDeployInfo.userDefineDir;
            param.publishType = this.appDeployInfo.publishType;
            param.confDir = this.appDeployInfo.confDir;
            param.incr = this.appDeployInfo.incr;
            param.useTomcat = this.appDeployInfo.useTomcat;
            param.jdkVersion = this.appDeployInfo.jdkVersion;
            param.tomcatVersion = this.appDeployInfo.otherConfigObject.tomcatVersion;
            param.tomcatContext = this.appDeployInfo.otherConfigObject.tomcatContext;
            param.tomcatDefaultPort = this.appDeployInfo.otherConfigObject.tomcatDefaultPort;
            param.tomcatJavaOpts = this.appDeployInfo.otherConfigObject.tomcatJavaOpts;
            param.tomcatConnectorConfig = JSON.stringify(this.connectorInfo);
            if (this.appDeployInfo.startShellParamList && this.appDeployInfo.startShellParamList.length !== 0) {
              param.startShellParams = JSON.stringify(this.appDeployInfo.startShellParamList);
            } else {
              param.startShellParams = "";
            }

            if (this.appDeployInfo.stopShellParamList && this.appDeployInfo.stopShellParamList.length !== 0) {
              param.stopShellParams = JSON.stringify(this.appDeployInfo.stopShellParamList);
            } else {
              param.stopShellParams = "";
            }

            if (this.appDeployInfo.logDir.trim().startsWith('/')) {
              param.instanceLogDistinguish = this.appDeployInfo.instanceLogDistinguish;
            } else {
              param.instanceLogDistinguish = 0;
            }

            if (this.appDeployInfo.userDefineDir == 0 || this.appDeployInfo.publishType != 1) {
              param.instanceDir = "";
            } else {
              param.instanceDir = this.appDeployInfo.baseDir + this.appDeployInfo.instanceDir;
            }

            if (this.appDeployInfo.publishType == 1) {
              param.rollBackShell = this.appDeployInfo.rollBackShell;
            } else {
              param.rollBackShell = "";
            }
            // console.log(param)
            $http.post($http.api.app.save_app_deploy_config, param).then((res) => {
              if (res.status == 200) {
                this.$message({ message: '保存成功', type: 'success' });
              } else {
                this.$message({ message: '保存失败', type: 'error' });
              }
              this.getAppDeployInfo();
            }).catch(e => {
              this.$message({ message: '保存失败', type: 'error' });
              this.getAppDeployInfo();
            });
          }
        });
      },

      getConfigCenterUrl() {//获得配置中心url
        $http.get($http.api.config_center.get_sys_config_info, { configKey: 'config_center' }).then((res) => {
          for (let index in res.data) {
            let data = res.data[index];
            if (data.showVal == null) {
              this.configCenterUrl[data.key] = data.value;
            } else {
              this.configCenterUrl[data.key] = data.showVal;
            }
          }
        });
      },

      getConfigCenterApplication() {
        $http.get($http.api.config_center.config_center_application, { appId: this.appId }).then((res) => {
          if (res.data.isUsed == 1) {
            this.configCenterInfo = res.data.data;
            this.selectConfigCenterAppName = this.configCenterInfo.configCenterAppName;
            this.useConfigCenter = 1;
            this.getConfigCenterInfo();
          } else {
            this.configCenterInfo = null;
            this.selectConfigCenterAppName = res.data.data;
          }
        })
      },

      getNullConfigCenterInfo() {
        $http.get($http.api.config_center.app_config_info, { configCenterName: "" }).then((res) => {
          //初始化 configCenterSelectData.onlineEnvVersion configCenterSelectData.onlineEnvName
          this.configCenterData = res.data;

          //初始化
          for (let index in this.env) {
            let onlineData = res.data[this.env[index] + '_config_center'];
            if (res.data && onlineData && onlineData.responseMap) {
              for (let key in onlineData.responseMap) {
                let envName = this.env[index] + 'EnvName';
                this.configCenterSelectData[envName] = key;
                for (let key1 in onlineData.responseMap[key].versionConfigMap) {
                  let version = this.env[index] + 'EnvVersion';
                  this.configCenterSelectData[version] = key1;
                  break;
                }
                break;
              }
            }
          }

          //清空已有缓存
          this.configCenterSelectData.devEnvVersion = '';
          this.configCenterSelectData.devEnvName = '';
          this.configCenterSelectData.testEnvVersion = '';
          this.configCenterSelectData.testEnvName = '';
          this.configCenterSelectData.onlineEnvVersion = '';
          this.configCenterSelectData.onlineEnvName = '';
        });
      },

      getConfigCenterInfo() {
        $http.get($http.api.config_center.app_config_info, { configCenterName: this.selectConfigCenterAppName }).then((res) => {
          //初始化 configCenterSelectData.onlineEnvVersion configCenterSelectData.onlineEnvName
          this.configCenterData = res.data;
          //初始化
          for (let index in this.env) {
            let onlineData = res.data[this.env[index] + '_config_center'];
            if (res.data && onlineData && onlineData.responseMap) {
              for (let key in onlineData.responseMap) {
                let envName = this.env[index] + 'EnvName';
                this.configCenterSelectData[envName] = key;
                for (let key1 in onlineData.responseMap[key].versionConfigMap) {
                  let version = this.env[index] + 'EnvVersion';
                  this.configCenterSelectData[version] = key1;
                  break;
                }
                break;
              }
            }
          }
        });
      },

      getApplicationMemberConfigInfo() {
        $http.get($http.api.app.get_application_member_config_info, { appId: this.appId }).then((res) => {
          this.applicationMemberInfo = res.data;
        });
      },

      saveApplicationMemberConfigInfo() {
        this.appDeployInfo.appId = this.appId;
        $http.post($http.api.app.save_application_member_config_info, this.applicationMemberInfo).then((res) => {
          this.$message({
            message: '保存成功',
            type: 'success'
          });
          this.getApplicationMemberConfigInfo();
        });
      },

      getConfigExpandCollapse(param) {
        var ret = [];
        for (let paramKey in param) {
          ret.push(paramKey);
        }
        return ret;
      },

      triggerVersionNameTemplateDesc() {
        if (this.showVersionNameTemplateDesc) {
          this.showVersionNameTemplateDesc = false;
          this.showPublishableBranchesDesc = false;
        } else {
          this.showVersionNameTemplateDesc = true;
          this.showPublishableBranchesDesc = false;
        }
      },

      triggerPublishableBranchesDesc() {
        if (this.showPublishableBranchesDesc) {
          this.showPublishableBranchesDesc = false;
          this.showVersionNameTemplateDesc = false;
        } else {
          this.showPublishableBranchesDesc = true;
          this.showVersionNameTemplateDesc = false;
        }
      },

      async handleDevelopModeChange(value) {
        let confirmResult;
        try {
          confirmResult = await this.$confirm(
            '确定调整应用开发模式？', '提示',
            {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            });
        } catch(e) {
          //do nothing
        }

        if(!confirmResult) {
          this.appBasicInfo.developMode = 1 - value;
          return;
        }

        this.fullScreenLoading = this.$loading({
          lock: true,
          text: '正在切换中',
          spinner: 'el-icon-loading',
          background: 'rgba(0, 0, 0, 0.7)'
        });


        let formData = new FormData();
        formData.set("appId", this.appId);
        formData.set("developMode", value);

        $http.post($http.api.app.switchDevelopMode, formData).then(response => {

          this.fullScreenLoading.close();
          if(response.status == 200) {
            this.$message({
              type: "success",
              message: "更新成功"
            });

            //跳转刷新页面
            let targetRouter = $utils.getRouter("appSettings");
            if(targetRouter) {
              let targetHref = targetRouter.path;
              targetHref += "?bizId=" + this.bizId + "&appId=" + this.appId + "&activeTab=fourth";
              window.location.href = targetHref;
            }
          } else {
            this.appBasicInfo.developMode = 1 - value;
          }

        }).catch((e) => {
          this.fullScreenLoading.close();
        });
      },

      async handleIntegratedDevChange(newValue){
        let confirmResult;

        if(newValue == false) {
          try {
            confirmResult = await this.$confirm(
              '确人取消【开发集成环境】？', '提示',
              {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
              });
          } catch(e) {
            //do nothing
          }

          if(!confirmResult) {
            this.appBasicInfo.appIntegratedSettings.integratedDevEnabled = !newValue;
            return;
          }
        }

        let formData = new FormData();
        formData.set("appId", this.appId);
        formData.set("integratedDevEnabled", newValue);
        $http.post($http.api.app.switchbleIntegratedEnv, formData).then(response => {

          if(response.status == 200) {
            this.$message({
              type: "success",
              message: "更新成功"
            });
          } else {
            this.appBasicInfo.appIntegratedSettings.integratedDevEnabled = !newValue;
          }

        }).catch((e) => {
          this.appBasicInfo.appIntegratedSettings.integratedDevEnabled = !newValue;
        });
      }
    },
    components: {
      maxPkgUploadManage,
      memberSettings
    }
  };
</script>
<style lang="scss" scoped>
  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .table-box-bs {
    box-sizing: border-box;
    background: #fff;
    height: calc(100% - 30px);

    .table-box-top-bs {
      width: 100%;
      height: calc(100% - 5px)
    }
  }

  .table-box {
    .server-box {
      .header-a {
        .zjlb {
          margin-left: 10px;
          margin-bottom: 5px;
          margin-right: 10px;
          display: inline-block;
        }

        .tjzj {
          width: 55px;
          height: 20px;
          margin-left: 10px;
          margin-bottom: 5px;
          display: inline-block;
          cursor: pointer;
        }

        .tjzj:hover {
          color: #409EFF;
          //  border: 1px solid #409EFF;
          //  box-shadow: 0 0 10px #409EFF;
        }
      }

      .el-tabs--top {
        border: 1px solid #e4e7ed;
      }

      .el-progress {
        width: 70%;
        float: left;
        margin-top: 4px;
      }

      .progressNum {
        width: 25%;
        float: right;
        text-align: left;
      }

    }
  }

  .pzheader {
    height: calc(7% - 4px);
    border-bottom: 1px solid #e4e7ed;
  }

  .pzhg {
    height: calc(20% - 10px);
    min-height: 143px;
    border: 1px solid #e4e7ed;
    margin-bottom: 10px;

    .el-form-item {
      margin-bottom: 0px !important;
    }

  }

  .pzhjxq {
    height: 73%;

    .pzhjxq-s {
      width: calc(33% - 10px);
      min-width: 460px;
      height: 100%;
      border: 1px solid #E8E8E8;
      display: inline-block;
      overflow: hidden;
      /*overflow: auto;*/

      .kf-cs-zs {
        height: 30px;
        background: #e4e7ed;
      }

      .pz-hj-bb {
        height: 50px;
        border-bottom: 1px solid #e4e7ed;

        .pz-hj-bb-block {
          height: 50px;
          width: calc(50% - 10px);
          display: inline-block;
        }

      }

      .content {
        height: calc(100% - 80px);
        /*background: #F8F8F8;*/
      }
    }
  }
</style>
