<template>
  <div class="content-box">
    <div class="page-content-box-width" v-loading="loading"
      element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      element-loading-background="rgba(255,255,255, 0.5)">
      <header-filter @filterChange="filterChange" @exportExcel="exportExcel" :tabTypes="tabTypes"></header-filter>
      <el-tabs type="border-card" v-model="currentTab" class="body-tab">
        <el-tab-pane label="需求质量" name="requirement">
          <el-table :data="requirementTable" stripe>
            <el-table-column prop="time" label="时间" width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="projectName" label="项目" min-width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="sprintCount" label="总迭代数" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.sprintCount > 0" class="c-blue cp" @click="showSprintDialog(scope.row.sprintIds)">{{scope.row.sprintCount}}</span>
                <span v-if="scope.row.sprintCount == 0">{{scope.row.sprintCount}}</span>
              </template>
            </el-table-column>
            <!-- <el-table-column prop="requireCount" label="进行中的迭代" width="100" show-overflow-tooltip></el-table-column> -->
            <el-table-column prop="requireCount" label="总完成需求" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.requireCount > 0" class="c-blue cp" @click="showReqtDialog(scope.row.totalRequireIds)">{{scope.row.requireCount}}</span>
                <span v-if="scope.row.requireCount == 0">{{scope.row.requireCount}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="requireModifyCount" label="需求变更" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.requireModifyCount > 0" class="c-blue cp" @click="showReqtDialog(scope.row.requireModifyIds)">{{scope.row.requireModifyCount}}</span>
                <span v-if="scope.row.requireModifyCount == 0">{{scope.row.requireModifyCount}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="requireInsertCount" label="需求插入" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.requireInsertCount > 0" class="c-blue cp" @click="showReqtDialog(scope.row.requireInsertIds)">{{scope.row.requireInsertCount}}</span>
                <span v-if="scope.row.requireInsertCount == 0">{{scope.row.requireInsertCount}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="requireCancelCount" label="需求取消" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.requireCancelCount > 0" class="c-blue cp" @click="showReqtDialog(scope.row.requireCancelIds)">{{scope.row.requireCancelCount}}</span>
                <span v-if="scope.row.requireCancelCount == 0">{{scope.row.requireCancelCount}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="requireDelayCount" label="需求延期" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.requireDelayCount > 0" class="c-blue cp" @click="showReqtDialog(scope.row.requireDelayIds)">{{scope.row.requireDelayCount}}</span>
                <span v-if="scope.row.requireDelayCount == 0">{{scope.row.requireDelayCount}}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="研发质量" name="development">
          <el-table :data="defectTable" stripe>
            <el-table-column label="日期" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                {{scope.row.searchMonth.display}}
              </template>
            </el-table-column>
            <el-table-column prop="projectName" label="项目" min-width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="total" label="总缺陷" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.total > 0" class="c-blue cp" @click="showDefectDialog(scope.row.totalDefectIds)">{{scope.row.total}}</span>
                <span v-if="scope.row.total == 0">{{scope.row.total}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="lowLevel" label="低级缺陷" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.lowLevel > 0" class="c-blue cp" @click="showDefectDialog(scope.row.lowDefectIds)">{{scope.row.lowLevel}}</span>
                <span v-if="scope.row.lowLevel == 0">{{scope.row.lowLevel}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="average" label="平均处理时长" width="100" show-overflow-tooltip></el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="测试质量" name="test">
          <el-table :data="defectTable" stripe>
            <el-table-column label="日期" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                {{scope.row.searchMonth.display}}
              </template>
            </el-table-column>
            <el-table-column prop="projectName" label="项目" min-width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="total" label="总缺陷" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.total > 0" class="c-blue cp" @click="showDefectDialog(scope.row.totalDefectIds)">{{scope.row.total}}</span>
                <span v-if="scope.row.total == 0">{{scope.row.total}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="ignored" label="测试漏测" width="100" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.ignored > 0" class="c-blue cp" @click="showDefectDialog(scope.row.ignoreDefectIds)">{{scope.row.ignored}}</span>
                <span v-if="scope.row.ignored == 0">{{scope.row.ignored}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="rejected" label="打回的低质量缺陷" width="140" show-overflow-tooltip>
              <template slot-scope="scope">
                <span v-if="scope.row.rejected > 0" class="c-blue cp" @click="showDefectDialog(scope.row.rejectDefectIds)">{{scope.row.rejected}}</span>
                <span v-if="scope.row.rejected == 0">{{scope.row.rejected}}</span>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane label="发布统计" name="deploy">
          <el-table :data="deployTable" stripe>
            <el-table-column prop="bizName" label="业务" min-width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="totalCount" label="总发布" width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="urgentCount" label="紧急发布" width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="overFreqCount" label="超频发布" width="100" show-overflow-tooltip></el-table-column>
            <el-table-column prop="rollBackcount" label="发布失败" width="100" show-overflow-tooltip></el-table-column>
          </el-table>
        </el-tab-pane>
      </el-tabs>
    </div>
    <!--迭代弹窗-->
    <el-dialog title="迭代详情" :visible.sync="sprintVisibility" width="750px" :before-close="closeSprint">
      <el-table :data="sprintDialogTableInfo.slice((sprintPageInfo.pageNum-1)*sprintPageInfo.pageSize,
                          sprintPageInfo.pageNum*sprintPageInfo.pageSize)" stripe>
        <el-table-column prop="name" label="名称" min-width="200" show-overflow-tooltip></el-table-column>
        <el-table-column prop="sprintDesc" label="描述" width="200" show-overflow-tooltip></el-table-column>
        <el-table-column prop="chargeUser" label="负责人" width="100" show-overflow-tooltip></el-table-column>
        <el-table-column prop="startTime" label="开始日期" width="100" show-overflow-tooltip>
        </el-table-column>
        <el-table-column prop="endTime" label="结束日期" width="100" show-overflow-tooltip></el-table-column>
      </el-table>
      <div class="pageModule">
        <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="sprintSizeChange"
                       @current-change="sprintCurChange"
                       :current-page="sprintPageInfo.pageNum"
                       :page-size="sprintPageInfo.pageSize"
                       :total="sprintPageInfo.total"
                       layout="total, prev, pager, next">
        </el-pagination>
      </div>
    </el-dialog>
    <!--需求弹窗-->
    <el-dialog title="需求详情" :visible.sync="reqtVisibility" width="1000px" :before-close="closeReqt">
      <el-table :data="reqtDialogTableInfo.slice((reqtPageInfo.pageNum-1)*reqtPageInfo.pageSize,
                          reqtPageInfo.pageNum*reqtPageInfo.pageSize)" stripe>
        <el-table-column prop="display.title" label="标题" min-width="230" show-overflow-tooltip>
          <template slot-scope="scope">
            <span class="c-blue cp" @click="jump2Reqt(scope.row.projectId, scope.row.id)">{{scope.row.display.title}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="display.priority" label="优先级" min-width="60" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.sprint" label="迭代" min-width="120" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.status" label="状态" min-width="80" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.assignUser" label="处理人" min-width="80" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.category" label="需求分类" min-width="100" show-overflow-tooltip></el-table-column>
        <el-table-column prop="startTime" label="预计开始时间" min-width="90" show-overflow-tooltip></el-table-column>
        <el-table-column prop="endTime" label="预计结束时间" min-width="90" show-overflow-tooltip></el-table-column>
      </el-table>
      <div class="pageModule">
        <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="reqtSizeChange"
                       @current-change="reqtCurChange"
                       :current-page="reqtPageInfo.pageNum"
                       :page-size="reqtPageInfo.pageSize"
                       :total="reqtPageInfo.total"
                       layout="total, prev, pager, next">
        </el-pagination>
      </div>
    </el-dialog>
    <!--缺陷弹窗-->
    <el-dialog title="缺陷详情" :visible.sync="defectVisibility" width="1200px" :before-close="closeDefect">
      <el-table :data="defectDialogTableInfo.slice((defectPageInfo.pageNum-1)*defectPageInfo.pageSize,
                          defectPageInfo.pageNum*defectPageInfo.pageSize)" stripe>
        <el-table-column prop="display.title" label="标题" min-width="350" show-overflow-tooltip>
          <template slot-scope="scope">
            <span class="c-blue cp" @click="jump2Defect(scope.row.projectId, scope.row.id)">{{scope.row.display.title}}</span>
          </template>
        </el-table-column>
        <el-table-column prop="display.priority" label="严重程度" width="80" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.status" label="状态" width="60" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.cause" label="缺陷原因" width="80" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.sprint" label="所属迭代" width="120" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.assignUser" label="处理人" width="70" show-overflow-tooltip></el-table-column>
        <el-table-column prop="display.createUser" label="创建人" width="70" show-overflow-tooltip></el-table-column>
        <el-table-column prop="createTime" label="创建时间" width="160" show-overflow-tooltip></el-table-column>
        <el-table-column prop="updateTime" label="修改时间" width="160" show-overflow-tooltip></el-table-column>
      </el-table>
      <div class="pageModule">
        <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="defectSizeChange"
                       @current-change="defectCurChange"
                       :current-page="defectPageInfo.pageNum"
                       :page-size="defectPageInfo.pageSize"
                       :total="defectPageInfo.total"
                       layout="total, prev, pager, next">
        </el-pagination>
      </div>
    </el-dialog>
  </div>
</template>
<script>
/**
 * @title 
 * @desc 
 * @author heyunjiang
 * @date 
 */
import HeaderFilter from './HeaderFilter'
import StringView from '@/components/commonComponents/StringView'

export default {
  name: "metric",
  components: {
    HeaderFilter
  },
  mixins: [],
  props: {},
  data() {
    return {
      sprintPageInfo: {pageNum: 1, pageSize: 10, total: 0},
      reqtPageInfo: {pageNum: 1, pageSize: 10, total: 0},
      defectPageInfo: {pageNum: 1, pageSize: 10, total: 0},
      defectDialogTableInfo: [],
      defectVisibility: false,
      reqtVisibility: false,
      sprintDialogTableInfo: [],
      reqtDialogTableInfo: [],
      sprintVisibility: false,
      filterInfo: {}, // 临时存储的过滤信息
      requirementTable: [], // 需求质量
      defectTable: [], // 研发质量、测试质量
      deployTable: [], // 发布统计
      currentTab: 'requirement',
      loading: false
    }
  },
  computed: {
    // 用于切换 filter 过滤数据
    tabTypes() {
      return this.currentTab === 'deploy' ? 'biz' : 'project';
    }
  },
  watch: {
    // 当 tab 切换时，需要获取 table 数据
    currentTab() {
      this.tableInit()
    }
  },
  created() { },
  methods: {
    closeSprint() {
      this.sprintVisibility = false
      this.sprintPageInfo.pageNum = 1
    },
    closeReqt() {
      this.reqtVisibility = false
      this.reqtPageInfo.pageNum = 1
    },
    closeDefect() {
      this.defectVisibility = false
      this.defectPageInfo.pageNum = 1
    },
    jump2Reqt(projectId, reqtId) {
      let url = "/requirement/list?projectId="+ projectId +"&requireId=" + reqtId
      window.open(url, '_blank');
    },
    jump2Defect(projectId, defectId) {
      let url = "/bugList/list?projectId="+ projectId+ "&bugId=" + defectId
      window.open(url, '_blank');
    },
    sprintSizeChange(val) {
      this.sprintPageInfo.pageSize = val
    },
    sprintCurChange(val) {
      this.sprintPageInfo.pageNum = val
    },
    reqtSizeChange(val) {
      this.reqtPageInfo.pageSize = val
    },
    reqtCurChange(val) {
      this.reqtPageInfo.pageNum = val
    },
    defectSizeChange(val) {
      this.defectPageInfo.pageSize = val
    },
    defectCurChange(val) {
      this.defectPageInfo.pageNum = val
    },

    showSprintDialog(val) {
      let idsStr = "";
      if (val != null && val.length != 0) {
        idsStr = val.join(",");
      }
      $http.get($http.api.sprint.query_ids ,{idsStr: idsStr}).then((res) => {
        this.sprintDialogTableInfo = res.data
        this.sprintPageInfo.total = this.sprintDialogTableInfo.length
        this.sprintVisibility = true
      }).catch(e => {
        this.$message({message: '获取迭代信息失败！', type: 'error'})
      })
    },
    showReqtDialog(val) {
      let idsStr = "";
      if (val != null && val.length != 0) {
        idsStr = val.join(",");
      }
      $http.get($http.api.requirement.list ,{idsStr: idsStr}).then((res) => {
        this.reqtDialogTableInfo = res.data
        this.reqtPageInfo.total = this.reqtDialogTableInfo.length
        this.reqtVisibility = true
      }).catch(e => {
        this.$message({message: '获取需求信息失败！', type: 'error'})
      })
    },
    showDefectDialog(val) {
      let idsStr = "";
      if (val != null && val.length != 0) {
        idsStr = val.join(",");
      }
      $http.get($http.api.defect.list, {idsStr: idsStr}).then((res) => {
        this.defectDialogTableInfo = res.data
        this.defectPageInfo.total = this.defectDialogTableInfo.length
        this.defectVisibility = true
      }).catch(e => {
        this.$message({message: '获取缺陷信息失败！', type: 'error'})
      })
    },
    // 过滤条件验证
    validator() {
      // 过滤信息校验
      try {
        if(this.filterInfo.searchMonths === null) {return false;}
      } catch(_) {
        return false;
      }
      return true;
    },
    // table 数据更新
    tableInit() {
      if(!this.validator()) {return ;}
      
      switch(this.currentTab) {
        case 'requirement': this.getRequirementTable();break;
        case 'development': this.getDefectTable();break;
        case 'test': this.getDefectTable();break;
        case 'deploy': this.getDeployTable();break;
        default: ;
      }
    },
    // 获取需求质量
    async getRequirementTable() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.post($http.api.metric.requirement_info, {
          ...this.filterInfo,
          searchMonths: [this.filterInfo.searchMonths]
        });
      } finally {
        this.loading = false;
      }
      if(!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取需求质量数据失败',
          type: 'error'
        })
        return ;
      }
      this.requirementTable = result.data || [];
    },
    // 获取研发质量、测试质量
    async getDefectTable() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.post($http.api.metric.defect, {
          ...this.filterInfo,
          searchMonths: [this.filterInfo.searchMonths]
        });
      } finally {
        this.loading = false;
      }
      if(!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取研发质量、测试质量数据失败',
          type: 'error'
        })
        return ;
      }
      this.defectTable = result.data || [];
    },
    // 获取发布统计
    async getDeployTable() {
      let result = {}
      try {
        this.loading = true;
        result = await $http.get($http.api.metric.biz_info, {
          yearMonthStr: this.filterInfo.searchMonths,
          bizIdsStr: this.filterInfo.bizIds.join(',')
        });
      } finally {
        this.loading = false;
      }
      if(!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取发布统计数据失败',
          type: 'error'
        })
        return ;
      }
      this.deployTable = result.data || [];
    },
    // 导出 excel
    exportExcel() {
      if(!this.validator()) {
        this.$message({
          message: '请先选择过滤条件，再点击导出',
          type: 'warning'
        })
        return ;
      }
      const filterInfo = {
        projectIds: [],
        searchMonths: [this.filterInfo.searchMonths]
      };
      const exportUrl = $http.api.metric.exportAll.url;
      // switch(this.currentTab) {
      //   case 'requirement': filterInfo = {
      //     ...this.filterInfo, 
      //     searchMonths: [this.filterInfo.searchMonths]
      //   };exportUrl = $http.api.metric.exportRequirement.url;break;
      //   case 'development': filterInfo = {
      //     ...this.filterInfo, 
      //     searchMonths: [this.filterInfo.searchMonths]
      //   };exportUrl = $http.api.metric.exportDefect.url;break;
      //   case 'test': filterInfo = {
      //     ...this.filterInfo, 
      //     searchMonths: [this.filterInfo.searchMonths]
      //   };exportUrl = $http.api.metric.exportDefect.url;break;
      //   case 'deploy': filterInfo = {
      //     yearMonthStr: this.filterInfo.searchMonths,
      //     bizIdsStr: this.filterInfo.bizIds.join(',')
      //   };exportUrl = $http.api.metric.exportBiz.url;break;
      //   default: ;
      // }
      this.fileDownLoadForGet(exportUrl, filterInfo);
    },
    // 过滤条件变更
    filterChange(filterInfo) {
      this.filterInfo = filterInfo;
      this.tableInit();
    }
  }
}
</script>
<style lang="scss" scoped>
  .content-box {
    .page-content-box-width {
      margin-top: 10px;
      padding: 10px 20px 20px;
      background: #f2f2f2;
      .body-tab {
        margin-top: 10px;
      }
    }
  }
  .pageModule {
    overflow: hidden;
  }
  
</style>
