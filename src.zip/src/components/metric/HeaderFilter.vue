<template>
  <header>
    <el-select v-model="filterInfo.searchMonths" @change="filterChange" class="month-select" placeholder="请选择月份">
      <el-option :label="item.display" :value="item.key" v-for="item in monthList" :key="item.key"></el-option>
      <!-- <el-option label="201907" value="201907"></el-option> -->
    </el-select>
    <el-select v-model="filterInfo.projectIds" v-show="tabTypes === 'project'" @change="filterChange" multiple placeholder="请选择项目">
      <el-option label="全部" value="all"></el-option>
      <el-option :label="item.name" :value="item.id" v-for="item in projectList" :key="item.id"></el-option>
    </el-select>
    <el-select v-model="filterInfo.bizIds" v-show="tabTypes === 'biz'" @change="filterChange" multiple placeholder="请选择业务">
      <el-option label="全部" value="all"></el-option>
      <el-option :label="item.bizName" :value="item.bizId" v-for="item in bizList" :key="item.bizId"></el-option>
    </el-select>
    <el-button type="primary" class="export-excel" :disabled="!canExport" @click="exportExcel">导出Excel</el-button>
  </header>
</template>
<script>
/**
 * @title 
 * @desc 
 * @author heyunjiang
 * @date 
 */
import { mapState } from 'vuex'

export default {
  name: "HeaderFilter",
  components: {},
  mixins: [],
  props: {
    tabTypes: {
      type: String,
      required: false,
      default: 'project',
      desc: '当前 tab 类型',
      validator: (value) => {
        return ['project', 'biz'].includes(value)
      }
    }
  },
  data() {
    return {
      filterInfo: {
        searchMonths: null,
        projectIds: ['all'],
        bizIds: ['all']
      },
      monthList: [],
      bizList: [],
      bizListPageInfo: {
        pageNum: 1,
        pageSize: 100  // 目前所有需要分页的下拉框都是获取 100 条，后续需要做持续加载
      },
      projectListPageInfo: {
        pageNumber: 1,
        pageSize: 100
      },
      loading: false
    }
  },
  computed: {
    ...mapState({
      projectInfo: state => state.pf.ProjectInfo.unCompleted, // 获取进行中项目的列表信息
    }),
    projectList() {
      return this.projectInfo.ProjectList.slice(0, this.projectListPageInfo.pageNumber * this.projectListPageInfo.pageSize);
    },
    canExport() {
      return this.filterInfo.searchMonths !== null;
    }
  },
  watch: {
    tabTypes() {
      switch(this.tabTypes) {
        case 'project': this.getProjectList();break;
        case 'biz': this.getBizList();break;
        default: ;
      }
    }
  },
  mounted() {
    this.getMonthsAvaliable();
    this.getProjectList();
  },
  methods: {
    // 月份、项目变化时
    filterChange() {
      let projectIds = this.filterInfo.projectIds, bizIds = this.filterInfo.bizIds;
      if(projectIds[projectIds.length - 1] === 'all') {
        this.filterInfo.projectIds = ['all'];
      } else if(projectIds.includes('all')&&projectIds.length>1) {
        this.filterInfo.projectIds = projectIds.filter(item => item !== 'all')
      }
      if(bizIds[bizIds.length - 1] === 'all') {
        this.filterInfo.bizIds = ['all'];
      } else if(bizIds.includes('all')&&bizIds.length>1) {
        this.filterInfo.bizIds = bizIds.filter(item => item !== 'all')
      }
      this.$nextTick(this.sendDateChangeEvent);
    },
    sendDateChangeEvent() {
      this.$emit('filterChange', {
        ...this.filterInfo,
        projectIds: this.filterInfo.projectIds.includes('all')?[]:this.filterInfo.projectIds,
        bizIds: this.filterInfo.bizIds.includes('all')?[]:this.filterInfo.bizIds,
      });
    },
    exportExcel() {
      this.$emit('exportExcel');
    },
    // 获取今天
    getToday() {
      const today = new Date();
      const month = '0' + (today.getMonth() + 1);
      return today.getFullYear() + (month.length===2?month:month.slice(1, 2));
    },
    // 获取可选择月份列表
    async getMonthsAvaliable() {
      let result = {}
      try {
        result = await $http.get($http.api.metric.months);
      } catch (_) {}
      if(!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取可选择月份数据失败',
          type: 'error'
        })
        return ;
      }
      this.monthList = result.data;
      if(this.monthList.some(item => item.key === this.getToday())) {
        this.filterInfo.searchMonths = this.getToday();
        this.$nextTick(this.sendDateChangeEvent);
      } else {
        this.filterInfo.searchMonths = result.data.length > 0 ? result.data[0].key : null;
      }
    },
    // 获取项目列表数据，分页信息依赖当前组件的 projectListPageInfo
    async getProjectList() {
      this.loading = true;
      await this.$store.dispatch({ type: 'getProjectList', payload: {
        type: 'unCompleted',
        pageInfo: this.projectListPageInfo
      } })
      this.loading = false;
    },
    // 获取业务列表数据
    async getBizList() {
      let result = {}
      try {
        result = await $http.get($http.api.biz.getBizList, {...this.bizListPageInfo});
      } catch (_) {}
      if(!result.status || result.status !== 200) {
        this.$message({
          message: result.msg || '获取业务列表数据失败',
          type: 'error'
        })
        return ;
      }
      this.bizList = result.data.list || [];
    }
  }
}
</script>
<style lang="scss" scoped>
header {
  .month-select {
    width: 140px;
    vertical-align: top;
  }
  .export-excel {
    float: right;
  }
}
</style>
