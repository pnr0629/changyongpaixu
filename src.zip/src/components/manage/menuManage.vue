<template>
  <div id="manage-box" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar">
        <span class="function-bar-title ml10 mr10 fl">菜单管理</span>
        <el-select placeholder="选择功能" class="function-bar-select po-re-top-1" v-model="menuType" @change="handleMenuTypeChange">
          <el-option v-for="item in defaultMenuList" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
      </div>
      <!--菜单列表-->
      <div class="ml10 menu-list-box">
        <div>
          <h3 class="ml10">菜单列表</h3>
        </div>
        <div>
          <el-tree @node-click="handleNodeClick" :data="menuList" default-expand-all :props="defaultProps" highlight-current
                   :expand-on-click-node="false" node-key="id" ref="tree" class="menu-list-box-tree"/>
        </div>
      </div>

      <!--菜单信息-->
      <div class="menu-info-box">
        <div>
          <h3 class="ml10" @contextmenu.preven="">菜单信息</h3>
        </div>
        <div class="form-iterm-box">
          <el-form :model="menuInfo" ref="menuInfoForm" label-width="100px" label-position="right">
            <el-form-item label="菜单ID:" class="mb15" prop="menuId" :rules="rules.menuId">
              <el-input v-model="menuInfo.menuId" width="500px" placeholder="请输入菜单ID" disabled/>
            </el-form-item>
            <el-form-item label="菜单名称:" class="mb20" prop="menuName" :rules="rules.menuName">
              <el-input v-model="menuInfo.menuName" placeholder="请输入菜单名称"></el-input>
            </el-form-item>
            <el-form-item label="菜单链接:" class="mb15">
              <el-input placeholder="请输入菜单链接" v-model="menuInfo.url"></el-input>
            </el-form-item>
            <el-form-item label="排序值:" class="mb15" prop="rank" :rules="rules.rank">
              <el-input placeholder="请输入排序值，必须为数字" v-model="menuInfo.rank"></el-input>
            </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer menu-info-box-footer">
            <el-button type="primary" @click="updateMenu">保存</el-button>
            <el-button type="info" @click="delMenu">删除</el-button>
            <el-button type="success" @click="addSubMenu">添加子菜单</el-button>
          </span>
        </div>
      </div>

      <!--功能列表-->
      <div class="function-list-box">
        <div>
          <h3 class="ml10" @contextmenu.preven="">功能列表</h3>
        </div>
        <el-transfer filterable filter-placeholder="请输入功能名称" v-model="selectedFuncitonList" :data="allFunctionList"
                     :props="funcProps" :titles="['未选择功能', '已选择功能']"/>
        <span slot="footer" class="dialog-footer function-list-box-footer">
          <el-button type="primary" @click="saveMenu2Func">保存</el-button>
        </span>
      </div>
    </div>

    <!--添加子菜单弹窗-->
    <el-dialog
      title="添加子菜单"
      :visible.sync="addSubMenuDialogVisible"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="menuAddInfo" ref="addSubMenuForm" label-width="100px" label-position="right">
          <el-form-item label="菜单ID:" class="mb15" prop="menuId" :rules="rules.menuId">
            <el-input v-model="menuAddInfo.menuId" placeholder="请输入菜单ID"></el-input>
          </el-form-item>
          <el-form-item label="菜单名称:" class="mb20" prop="menuName" :rules="rules.menuName">
            <el-input v-model="menuAddInfo.menuName" placeholder="请输入菜单名称"></el-input>
          </el-form-item>
          <el-form-item label="菜单链接:" class="mb15">
            <el-input placeholder="请输入菜单链接" v-model="menuAddInfo.url"></el-input>
          </el-form-item>
          <el-form-item label="排序值:" class="mb15" prop="rank" :rules="rules.rank">
            <el-input placeholder="请输入排序值，必须为数字" v-model="menuAddInfo.rank"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeMenuAddDialog">关闭</el-button>
        <el-button type="primary" @click="saveMenu">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "MenuManage",
    data() {
      let validRank = (rule, value, callback) => {
        let pattren = /^(\-)?\d+$/;
        if (pattren.test(value)) {
          callback();
        }
        callback(new Error("请输入数字"));
      };
      let validValue = (rule, value, callback) => {
        if (value && (value.trim() != '') && (!value.startsWith(' '))) {
          callback();
        }
        callback(new Error("请去除空格等无用字符"));
      };
      return {
        currentKey: '',
        rules: {
          menuName: [{required: true, message: '菜单名称不能为空', trigger: 'blur'},{validator: validValue, trigger: 'blur'}],
          menuId: [{required: true, message: '菜单ID不能为空', trigger: 'blur'},{validator: validValue, trigger: 'blur'}],
          rank: [{required: true, message: '排序值不能为空', trigger: 'blur'},{validator: validRank, trigger: 'blur'}]
        },
        funcProps: {
          key: 'functionId',
          label: 'functionName'
        },
        addSubMenuDialogVisible: false,
        defaultProps: {
          children: 'children',
          label: 'name',
        },
        menuType: 0,
        defaultMenuList: [
          {id: 0, name:'系统菜单'},
          {id: 1, name:'业务菜单'},
          {id: 2, name:'应用菜单'},
          {id: 3, name:'项目菜单'},
        ],
        menuList: [],
        menuAddInfo: {
          menuId: '',
          menuName: '',
          url: '',
          rank: 0
        },
        menuInfo: {
          menuId: '',
          menuName: '',
          url: '',
          rank: 0
        },
        allFunctionList: [],
        selectedFuncitonList: []
      };
    },

    mounted() {
      this.getMenuList(this.menuType);
    },

    methods: {
      setCurrentKey() {
        this.$refs['tree'].setCurrentKey(this.currentKey);
      },
      saveMenu2Func() {
        if (!this.menuInfo.menuId) {
          this.$message({message: '请选择一个菜单！', type: 'error'});
          return;
        }
        let param = {};
        let idsStr = '';
        param.menuId = this.menuInfo.menuId;
        let selectedFunIds = this.selectedFuncitonList;
        if (!selectedFunIds || selectedFunIds.length == 0) {
          idsStr = '';
        }
        idsStr = selectedFunIds.join(",");
        param.functionIds = idsStr;
        $http.get($http.api.menu_manage.save_menu_2_func, param).then(res => {
          if (res.status == 200) {
            this.$message({message: '绑定功能成功！', type: 'success'});
            this.getMenuList(this.menuType);
          } else {
            this.$message({message: '绑定功能失败！', type: 'error'});
          }
        }).catch(_ => {})
      },
      delMenu() {
        if (!this.menuInfo.menuId) {
          this.$message({message: '请选择一个菜单！', type: 'error'});
          return;
        }
        this.$confirm('确认删除[' + this.menuInfo.menuName + ']菜单吗？').then(_ => {
          let param = {};
          param.menuId = this.menuInfo.menuId;
          $http.get($http.api.menu_manage.del_menu, param).then(res => {
            if (res.status == 200) {
              this.$message({message: '删除菜单成功', type: 'success'});
              this.getMenuList(this.menuType);
              this.menuInfo = {};
            } else {
              this.$message({message: '删除菜单失败，' + res.msg, type: 'error'});
            }
          }).catch(_ => {})
        }).catch(_ => {});
      },
      closeMenuAddDialog() {
        this.addSubMenuDialogVisible = false;
      },
      addSubMenu() {
        this.menuAddInfo = {};
        this.addSubMenuDialogVisible = true;
      },
      saveMenu() {
        this.$refs['addSubMenuForm'].validate(validate => {
          if (validate) {
            let param = this.menuAddInfo;
            param.menuType = this.menuType;
            param.parentMenuId = this.menuInfo.menuId;
            $http.post($http.api.menu_manage.save_munu, param).then(res => {
              if (res.status == 200) {
                this.addSubMenuDialogVisible = false;
                this.getMenuList(this.menuType);
                this.$message({message: '添加子菜单成功', type: 'success'});
              }
            }).catch(_ => {})
          }
        })
      },
      updateMenu() {
        if (!this.menuInfo.menuId) {
          this.$message({message: '请选择一个菜单！', type: 'error'});
          return;
        }
        this.$refs['menuInfoForm'].validate(validate => {
          if (validate) {
            $http.get($http.api.menu_manage.update_menu, this.menuInfo).then(res => {
              if (res.status == 200) {
                this.$message({message: '更新菜单成功', type: 'success'});
                this.getMenuList(this.menuType);
              } else {
                this.$message({message: '更新菜单失败', type: 'error'});
              }
            }).catch(_ => {})
          }
        })
      },
      handleMenuTypeChange(val) {
        this.currentKey = '';
        this.getMenuList(val);
        this.menuInfo = {};
        this.allFunctionList = [];
        this.selectedFuncitonList = [];
      },
      getMenuList(menuType) {
        let param = {};
        param.menuType = menuType;
        $http.get($http.api.menu_manage.get_menu_list, param).then(res => {
          if (res.status == 200) {
            this.menuList = res.data;
          } else {
            this.$message({message: '获取菜单列表失败', type: 'error'});
          }
          this.$nextTick(() => {
            this.setCurrentKey();
          })
        }).catch(_ => {})
      },
      handleNodeClick(data, node, self) {
        this.currentKey = data.id;
        this.menuInfo.menuId = data.id;
        this.menuInfo.menuName = data.name;
        this.menuInfo.url = data.url;
        this.menuInfo.rank = data.rank;

        let param = {};
        param.menuId = data.id;
        param.menuType = this.menuType;
        $http.get($http.api.menu_manage.menu_func_list, param).then(res => {
          if (res.status == 200) {
            this.allFunctionList = res.data.allList;
            let seledList = res.data.selectedList;
            let selIds = [];
            seledList.forEach(item => {
              selIds.push(item.functionId);
            })
            this.selectedFuncitonList = selIds;
          }
        }).catch(_ => {})
      }
    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  @import 'manageCommon';

  .menu-list-box {
    float: left;
    height: 100%;
    .menu-list-box-tree {
      background-color: #dcf1d9;
      width: 300px;
      white-space: nowrap;
    }
  }
  .menu-info-box {
    margin-left: 100px;
    display: inline-block;
    width: 667px;
    .menu-info-box-footer {
      margin-left: 200px;
    }
  }
  .function-list-box {
    margin-left: 410px;
    .function-list-box-footer {
      margin-left: 600px;
    }
  }

  .issuedialog {
    .addclassTap {
      height: 40px;
      margin-bottom: 10px;
      border-bottom: 2px solid #d8dee5;

      .tapTitile {
        font-size: 16px;
        font-weight: 400;
      }

      .addtap {
        float: right;
      }
    }

    .tabtable {
      height: 490px;
      //   background: red;
    }
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .paintermouse {
    cursor: pointer;
  }

  .paintermouse:hover {
    color: #409eff;
  }
</style>
