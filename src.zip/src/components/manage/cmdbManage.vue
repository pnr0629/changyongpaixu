<template>
  <div id="manage-box" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar">
        <span class="function-bar-title ml10 mr10 fl">CMDB绑定列表</span>
        <el-input v-model="search" class="function-bar-input fl" placeholder="请输入关键字" clearable></el-input>
        <el-button type="primary" class="ml10" @click="getCmdbData()">查询</el-button>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-outer-style">
            <div class="table-box">
              <div class="table-box-top">
                <el-table :data="cmdbData.list" border class="table-full">
                  <el-table-column prop="appCode" label="应用ID" min-width="100"></el-table-column>
                  <el-table-column prop="bizName" label="所属业务" min-width="100"></el-table-column>
                  <el-table-column prop="cmdbId" label="CMDB_ID" min-width="100"></el-table-column>
                  <el-table-column prop="cmdbPath" label="CMDB_PATH" min-width="300"></el-table-column>
                  <el-table-column label="操作" min-width="60">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="showEditCmdbDialog(scope.row)">编辑</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10 pageination-top" @size-change="handleAppSizeChange"
                  @current-change="handleAppPageChange" :current-page="cmdbData.pageNum" :page-sizes="[10, 20, 30]"
                  :page-size="cmdbData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="cmdbData.total">
                </el-pagination>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>


    <el-dialog title='绑定CMDB' :visible.sync="dialogCmdbVisible" class="el-dialog-640w issuedialog"
      :modal-append-to-body="false" :close-on-click-modal='false'>
      <div class="form-iterm-box">
            <el-form>
              <el-form-item label="应用ID" class="mb15" label-width="80px">
                <el-input v-model="cmdbBind.appCode" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item label="CMDB" class="mb15" label-width="80px">
                <el-select v-model="cmdbBind.cmdbIdArr" multiple filterable remote placeholder="请输入CMDB分类查找"
                  :remote-method="cmdbPathQuery" :loading="loading" class="cmdb-dialog-select-width">
                  <el-option v-for="item in cmdbPathList" :key="item.cmdbId" :label="item.cmdbPath" :value="item.cmdbId">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleSetCmdbDialogClose">关闭</el-button>
        <el-button type="primary" @click="saveCmdbBind">保存</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  export default {
    name: 'CmdbManage',
    data() {
      return {
        cmdbData: {
          pageNum: 1,
          pageSize: 20,
          total: 0,
          list: []
        },
        pageSize: 20,
        page: 1,
        dialogCmdbVisible: false,
        cmdbBind: {
          cmdbIdArr: []
        },
        cmdbPathList: [],
        loading: false,
        search: ''
      }
    },

    mounted() {
      this.getCmdbData()
    },

    methods: {
      handleAppSizeChange(val) {
        this.pageSize = val;
        this.getCmdbData()
      },
      handleAppPageChange(val) {
        this.page = val
        this.getCmdbData()
      },

      //打开编辑cmdb绑定窗口
      showEditCmdbDialog(val) {
        this.dialogCmdbVisible = true;
        this.cmdbBind.appCode = val.appCode;
        this.cmdbBind.appId = val.appId;
        this.cmdbPathList = [];
        this.cmdbBind.cmdbIdArr = [];
        const initWord='a';
        $http.get($http.api.cmdb.search, { keyWord: initWord }).then((res) => {
          this.cmdbPathList = res.data;
          if (val.cmdbId) {
            let tempCmdbPath = val.cmdbPath.split(",");
            let tempCmdbId = val.cmdbId.split(",");

            tempCmdbId.forEach((v, i) => {
              this.cmdbPathList[i] = {}
              this.cmdbPathList[i].cmdbId = v;
              this.cmdbPathList[i].cmdbPath = tempCmdbPath[i];

            })

            this.cmdbBind.cmdbIdArr = tempCmdbId;
          }
        })

      },

      //获取cmdb列表
      getCmdbData() {
        $http.get($http.api.cmdb.list, {appCode: this.search, pageNum: this.page, pageSize: this.pageSize }).then((res) => {
          this.cmdbData = res.data;
        })
      },

      //关闭cmdb的窗口
      handleSetCmdbDialogClose() {
        this.dialogCmdbVisible = false;
      },

      //保存
      saveCmdbBind() {
        let formData = new FormData();
        formData.append('appId', this.cmdbBind.appId);
        formData.append('cmdbIdArr[]', this.cmdbBind.cmdbIdArr);

        $http.post($http.api.cmdb.save_bind, formData).then((res) => {
          this.$message({
            type: 'success',
            message: '保存成功!'
          });

          this.handleSetCmdbDialogClose();
          this.getCmdbData();
        })
      },

      //获取所有的cmdb分类列表
      cmdbPathQuery(query) {
        if (query !== '') {
          this.loading = true;
          setTimeout(() => {
            $http.get($http.api.cmdb.search, { keyWord: query }).then((res) => {
              this.cmdbPathList = res.data;
              this.loading = false;
            })
          }, 200);
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'manageCommon';

  .cmdb-dialog-select-width {
    width: 100%;
  }
</style>
