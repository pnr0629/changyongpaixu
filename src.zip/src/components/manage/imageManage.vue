<template>
  <div id="bizList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar" style="border-bottom:2px solid #d6d9e0">
        <span style="float:left;margin-left:10px;margin-top:5px;margin-right:10px;font-size:16px;color:#606266">镜像管理</span>
      </div>
      <!--镜像类型-->
      <div style="display: inline-block;float: left;height: 100%" class="ml10">
        <div>
          <h3 class="ml10">镜像类型</h3>
          <el-button style="display: inline-block" type="primary" @click="addSubMenu">添加镜像类型</el-button>
        </div>
        <div>
          <el-tree @node-click="handleNodeClick" :data="typeList" default-expand-all :props="defaultProps" highlight-current
                   :expand-on-click-node="false" node-key="typeId" ref="tree" style="background-color:#dcf1d9;width: 300px;white-space:nowrap"/>
        </div>
      </div>

      <!--镜像类型信息-->
      <div style="margin-left: 100px;display: inline-block;width: 667px">
        <div>
          <h3 class="ml10" @contextmenu.preven="">镜像类型信息</h3>
        </div>
        <div class="form-iterm-box">
          <el-form :model="typeInfo" ref="menuInfoForm" label-width="100px" label-position="right">
            <el-form-item label="镜像类型ID:" class="mb15" prop="menuId" v-show="false">
              <el-input v-model="typeInfo.typeId" width="500px" placeholder="请输入菜单ID" disabled/>
            </el-form-item>
            <el-form-item label="类型名称:" class="mb20" prop="typeName" :rules="{required: true, message: '镜像类型名称不能为空', trigger: 'blur'}">
              <el-input v-model="typeInfo.typeName" placeholder="请输入菜单名称"></el-input>
            </el-form-item>
            <el-form-item label="类型描述:" class="mb15" prop="typeDesc" :rules="{required: true, message: '镜像类型描述不能为空', trigger: 'blur'}">
              <el-input placeholder="请输入菜单链接" v-model="typeInfo.typeDesc"></el-input>
            </el-form-item>
            <el-form-item label="是否私有:" class="mb15" prop="typePrivate" :rules="{ required: true, message: '请选择所有权' , trigger: 'blur'}">
              <el-radio-group v-model="typeInfo.typePrivate" >
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="用途类别:" class="mb15" prop="typePurpose" :rules="{required: true, message: '用途类别不能为空', trigger: 'blur'}">
              <el-select v-model="typeInfo.typePurpose" placeholder="请选择" style="width: 547px">
                <el-option label="构建" :value="0"/>
                <el-option label="上传至ceph" :value="1"/>
                <el-option label="推送至harbor" :value="2"/>
              </el-select>
            </el-form-item>
            <el-form-item label="构建方式:" class="mb15" prop="compileType" v-if = 'typeInfo.typePurpose==0' :rules="{required: true, message: '构建方式不能为空', trigger: 'blur'}">
              <el-select v-model="typeInfo.compileType" placeholder="请选择" style="width: 547px">
                <el-option v-for="item in compileMethodOptions" :key="item.key"  :label="item.key" :value="item.value">
                </el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <span slot="footer" class="dialog-footer" style="margin-left: 200px">
            <el-button type="primary" @click="updateMenu">保存</el-button>
            <el-button type="info" @click="delMenu">删除</el-button>
          </span>
        </div>
      </div>

      <!--镜像列表-->
      <div style="margin-left: 410px;">
        <div>
          <h3 class="ml10" @contextmenu.preven="">镜像列表</h3>
          <el-button style="display: inline-block" type="primary" @click="showAddImageDialog">添加镜像</el-button>
        </div>
        <el-table :data="imageList" style="width:100%;height:100%;overflow:auto;">
          <el-table-column prop="imageRepo" label="镜像仓库" min-width="100"></el-table-column>
          <el-table-column prop="imageTag" label="镜像标签" min-width="100"></el-table-column>
          <el-table-column label="操作" min-width="120">
            <template slot-scope="scope">
              <span class="c-blue cp" v-if="compileTypePrivate == 1 "@click="showBindImageDialog(scope.row)">绑定</span>
              <span class="c-blue cp" style="padding: 4px" @click="delImage(scope.row)">删除</span>
              <span class="c-blue cp" style="padding: 4px" v-if="scope.row.stable == 0" @click="checkImageStable(scope.row)">设为稳定版本</span>
              <span class="c-blue cp" style="padding: 4px" v-if="scope.row.stable == 1" @click="setImageContainerUp(scope.row)">{{scope.row.containerUp==0?'保留构建环境':'不保留构建环境'}}</span>
            </template>
          </el-table-column>
        </el-table>

      </div>
    </div>

    <!--添加镜像类型弹窗-->
    <el-dialog
      title="添加镜像类型"
      :visible.sync="addSubMenuDialogVisible"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="menuAddInfo" ref="addSubMenuForm" label-width="110px" label-position="right">
          <el-form-item label="镜像类型名称:" class="mb15" prop="typeName" :rules="{required: true, message: '镜像类型名称不能为空', trigger: 'blur'}">
            <el-input v-model="menuAddInfo.typeName" placeholder="请输入镜像类型名称"></el-input>
          </el-form-item>
          <el-form-item label="镜像类型描述:" class="mb20" prop="typeDesc" :rules="{required: true, message: '镜像类型描述不能为空', trigger: 'blur'}">
            <el-input v-model="menuAddInfo.typeDesc" placeholder="请输入镜像类型描述"></el-input>
          </el-form-item>
          <el-form-item label="是否私有:" class="mb15" prop="typePrivate" :rules="{ required: true, message: '请选择所有权', trigger: 'blur' }">
            <el-radio-group v-model="menuAddInfo.typePrivate" >
              <el-radio :label="1">是</el-radio>
              <el-radio :label="0">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="用途类别:" class="mb15" prop="typePurpose" :rules="{required: true, message: '用途类别不能为空', trigger: 'blur'}">
            <el-select v-model="menuAddInfo.typePurpose" placeholder="请选择" style="width: 420px">
              <el-option label="构建" :value="0"/>
              <el-option label="上传至ceph" :value="1"/>
              <el-option label="推送至harbor" :value="2"/>
            </el-select>
          </el-form-item>
          <el-form-item label="构建方式:" class="mb15" prop="compileType" v-if = 'menuAddInfo.typePurpose==0' :rules="{required: true, message: '构建方式不能为空', trigger: 'blur'}">
            <el-select v-model="menuAddInfo.compileType" placeholder="请选择" style="width:420px">
              <el-option v-for="item in compileMethodOptions" :key="item.key" :label="item.key" :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeMenuAddDialog">关闭</el-button>
        <el-button type="primary" @click="saveMenu">保存</el-button>
      </span>
    </el-dialog>
    <!--添加/编辑镜像弹窗-->
    <el-dialog
      :title="dialogTitle"
      :visible.sync="ImageDialogShow"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="imageInfo" ref="imageInfoEditForm" label-width="110px" label-position="right">
          <el-form-item label="镜像名称:" class="mb15" prop="imageRepo" :rules="{required: true, message: '镜像名称不能为空', trigger: 'blur'}">
            <el-input v-model="imageInfo.imageRepo" placeholder="请输入镜像类型名称"></el-input>
          </el-form-item>
          <el-form-item label="镜像标签:" class="mb20" prop="imageTag" :rules="{required: true, message: '镜像标签不能为空', trigger: 'blur'}">
            <el-input v-model="imageInfo.imageTag" placeholder="请输入镜像类型描述"></el-input>
          </el-form-item>
          <el-form-item label="稳定版本:" class="mb20" prop="stable" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
            <el-radio-group v-model="imageInfo.stable" placeholder="请选择" style="width: 110px"
                            class="width-input-select" @change="">
              <el-radio :label="1" class="mt5 mb10">是</el-radio>
              <el-radio :label="0" class="mt5 mb10">否</el-radio>
            </el-radio-group>
            <i class="el-icon-question" title="同一个镜像名称下只有一个稳定版本，构建时将使用稳定版本" style="font-size: 16px;padding: 5px"></i>
          </el-form-item>
          <el-form-item label="保留构建环境:" v-if="imageInfo.stable == 1" class="mb20" prop="containerUp" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
            <el-radio-group v-model="imageInfo.containerUp" placeholder="请选择" style="width: 110px"
                            class="width-input-select">
              <el-radio :label="1" class="mt5 mb10">是</el-radio>
              <el-radio :label="0" class="mt5 mb10">否</el-radio>
            </el-radio-group>
            <i class="el-icon-question" title="若选择保留构建环境，构建完毕后容器将会保留，下次构建仍会使用此容器" style="font-size: 16px;padding: 5px"></i>
          </el-form-item>
          <el-form-item label="手工上传:" class="mb20" prop="stable" :rules="[{ required: true, message: '不能为空' ,trigger:'blur'}]">
            <el-radio-group v-model="imageInfo.manualUpload" placeholder="请选择" style="width: 110px"
                            class="width-input-select">
              <el-radio :label="1" class="mt5 mb10">是</el-radio>
              <el-radio :label="0" class="mt5 mb10">否</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="镜像包(tar.gz):" class="mb20" v-if="imageInfo.manualUpload==0">
            <el-upload class="upload-demo"
                       ref="upload"
                       action=""
                       :on-exceed="handleExceed"
                       :file-list="fileList"
                       :limit="1"
                       :auto-upload="false">
              <span size="small" type="primary" class="c-blue" style="line-height:22px;">选取文件</span>
              <i class="el-icon-question" title="1.docker save成tar包后必须再压缩成tar.gz包; 2.名字必须是${image name}_${tag}.tar.gz" style="font-size: 16px;padding: 5px"></i>
            </el-upload>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeImageDialog">关闭</el-button>
        <el-button type="primary" :loading="submit_upload_loading" @click="saveOrUpdateImage">保存</el-button>
      </span>
    </el-dialog>

    <!--绑定镜像弹窗-->
    <el-dialog
      title="绑定镜像"
      :visible.sync="bindImageDialogVisible"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="image2bizInfo" ref="bindImageForm" label-width="110px" label-position="right">
          <el-form-item label="镜像名称:" class="mb15" prop="imageName" :rules="{required: true, message: '镜像名称不能为空', trigger: 'blur'}">
            <el-input v-model="image2bizInfo.imageName" disabled placeholder="请输入镜像类型名称"></el-input>
          </el-form-item>
          <el-form-item label="业务名称:" class="mb20" prop="bizId" :rules="{required: true, message: '业务名称不能为空', trigger: 'blur'}">
            <el-select v-model="image2bizInfo.bizIdArr" multiple filterable placeholder="请选择" style="width: 420px">
              <el-option v-for="item in bizList" :key=item.bizId :label="item.bizName"
                         :value=item.bizId></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeBindImageDialog">关闭</el-button>
        <el-button type="primary" @click="saveBindImage">保存</el-button>
      </span>
    </el-dialog>

    <!--上传镜像日志弹窗-->
    <el-dialog title="上传日志详情" :visible.sync="imageUploadLogDialogVisible" class="box-card-body-body" style="height: 800px">
      <div id="logDetail" class="box-card-body-body_right" style="background-color: #544c4c; color: floralwhite;font-size:14px;font-weight:400;margin-top: 10px;">
        <p v-html="logDetail" style="word-wrap: break-word;word-break: break-all;"></p>
        <p v-show="lastOffsets > 0"><i class="el-icon-loading"></i></p>
      </div>
    </el-dialog>

  </div>
</template>

<script>
  export default {
    name: "menuManage",
    data() {
      let validRank = (rule, value, callback) => {
        let pattren = /^(\-)?\d+$/;
        if (pattren.test(value)) {
          callback();
        }
        callback(new Error("请输入数字"));
      };
      let validValue = (rule, value, callback) => {
        if (value && (value.trim() != '') && (!value.startsWith(' '))) {
          callback();
        }
        callback(new Error("请去除空格等无用字符"));
      };
      return {
        compileTypePrivate: 0,
        logDetail: '',
        lastOffsets: -1,
        imageUploadLogDialogVisible: false,
        fileList: [],
        falseD: false,
        dialogTitle: '',
        image2bizInfo: {
          imageId:-1,
          imageName:'',
          bizIdArr:-1
        },
        compileMethodOptions: [
          {key: 'Java编译', value: 1},
          {key: 'Java Web编译', value: 2},
          {key: '自动打包',  value: 3},
          {key: '自定义脚本',    value: 4},
          {key: '多仓库自定义脚本', value: 5},
          {key: 'Java Gradle编译', value: 6},
          {key: 'Java Web Gradle编译', value: 7},
          {key: 'Android APK', value: 8},
        ],
        imageInfo: {
          id: 0,
          imageRepo: '',
          imageTag: '',
          imageOrder: 0,
          imageRegistry: '',
          stable: 0,
          containerUp: 0,
          buildType: 0,
          manualUpload: 0
        },
        ImageDialogShow: false,
        submit_upload_loading: false,
        currentKey: 0,
        rules: {
          menuName: [{required: true, message: '菜单名称不能为空', trigger: 'blur'},{validator: validValue, trigger: 'blur'}],
          menuId: [{required: true, message: '菜单ID不能为空', trigger: 'blur'},{validator: validValue, trigger: 'blur'}],
          rank: [{required: true, message: '排序值不能为空', trigger: 'blur'},{validator: validRank, trigger: 'blur'}]
        },
        funcProps: {
          key: 'functionId',
          label: 'functionName'
        },
        addSubMenuDialogVisible: false,
        bindImageDialogVisible: false,
        defaultProps: {
          children: 'children',
          label: 'typeName',
        },
        menuType: 0,
        defaultMenuList: [
          {id: 0, name:'系统菜单'},
          {id: 1, name:'业务菜单'},
          {id: 2, name:'应用菜单'},
          {id: 3, name:'项目菜单'},
        ],
        typeList: [],
        menuAddInfo: {
          typeName: '',
          typeDesc: '',
          typePurpose: 0,
          compileType: '',
          typePrivate: ''
        },
        typeInfo: {
          typeId: 0,
          typeName: '',
          typeDesc: '',
          typePurpose: '',
          compileType: '',
          typePrivate:''
        },
        imageList: [],
        bizList: [],
        fileList: []
      };
    },

    mounted() {
      this.getImageTypes();
    },

    methods: {

      handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 1 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
      },

      //获取上传日志
      getImageUploadLog(id) {
        this.imageUploadLogDialogVisible = true;
        $http.get($http.api.compile.logs, {id: id, offset: this.lastOffsets}).then(res => {
          let str = res.data.logs;
          if (str && str.length > 0) {
            let lineArr = str.split('\n');
            let newStr = '';
            if (lineArr.length > 0) {
              lineArr.forEach((line) => {
                if (line && line.length > 0) {
                  if (line.indexOf('[WARN]') > -1 || line.indexOf('[WARNING]') > -1) {
                    newStr += '<span class="c-yellow">' + line + '</span><br/>';
                  } else if (line.indexOf('[ERROR]') > -1) {
                    newStr += '<span class="c-error">' + line + '</span><br/>';
                  } else {
                    newStr += line + '<br/>';
                  }
                }
              })
            }
            this.logDetail += newStr;
          }
          this.lastOffsets = res.data.offset;
        })
      },
      checkImageStable(item){
        $http.get($http.api.image_manage.check_image_stable, {typeId: item.typeId, imageRepo: item.imageRepo, bizId: -1}).then(res => {
          if (res.status == 200) {
            if(res.data){
              this.$confirm("相同镜像名称下已存在稳定版本，是否替换?", "提示", {
                distinguishCancelAndClose: true,
                confirmButtonText: "确定",
                cancelButtonText: "取消",
                type: "warning"
              }).then(() => {
                this.setImageStable(item);
              }).catch(() => {

              });
            }else{
              this.setImageStable(item);
            }
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },
      setImageStable(item){
        let changeStable = item.stable === 1? 0 : 1;
        $http.get($http.api.image_manage.set_image_stable, {typeId: item.typeId, imageRepo: item.imageRepo, imageId: item.id, stable: changeStable}).then(res => {
          if (res.status == 200) {
            this.$message({
              message: '设置稳定版本成功',
              type: 'success'
            });
            this.getImageList();
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },
      setImageContainerUp(item){
        let currentContainerUp = item.containerUp === 1?0:1;
        $http.get($http.api.image_manage.image_container_up, {imageId: item.id, containerUp:currentContainerUp}).then(res => {
          if (res.status == 200) {
            this.$message({
              message: '设置容器常态成功',
              type: 'success'
            });
            this.getImageList();
          } else {
            this.$message({
              message: res.msg,
              type: 'warning'
            })
          }
        });
      },
      delImage(item) {
        this.$confirm('确认删除[' + item.imageRepo + ":" + item.imageTag + ']镜像吗？').then(_ => {
          let param = {};
          param.id = item.id;
          $http.get($http.api.image_manage.del_image, param).then(res => {
            if (res.status == 200) {
              this.$message({message: '删除镜像成功', type: 'success'});
              this.getImageList();
            } else {
              this.$message({message: '删除镜像失败，' + res.msg, type: 'error'});
            }
          }).catch(_ => {})
        }).catch(_ => {});
      },
      showAddImageDialog() {
        if (this.typeInfo.typeId == null) {
          this.$message({message: '请选择一个镜像类型！', type: 'error'});
          return;
        }
        this.imageInfo.containerUp = 0;
        this.imageInfo.stable = 0;
        this.dialogTitle = '添加镜像';
        this.ImageDialogShow = true;
      },

      showBindImageDialog(item) {
        let param = {};
        param.imageId = item.id;
        this.image2bizInfo.imageId = item.id;
        this.image2bizInfo.imageName = item.imageRepo + ":" + item.imageTag;
        $http.get($http.api.image_manage.get_biz_by_image,param).then(res => {
          if (res.status == 200) {
            this.image2bizInfo.bizIdArr = res.data;
          } else {
            this.$message({message: '获取绑定的业务失败！', type: 'error'});
          }
        })

        this.getBizInfos();
        this.bindImageDialogVisible = true;
      },

      saveBindImage(){
        let formData = new FormData();
        formData.append('imageId', this.image2bizInfo.imageId);
        formData.append('bizIdArr[]', this.image2bizInfo.bizIdArr);

        $http.post($http.api.image_manage.save_biz_image, formData).then((res) => {
          this.$message({
            type: 'success',
            message: '保存成功!'
          });

          this.closeBindImageDialog();
        })
      },

      getBizInfos() {
        $http.get($http.api.biz.list_all_biz).then(res => {
          if (res.status == 200) {
            this.bizList = res.data;
          } else {
            this.$message({message: '获取业务失败！', type: 'error'});
          }
        }).catch(_ => {})
      },


      getImageTypes() {
        $http.get($http.api.image_manage.get_image_types, {typePurpose:-1}).then(res => {
          if (res.status == 200) {
            this.typeList = res.data;
          } else {
            this.$message({message: '获取镜像类型失败！', type: 'error'});
          }
          this.$nextTick(() => {
            this.setCurrentKey();
          })
        }).catch(_ => {})
      },
      setCurrentKey() {
        this.$refs['tree'].setCurrentKey(this.currentKey);
      },
      saveOrUpdateImage() {
        if (this.typeInfo.typeId == null) {
          this.$message({message: '请选择一个镜像类型！', type: 'error'});
          return;
        }
        this.$refs['imageInfoEditForm'].validate((valid) => {
          if (valid) {
            this.submit_upload_loading = true;
            $http.get($http.api.image_manage.check_image_repeat, {typeId: this.typeInfo.typeId, imageRepo: this.imageInfo.imageRepo, imageTag: this.imageInfo.imageTag}).then(res => {
              if (res.status == 200) {
                this.checkImageInfo = res.data;
                if(this.checkImageInfo.check){
                  this.uploadImage();
                }else{
                  this.$message({
                    message: this.checkImageInfo.msg,
                    type: 'warning'
                  });
                }
              } else {
                this.$message({
                  message: res.msg,
                  type: 'warning'
                })
              }
            });
            this.submit_upload_loading = false;
          }
        });
      },
      uploadImage(){
        let formData = new FormData();
        formData.append("bizId", -1);
        formData.append("imageRepo", this.imageInfo.imageRepo);
        formData.append("imageTag", this.imageInfo.imageTag);
        formData.append("typeId", this.typeInfo.typeId);
        formData.append("stable", this.imageInfo.stable);
        formData.append("containerUp", this.imageInfo.containerUp);
        formData.append("buildType", this.imageInfo.buildType);
        formData.append("manualUpload", this.imageInfo.manualUpload);
        if(this.imageInfo.manualUpload === 0){
          let uploadform = this.$refs.upload.$data.uploadFiles;
          if (!uploadform || uploadform.length === 0) {
            this.$message({
              message: '请选择文件',
              type: 'warning'
            });
            return;
          }
          formData.append("file", uploadform[0].raw);
        }
        $http.post($http.api.image_manage.upload_image, formData).then(res => {
          if (res.status == 200) {
            this.$message({
              message: '上传成功',
              type: "success"
            });
            if(this.imageInfo.manualUpload === 1){
              this.getImageList();
            }
            this.closeImageDialog();
          } else {
            this.$message({
              message: res.msg,
              type: "warning"
            });
          }
        });
      },
      closeImageDialog() {
        this.imageInfo = {
          id: 0,
          imageRepo: '',
          imageTag: '',
          imageOrder: 0,
          imageRegistry: '',
          stable: 0,
          containerUp: 0,
          buildType: 0,
          manualUpload: 0
        };
        this.ImageDialogShow = false;
      },

      delMenu() {
        if (this.typeInfo.typeId == null) {
          this.$message({message: '请选择一个镜像类型！', type: 'error'});
          return;
        }
        this.$confirm('确认删除[' + this.typeInfo.typeName + ']镜像类型吗？').then(_ => {
          let param = {};
          param.typeId = this.typeInfo.typeId;
          $http.get($http.api.image_manage.del_image_type, param).then(res => {
            if (res.status == 200) {
              this.$message({message: '删除镜像类型成功', type: 'success'});
              this.getImageTypes();
              this.typeInfo = {
                typeId: 0,
                typeName: '',
                typeDesc: '',
                typePurpose: '',
                compileType: '',
                typePrivate:''
              };
            } else {
              this.$message({message: '删除镜像类型失败，' + res.msg, type: 'error'});
            }
          }).catch(_ => {})
        }).catch(_ => {});
      },
      closeBindImageDialog() {
        this.bindImageDialogVisible = false;
      },

      closeMenuAddDialog() {
        this.addSubMenuDialogVisible = false;
      },
      addSubMenu() {
        this.menuAddInfo = {};
        this.addSubMenuDialogVisible = true;
      },
      saveMenu() {
        this.$refs['addSubMenuForm'].validate(validate => {
          if (validate) {
            let param = this.menuAddInfo;
            $http.post($http.api.image_manage.save_image_type, param).then(res => {
              if (res.status == 200) {
                this.addSubMenuDialogVisible = false;
                this.getImageTypes();
                this.$message({message: '添加镜像类型成功', type: 'success'});
              }
            }).catch(_ => {})
          }
        })
      },
      updateMenu() {
        if (this.typeInfo.typeId == null) {
          this.$message({message: '请选择一个镜像类型！', type: 'error'});
          return;
        }
        this.$refs['menuInfoForm'].validate(validate => {
          if (validate) {
            $http.post($http.api.image_manage.update_image_type, this.typeInfo).then(res => {
              if (res.status == 200) {
                this.$message({message: '更新镜像类型成功', type: 'success'});
                this.getImageTypes();
                this.handleNodeClick(this.typeInfo);
              } else {
                this.$message({message: '更新镜像类型失败', type: 'error'});
              }
            }).catch(_ => {})
          }
        })
      },
      handleNodeClick(data, node, self) {
        this.currentKey = data.typeId;
        this.typeInfo.typeId = data.typeId;
        this.typeInfo.typeName = data.typeName;
        this.typeInfo.typeDesc = data.typeDesc;
        this.typeInfo.typePurpose = data.typePurpose;
        this.typeInfo.compileType = data.compileType;
        this.typeInfo.typePrivate = data.typePrivate;
        this.compileTypePrivate = data.typePrivate;
        this.getImageList();
      },
      getImageList() {
        $http.get($http.api.image_manage.get_images, {typeId: this.currentKey, bizId: -1}).then(res => {
          if (res.status == 200) {
            this.imageList = res.data;
          }
        }).catch(_ => {})
      }
    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  .issuedialog {
    .addclassTap {
      height: 40px;
      margin-bottom: 10px;
      border-bottom: 2px solid #d8dee5;

      .tapTitile {
        font-size: 16px;
        font-weight: 400;
      }

      .addtap {
        float: right;
      }
    }

    .tabtable {
      height: 490px;
      //   background: red;
    }
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .paintermouse {
    cursor: pointer;
  }

  .paintermouse:hover {
    color: #409eff;
  }

  .box-card-body-body_right {
    display: inline-block;
    width: 100%;
    height: 500px;
    overflow: auto;
    background: black;
    border-left: 0;
    color: aliceblue;
    word-wrap: break-word;
    word-break: break-word;

    p {
      line-height: 18px;
      margin-left: 10px;
      margin-right: 10px;
    }
  }
</style>
