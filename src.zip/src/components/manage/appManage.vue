<template>
  <div id="bizList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar" style="border-bottom:2px solid #d6d9e0">
        <span style="float:left;margin-left:10px;margin-top:5px;margin-right:10px;font-size:16px;color:#606266">应用管理</span>
      </div>
      <el-button style="display: inline-block" type="primary" @click="addDialog">新增窗口期</el-button>
      <div class="table-outer-style">
        <div class="table-box">
          <div class="table-box-top">
            <el-table border :data="deployNotePeriodList" class="table-full">
              <el-table-column prop="bizName" label="业务名称" min-width="80"/>
              <el-table-column prop="deployUnit" label="发布单元" min-width="80"/>
              <el-table-column prop="startTime" label="开始时间" min-width="80"/>
              <el-table-column prop="endTime" label="结束时间" min-width="80"/>
              <el-table-column label="操作" min-width="80">
                <template slot-scope="scope">
                  <span @click="editDialog(scope.row.id)" class="c-blue cp">编辑</span>
                  <span @click="delPeriod(scope.row.id)" class="c-blue cp">删除</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>

      <!--容器化构建管理-->
      <div class="function-list-box" style="display: inline-block;vertical-align: top;margin-right: 10px">
        <div>
          <h3 class="ml10" @contextmenu.preven="">非容器化构建应用</h3>
        </div>
        <el-select filterable collapse-tags multiple remote :remote-method="searchRemoteApp" v-model="showSelectedCompileManageAppList" placeholder="请选择" style="width: 470px">
          <el-option v-for="item in allAppList" :key="item.appId" :label="item.appCode" :value="item.appId"/>
        </el-select>
        <!--realItem-->
        <el-select v-show="false" filterable collapse-tags multiple v-model="selectedCompileManageAppList" placeholder="请选择" style="width: 470px">
          <el-option v-for="item in allAppList" :key="item.appId" :label="item.appCode" :value="item.appId"/>
        </el-select>
        <span slot="footer" class="dialog-footer function-list-box-footer">
          <el-button type="primary" @click="changeImageBak">添加</el-button>
        </span>
        <el-table border :data="selectedCompileManageTableList.filter(data => !searchCompileManageKey || data.appCode.toLowerCase().includes(searchCompileManageKey.toLowerCase())).
                          slice((compileManagePageInfo.pageNum-1)*compileManagePageInfo.pageSize,
                          compileManagePageInfo.pageNum*compileManagePageInfo.pageSize)" class="table-full">
          <el-table-column prop="appCode" label="应用编码" min-width="80"/>
          <el-table-column width="0">

          </el-table-column>
          <el-table-column min-width="80">
            <template slot="header" slot-scope="scope">
              <el-input
                v-model="searchCompileManageKey"
                size="mini"
                placeholder="输入关键字搜索"/>
            </template>
            <template slot-scope="scope">
              <span @click="delSingleImageBak(scope.row.appId)" class="c-blue cp">删除</span>
            </template>
          </el-table-column>
        </el-table>
        <div class="pageModule">
          <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleCompileImageSizeChange"
                         @current-change="handleCompileImageCurrentChange"
                         :current-page="compileManagePageInfo.pageNum" :page-sizes="[10, 20]"
                         :page-size="compileManagePageInfo.pageSize"
                         layout="total, sizes, prev, pager, next, jumper" :total="compileManagePageInfo.total">
          </el-pagination>
        </div>
      </div>


      <!--快速发布管理-->
      <div class="function-list-box" style="display: inline-block;vertical-align: top;margin-right: 10px">
        <div>
          <h3 class="ml10" @contextmenu.preven="">允许快速发布应用</h3>
        </div>
        <el-select filterable collapse-tags multiple remote :remote-method="searchRemoteApp" v-model="showSelectedFastDeployAppList" placeholder="请选择" style="width: 470px">
          <el-option v-for="item in allAppList" :key="item.appId" :label="item.appCode" :value="item.appId"/>
        </el-select>
        <span slot="footer" class="dialog-footer function-list-box-footer">
          <el-button type="primary" @click="changeFastDeploy">添加</el-button>
        </span>
        <el-table border :data="selectedFastDeployTableList.filter(data => !searchFastDeployAppKey || data.appCode.toLowerCase().includes(searchFastDeployAppKey.toLowerCase()))
                          .slice((fastDeployPageInfo.pageNum-1)*fastDeployPageInfo.pageSize,
                          fastDeployPageInfo.pageNum*fastDeployPageInfo.pageSize)" class="table-full">
          <el-table-column prop="appCode" label="应用编码" min-width="80"/>
          <el-table-column width="0">

          </el-table-column>
          <el-table-column min-width="80">
            <template slot="header" slot-scope="scope">
              <el-input
                v-model="searchFastDeployAppKey"
                size="mini"
                placeholder="输入关键字搜索"/>
            </template>
            <template slot-scope="scope">
              <span @click="delSingleFastDeploy(scope.row.appId)" class="c-blue cp">删除</span>
            </template>
          </el-table-column>
        </el-table>
        <div class="pageModule">
          <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleFastDeploySizeChange"
                         @current-change="handleFastDeployCurrentChange"
                         :current-page="fastDeployPageInfo.pageNum" :page-sizes="[10, 20]"
                         :page-size="fastDeployPageInfo.pageSize"
                         layout="total, sizes, prev, pager, next, jumper" :total="fastDeployPageInfo.total">
          </el-pagination>
        </div>
      </div>

      <!--手工上传管理-->
      <div class="function-list-box" style="display: inline-block;vertical-align: top;margin-right: 10px">
        <div>
          <h3 class="ml10" @contextmenu.preven="">允许手工上传应用</h3>
        </div>
        <el-select filterable collapse-tags multiple remote :remote-method="searchRemoteApp" v-model="showSelectedManualUploadAppList" placeholder="请选择" style="width: 470px">
          <el-option v-for="item in allAppList" :key="item.appId" :label="item.appCode" :value="item.appId"/>
        </el-select>
        <span slot="footer" class="dialog-footer function-list-box-footer">
          <el-button type="primary" @click="changeManualUpload">添加</el-button>
        </span>
        <el-table border :data="selectedManualUploadTableList.filter(data => !searchManualUploadAppKey || data.appCode.toLowerCase().includes(searchManualUploadAppKey.toLowerCase()))
                          .slice((manualUploadPageInfo.pageNum-1)*manualUploadPageInfo.pageSize,
                          manualUploadPageInfo.pageNum*manualUploadPageInfo.pageSize)" class="table-full">
          <el-table-column prop="appCode" label="应用编码" min-width="80"/>
          <el-table-column width="0"></el-table-column>
          <el-table-column min-width="80">
            <template slot="header" slot-scope="scope">
              <el-input
                v-model="searchManualUploadAppKey"
                size="mini"
                placeholder="输入关键字搜索"/>
            </template>
            <template slot-scope="scope">
              <span @click="delSingleManualUpload(scope.row.appId)" class="c-blue cp">删除</span>
            </template>
          </el-table-column>
        </el-table>
        <div class="pageModule">
          <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleManualUploadSizeChange"
                         @current-change="handleManualUploadCurrentChange"
                         :current-page="manualUploadPageInfo.pageNum" :page-sizes="[10, 20]"
                         :page-size="manualUploadPageInfo.pageSize"
                         layout="total, sizes, prev, pager, next, jumper" :total="manualUploadPageInfo.total">
          </el-pagination>
        </div>
      </div>
    </div>

    <!--添加/编辑窗口期弹窗-->
    <el-dialog
      :title="dialogTitle"
      :visible.sync="dialogShow"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="periodInfo" ref="peridInfoForm" label-width="110px" label-position="right">
          <el-form-item label="业务名称:" class="mb20" prop="bizId" :rules="{required: true, message: '业务名称不能为空', trigger: 'blur'}">
            <el-select v-model="periodInfo.bizId" placeholder="请选择" style="width: 420px" @change="handleBizChange" filterable>
              <el-option v-for="item in allBizList" :key="item.bizId" :label="item.bizName" :value="item.bizId"/>
            </el-select>
          </el-form-item>
          <el-form-item v-show="false" label="bizName:" class="mb15">
            <el-input v-model="periodInfo.bizName"/>
          </el-form-item>
          <el-form-item label="开始时间:" class="mb15" prop="startTime" :rules="{required: true, message: '开始时间不能为空', trigger: 'blur'}">
            <el-date-picker value-format="timestamp" v-model="periodInfo.startTime" prefix-icon="clean-icon"
                            :picker-options="dateOptions" type="date" style="width: 100%" placeholder="选择日期"/>
          </el-form-item>
          <el-form-item label="结束时间:" class="mb15" prop="endTime" :rules="{required: true, message: '结束时间不能为空', trigger: 'blur'}">
            <el-date-picker value-format="timestamp" v-model="periodInfo.endTime" prefix-icon="clean-icon"
                            :picker-options="dateOptions" type="date" style="width: 100%" placeholder="选择日期"/>
          </el-form-item>
          <el-form-item label="机房(单元):" class="mb20">
            <el-select v-model="periodInfo.deployCode" placeholder="请选择" style="width: 420px" @change="handleDeployUnitChange">
              <el-option v-for="item in allDeployUnitList" :key="item.deployCode" :label="item.deployUnit" :value="item.deployCode"/>
            </el-select>
          </el-form-item>
          <el-form-item v-show="false" label="deployUnit:" class="mb15">
            <el-input v-model="periodInfo.deployUnit"/>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeDialog">关闭</el-button>
        <el-button type="primary" @click="insertOrSavePeriodInfo">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: "menuManage",
    data() {
      let validRank = (rule, value, callback) => {
        let pattren = /^(\-)?\d+$/;
        if (pattren.test(value)) {
          callback();
        }
        callback(new Error("请输入数字"));
      };
      let validValue = (rule, value, callback) => {
        if (value && (value.trim() != '') && (!value.startsWith(' '))) {
          callback();
        }
        callback(new Error("请去除空格等无用字符"));
      };
      return {
        dateOptions: {
          disabledDate(now) {
            return now.getTime() > now ;
          }
        },
        allDeployUnitList: [],
        allBizList: [],
        periodInfo: {
          id: '',
          bizId: '',
          bizName: '',
          startTime: '',
          endTime: '',
          deployUnit: '',
          deployCode: ''
        },
        dialogTitle: '',
        dialogShow: false,
        showSelectedFastDeployAppList: [],
        showSelectedManualUploadAppList: [],
        allAppList: [],
        showSelectedCompileManageAppList: [],
        selectedCompileManageAppList: [],
        deployNotePeriodList: [],
        selectedCompileManageTableList: [],
        searchCompileManageKey: '',
        selectedFastDeployTableList: [],
        searchFastDeployAppKey: '',
        selectedManualUploadTableList: [],
        searchManualUploadAppKey: '',
        compileManagePageInfo: {
          pageNum:1,
          pageSize:10,
          total:0
        },
        fastDeployPageInfo: {
          pageNum:1,
          pageSize:10,
          total:0
        },
        manualUploadPageInfo: {
          pageNum:1,
          pageSize:10,
          total:0
        },
        appProps: {
          key: 'appId',
          label: 'appCode'
        },
      };
    },

    mounted() {
      this.initPage()
    },

    methods: {
      searchRemoteApp(keyWord) {
        $http.get($http.api.app.get_simple_apps,{keyWord: keyWord}).then((res) => {
          this.allAppList = res.data
        }).catch((e) => {
          this.$message({message: '获取应用信息失败!', type: 'error'});
        })
      },
      closeDialog() {
        this.dialogShow = false
        this.periodInfo = {}
      },
      handleCompileImageSizeChange(val) {
        this.compileManagePageInfo.pageSize = val
      },
      handleCompileImageCurrentChange(val) {
        this.compileManagePageInfo.pageNum = val
      },
      handleFastDeploySizeChange(val) {
        this.fastDeployPageInfo.pageSize = val
      },
      handleFastDeployCurrentChange(val) {
        this.fastDeployPageInfo.pageNum = val
      },
      handleManualUploadSizeChange(val) {
        this.manualUploadPageInfo.pageSize = val
      },
      handleManualUploadCurrentChange(val) {
        this.manualUploadPageInfo.pageNum = val
      },
      delSingleImageBak(appId) {
        $http.get($http.api.app.del_single_image_bak,{appId: appId}).then((res) => {
          this.$message({message: '更改成功!', type: 'success'});
          this.getAppImageBackInfo()
        }).catch(e => {
          this.$message({message: '更改失败!', type: 'error'});
        })
      },
      delSingleFastDeploy(appId) {
        $http.get($http.api.app.del_single_fast_deploy,{appId: appId, fastDeploy: 0}).then((res) => {
          this.$message({message: '更改成功!', type: 'success'});
          this.getAppFastDeployInfo()
        }).catch(e => {
          this.$message({message: '更改失败!', type: 'error'});
        })
      },
      delSingleManualUpload(appId) {
        $http.get($http.api.app.del_single_manual_upload,{appId: appId, manualUpload: 0}).then((res) => {
          this.$message({message: '更改成功!', type: 'success'});
          this.getAppManualUploadInfo()
        }).catch(e => {
          this.$message({message: '更改失败!', type: 'error'});
        })
      },
      delPeriod(id) {
        this.$confirm('确认删除该窗口期吗？').then(_ => {
          $http.get($http.api.deploy_note.del_deploy_period,{id: id}).then((res) => {
            this.$message({message: '删除成功!', type: 'success'});
            this.getDeployNotePeriodList()
          }).catch(e => {
            this.$message({message: '删除失败!', type: 'error'});
          })
        })
      },
      handleDeployUnitChange(deployCode) {
        this.setDeployUnit(deployCode);
      },
      setDeployUnit(deployCode) {
        this.allDeployUnitList.forEach(item => {
          if (deployCode == item.deployCode) {
            this.periodInfo.deployUnit = item.deployUnit
            return
          }
        })
      },
      handleBizChange(bizId) {
        this.setBizName(bizId)
      },
      setBizName(bizId) {
        this.allBizList.forEach(item => {
          if (bizId == item.bizId) {
            this.periodInfo.bizName = item.bizName
            return
          }
        })
      },
      insertOrSavePeriodInfo() {
        let msgPre = '编辑窗口期'
        let param = this.periodInfo
        if (this.dialogTitle == '添加窗口期') {
          param.id = null
          msgPre = '添加窗口期'
        }
        this.$refs['peridInfoForm'].validate((valid) => {
          if (valid) {
            $http.post($http.api.deploy_note.insert_or_update_period_info,param).then((res) => {
              this.$message({message: msgPre + '成功!', type: 'success'})
              this.getDeployNotePeriodList()
              this.unShowDialog()
            }).catch((e) => {
              this.$message({message: msgPre + '失败!', type: 'error'});
            })
          }
        })
      },
      addDialog() {
        this.periodInfo = {}
        this.dialogTitle = '添加窗口期'
        this.dialogShow = true
      },
      editDialog(id) {
        $http.get($http.api.deploy_note.get_ori_period_info, {id: id}).then((res) => {
          this.periodInfo = res.data
          this.dialogTitle = '编辑窗口期'
          this.dialogShow = true
        }).catch(e => {
          this.$message({message: '获取窗口期信息失败!', type: 'error'});
        })
      },
      unShowDialog() {
        this.periodInfo = {};
        this.dialogShow = false;
      },
      initPage() {
        this.getSimpleApps();
        this.getDeployNotePeriodList();
        this.getAppImageBackInfo();
        this.getAppFastDeployInfo();
        this.getAppManualUploadInfo();
        this.getSimpleBizs();
        this.getZoneList();
      },
      getZoneList() {
        $http.get($http.api.app.getZoneList, {env: 'online'}).then((res) => {
          let oriList = res.data;
          let TargetList = [];
          //字段转换
          oriList.forEach(item => {
            let target = {};
            target.deployCode = item.code;
            target.deployUnit = item.name;
            TargetList.push(target)
          })
          this.allDeployUnitList = TargetList
        }).catch(e => {
          this.$message({message: '获取机房信息失败!', type: 'error'});
        })
      },
      getAppImageBackInfo() {
        //清除showItem
        this.showSelectedCompileManageAppList = []
        $http.get($http.api.app.get_image_back).then((res) => {
          let selectedApps = res.data.selectedApps;
          let selectedIds = []
          selectedApps.forEach(item => {
            selectedIds.push(item.appId)
          })
          this.selectedCompileManageTableList = selectedApps
          this.selectedCompileManageAppList = selectedIds
          //前台分页信息
          this.compileManagePageInfo.total = selectedApps.length
        })
      },
      getAppFastDeployInfo() {
        //清除showItem
        this.showSelectedFastDeployAppList = [];
        $http.get($http.api.app.get_fast_deploy_info).then((res) => {
          let selectedApps = res.data.selectedApps;
          let selectedIds = []
          selectedApps.forEach(item => {
            selectedIds.push(item.appId)
          });
          this.selectedFastDeployTableList = selectedApps;
          //前台分页信息
          this.fastDeployPageInfo.total = selectedApps.length
        })
      },
      getAppManualUploadInfo() {
        //清除showItem
        this.showSelectedManualUploadAppList = []
        $http.get($http.api.app.get_manual_upload_info).then((res) => {
          let selectedApps = res.data.selectedApps;
          let selectedIds = []
          selectedApps.forEach(item => {
            selectedIds.push(item.appId)
          })
          this.selectedManualUploadTableList = selectedApps
          //前台分页信息
          this.manualUploadPageInfo.total = selectedApps.length
        })
      },
      getSimpleApps() {
        $http.get($http.api.app.get_simple_apps, {keyWord: ''}).then((res) => {
          this.allAppList = res.data
        }).catch((e) => {
          this.$message({message: '获取应用信息失败!', type: 'error'});
        })
      },
      getSimpleBizs() {
        $http.get($http.api.biz.get_sim_bizs).then((res) => {
          this.allBizList = res.data
        }).catch((e) => {
          this.$message({message: '获取业务信息失败!', type: 'error'});
        })
      },
      changeImageBak() {
        if(this.showSelectedCompileManageAppList){
          if(this.showSelectedCompileManageAppList.length < 1){
            this.$message({
              message: '请选择应用',
              type: 'error'
            });
            return;
          }
        }
        let showSelectedIds = this.showSelectedCompileManageAppList
        let selectedIdsStr = showSelectedIds.join(",")
        let param = {appIdsStr: selectedIdsStr}
        param.imageBak = 1;
        $http.get($http.api.app.change_image_back, param).then((res) => {
          if(res.status === 200){
            this.getAppImageBackInfo();
            this.$message({message: '更改状态成功!', type: 'success'});
          }else{
            this.$message({message: '更改状态失败!', type: 'error'});
          }
        }).catch((e) => {
          this.$message({message: '更改状态失败!', type: 'error'});
        })
      },
      changeFastDeploy() {
        if(this.showSelectedFastDeployAppList){
          if(this.showSelectedFastDeployAppList.length < 1){
            this.$message({
              message: '请选择应用',
              type: 'error'
            });
            return;
          }
        }
        let selectedIdsStr = this.showSelectedFastDeployAppList.join(",");
        let param = {
          appIdsStr: selectedIdsStr,
          fastDeploy: 1
        };
        $http.get($http.api.app.change_fast_deploy, param).then((res) => {
          if(res.status === 200){
            this.getAppFastDeployInfo();
            this.$message({message: '更改状态成功!', type: 'success'});
          }else{
            this.$message({message: '更改状态失败!', type: 'error'});
          }
        }).catch((e) => {
          this.$message({message: '更改状态失败!', type: 'error'});
        })
      },
      changeManualUpload() {
        if(this.showSelectedManualUploadAppList){
          if(this.showSelectedManualUploadAppList.length < 1){
            this.$message({
              message: '请选择应用',
              type: 'error'
            });
            return;
          }
        }
        let selectedIdsStr = this.showSelectedManualUploadAppList.join(",")
        let param = {
          appIdsStr: selectedIdsStr,
          manualUpload: 1
        };
        $http.get($http.api.app.change_manual_upload, param).then((res) => {
          if(res.status === 200){
            this.getAppManualUploadInfo();
            this.$message({message: '更改状态成功!', type: 'success'});
          }else{
            this.$message({message: '更改状态失败!', type: 'error'});
          }
        }).catch((e) => {
          this.$message({message: '更改状态失败!', type: 'error'});
        })
      },
      getDeployNotePeriodList() {
        $http.post($http.api.deploy_note.all_period_list).then((res) => {
          this.deployNotePeriodList = res.data.list
        }).catch((e) => {
          this.$message({message: '获取窗口期信息失败!', type: 'error'});
        })
      }
    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  .pageModule {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    width: 100%;
    height: 40px;
  }
  .issuedialog {
    .addclassTap {
      height: 40px;
      margin-bottom: 10px;
      border-bottom: 2px solid #d8dee5;

      .tapTitile {
        font-size: 16px;
        font-weight: 400;
      }

      .addtap {
        float: right;
      }
    }

    .tabtable {
      height: 490px;
      //   background: red;
    }
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .paintermouse {
    cursor: pointer;
  }

  .paintermouse:hover {
    color: #409eff;
  }
</style>
