<template>
  <div id="manage-box" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar">
        <span class="function-bar-title ml10 mr10 po-re-top-1">人员管理</span>
        <el-input v-model="search" class="function-bar-input-l po-re-top-2 ml30" placeholder="请输入关键字" @input="getMemberList"></el-input>
        <el-select v-model="value" class="function-bar-select-s po-re-top-2 ml30" placeholder="请选择" @change="getMemberList">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
        <el-button type="primary" class="ml30 po-re-top-2" @click="showAddMember">添加人员</el-button>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-outer-style">
            <div class="table-box">
              <div class="table-box-top">
                <el-table border :class="{'el-table-left-none':memberData.list.length == 0}"
                          :data="memberData.list" class="table-full">
                  <el-table-column prop="userId" label="人员工号" min-width="100"></el-table-column>
                  <el-table-column prop="userName" label="姓名" min-width="100"></el-table-column>
                  <el-table-column label="系统角色" min-width="100">
                    <template slot-scope="scope">
                      {{roleArrayJoiner(scope.row.roleList,'、')}}
                    </template>
                  </el-table-column>
                  <el-table-column label="操作" min-width="60">
                    <template slot-scope="scope">
                      <span class="c-blue cp" @click="showEditMember(scope.row)">编辑用户</span>
                      <span class="c-blue cp" style="padding: 4px" @click="impersionateStart(scope.row.userId)">模拟</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10 pageination-top" @size-change="handleMemberSizeChange"
                               @current-change="handleMemberPageChange" :current-page="memberData.pageNum" :page-sizes="[10, 20, 30]"
                               :page-size="memberData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="memberData.total">
                </el-pagination>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>


    <el-dialog :title="dialogName"  :visible.sync="dialogPersonnelVisible" class="el-dialog-580w issuedialog"
               :modal-append-to-body="false" :close-on-click-modal='false' :before-close="personnelDialogClose">
      <div class="form-iterm-box">
        <el-form :model="memberForm" ref="memberForm">
          <el-form-item label="工号" class="mb15" label-width="80px" prop="userId" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="memberForm.userId" @blur="checkUserExist" :disabled="disabledType"></el-input>
          </el-form-item>
          <el-form-item label="姓名" class="mb15" label-width="80px" prop="userName" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="memberForm.userName" :disabled="disabledType"></el-input>
          </el-form-item>
          <el-form-item label="邮箱" class="mb15" label-width="80px" prop="userEmail" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="memberForm.userEmail" :disabled="disabledType"></el-input>
          </el-form-item>
          <el-form-item label="角色" class="mb15" label-width="80px" prop="optionRoleList" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-select v-model="memberForm.optionRoleList" multiple
                       class="mb15 optionRoleList">
              <el-option v-for="item in roleList" :key="item.roleId" :label="item.roleName" :value="item.roleId">
                <span style="float: left">{{ item.roleName }}</span>
              </el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="personnelDialogClose">关闭</el-button>
        <el-button type="primary" @click="savePersonnel">保存</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  export default {
    name: 'MemberManage',
    data() {
      return {
        dialogPersonnelVisible: false,
        memberData:{
          list: [],
          pageNum: 1,
          pageSize: 20,
        },
        options: [{
          value: "all",
          label: '全部'
        }],
        value: "all",
        search: '',
        memberForm: {
          userId: '',
          userName: '',
          userEmail: '',
          optionRoleList: [],
        },
        roleList: [],
        dialogName: '',
        disabledType: false,
        operationType: ""
      }
    },

    mounted() {
      this.getSystemRole();
      this.getMemberList();
    },

    methods: {
      checkUserExist(){
        $http.get($http.api.user.checkUser,{userId: this.memberForm.userId}).then((res) =>{
          if (res.data===true){
            this.$message({
              message: '用户已存在',
              type: 'warning'
            });
          }
        })
      },

      roleArrayJoiner(inputArray,joiner){
        let arr=[];
        inputArray.forEach(item =>{
          arr.push(item.roleName)
        })
        return arr.join(joiner);
      },

      getSystemRole(){
        $http.get($http.api.pipeline.systemRole).then((res) =>{
          let roles=res.data;
          roles.forEach(item =>{
            if (item.roleType===0){
              let value={
                value: item.roleId,
                label: item.roleName
              };
              this.options.push(value);
            }
          })
          this.roleList=[];
          this.options.forEach(item =>{
            if (item.value!=="all"){
              let value={
                roleId: item.value,
                roleName: item.label
              };
              this.roleList.push(value);
            }
          })
        }).catch((e,res) =>{
          return;
        })
      },

      getMemberList(){
        let params={};
        if (this.value==="all"){
          params.roleId=""
        }else {
          params.roleId=this.value;
        };

        params.pageSize=this.memberData.pageSize;
        params.pageNum=this.memberData.pageNum;
        params.keyWord=this.search;
        $http.get($http.api.user.getUserList,params).then((res) =>{
          this.memberData=res.data;
        })

      },
      handleMemberSizeChange(val) {
        this.memberData.pageSize = val;
        this.getMemberList();
      },
      handleMemberPageChange(val) {
        this.memberData.pageNum = val;
        this.getMemberList();
      },

      showAddMember(){
        this.operationType="add";
        this.disabledType=false;
        this.dialogName="添加人员";
        this.dialogPersonnelVisible=true;
      },
      showEditMember(user){
        this.operationType="edit";
        this.disabledType=true;
        this.dialogName="编辑人员";
        this.memberForm.userId=user.userId;
        this.memberForm.userName=user.userName;
        this.memberForm.userEmail=user.userEmail;
        this.memberForm.optionRoleList=[];
        user.roleList.forEach(item =>{
          this.memberForm.optionRoleList.push(item.roleId);
        })
        this.dialogPersonnelVisible=true;
      },
      async refreshUser(){
        await $utils.getUserInfo();
        window.location.href="/biz/list"
      },

      //模拟开始
      impersionateStart(userId) {
        $http.get($http.api.user.impersionate_start, {
          userId: userId
        }).then((res) => {
          this.refreshUser();
        }).catch((e) => {
          this.$message({
            type: 'error',
            message: '模拟用户异常'
          });
        });
      },

      personnelDialogClose(){
        this.resetvalidate("memberForm");
        this.memberForm.userId="";
        this.memberForm.userName="";
        this.memberForm.userEmail="";
        this.memberForm.optionRoleList=[];
        this.dialogPersonnelVisible=false;
      },
      resetvalidate(formName){
        if(this.$refs[formName]!==undefined){
          //this.$refs[formName].resetFields();//如果只是清除表单验证用
          this.$refs[formName].clearValidate();
        }
      },

      savePersonnel(){
        if (this.memberForm.optionRoleList.length===0){
          this.$message({
            message: '角色不能为空',
            type: 'warning'
          });
          return;
        };
        let roleList=[];
        this.memberForm.optionRoleList.forEach(item =>{
          roleList.push({
            roleId: item,
            roleName: "",
            roleType:""
          });
        });
        if (this.operationType==="add"){
          this.$refs['memberForm'].validate((valid) => {
            if (valid) {
              $http.post($http.api.user.addUser,{
                userId: this.memberForm.userId,
                userName: this.memberForm.userName,
                userEmail: this.memberForm.userEmail,
                roleList: roleList
              }).then((res) =>{
                this.$message({
                  message: '保存成功',
                  type: 'success'
                });
                this.personnelDialogClose();
                this.getMemberList();
              }).catch((e,res) =>{
                this.$message({
                  message: '保存失败',
                  type: 'error'
                });
              })
            }
          });
        }else {
          if (this.memberForm.optionRoleList.length===0){
            this.$message({
              message: '角色不能为空',
              type: 'warning'
            });
          }else {
            $http.post($http.api.user.updateUser,{
              userId: this.memberForm.userId,
              userName: this.memberForm.userName,
              userEmail: this.memberForm.userEmail,
              roleList: roleList
            }).then((res) =>{
              this.$message({
                message: '保存成功',
                type: 'success'
              });
              this.personnelDialogClose();
              this.getMemberList();
            }).catch((e,res) =>{
              this.$message({
                message: '保存失败',
                type: 'error'
              });
            })
          }

        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  @import 'manageCommon';
  
  .optionRoleList {
    width: 100%;
  }
</style>
