<template>
  <div id="manage-box" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar">
        <span class="function-bar-title ml10 mr10 po-re-top-1">权限管理</span>
        <el-select v-model="entityTypeValue" class="function-bar-select-s po-re-top-2 ml30" placeholder="请选择" @change="searchAuthSet">
          <el-option
            :key="'ALL'"
            :label="'全部'"
            :value="'ALL'">
          </el-option>
          <el-option
            v-for="item in entityManageList"
            :key="item.entityType"
            :label="item.entityName"
            :value="item.entityType">
          </el-option>
        </el-select>
        <el-button type="primary" class="ml30 po-re-top-2" @click="addAuthSet">添加权限集合</el-button>
        <el-button type="primary" class="ml30 po-re-top-2 fr mt15" @click="showSetEntityType">实体管理</el-button>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-outer-style">
            <div class="table-box">
              <div class="table-box-top">
                <el-table border :class="{'el-table-left-none':authSetLstData.list.length == 0}"
                          :data="authSetLstData.list" class="table-full">
                  <el-table-column prop="authId" label="权限集合ID" min-width="80"></el-table-column>
                  <el-table-column prop="authName" label="权限集合名称" min-width="80"></el-table-column>
                  <el-table-column prop="entityType" label="实体类型" min-width="80"></el-table-column>
                  <el-table-column prop="createUser" label="创建人" min-width="80"></el-table-column>
                  <el-table-column prop="createTime" label="创建时间" min-width="80"></el-table-column>
                  <el-table-column label="操作" min-width="120">
                    <template slot-scope="scope">
                      <span class="c-blue cp" style="padding: 4px" @click="viewPermissions(scope.row)">设置权限</span>
                      <span class="c-blue cp" @click="editAuthSet(scope.row)">编辑</span>
                      <span class="c-blue cp" style="padding: 4px" @click="checkAndDeleteAuthSet(scope.row)">删除</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10 pageination-top" @size-change="handleAuthSizeChange"
                               @current-change="handleAuthPageChange" :current-page="authSetLstData.pageNum" :page-sizes="[10, 20, 30]"
                               :page-size="authSetLstData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="authSetLstData.total">
                </el-pagination>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

    <el-dialog :title="dialogName"  :visible.sync="dialogAuthSetVisible" class="el-dialog-640w issuedialog"
               :modal-append-to-body="false" :close-on-click-modal='false' :before-close="closeAuthTree">
      <div class="form-iterm-box roleset-height" id="authTree">
        <el-tree
          ref="tree"
          :data="treeMenuFunc"
          show-checkbox
          node-key="id"
          :default-expand-all="true"
          :filter-node-method="filterNode"
          :props="defaultProps">
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span>
              <i :class="data.isFun===0?'el-icon-menu':'el-icon-star-on'" class="roleset-label-color"> </i> {{ node.label }}
            </span>
          </span>
        </el-tree>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="saveAuthPermissions">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog :title="authSetDialogName"  :visible.sync="dialogAddAuthVisible" class="el-dialog-580w issuedialog"
               :modal-append-to-body="false" :close-on-click-modal='false' :before-close="authDialogClose">
      <div class="form-iterm-box">
        <el-form :model="authSetForm" ref="authSetForm">
          <el-form-item label="实体类型" class="mb15" label-width="110px">
            <el-select v-model="authSetForm.entityType" class="fl roledialog-select" placeholder="请选择">
              <el-option
                v-for="item in entityManageList"
                :key="item.entityType"
                :label="item.entityName"
                :value="item.entityType">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="权限集合ID" class="mb15" label-width="110px" prop="authId" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="authSetForm.authId" :disabled="authOperationType==='edit'?true:false"></el-input>
          </el-form-item>
          <el-form-item label="权限集合名称" class="mb15" label-width="110px" prop="authName" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="authSetForm.authName"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="checkAndSaveAuthSet">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog title="实体管理" :visible.sync="dialogEntityManageVisible"
               class="el-dialog-640w el-dialog-26h issuedialog" :before-close="handleCloseEntityManage"
               :modal-append-to-body="false" :close-on-click-modal='false'>
        <div class="table-box-top">
          <div class="table-box" style="margin-bottom: 10px">
            <a class="fl ml10 c-blue cp task-decompose-title" @click="addEntityType()"
               style="margin-top: -3px;">+新增实体</a>
            <el-table :data="entityManageList.slice((entityManageData.pageNum-1)*entityManageData.pageSize,
                          entityManageData.pageNum*entityManageData.pageSize)" border
                      :class="{'el-table-left-none':entityManageList.length == 0}">
              <el-table-column prop="entityType" label="实体ID" min-width="100">
                <template slot-scope="scope">
                  <el-input v-if="scope.row.addEntityTypeFlag" v-model="createEntityType.entityType" placeholder="输入实体名称">
                  </el-input>
                  <span v-else>{{scope.row.entityType}}</span>
                </template>
              </el-table-column>
              <el-table-column prop="entityName" label="实体名称" min-width="100">
                <template slot-scope="scope">
                  <el-input v-if="scope.row.addEntityTypeFlag" v-model="createEntityType.entityName" placeholder="输入实体名称">
                  </el-input>
                  <global-input v-else :initValue="scope.row.entityName"
                                :onChange="(value)=>{updateEntityInfo(scope.row.entityType, value)}">
                        <span class="table-input-edit-text" slot>
                          {{scope.row.entityName}}
                        </span>
                  </global-input>
                </template>
              </el-table-column>
              <el-table-column prop="createUser" label="创建人" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.addEntityTypeFlag"></span>
                  <span v-else>{{scope.row.createUser}}</span>
                </template>
              </el-table-column>
              <el-table-column label="操作" min-width="100">
                <template slot-scope="scope">
                  <span v-if="scope.row.addEntityTypeFlag" class="c-blue cp" style="padding: 4px" @click="insertEntityInfo()">保存</span>
                  <span v-if="scope.row.addEntityTypeFlag" class="c-blue cp" style="padding: 4px" @click="cancelAddEntityType()">取消</span>
                  <span v-if="!scope.row.addEntityTypeFlag" class="c-blue cp" style="padding: 4px" @click="deleteEntityType(scope.row)">删除</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <div class="pageModule" style="height: 35px">
            <el-pagination class="fr mr10" style="margin-top:4px;" @size-change="handleEntityManageSizeChange"
                           @current-change="handleEntityManagePageChange"
                           :current-page="entityManageData.pageNum" :page-sizes="[10]"
                           :page-size="entityManageData.pageSize"
                           layout="total, sizes, prev, pager, next, jumper" :total="entityManageData.total">
            </el-pagination>
        </div>
        </div>
    </el-dialog>

  </div>
</template>

<script>
  import GlobalInput from "@/components/tool/FieldEdit/GlobalInput.vue";
  export default {
    name: 'RoleManage',
    components: {
      GlobalInput
    },
    data() {
      return {
        dialogName: "",
        authSetDialogName: "",
        authSetForm: {
          authId: "",
          authName: "",
          createUser: "",
          authType: 3, //预设权限类型级别（项目、业务、应用）
          entityType:""
        },
        dialogAuthSetVisible: false,
        dialogAddAuthVisible: false,
        authSetLstData: {
          allList: [],
          list: [],
          pageNum: 1,
          pageSize: 20,
          total: null
        },
        entityTypeValue: 'ALL',
        checkedKey: [],
        functionIds: [],
        menuIds: [],
        treeMenuFunc: [],
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        authOperationType: "",
        curAuthId: '',
        dialogEntityManageVisible: false,
        entityManageList: [],
        entityManageData: {
          pageNum:1,
          pageSize:10,
          total:0
        },
        entityTypeInfo:{
          entityType: '',
          entityName: ''
        },
        createEntityType: {
          addEntityTypeFlag: false,
          entityType: '',
          entityName: '',
          createUser: ''
        }
      };
    },

    mounted(){
      this.searchAuthSet();
      this.getSetEntityInfo();
    },

    methods: {
      deleteEntityType(val){
        this.$confirm("确定删除?", "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.auth.deleteEntity, {entityType: val.entityType}).then((res) =>{
            if (res.status===200){
              this.getSetEntityInfo();
              this.$message({
                message: '删除成功',
                type: 'success'
              });
            }else{
              this.$message({
                message: res.msg,
                type: 'error'
              });
            }
          })
        }).catch(() => {
        });
      },
      addEntityType(){
        for (let i of this.entityManageList) {
          if (i.addEntityTypeFlag) {
            return this.$message({
              message: "同时只能增加一条任务",
              type: "warning"
            });
          }
        }
        this.createEntityType.entityType = '';
        this.createEntityType.entityName = '';
        this.createEntityType.addEntityTypeFlag = true;
        this.entityManageList.unshift(this.createEntityType);
      },
      getSetEntityInfo(){
        $http.get($http.api.auth.getSetEntity).then((res) =>{
          if (res.status===200){
            this.entityManageList = res.data;
            this.entityManageData.total = this.entityManageList.length;
          }else{
            this.$message({
              message: '获取实体类型列表失败',
              type: 'error'
            });
          }
        })
      },
      insertEntityInfo(){
        $http.get($http.api.auth.insertEntity, {entityType: this.createEntityType.entityType, entityName: this.createEntityType.entityName}).then((res) =>{
          if (res.status===200){
            this.addEntityTypeFlag = false;
            this.getSetEntityInfo();
            this.$message({
              message: '保存成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: res.msg,
              type: 'error'
            });
          }
        })
      },
      cancelAddEntityType(){
        this.addEntityTypeFlag = false;
        this.entityManageList.shift();
      },
      updateEntityInfo(entityType, entityName){
        $http.get($http.api.auth.updateEntity, {entityType: entityType, entityName: entityName}).then((res) =>{
          if (res.status===200){
            this.getSetEntityInfo();
            this.$message({
              message: '保存成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: '保存失败',
              type: 'error'
            });
          }
        })
      },
      handleEntityManageSizeChange(val){
        this.entityManageData.pageSize = val;
      },
      handleEntityManagePageChange(val){
        this.entityManageData.pageNum = val;
      },
      showSetEntityType(){
        this.getSetEntityInfo();
        this.dialogEntityManageVisible = true;
      },
      handleCloseEntityManage(){
        this.dialogEntityManageVisible = false;
        this.getSetEntityInfo();
      },
      searchAuthSet(){
        let curEntityType = null;
        if(this.entityTypeValue !== 'ALL'){
          curEntityType = this.entityTypeValue;
        }
        $http.get($http.api.auth.getAuthSet, {entityType: curEntityType}).then((res) =>{
          if(res.data){
            this.authSetLstData.allList = res.data;
            this.authSetLstData.total = res.data.length;
          }
          this.pageUtil();
        })
      },

      handleAuthSizeChange(val) {
        this.authSetLstData.pageSize = val;
        this.pageUtil();
      },
      handleAuthPageChange(val) {
        this.authSetLstData.pageNum = val;
        this.pageUtil();
      },

      pageUtil(){
        let size=this.authSetLstData.pageSize;
        let num=this.authSetLstData.pageNum;
        let tatol=this.authSetLstData.total;
        let pages=Math.floor(tatol/size+1);
        if (num>pages){
          num=pages;
          this.authSetLstData.pageNum=num;
        };
        let start=(num-1)*size;
        let end=num*size-1;
        if (end>tatol){
          end=tatol;
        }
        this.authSetLstData.list=this.authSetLstData.allList.slice(start,end);
      },

      closeAuthTree(){
        this.dialogAuthSetVisible=false;
        var authDiv=document.getElementById('authTree');
        if (authDiv!==null&&!this.dialogAuthSetVisible){
          authDiv.scrollTop=0;
        }
      },

      viewPermissions(val){
        this.curAuthId=val.authId;
        this.dialogName="设置权限"+"【"+val.authName+"】";
        this.checkedKey=[];
        this.functionIds=[];
        $http.get($http.api.user.menuFunTree,{menuType: val.authType}).then((res) =>{
          this.treeMenuFunc=res.data;
          this.dialogAuthSetVisible=true;
          $http.get($http.api.user.roleMenuFuns,{roleId: val.authId}).then((res) =>{
            this.functionIds=res.data.functionIds;
            this.menuIds=res.data.menuIds;
            this.fileterMenu();
          });
        });
      },

      filterNode(value,data,node){
        if (data.isFun===1){
          let Identification=false;
          this.functionIds.forEach(s => {
            if (s === node.key) {
              Identification = true;
            }
          });
          let Identification1=false;
          if (node.parent.key!==undefined){
            this.menuIds.forEach(item =>{
              if (item===node.parent.key){
                Identification1=true;
              }

            })
          }else{
            Identification1=true;
          }
          if (Identification&&Identification1){
            node.checked=true;
            this.$refs.tree.setChecked(node,true,false);
          }
        }
        return true;
      },

      fileterMenu(){
        this.menuIds.forEach(item =>{
          let node=this.$refs.tree.getNode(item);
          if (node!==null){
            if (node.childNodes.length===0){
              this.$refs.tree.setChecked(node,true,false);
            }
          }

        })
        this.$refs.tree.filter();
      },

      saveAuthPermissions(){
        this.closeAuthTree();
        let nodes=this.$refs.tree.getCheckedNodes(false,true);
        let menuIds=[];
        let functionIds=[];
        nodes.forEach(item =>{
          if (item.isFun===1){
            let Identification=false;
            functionIds.forEach(s =>{
              if (s===item.id){
                Identification=true;
              };
            })
            if (!Identification){
              functionIds.push(item.id);
            }
          } else{
            menuIds.push(item.id);
          }
        })
        let params={
          roleId: this.curAuthId,
          menuIds: menuIds,
          functionIds: functionIds,
          customRole: 1
        };
        $http.post($http.api.user.updateMenuFuns,params).then((res) =>{
          if (res.status===200){
            this.$message({
              message: '保存成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: '保存失败',
              type: 'error'
            });
          }
        })
      },

      addAuthSet(){
        this.authOperationType="add";
        this.authSetDialogName="添加权限集合";
        this.dialogAddAuthVisible=true;
      },
      editAuthSet(val){
        this.authOperationType="edit";
        this.authSetDialogName="编辑权限集合";
        this.authSetForm.authId = val.authId;
        this.authSetForm.authName = val.authName;
        this.authSetForm.entityType = val.entityType;
        this.dialogAddAuthVisible=true;
      },

      authDialogClose(){
        this.resetvalidate("authSetForm");
        this.authSetForm.authId = '';
        this.authSetForm.authName = '';
        this.authSetForm.entityType = '';
        this.dialogAddAuthVisible=false;
      },

      resetvalidate(formName){
        if(this.$refs[formName]!==undefined){
          this.$refs[formName].clearValidate();
        }
      },
      checkAndDeleteAuthSet(val){
        let msg = "确定删除权限集合"+"【"+val.authName+"】";
        $http.get($http.api.auth.checkSetFunction,{authId: val.authId}).then((res) =>{
          if (res.status===200){
            if(res.data > 0){
              msg = "权限集合有绑定功能，确定删除"+"【"+val.authName+"】";
            }
          }
          this.deleteAuthSet(val, msg);
        })
      },

      deleteAuthSet(val, msg){
        this.$confirm(msg, "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.auth.deleteAuthSet,{authId: val.authId}).then((res) =>{
            if (res.status===200){
              this.$message({
                message: '删除成功',
                type: 'success'
              });
              this.searchAuthSet();
            } else {
              this.$message({
                message: res.msg,
                type: 'error'
              });
            }
          })
        })
      },

      checkAndSaveAuthSet(){
        if (this.authSetForm.entityType===null){
          this.$message({
            message: '权限集合实体不能为空',
            type: 'warning'
          });
          return;
        };
        this.$refs['authSetForm'].validate((valid) => {
          if (valid) {
            $http.get($http.api.auth.authSetCheck, {authId: this.authSetForm.authId}).then(res => {
              if(res.data > 0 && this.authOperationType==="add"){
                this.$message({
                  message: 'ID重复，请修改',
                  type: 'error'
                });
                return;
              }else{
                this.saveAuthSet();
              }
            }).catch((e) => {
              this.$message({
                message: '判断已有权限ID失误',
                type: 'error'
              });
              return;
            });
          }
        });
      },

      saveAuthSet(){
        let params={
          authId: this.authSetForm.authId,
          authName: this.authSetForm.authName,
          authType:this.authSetForm.authType,
          entityType:this.authSetForm.entityType
        };
        if (this.authOperationType==="add"){
          $http.post($http.api.auth.addAuthSet,params).then((res) =>{
            if(res.status === 200){
              this.$message({
                message: '保存成功',
                type: 'success'
              });
              this.searchAuthSet();
              this.authDialogClose();
            }else{
              this.$message({
                message: '保存失败',
                type: 'error'
              });
            }
          }).catch((e) => {
            this.$message({
              message: '保存失败',
              type: 'error'
            });
          });
        }else {
          $http.post($http.api.auth.updateAuthSet,params).then((res) =>{
            if(res.status === 200){
              this.$message({
                message: '保存成功',
                type: 'success'
              });
              this.searchAuthSet();
              this.authDialogClose();
            }else{
              this.$message({
                message: '保存失败',
                type: 'error'
              });
            }
          }).catch((e) => {
            this.$message({
              message: '保存失败',
              type: 'error'
            });
          });
        }
      }
    }
  };
</script>

<style lang="scss" scoped>
  @import 'manageCommon';

  #app .roleset-height {
    height: 500px;
    overflow-y: auto;
  }
  .roleset-label-color {
    color: #1a1b1d;
  }
  .roledialog-select {
    width: 100%;
  }
</style>
