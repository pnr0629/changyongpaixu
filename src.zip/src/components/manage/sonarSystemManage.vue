<template>
  <div id="sonarSystemManageDiv" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar" style="border-bottom:2px solid #d6d9e0">
        <span style="float:left;margin-left:10px;margin-top:6px;margin-right:10px;font-size:16px;color:#606266">Sonar系统管理</span>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-box-top" style="height:100%;padding-left:10px;padding-right:10px;">
            <div class="table-box">
              <el-collapse v-model="activeNames">
                <el-collapse-item title="SonarQube服务器健康状态" name="healthInfo">
                  <el-row>
                    <el-col :span="6"><span>SonarQube服务器地址：</span></el-col>
                    <el-col :span="6"><span>{{healthInfo.serverUrl}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>SonarQube服务器状态：</span></el-col>
                    <el-col :span="6"><span :style="healthInfo.health=='GREEN' ? 'color: green;' : healthInfo.health=='YELLOW' ? 'color: yellow;' : 'color: red;'">{{healthInfo.health}}</span></el-col>
                  </el-row>
                </el-collapse-item>
                <el-collapse-item title="Sonar限流状态" name="sonarRateLimitInfo">
                  <el-row>
                    <el-col :span="6"><span>当前是否限流：</span></el-col>
                    <el-col :span="6"><span>{{rateLimitInfo.rateLimitOpened}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>Sonar限流队列中待处理消息数：</span></el-col>
                    <el-col :span="6"><span>{{rateLimitInfo.rateLimitQueueSize}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>操作：</span></el-col>
                    <el-col :span="6">
                      <button v-if="rateLimitInfo.rateLimitOpened==false" @click="openSonarRateLimit()">开启限流</button>
                      <button v-if="rateLimitInfo.rateLimitOpened==true" @click="closeSonarRateLimit()">关闭限流</button>
                    </el-col>
                  </el-row>
                </el-collapse-item>
                <el-collapse-item title="SonarQube计算引擎服务统计信息(SonarQube Compute Engine Tasks MBean Info)" name="computeEngineTasksMBeanInfo">
                  <el-row>
                    <el-col :span="6"><span>SonarQube JMX RMI地址：</span></el-col>
                    <el-col :span="6"><span>{{computeEngineTasksMBeanInfo.serverRMI}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>运行总时间（毫秒）：</span></el-col>
                    <el-col :span="6"><span>{{computeEngineTasksMBeanInfo.processingTime}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>处理成功任务数：</span></el-col>
                    <el-col :span="6"><span>{{computeEngineTasksMBeanInfo.successCount}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>处理失败任务数：</span></el-col>
                    <el-col :span="6"><span :style="computeEngineTasksMBeanInfo.errorCount>0 ? 'color: red;' : ''">{{computeEngineTasksMBeanInfo.errorCount}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>处理单个任务平均耗时（毫秒）：</span></el-col>
                    <el-col :span="6"><span>{{computeEngineTasksMBeanInfo.averageProcessTime}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>正在处理任务数：</span></el-col>
                    <el-col :span="6"><span>{{computeEngineTasksMBeanInfo.inProgressCount}}</span></el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="6"><span>等待处理任务数：</span></el-col>
                    <el-col :span="6"><span>{{computeEngineTasksMBeanInfo.pendingCount}}</span></el-col>
                  </el-row>
                </el-collapse-item>

                 <el-collapse-item title="SonarQube Scanner机器负载信息" name="scannerMachineLoadInfoList">
                    <div class="btnArea">
                      <el-row type="flex" justify="space-between">
                          <span> 指标采集时间为过去{{samplingTime}}秒</span>
                          <el-button type="primary" class="mb10" @click="renderScannerMachineInfoTable()">刷新</el-button>
                      </el-row>
                    </div>
                    <div class="table-box-bs" v-loading="table_loading" element-loading-text="拼命加载中">
                      <div class="table-box-top-bs">
                        <el-table :data="scannerMachineLoadInfoList" style="width:100%;height:100%;overflow:auto;">

                          <el-table-column label="IP" prop="monitorHost" min-width="120">

                          </el-table-column>

                          <el-table-column prop="ramInfo" label="RAM(M)" min-width="120">
                            <template slot-scope="scope">
                              {{parseScannerRamInfo(scope.row.ramInfo)}}
                            </template>
                          </el-table-column>

                          <el-table-column prop="cpuInfo" label="CPU(%)" min-width="120">
                            <template slot-scope="scope">
                              {{parseScannerCpuInfo(scope.row.cpuInfo)}}
                            </template>
                          </el-table-column>

                          <el-table-column prop="loadInfo" label="LOAD" min-width="120">
                            <template slot-scope="scope">
                              {{parseScannerLoadInfo(scope.row.loadInfo)}}
                            </template>
                          </el-table-column>

                        </el-table>
                      </div>
                    </div>
                </el-collapse-item>
              </el-collapse>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
  export default {
    name: 'sonarSystemManage',
    data() {
      return {
        timer: null,
        healthInfo: {
          health: '',
          serverUrl: ''
        },
        computeEngineTasksMBeanInfo: {
          serverRMI: '',
          processingTime: '',
          successCount: '',
          errorCount: '',
          averageProcessTime: '',
          inProgressCount: '',
          pendingCount: '',
        },
        rateLimitInfo: {
          rateLimitOpened: '',
          rateLimitQueueSize: '',
        },

        table_loading: false,
        scannerMachineLoadInfoList:[],
        samplingTime: 60,
        activeNames: ['healthInfo', 'sonarRateLimitInfo', 'computeEngineTasksMBeanInfo', 'scannerMachineLoadInfoList'],
      };
    },

    mounted() {
      this.getSonarQubeSystemInfo();
      this.renderScannerMachineInfoTable();
      this.getSonarRateLimitInfo();

      this.timer = setInterval(() => {
        this.getSonarQubeSystemInfo();
        this.renderScannerMachineInfoTable();
        this.getSonarRateLimitInfo();
      }, 3000);
    },

    beforeDestroy: function () {
      if (this.timer) { //如果定时器还在运行 或者直接关闭，不用判断
        clearInterval(this.timer); //关闭
      }
    },

    methods: {

      getSonarRateLimitInfo() {
        $http.get($http.api.sonar_manage.get_sonar_rate_limit_info).then(res => {
          if (res.data) {
            this.rateLimitInfo = res.data;
          }
        });
      },

      openSonarRateLimit() {
        this.$confirm('此操作将开启Sonar任务限流，是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.sonar_manage.open_sonar_rate_limit).then(res => {
            this.getSonarRateLimitInfo();
          });
        }).catch(() => {
        });
      },

      closeSonarRateLimit() {
        this.$confirm('此操作将关闭Sonar任务限流，是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          $http.post($http.api.sonar_manage.close_sonar_rate_limit).then(res => {
            this.getSonarRateLimitInfo();
          });
        }).catch(() => {
        });
      },

      getSonarQubeSystemInfo() {
        $http.get($http.api.sonar_manage.get_sonarqube_system_info).then(res => {
          if (res.data){
            this.healthInfo = res.data.healthInfo;
            this.computeEngineTasksMBeanInfo = res.data.computeEngineTasksMBeanInfo;
          }
        });
      },

      renderScannerMachineInfoTable() {
        this.table_loading = true;
        $http.get($http.api.sonar_manage.get_sonarqube_scanner_machine_info).then(response => {
          this.scannerMachineLoadInfoList = response.data;
          if(Array.isArray(this.scannerMachineLoadInfoList) && this.scannerMachineLoadInfoList.length > 0) {
            this.samplingTime = this.scannerMachineLoadInfoList[0].samplingTime;
          }
          this.table_loading = false;
        });
      },

      parseScannerRamInfo(ramInfo) {
        if(!ramInfo) return "N/A";
        var samplingTime = ramInfo.samplingTime;
        var used =  (ramInfo.used / samplingTime).toFixed(2);
        var free =  (ramInfo.free / samplingTime).toFixed(2);
        var buffers = (ramInfo.buffers / samplingTime).toFixed(2);
        var cached = (ramInfo.cached / samplingTime).toFixed(2);

        return `used: ${used}, free: ${free}, buffers: ${buffers}, cached: ${cached}`;
      },

      parseScannerCpuInfo(cpuInfo) {
        if(!cpuInfo) return "N/A";
        var user = cpuInfo.user.toFixed(2);
        var system = cpuInfo.system.toFixed(2);
        var iowait = cpuInfo.iowait.toFixed(2);
        return `user: ${user}, system: ${system}, iowait: ${iowait}`;

      },

      parseScannerLoadInfo(loadInfo) {
        if(!loadInfo) return "N/A";
        var samplingTime = loadInfo.samplingTime;
        var loadDataUnit = samplingTime/5;
        var load1 = (loadInfo.load1 / loadDataUnit).toFixed(2);
        var load5 = (loadInfo.load5 / loadDataUnit).toFixed(2);
        var load15 = (loadInfo.load15 / loadDataUnit).toFixed(2);
        return `load1: ${load1}, load5: ${load5}, load15: ${load15}`;
      },

    }
  };
</script>

