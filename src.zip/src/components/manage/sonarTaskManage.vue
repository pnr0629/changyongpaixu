<template>
  <div id="sonarTaskList" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar" style="border-bottom:2px solid #d6d9e0">
        <span style="float:left;margin-left:10px;margin-top:5px;margin-right:10px;font-size:16px;color:#606266">Sonar任务管理
        </span>
        <el-select v-model="searchAppId" style="width:200px;margin-top:5px;margin-left: 30px;float:left" filterable placeholder="请选择应用" @change="searchSonarTask">
          <el-option key="0" label="全部" value="0">
          </el-option>
          <el-option
            v-for="item in searchAppList"
            :key="item.appId"
            :label="item.appCode"
            :value="item.appId">
          </el-option>
        </el-select>
        <el-select v-model="searchStatus" style="width:200px;margin-top:5px;margin-left: 30px;float:left" placeholder="请选择状态" @change="searchSonarTask">
          <el-option
            v-for="item in searchStatusList"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-box-top" style="height:100%;padding-left:10px;padding-right:10px;">
            <div class="table-box">
              <div class="table-box-top">
                <el-table border :class="{'el-table-left-none':sonarTaskData.list.length == 0}"
                          :data="sonarTaskData.list" style="width: 100%;height:100%;">
                  <el-table-column prop="appCode" label="应用" min-width="80"></el-table-column>
                  <el-table-column prop="workflowTaskId" label="WorkflowTaskId" min-width="90"></el-table-column>
                  <el-table-column prop="statusName" label="状态" min-width="80"></el-table-column>
                  <el-table-column prop="columbusWorkerMachine" label="哥伦布WORKER" min-width="85"></el-table-column>
                  <el-table-column prop="sonarScannerMachine" label="SONAR SCANNER" min-width="85"></el-table-column>
                  <el-table-column label="任务参数" min-width="110">
                    <template slot-scope="scope">
                      {{(!scope.row.expand && scope.row.taskParams && scope.row.taskParams.length > 35) ?
                      scope.row.taskParams.substring(0,25) + '...' : scope.row.taskParams}}
                      <span class="c-blue cp" v-if="!scope.row.expand && scope.row.taskParams && scope.row.taskParams.length > 35"
                            @click="expandInfo(scope.row)">
                        查看全部
                      </span>
                      <span class="c-blue cp" v-if="scope.row.expand" @click="unExpandInfo(scope.row)">收起</span>
                    </template>
                  </el-table-column>
                  <el-table-column prop="createTime" label="创建时间" min-width="80"></el-table-column>
                  <el-table-column prop="updateTime" label="更新时间" min-width="80"></el-table-column>
                  <el-table-column label="操作" min-width="40">
                    <template slot-scope="scope">
                      <!--<span class="c-blue cp" style="padding: 4px" @click="viewPermissions(scope.row)">设置权限</span>-->
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10" style="margin-top: 9px;" @size-change="handleSizeChange"
                               @current-change="handlePageChange" :current-page="sonarTaskData.pageNum" :page-sizes="[10, 20, 30]"
                               :page-size="sonarTaskData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="sonarTaskData.total">
                </el-pagination>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>

</template>

<script>
  export default {
    name: 'sonarTaskManage',
    data() {
      return {
        searchAppId: null,
        searchAppList: [],
        sonarTaskData: {
          list: [],
          pageNum: 1,
          pageSize: 20,
          total: null
        },
        searchStatus: null,
        searchStatusList: [{
          value: -1,
          label: "全部"
        },{
          value: 0,
          label: "新建"
        },{
          value: 1,
          label: "哥伦布WORKER限流中"
        },{
          value: 2,
          label: "哥伦布WORKER处理中"
        },{
          value: 3,
          label: "SONAR SCANNER扫描中"
        },{
          value: 4,
          label: "SONARQUBE生成报告中"
        },{
          value: 5,
          label: "扫描成功且通过"
        },{
          value: 6,
          label: "扫描失败或不通过"
        },{
          value: 7,
          label: "扫描任务异常"
        }],
      };
    },

    mounted(){
      this.getSearchSonarTaskApp();
      this.searchSonarTask();
    },

    methods: {
      expandInfo(row) {
        this.$set(row, 'expand', true);
      },
      unExpandInfo(row) {
        this.$set(row, 'expand', false);
      },

      getSearchSonarTaskApp(){
        $http.get($http.api.sonar_manage.get_sonar_task_manage_list_app).then(res => {
          this.searchAppList = res.data;
        });
      },

      searchSonarTask(){
        let params = {
          appId: this.searchAppId,
          status:this.searchStatus,
          pageNum: this.sonarTaskData.pageNum,
          pageSize: this.sonarTaskData.pageSize
        };
        $http.get($http.api.sonar_manage.get_sonar_task_manage_list, params).then(res => {
          this.sonarTaskData = res.data;
        });
      },

      handleSizeChange(val) {
        this.sonarTaskData.pageSize = val;
        this.searchSonarTask();
      },
      handlePageChange(val) {
        this.sonarTaskData.pageNum = val;
        this.searchSonarTask();
      },

    }
  };
</script>

<style>
</style>
