<template>
  <div id="manage-box" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar">
        <span class="function-bar-title ml10 mr10 po-re-top-1">角色管理</span>
        <el-select v-model="roleValue" class="function-bar-select-s po-re-top-2 ml30" placeholder="请选择" @change="searchRoleType">
          <el-option
            v-for="item in roleType"
            :key="item.value"
            :label="item.label"
            :value="item.value">
          </el-option>
        </el-select>
        <el-button type="primary" class="ml30 po-re-top-2" @click="addRole">添加角色</el-button>
      </div>
      <div class="white-box table-outer-box">
        <div class="mt0">
          <div class="table-outer-style">
            <div class="table-box">
              <div class="table-box-top">
                <el-table border :class="{'el-table-left-none':roleData.list.length == 0}"
                          :data="roleData.list" class="table-full">
                  <el-table-column prop="roleId" label="角色ID" min-width="80"></el-table-column>
                  <el-table-column prop="roleName" label="角色名称" min-width="80"></el-table-column>
                  <el-table-column label="角色类型" min-width="80">
                    <template slot-scope="scope">
                      {{roleType2String(scope.row.roleType)}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="createUser" label="创建人" min-width="80"></el-table-column>
                  <el-table-column prop="createTime" label="创建时间" min-width="80"></el-table-column>
                  <el-table-column label="操作" min-width="120">
                    <template slot-scope="scope">
                      <span class="c-blue cp" style="padding: 4px" @click="viewPermissions(scope.row)">设置权限</span>
                      <span class="c-blue cp" @click="editRole(scope.row)">编辑</span>
                      <span class="c-blue cp" style="padding: 4px" @click="checkAndDeleteRole(scope.row)">删除</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div class="table_b_f_b">
                <el-pagination class="fr mr10 pageination-top" @size-change="handleRoleSizeChange"
                               @current-change="handleRolePageChange" :current-page="roleData.pageNum" :page-sizes="[10, 20, 30]"
                               :page-size="roleData.pageSize" layout="total, sizes, prev, pager, next, jumper" :total="roleData.total">
                </el-pagination>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>


    <el-dialog :title="dialogName"  :visible.sync="dialogRoleVisible" class="el-dialog-640w issuedialog"
               :modal-append-to-body="false" :close-on-click-modal='false' :before-close="closeRoleTree">
      <div class="form-iterm-box roleset-height" id="roleTree">
        <el-tree
          ref="tree"
          :data="data2"
          show-checkbox
          node-key="id"
          :default-expand-all="true"
          :filter-node-method="filterNode"
          :props="defaultProps">
          <span class="custom-tree-node" slot-scope="{ node, data }">
            <span>
              <i :class="data.isFun===0?'el-icon-menu':'el-icon-star-on'" class="roleset-label-color"> </i> {{ node.label }}
            </span>
          </span>
        </el-tree>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="saveRolePermissions">保存</el-button>
      </span>
    </el-dialog>

    <el-dialog :title="roleDialogName"  :visible.sync="dialogAddRoleVisible" class="el-dialog-580w issuedialog"
               :modal-append-to-body="false" :close-on-click-modal='false' :before-close="roleDialogClose">
      <div class="form-iterm-box">
        <el-form :model="roleForm" ref="roleForm">
          <el-form-item label="角色类型" class="mb15" label-width="80px">
            <el-select v-model="roleForm.roleType" class="fl roledialog-select" placeholder="请选择" @change="addPrefix()">
              <el-option
                v-for="item in roleType1"
                :key="item.value"
                :label="item.label"
                :value="item.value">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="角色ID" class="mb15" label-width="80px" prop="roleId" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="roleForm.roleId" :disabled="roleOperationType==='edit'?true:false"></el-input>
          </el-form-item>
          <el-form-item label="角色名称" class="mb15" label-width="80px" prop="roleName" :rules="[
                            { required: true, message: '不能为空', trigger: 'blur' }
                        ]">
            <el-input v-model="roleForm.roleName"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="saveRole">保存</el-button>
      </span>
    </el-dialog>

  </div>

</template>

<script>
  export default {
    name: 'RoleManage',
    data() {
      return {
        dialogName: "",
        roleDialogName: "",
        roleForm: {
          roleType: null,
          roleId: "",
          roleName: ""
        },
        dialogRoleVisible: false,
        dialogAddRoleVisible: false,
        roleData: {
          allList: [],
          list: [],
          pageNum: 1,
          pageSize: 20,
          total: null
        },
        roleType: [{
          value: -1,
          label: "全部"
        },{
          value: 0,
          label: "系统角色"
        },{
          value: 1,
          label: "业务角色"
        },{
          value: 2,
          label: "应用角色"
        },{
          value: 3,
          label: "项目角色"
        }],
        roleType1: [{
          value: 0,
          label: "系统角色"
        },{
          value: 1,
          label: "业务角色"
        },{
          value: 2,
          label: "应用角色"
        },{
          value: 3,
          label: "项目角色"
        }],
        roleValue: -1,
        checkedKey: [],
        functionIds: [],
        menuIds: [],
        data2: [],
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        roleOperationType: "",
        roleId: ''
      };
    },

    mounted(){
      this.getRoleList();
    },

    methods: {
      roleType2String(type){
        if (type===0){
          return "系统角色";
        };
        if (type===1){
          return "业务角色";
        };
        if (type===2){
          return "应用角色";
        };
        if (type===3){
          return "项目角色";
        };
      },

      getRoleList(){
        $http.get($http.api.pipeline.systemRole).then((res) =>{
          this.roleData.allList=res.data;
          this.roleData.total=this.roleData.allList.length;
          this.pageUtil();
        })
      },

      searchRoleType(){
        if (this.roleValue===-1){
          this.getRoleList();
          return;
        }
        this.roleData.allList=[];
        $http.get($http.api.pipeline.systemRole).then((res) =>{
          res.data.forEach(item =>{
            if (item.roleType===this.roleValue){
              this.roleData.allList.push(item);
            }
          });
          this.roleData.total=this.roleData.allList.length;
          this.pageUtil();
        })
      },

      handleRoleSizeChange(val) {
        this.roleData.pageSize = val;
        this.pageUtil();
      },
      handleRolePageChange(val) {
        this.roleData.pageNum = val;
        this.pageUtil();
      },

      pageUtil(){
        let size=this.roleData.pageSize;
        let num=this.roleData.pageNum;
        let tatol=this.roleData.total;
        let pages=Math.floor(tatol/size+1);
        if (num>pages){
          num=pages;
          this.roleData.pageNum=num;
        };
        let start=(num-1)*size;
        let end=num*size-1;
        if (end>tatol){
          end=tatol;
        }
        this.roleData.list=this.roleData.allList.slice(start,end);
      },

      closeRoleTree(){
        this.dialogRoleVisible=false;
        var roleDiv=document.getElementById('roleTree');
        if (roleDiv!==null&&!this.dialogRoleVisible){
          roleDiv.scrollTop=0;
        }
      },

      addPrefix(){
        if (this.roleOperationType==="add") {
          if (this.roleForm.roleType===0){
            this.roleForm.roleId="SYS_";
          };
          if (this.roleForm.roleType===1){
            this.roleForm.roleId="BIZ_";
          };
          if (this.roleForm.roleType===2){
            this.roleForm.roleId="APP_";
          };
          if (this.roleForm.roleType===3){
            this.roleForm.roleId="PROJ_";
          };

        }

      },

      viewPermissions(role){
        this.roleId=role.roleId;
        this.dialogName="设置权限"+"【"+role.roleName+"】";
        this.checkedKey=[];
        this.functionIds=[];
        $http.get($http.api.user.menuFunTree,{menuType: role.roleType}).then((res) =>{
          this.data2=res.data;
          this.dialogRoleVisible=true;
          $http.get($http.api.user.roleMenuFuns,{roleId: role.roleId}).then((res) =>{
            this.functionIds=res.data.functionIds;
            this.menuIds=res.data.menuIds;
            this.fileterMenu();
          });
        });
      },

      filterNode(value,data,node){
        if (data.isFun===1){
          let Identification=false;
          this.functionIds.forEach(s => {
            if (s === node.key) {
              Identification = true;
            }
          });
          let Identification1=false;
          if (node.parent.key!==undefined){
            this.menuIds.forEach(item =>{
              if (item===node.parent.key){
                Identification1=true;
              }

            })
          }else{
            Identification1=true;
          }
          if (Identification&&Identification1){
            node.checked=true;
            this.$refs.tree.setChecked(node,true,false);
          }
        }
        return true;
      },

      fileterMenu(){
        this.menuIds.forEach(item =>{
          let node=this.$refs.tree.getNode(item);
          if (node!==null){
            if (node.childNodes.length===0){
              this.$refs.tree.setChecked(node,true,false);
            }
          }

        })
        this.$refs.tree.filter();
      },

      saveRolePermissions(){
        this.closeRoleTree();
        let nodes=this.$refs.tree.getCheckedNodes(false,true);
        let menuIds=[];
        let functionIds=[];
        nodes.forEach(item =>{
          if (item.isFun===1){
            let Identification=false;
            functionIds.forEach(s =>{
              if (s===item.id){
                Identification=true;
              };
            })
            if (!Identification){
              functionIds.push(item.id);
            }
          } else{
            menuIds.push(item.id);
          }
        })
        let params={
          roleId: this.roleId,
          menuIds: menuIds,
          functionIds: functionIds
        };
        $http.post($http.api.user.updateMenuFuns,params).then((res) =>{
          if (res.status===200){
            this.$message({
              message: '保存成功',
              type: 'success'
            });
          }else{
            this.$message({
              message: '保存失败',
              type: 'error'
            });
          }
        })
      },

      addRole(){
        this.roleOperationType="add";
        this.roleDialogName="添加角色";
        this.dialogAddRoleVisible=true;
      },
      editRole(role){
        this.roleOperationType="edit";
        this.roleDialogName="编辑角色";
        this.roleForm.roleType=role.roleType;
        this.roleForm.roleId=role.roleId;
        this.roleForm.roleName=role.roleName;
        this.dialogAddRoleVisible=true;
      },

      roleDialogClose(){
        this.resetvalidate("roleForm");
        this.roleForm.roleType=null;
        this.roleForm.roleId="";
        this.roleForm.roleName="";
        this.dialogAddRoleVisible=false;
      },

      resetvalidate(formName){
        if(this.$refs[formName]!==undefined){
          //this.$refs[formName].resetFields();//如果只是清除表单验证用
          this.$refs[formName].clearValidate();
        }
      },
      checkAndDeleteRole(role){
        let msg = "确定删除角色"+"【"+role.roleName+"】";
        $http.get($http.api.user.checkRole,{roleId: role.roleId}).then((res) =>{
          if (res.status===200){
            if(res.data > 0){
              msg = "此角色有绑定用户，确定删除角色"+"【"+role.roleName+"】";
            }
          }
          this.deleteRole(role, msg);
        })
      },

      deleteRole(role, msg){
        this.$confirm(msg, "提示", {
          distinguishCancelAndClose: true,
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning"
        }).then(() => {
          $http.get($http.api.user.deleteRole,{roleId: role.roleId}).then((res) =>{
            if (res.status===200){
              this.$message({
                message: '删除成功',
                type: 'success'
              });
              this.searchRoleType();
            } else {
              this.$message({
                message: res.msg,
                type: 'error'
              });
            }
          })
        })
      },

      saveRole(){
        if (this.roleForm.roleType===null){
          this.$message({
            message: '角色类型不能为空',
            type: 'warning'
          });
          return;
        };

        let params={
          roleId: this.roleForm.roleId,
          roleName: this.roleForm.roleName,
          roleType:this.roleForm.roleType
        };
        this.$refs['roleForm'].validate((valid) => {
          if (valid) {
            if (this.roleOperationType==="add"){
              $http.post($http.api.user.addRole,params).then((res) =>{
                if (res.status===200){
                  this.$message({
                    message: '保存成功',
                    type: 'success'
                  });
                  this.searchRoleType();
                  this.roleDialogClose();
                }else{
                  this.$message({
                    message: '保存失败',
                    type: 'error'
                  });
                }
              })
            }else {
              $http.post($http.api.user.updateRole,params).then((res) =>{
                if (res.status===200){
                  this.$message({
                    message: '保存成功',
                    type: 'success'
                  });
                  this.searchRoleType();
                  this.roleDialogClose();
                }else{
                  this.$message({
                    message: '保存失败',
                    type: 'error'
                  });
                }
              })
            }
          }
        });
      }
    }
  };
</script>

<style lang="scss" scoped>
  @import 'manageCommon';

  #app .roleset-height {
    height: 500px;
    overflow-y: auto;
  }
  .roleset-label-color {
    color: #1a1b1d;
  }
  .roledialog-select {
    width: 100%;
  }
</style>
