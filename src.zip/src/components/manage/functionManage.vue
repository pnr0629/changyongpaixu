<template>
  <div id="manage-box" class="content-outer-box">
    <div class="x-arD content-box">
      <div class="function-bar">
        <span class="function-bar-title ml10 mr10 fl">功能管理</span>
        <el-select class="function-bar-select fl mt10" placeholder="选择功能" v-model="functionType" @change="handleSelectChange">
          <el-option v-for="(item,index) in outterFuncList" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <el-input v-model="search" class="function-bar-input-s fl ml15" placeholder="输入功能ID或功能名称搜索" @input="handleSerch"/>
        <el-button type="primary" class="ml10" @click="addFunc">添加功能</el-button>
      </div>
      <div class="white-box table-outer-box">
        <div class="table-outer-style">
          <el-table border
                    :class="{'el-table-left-none':functionList.length == 0,'el-table-right-none':functionList.length != 0}"
                    :data="functionList">
            <el-table-column prop="functionId" label="功能ID" min-width="100"></el-table-column>
            <el-table-column prop="functionName" label="功能名称" min-width="100"></el-table-column>
            <el-table-column prop="url" label="功能URL" min-width="100"></el-table-column>
            <el-table-column prop="functionType" label="功能类型" min-width="100">
              <template slot-scope="scope">
                <span>{{scope.row.functionTypeStr}}</span>
              </template>
            </el-table-column>
            <el-table-column prop="createUser" label="创建人" min-width="100"></el-table-column>
            <el-table-column prop="updateTime" label="最后更新时间" min-width="100"></el-table-column>
            <el-table-column label="操作" width="150">
              <template slot-scope="scope">
                <span class="c-blue cp ml10" @click="editFunc(scope.row.functionId)">编辑</span>
                <span class="c-blue cp" @click="delFunc(scope.row)">删除</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="table_b_f_b">
          <el-pagination
            class="fr mr20 pageination-top"
            @size-change="handleSizeChange"
            @current-change="handlePageChange"
            :current-page="pageInfo.pageNum"
            :page-sizes="[10, 20, 30]"
            :page-size="pageInfo.pageSize"
            layout="total, sizes, prev, pager, next, jumper"
            :total="pageInfo.total">
          </el-pagination>
        </div>
      </div>
    </div>

    <!--编辑功能-->
    <el-dialog
      title="编辑功能"
      :visible.sync="editDialogVisible"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="funcInfo" ref="funcInfoForm" label-width="100px" label-position="right">
          <el-form-item label="功能类型:" class="mb20" prop="functionType" :rules="[{required: true, message: '不能为空', trigger: 'blur'}]">
            <el-select placeholder="选择功能" style="width: 430px" class="fl ml10 mt10" v-model="funcInfo.functionType">
              <el-option v-for="(item,index) in funcList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="功能ID:" class="mb15" prop="functionId" :rules="rules.functionId">
            <el-input v-model="funcInfo.functionId" placeholder="请输入功能ID" disabled></el-input>
          </el-form-item>
          <el-form-item label="功能名称:" class="mb20" prop="functionName" :rules="rules.functionName">
            <el-input v-model="funcInfo.functionName" placeholder="请输入功能名称"></el-input>
          </el-form-item>
          <el-form-item label="功能URL:" class="mb15">
            <el-input placeholder="请输入url" v-model="funcInfo.url"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeEditDialog">关闭</el-button>
        <el-button type="primary" @click="saveFunc">保存</el-button>
      </span>
    </el-dialog>

    <!--添加功能-->
    <el-dialog
      title="添加功能"
      :visible.sync="addDialogVisible"
      class="el-dialog-580w issuedialog">
      <div class="form-iterm-box">
        <el-form :model="funcInfo" ref="funcInfoForm1" label-width="100px" label-position="right">
          <el-form-item label="功能类型:" class="mb20" prop="functionType" :rules="[{required: true, message: '不能为空', trigger: 'blur'}]">
            <el-select placeholder="选择功能" class="fl ml10 mt10 functionType" v-model="funcInfo.functionType">
              <el-option v-for="(item,index) in funcList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="功能ID:" class="mb15" prop="functionId" :rules="rules.functionId">
            <el-input v-model="funcInfo.functionId" placeholder="请输入功能ID"></el-input>
          </el-form-item>
          <el-form-item label="功能名称:" class="mb20" prop="functionName" :rules="rules.functionName">
            <el-input v-model="funcInfo.functionName" placeholder="请输入功能名称"></el-input>
          </el-form-item>
          <el-form-item label="功能URL:" class="mb15">
            <el-input placeholder="请输入url" v-model="funcInfo.url"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="closeAddDialog">关闭</el-button>
        <el-button type="primary" @click="tjFunc">保存</el-button>
      </span>
    </el-dialog>

  </div>
</template>

<script>
  export default {
    name: "FunctionManage",
    data() {
      let validValue = (rule, value, callback) => {
        if (value && (value.trim() != '') && (!value.startsWith(' '))) {
          callback();
        }
        callback(new Error("请去除空格等无用字符"));
      };
      return {
        rules: {
          functionName: [{required: true, message: '功能名称不能为空', trigger: 'blur'},{validator: validValue, trigger: 'blur'}],
          functionId: [{required: true, message: '功能ID不能为空', trigger: 'blur'},{validator: validValue, trigger: 'blur'}]
        },
        addDialogVisible: false,
        outterFuncList: [
          {id: -1, name:'全部功能'},
          {id: 0, name:'系统功能'},
          {id: 1, name:'业务功能'},
          {id: 2, name:'应用功能'},
          {id: 3, name:'项目功能'},
        ],
        funcList: [
          {id: 0, name:'系统功能'},
          {id: 1, name:'业务功能'},
          {id: 2, name:'应用功能'},
          {id: 3, name:'项目功能'},
        ],
        funcInfo: {
          functionId: '',
          functionType: 0,
          functionName: '',
          url: '',
          updateTime: '',
          createTime: '',
          createUser: ''
        },
        editDialogVisible: false,
        search: '',
        functionType: 0,
        pageInfo: {
          pageNum: 1,
          pageSize: 10,
          total: 0,
          pages: 0
        },
        functionList: []
      };
    },

    mounted() {
      this.getFuncList();
    },

    methods: {
      handleSerch() {
        this.getFuncList();
      },
      tjFunc() {
        this.$refs["funcInfoForm1"].validate(validate => {
          if (validate) {
            $http.post($http.api.function_manage.add_func, this.funcInfo).then(res => {
              if (res.status == 200) {
                this.$message({message: '添加功能成功', type: 'success'});
                this.closeAddDialog();
                this.getFuncList();
              } else {
                this.$message({message: '添加功能失败', type: 'error'});
              }
            }).catch(_ => {})
          }
        })
      },
      addFunc() {
        this.funcInfo = {};
        this.addDialogVisible = true;
      },
      closeEditDialog() {
        this.funcInfo = {};
        this.editDialogVisible = false;
      },
      closeAddDialog() {
        this.funcInfo = {};
        this.addDialogVisible = false;
      },
      saveFunc() {
        this.$refs["funcInfoForm"].validate(validate => {
          if (validate) {
            $http.get($http.api.function_manage.update_func, this.funcInfo).then(res => {
              if (res.status == 200) {
                this.$message({message: '编辑功能成功', type: 'success'});
                this.closeEditDialog();
                this.getFuncList();
              } else {
                this.$message({message: '编辑功能失败', type: 'error'});
              }
            })
          }
        });
      },
      getFuncList() {
        let param = {}
        param.functionType = this.functionType;
        param.pageNum = this.pageInfo.pageNum;
        param.pageSize = this.pageInfo.pageSize;
        param.keyWord = this.search;
        $http.get($http.api.function_manage.get_func_list, param).then(res => {
          if (res.status == 200) {
            this.pageInfo = res.data;
            let funcList = res.data.list;
            funcList.forEach(item => {
              this.getFunctionTypeStr(item);
            })
            this.functionList = funcList;
          } else {
            this.$message({message: '获取功能列表失败', type: 'error'});
          }
        })
      },
      editFunc(functionId) {
        this.editDialogVisible = true;
        let param = {};
        param.functionId = functionId;
        $http.get($http.api.function_manage.get_func_info, param).then(res => {
          if (res.status == 200) {
            this.funcInfo = res.data;
          } else {
            this.$message({message: '获取功能信息失败', type: 'error'});
          }
        })
      },
      delFunc(item) {
        this.$confirm('确认删除该功能[' + item.functionName + ']吗？').then(_ => {
          let param = {};
          param.functionId = item.functionId;
          $http.get($http.api.function_manage.del_func, param).then(res => {
            if (res.status == 200) {
              this.$message({message: '删除功能成功', type: 'success'});
              this.getFuncList();
            } else {
              this.$message({message: '删除功能失败', type: 'error'});
            }
          })
        }).catch(_ => {});
      },
      getFunctionTypeStr(item) {
        if (!item.functionType) {
          item.functionTypeStr = '';
        }
        if (item.functionType == 0) {
          item.functionTypeStr = '系统功能';
        }
        if (item.functionType == 1) {
          item.functionTypeStr = '业务功能';
        }
        if (item.functionType == 2) {
          item.functionTypeStr = '应用功能';
        }
        if (item.functionType == 3) {
          item.functionTypeStr = '项目功能';
        }
      },
      handlePageChange(val) {
        this.pageInfo.pageNum = val;
        this.getFuncList();
      },
      handleSizeChange(val) {
        this.pageInfo.pageSize = val;
        this.getFuncList();
      },
      handleSelectChange(val) {
        this.functionType = val;
        this.getFuncList();
      },
    },
    components: {}
  };
</script>

<style lang="scss" scoped>
  @import 'manageCommon';

  .issuedialog {
    .functionType {
      width: 430px;
    }
    .addclassTap {
      height: 40px;
      margin-bottom: 10px;
      border-bottom: 2px solid #d8dee5;

      .tapTitile {
        font-size: 16px;
        font-weight: 400;
      }

      .addtap {
        float: right;
      }
    }

    .tabtable {
      height: 490px;
      //   background: red;
    }
  }

  .el-tabs-wai {
    height: 100%;

    .el-tabs__content {
      height: calc(100% - 55px);
      overflow: hidden;
      overflow: auto;

      .el-tab-pane {
        height: calc(100% - 10px);
      }
    }
  }

  .paintermouse {
    cursor: pointer;
  }

  .paintermouse:hover {
    color: #409eff;
  }
</style>
